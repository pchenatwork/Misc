﻿using EVO.TimesheetPortal.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Site.Models
{
    public class TimeSheetModel
    {
       
        public int ResourceId { get; set; }
       
        public string ResourceName { get; set; }
       
        public string ResourceType { get; set; }
        /// <summary>
        ///  Generic Subject ID (eg ProjectID), 
        /// </summary>
       
        public int SubjectId { get; set; }
      
        public string SubjectName { get; set; }
        
        public string SubjectType { get; set; }
       
        public DateTime FromDate { get; set; }
       
       
        public DateTime ToDate { get; set; }
      

       
        public string CurrentPeriodCode { get; set; }
     
        public string PeriodCode { get; set; }
      
        public int PeriodStatusId { get; set; }
        public string PeriodStatus
        {
            get { return TimesheetPeriodStatusEnum.GetById(PeriodStatusId).Name; }
        }
       
        public int TimesheetStatusId { get; set; }
        public string TimesheetStatus
        {
            get { return TimesheetStatusEnum.GetById(TimesheetStatusId).Name; }
        }
       
        public decimal Hours { get; set; }

       

        public static List<TimeSheetModel> MapEntitysToModels(ICollection<Timesheet> entities)
        {
            if(entities == null || entities.Count < 1)
            {
                return new List<TimeSheetModel>();
            }
            var timeSheetList = new List<TimeSheetModel>() { };
            foreach(var entity in entities)
            {
                var model = new TimeSheetModel();
                model.ResourceId = entity.ResourceId;
                model.PeriodCode = entity.PeriodCode;
                model.PeriodStatusId = entity.PeriodStatusId;
                model.ResourceName = entity.ResourceName;
                model.ResourceType = entity.ResourceType;
                model.SubjectId = entity.SubjectId;
                model.SubjectName = entity.SubjectName;
                model.SubjectType = entity.SubjectType;
                model.TimesheetStatusId = entity.TimesheetStatusId;
                model.ToDate = entity.ToDate;
                model.FromDate = entity.FromDate;
                model.Hours = entity.Hours;
              
                timeSheetList.Add(model);
            }
            return timeSheetList;
        }
    }
}
