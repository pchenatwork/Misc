﻿using EVO.TimesheetPortal.Entity;
using System.ComponentModel.DataAnnotations;

namespace EVO.TimesheetPortal.Site.Models
{
    public class WorkflowHistoryModel : BaseModel
    {
        public int EntityId { get; set; }
        public int StatusId { get; set; }

        [DataType(DataType.Text)]
        [StringLength(50)]
        public string StatusName
        {
            get
            {
                return
                    EntityId == 1 ? ProjectStatusEnum.GetById(StatusId).Name : (
                    EntityId == 2 ? TimesheetStatusEnum.GetById(StatusId).Name : string.Empty
                    );
            }
        }

        [DataType(DataType.Text)]
        [StringLength(300, ErrorMessage = "The Description lenth cannot greater than 300.")]
        public string Comment { get; set; }
    }
}