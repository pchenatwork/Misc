﻿using EVOUserWSServiceReference;
using System.Collections.Generic;
using System.Linq;

namespace TimeSheetTrackerCore.Site.Models
{
    public class MenuItemModel
    {
        public int ParentItemID { get; set; }
        public int MenuItemID { get; set; }
        public string MenuName { get; set; }
        public string ParentMenuItemName { get; set; }
        public string Url { get; set; }
        public int OrderBy { get; set; }
        public int MenuItemLevel { get; set; }
        public bool IsActive { get; set; }
        public bool IsVisible { get; set; }
        public List<MenuItemModel> ChildrenMenuItems { get; set; }

        public List<MenuItemModel> MapObjectToModel(List<MenuItem> menus)
        {
            List<MenuItemModel> menuModel = new List<MenuItemModel>();
            if (menus.Count > 0)
            {
                foreach (MenuItem menu in menus)
                {
                    if (menu.ParentItemID == 0)
                    {
                        MenuItemModel item = new MenuItemModel();
                        item.MenuItemID = menu.MenuItemID;
                        item.MenuName = menu.MenuName;
                        item.Url = menu.URL;
                        item.OrderBy = menu.OrderBy;
                        item.ParentItemID = menu.ParentItemID;
                        item.IsVisible = menu.IsVisible;
                        item.ParentMenuItemName = string.IsNullOrEmpty(menu.ParentItemName) ? string.Empty : menu.ParentItemName;
                        item.IsActive = menu.IsActive;
                        item.ChildrenMenuItems = (menus.Where(m => m.ParentItemID == menu.MenuItemID).Select(m => BuildMenu(m, menu.MenuName, menus)).ToList());
                        menuModel.Add(item);
                    }
                }
            }
            return menuModel;
        }

        public MenuItemModel BuildMenu(MenuItem m, string parentName, List<MenuItem> menus)
        {
            MenuItemModel menu = new MenuItemModel();
            menu.MenuItemID = m.MenuItemID;
            menu.MenuName = m.MenuName;
            menu.OrderBy = m.OrderBy;
            menu.ParentItemID = m.ParentItemID;
            menu.ParentMenuItemName = parentName;
            menu.Url = m.URL;
            menu.IsActive = m.IsActive;
            menu.IsVisible = m.IsVisible;
            menu.ChildrenMenuItems = (menus.Where(r => r.ParentItemID == m.MenuItemID).Select(r => BuildMenu(r, menu.MenuName, menus)).ToList());
            return menu;
        }
    }
}