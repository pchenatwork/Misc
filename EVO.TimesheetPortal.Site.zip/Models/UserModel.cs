﻿using EVO.TimesheetPortal.Site.Models;
using EVOUserWSServiceReference;
using System;
using System.Collections.Generic;

namespace TimeSheetTrackerCore.Site.Models
{
    public class UserModel
    {
        public User User { get; set; } = new User();

        public EmployeeModel Employee { get; set; } = new EmployeeModel();

        public List<TeamModel> LoginUserTeam { get; set; } = new List<TeamModel>();

        public string RoleName { get; set; }

        public bool IsAdmin { get; set; }

        public bool CheckIsAdmin(User user)
        {
            if (user != null && user.Roles != null)
            {
                return user.Roles.RoleName.Equals("Admin", StringComparison.OrdinalIgnoreCase);
            }
            return false;
        }

        public string DisplayName => User != null ? User.FirstName + " " + User.MiddleName + " " + User.LastName : Employee.DisplayName;
    }
}