﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Models
{
    public class GridColumn
    {
        public string field { get; set; }
        public string title { get; set; }
    }

    public class EmployeeTrendData
    {
        public string ResourceName { get; set; }
        public List<GridColumn> Columns { get; set; }

    }

 
}
