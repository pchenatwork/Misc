﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Models
{
    public class SaveResult
    {
        public bool Success { get; set; }

        public object AssociatedObject { get; set; }

        public string ErrorDescription { get; set; }
    }
}
