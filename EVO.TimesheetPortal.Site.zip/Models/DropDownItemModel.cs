﻿using System.Collections.Generic;

namespace EVO.TimesheetPortal.Site.Models
{
    public class DropDownItemModelStringID
    {
        public string DataText { get; set; } = string.Empty;
        public string DataID { get; set; }
    }
    public class DropDownItemModel
    {
        public string DataText { get; set; } = string.Empty;
        public int DataID { get; set; }
    }
    public class ProjectPhaseDropDown: DropDownItemModel
    {
        public string OwnerName { get; set; }
        public int PhaseID { get; set; }
    }

    public class DropDownItemStringKeyModel
    {
        public string DataText { get; set; }
        public string DataID { get; set; }
    }

    public class TeamDropDownItemModel : DropDownItemModel
    {
        public string ManagerName { get; set; }

        public int ManagerID { get; set; }

        public string ShortName { get; set; }
    }

    public class JobgradeDropDown : DropDownItemModel
    {
        public int JobGrade { get; set; }
    }

    public class EditableDropDown : DropDownItemModel
    {
        public bool Editable { get; set; }

        public List<int> ManagerList { get; set; }
    }

}