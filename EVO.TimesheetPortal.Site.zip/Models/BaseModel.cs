﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EVO.TimesheetPortal.Site.Models
{
    public class BaseModel
    {
        public int ID { get; set; }
        public bool IsActive { get; set; }
        public DateTime UpdateDate { get; set; }

        [DataType(DataType.Text)]
        [StringLength(100)]
        public string UpdateBy { get; set; }

        public DateTime CreateDate { get; set; }

        [DataType(DataType.Text)]
        [StringLength(100)]
        public string CreateBy { get; set; }

        public bool IsReadonly { get; set; }

        /// <summary>
        /// Reserved for Model specific permission
        /// </summary>
        public bool Is1OK { get; set; }

        /// <summary>
        /// Reserved for Model specific permission
        /// </summary>
        public bool Is2OK { get; set; }

        /// <summary>
        /// Reserved for Model specific permission
        /// </summary>
        public bool Is3OK { get; set; }

        [DataType(DataType.Text)]
        /// <summary>
        /// Extra data related to the model
        /// </summary>
        public string Extra { get; set; }
    }
}