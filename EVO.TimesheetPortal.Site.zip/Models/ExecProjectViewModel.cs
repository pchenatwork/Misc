﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Models
{
    /// <summary>
    /// ViewModel for ExecApprovalProject component
    /// </summary>
    public class ExecProjectViewModel
    {
        public int EntityId { get; set; }
        public string PeriodCode { get; set; }
        public DataTable DT { get; set; }   
    }
}
