﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Models
{
    [BindProperties]
    public class TimesheetRemoveModel
    {
        public int Id { get; set; }
        public int IsTimeSheet { get; set; }
    }
}
