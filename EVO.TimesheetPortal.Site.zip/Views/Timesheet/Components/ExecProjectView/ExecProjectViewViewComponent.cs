﻿using EVO.Common.UtilityCore;
using EVO.TimesheetPortal.Site.Models;
using EVO.TimesheetPortal.Site.Service;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Text.Json;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Views.Timesheet.Components.ExecProjectList
{
    public class ExecProjectViewViewComponent : ViewComponent
    {
        private ITimeSheetService _TimesheetService;

        public ExecProjectViewViewComponent(ITimeSheetService timeSheetService)
        {
            _TimesheetService = timeSheetService;
        }
        public async Task<IViewComponentResult> InvokeAsync(int EntityId = 0, string PeriodCode = "")
        {
            if (string.IsNullOrEmpty(PeriodCode))
            {
                PeriodCode = DateTime.UtcNow.ToString("yyyyMM");
            }
            System.Data.DataTable dt = new DataTable();
            var data = await _TimesheetService.GetOutlookExecProjectView(PeriodCode, EntityId);
            if (data.Content != null)
            {
                JsonSerializerOptions options = new JsonSerializerOptions()
                { Converters = { new DataTableJsonConverter() }, WriteIndented = true };

                dt = System.Text.Json.JsonSerializer.Deserialize<System.Data.DataTable>(data.Content, options);

                // Add a total column, and calculate total
                DataColumn newCol = new DataColumn("Total", typeof(decimal));
                newCol.AllowDBNull = false;
                dt.Columns.Add(newCol);
                foreach (DataRow row in dt.Rows)
                {
                    decimal total = 0;
                    foreach (var f in row.ItemArray)
                    {
                        if (f.ToString().Split("::").Length == 3)
                            total = total + decimal.Parse(f.ToString().Split("::")[0]);
                    }
                    row["Total"] = total;
                }
            }
            var m = new ExecProjectViewModel(); 
            m.EntityId = EntityId;
            m.PeriodCode = PeriodCode;
            m.DT = dt;
            return View("Index", m);
        }

    }
}
