﻿using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using EVO.TimesheetPortal.Site.App_Classes;
using EVO.TimesheetPortal.Site.Service;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class ApplicationLogController : BaseController<IApplicationLogService>
    {
        public ApplicationLogController(IApplicationLogService service) : base(service)
        { }

        [PageEntry(ActionName = "index", ControllerName = "ApplicationLog")]
        public IActionResult Index()
        {
            return View();
        }

        public async Task<ActionResult> Read([DataSourceRequest] DataSourceRequest request)
        {
            var result = await Client.GetAllAsync();
            return Json(result.Content.ToDataSourceResult(request));
        }
    }
}