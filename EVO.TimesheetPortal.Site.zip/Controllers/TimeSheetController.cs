﻿using EasyCaching.Core;
using EmailService;
using EVO.Common.UtilityCore;
using EVO.TimesheetPortal.Entity;
using EVO.TimesheetPortal.Site.App_Classes;
using EVO.TimesheetPortal.Site.Models;
using EVO.TimesheetPortal.Site.Service;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Text;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class TimeSheetController : BaseController<ITimeSheetActivityService>
    {
        private readonly ITeamService TeamService;
        private readonly ITimeSheetActivityService ActivityService;

        private readonly IEmployeeActivityMapService MapService;
        private readonly IProjectService ProjectService;
        private readonly IEmployeeService EmployeeService;
        private readonly ITimeSheetService TimeSheetService;
        private readonly IEasyCachingProvider MemoryCache;

        private EmailServiceSoapClient EmailService;
        private IConfiguration Configuration;

        public TimeSheetController(
            ITimeSheetActivityService activityService,
            IProjectService projectService,
            IEmployeeActivityMapService mapService,
            IEmployeeService employeeService,
            EmailServiceSoapClient emailServiceSoapClient,
                                 IConfiguration configuration,
            ITimeSheetService timeSheetService, ITeamService teamService, IEasyCachingProviderFactory memoryCache)
        {
            ActivityService = activityService;
            ProjectService = projectService;
            MapService = mapService;
            EmployeeService = employeeService;
            TimeSheetService = timeSheetService;
            TeamService = teamService;
            MemoryCache = memoryCache.GetCachingProvider("timesheetcache");
            EmailService = emailServiceSoapClient;
            Configuration = configuration;
        }

        [PageEntry(ActionName = "Index", ControllerName = "TimeSheet")]
        public IActionResult Index()
        {
            var model = new BaseModel();
            model.Is1OK = ApplicationSession.IsTimesheetAdmin;
            return View(model);
        }

        [PageEntry(ActionName = "Executive", ControllerName = "TimeSheet")]
        public async Task<ActionResult> Executive()
        {
            /*&*
            var timeSheet = new TimeSheetModel();
            //var periodResult = await TimeSheetService.SearchPeriod(new TimesheetPeriod() { StatusId = TimesheetPeriodStatusEnum.Current.Id });
            //var item = periodResult.Content.FirstOrDefault();
            //if (item != null)
            //{
            //    timeSheet.CurrentPeriodCode = item.PeriodCode;
            //    timeSheet.FromDate = item.FromDate;
            //    timeSheet.ToDate = item.ToDate;
            //}

            var teamListResult = await TeamService.SearchAsync(new TeamCriteria() { ParentId = 0 });
            if (teamListResult.Content != null)
            {
                var executiveModels = ExecutiveTeamModel.MapEntitysToModels(teamListResult.Content);
                ViewData["teams"] = System.Text.Json.JsonSerializer.Serialize(executiveModels);
            }

            return View(timeSheet);
            **/

            var timeSheet = await TimeSheetService.GetOutlookExecApprovalView(1); // Default AccoutingEntity=1 (USA)
            return View("ApprovalExec", timeSheet.Content??new Timesheet());
        }

        [HttpGet]
        public async Task<TimesheetPeriod> GetCurrentPeriod()
        {
            var result = await TimeSheetService.SearchPeriod(new TimesheetPeriod() { StatusId = TimesheetPeriodStatusEnum.Current.Id });
            if (result.Content != null)
            {
                return result.Content.FirstOrDefault();
            }
            return new TimesheetPeriod();
        }

        [HttpPost]
        public async Task<JsonResult> ExecutiveApproval(string periodCode, int accountingEntityId)
        {
            var user = ApplicationSession.GetUser();
            var saveResult = new Models.SaveResult() { Success = true };
            var result = await TimeSheetService.ExecutiveApproval(periodCode, user?.Employee?.UserId, accountingEntityId);
            if (result.Error != null)
            {
                saveResult.Success = false;
                saveResult.ErrorDescription = "Executive Approval Error.";
            }
            else
            {
                saveResult.Success = result.Content;
                await SendEmailForAccounting(periodCode);
            }
            return Json(saveResult);
        }

        [HttpPost]
        public async Task<JsonResult> ExecutiveApprovalUndo(string periodCode)
        {
            var user = ApplicationSession.GetUser();
            var saveResult = new Models.SaveResult() { Success = true };
            var result = await TimeSheetService.ExecutiveApprovalUndo(periodCode, user?.Employee?.UserId);
            if (result.Error != null)
            {
                saveResult.Success = false;
                saveResult.ErrorDescription = "Undo Executive Approval Error.";
            }
            else
            {
                saveResult.Success = result.Content;
            }
            return Json(saveResult);
        }

        public async Task<JsonResult> GetResourView([DataSourceRequest] DataSourceRequest request, string periodCode,int entityId)
        {
            var data = await TimeSheetService.GetOutlookByTeamResource(periodCode,entityId);
            if (data.Content != null)
            {
                var timesheetModelList = TimeSheetModel.MapEntitysToModels(data.Content?.Details);
                return Json(timesheetModelList.ToDataSourceResult(request));
            }
            return Json(new List<TimeSheetModel>().ToDataSourceResult(request));
        }

        public async Task<ActionResult> GetResourceDetail(int projectId = 1, int teamId = 9, string periodCode = "",int entityId =0)
        {
            var data = await TimeSheetService.GetOutlookByTeamProject(teamId, projectId, periodCode,entityId);
            var result = data.Content;
            result = result ?? new Timesheet();
            return PartialView("ResourceDetail", result);
        }

        public async Task<ActionResult> GetExecutionSummary(string periodCode, int entityId)
        {
            var data = await TimeSheetService.GetOutlookByExecutiveSummary(periodCode,entityId);

            if (data.Content != null)
            {
                JsonSerializerOptions options = new JsonSerializerOptions()
                { Converters = { new DataTableJsonConverter() }, WriteIndented = true };

                var dataTable = System.Text.Json.JsonSerializer.Deserialize<System.Data.DataTable>(data.Content, options);
                var projectData = await TimeSheetService.GetOutlookProjectSummary(periodCode,entityId);

                var projectSummary = System.Text.Json.JsonSerializer.Deserialize<List<ProjectSummaryModel>>(projectData.Content, options);

                // var projectSummary = DataTableUtil.ToEntityList<ProjectSummaryModel>(projectSummaryTable);

                dataTable.Columns.Add("Total");
                for (var i = 0; i < dataTable.Rows.Count; i++)
                {
                    var row = dataTable.Rows[i];
                    var projectObj = row["Project"];
                    var projectName = projectObj != null ? projectObj.ToString() : "";
                    row["Total"] = 0.00;
                    if (!string.IsNullOrWhiteSpace(projectName))
                    {
                        var projectItem = projectSummary.Where(o => o.ProjectName.Equals(projectName)).FirstOrDefault();
                        if (projectItem != null)
                        {
                            row["Total"] = projectItem.Hours;
                        }
                    }
                }

                return Json(dataTable);
            }
            return Json(null);
        }

        public async Task<JsonResult> GetTimesheetMonthly([DataSourceRequest] DataSourceRequest request, TimesheetSearchModel searchModel)
        {
            var user = ApplicationSession.GetUser();
            int employeeId = user.Employee.ID;
            if (ApplicationSession.IsTimesheetAdmin)
            {
                employeeId = searchModel.EmployeeId;
            }
            var timesheetData = (await ActivityService.
                GetByMonthAsync(employeeId, searchModel.StartDate.GetValueOrDefault(DateTime.UtcNow),
                searchModel.EndDate.GetValueOrDefault(DateTime.UtcNow))).Content
                ?? new List<TimesheetActivity>();

            List<TimesheetMonthModel> monthList = new List<TimesheetMonthModel>();
            foreach (var timeData in timesheetData)
            {
                monthList.Add(new TimesheetMonthModel()
                {
                    Start = new DateTime(timeData.ActivityDate.Ticks, DateTimeKind.Utc),
                    End = new DateTime(timeData.ActivityDate.Ticks, DateTimeKind.Utc),
                    ResourceID = timeData.EmployeeId,
                    Title = timeData.Hours.ToString(),
                    Description = timeData.Hours.ToString()
                });
            }

            return Json(monthList.ToDataSourceResult(request));
        }

        public async Task<ActionResult> Read([DataSourceRequest] DataSourceRequest request, DateTime activityDate, int resourceID)
        {
            var user = ApplicationSession.GetUser();
            int employeeId = user.Employee.ID;
            if (ApplicationSession.IsTimesheetAdmin)
            {
                employeeId = resourceID;
            }
            var timesheetData = (await ActivityService.GetByDateAsync(employeeId, activityDate)).Content;
            if (timesheetData == null)
            {
                timesheetData = new List<TimesheetActivity>();
            }
            var list = timesheetData.Select(s => TimesheetActivityModel.MappingFromEntity(s)).ToList();
            return Json(list.ToDataSourceResult(request));
        }

        public ActionResult CreateTask()
        {
            var model = new NewTaskModel();
            return PartialView("Task", model);
        }

        [HttpGet]
        [Consumes("application/json")]
        public async Task<JsonResult> GetProjectList(int resourceID)
        {
            var projectData = (await GetProjects(resourceID)).OrderBy(c => c.IsPredefined).ToList();
            return Json(projectData.Select(s => new DropDownItemModel { DataID = s.Id, DataText = s.Name }));
        }

        private async Task<IList<Project>> GetProjects(int resourceID)
        {
            var searchEntity = new Entity.Project();
            bool isAdmin = false;
            Collection<Team> teams = new Collection<Team>();
            if (ApplicationSession.IsTimesheetAdmin && resourceID > 0)
            {
                var team = EmployeeService.GetAsync(resourceID).Result?.Content?.Team;
                if (team != null)
                {
                    teams.Add(team);
                }
                isAdmin = false;
            }
            else
            {
                ApplicationSession.GetUser().LoginUserTeam.ForEach(t => teams.Add(TeamModel.MapModelToObject(t)));
                isAdmin = ApplicationSession.IsITExecutive || ApplicationSession.IsProjectAdmin;
            }
            searchEntity.Teams = teams;
            searchEntity.IsAdmin = isAdmin;
            searchEntity.QueryStatus = new Collection<int> { ProjectStatusEnum.Approved };

            return (await ProjectService.SearchAsync(searchEntity)).Content;
        }

        private async Task<IList<Team>> GetTeams()
        {
            return (await TeamService.SearchAsync(new TeamCriteria())).Content;
        }

        [HttpPost]
        public async Task<JsonResult> CreateTaskForm([Bind(@"EmployeeId,ProjectId,ActivityId,ActivityDate")] TimesheetCreateModel model)
        {
            var saveResult = new Models.SaveResult() { Success = false };
            var user = ApplicationSession.GetUser();
            int employeeId = user.Employee.ID;
            if (ApplicationSession.IsTimesheetAdmin)
            {
                employeeId = model.EmployeeId;
            }
            var dailyData = (await ActivityService.GetByDateAsync(employeeId, model.ActivityDate)).Content;
            if (dailyData != null && dailyData.Where(s => s.ProjectId == model.ProjectId && s.ActivityId == model.ActivityId).Count() > 0)
            {
                saveResult.Success = false;
                saveResult.ErrorDescription = "The project and activity exists, please try another one.";
                return Json(saveResult);
            }
            TimesheetActivity entity = new TimesheetActivity()
            {
                ActivityDate = model.ActivityDate,
                EmployeeId = employeeId,
                ProjectId = model.ProjectId,
                ActivityId = model.ActivityId,
                CreateBy = user.DisplayName
            };
            var employeeActivityMap = new EmployeeActivityMap()
            {
                EmployeeId = employeeId,
                ProjectId = model.ProjectId,
                ActivityId = model.ActivityId,
                CreateBy = user.User?.UserName
            };
            saveResult.Success = (await MapService.InsertAsync(employeeActivityMap)).Content > 0;
            var newData = TimesheetActivityModel.MappingFromEntity((await ActivityService.GetByCriteria(entity)).Content);
            saveResult.AssociatedObject = newData;
            return Json(saveResult);
        }

        [HttpPost]
        public async Task<JsonResult> UpdateTask([Bind(@"Id,Hours,Description,IsTimeSheet,EmployeeId,ProjectId,ActivityId,ActivityDate")] TimesheetUpdateModel model)
        {
            var saveResult = new Models.SaveResult() { Success = false };
            var user = ApplicationSession.GetUser();
            int employeeId = user.Employee.ID;
            if (ApplicationSession.IsTimesheetAdmin)
            {
                employeeId = model.EmployeeId;
            }
            TimesheetActivity entity = new TimesheetActivity();
            if (model.IsTimeSheet == 1)
            {
                entity = (await ActivityService.GetAsync(model.Id)).Content;
                entity.Hours = model.Hours;
                entity.Description = model.Description;
                entity.UpdateBy = user.DisplayName;
            }
            else
            {
                entity.ProjectId = model.ProjectId;
                entity.ActivityId = model.ActivityId;
                entity.ActivityDate = model.ActivityDate;
                entity.Hours = model.Hours;
                entity.Description = model.Description;
                entity.CreateBy = user.DisplayName;
                entity.EmployeeId = employeeId;
            }
            saveResult.Success = (await ActivityService.InsertAsync(entity)).Content?.Id > 0;
            var newData = TimesheetActivityModel.MappingFromEntity((await ActivityService.GetByCriteria(entity)).Content);
            saveResult.AssociatedObject = newData;

            return Json(saveResult);
        }

        [HttpPost]
        public async Task<JsonResult> RemoveTask([Bind(@"Id,IsTimeSheet")] TimesheetRemoveModel model)
        {
            var saveResult = new Models.SaveResult() { Success = true };
            if (model.IsTimeSheet == 1)
            {
                saveResult.Success = (await ActivityService.DeleteAsync(model.Id)).Content;
            }
            else
            {
                saveResult.Success = (await MapService.DeleteAsync(model.Id)).Content;
            }
            return Json(saveResult);
        }

        #region Timesheet Approval

        [PageEntry(ActionName = "Approval", ControllerName = "TimeSheet")]
        public ActionResult Approval()
        {
            var invalidCount = MemoryCache.Get<int>(UserName + "invalidCount");
            ViewData["IsInvalid"] = invalidCount.HasValue ? true : false;
            ViewData["SelectValue"] = ApplicationSession.GetUser()?.Employee?.Team?.Owner?.ID 
                == ApplicationSession.GetUser()?.Employee?.ID 
                ? ApplicationSession.GetUser()?.Employee?.Team?.Owner?.ID.ToString() : "";
            var model = new BaseModel();
            var user = ApplicationSession.GetUser().Employee;
            model.Is1OK = (user?.ID == user?.Team?.Manager?.ID || ApplicationSession.IsTimesheetAdmin)
                && ApplicationSession.GetPermissionAccessByKey("Timesheet_Approve");
            return View(model);
        }

        [HttpGet]
        [Consumes("application/json")]
        public async Task<ActionResult> GetResources()
        {
            //need admin permission to get all resources.
            var currEmpId = ApplicationSession.GetUser()?.Employee?.ID;
            var list = new List<DropDownItemStringKeyModel>();
            var employeeList = await GetResourceList();
            employeeList?.ForEach(p => { list.Add(new DropDownItemStringKeyModel() { DataText = p.DisplayName, DataID = p.Id.ToString() }); });
            return Json(list);
        }

        private async Task<List<Employee>> GetResourceList()
        {
            var currEmpId = (ApplicationSession.GetUser()?.Employee?.ID) ?? 0;
            var employeeList = await EmployeeService.FindForManagerApprovalAsync(currEmpId);
            return employeeList.Content;

            /// 1/6/2021 Simplify logic by PC
            ///var employeeList = new List<Employee>();
            ////var currEmpId = ApplicationSession.GetUser()?.Employee?.ID;
            ////var userList = (await EmployeeService.GetAllAsync()).Content;
            ////var roleNames = ResouceRolesEnum.List.Select(c => c.Name).ToList();
            ////userList = userList?.Where(c => c.RoleNames != null && c.RoleNames.Count > 0 && c.RoleNames[0] != null && roleNames.Contains(c.RoleNames[0])).ToList();
            ////if (ApplicationSession.IsTimesheetAdmin)
            ////{
            ////    employeeList = userList;
            ////}
            ////else
            ////{
            ////    employeeList = userList.Where(w => w.Team?.Manager?.Id == currEmpId || w.Team?.Owner?.Id == currEmpId).ToList();
            ////    //get the employee whose team manager==current user or  get the employee whose team owner==current user
            ////}

            ////return employeeList;
        }

        public async Task<JsonResult> Approval_Read([DataSourceRequest] DataSourceRequest request, string periodCode, int resourceId)
        {
            var timesheetData = (await TimeSheetService.GetOutlookByEmployee(resourceId, periodCode)).Content;
            if (timesheetData == null)
            {
                return Json(new List<Timesheet>().ToDataSourceResult(request));
            }
            return Json(timesheetData?.Details.ToDataSourceResult(request));
        }

        public async Task<ActionResult> GetTimesheetDetail(string periodCode, int resourceId, int projectId)
        {
            var timesheetData = (await TimeSheetService.GetOutlookByEmployeeProject(resourceId, projectId, periodCode)).Content;
            //  var activityList = timesheetData == null ? new Collection<TimesheetActivity>() : timesheetData.Activities;
            return PartialView("TimeSheetDetail", timesheetData);
        }

        /// <summary>
        /// Create by PCHEN for DEMO purpose using ViewComponent
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="PeriodCode"></param>
        /// <returns></returns>
        public IActionResult ReloadManagerApproval(int EmployeeId, string PeriodCode)
        {
            return ViewComponent("ManagerApproval", new { EmployeeId = EmployeeId, PeriodCode = PeriodCode });
        }
        public IActionResult GetViewExecProjectView(int EntityId, string PeriodCode)
        {
            return ViewComponent("ExecProjectView", new { EntityId = EntityId, PeriodCode = PeriodCode });
        }

        [HttpPost]
        public async Task<JsonResult> ManagerApproval(int EmployeeId, string PeriodCode)
        {
            var user = ApplicationSession.GetUser();
            var saveResult = new Models.SaveResult() { Success = true };
            saveResult.Success = (await TimeSheetService.ManagerApproval(EmployeeId, PeriodCode, user.DisplayName)).Content;
            return Json(saveResult);
        }

        [HttpPost]
        public async Task<JsonResult> ManagerApprovalUndo(int EmployeeId, string PeriodCode)
        {
            var user = ApplicationSession.GetUser();
            var saveResult = new Models.SaveResult() { Success = true };
            saveResult.Success = (await TimeSheetService.ManagerApprovalUndo(EmployeeId, PeriodCode, user.Employee.UserId)).Content;
            return Json(saveResult);
        }

        #endregion Timesheet Approval

        #region Summary Report

        //private List<TimesheetModel> GetTimeSheetSummary(int period)
        //{
        //    var queryModel = new TimeSheetQueryEntity();
        //    queryModel.PeriodMonthID = period;
        //    queryModel.IsAdmin = ApplicationSession.IsITExecutive;
        //    var teams = new List<TeamEntity>();
        //    ApplicationSession.GetUser().LoginUserTeam.ForEach(f => teams.Add(new TeamEntity { TeamID = f.TeamID }));

        //    queryModel.Teams = teams.ToArray();
        //    return Client.GetTimeSheetSummary(queryModel);
        //}

        public async Task<ActionResult> GetTimesheetSummary(string periodCode)
        {
            var employeId = ApplicationSession.GetUser().Employee?.ID ?? 0;
            var timesheetData = (await TimeSheetService.GetEmployeeSummaryData(employeId, periodCode)).Content;
            return PartialView("TimesheetSummary", timesheetData);
        }

        #endregion Summary Report

        #region Trend Report

        public async Task<ActionResult> GetTimesheetTrend(string period, int employeeid)
        {
            var trendList = new List<Timesheet>();
            var trendData = (await TimeSheetService.GetTrendData(employeeid, period)).Content;
            if (trendList != null)
            {
                trendList = trendData.Details.ToList();
            }

            string employeeName = (await EmployeeService.GetAsync(employeeid)).Content?.DisplayName;
            int i = 1;
            List<GridColumn> monthCols = new List<GridColumn>();
            List<string> monthColsArr = new List<string>();
            List<decimal> nums = new List<decimal>();
            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonTextWriter(sw);
            writer.WriteStartObject();
            if (trendList != null && trendList.Count > 0)
            {
                foreach (var data in trendList)
                {
                    string fieldName = "Month" + i.ToString();
                    monthCols.Add(new GridColumn() { field = fieldName, title = data.PeriodCode });
                    monthColsArr.Add(data.PeriodCode);
                    nums.Add(data.Hours);
                    writer.WritePropertyName(fieldName);
                    writer.WriteValue(data.Hours.ToString("0.00"));
                    i++;
                }
            }
            writer.WriteEndObject();
            writer.Flush();
            string jsonText = sw.GetStringBuilder().ToString();
            // monthCols.Reverse();
            ViewData["monthCols"] = System.Text.Json.JsonSerializer.Serialize(monthCols);
            ViewData["monthColsArr"] = monthColsArr.ToArray();
            ViewData["employeeid"] = employeeid;
            ViewData["employeeName"] = employeeName;
            ViewData["trendData"] = jsonText;
            ViewData["lineData"] = nums;
            return PartialView("TimesheetTrend");
        }

        #endregion Trend Report

        #region Export

        [HttpPost]
        public async Task<ActionResult> Export([FromServices] IWebHostEnvironment webHostingEnv, [FromQuery] string periodCode)
        {
            // Guid guid = Guid .NewGuid();
            var empId = ApplicationSession.GetUser().Employee?.ID ?? 0;
            //var isAdmin = ApplicationSession.IsITExecutive || ApplicationSession.IsProjectAdmin;
            var results = (await TimeSheetService.GetTeamExportData(empId, periodCode)).Content;

            return DownLoadFile(webHostingEnv, "TimeSheetExportList.xlsx", new { Items = results });
        }

        [HttpGet]
        public FileResult GetGeneratedExcel(string title, string guid)
        {
            // Is there a spreadsheet stored in session?
            if (!HttpContext.Session.TryGetValue(guid, out byte[] file))
            {
                throw new Exception(string.Format("{0} not found", title));
            }

            // Get the spreadsheet from session.
            string filename = string.Format("{0}.xlsx", title);

            // Remove the spreadsheet from session.
            HttpContext.Session.Remove(guid);

            // Return the spreadsheet.
            // HttpContext.Response. = true;
            //HttpContext.Response.bu
            //HttpContext.Response.Headers.Add("Content-Disposition", string.Format("attachment; filename={0}", filename));
            return File(file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename);
        }

        #endregion Export

        #region Import

        [HttpPost]
        public ActionResult Download([FromServices] IWebHostEnvironment webHostingEnv)
        {
            return DownLoadFile(webHostingEnv, "TimeSheetImportTemplate.xlsx", new TimesheetActivityModel());
        }

        public async Task<ActionResult> Upload([FromServices] IWebHostEnvironment webHostingEnv, IEnumerable<IFormFile> importTimesheetFiles, int DateRange)
        {
            try
            {
                var file = importTimesheetFiles?.FirstOrDefault();
                if (file == null || file.Length < 1)
                {
                    return ValidationProblem("File length error", statusCode: 500);
                }

                List<TimeSheetUploadModel> timeSheetUploadList;

                using (var inputStream = new MemoryStream())
                {
                    await file.CopyToAsync(inputStream);
                    var data = ExcelWorksheetHelper.Read(inputStream);
                    timeSheetUploadList = DataTableUtil.ToEntityList<TimeSheetUploadModel>(data);
                }

                if (timeSheetUploadList == null || timeSheetUploadList.Count < 1)
                {
                    return ValidationProblem(" Timesheet file should contains at least one record.", statusCode: 207);
                }
                var inValidList = await SaveValidTimesheet(timeSheetUploadList, UserName);

                if (inValidList.Count > 0)
                {
                    MemoryCache.Set<int>(UserName + "invalidCount", inValidList.Count, TimeSpan.FromSeconds(60));
                    MemoryCache.Set<List<TimeSheetUploadModel>>(UserName + "timesheetinvalidList", inValidList, TimeSpan.FromSeconds(60));
                    return Json(new { Invalid = true });
                }
                else
                {
                    MemoryCache.Set<List<TimeSheetUploadModel>>(UserName + "timesheetinvalidList", inValidList, TimeSpan.FromSeconds(60));
                }

                return Ok();
            }
            catch (Exception ex)
            {
                Serilog.Log.Error(ex, "Import Timesheet file error.");
                return ValidationProblem("Import file error occurred, please try again!", statusCode: 500);
            }
        }

        public async Task<List<TimeSheetUploadModel>> SaveValidTimesheet(List<TimeSheetUploadModel> timeSheetUploadList, string userName)
        {
            var invalidList = new List<TimeSheetUploadModel>();
            var validTimeSheetList = new List<TimesheetActivity>();
            var employeeList = await GetResourceList();
            var projectList = await GetProjects(0);
            //var teamList = await GetTeams();
            var requiredCheckMsg = " {0} {1} required.";
            var loginUser = ApplicationSession.GetUser();
            foreach (var item in timeSheetUploadList)
            {
                var errors = new List<string>();
                var projectEntity = projectList.FirstOrDefault(p => p.Name.Equals(item.Project, StringComparison.OrdinalIgnoreCase));

                if (string.IsNullOrWhiteSpace(item.Project))
                {
                    errors.Add("Project");
                }
                if (string.IsNullOrWhiteSpace(item.Activity) && projectEntity.IsPredefined == false)
                {
                    errors.Add("Project activity");
                }
                if (string.IsNullOrWhiteSpace(item.UserId))
                {
                    errors.Add("UserId");
                }
                if (item.Date == null)
                {
                    errors.Add("Date");
                }
                if (item.Hours == null)
                {
                    errors.Add("Hours");
                }
                if (errors.Count > 0)
                {
                    item.Error = errors.Count == 1 ? string.Format(requiredCheckMsg, string.Join(",", errors), "is") : string.Format(requiredCheckMsg, string.Join(",", errors), "are");
                    invalidList.Add(item);
                    continue;
                }

                if (item.Hours <= 0 || item.Hours > 999)
                {
                    item.Error = "Hours must be between 1 and 999.";
                    invalidList.Add(item);
                    continue;
                }

                if (projectEntity == null)
                {
                    item.Error = "Project does not exists.";
                    invalidList.Add(item);
                    continue;
                }

                if (projectEntity.StatusId != ProjectStatusEnum.Approved && projectEntity.IsPredefined == false)  // don't be approve
                {
                    item.Error = "The project is not approved.";
                    invalidList.Add(item);
                    continue;
                }

                var projectPhaseList = projectEntity.Activities;
                var phaseEntity = projectPhaseList.FirstOrDefault((entity) => entity.TextVal.Equals(item.Activity?.Trim('\t').Trim('\n'), StringComparison.OrdinalIgnoreCase));
                var employee = employeeList.Where(o => o.UserId.Equals(item.UserId, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                if (employee == null || string.IsNullOrEmpty(employee.DisplayName))
                {
                    item.Error = $"{item.UserId} does not belong to your team.";
                    invalidList.Add(item);
                    continue;
                }

                //if (!teamList.Where(t => t.Manager.Id == loginUser.Employee.ID && t.IsActive).Any(a => a.Id == employee.Team.Id)
                //   && ApplicationSession.IsTimesheetAdmin == false
                //   && !projectEntity.IsPredefined)
                //{
                //    item.Error = $"{employee.UserId} does not belong to your team.";
                //    invalidList.Add(item);
                //    continue;
                //}

                if (!projectEntity.Teams.Any(t => t.Id == employee.Team.Id) && !projectEntity.IsPredefined)
                {
                    item.Error = $"{employee.UserId} is not with the team(s) assigned to project {projectEntity.Name}.";
                    invalidList.Add(item);
                    continue;
                }

                if (phaseEntity == null && projectEntity.IsPredefined == false)
                {
                    item.Error = "Project activity does not exists.";
                    invalidList.Add(item);
                    continue;
                }

                if (projectEntity.IsPredefined)
                {
                    phaseEntity = new Setting { KeyVal = "8", TextVal = "N/A" };
                }

                TimesheetActivity entity = new TimesheetActivity()
                {
                    ActivityDate = item.Date.Value,
                    EmployeeName = item.UserId,
                    EmployeeId = employee.Id,
                    ProjectId = projectEntity.Id,
                    ProjectName = item.Project,
                    ActivityId = int.Parse(phaseEntity.KeyVal),
                    ActivityName = item.Activity,
                    CreateBy = ApplicationSession.GetUser()?.DisplayName,
                    Hours = item.Hours.Value,
                    SourceId = 2
                };
                validTimeSheetList.Add(entity);
            }

            if (validTimeSheetList.Count > 0)
            {
                var faildData = (await ActivityService.InsertBatch(validTimeSheetList, userName)).Content;
                if (faildData != null && faildData.Count > 0)
                {
                    faildData.ForEach(f =>
                    {
                        invalidList.Add(new TimeSheetUploadModel()
                        {
                            Activity = f.ActivityName,
                            Date = f.ActivityDate,
                            Error = string.Format("Import contains data that conflicts with submitted data for resource {0} on {1}", f.EmployeeName, f.ActivityDate.ToString("dd-MM-yyyy")),
                            Hours = f.Hours,
                            Project = f.ProjectName,
                            UserId = f.EmployeeName
                        });
                    });
                }
            }
            return invalidList;
        }

        [HttpPost]
        public ActionResult DownloadInvalidList([FromServices] IWebHostEnvironment webHostingEnv)
        {
            var InvlidListKey = UserName + "timesheetinvalidList";
            var data = MemoryCache.Get<List<TimeSheetUploadModel>>(InvlidListKey);
            if (data.HasValue)
            {
                return DownLoadFile(webHostingEnv, "TimeSheetInvalidList.xlsx", new { Items = data.Value });
            }
            return RedirectToAction("Approval", new { isInvalid = true });
        }

        private ActionResult DownLoadFile(IWebHostEnvironment webHostingEnv, string fileName, object templateData)
        {
            var rootPath = webHostingEnv.ContentRootPath + "\\Templates";
            var data = ExportHelper.Generate(rootPath, fileName, templateData);
            return File(data, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
        }

        #endregion Import

        #region Search

        public async Task<ActionResult> ReadSearch([DataSourceRequest] DataSourceRequest request, string periodCode)
        {
            var user = ApplicationSession.GetUser();
            int employeeId = user.Employee.ID;
            var timesheetData = (await ActivityService.GetByAccountAsync(new TimesheetCriteria() { PeriodCode = periodCode })).Content;
            if (timesheetData == null)
            {
                timesheetData = new List<TimesheetActivity>();
            }
            var list = timesheetData.Select(s => TimesheetActivityModel.MappingFromEntity(s)).ToList();
            return Json(list.ToDataSourceResult(request));
        }

        [PageEntry(ActionName = "Search", ControllerName = "TimeSheet")]
        public IActionResult Search()
        {
            return View();
        }

        #endregion Search

        private async Task SendEmailForAccounting(string periodCode)
        {
            var email = new EmailEntity();
            string periodDispay = "";
            if (!string.IsNullOrEmpty(periodCode))
            {
                int year = int.Parse(periodCode.Substring(0, 4));
                int month = int.Parse(periodCode.Substring(4, 2));
                DateTime period = DateTime.ParseExact($"{year}-{month}-01", "yyyy-MM-dd", CultureInfo.InvariantCulture);
                periodDispay = $"{ period.ToString("MMM") } { period.ToString("yyyy")}";
            }
           
            email.Body = $"{periodDispay} Timesheet has been approved. Please use https://timetrack.goevo.com to review.";
            email.Subject = $"Timesheet Portal – {periodDispay} Timesheet Has Been Approved";
            var toList = new List<string>();
            var resourceListRes = await EmployeeService.GetAllAsync();
            var itList = resourceListRes.Content?.Where(w => w.RoleNames.Any(s => s.ToLower().Contains("accounting"))).Select(s => s.Email);
            toList.AddRange(itList);
            email.To = string.Join(";", toList);
            var emailHelper = new EmailHelper(EmailService, Configuration);
            await emailHelper.SendEmailAsync(email);
        }
    }
}