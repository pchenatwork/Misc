﻿using EVO.TimesheetPortal.Site.Models;
using EVO.TimesheetPortal.Site.Service;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class AccountingEntityController : BaseController<IAccountingEntityService>
    {
        private IAccountingEntityService _svc;

        public AccountingEntityController(IAccountingEntityService accountingEntityService)
        {
            _svc = accountingEntityService;
        }

        [HttpGet]
        [Consumes("application/json")]
        public async Task<JsonResult> GetAll()
        {
            var apiResponse = await _svc.GetAllAsync();
            var list = apiResponse.Content?.ToList();
            return Json(list.Select(s => new AccountingEntityModel { ID = s.Id, Name = s.Name }));
        }
    }
}