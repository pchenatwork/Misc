﻿using DocumentFormat.OpenXml.EMMA;
using EmailService;
using EVO.TimesheetPortal.Entity;
using EVO.TimesheetPortal.Site.App_Classes;
using EVO.TimesheetPortal.Site.Models;
using EVO.TimesheetPortal.Site.Service;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class ProjectController : BaseController
    {
        private IProjectService ProjectService;
        private ITeamService TeamService;
        private EmailServiceSoapClient EmailService;
        private IConfiguration Configuration;
        private IEmployeeService EmployeeService;

        public ProjectController(IProjectService projectService,
                                 ITeamService teamService,
                                 EmailServiceSoapClient emailServiceSoapClient,
                                 IConfiguration configuration,
                                 IEmployeeService employee)
        {
            ProjectService = projectService;
            TeamService = teamService;
            EmailService = emailServiceSoapClient;
            Configuration = configuration;
            EmployeeService = employee;
        }

        [PageEntry(ActionName = "Index", ControllerName = "Project")]
        public ActionResult Index()
        {
            BaseModel model = new BaseModel();
            model.Is1OK = ApplicationSession.GetPermissionAccessByKey("Project_Edit");
            model.Is2OK = ApplicationSession.IsAccounting;
            return View(model);
        }

        [PageEntry(ActionName = "Approval", ControllerName = "Project")]
        public ActionResult Approval()
        {
            return View();
        }

        public async Task<ActionResult> Read([DataSourceRequest] DataSourceRequest request)
        {
            var projectList = await GetProject();
            return Json(projectList.ToDataSourceResult(request));
        }

        public async Task<ActionResult> Approval_Read([DataSourceRequest] DataSourceRequest request, ProjectModel model)
        {
            int status = ProjectStatusEnum.PendAppv;
            if (model.Status == "2")
            {
                status = ProjectStatusEnum.Approved;
            }
            var projectList = await GetProject(status);
            return Json(projectList.ToDataSourceResult(request));
        }

        public ActionResult CreateProject()
        {
            var model = new ProjectModel();
            return PartialView(model);
        }

        public async Task<ActionResult> UpdateProject(int Id)
        {
            var apiResponse = await ProjectService.GetAsync(Id);
            var entity = apiResponse.Content;

            return PartialView(ProjectModel.MappingFromEntity(entity));
        }

        [HttpPost]
        public async Task<JsonResult> CreateProjectForm([Bind(include: @"ID,Name,TypeID,Description,Type,PIRNo,Phase,PhaseList,Phases,Team,TeamList,Teams,EstimatedHours,
                StartDate,EndDate,ProdDate,Country,RequestedBy,Status,ProjectNo,AccountingEntityId")] ProjectModel model)
        {
            if (model == null)
            {
                return Json(false);
            }
            model.UpdateBy = UserName;
            var entity = ProjectModel.MappingFromModel(model);
            var result = await ProjectService.SaveAsync(entity);
            if (model.ID <= 0 && result.IsSuccessStatusCode)
            {
                await SendEmailForSubmit();
            }
            return Json(result.Content);
        }

        [HttpPost]
        public async Task<JsonResult> Impair([FromBody] int Id)
        {
            var entity = new WorkflowHistory();
            entity.StatusId = ProjectStatusEnum.Impaired;
            entity.UpdateBy = UserName;
            entity.EntityId = Id;
            var result = await ProjectService.UpdateStatusAsync(entity);
            return Json(result.Content);
        }

        [HttpPost]
        public async Task<JsonResult> Close([FromBody] int Id)
        {
            var entity = new WorkflowHistory();
            entity.EntityId = Id;
            entity.StatusId = ProjectStatusEnum.Closed;
            entity.UpdateBy = UserName;
            var result = await ProjectService.UpdateStatusAsync(entity);
            return Json(result.Content);
        }

        [HttpPost]
        public async Task<JsonResult> Delete([FromBody] int Id)
        {
            var entity = new WorkflowHistory();
            entity.EntityId = Id;
            entity.StatusId = ProjectStatusEnum.Deleted;
            entity.UpdateBy = UserName;
            var result = await ProjectService.UpdateStatusAsync(entity);
            return Json(result.Content);
        }

        [HttpPost]
        public async Task<JsonResult> ReSubmit([FromBody] int Id)
        {
            var entity = new WorkflowHistory();
            entity.StatusId = ProjectStatusEnum.PendAppv;
            entity.UpdateBy = UserName;
            entity.EntityId = Id;
            var result = await ProjectService.UpdateStatusAsync(entity);
            if (result.IsSuccessStatusCode)
            {
                await SendEmailForSubmit();
            }
            return Json(result.Content);
        }

        [HttpPost]
        public async Task<JsonResult> Approve([FromBody] int Id)
        {
            var entity = new WorkflowHistory();
            entity.EntityId = Id;
            entity.StatusId = ProjectStatusEnum.Approved;
            entity.UpdateBy = UserName;
            var result = await ProjectService.UpdateStatusAsync(entity);
            return Json(result.Content);
        }

        [HttpPost]
        public async Task<JsonResult> Reject([FromBody][Bind("EntityId,StatusId,StatusName,Comment")] WorkflowHistoryModel model)
        {
            var entity = new WorkflowHistory();
            entity.EntityId = model.ID;
            entity.StatusId = ProjectStatusEnum.Rejected;
            entity.Comment = model.Comment;
            entity.UpdateBy = UserName;
            var result = await ProjectService.UpdateStatusAsync(entity);
            if (result.IsSuccessStatusCode)
            {
                await SendEmailForReject(model.ID);
            }
            return Json(result.Content);
        }

        [HttpGet]
        [Consumes("application/json")]
        public async Task<JsonResult> GetTeam()
        {
            var apiResponse = await TeamService.SearchAsync(new TeamCriteria());
            var list = apiResponse.Content?.Where(w => w.IsActive).ToList().Select(s => new DropDownItemModel { DataID = s.Id, DataText = s.Name });
            return Json(list);
        }

        [HttpGet]
        public async Task<bool> CheckProjectName(string name, int id)
        {
            var apiResponse = await ProjectService.SearchAsync(new Project() { Name = name, IsAdmin = true });
            var any = apiResponse.Content?.ToList().Any(
                a => a.Name.Equals(name, StringComparison.OrdinalIgnoreCase)
                    && !a.Id.Equals(id)
                    // 11/12/2021 As per ahad, name should not be compared with rejected & impaired projects
                    // new Project can be reqeusted with the same name if it was "rejected" or "Impaired" before
                    && !(new int[] {
                        ProjectStatusEnum.Deleted.Id,
                        //ProjectStatusEnum.Rejected.Id,
                        ProjectStatusEnum.Impaired.Id}).Contains(a.StatusId)
                    );
            return any ?? false;
        }

        [HttpGet]
        [Consumes("application/json")]
        public async Task<JsonResult> GetActivity(int projectId)
        {
            var projectData = await ProjectService.GetAsync(projectId);
            var list = projectData.Content?.Activities;
            return Json(list.Select(s => new DropDownItemModelStringID { DataID = s.KeyVal, DataText = s.TextVal }).ToList());
        }

        private async Task<List<ProjectModel>> GetProject(int status = 0)
        {
            var searchEntity = new Project();
            Collection<Team> teams = new Collection<Team>();
            ApplicationSession.GetUser().LoginUserTeam.ForEach(t => teams.Add(TeamModel.MapModelToObject(t)));
            searchEntity.Teams = teams;
            searchEntity.IsAdmin = ApplicationSession.IsITExecutive || ApplicationSession.IsProjectAdmin;
            if (status > 0)
            {
                searchEntity.StatusId = status;
            }
            else
            {
                if (ApplicationSession.IsAccounting)
                {
                    searchEntity.QueryStatus = new Collection<int> { ProjectStatusEnum.Approved };
                    searchEntity.IsAdmin = true;
                }
                else if (ApplicationSession.IsITExecutive)
                {
                    searchEntity.QueryStatus = new Collection<int> { ProjectStatusEnum.Approved, ProjectStatusEnum.PendAppv, ProjectStatusEnum.Rejected };
                }
                else if (ApplicationSession.IsProjectAdmin)
                {
                    searchEntity.QueryStatus = new Collection<int> {
                        ProjectStatusEnum.Approved,
                        ProjectStatusEnum.Deleted,
                        ProjectStatusEnum.Impaired,
                        ProjectStatusEnum.Rejected,
                        ProjectStatusEnum.Closed
                    };
                }
                else
                {
                    searchEntity.QueryStatus = new Collection<int> { ProjectStatusEnum.Approved };
                }
            }

            var apiResponse = await ProjectService.SearchAsync(searchEntity);
            var list = apiResponse.Content?.Where(w => w.IsPredefined == false);
            List<ProjectModel> projectList = new List<ProjectModel>();
            if (status > 0)
            {
                list = list?.Where(w => w.StatusId == status);
            }
            list?.OrderByDescending(o => o.UpdateDate).ToList().ForEach(item =>
              {
                  projectList.Add(ProjectModel.MappingFromEntity(item));
              });
            bool editPermission = ApplicationSession.GetPermissionAccessByKey("Project_Edit");
            bool approvePermission = ApplicationSession.GetPermissionAccessByKey("Project_Approve");
            bool rejectPermission = ApplicationSession.GetPermissionAccessByKey("Project_Reject");
            projectList.ForEach(f =>
            {
                f.Is1OK = editPermission;
                f.Is2OK = approvePermission;
                f.Is3OK = rejectPermission;
            });
            return projectList;
        }

        private async Task SendEmailForSubmit()
        {
            var email = new EmailEntity();
            email.Body = @"A new project has been requested. Please use https://timetrack.goevo.com to review and approve the project.";
            email.Subject = @"Timesheet Portal – New Project Requested";
            var toList = new List<string>();
            var resourceListRes = await EmployeeService.GetAllAsync();
            var itList = resourceListRes.Content?.Where(w => w.RoleNames.Any(s => s.ToLower().Contains("itexecutive"))).Select(s => s.Email);
            toList.AddRange(itList);
            email.To = string.Join(";", toList);
            var emailHelper = new EmailHelper(EmailService, Configuration);
            await emailHelper.SendEmailAsync(email);
        }

        private async Task SendEmailForReject(int projectID)
        {
            var email = new EmailEntity();
            email.Body = @"Your project has been Rejected. Please use https://timetrack.goevo.com to review and re-submit the project.";
            email.Subject = @"Timesheet Portal – Project Request Rejected";

            var toList = new List<string>();
            var projectRes = await ProjectService.GetAsync(projectID);
            //var requestBy = projectRes.Content?.RequestBy;
            //if (!string.IsNullOrEmpty(requestBy))
            //{
            //    var resourceRes = await EmployeeService.GetAsync(int.Parse(requestBy));
            //    var resource = resourceRes.Content;
            //    toList.Add(resource.Email);
            //}
            var resourceListRes = await EmployeeService.GetAllAsync();
            var projectAdminList = resourceListRes.Content?.Where(w => w.RoleNames.Any(s => s.ToLower().Contains("projectadmin"))).Select(s => s.Email);
            toList.AddRange(projectAdminList);

            email.To = string.Join(";", toList);

            if (string.IsNullOrEmpty(email.To))
            {
                Serilog.Log.Debug("Send mail for project: cannot find the user.");
            }
            var emailHelper = new EmailHelper(EmailService, Configuration);
            await emailHelper.SendEmailAsync(email);
        }
    }
}