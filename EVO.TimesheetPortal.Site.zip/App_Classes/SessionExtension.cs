﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace EVO.TimesheetPortal.Site.App_Classes
{
    public static class SessionExtension
    {
        public static void SetJson(this ISession session, string key, object value)
        {
            session.SetString(key, JsonConvert.SerializeObject(value));
        }

        public static void SetJson<T>(this ISession session, string key, T t)
        {
            session.SetString(key, JsonConvert.SerializeObject(t));
        }

        public static T GetJson<T>(this ISession session, string key)
        {
            var sessionData = session.GetString(key);
            return sessionData == null
                 ? default(T) : JsonConvert.DeserializeObject<T>(sessionData);
        }

        public static bool IsAjaxRequest(this HttpRequest request)
        {
            if (request == null)
                throw new System.ArgumentNullException(nameof(request));

            if (request.Headers != null)
                return request.Headers["X-Requested-With"] == "XMLHttpRequest";
            return false;
        }
    }
}