﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
using System;
using System.Linq;

namespace EVO.TimesheetPortal.Site.App_Classes
{
    /// <summary>
    /// The page entry atrribute is using to check the view permission
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class PageEntryAttribute : ActionFilterAttribute
    {
        public string ActionName { get; set; }
        public string ControllerName { get; set; }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            string url = $"/{ControllerName.ToLower()}/{ActionName.ToLower()}";
            if (ApplicationSession.GetUser()?.User?.MenuItems == null)
            {
                filterContext.Result = new RedirectToRouteResult
                 (
                     new RouteValueDictionary(new
                     {
                         action = "UserLogin",
                         controller = "Login"
                     }));
                return;
            }
            if ((bool)!ApplicationSession.GetUser()?.User?.MenuItems?.Any(a => a.URL.ToLower().Contains(url)))
            {
                filterContext.Result = new RedirectToRouteResult
                (
                    new RouteValueDictionary(new
                    {
                        action = "Permission",
                        controller = "Home"
                    }));
                return;
            }
        }
    }
}