﻿using EVOUserWSServiceReference;
using Microsoft.AspNetCore.Http;
using System.Linq;
using System.Text;
using TimeSheetTrackerCore.Site.Models;

namespace EVO.TimesheetPortal.Site.App_Classes
{
    public class ApplicationSession
    {
        private static UserModel _user;

        public static string ApplicationName { get; set; } = "Time-sheet Portal";

        public static UserModel GetUser()
        {
            byte[] sessionStr = null;
            if (ApplicationContext.Current != null)
                sessionStr = ApplicationContext.Current.Session.Get("User");

            if (sessionStr == null)
            {
                return new UserModel();
            }
            _user = Newtonsoft.Json.JsonConvert.DeserializeObject<UserModel>(Encoding.UTF8.GetString(sessionStr));
            return _user;
        }

        public static void SetUser(UserModel user)
        {
            string userJson = Newtonsoft.Json.JsonConvert.SerializeObject(user);
            ApplicationContext.Current.Session.Set("User", Encoding.UTF8.GetBytes(userJson));
        }

        public static bool GetPermissionAccessByKey(string key)
        {
            UserPermissions permission = GetPermissionByKey(key);

            if (permission != null)
            {
                return true;
            }

            return false;
        }

        public static UserPermissions GetPermissionByKey(string key)
        {
            var user = GetUser().User;
            if (user == null || user.Permissions == null) return null;
            UserPermissions permission = GetUser().User?.Permissions.ToList().Find((p) =>
            {
                return !string.IsNullOrEmpty(p.PermissionName) && (p.PermissionName.ToLower() == key.ToLower());
            });

            return permission;
        }

        public static bool IsITExecutive
        {
            get
            {
                return CheckRoleName("itexecutive") || IsTimesheetAdmin;
            }
        }

        public static bool IsAdmin { get { return CheckRoleName("admin"); } }

        public static bool IsAccounting { get { return CheckRoleName("accounting"); } }

        public static bool IsProjectAdmin
        {
            get
            {
                return CheckRoleName("projectadmin") || CheckRoleName("admin");
            }
        }

        public static bool IsTimesheetAdmin
        {
            get
            {
                return CheckRoleName("timesheetadmin") || CheckRoleName("admin");
            }
        }

        private static bool CheckRoleName(string roleName)
        {
            return GetUser().User?.Roles?.RoleName?.ToLower()?.Equals(roleName) ?? false;
        }

        public static bool IsManager
        {
            get
            {
                return CheckRoleName("manager");
            }
        }

        public static string CurrentLanguage { get; set; } = "en-US";
    }
}