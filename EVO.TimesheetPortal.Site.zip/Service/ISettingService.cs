﻿using EVO.TimesheetPortal.Entity;
using Refit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Service
{
    public interface ISettingService : IService
    {
        [Get("/api/setting/search")]
        Task<ApiResponse<IList<Setting>>> SearchAsync(Setting setting);

        [Get("/api/setting/get")]
        Task<ApiResponse<Setting>> GetSettingAsync(int Id);
         
        [Post("/api/setting/save")]
        Task<ApiResponse<Setting>> SaveAsync(Setting setting);

        [Get("/api/setting/delete")]
        Task<ApiResponse<bool>> DeleteAsync(int Id);

        [Get("/api/setting/FindAccountingEnities")]
        Task<ApiResponse<IList<Setting>>> FindAccountingEnitiesAsync();
        
    }
}
