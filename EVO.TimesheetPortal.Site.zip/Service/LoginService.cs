﻿using EVO.TimesheetPortal.Entity;
using EVO.TimesheetPortal.Site.Service;
using EVOUserWSServiceReference;
using Microsoft.Extensions.Configuration;
using System.Collections.ObjectModel;
using System.Threading.Tasks;


namespace TimeSheetTrackerCore.Site.Service
{
    public class LoginService : IService
    {
        private IEVOUserWS UserManagementClient;

        private  IConfiguration Configuration;

        private IEmployeeService EmployeeService;

        public LoginService(IEVOUserWS userManagementClient, IConfiguration configuration, IEmployeeService employeeService)
        {
            UserManagementClient = userManagementClient;
            Configuration = configuration;
            EmployeeService = employeeService;
           
        }

        public async Task<UserWP> GetUserData(string userName)
        {
            string applicationName = Configuration.GetValue<string>("Application:Name");
            return await UserManagementClient.GetUserProfileAsync(applicationName, userName);
        }

        
        public async Task<int> SyncEmployee(int ID, string userID, string employeeName, string roleName,string email)
        {
            var entity = new Employee()
            {
                Id = ID,
                UserId = userID,
                DisplayName = employeeName,
                RoleNames = new Collection<string>() { roleName },
                UpdateBy = userID,
                UpdateDate = System.DateTime.UtcNow,
                Title =  roleName,
                Email = email,
                IsActive = true
            };
            var result =  await EmployeeService.UpdateAsync(entity);
            return result.Content;
        }
    }
}