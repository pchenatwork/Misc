﻿using EVO.TimesheetPortal.Entity;
using Refit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Service
{
    public interface IAccountingEntityService : IService
    {
        [Get("/api/accountingentity/getall")]
        Task<ApiResponse<IList<AccountingEntity>>> GetAllAsync();
    }
}
