﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Refit;
using EVO.TimesheetPortal.Entity;


namespace EVO.TimesheetPortal.Site.Service
{
    public interface IApplicationLogService: IService
    {

        [Post("/api/ApplicationLog")]
        Task<ApiResponse<int>> CreateAsync(ApplicationLog entity);

        [Put("/api/ApplicationLog")]
        Task<ApiResponse<int>> UpdateAsync(ApplicationLog entity);

        [Delete("/api/ApplicationLog")]
        Task<ApiResponse<bool>> DeleteAsync(int Id, string updateBy);

        [Get("/api/ApplicationLog/getall")]
        Task<ApiResponse<List<ApplicationLog>>> GetAllAsync();
    }
}
