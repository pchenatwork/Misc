﻿using EVO.Common.UtilityCore;
using EVO.TimesheetPortal.Site.App_Classes;
using EVO.TimesheetPortal.Site.Models;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Service
{
    public class AccountingService
    {
        private readonly IAccountingService Service;

        public AccountingService(IAccountingService service)
        {
            Service = service;
        }

        public async Task<List<AccountingModel>> GenearteAccountModel(IFormFile file)
        {
            List<AccountingModel> accountingList;

            using (var inputStream = new MemoryStream())
            {
                await file.CopyToAsync(inputStream);
                var data = ExcelWorksheetHelper.Read(inputStream);
                accountingList = DataTableUtil.ToEntityList<AccountingModel>(data);
            }

            return accountingList;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="DateRange"></param>
        /// <param name="dataKey"></param>
        /// <param name="accountingList"></param>
        /// <returns>0: no match; 1: all matched; 2: partial matched</returns>
        public async Task<int> CalculatePayrate(string DateRange, string entitiesID, string dataKey, List<AccountingModel> accountingList)
        {
            var sessionKey = string.Format(dataKey, $"{DateRange}:{entitiesID}");
            var timeSheetList = await GetTimesheetAccounting(DateRange, entitiesID);

            bool isMatch = false;

            int iItemCnt = timeSheetList.Count;
            int iCnt = 0;

            foreach (var item in timeSheetList)
            {
                var accountItem = accountingList.Where(o => o.PayLevel != null
                                                            && o.PayLevel.Equals(item.PayLevel)
                                                            && o.CountryCode != null
                                                            && o.CountryCode.Equals(item.Country)
                                                            && o.DepartmentCode != null
                                                            && o.DepartmentCode.TrimStart('0').Equals(item.Department?.TrimStart('0'))
                                                            ).FirstOrDefault();
                if (accountItem != null)
                {
                    item.Department = item.Department;
                    item.PayLevel = accountItem.PayLevel;
                    item.AverageRate = accountItem.AverageRate;
                    item.Salary = item.Hours * accountItem.AverageRate;
                    item.Taxes = item.Salary * accountItem.TaxRate;
                    item.Benefits = item.Salary * accountItem.BenefitRate;
                    item.FourZeroOneK = item.Salary * accountItem.FourZeroOneKRate;
                    item.Total = item.Salary + item.Taxes + item.Benefits + item.FourZeroOneK;
                    item.FinalCap = item.ProjectTypeCap && item.PhaseTypeCap ? "Yes" : "No";
                    isMatch = true;
                    iCnt++;
                }
            }
            if (isMatch)
            {
                ApplicationContext.Current.Session.SetJson(sessionKey, timeSheetList);
            }
            return iCnt == 0 ? 0 : (iCnt == iItemCnt ? 1 : 2);
        }

        public async Task<List<TimeSheetAccountingModel>> GetTimesheetAccounting(string periodCode, string entitiesID)
        {
            var timeSheetList = new List<TimeSheetAccountingModel>();
            var apiRes = await Service.SearchAsync(periodCode, entitiesID);
            var list = apiRes.Content?.ToList();
            list?.ForEach(f => timeSheetList.Add(TimeSheetAccountingModel.MappingFromEntity(f)));
            return timeSheetList;
        }
    }
}