﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Refit;
using EVO.TimesheetPortal.Entity;
using Microsoft.AspNetCore.Mvc;

namespace EVO.TimesheetPortal.Site.Service
{
    public interface ITeamService: IService
    {

        [Get("/api/team")]
        Task<ApiResponse<List<Team>>> SearchAsync([FromQuery] TeamCriteria teamCriteria);

        [Post("/api/team")]
        Task<ApiResponse<int>> InsertAsync([FromBody] Team team);

        [Put("/api/team")]
        Task<ApiResponse<int>> SaveAsync([FromBody] Team team);

        [Delete("/api/team")]
        Task<ApiResponse<bool>> DeleteAsync(int id);

        [Get("/api/team/get")]
        Task<ApiResponse<Team>> GetTeamAsync(int id);
    }
}
