﻿
var employeeSearchWin = {

    AddEmployee: function () {
        if (checkedEmployeeIds && checkedEmployeeIds.length == 0) {
            DisplayNotification("Please select an employee to add the employee in employee management page!", "info");
            return;
        }
        var grid = $("#EmployeeSearch").data('kendoGrid');
        var employeeGrid = $('#Employees').data('kendoGrid');
        var dataSource = employeeGrid.dataSource;
        var dataItems = grid.dataSource.data();
        //var sel = grid.select();
        // Get data item for each

        $.each(dataItems, function (idx, item) {
            //var item = grid.dataItem(row);
            var displayName = (item.FirstName || '') + " " + (item.LastName || '')
           // var manager = { ID: 0, EmployeeName: "" };
            if (!item.IsAdd && checkedEmployeeIds.indexOf(item.UserID) > -1) {

                var employeeItems = employeeGrid.dataItems();
                var isExist = false;
                $.each(employeeItems, function (index, o) {
                    if (o.UserID === item.UserName) {
                        isExist = true;
                        return;
                    }
                })
               
                if (!isExist) {
                    var mode = employeeGrid.options.editable.mode;
                    employeeGrid.options.editable.mode = 'inline';
                    try {

                        var editModel = dataSource._createNewModel({})
                        editModel.IsAdd = true;
                        editModel.UserID = item.UserName;
                        editModel.EmployeeName = displayName.trim().length > 0 ? displayName : item.UserName;
                        editModel.Email = item.Email;
                        editModel.EmailAlert = true;
                        editModel.IsActive = true;
                        editModel.RoleName = item.RoleName;

                        editModel = dataSource.insert(0, editModel);
                        var table = employeeGrid.lockedContent ? employeeGrid.lockedTable : employeeGrid.table;
                        var editRow = table.find('[' + kendo.attr('uid') + '=' + editModel.uid + ']');
                        employeeGrid._editModel(editModel);
                        //employeeGrid.editRow(editRow);

                    } finally {
                        employeeGrid.options.editable.mode = mode;
                    }

                }
            }
        });

        var window = $('#employeeList').data("kendoWindow");
        if (window) {
            checkedEmployeeIds = [];
            window.close();
        }
    }
}

