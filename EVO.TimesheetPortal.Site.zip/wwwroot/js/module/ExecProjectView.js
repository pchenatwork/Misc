﻿var ExecProjectView = (() => {
    var _generateModel = function (gridData) {
        var model = {};
        model.id = "xxxID"; //???
        var fields = {};
        for (var property in gridData) {
            var propType = typeof gridData[property];
            if (propType == "number") {
                fields[property] = {
                    type: "number",
                    validation: {
                        required: true
                    }
                };
            } else if (propType == "boolean") {
                fields[property] = {
                    type: "boolean",
                    validation: {
                        required: true
                    }
                }; 
            } else if (propType == "string") {
                var parsedDate = kendo.parseDate(gridData[property]);
                if (parsedDate) {
                    fields[property] = {
                        type: "date",
                        validation: {
                            required: true
                        }
                    };
                    dateFields.push(property);
                } else {
                    fields[property] = {
                        validation: {
                            required: true
                        }
                    };
                }
            } else {
                fields[property] = {
                    validation: {
                        required: true
                    }
                };
            }

        }
        model.fields = fields;
        return model;
    }
    var _onDataBound = function (e) {
        var grid = $(this.element).data("kendoGrid");
        _processTableHeader(grid);
        _processTableCells(grid);
    };
    var _processTableHeader = function (grid) {
        grid.thead.find("[data-field*='T_']").each(function (e) {
            var ele = $(this);
            var id = ele.data("field").split('_')[1];
            $.when($.get("/team/getteam/" + id)).then(function (data) {
                // compose header value from 'data'
                //var header = data.ShortName;
                //ele.text(header);
                var header = "<div style='display:inline'>" + data.DeptCode + "<br />" + "(" + data.Owner.DisplayName + ")";
                ele.html(header);
            })
        })
    };
    var _processTableCells = function (grid) {
        // transforming "{Hours}::{ProjectId}::{TeamId}" value
        var gridData = grid.dataSource.view();
        for (var i = 0; i < gridData.length; i++) {
            var uid = gridData[i].uid;
            var row = grid.table.find("tr[data-uid='" + uid + "']")[0];
            //debugger;
            for (var j = 0; j < row.cells.length; j++) {
                var cell = row.cells[j];
                if (cell.innerText.split('::').length == 3) {
                    var A = cell.innerText.split("::");
                    var hours = A[0], projectId = A[1], teamId = A[2];
                    var html;
                    html = kendo.format(
                        "<a style='color:blue' id='btnShowDetail_" + projectId + "_" + teamId + "' onClick = 'onShowDetail(this,\"" + projectId + "\",\"" + teamId + "\")' href = 'javascript:void(0)' >" + hours + " </a> "
                    );
                    cell.innerHTML = html;
                }
            }
        }
    };
    return {
        generateGrid: function (grdName, gridData) {
            var model = _generateModel(gridData[0]);
            var grid = $("#" + grdName).kendoGrid({
                dataSource: {
                    data: gridData,
                    model: model,
                },
                editable: false,
                sortable: true,
                dataBound: _onDataBound,
            });
        }
    }
})();
