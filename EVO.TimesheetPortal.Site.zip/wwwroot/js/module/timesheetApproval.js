﻿$(document).ready(function () {
    setInvalidDownloadButtonStatus();
    setDate(new Date());
    $("#btnDate").kendoDatePicker({
        start: "year",
        depth: "year",
        format: "yyyyMM",
        change: function () {
            setDate(this.value());
        }
    });
    $('#btnPreDate').click(function () {
        setDate(addMonth($('#taskDate').val(), -1));
    });
    $('#btnNextDate').click(function () {
        setDate(addMonth($('#taskDate').val(), 1));
    });
    $('#btnDate').click(function () {
        $("#btnDate").kendoDatePicker().open();
    });
    $('.ApproveButton').click(function () {
        kConfirm("Please Confirm", "Are you sure to approve all the datas?")
    });
    $('.k-grid-TrendReport').click(function () {
        var currentDate = kendo.toString(new Date($('#taskDate').val()), 'yyyyMM');
        $.when($.post("/timesheet/GetTimesheetTrend", { period: currentDate, employeeid: $("#ResourceID").val() })).then(function (data) {
            var employeeWindow = $("#timesheetTrend");
            employeeWindow.html('');
            employeeWindow.append(data);
            employeeWindow = employeeWindow.kendoWindow({
                modal: true,
                title: "Timesheet Trend Report",
                visible: false,
                width: "1000px",
                actions: ["Close"]
            }).data("kendoWindow");
            if (employeeWindow) {
                employeeWindow.center().open();

                setTimeout(function () {
                    var h = window.innerHeight;
                    var w = window.innerWidth;
                    var wheight = $("#timesheetTrend").parent()[0].scrollHeight / 2;
                    var wWidth = $("#timesheetTrend").parent()[0].scrollWidth / 2;
                    $("#timesheetTrend").closest(".k-window").css({
                        top: h / 2 - wheight,
                        left: w / 2 - wWidth
                    });
                }, 500)
            }
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    });
    $('.k-grid-SummaryReport').click(function () {
        var currentDate = kendo.toString(new Date($('#taskDate').val()), 'yyyyMM');
        $.when($.post("/timesheet/GetTimesheetSummary", { periodCode: currentDate })).then(function (data) {
            var employeeWindow = $("#timesheetSummary");
            employeeWindow.html('');
            employeeWindow.append(data);
            employeeWindow = employeeWindow.kendoWindow({
                modal: true,
                title: "Timesheet Summary Report",
                visible: false,
                width: "1000px",
                actions: ["Close"]
            }).data("kendoWindow");
            if (employeeWindow) {
                employeeWindow.center().open();

                setTimeout(function () {
                    var h = window.innerHeight;
                    var w = window.innerWidth;
                    var wheight = $("#timesheetSummary").parent()[0].scrollHeight / 2;
                    var wWidth = $("#timesheetSummary").parent()[0].scrollWidth / 2;
                    $("#timesheetSummary").closest(".k-window").css({
                        top: h / 2 - wheight,
                        left: w / 2 - wWidth
                    });
                }, 500)
            }
        });
    });
    $('.k-grid-excel').click(function () {
        var currentDate = kendo.toString(new Date($('#taskDate').val()), 'yyyyMM');
        kConfirm("Please Confirm", "Are you sure that you want to export?").then(function () {
            var form = $("<form></form>").attr("action", "/timesheet/Export?periodCode=" + currentDate).attr("method", "post");
            var token = $("[name='__RequestVerificationToken']").val();
            form.append($("<input></input>").attr("type", "hidden").attr("name", "__RequestVerificationToken").attr("value", token));
            form.appendTo('body').submit().remove();
        }, function () { });
    });
    $('#downloadTemplate').click(function () {
        kConfirm("Please Confirm", "Are you sure that you want to download?").then(function () {
            var form = $("<form></form>").attr("action", "/TimeSheet/Download").attr("method", "post");
            var token = $("[name='__RequestVerificationToken']").val();
            form.append($("<input></input>").attr("type", "hidden").attr("name", "__RequestVerificationToken").attr("value", token));
            form.appendTo('body').submit().remove();
        }, function () { });
    });
    $("#importTimesheetFiles").kendoUpload({
        "upload": OnAttachUpload,
        "success": OnAttachSuccess,
        "select": onSelect,
        "validation": {
            "allowedExtensions": [".xlsx"],
            "maxFileSize": 900000,
        },
        "error": OnError,
        "async": { "autoUpload": true, "saveUrl": "/TimeSheet/Upload" },
        "multiple": false,
        "showFileList": false
    });
    $('#invalidDownload').click(function () {
        kConfirm("Please Confirm", "Are you sure that you want to download?").then(function () {
            var form = $("<form></form>").attr("action", "/timesheet/DownloadInvalidList").attr("method", "post");
            var token = $("[name='__RequestVerificationToken']").val();
            form.append($("<input></input>").attr("type", "hidden").attr("name", "__RequestVerificationToken").attr("value", token));
            form.appendTo('body').submit().remove();
        }, function () { });
    })
});

function onResRequestEnd(e) {
    if (e.type === "read" && e.response) {
        if (e.response.length > 0) {
            loadManagerApproval(e.response[0].DataID);
        }
    }
}

function OnAttachUpload(arg) {
    var dateRangeValue = kendo.toString(new Date($('#taskDate').val()), 'yyyyMM');
    arg.data = { DateRange: dateRangeValue };
}

function OnAttachSuccess(arg) {
    $('.k-upload-status').hide();
    var result = arg.response;
    var message = (result || "").detail || "Import file error occurred, please try again!";
    if (arg.response.status == '207') {
        DisplayNotification(message, "error");
    } else {
        if (arg.response.Invalid) {
            $("#btnRow").width("1320px")
            $('#invalidDownload').show();
            DisplayNotification("Import failed, please download invalid list to check reason.", "warning");
        } else {
            $("#btnRow").width("1150px")
            $('#invalidDownload').hide();
            DisplayNotification("Import timesheet successfully.", "info");
        }
    }
    $("#uploadIcon").removeClass("k-i-loading");
    $("#uploadIcon").addClass("k-i-upload");
    $("#uploadLbl").text("Import");
    $("#importTimesheetFiles").data("kendoUpload").enable();
}

function onSelect(e) {
    $('.k-upload-status').remove();
    $("#uploadIcon").removeClass("k-i-upload");
    $("#uploadIcon").addClass("k-i-loading");
    $("#uploadLbl").text("Uploading...");
    $("#importTimesheetFiles").data("kendoUpload").disable();
};

function OnError(arg) {
    $('.k-upload-status').hide();
    $("#uploadIcon").removeClass("k-i-loading");
    $("#uploadIcon").addClass("k-i-upload");
    $("#importTimesheetFiles").data("kendoUpload").enable();
    $("#uploadLbl").text("Import");
    if (arg.XMLHttpRequest.status == '500') {
        DisplayNotification("Import file error occurred, please try again!", "error");
    }

    if (arg.XMLHttpRequest.status == "200") {
        location.href = "/TimeSheet/approval";
        DisplayNotification("Import file success!", "success");
    }
}

function setDate(date) {
    $("#currentDate").text(kendo.toString(date, 'MMMM, yyyy'));
    $('#taskDate').val(date);
    var datepicker = $("#datepicker").data("kendoDatePicker");
    if (datepicker) {
        datepicker.value(date);
    }
    if (!isFirstLoad) {
        loadManagerApproval();
    }
    isFirstLoad = false;
}

function loadManagerApproval(resID) {
    var currentDate = kendo.toString(new Date($('#taskDate').val()), 'yyyyMM');
    var employeeId = $("#ResourceID").val();
    if (employeeId === '' && typeof resID !== 'object') {
        employeeId = resID;
    }
    var data = {
        EmployeeId: employeeId,
        PeriodCode: currentDate
    }
    $.ajax({
        url: '/timesheet/ReloadManagerApproval',
        data: data,
        success: function (data) {
            $("#managerApproval").html(data);
            if ($('#hidTimeApprove').val() === 'True') {
                $('.timesheet-approve').show();
            } else {
                $('.timesheet-approve').hide();
            }
        }
    })
}

function approveTimesheet(employeeId, periodCode) {
    kConfirm("Please Confirm", "Are you sure that you want to approve?").then(function () {
        var data = {};
        data.EmployeeId = employeeId;
        data.PeriodCode = periodCode;
        $.when($.ajax({
            url: '/timesheet/ManagerApproval',
            type: "POST",
            data: data
        })).then(function (data) {
            console.log(data);
            if (data.Success) {
                DisplayNotification("Record approved successfully!", "success");
            } else {
                DisplayNotification("This operation failed.", "error");
            }
            loadManagerApproval();
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    }, function (e) {
        DisplayNotification("Connot connect to the Server", "warning");
    });
}

function setInvalidDownloadButtonStatus() {
    if (invalidData == 'True') {
        $("#btnRow").width("1320px")
        $('#invalidDownload').show();
    } else {
        $("#btnRow").width("1150px")
        $('#invalidDownload').hide();
    }
}
 

function onDataBound(e) {
 
}


function onReloadGridDataSource() {
    var grid = $("#Timesheet").data("kendoGrid");
    this.checkedIds = [];
    grid.dataSource.read();
}

function onDataFilter() {
    
}

function AllowedEditComment(dataItem) {
    return dataItem.StatusDesc === defaultStatus || (isTimesheetAdmin === 'True' && !['Approved', 'Rejected'].includes(dataItem.StatusDesc));
}

function redirectToApproval(resourceId, statusId) {
    //if (statusId == 0) {
        
    //}
    $("#timesheetSummary").data("kendoWindow").close();
    $("#ResourceID").data("kendoComboBox").value(resourceId);
    loadManagerApproval();
}