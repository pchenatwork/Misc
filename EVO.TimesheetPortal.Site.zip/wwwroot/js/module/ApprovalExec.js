﻿var ApprovalExec = (() => {
    return {
        onEntityFilterChange: function () {
            alert("onEntityFilterChange fired");
        }
    }
})();

function onEntityFilterChange() {
    loadDetails();
}

function GetView_ExecProjectView(grdId, entityId, periodCode) {
    $.ajax({
        url: '/timesheet/GetViewExecProjectView',
        data: {
            EntityId: entityId,
            PeriodCode: periodCode
        },
        success: function (data) {
            $('#' + grdId).html(data);
        }
    })
}
function loadDetails() {
    var periodCode = kendo.toString(new Date($('#taskDate').val()), 'yyyyMM');
    var entityId = $("#AccountingEntity").data('kendoComboBox').dataItem().ID;

    // Step 1: Refresh ProjectView
    GetView_ExecProjectView('divProjectView', entityId, periodCode);

    // Refresh ResourceView

    // Refresh ExecApprovalView data to set Approval Button
}

function setDate(date) {
    $("#currentDate").text(kendo.toString(date, 'MMMM, yyyy'));
    $('#taskDate').val(date);
    var datepicker = $("#datepicker").data("kendoDatePicker");
    if (datepicker) {
        datepicker.value(date);
        loadDetails();
    }
}

$(() => {
    $("#btnDate").kendoDatePicker({
        start: "year",
        depth: "year",
        format: "yyyyMM",
        change: function () {
            setDate(this.value());
        }
    });
    // Set default date
    var yyyyMM = $("#divData").data("periodcode");
    var date = new Date(yyyyMM.toString().substring(0, 4), yyyyMM.toString().substring(4, 6) - 1);
    setDate(date);

    /// set default AccountingEntity selection here
    var cbx = $("#AccountingEntity").data("kendoComboBox");
    cbx.select(function (dataItem) {
        return dataItem.id === $("#divData").data("entityid")
    });

    $("#tabstrip").kendoTabStrip({
        animation: {
            open: {
                effects: "fadeIn"
            }
        },
        activate: function (e) {

            $('.k-state-active').css('height', '100%');
            var id = e.item.id;
            var type = id == 'tabProject' ? 'project' : 'resource';
            //debugger;
            if (type == 'resource') {
                //var grid = $('#ResourceViewGrid').data('kendoGrid');
                //if (grid) {
                //    grid.dataSource.read();
                //}

            } else {
                var grid = $('#projectViewGrid').data('kendoGrid');
                if (grid) {
                    grid.refresh();
                    grid._resize();
                }
            }

            ////var currentDate =  new Date($('#taskDate').val()) ;
            ////currentDate = kendo.toString(currentDate, 'yyyyMM')
            ////var currentPeriodCode = $('#currentPeriodCode').val();
            ////var disabled = currentDate != currentPeriodCode
            //ProjectViewGrid.setApproveButtonStatus();
            //$('#btnApprove').off('click');
            //$('#btnApprove').on('click', function () {
            //    ProjectViewGrid.approveExecutive(type)
            //})
        }
    });

    $('#btnPreDate').click(function () {
        setDate(addMonth($('#taskDate').val(), -1));
    });
    $('#btnNextDate').click(function () {
        setDate(addMonth($('#taskDate').val(), 1));
    });
    $('#btnDate').click(function () {
        $("#btnDate").kendoDatePicker().open();
    });
    $('#btnApprove').on('click', function () {
        //ProjectViewGrid.approveExecutive('project');
        alert("btnApprove clicked");
    })
    $('#btnApproveUndo').on('click', function () {
        //ProjectViewGrid.approveExecutive('project');
        alert("btnApproveUndo clicked");
    })
})