﻿function onProjectChange() {
    var projectID = $("#ProjectId").data("kendoDropDownList").value();
    if (projectID) {
        $("#ActivityId").kendoDropDownList({
            dataSource: {
                transport: {
                    read: "/Project/GetActivity?projectId=" + projectID
                }
            },
            dataTextField: "DataText",
            dataValueField: "DataID",
            optionLabel: "--Select--",
            dataBound: function (e) {
                if (e.sender.dataSource.data().length === 1) {
                    this.select(1);
                } else {
                    this.select(0);
                }
            }
        });
    } else {
        var dataSource = new kendo.data.DataSource({
            data: []
        });
        var dropdownlist = $("#ActivityId").data("kendoDropDownList");
        dropdownlist.setDataSource(dataSource);
    }
}

function onProjectFilter() {
    return { resourceID: $('#ResourceID').val() };
}

function setDate(date) {
    var isDirty = dirtyCheck();
    if (isDirty) {
        kConfirm("Please Confirm", "Timesheet records have not been saved yet. Are you sure you want to navigate away from this page?").
            then(function () {
            ReloadGridByNewDate(date);
        }, function () {
        });
    } else {
        ReloadGridByNewDate(date)
    }
}

function ReloadGridByNewDate(date) {
    $("#currentDate").text(kendo.toString(date, 'D'));
    $('#taskDate').val(date);
    var datepicker = $("#datepicker").data("kendoDatePicker");
    if (datepicker) {
        datepicker.value(date);
    }
    onReloadGridDataSource();
}

function onReloadGridDataSource() {
    var grid = $("#tasks").data("kendoGrid");
    grid.dataSource.read();
}

$(document).ready(function () {
    $('.k-nav-today').hide();
    setDate(new Date());
    $("#btnDate").kendoDatePicker({
        change: function () {
            setDate(this.value());
        }
    });
    $('#btnPreDate').click(function () {
        setDate(addDays($('#taskDate').val(), -1));
    });
    $('#btnNextDate').click(function () {
        setDate(addDays($('#taskDate').val(), 1));
    });
    $('#btnDate').click(function () {
        $("#btnDate").kendoDatePicker().open();
    });
    $("#tabstrip").kendoTabStrip({
        animation: {
            open: {
                effects: "fadeIn"
            }
        },
        activate: function (e) {
            var title = $(e.item).find("> .k-link").text();
            if (title.indexOf("Day") >= 0) {
                onReloadGridDataSource();
            } else {
                $("#scheduler").data("kendoScheduler").dataSource.read();
            }
        },
        select: function (e) {
            var isDirty = dirtyCheck();
            var title = $(e.item).find("> .k-link").text();
            var tabIndex = "#tabMonth";
            if (title.indexOf("Day") >= 0) {
                tabIndex = "#tabDay";
            }
            var tabStrip = $("#tabstrip").kendoTabStrip().data("kendoTabStrip");
            if (isDirty) {
                var tab = tabStrip.select();
                var otherTab = tab.next();
                tabStrip.enable(otherTab, false);
                e.preventDefault();
                kConfirm("Please Confirm", "You have input the data without submit/delete the record, your changes will be lost.  Are you sure you want to continue?").then(function () {
                    var tab = tabStrip.select();
                    var otherTab = tab.next();
                    tabStrip.enable(otherTab, true);
                    tabStrip.activateTab($(tabIndex))
                    var grid = $("#tasks").data("kendoGrid");
                    grid.dataSource.read();
                }, function () {
                    var tab = tabStrip.select();
                    var otherTab = tab.next();
                    tabStrip.enable(otherTab, true);
                    return;
                });
            }
        }
    });

    $('.task-plus').click(function () {
        $.when($.post("/TimeSheet/CreateTask")).then(function (data) {
            var openWindow = $("#createTask");
            openWindow.html('');
            openWindow.append(data);
            openWindow = openWindow.kendoWindow({
                modal: true,
                title: "+ Task",
                visible: false,
                width: "600px",
                actions: ["Close"],
                resizable: false
            }).data("kendoWindow");
            if (openWindow) {
                openWindow.center().open();
                openWindow.bind("close", taskFormEditor.onWindowClose)
            }
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    });

    $("#tasks").kendoTooltip({
        filter: ".tooltips",
        width: '300px',
        content: function (e) {
            var dataItem = $(".k-grid").data("kendoGrid").dataItem(e.target.closest("tr"));
            if (formatLongStr(dataItem.Description, 30) === e.target.html()) {
                return dataItem.Description;
            }
            return '';
        }
    });  
});

var taskFormEditor = {
    onFormValidateField: function (e) {
        $("#validation-success").html("");
    },
    onFormSubmit: function (e) {
        taskFormEditor.submitData(false);
        e.preventDefault();
    },
    onFormCreateAndSubmit: function () {
        var validator = $("#CreateTaskForm").kendoValidator().data("kendoValidator");
        if (validator.validate()) {
            taskFormEditor.submitData(true);
        }
    },
    onFormClear: function (e) {
        $("#validation-success").html("");
    },
    submitData: function (isSubmit) {
        var data = {};
        data.ProjectId = $("#ProjectId").val();
        data.EmployeeId = $('#ResourceID').val();
        data.ActivityId = $("#ActivityId").val();
        data.ActivityDate = new Date($("#currentDate").text()).toDateString();
        $.when($.ajax({
            url: "/TimeSheet/CreateTaskForm",
            type: "POST",
            data: data
        })).then(function (data) {
            if (data.Success) {
                var grid = $('#tasks').data('kendoGrid');
                dataSource = grid.dataSource;
                dataSource.pushCreate(data.AssociatedObject);
                DisplayNotification("Create task successfully!", "success");
            } else {
                if (data.ErrorDescription) {
                    DisplayNotification(data.ErrorDescription, "warning");
                } else {
                    DisplayNotification("This operation failed.", "error");
                }
            }
            var openWindow = $("#createTask").data("kendoWindow");
            openWindow.close();
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    },
    onWindowClose: function () {
    },
    onAddHours: function (e) {
        var grid = $(".k-grid").data("kendoGrid");
        list = grid.dataSource.data();
        var dirty = $.grep(list, function (item) {
            return item.dirty
        });
        var isInValid = $(".k-grid").data("kendoGrid").editable && !$(".k-grid").data("kendoGrid").editable.end();
        if (isInValid || dirty.length === 0) {
            return;
        }  
        var timeData = $(".k-grid").data("kendoGrid").dataItem($(e).closest('tr'));
        var taskID = timeData.ID;
        var projectID = timeData.ProjectId;
        var phaseID = timeData.ActivityId;
        var desc = timeData.Description;
        var hours = timeData.Hours;
        var isTimeSheet = timeData.IsTimeSheet;
        var data = {};
        data.Id = taskID;
        data.ProjectId = projectID;
        data.ActivityId = phaseID;
        data.Hours = hours;
        data.Description = desc;
        data.IsTimeSheet = isTimeSheet;
        data.ActivityDate = $("#currentDate").text();
        data.EmployeeId = $('#ResourceID').val();
        $.when($.ajax({
            url: "/TimeSheet/UpdateTask",
            type: "POST",
            data: data
        })).then(function (data) {
            if (data.Success) {
                var grid = $('#tasks').data('kendoGrid');
                dataSource = grid.dataSource;
                var updateObj = data.AssociatedObject;
                if (updateObj.ID != timeData.ID) {
                    dataSource.pushDestroy(timeData);
                    dataSource.pushCreate(data.AssociatedObject);
                } else {
                    dataSource.pushUpdate(updateObj);
                }
               
                DisplayNotification("Update task successfully!", "success");
            } else {
                DisplayNotification("This operation failed.", "error");
            }
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    },
    onRemoveHours: function (e) {
        kConfirm("Please Confirm", "Are you sure that you want to delete?").then(function () {
            var timeData = $(".k-grid").data("kendoGrid").dataItem($(e).closest('tr'));
            var data = {};
            data.Id = timeData.ID;
            data.IsTimeSheet = timeData.IsTimeSheet;
            $.when($.ajax({
                url: "/TimeSheet/RemoveTask",
                type: "POST",
                data: data
            })).then(function (data) {
                if (data.Success) {
                    var grid = $('#tasks').data('kendoGrid');
                    dataSource = grid.dataSource;
                    dataSource.pushDestroy(timeData);
                    DisplayNotification("Remove task successfully!", "success");
                } else {
                    DisplayNotification("This operation failed.", "error");
                }
            });
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    },
    onSelectDate: function (e) {
        switch (e.indices) {
            case 0:
                break;
            case 1:
                var datepicker = $("#datepicker").data("kendoDatePicker");
                datepicker.open();
                break;
            case 2:
                break;
        }
    }
};

function activity_editable(data) {
    return !data.IsReadonly || data.SourceId === 2;
}

function onDataBound(data) {
    var grid = $(".k-grid").data("kendoGrid");
    var allRows = grid.items();
    var dataItem;
    $.each(allRows, function (index, value) {
        dataItem = grid.dataSource.data().find(u => u.ID == grid.dataItem(value).ID)
        if (dataItem && !activity_editable(dataItem)) {
            $(value).find(".k-actions").hide();
        } 
    });
}

function onDailyDataFilter() {
    if (!!$('#ResourceID') && $('#ResourceID').val() === '') {
        $('.task-plus').hide();
    } else {
        $('.task-plus').show();
    }
    var activityDate = $("#currentDate").text();
    if (!activityDate) {
        activityDate = kendo.toString(new Date(), 'D')
    }
    var obj = {
        activityDate: activityDate,
        resourceID: $('#ResourceID').val()
    }
    return compoundObjectWithForgeryToken(obj);
}

function onMonthlyDataFilter() {
    var scheduler = $("#scheduler").data("kendoScheduler");
    var start = scheduler.view().startDate();
    var end = scheduler.view().endDate();

    var obj = {
        StartDate: start,
        EndDate: end,
        EmployeeId: $('#ResourceID').val()
    }
    return compoundObjectWithForgeryToken(obj);
}

function scheduler_edit(e) {
    var tabStrip = $("#tabstrip").kendoTabStrip().data("kendoTabStrip");
    tabStrip.activateTab($('#tabDay'))
    setDate(e.event.start);
    e.preventDefault();
}

function scheduler_add(e) {
    var tabStrip = $("#tabstrip").kendoTabStrip().data("kendoTabStrip");
    tabStrip.activateTab($('#tabDay'))
    setDate(e.event.start);
    e.preventDefault();
}

function scheduler_navigate(e) {
    setDate(e.date);
    setTimeout(function () {
        e.sender.dataSource.read();
    }, 10);
}