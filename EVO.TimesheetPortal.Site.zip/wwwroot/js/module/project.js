﻿$(document).ready(function () {
    $('.k-grid-Add').click(function () {
        $.when($.post("/project/CreateProject")).then(function (data) {
            var timesheetWindow = $("#createProject");
            timesheetWindow.html('');
            timesheetWindow.append(data);
            timesheetWindow = timesheetWindow.kendoWindow({
                modal: true,
                title: "+ Project",
                visible: false,
                width: "700px",
                actions: ["Close"],
                resizable: false
            }).data("kendoWindow");
            if (timesheetWindow) {
                timesheetWindow.center().open();
                timesheetWindow.bind("close", projectFormEditor.onWindowClose)
                projectFormEditor.fixKendoDropdownPopup();
            }
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    });

    $("#project").kendoTooltip({
        filter: ".tooltips",
        width: '300px',
        show: function (e) {
            if (this.content.text().length > 0) {
                this.content.parent().css("visibility", "visible");
            }
        },
        hide: function (e) {
            this.content.parent().css("visibility", "hidden");
        },
        content: function (e) {
            var dataItem = $(".k-grid").data("kendoGrid").dataItem(e.target.closest("tr"));
            if ('team' === e.target[0].id){
                return dataItem.Team;
            } else if ('description' === e.target[0].id){
                return htmlEncode(dataItem.Description);
            } else if ('phase' === e.target[0].id){
                return dataItem.Phase;
            } else if ('name' === e.target[0].id){
                return htmlEncode(dataItem.Name);
            } else if ('type' === e.target[0].id){
                return dataItem.Type;
            }
            return '';
        }
    });

    $("#projectApprove").kendoTooltip({
        filter: ".tooltips",
        width: '300px',
        show: function (e) {
            if (this.content.text().length > 0) {
                this.content.parent().css("visibility", "visible");
            }
        },
        hide: function (e) {
            this.content.parent().css("visibility", "hidden");
        },
        content: function (e) {
            var dataItem = $(".k-grid").data("kendoGrid").dataItem(e.target.closest("tr"));
           
            if ('DESC' == e.target[0].id){
                return htmlEncode(dataItem.Description);
            }  else if ('name' === e.target[0].id) {
                return htmlEncode(dataItem.Name);
            } else if ('type' === e.target[0].id) {
                return dataItem.Type;
            }
            return '';
        }
    });
});

var project = {
    onDataBound: function (e) {
        var grid = $(".k-grid").data("kendoGrid");
        var data = grid.dataSource.data();
        $.each(data, function (i, row) {
            if (row.Status == 'Pending Approval') {
                $('tr[data-uid="' + row.uid + '"] ').css("color", "gray");
            } else if (row.Status === 'Rejected') {
                $('tr[data-uid="' + row.uid + '"] ').css("color", "#b34d4d");
            } else if (row.Status === 'Approved') {
                $('tr[data-uid="' + row.uid + '"] ').css("color", "#007bff");
            }

            var des = $('tr[data-uid="' + row.uid + '"]').find("[id*='_action_for_']");
            if (des.length == 1 && row.Is1OK) {
                ActionMenuMaker.MakeMenu(des[0]);
            }
        });
    },
    onShowMore: function (e) {
        var grid = $(".k-grid").data("kendoGrid");
        var data = grid.columns;
        if ($(e).text() === 'More') {
            $(e).text('Less')
            $.each(data, function (i, row) {
                if (row.hidden && i > 1) {
                    grid.showColumn(i);
                }
            });
        } else {
            $(e).text('More')
            var hideCols = ['Type', 'Description', 'EstimatedHours', 'StartDate', 'EndDate', 'ProdDate', 'Country', 'RequestedBy'];
            $.each(data, function (i, row) {
                if (hideCols.indexOf(row.field) > 0) {
                    grid.hideColumn(i);
                }
            });
        }
    },
    onMenuAction: function (n,e) {
        $.ajax(
            {
                url: "/project/" + e.split(':')[0],
                type: 'post',
                dataType: "json",
                data: JSON.stringify(e.split(':')[1]),
                contentType: 'application/json; charset=utf-8',
                async: false,
                success: function (result) {
                    DisplayNotification(n + " successfully!", "success");
                    var grid = $('#project').data('kendoGrid');
                    grid.dataSource.read();
                },
                error: function (e) {
                    DisplayNotification("Server side error ocurred", "warning");
                    return true;
                }
            });
    }
};

var projectFormEditor = {
    onFormValidateField: function (e) {
        $("#validation-success").html("");
    },
    onFormSubmit: function (e) {
        projectFormEditor.submitData(e);
        e.preventDefault();
    },
    onFormCreateAndSubmit: function () {
        var validator = $("#CreateProjectForm").kendoValidator().data("kendoValidator");
        if (validator.validate()) {
            projectFormEditor.submitData(e);
        }
    },
    onFormClear: function (e) {
        $("#validation-success").html("");
    },
    submitData: function (e) {
        var data = {};
        var teams = $("#Teams").data("kendoMultiSelect");
        var phase = $("#Phases").data("kendoMultiSelect");
        var request = $("#RequestedBy").data("kendoComboBox");
        data.ID = $("#ID").val();
        data.Name = $("#Name").val();
        data.TypeID = $("#TypeID").val();
        data.Description = $("#Description").val();
        data.PhaseList = phase.value();
        data.Country = $("#Country").val();
        data.EstimatedHours = $("#EstimatedHours").val();
        data.TeamList = teams.value();
        data.RequestedBy = request.text();
        data.PIRNo = $("#PIRNo").val();
        data.AccountingEntityId = $("#AccountingEntityId").val();

        if ($("#StartDate").val()) {
            data.StartDate = $("#StartDate").val();
        }
        if ($("#EndDate").val()) {
            data.EndDate = $("#EndDate").val();
        }
        if ($("#ProdDate").val()) {
            data.ProdDate = $("#ProdDate").val();
        }
        $.when($.ajax({
            url: "/project/CreateProjectForm",
            type: "POST",
            data: data
        })).then(function (data) {
            var grid = $('#project').data('kendoGrid');
            var message = e.model.ID > 0 ? "Updated" : "Created";
            DisplayNotification(message + " successfully!", "success");
            grid.dataSource.read();
            var createProjectWindow = $('#createProject').data("kendoWindow");
            var editProjectWindow = $('#editProject').data("kendoWindow");
            if (createProjectWindow) {
                createProjectWindow.close();
            }
            if (editProjectWindow) {
                editProjectWindow.close();
            }
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    },
    onWindowClose: function () {
        var grid = $('#project').data('kendoGrid');
        grid.dataSource.read();
    },
    /*workaround for the BUG 237640:
     for the dropdown editor if different form(f.g. Create and Edit in this case) has same fields, open the these forms, 
     then click on the label on the form last opened, the dropdown content window popups on the left top corner.*/
    fixKendoDropdownPopup: function () {
        $('label[for="Country"]').attr('for', '');
        $('label[for="TypeID"]').attr('for', '');
    }
};

var projectApprove = {
    approveProject: function (e) {
        var id = $(e).closest('tr').find('td').eq(0).text();
        $.ajax(
            {
                url: "/project/approve",
                type: 'post',
                dataType: "json",
                data: JSON.stringify(id),
                contentType: 'application/json; charset=utf-8',
                async: false,
                success: function (result) {
                    DisplayNotification("Approved successfully!", "success");
                    var grid = $('#projectApprove').data('kendoGrid');
                    grid.dataSource.read();
                },
                error: function (e) {
                    DisplayNotification("Server side error ocurred", "warning");
                    return true;
                }
            });
    },
    onDataFilter: function () {
        var obj = {
            Status: $("#projectStatus").val()
        }
        return compoundObjectWithForgeryToken(obj);
    },
    rejectProject: function (e) {
        var id = $(e).closest('tr').find('td').eq(0).text();
        $('#projectID').val(id);
        var editorWindow = $("#RejectWindow");
        editorWindow.kendoWindow({
            width: "400px",
            height: "230px",
            modal: true,
            actions: [
                "Close"
            ],
            close: function () {
            }
        }).data("kendoWindow")
            .title('Reject')
            .center();
        var wnd = $("#RejectWindow").data("kendoWindow");
        wnd.open();
    },
    closeComment: function (e) {
        if (e === 1) {
            var data = {};
            data.Id = $('#projectID').val();
            data.Comment = $('#Comment').val();
            if (data.Comment.length > 300) {
                $('#Comment').addClass('k-invalid')
                $('#Comment-msg').show();
                return;
            } else {
                $('#Comment-msg').hide();
                $('#Comment').removeClass('k-invalid')
                $.ajax(
                    {
                        url: "/project/reject",
                        type: 'post',
                        dataType: "json",
                        data: JSON.stringify({ 'ID': $('#projectID').val(), 'Comment': $('#Comment').val() }),
                        contentType: 'application/json; charset=utf-8',
                        async: false,
                        success: function (result) {
                            DisplayNotification("Rejected successfully!", "success");
                            var grid = $('#projectApprove').data('kendoGrid');
                            grid.dataSource.read();
                        },
                        error: function (e) {
                            DisplayNotification("Server side error ocurred", "warning");
                            return true;
                        }
                    });
            }
        }
        var wnd = $("#RejectWindow").data("kendoWindow");
        $('#Comment').val('');
        wnd.close();
    },
    onSelect: function (e, btn) {
        var grid = $(".k-grid").data("kendoGrid");
        if (btn !== '') {
            $('.k-button').removeClass('k-primary');
            $(btn).addClass('k-primary');
        }
        if (e == 1) {
            $("#projectStatus").val(2);
            grid.hideColumn(10);
            grid.hideColumn(11);
            grid.dataSource.read();
        } else if (e == 0) {
            $("#projectStatus").val(1);
            grid.showColumn(10);
            grid.showColumn(11);
            grid.dataSource.read();
        } else {
            grid.options.excel.fileName = projectApprove.getExcelName();
            grid.saveAsExcel();
        }
    },
    excelExport: function (e) {
        e.workbook.sheets[0].name = projectApprove.getExcelName();
    },
    showApproveBtn: function (dataItem) {
        return dataItem.Status === 'Pending' && dataItem.Is2OK;
    },
    showRejectBtn: function (dataItem) {
        return dataItem.Status === 'Pending' && dataItem.Is3OK;
    },
    getExcelName: function () {
        if ($("#projectStatus").val() === '1') {
            return 'Project Pending Listing';
        } else {
            return 'Project Listing';
        }
    },
    onCommnetBlur: function () {
        if ($('#Comment').val().length > 300) {
            $('#Comment-msg').show();
            $('#Comment').addClass('k-invalid')
        } else {
            $('#Comment-msg').hide();
            $('#Comment').removeClass('k-invalid')
        }
    }
};

(function ($, kendo) {
    $.extend(true, kendo.ui.validator, {
        validateOnBlur: true,
        rules: { // custom rules
            projectnamevalidation: function (input, params) {
                if (input.is("[name='Name']") && input.val() !== "") {
                    input.attr("data-Name-msg", "Project Name Exists");
                    $.ajax(
                        {
                            url: "/Project/CheckProjectName?name=" + input.val() + "&id=" + $("input[name='ID']").val() ,
                            type: 'get',
                            dataType: "json",
                            contentType: 'application/json; charset=utf-8',
                            async: false,
                            success: function (result) {
                                retValue = !result;
                            },
                            error: function (e) {
                                return true;
                            }
                        });
                    return retValue;
                } else {
                    return true;
                }
            }
        },
        messages: {
            projectnamevalidation: function (input) {
                return input.attr("data-Name-msg");
            }
        }
    });
})(jQuery, kendo);

var ActionMenuMaker = (function () {
    /* Use bootstrap dropdown menu to construct the ActionOption Menu */
    var _popup = function (name, value, extra) {
        // Logic for preparing element that will link a "Popup" goes here
        var item = $('<button class="btn btn-default btn-sm dropdown-item" type="button">' + name + '</button>');
        item.on('click', function () {
            if (value.split(':')[0] === 'edit') {
                $.when($.post("/project/UpdateProject?Id=" + value.split(':')[1]))
                    .then(function (data) {
                    var timesheetEditWindow = $("#editProject");
                    timesheetEditWindow.html('');
                    timesheetEditWindow.append(data);
                    timesheetEditWindow = timesheetEditWindow.kendoWindow({
                        modal: true,
                        title: "Edit Project",
                        visible: false,
                        width: "700px",
                        actions: ["Close"],
                        resizable: false
                    }).data("kendoWindow");
                    if (timesheetEditWindow) {
                        timesheetEditWindow.center().open();
                        timesheetEditWindow.bind("close", projectFormEditor.onWindowClose)
                        projectFormEditor.fixKendoDropdownPopup();
                    }
                    }, function (e) {
                        DisplayNotification("Connot connect to the Server", "warning");
                    });
            }
        });
        return item;
    };
    var _redirect = function (name, value, extra) {
        // Logic for preparing element that will "Redirect" to a new page goes here
        var item = $('<a class="dropdown-item" href="#">' + name + '</a>');
        item.on('click', function () {
            alert('redirect to : ' + value);
        });
        return item;
    };
    var _formpost = function (name, value, extra) {
        // Logic for preparing element that will result a "Form Post" goes here
        var item = $('<a class="dropdown-item" href="#">' + name + '</a>');
        item.on('click', function () {
            project.onMenuAction(name, value);
        });
        return item;
    };
    return {
        MakeMenu: function (ele) {
            var arr = JSON.parse($(ele).attr("data-options"));
            if (arr.length > 0) {
                var id = "ActionOption" + ele.id.substring(ele.id.lastIndexOf("_"), ele.length);
                var div = $('<div class="dropdown" />');
                div.hover(function () {
                    $('.k-i-gear', this).trigger('click');
                });
                // var btn = $('<button class="btn btn-info btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="' + id + '">Action</button>');
                var btn = $('<span class="k-icon k-i-gear dropdown-toggle.caret-off" ' +
                    'data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id = "' + id + '" /> ');
                div.append(btn);

                var menuitem = $('<div class="dropdown-menu" aria-labelledby="' + id + '" />');
                menuitem.append($('<h4 class="dropdown-header">Action</h4>'));
                menuitem.append($('<div class="dropdown-divider" />'));
                arr.forEach(function (o) {
                    switch (o.T) {
                        case 1: // popup
                            menuitem.append(_popup(o.N, o.V, o.E));
                            break;
                        case 2: // redirect
                            menuitem.append(_redirect(o.N, o.V, o.E));
                            break;
                        case 3:  // form post
                            menuitem.append(_formpost(o.N, o.V, o.E));
                            break;
                        default:
                            break
                    }
                })
                div.append(menuitem);

                $(ele).append(div);
            }
        }
    }
})();