(function ($, kendo) {
    var confirmDelete = function (row, grid) {
        var kendoWindow = $("<div />").kendoWindow({
            title: "Delete Confirmation?",
            resizable: false,
            modal: true,
            width: '400px',
            draggable: true,
            actions: ['Close']
        });
        kendoWindow.data('kendoWindow')
            .content($('<p>' + grid.options.messages.editable.confirmation + '</p><div class="text-right"><button class="confirm-ok k-button k-primary">'
                + grid.options.messages.editable.confirmDelete + '</button>&nbsp;<a href="javascript:void(0);" class="confirm-cancel k-button">' + grid.options.messages.editable.cancelDelete + '</a></div>'))
            .center().open();
        kendoWindow
            .find(".confirm-ok, .confirm-cancel")
            .click(function () {
                kendoWindow.data("kendoWindow").close();
                kendoWindow.data("kendoWindow").destroy();
                if ($(this).hasClass('confirm-ok')) {
                    grid._removeRow(row);
                }
            });
    };

    var Grid = kendo.ui.Grid.extend({
        removeRow: function (row) {
            var that = this;
            confirmDelete(row, that);
        },
    });

    kendo.ui.plugin(Grid);
}(window.kendo.jQuery, window.kendo));

var isDeleted = false;
function DisplayNotification(displayMsg, displayType) {
    var element = $("#NotificationWindow").data("kendoNotification");
    element.show({ myMessage: displayMsg }, displayType);
}
function kConfirm(title, content) {
    return $("<div></div>").kendoConfirm({
        title: title,
        content: content,
        messages: { okText: "OK", cancel: "Cancel" }
    }).data("kendoConfirm").open().result;
}

function onShow(e) {
    if (e.sender.getNotifications().length === 1) {
        var element = e.element.parent(),
            eWidth = element.width(),
            eHeight = element.height(),
            wWidth = $(window).width(),
            wHeight = $(window).height(),
            newTop, newLeft;
        var doc = document.documentElement;
        newLeft = Math.floor(wWidth / 2 - eWidth / 2);
        var eleWidth = e.element.width();
        e.element.width(eleWidth + 20);
        //For Centered Location
        //newTop = Math.floor(wHeight / 2 - eHeight / 2);
        newTop = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
        e.element.parent().css({ top: newTop, left: newLeft });
    }
}

function formatLongStr(str, len, ellipsis) {
    if (!ellipsis) {
        ellipsis = '...';
    }

    if (str && str.length > len) {
        return str.substring(0, len - 1) + ellipsis;
    } else {
        return str;
    }
}

function formatAmount(Amount) {
    if (Amount < 0) {
        return "(" + kendo.toString(Math.abs(Amount), "n2") + ")"
    } else {
        return kendo.toString(Amount, "n2")
    }
}

function NumericFilter(control) {
    $(control).kendoNumericTextBox({ "format": "#", "decimals": 0 });
}

function formatCount(TransactionCount) {
    return kendo.toString((TransactionCount), "###,###.##")
}

function formatDate(date) {
    return kendo.toString(kendo.parseDate(date), 'yyyy-MM-dd');
}

function formatUtcDate(utcDate) {
    if (utcDate === null || utcDate === undefined || utcDate === '' || utcDate.toDateString().includes('0001')) {
        return '';
    }
    return kendo.toString(moment.utc(utcDate).toDate(), "d", kendo.culture().name)
}
function formatNumber(number) {
    return kendo.toString((number), "0.00")
}



$(document).ajaxError(function (event, request, settings) {
    if (request.status == 401 || request.status == 400) {
        window.location.href = '/login/userlogin';
    }
});

function error_handler(e) {
    var message = "Errors:\n";
    if (e.status === 'error') {
        if (e.xhr.status === 401 || e.xhr.status == 400) {
            location.href = '/login/userlogin'
        } else if (e.xhr.status == 500) {
            DisplayNotification("Server side error occurred.", "error");
        } else {
            DisplayNotification("The operation failed, please try again.", "error");
        }
    }

    if (e.errors) {
        $.each(e.errors, function (key, value) {
            if ('errors' in value) {
                $.each(value.errors, function () {
                    message += this + "\n";
                });
            }
        });
        DisplayNotification(message, "error");
    }
}

//render handler for multi select control
function renderMultiSelectText(selectedList) {
    if (selectedList !== undefined) {
        var displayText = '';
        $.each(selectedList, function (index) {
            if (displayText === undefined) {
                displayText = selectedList[index].DataText + ', ';
            } else {
                displayText = displayText + selectedList[index].DataText + ', ';
            }
        });
        return displayText.slice(0, -2);
    } else {
        return '';
    }
}

function renderTextWithTitle(text) {
    if (text) {
        return `<div title ="${text}">${text}</div>`
    }
    return text;
}

function NotAllowedEdit() {
    return false;
}

function isNewAllowEditable(dataItem) {
    return dataItem.isNew();
}

function onExcelExportOfProject(e) {
    var workbook = e.workbook.sheets[0];
    var multipleSelectList = ['Teams', 'System Name', 'Phases', 'Project Phase', 'Project Name'];
    var multipleSelectIndex = [];
    if (workbook.rows[0]) {
        for (var cellIndex = 0; cellIndex < workbook.rows[0].cells.length; cellIndex++) {
            if (multipleSelectList.indexOf(workbook.rows[0].cells[cellIndex].value) >= 0) {
                multipleSelectIndex.push(cellIndex);
            }
        }
    }
    for (var i = 1; i < workbook.rows.length; i++) {
        for (var j = 0; j < multipleSelectIndex.length; j++) {
            var multipleValues = workbook.rows[i].cells[multipleSelectIndex[j]].value;
            workbook.rows[i].cells[multipleSelectIndex[j]].value = getMultipleSelectValue(multipleValues);
        }
    }
}

function getMultipleSelectValue(selectedList) {
    var text = '';
    if (typeof (selectedList) !== 'string' && selectedList !== null) {
        if (selectedList.length) {
            for (var i = 0; i < selectedList.length; i++) {
                if (text === '') {
                    text = selectedList[i].DataText;
                } else {
                    text = text + ',' + selectedList[i].DataText;
                }
            }
        } else {
            text = selectedList.DataText;
        }
    } else {
        text = selectedList;
    }
    return text;
}

function excelExport(e) {
    var date = $('#FileDate').val() || "";
    var elementName = (e.sender.element || [])[0].id || "TransactionDetail";
    var d = '';
    if (date.length > 0) {
        d = date.split("/");
    }
    var currentDate = new Date();
    var filedate = currentDate.getMonth() + 1 + '-' + currentDate.getDate() + '-' + currentDate.getFullYear();
    if (d.length > 0) {
        filedate = d[0] + '-' + d[1] + '-' + d[2];
    }

    e.workbook.fileName = elementName + '_' + filedate + '_' + $("#ReportID").text().trim() + ".xlsx";

    if (e.sender._exporting === undefined) {
        e.sender._exporting = true;
    }
    var gridcolumn = e.sender.columns;
    e.sender._exporting = true;
    var groupData = window.flattenGroupData(e.data || []);
    var leafColumns = window.leafColumns(gridcolumn, 'columns');

    var sheet = e.workbook.sheets[0];
    $.each(sheet.columns, function (index, column) {
        if (!column.width) {
            column.width = 200;
            column.autoWidth = false;
        }
    })
    var groupIndex = 0;
    var hearderRows = sheet.rows.filter(function (o) {
        return o.type == 'header';
    }).reverse();

    var isCheckBox = (leafColumns[0].template || []).includes("input type='checkbox'");

    if (isCheckBox) {
        leafColumns.shift();
        //e.sender.columns.shift();
        for (var i = 0; i < sheet.rows.length; i++) {
            sheet.rows[i].cells.shift();
        }
        sheet.columns.shift();
    }
    var headRowCount = hearderRows[0].cells.length;
    for (var rowIndex = 1; rowIndex < sheet.rows.length; rowIndex++) {
        var row = sheet.rows[rowIndex];
        var filedNames = ["Comment", "Description"];
        if (row.type === 'data') {
            for (var index = 0; index < row.cells.length; index++) {
                var column = leafColumns[index];
                var cellValue = row.cells[index].value;
                var isGroupData = belongToGroupData(groupData, cellValue);
                var className = (column && column.attributes || {}).class || '';
                var isNumber = className.indexOf('countRightAlign') > -1;
                var isCurrency = className.indexOf('currencyRightAlign') > -1;

                if (isNumber) {
                    row.cells[index].hAlign = "right";
                }
                if (isCurrency) {
                    row.cells[index].format = "#,##0.00;(#,##0.00)";
                    row.cells[index].value = cellValue;
                    row.cells[index].hAlign = "right";
                } else if (isGroupData) {
                    //the value should not be shown in the groupping column.
                    row.cells[index].value = '';
                } else {
                    if (filedNames.includes(column.field)) {
                        //console.log('start', cellValue);
                        try {
                            var elem = document.createElement('div')
                            elem.innerHTML = kendo.template(cellValue)({})
                            // console.log('start', elem.innerText);
                            row.cells[index].value = elem.innerText;
                        }
                        catch (e) {
                        }
                    }
                }
            }
        }

        if (row.type === 'group-header') {
            var groupItem = groupData[groupIndex];
            var deep = (groupItem || {}).deep || 1;
            var groupCells = row.cells[deep - 1];
            if (belongToGroupData(groupData, groupCells.value)) {
                //if the column grouping in the kendo grid, export to excel this column will add title as the prefix.
                //it's the default behavior of the kendo grid.
                groupCells.value = groupCells.value.substring(groupCells.value.indexOf(':') + 1);
            }
            groupCells.colSpan = Math.abs(headRowCount - leafColumns.length) + 1;

            for (var gIndex = deep; gIndex < leafColumns.length; gIndex++) {
                var column = leafColumns[gIndex];
                var columnAggregates = (column.aggregates || []);
                var cell = $.extend(true, {}, row.cells[0]);
                cell.colSpan = 1;
                var className = (column && column.attributes || {}).class || '';
                var isNumber = className.indexOf('countRightAlign') > -1;
                if (columnAggregates.length > 0) {
                    cell.value = groupItem.aggregates[column.field][columnAggregates[0]];
                    cell.format = isNumber ? "" : "#,##0.00;(#,##0.00)";
                    cell.hAlign = "right";
                } else {
                    cell.value = "";
                }
                row.cells.push(cell);
            }
            groupIndex++;
        }
    }
}

function belongToGroupData(groupData, cellValue) {
    var isGroupData = false;
    cellValue = cellValue + '';
    for (var i = 0; i < groupData.length; i++) {
        if (cellValue.indexOf(groupData[i].value) >= 0 && !isGroupData) {
            isGroupData = true;
        }
    }
    return isGroupData;
}

function leafColumns(columns, itemName) {
    var self = this;
    var result = [];
    for (var idx = 0; idx < columns.length; idx++) {
        if (!columns[idx][itemName]) {
            if (!columns[idx]["hidden"] || !itemName) {
                result.push(columns[idx]);
            }
        } else {
            result = result.concat(self.leafColumns(columns[idx][itemName]));
        }
    }
    return result;
}

function flattenGroupData(groupData, deep) {
    var self = this;
    deep = deep || 0;
    deep++;
    var result = [];
    for (var idx = 0; idx < groupData.length; idx++) {
        var item = groupData[idx];
        if (!item.items) {
            if (item.aggregates) {
                item.deep = deep;
                result.push(item);
            }
        } else {
            item.deep = deep;
            result.push(item);
            result = result.concat(self.flattenGroupData(item.items, deep));
        }
    }
    return result;
}

function compoundObjectWithForgeryToken(obj) {
    var antiforgery = forgeryToken();
    $.extend(true, obj, antiforgery);
    return obj;
}

function dirtyCheck() {
    var isExist = false;
    var grid = $(".k-grid").data("kendoGrid");
    if (grid) {
        var items = grid.dataItems();
        var destroyData = grid.dataSource._destroyed;
        if (destroyData && destroyData.length > 0) return true;
        items.forEach(function (o) {
            if (o.dirty || o.IsAdd && o.ID < 1) {
                isExist = true;
                return;
            }
        });
    }
    return isExist;
}

function onRequestEnd(e) {
    if (e.type === "update" && !e.response.Errors) {
        DisplayNotification("Record updated successfully!", "success");
    }
    if (e.type === "create" && !e.response.Errors) {
        DisplayNotification("Record created successfully!", "success");
    }
    if (e.type === "destroy" && !e.response.Errors) {
        DisplayNotification("Record deleted successfully!", "success");
    }
    return true;
}

var kendoGrid = {
    onCellClose: function (e) {
        if (e.model.id > 0) {
            if ($(e.container).next().length >= 0) {
                setTimeout(function () {
                    var currentEditor = e.container;
                    var nextEditor = currentEditor.next();
                    // kendoGrid.onEditNextCell(currentEditor, nextEditor, e.sender);
                }, 10);
            }
        }
    },

    onEditNextCell: function (currentEditor, nextEditor, grid) {
        // debugger;
        var column = leafColumns(grid.columns)[grid.cellIndex(nextEditor)];
        var dataItem = grid._modelForContainer(nextEditor);
        var isEdit = column && column.editable && column.editable(dataItem);
        if (isEdit || column && column.editable) {
            grid.editCell(nextEditor);
        } else {
            nextEditor = nextEditor.next();
            if (nextEditor) {
                // grid.editCell(nextEditor);
                // kendoGrid.onEditNextCell(nextEditor, grid);
            } else {
            }
        }
    },
    setRowHighlight: function (rows) {
        for (var i = 0; i < rows.length; i++) {
            $(rows[i]).attr('style', 'background-color: lightsalmon');
        }
    }
}

var isRefresh = false;
function onRequestStart(e) {
    if (e.type === "read") {
        var isDirty = dirtyCheck();
        var dataSource = e.sender;
        if (isDirty && !isRefresh) {
            e._defaultPrevented = true;
            var title = "Changes have not been saved";
            var content = "If you have made any changes to the fields without clicking the Save button, your changes will be lost.  Are you sure you want to continue?";
            if (location.pathname.toLowerCase().indexOf('approval') > 0) {
                content = "You have input the comment without submit/reject the record, your changes will be lost.  Are you sure you want to continue?";
                title = "Changes have not been apply";
            }

            var confirmDialog = $("<div />").kendoConfirm({ width: "600px", height: "180px", title: title, content: content }).data('kendoConfirm').open();
            confirmDialog.result
                .then(function () {
                    isRefresh = true;
                    dataSource.read();
                    isRefresh = false;
                });
        }
    }
}

var isRefershLink = false;
function linkTo(path) {
    if (path.indexOf(".pdf") > 0) {
        DownloadFile(path);
    } else {
        var isDirty = dirtyCheck();
        if (isDirty) {
            isRefershLink = true;
            var title = "Changes have not been saved";
            var content = "If you have made any changes to the fields without clicking the Save button, your changes will be lost.  Are you sure you want to continue?";
            if (location.pathname.toLowerCase().indexOf('approval') > 0) {
                content = "You have input the comment without submit/reject the record, your changes will be lost.  Are you sure you want to continue?";
                title = "Changes have not been apply";
            }
            var confirmDialog = $("<div />").kendoConfirm({ width: "600px", height: "180px", title: title, content: content }).data('kendoConfirm').open();
            confirmDialog.result
                .then(function () {
                    window.location.href = path;
                })
        } else {
            window.location.href = path;
        }
    }
}

/*
To over write the cell close event, in order to fixed the JS error in edit mode. becuase we misused the cell edit mode to met the requirment,
then kendo grid cannot kindly support batch edit under the validation in the row edit mode.
*/
$(document).ready(function () {
    var grid = $('.k-grid').data('kendoGrid');
    if (grid) {
        grid.bind("cellClose", kendoGrid.onCellClose);
        grid.closeCell = function (isCancel) {
            var that = this, cell = that._editContainer, column, tr, model;
            if (!cell) {
                return;
            }
            model = that._modelForContainer(cell);
            if (isCancel && that.trigger('cancel', {
                container: cell,
                model: model
            })) {
                return;
            }
            if (cell && cell.hasClass('k-grid-edit-row') && cell.length >= 1 && $('#Employees').data('kendoGrid')) {
                var that = this;
                var valid = that.editable && that.editable.end();
                if ((valid || !that.editable) && !that.trigger('saveChanges')) {
                } else if (!valid) {
                    that._scrollVirtualWrapper();
                }
            }

            if (cell) {
                that.trigger('cellClose', {
                    type: isCancel ? 'cancel' : 'save',
                    model: model,
                    container: cell
                });
            }
            cell.removeClass('k-edit-cell');
            tr = cell.parent().removeClass('k-grid-edit-row');
            if (that.lockedContent) {
                that._relatedRow(tr).removeClass('k-grid-edit-row');
            }

            if (cell[0].tagName === 'TR') {
                // if(that.editable.end()) {
                // that._destroyEditable();
                // that._displayRow(cell); //in the row validation the cell is not cell object, actually it's a row object. so it has an error.
                // }

                if ($(document.activeElement).is('body') || $(document.activeElement).is('table') || cell) {
                    if (that.editable.end()) {
                        that._destroyEditable();
                        //sepcial logic to fixed 231415. it was not the root cause, but we haven't time to find out currently.
                        if (model.hasOwnProperty('Hours') && $('#Timesheet_active_cell').attr('data-container-for') === 'Hours') {
                            model.Hours = parseFloat($('#Timesheet_active_cell input').val());
                            model.dirtyFields['Hours'] = true;
                        }
                        that._displayRow(cell);
                    }
                } else {
                    return;
                }
            } else {
                that._destroyEditable();
                column = leafColumns(that.columns)[that.cellIndex(cell)];
                that._displayCell(cell, column, model);
            }

            if (that._shouldClearEditableState) {
                that._clearEditableState();
            }
            that.trigger('itemChange', {
                item: tr,
                data: model,
                ns: kendo.ui
            });
            //if (that.lockedContent) {
            //    that._adjustRowsHeight(tr.css('height', '')[0], that._relatedRow(tr).css('height', '')[0]);
            //}
        }
    }
    resizeGridAuto();
});

function LoadMenu(content) {
    $("#lvc-nav").html(content);
    initMenuTree();
    var wrapMenuData = sessionStorage.getItem("wrapMenu");
    if (wrapMenuData && wrapMenuData == "0") {
        $(".icon-menu").click();
    }
}

function initMenuTree() {
    $(".icon-menu").click(function () {
        var wrapMenuData = sessionStorage.getItem("wrapMenu");
        var isExpand = wrapMenuData && wrapMenuData == "1";
        $(".lvc-wrap").toggleClass(function () {
            if ($(this).hasClass("lvc-close") && isExpand) {
                $(this).removeClass("lvc-close");
                return "";
            } else {
                $(this).removeClass("");
                return "lvc-close";
            }
            //"lvc-close"
        });
        $("#aside").toggleClass(function () {
            if ($(this).hasClass("lvc-close") && isExpand) {
                $(this).removeClass("lvc-close");
                return "";
            } else {
                $(this).removeClass("k-i-indent");
                return "lvc-close";
            }
            //"lvc-close"
        });
        $("#main").toggleClass(function () {
            if ($(this).hasClass("lvc-close") && isExpand) {
                $(this).removeClass("lvc-close");
                return "";
            } else {
                $(this).removeClass("");
                return "lvc-close";
            }
            //"lvc-close"
        });
        $("ol").toggleClass(function () {
            if ($(this).hasClass("small-ol") && isExpand) {
                $(this).removeClass("small-ol");
                return "";
            } else {
                $(this).removeClass("");
                return "small-ol";
            }
            //"lvc-close"
        })
        $(".next-layer ol").hide();
        $("#expandIcon").toggleClass(function () {
            if ($(this).hasClass("k-i-outdent")) {
                $(this).removeClass("k-i-outdent");
                return "k-i-indent";
            } else {
                $(this).removeClass("k-i-indent");
                return "k-i-outdent";
            }
        });
        if ($("#lvc-nav").hasClass('lvc-close')) {
            $(".next-layer ").removeClass("arrow")
        }

        setMenuState();
        setTimeout(resizeGrid, 500);
    })

    $(".lvc-nav li").click(function () {
        $(this).siblings().find('ol').hide();
        $(this).addClass("active").siblings().removeClass("active")
    })

    $("ol>li").click(function (e) {
        // console.log('ol>li clicked')
        e.stopPropagation();
        $(this).parent().parent().removeClass("active")
    })

    $(".next-layer").click(function () {
        $(this).children("ol").toggle();
        $(this).toggleClass("arrow").siblings().removeClass("arrow")
    })

    $("ol li").click(function () {
        if ($("ol").hasClass('small-ol')) {
            $(".small-ol").hide();
            $(this).parent().parent().addClass("active")
        }
    })
}

function setMenuState() {
    //var wrapMenuData = sessionStorage.getItem("wrapMenu");

    var isClose = $(".lvc-wrap").hasClass("lvc-close");
    if (isClose) {
        sessionStorage.setItem("wrapMenu", "0");
    } else {
        sessionStorage.setItem("wrapMenu", "1");
    }
}

function resizeGrid() {
    var grid = $(".k-grid").data("kendoGrid");
    if (grid) {
        grid._resize();
    }
}

function EncodeHtml(value) {
    //if (value.indexOf('&lt;') < 0) {
    //    return value;
    //}
    var parser = new DOMParser();
    var dom = parser.parseFromString(
        '<!doctype html><body>' + value,
        'text/html');
    return dom.body.textContent;
}

function resizeGridAuto() {
    //var dataArea = $(".k-grid").find(".k-grid-content");
    //var bottomArea = $(".k-grid").find(".k-grid-pager");
    //var newHeight = $(document.body).height() - ((typeof ($(".k-grid").offset()) === 'undefined') ? 0 : $(".k-grid").offset().top);
    //var diff = $(".k-grid").innerHeight() - dataArea.innerHeight();
    //$(".k-grid").height(newHeight - bottomArea.innerHeight());
    //dataArea.height(newHeight - diff - bottomArea.innerHeight());
};

$(window).resize(function () {
    resizeGridAuto();
    resizeGrid();
});

function DownloadFile(filePath) {
    var filename = filePath.substr(filePath.lastIndexOf('/') + 1);
    kConfirm("Please Confirm", "File '" + filename + "' will be downloaded. Click 'OK' to proceed.").then(function () {
        var l = document.createElement('a');
        l.href = filePath;
        l.download = filename
        l.target = '_blank';
        l.click();
    })
}

function addDays(date, days) {
    var result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
}

function addMonth(date, months) {
    var result = new Date(date);
    result.setMonth(result.getMonth() + months);
    return result;
}
function htmlEncode(value) {
    // Create a in-memory element, set its inner text (which is automatically encoded)
    // Then grab the encoded contents back out. The element never exists on the DOM.
    return $('<textarea/>').text(value).html();
}

function htmlDecode(value) {
    return $('<textarea/>').html(value).text();
}