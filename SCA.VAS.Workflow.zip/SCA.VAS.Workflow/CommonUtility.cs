#region	Copyright 2005 by SCA.VAS USA Inc.
/*
************************************************************************
Copyright 2005 by SCA.VAS USA Inc.

All	rights reserved. No	portion	of this	software or	its	content	may	be
reproduced in any form or by any means,	without	the	express	written
permission of the copyright	owner.
************************************************************************
*/
#endregion Copyright

#region	References
using System;
using System.Data;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.IO;
using System.Xml;
using System.Globalization;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Configuration;
using System.Collections.ObjectModel;
using ICSharpCode.SharpZipLib.Zip;

using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.ValueObjects;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.ValueObjects.Supplier.Subcontractor;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.ValueObjects.Scorecard.Template;

using SCA.VAS.ValueObjects.Scorecard;

using SCA.VAS.ValueObjects.Rfd;
//using SCA.VAS.BusinessLogic.Rfd;
using Microsoft.Office.Interop.Word;
using TimeZone = SCA.VAS.ValueObjects.Common.TimeZone;
using WizardStep = SCA.VAS.ValueObjects.Common.WizardStep;
using Menu = SCA.VAS.ValueObjects.User.Menu;
using WizardStepCollection = SCA.VAS.ValueObjects.Common.WizardStepCollection;
using SCA.VAS.BusinessLogic.Supplier.Subcontractor.Utilities;
using SCA.VAS.BusinessLogic.Supplier.Subcontractor;
using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using log4net;
using SCA.VAS.Workflow;
using Page = System.Web.UI.Page;

#endregion

namespace SCA.VAS.Workflow
{


    public partial class CommonUtility
    {
        #region	Private Member
        private static Menu currentStep;
        private static int level = 0;
        private static MenuCollection allLevelMenus;
        private static ILog _logger = null;
        #endregion

        #region	Constructors
        static CommonUtility()
        {
            _logger = LoggingUtility.GetLogger(typeof(CommonUtility).FullName);
        }

        ///	<summary>
        ///	default	constructor	
        ///	</summary>
        public CommonUtility()
        {
        }
        #endregion Constructors

        #region	Public Methods
        public static bool IsAdministrator(string userName)
        {
            return Roles.IsUserInRole(userName, "Administrator");
        }
        public static bool IsCQUAdministrator(string userName)
        {
            return Roles.IsUserInRole(userName, "CQU Admin");
        }

        public static bool IsContractSpecialist(string userName)
        {
            return Roles.IsUserInRole(userName, "Contract Specialist");
        }

        public static bool IsGlobalCESAdmin(string userName)
        {
            return (Roles.IsUserInRole(userName, "Administrator")
                || Roles.IsUserInRole(userName, "Global CES Admin"));
        }

        public static bool IsCESAdmin(string userName)
        {
            return (Roles.IsUserInRole(userName, "Administrator")
                || Roles.IsUserInRole(userName, "Global CES Admin")
                || Roles.IsUserInRole(userName, "Departmental CES Admin"));
        }

        public static bool IsCESViewer(string userName)
        {
            return (Roles.IsUserInRole(userName, "Administrator")
                || Roles.IsUserInRole(userName, "Global CES Admin")
                || Roles.IsUserInRole(userName, "Global CES Viewer")
                || Roles.IsUserInRole(userName, "Departmental CES Admin"));
        }

        public static bool HasRole(string userName, string roleName)
        {
            return Roles.IsUserInRole(userName, roleName);
        }

        public static bool IsValidEmailAddress(string emailAddressString)
        {
            Regex objRegex = new Regex(@"^((([a-z]|[0-9]|!|#|$|%|&|'|\*|\+|\-|/|=|\?|\^|_|`|\{|\||\}|~)+(\.([a-z]|[0-9]|!|#|$|%|&|'|\*|\+|\-|/|=|\?|\^|_|`|\{|\||\}|~)+)*)@((((([a-z]|[0-9])([a-z]|[0-9]|\-){0,61}([a-z]|[0-9])\.))*([a-z]|[0-9])([a-z]|[0-9]|\-){0,61}([a-z]|[0-9])\.(af|ax|al|dz|as|ad|ao|ai|aq|ag|ar|am|aw|au|at|az|bs|bh|bd|bb|by|be|bz|bj|bm|bt|bo|ba|bw|bv|br|io|bn|bg|bf|bi|kh|cm|ca|cv|ky|cf|td|cl|cn|cx|cc|co|km|cg|cd|ck|cr|ci|hr|cu|cy|cz|dk|dj|dm|do|ec|eg|sv|gq|er|ee|et|fk|fo|fj|fi|fr|gf|pf|tf|ga|gm|ge|de|gh|gi|gr|gl|gd|gp|gu|gt| gg|gn|gw|gy|ht|hm|va|hn|hk|hu|is|in|id|ir|iq|ie|im|il|it|jm|jp|je|jo|kz|ke|ki|kp|kr|kw|kg|la|lv|lb|ls|lr|ly|li|lt|lu|mo|mk|mg|mw|my|mv|ml|mt|mh|mq|mr|mu|yt|mx|fm|md|mc|mn|ms|ma|mz|mm|na|nr|np|nl|an|nc|nz|ni|ne|ng|nu|nf|mp|no|om|pk|pw|ps|pa|pg|py|pe|ph|pn|pl|pt|pr|qa|re|ro|ru|rw|sh|kn|lc|pm|vc|ws|sm|st|sa|sn|cs|sc|sl|sg|sk|si|sb|so|za|gs|es|lk|sd|sr|sj|sz|se|ch|sy|tw|tj|tz|th|tl|tg|tk|to|tt|tn|tr|tm|tc|tv|ug|ua|ae|gb|us|um|uy|uz|vu|ve|vn|vg|vi|wf|eh|ye|zm|zw|com|edu|gov|int|mil|net|org|biz|info|name|pro|aero|coop|museum|arpa))|(((([0-9]){1,3}\.){3}([0-9]){1,3}))|(\[((([0-9]){1,3}\.){3}([0-9]){1,3})\])))$", RegexOptions.IgnoreCase | RegexOptions.Compiled);
            return objRegex.IsMatch(emailAddressString);
        }

        public static User GetUser(int userId)
        {
            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, userId);

            if (user == null) return null;

            MembershipUser membershipUser = Membership.GetUser(user.UserName);

            user.Email = membershipUser.Email;
            user.Password = membershipUser.GetPassword();

            return user;
        }

        public static bool CreateUserLog(int userId, string url, string refType, int refId, string ipAddress)
        {
            UserLog userLog = UserLogUtility.CreateObject();
            userLog.UserId = userId;
            userLog.AccessUrl = url;
            userLog.RefType = refType;
            userLog.RefId = refId;
            userLog.IpAddress = ipAddress;
            return UserLogUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, userLog);
        }

        public static bool BuyerLogin(int buyerId, string sessionId)
        {
            AccessLog accessLog = AccessLogUtility.CreateObject();

            accessLog.UserType = "User";
            accessLog.UserId = buyerId;
            accessLog.SessionId = sessionId;

            return AccessLogUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, accessLog);
        }

        public static bool BuyerLogout(string sessionId)
        {
            AccessLog accessLog = AccessLogUtility.CreateObject();

            accessLog.UserType = "User";
            accessLog.SessionId = sessionId;

            return AccessLogUtility.Update(ConstantUtility.USER_DATASOURCE_NAME, accessLog);
        }

        public static void Display(DataGrid dataGrid, int totalNumber)
        {
            dataGrid.VirtualItemCount = totalNumber;
            if (totalNumber <= dataGrid.PageSize)
            {
                dataGrid.AllowCustomPaging = false;
                dataGrid.AllowPaging = false;
            }
            else
            {
                dataGrid.AllowCustomPaging = true;
                dataGrid.AllowPaging = true;
            }
            dataGrid.Visible = true;
        }

        public static void SetWorkflowControlPermission(Control dataItem, int menuId, int nodeId)
        {
            PermissionDetailCollection permissionControls = PermissionDetailUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                PermissionDetailManager.FIND_PERMISSIONDETAIL_BY_USER,
                new object[] { menuId, 0, ConstantUtility.WORKFLOW_PERMISSION, nodeId });

            if (permissionControls != null && permissionControls.Count > 0)
            {
                foreach (PermissionDetail permissionDetail in permissionControls)
                {
                    Control control = dataItem.FindControl(permissionDetail.ControlName);
                    if (control != null && control is WebControl)
                    {
                        ((WebControl)control).Enabled = false;
                        control.Visible = false;
                    }
                }
            }
        }

        public static void SetSystemControlPermission(Page page, int userId, int menuId)
        {
            Control localControl = page.Form.FindControl("content");

            PermissionDetailCollection permissionControls = PermissionDetailUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                PermissionDetailManager.FIND_PERMISSIONDETAIL_BY_USER,
                new object[] { menuId, userId, ConstantUtility.SYSTEM_PERMISSION, 0 });

            if (permissionControls != null && permissionControls.Count > 0)
            {
                foreach (PermissionDetail permissionDetail in permissionControls)
                {
                    string[] controlPath = permissionDetail.ControlName.Split(':');
                    SetControlPermission(localControl, controlPath, 0);
                }
            }
        }

        public static void SetControlPermission(Control localControl, string[] controlPath, int index)
        {
            Control control = localControl;
            if (control == null) return;

            for (int i = index; i < controlPath.Length; i++)
            {
                if (controlPath[i] != "")
                {
                    control = control.FindControl(controlPath[i]);
                    if (control == null) return;
                }
                else
                {
                    for (int j = 0; j < control.Controls.Count; j++)
                        SetControlPermission(control.Controls[j], controlPath, i + 1);
                    return;
                }
            }
            if ((control is WebControl && ((WebControl)control).Enabled) || !(control is WebControl))
                control.Visible = true;
        }

        public static void SetControlReadOnlyPermission(Control control)
        {
            if (control == null) return;

            if (control is Button)
            //|| control is TextBox || control is CheckBox || control is CheckBoxList
            //|| control is RadioButton || control is RadioButtonList || control is ImageButton
            //|| control is LinkButton)
            {
                ((WebControl)control).Enabled = false;
            }

            if (control.Controls != null && control.Controls.Count > 0)
            {
                foreach (Control c in control.Controls)
                    SetControlReadOnlyPermission(c);
            }
            return;
        }

        public static bool HasPermission(int userId, string pageName)
        {
            MenuCollection menus = MenuUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                MenuManager.FIND_MENU_BY_USER,
                new object[] 
                { 
                    userId, 
                    Membership.ApplicationName,
                    pageName
                });
            level = 0;
            allLevelMenus = new MenuCollection();
            GetAllLevelMenu(menus);

            bool pagePermission = false;
            for (int i = 0; i < allLevelMenus.Count; i++)
            {
                if (allLevelMenus[i].Url.ToLower().IndexOf(pageName.ToLower()) != -1)
                {
                    pagePermission = true;
                    break;
                }
            }
            return pagePermission;
        }

        // Writes file to current folder
        public static void WriteToFile(string strPath, byte[] Buffer)
        {
            FileStream newFile = null;
            try
            {
                // Create a file
                newFile = new FileStream(strPath, FileMode.Create);

                // Write data to the file
                newFile.Write(Buffer, 0, Buffer.Length);
            }
            catch { }
            finally
            {
                // Close file
                newFile.Close();
            }
        }

        public static TimeZoneCollection AllTimeZones()
        {
            string xmlFileName = ConfigurationManager.AppSettings["LookupFolder"] + "TimeZone.xml";
            string s = ReadFile(xmlFileName);
            TimeZoneCollection timeZones = (TimeZoneCollection)XmlUtility.Deserialize(s, typeof(TimeZoneCollection));

            ReadOnlyCollection<TimeZoneInfo> tzCollection = TimeZoneInfo.GetSystemTimeZones();

            foreach (TimeZoneInfo tz in tzCollection)
            {
                for (int i = 0; i < timeZones.Count; i++)
                {
                    if (tz.StandardName == timeZones[i].StdName)
                    {
                        timeZones[i].Description = tz.DisplayName;
                    }
                }
            }

            return timeZones;
        }

        public static string FormatPhone(string phone)
        {
            string formatedPhone = StringUtility.RemoveExtra(phone);
            if (formatedPhone.Length == 11)
                formatedPhone = formatedPhone.Substring(1);
            if (formatedPhone.Length == 10)
            {
                formatedPhone = formatedPhone.Substring(0, 3) + "/" + formatedPhone.Substring(3, 3)
                    + "-" + formatedPhone.Substring(6, 4);
            }
            return formatedPhone;
        }

        public static string FormatSize(Int64 lSize)
        {
            //Format number to KB 
            string stringSize = "";
            NumberFormatInfo myNfi = new NumberFormatInfo();
            Int64 lKBSize = 0;

            if (lSize < 1024)
            {
                if (lSize == 0)
                {
                    //zero byte 
                    stringSize = "0";
                }
                else
                {
                    //less than 1K but not zero byte 
                    stringSize = "1";
                }
            }
            else
            {
                //convert to KB 
                lKBSize = lSize / 1024;

                //format number with default format 
                stringSize = lKBSize.ToString("n", myNfi);

                //remove decimal 
                stringSize = stringSize.Replace(".00", "");
            }

            return stringSize + " KB";
        }

        public static string GetSupplierStatus(SupplierStatus supplierStatus)
        {
            if (supplierStatus == null) return "N/A";

            if (supplierStatus.Status == "New Qualification" ||
                supplierStatus.Status == "New Certification" ||
                supplierStatus.Status == "Application Submitted" ||
                supplierStatus.Status == "Appendix A Pending" ||
                supplierStatus.Status == "Certification Submitted" ||
                supplierStatus.Status == "Qualified" ||
                supplierStatus.Status == "Certified" ||
                supplierStatus.Status == "Administratively Closed" ||
                supplierStatus.Status == "Certification Admin Closed" ||
                supplierStatus.Status == "Inactive" ||
                supplierStatus.Status == "Disqualified" ||
                supplierStatus.Status == "Decertified" ||
                supplierStatus.Status == "Withdrawn" ||
                supplierStatus.Status == "Rescinded" ||
                supplierStatus.Status == "Suspended" ||
                supplierStatus.Status == "Expired" ||
                supplierStatus.Status == "Deny" ||
                supplierStatus.Status == "Conditionally Certified")
                return supplierStatus.Status;
            else
                return "Pending";
        }

        public static Hashtable GetSupplierHashTable(Supplier supplier)
        {
            SupplierFieldMapCollection supplierFieldMaps = SupplierFieldMapUtility.GetAll(ConstantUtility.SUPPLIER_DATASOURCE_NAME);
            Hashtable supplierList = new Hashtable();
            if (supplierFieldMaps != null)
            {
                foreach (SupplierFieldMap sfm in supplierFieldMaps)
                {
                    // Supplier Property
                    Type typeSupplier = typeof(Supplier);
                    if (typeSupplier.GetProperty(sfm.PropertyName) == null) continue;
                    object property = typeSupplier.InvokeMember(sfm.PropertyName,
                        BindingFlags.GetProperty, null, supplier, null);
                    if (property == null)
                    {
                        sfm.FieldValue = (sfm.IsRequired == "Y") ? ConstantUtility.REQUIRED_FIELD_STR : ConstantUtility.NOT_SPECIFIED_STR;
                        supplierList.Add(sfm.SystemName, sfm.FieldValue);
                        continue;
                    }

                    if (sfm.SubPropertyName == string.Empty)
                    {
                        if (ContentToString(property) == string.Empty)
                            sfm.FieldValue = (sfm.IsRequired == "Y") ? ConstantUtility.REQUIRED_FIELD_STR : ConstantUtility.NOT_SPECIFIED_STR;
                        else
                            sfm.FieldValue = property.ToString();
                        supplierList.Add(sfm.SystemName, sfm.FieldValue);
                        continue;
                    }

                    //Supplier Sub-Property
                    Type typeSub = property.GetType();
                    object subProperty = null;
                    if (property is CollectionBase)
                    {
                        CollectionBase collection = (CollectionBase)property;
                        if (sfm.TypeField == string.Empty)
                        {
                            if (sfm.TypeValue == string.Empty)
                            {
                                // All data in collection
                                string strValue = string.Empty;
                                foreach (object obj in collection)
                                {
                                    Type typeSubObj = obj.GetType();
                                    if (typeSubObj.GetProperty(sfm.SubPropertyName) == null) continue;
                                    subProperty = typeSubObj.InvokeMember(sfm.SubPropertyName, BindingFlags.GetProperty, null, obj, null);
                                    strValue += sfm.SymbolValue + subProperty.ToString();
                                }

                                if (strValue == string.Empty)
                                    sfm.FieldValue = (sfm.IsRequired == "Y") ? ConstantUtility.REQUIRED_FIELD_STR : ConstantUtility.NOT_SPECIFIED_STR;
                                else
                                    sfm.FieldValue = strValue.Substring(sfm.SymbolValue.Length);
                                supplierList.Add(sfm.SystemName, sfm.FieldValue);
                            }
                            else
                            {
                                // Indexed data in collection
                                int index = ConvertUtility.ConvertInt(sfm.TypeValue);
                                if (collection.Count <= index)
                                {
                                    sfm.FieldValue = (sfm.IsRequired == "Y") ? ConstantUtility.REQUIRED_FIELD_STR : ConstantUtility.NOT_SPECIFIED_STR;
                                    supplierList.Add(sfm.SystemName, sfm.FieldValue);
                                    continue;
                                }

                                Type collectionType = collection.GetType();
                                PropertyInfo indexProperty = collectionType.GetProperty("Item");
                                object obj = indexProperty.GetValue(collection, new object[] { index });

                                Type typeSubObj = obj.GetType();
                                if (typeSubObj.GetProperty(sfm.SubPropertyName) == null) continue;
                                subProperty = typeSubObj.InvokeMember(sfm.SubPropertyName, BindingFlags.GetProperty, null, obj, null);
                                if (ContentToString(subProperty) == string.Empty)
                                    sfm.FieldValue = (sfm.IsRequired == "Y") ? ConstantUtility.REQUIRED_FIELD_STR : ConstantUtility.NOT_SPECIFIED_STR;
                                else
                                    sfm.FieldValue = subProperty.ToString();
                                supplierList.Add(sfm.SystemName, sfm.FieldValue);
                            }
                        }
                        else
                        {
                            // Matched data in collection
                            string strValue = string.Empty;
                            foreach (object obj in collection)
                            {
                                Type typeFieldObj = obj.GetType();
                                if (typeFieldObj.GetProperty(sfm.TypeField) == null) continue;
                                object fieldProperty = typeFieldObj.InvokeMember(sfm.TypeField, BindingFlags.GetProperty, null, obj, null);

                                if (fieldProperty.ToString() == sfm.TypeValue)
                                {
                                    if (sfm.SymbolValue != string.Empty)
                                    {
                                        if (typeFieldObj.GetProperty(sfm.SubPropertyName) == null) continue;
                                        subProperty = typeFieldObj.InvokeMember(sfm.SubPropertyName, BindingFlags.GetProperty, null, obj, null);
                                        strValue = String.Format(sfm.SymbolValue, subProperty);
                                    }
                                    else
                                    {
                                        if (typeFieldObj.GetProperty(sfm.SubPropertyName) == null) continue;
                                        strValue = typeFieldObj.InvokeMember(sfm.SubPropertyName, BindingFlags.GetProperty, null, obj, null).ToString();
                                    }
                                }
                            }
                            if (strValue == string.Empty)
                                sfm.FieldValue = (sfm.IsRequired == "Y") ? ConstantUtility.REQUIRED_FIELD_STR : ConstantUtility.NOT_SPECIFIED_STR;
                            else
                                sfm.FieldValue = strValue;
                            supplierList.Add(sfm.SystemName, sfm.FieldValue);
                        }
                    }
                    else
                    {
                        if (typeSub.GetProperty(sfm.SubPropertyName) == null) continue;
                        subProperty = typeSub.InvokeMember(sfm.SubPropertyName, BindingFlags.GetProperty, null, property, null);
                        if (ContentToString(subProperty) == string.Empty)
                            sfm.FieldValue = (sfm.IsRequired == "Y") ? ConstantUtility.REQUIRED_FIELD_STR : ConstantUtility.NOT_SPECIFIED_STR;
                        else
                            sfm.FieldValue = subProperty.ToString();
                        supplierList.Add(sfm.SystemName, sfm.FieldValue);
                    }
                }
            }

            return supplierList;
        }

        public static string GetMyDummySSN(SupplierPersonnel sp)
        {
            string expxml = "<ArrayOfDynamicProperty>"
                                + "<DynamicProperty PropertyName=\"DummySSN\" />"
                            + "</ArrayOfDynamicProperty>";
            DynamicPropertyCollection expproperties = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_PROPERTIES,
                new object[] { "SupplierPersonnel", sp.Id, expxml });
            if (expproperties == null) return "";

            DynamicProperty dp = expproperties.Find("DummySSN");
            if (dp != null)
                return dp.PropertyText;

            return "";
        }
        public static string VendorBoilerPlateStatus(Vendor vendor, string type)
        {
            string expxml = "<ArrayOfDynamicProperty>"
                                + "<DynamicProperty PropertyName=\"BoilerPlateStatus\" PropertyType=\"" + type + "\"/>"
                            + "</ArrayOfDynamicProperty>";
            DynamicPropertyCollection expproperties = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_PROPERTIES,
                new object[] { "Vendor", vendor.Id, expxml });
            if (expproperties == null) return "";

            DynamicProperty dp = expproperties.Find("BoilerPlateStatus");
            if (dp != null)
                return dp.PropertyText;

            return "";
        }

        public static string[] GetVendorClassifications(Vendor vendor)
        {
            string[] classArrayValues = new string[] { "N", "N", "N", "N" };

            if (vendor.CertificationStatus == "Certified")
            {
                string xml = "<ArrayOfDynamicProperty>";
                DynamicPropertyCollection types = DynamicPropertyUtility.FindByCriteria(
                    ConstantUtility.USER_DATASOURCE_NAME,
                    DynamicPropertyManager.FIND_BY_OBJECT,
                    new object[] { "SupplierStaticCertification", vendor.CertifiedSupplierId });
                if (types != null)
                {
                    foreach (DynamicProperty property in types)
                    {
                        xml += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_c_dw_code\" />";
                    }
                }
                xml += "</ArrayOfDynamicProperty>";

                DynamicPropertyCollection properties = DynamicPropertyUtility.FindByCriteria(
                    ConstantUtility.USER_DATASOURCE_NAME,
                    DynamicPropertyManager.FIND_BY_PROPERTIES,
                    new object[] { "SupplierStaticCertification", vendor.CertifiedSupplierId, xml });

                string approvalString = string.Empty;
                if (properties != null)
                {
                    foreach (DynamicProperty property in properties)
                    {
                        switch (property.PropertyName)
                        {
                            case "V_c_dw_code":

                                approvalString = property.PropertyText == "Y" || property.PropertyText == "R" ? "Y" : "N";
                                switch (property.PropertyType)
                                {
                                    case "M":
                                        classArrayValues[0] = approvalString;
                                        break;
                                    case "W":
                                        classArrayValues[1] = approvalString;
                                        break;
                                    case "L":
                                        classArrayValues[2] = approvalString;
                                        break;
                                }
                                break;

                        }
                    }
                }
                classArrayValues[3] = "Y";

            }

            return classArrayValues;

        }


        public static string[] GetVendorSBSClassifications(Vendor vendor)
        {
            string[] classArrayValues = new string[] { "N", "N", "N", "N" };


            string xml = "<ArrayOfDynamicProperty>";
            DynamicPropertyCollection types = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_OBJECT,
                new object[] { "VendorSBSCertification", vendor.Id });
            if (types != null)
            {
                foreach (DynamicProperty property in types)
                {
                    xml += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"Status\" />";
                }
            }
            xml += "</ArrayOfDynamicProperty>";

            DynamicPropertyCollection properties = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_PROPERTIES,
                new object[] { "VendorSBSCertification", vendor.Id, xml });

            string approvalString = string.Empty;
            if (properties != null)
            {
                foreach (DynamicProperty property in properties)
                {
                    switch (property.PropertyName)
                    {
                        case "Status":

                            approvalString = property.PropertyText == "Certified" ? "Y" : "N";
                            switch (property.PropertyType)
                            {
                                case "MBE":
                                    classArrayValues[0] = approvalString;
                                    break;
                                case "WBE":
                                    classArrayValues[1] = approvalString;
                                    break;
                                case "LBE":
                                    classArrayValues[2] = approvalString;
                                    break;
                            }
                            break;

                    }
                }
            }
            classArrayValues[3] = "Y";


            return classArrayValues;

        }



        public static DateTime[] GetVendorSBSClassificationCertifiedDates(Vendor vendor)
        {
            DateTime[] classCertifiedDateArrayValues = new DateTime[3];


            string xml = "<ArrayOfDynamicProperty>";
            DynamicPropertyCollection types = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_OBJECT,
                new object[] { "VendorSBSCertification", vendor.Id });

            if (types != null)
            {
                foreach (DynamicProperty property in types)
                {
                    xml += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"CertifiedDate\" />";
                }
            }
            xml += "</ArrayOfDynamicProperty>";
            DynamicPropertyCollection properties = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_PROPERTIES,
                new object[] { "VendorSBSCertification", vendor.Id, xml });

            if (properties != null)
            {
                foreach (DynamicProperty property in properties)
                {
                    switch (property.PropertyName)
                    {
                        case "CertifiedDate":
                            switch (property.PropertyType)
                            {
                                case "MBE":
                                    classCertifiedDateArrayValues[0] = property.PropertyDate;
                                    break;
                                case "WBE":
                                    classCertifiedDateArrayValues[1] = property.PropertyDate;
                                    break;
                                case "LBE":
                                    classCertifiedDateArrayValues[2] = property.PropertyDate;
                                    break;
                            }
                            break;

                    }
                }
            }

            return classCertifiedDateArrayValues;
        }


        public static DateTime[] GetVendorSBSClassificationExpirationDates(Vendor vendor)
        {
            DateTime[] classExpirationDateArrayValues = new DateTime[3];


            string xml = "<ArrayOfDynamicProperty>";
            DynamicPropertyCollection types = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_OBJECT,
                new object[] { "VendorSBSCertification", vendor.Id });

            if (types != null)
            {
                foreach (DynamicProperty property in types)
                {
                    xml += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"ExpirationDate\" />";
                }
            }
            xml += "</ArrayOfDynamicProperty>";
            DynamicPropertyCollection properties = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_PROPERTIES,
                new object[] { "VendorSBSCertification", vendor.Id, xml });

            if (properties != null)
            {
                foreach (DynamicProperty property in properties)
                {
                    switch (property.PropertyName)
                    {
                        case "ExpirationDate":
                            switch (property.PropertyType)
                            {
                                case "MBE":
                                    classExpirationDateArrayValues[0] = property.PropertyDate;
                                    break;
                                case "WBE":
                                    classExpirationDateArrayValues[1] = property.PropertyDate;
                                    break;
                                case "LBE":
                                    classExpirationDateArrayValues[2] = property.PropertyDate;
                                    break;
                            }
                            break;

                    }
                }
            }

            return classExpirationDateArrayValues;
        }



        public static string GetVendorSBSClassificationsString(Vendor vendor)
        {
            string classifications = string.Empty;
            string[] classArrayValues = GetVendorClassifications(vendor);
            bool hasApproval = classArrayValues[ConstantUtility.CLASSIFICATION_ARRAY.Length] == "Y";
            for (int i = 0; i < classArrayValues.Length - 1; i++)
            {
                if (classArrayValues[i] == "Y")
                {
                    classifications += ConstantUtility.CLASSIFICATION_ARRAY[i];
                    classifications += ", ";
                }
            }
            if (classifications.Trim().Length > 0)
                classifications = classifications.Substring(0, classifications.Length - 2);

            return classifications;
        }


        public static string[] GetSupplierClassifications(Supplier supplier, WorkflowHistoryCollection histories)
        {
            string[] classArrayValues = new string[] { "N", "N", "N", "N" };
            if (histories == null)
            {
                int transactionId = 0;

                if (supplier.SupplierWorkflows != null)
                {
                    foreach (SupplierWorkflow sw in supplier.SupplierWorkflows)
                    {
                        if (sw.WorkflowId == 2)
                            transactionId = sw.TransactionId;
                    }
                }
                if (transactionId == 0)
                    return classArrayValues;

                histories = WorkflowHistoryUtility.FindByCriteria(
                    ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                    WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                    new object[] { transactionId });
            }
            bool hasApproval = false;
            if (histories != null)
            {
                foreach (WorkflowHistory wf in histories)
                {
                    if (wf.CurrentNodeName == CertificationStatusType.DirectorApproved.Description)
                        hasApproval = true;
                }
            }
            bool pException = false;
            SupplierStatus certStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);
            if (certStatus != null)
            {
                if (certStatus.Status == CertificationStatusType.Certified.Description)
                    hasApproval = true;
                if (certStatus.Status == CertificationStatusType.CertAnalystClosed.Description ||
                    certStatus.Status == CertificationStatusType.CertClosed.Description ||
                    certStatus.Status == CertificationStatusType.Deny.Description ||
                    certStatus.Status == CertificationStatusType.Decertified.Description ||
                    certStatus.Status == CertificationStatusType.Disqualified.Description ||
                    certStatus.Status == CertificationStatusType.Withdrawn.Description ||
                    certStatus.Status == CertificationStatusType.Rescinded.Description ||
                    certStatus.Status == CertificationStatusType.Decertified.Description ||
                    certStatus.Status == CertificationStatusType.Expired.Description ||
                    certStatus.Status == CertificationStatusType.CertAdminClosed.Description)
                    pException = true;
            }

            string xml = "<ArrayOfDynamicProperty>";
            DynamicPropertyCollection types = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_OBJECT,
                new object[] { "SupplierStaticCertification", supplier.Id });
            if (types != null)
            {
                foreach (DynamicProperty property in types)
                {
                    xml += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"IsApplied\" />";
                    xml += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_c_dw_code\" />";
                }
            }
            xml += "</ArrayOfDynamicProperty>";

            DynamicPropertyCollection properties = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_PROPERTIES,
                new object[] { "SupplierStaticCertification", supplier.Id, xml });
            string approvalString = string.Empty;
            if (properties != null)
            {
                foreach (DynamicProperty property in properties)
                {
                    switch (property.PropertyName)
                    {
                        case "IsApplied":
                            if (property.PropertyText == "Y" && !pException)
                            {
                                switch (property.PropertyType)
                                {
                                    case "M":
                                        if (classArrayValues[0] != "Y")
                                            classArrayValues[0] = "P";
                                        break;
                                    case "W":
                                        if (classArrayValues[1] != "Y")
                                            classArrayValues[1] = "P";
                                        break;
                                    case "L":
                                        if (classArrayValues[2] != "Y")
                                            classArrayValues[2] = "P";
                                        break;
                                }
                            }
                            break;
                        case "V_c_dw_code":
                            if (hasApproval)
                            {
                                approvalString = property.PropertyText == "Y" || property.PropertyText == "R" ? "Y" : "N";
                                switch (property.PropertyType)
                                {
                                    case "M":
                                        classArrayValues[0] = approvalString;
                                        break;
                                    case "W":
                                        classArrayValues[1] = approvalString;
                                        break;
                                    case "L":
                                        classArrayValues[2] = approvalString;
                                        break;
                                }
                            }
                            break;
                    }
                }
            }
            classArrayValues[3] = hasApproval ? "Y" : "N";
            return classArrayValues;
        }

        public static string GetSupplierClassificationsString(Supplier supplier, WorkflowHistoryCollection histories)
        {
            string classifications = string.Empty;
            string[] classArrayValues = GetSupplierClassifications(supplier, histories);
            bool hasApproval = classArrayValues[ConstantUtility.CLASSIFICATION_ARRAY.Length] == "Y";
            for (int i = 0; i < classArrayValues.Length - 1; i++)
            {
                if (hasApproval && classArrayValues[i] == "P")
                    continue;
                if (classArrayValues[i] != "N")
                {
                    classifications += ConstantUtility.CLASSIFICATION_ARRAY[i];
                    if (classArrayValues[i] == "P")
                        classifications += " <font color='#1C3764'><b>(P)</b></font>";
                    classifications += ", ";
                }
            }
            if (classifications.Trim().Length > 0)
                classifications = classifications.Substring(0, classifications.Length - 2);

            return classifications;
        }


        public static bool LetterSent(Supplier supplier)
        {
            if (supplier == null) return false;
            bool qualLetterSent = false;
            bool certLetterSent = false;
            SupplierStatus qualStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_QUALIFICATION);
            SupplierStatus certStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);
            qualLetterSent = qualStatus != null && (qualStatus.Status == SupplierStatusType.RequestMoreInfo.Description || qualStatus.Status == SupplierStatusType.RequestMoreInfo2.Description);
            certLetterSent = certStatus != null && (certStatus.Status == CertificationStatusType.RequestMoreCertInfo.Description || certStatus.Status == CertificationStatusType.RequestMoreCertInfo2.Description);
            return (qualLetterSent || certLetterSent);
        }

        public static VendorContact GetPrimaryContactBySupplier(int supplierId)
        {
            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "Supplier", supplierId.ToString());
            if (vendor == null) return null;
            return GetPrimaryContact(vendor.Id);
        }

        public static VendorContact GetPrimaryContact(int vendorId)
        {
            return GetPrimaryContact(vendorId, null);
        }

        public static VendorContact GetPrimaryContact(int vendorId, VendorContactCollection vendorContacts)
        {
            if (vendorContacts == null)
            {
                vendorContacts = VendorContactUtility.FindByCriteria(
                    ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                    VendorContactManager.FIND_CONTACT_BY_VENDOR,
                    new object[] { vendorId });
            }
            VendorContact primaryContact = null;
            if (vendorContacts != null)
            {
                foreach (VendorContact contact in vendorContacts)
                {
                    if (contact.ContactType == "Primary")
                        primaryContact = contact;
                }
            }
            return primaryContact;
        }

        public static IEnumerable<ExternalContactType> GetExternalContactType()
        {
            string regxml = ReadFile(ConfigurationManager.AppSettings["LookupFolder"] + "ExternalContactType.xml");
            var _contacts = (ExternalContactTypeCollection)XmlUtility.Deserialize(regxml, typeof(ExternalContactTypeCollection));

            return _contacts.Cast<ExternalContactType>();
        }

        public static MenuCollection GetWizardMenu(string MenuName)
        {
            string regxml = ReadFile(ConfigurationManager.AppSettings["LookupFolder"] + MenuName);
            return (MenuCollection)XmlUtility.Deserialize(regxml, typeof(MenuCollection));
        }
        public static int GetMenuProgress(MenuCollection menus)
        {
            if (menus == null) return 0;
            int totalBar = menus.Count * 2 - 2;
            int completedBar = 0;
            foreach (Menu m in menus)
            {
                if (m.SubMenus.Count == 0)
                {
                    if (m.ImgLeft == "~/Images/icon-complete.gif")
                        completedBar += 2;
                    else if (m.ImgLeft == "~/Images/icon-pcomplete.gif")
                        completedBar++;
                    continue;
                }

                totalBar += (m.SubMenus.Count * 2);
                int knt = 0;
                foreach (Menu mm in m.SubMenus)
                {
                    if (mm.ImgLeft == "~/Images/icon-complete.gif")
                        knt += 2;
                    else if (mm.ImgLeft == "~/Images/icon-pcomplete.gif")
                        knt++;
                }
                completedBar += knt;

                if (m.SubMenus.Count > 0 && m.SubMenus.Count * 2 == knt)
                {
                    m.ImgLeft = "~/Images/icon-complete.gif";
                    completedBar += 2;
                }
                else if (knt > 0)
                {
                    m.ImgLeft = "~/Images/icon-pcomplete.gif";
                    completedBar++;
                }
            }
            return (int)(completedBar * 100 / totalBar);
        }
        public static string ContentToString(object o)
        {
            switch (o.GetType().FullName)
            {
                case "System.Int16":
                    if ((System.Int16)o == 0) return string.Empty;
                    break;
                case "System.Int32":
                    if ((System.Int32)o == 0) return string.Empty;
                    break;
                case "System.Int64":
                    if ((System.Int64)o == 0) return string.Empty;
                    break;
            }
            return o.ToString().Trim();
        }

        public static string GenerateUsername(Supplier supplier)
        {
            return "10000000".Substring(0, 10 - supplier.Id.ToString().Length) + supplier.Id.ToString();
        }

        public static string ReadFile(string filename)
        {
            StreamReader f = new StreamReader(filename);
            f.BaseStream.Seek(0, SeekOrigin.Begin);
            string s = f.ReadToEnd();
            f.Close();
            return s;
        }

        public static byte[] ReadFromFile(string filename)
        {
            FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read);
            byte[] MyData = new byte[fs.Length];
            fs.Read(MyData, 0, System.Convert.ToInt32(fs.Length));
            fs.Close();
            return MyData;
        }

        public static string GetXmlString(HttpPostedFile file)
        /* VERACODE scan vulnerability downstream from GetWorksheet.  None of the 4 callers to this func have been used in last 16 months; disabling for now   */
        {
            string xml = string.Empty;

            // Check to see if file was uploaded
            if (file == null) return xml;

            // Get size of uploaded file
            int nFileLen = file.ContentLength;
            string fileName = file.FileName;

            // make sure the size of the file is > 0
            if (nFileLen > 0)
            {
                // Disabled due to VERACODE vulnerability in GetWorksheet

                //fileName = Path.GetFileName(fileName);
                //string uploadDirectory = ConfigurationManager.AppSettings["UploadDirectory"];
                //file.SaveAs(uploadDirectory + fileName);
                //fileName = uploadDirectory + fileName;

                //ArrayList sheets = ExcelUtility.WorksheetNames(fileName);

                //DataSet itemDS = ExcelUtility.GetWorksheet(fileName, (string)sheets[0]);

                //xml = itemDS.GetXml();
            }
            return xml;
        }

        public static bool SameAddress(SupplierAddress address1, SupplierAddress address2)
        {
            if (address1 == null || address2 == null)
                return false;
            return (String.Compare(address1.AddressLine1, address2.AddressLine1, true) == 0 &&
                String.Compare(address1.AddressLine2, address2.AddressLine2, true) == 0 &&
                String.Compare(address1.City, address2.City, true) == 0 &&
                String.Compare(address1.State, address2.State, true) == 0 &&
                String.Compare(address1.ZipCode, address2.ZipCode, true) == 0 &&
                String.Compare(address1.Country, address2.Country, true) == 0);
        }


        /// <summary>
        /// Get settings from [LookupFolder]\{fileName.xml}". 
        /// </summary>
        public static SettingCollection GetSettings(string fileName)
        {
            string xmlFileName = ConfigurationManager.AppSettings["LookupFolder"] + fileName;
            string s = ReadFile(xmlFileName);
            return (SettingCollection)XmlUtility.Deserialize(s, typeof(SettingCollection));
        }

        public static int GetWizardProgess(string wizardType)
        {
            return 2;
        }

        public static string GetRfdCommentSection(string src)
        {
            string section = src;
            switch (src)
            {
                case "project_supplier":
                    src = "Reviewer Review";
                    break;
                case "workflow_cpo_approve":
                    src = "Chief Project Officer Review";
                    break;
                case "workflow_cpo_review":
                    src = "CPO Review Request";
                    break;
                case "workflow_director_review":
                    src = "Director Review";
                    break;
                case "workflow_generalcounsel_approve":
                    src = "General Counsel Review";
                    break;
                case "workflow_manager_question":
                    src = "Manager Review";
                    break;
                case "workflow_manager_review":
                    src = "Manager Review";
                    break;
                case "workflow_president_approve":
                    src = "President Review";
                    break;
                case "workflow_vp_review":
                    src = "VP of Capital Planning Review Request"; // was VPAdmin ("VP of Admin")
                    break;
                case "workflow_vpadmin_approve":
                    src = "VP of Capital Planning Review"; // was VPAdmin ("VP of Admin")
                    break;
                case "workflow_vpcm_review":
                    src = "VP of Construction Mgmt Review Request";
                    break;
                case "workflow_vpconstmgmt_approve":
                    src = "VP for Construction Mgmt Review";
                    break;
            }
            return src;
        }

        public static DateTime ParseDate(DateTime selectedDate, string time, string amPm)
        {
            DateTime myDate;
            if (selectedDate == DateTime.MinValue ||
                !DateTime.TryParse(selectedDate.ToShortDateString() + " " + time + " " + amPm, out myDate))
                return new DateTime(1900, 1, 1);

            return myDate;
        }

        public static bool UnZipFile(string InputPathOfZipFile)
        {
            bool ret = true;
            try
            {
                if (File.Exists(InputPathOfZipFile))
                {
                    string baseDirectory = Path.GetDirectoryName(InputPathOfZipFile);

                    using (ZipInputStream ZipStream = new ZipInputStream(File.OpenRead(InputPathOfZipFile)))
                    {
                        ZipEntry theEntry;
                        while ((theEntry = ZipStream.GetNextEntry()) != null)
                        {
                            if (theEntry.IsFile)
                            {
                                if (theEntry.Name != "")
                                {
                                    string strNewFile = @"" + baseDirectory + @"\" + theEntry.Name;
                                    if (File.Exists(strNewFile))
                                    {
                                        continue;
                                    }

                                    using (FileStream streamWriter = File.Create(strNewFile))
                                    {
                                        int size = 2048;
                                        byte[] data = new byte[2048];
                                        while (true)
                                        {
                                            size = ZipStream.Read(data, 0, data.Length);
                                            if (size > 0)
                                                streamWriter.Write(data, 0, size);
                                            else
                                                break;
                                        }
                                        streamWriter.Close();
                                    }
                                }
                            }
                            else if (theEntry.IsDirectory)
                            {
                                string strNewDirectory = @"" + baseDirectory + @"\" + theEntry.Name;
                                if (!Directory.Exists(strNewDirectory))
                                {
                                    Directory.CreateDirectory(strNewDirectory);
                                }
                            }
                        }
                        ZipStream.Close();
                    }
                }
            }
            catch
            {
                ret = false;
            }
            return ret;
        }

        #endregion

        #region Supplier Properties
        public static SupplierProperty CreateSupplierProperty(Control control, string value, Type type, Control parent, string changeUser)
        {
            SupplierProperty supplierProperty = CreateSupplierProperty(control, value, type, parent);
            supplierProperty.ChangeUser = changeUser;
            return supplierProperty;
        }

        public static SupplierProperty CreateSupplierProperty(Control control, string value, Type type, Control parent)
        {
            SupplierProperty supplierProperty = SupplierPropertyUtility.CreateObject();
            supplierProperty.PropertyId = ConvertUtility.ConvertInt(control.ID.Substring(8));
            if (parent != null) supplierProperty.ParentId = supplierProperty.PropertyId;
            switch (type.Name)
            {
                case "Int32":
                    supplierProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    supplierProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    supplierProperty.PropertyText = value;
                    break;
            }
            return supplierProperty;
        }

        public static SupplierProperty CreateSupplierProperty(int propertyId, string value)
        {
            SupplierProperty supplierProperty = CreateSupplierProperty(propertyId, value, typeof(String));
            return supplierProperty;
        }

        public static SupplierProperty CreateSupplierProperty(int propertyId, string value, Type type)
        {
            SupplierProperty supplierProperty = SupplierPropertyUtility.CreateObject();
            supplierProperty.PropertyId = propertyId;
            switch (type.Name)
            {
                case "Int32":
                    supplierProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    supplierProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    supplierProperty.PropertyText = value;
                    break;
            }
            return supplierProperty;
        }

        public static SupplierPropertyCollection AddSupplierProperty(Supplier supplier, SupplierProperty supplierProperty)
        {
            SupplierPropertyCollection supplierProperties = new SupplierPropertyCollection();
            supplierProperties.Add(supplierProperty);
            return AddSupplierProperty(supplier, supplierProperties);
        }

        public static SupplierPropertyCollection AddSupplierProperty(Supplier supplier, SupplierPropertyCollection supplierProperties)
        {
            if (supplier.SupplierProperties == null)
            {
                supplier.SupplierProperties = new SupplierPropertyCollection();
            }
            foreach (SupplierProperty sp in supplierProperties)
            {
                if (sp.ParentId == 0)
                {
                    bool isChange = false;
                    foreach (SupplierProperty sp1 in supplier.SupplierProperties)
                    {
                        if (sp1.PropertyId == sp.PropertyId)
                        {
                            sp1.PropertyValue = sp.PropertyValue;
                            sp1.PropertyText = sp.PropertyText;
                            sp1.PropertyDate = sp.PropertyDate;
                            isChange = true;
                        }
                    }
                    if (!isChange)
                        supplier.SupplierProperties.Add(sp);
                }
                else
                {
                    //Multi values
                    supplier.SupplierProperties.Add(sp);
                }
            }
            return supplier.SupplierProperties;
        }

        //TODO: find a good place to move this code. I would move it to SupplierUtilities.cs except that it requires System.Web in order to reference the Control object.
        public static void SetSupplierPropertyCurrentOtherwisePrior(RadioButtonList radioList, SupplierPropertyCollection supplierProperties, SupplierPropertyCollection priorSupplierProperties)
        {
            // If we have a current value, display that, otherwise display the prior value.
            radioList.SelectedIndex = radioList.Items.IndexOf(radioList.Items.FindByValue(CommonUtility.GetSupplierProperty(radioList, supplierProperties).PropertyText == "" ? (priorSupplierProperties == null ? "" : CommonUtility.GetSupplierProperty(radioList, priorSupplierProperties).PropertyText) : CommonUtility.GetSupplierProperty(radioList, supplierProperties).PropertyText));
        }

        public static void SetSupplierPropertyCurrentOtherwisePrior(System.Web.UI.WebControls.CheckBox checkbx, SupplierPropertyCollection supplierProperties, SupplierPropertyCollection priorSupplierProperties)
        {
            // If we have a current value, display that, otherwise display the prior value.
            checkbx.Checked = ConvertUtility.ConvertBool(CommonUtility.GetSupplierProperty(checkbx, supplierProperties).PropertyText == "" ? (priorSupplierProperties == null ? "0" : CommonUtility.GetSupplierProperty(checkbx, priorSupplierProperties).PropertyText) : CommonUtility.GetSupplierProperty(checkbx, supplierProperties).PropertyText);
        }
        public static void SetSupplierPropertyCurrentOtherwisePrior(CheckBoxList checkList, SupplierPropertyCollection supplierProperties, SupplierPropertyCollection priorSupplierProperties)
        {
            // If we have a current value, display that, otherwise display the prior value.
            bool itemChecked = false;
            foreach (SupplierProperty sp in CommonUtility.GetSupplierProperties(checkList, supplierProperties))
            {
                int index = checkList.Items.IndexOf(checkList.Items.FindByValue(sp.PropertyText));
                if (index >= 0 && index < checkList.Items.Count)
                {
                    checkList.Items[index].Selected = true;
                    itemChecked = true;
                }
            }
            if (priorSupplierProperties != null && !itemChecked)   //set prior values
            {
                foreach (SupplierProperty sp in CommonUtility.GetSupplierProperties(checkList, priorSupplierProperties))
                {
                    int index = checkList.Items.IndexOf(checkList.Items.FindByValue(sp.PropertyText));
                    if (index >= 0 && index < checkList.Items.Count)
                        checkList.Items[index].Selected = true;
                }
            }
        }
        public static void SetSupplierPropertyCurrentOtherwisePrior(DropDownList dropDownList, SupplierPropertyCollection supplierProperties, SupplierPropertyCollection priorSupplierProperties)
        {
            // If we have a current value, display that, otherwise display the prior value.
            dropDownList.SelectedIndex = dropDownList.Items.IndexOf(dropDownList.Items.FindByValue(CommonUtility.GetSupplierProperty(dropDownList, supplierProperties).PropertyText == "" ? (priorSupplierProperties == null ? "" : CommonUtility.GetSupplierProperty(dropDownList, priorSupplierProperties).PropertyText) : CommonUtility.GetSupplierProperty(dropDownList, supplierProperties).PropertyText));
        }
        public static void SetSupplierPropertyCurrentOtherwisePrior(TextBox textbx, SupplierPropertyCollection supplierProperties, SupplierPropertyCollection priorSupplierProperties, bool returnPropertyValueAsString = false)
        {
            // If we have a current value, display that, otherwise display the prior value.
            if (returnPropertyValueAsString)
                textbx.Text = CommonUtility.GetSupplierProperty(textbx, supplierProperties, true).PropertyValue.ToString() == "" ? (priorSupplierProperties == null ? "" : CommonUtility.GetSupplierProperty(textbx, priorSupplierProperties, true).PropertyValue.ToString()) : CommonUtility.GetSupplierProperty(textbx, supplierProperties,true).PropertyValue.ToString();
            else
                textbx.Text = CommonUtility.GetSupplierProperty(textbx, supplierProperties).PropertyText == "" ? (priorSupplierProperties == null ? "" : CommonUtility.GetSupplierProperty(textbx, priorSupplierProperties).PropertyText) : CommonUtility.GetSupplierProperty(textbx, supplierProperties).PropertyText;
        }
        public static void SetSupplierPropertyCurrentOtherwisePrior(HiddenField textbx, SupplierPropertyCollection supplierProperties, SupplierPropertyCollection priorSupplierProperties)
        {
            // If we have a current value, display that, otherwise display the prior value.
            textbx.Value = CommonUtility.GetSupplierProperty(textbx, supplierProperties).PropertyText == "" ? (priorSupplierProperties == null ? "" : CommonUtility.GetSupplierProperty(textbx, priorSupplierProperties).PropertyText) : CommonUtility.GetSupplierProperty(textbx, supplierProperties).PropertyText;
        }

        //TODO: move dataselector control to a common location so the below is recognized when called from both External and Internal projects.
        //public static void SetSupplierPropertyCurrentOtherwisePrior(DateSelector datectl, SupplierPropertyCollection supplierProperties, SupplierPropertyCollection priorSupplierProperties)
        //{
        //    // If we have a current value, display that, otherwise display the prior value.
        //    datectl.PropertyDate = CommonUtility.GetSupplierProperty(datectl, supplierProperties).PropertyDate== "" ? (priorSupplierProperties == null ? "" : CommonUtility.GetSupplierProperty(textbx, priorSupplierProperties).PropertyText) : CommonUtility.GetSupplierProperty(textbx, supplierProperties).PropertyText;
        //}

        public static SupplierProperty GetSupplierProperty(Control control, SupplierPropertyCollection supplierProperties, bool defaultPropertyValueToMinus1 = false)
        {
            foreach (SupplierProperty sp in supplierProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(control.ID.Substring(8)))
                    return sp;
            }
            SupplierProperty spNew = SupplierPropertyUtility.CreateObject();
            if (defaultPropertyValueToMinus1)
                spNew.PropertyValue = -1;
            return spNew;
        }
        public static SupplierProperty GetSupplierProperty(string propertyId, SupplierPropertyCollection supplierProperties, bool defaultPropertyValueToMinus1 = false)
        {
            foreach (SupplierProperty sp in supplierProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(propertyId.Substring(8)))
                    return sp;
            }
            SupplierProperty spNew = SupplierPropertyUtility.CreateObject();
            if (defaultPropertyValueToMinus1)
                spNew.PropertyValue = -1;
            return spNew;
        }
        public static SupplierPropertyCollection GetSupplierProperties(Control control, SupplierPropertyCollection supplierProperties)
        {
            SupplierPropertyCollection localSupplierProperties = new SupplierPropertyCollection();
            foreach (SupplierProperty sp in supplierProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(control.ID.Substring(8)))
                    localSupplierProperties.Add(sp);
            }
            return localSupplierProperties;
        }
        public static SupplierPropertyCollection GetSupplierProperties(string controlId, SupplierPropertyCollection supplierProperties)
        {
            SupplierPropertyCollection localSupplierProperties = new SupplierPropertyCollection();
            foreach (SupplierProperty sp in supplierProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(controlId.Substring(8)))
                    localSupplierProperties.Add(sp);
            }
            return localSupplierProperties;
        }
        #endregion

        #region Public Methods - SupplierCheckList
        public static SupplierCheckList CreateSupplierCheckList(int checkId, string checkType, int status, string statusType)
        {
            SupplierCheckList supplierCheckList = SupplierCheckListUtility.CreateObject();
            supplierCheckList.CheckListId = checkId;
            supplierCheckList.CheckListType = checkType;
            supplierCheckList.Status = status;
            supplierCheckList.StatusType = statusType;
            return supplierCheckList;
        }

        public static SupplierCheckListCollection AddSupplierCheckList(Supplier supplier, SupplierCheckList supplierCheckList)
        {
            SupplierCheckListCollection supplierCheckLists = new SupplierCheckListCollection();
            supplierCheckLists.Add(supplierCheckList);
            return AddSupplierCheckList(supplier, supplierCheckLists);
        }

        public static SupplierCheckListCollection AddSupplierCheckList(Supplier supplier, SupplierCheckListCollection supplierCheckLists)
        {
            supplier.SupplierCheckLists = SupplierCheckListUtility.FindByCriteria(
                 ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                 SupplierCheckListManager.FIND_CHECKLIST_BY_SUPPLIER,
                 new object[] { supplier.Id });
            if (supplier.SupplierCheckLists == null)
                supplier.SupplierCheckLists = new SupplierCheckListCollection();

            foreach (SupplierCheckList sp in supplierCheckLists)
            {
                bool isChange = false;
                foreach (SupplierCheckList sp1 in supplier.SupplierCheckLists)
                {
                    if (sp1.CheckListId == sp.CheckListId && sp1.CheckListType == sp.CheckListType && sp1.StatusType == sp.StatusType)
                    {
                        sp1.Status = sp.Status;
                        isChange = true;
                    }
                }
                if (!isChange)
                    supplier.SupplierCheckLists.Add(sp);
            }
            return supplier.SupplierCheckLists;
        }

        public static SupplierCheckList GetSupplierCheckList(int checkId, string checkType, string statusType, SupplierCheckListCollection supplierCheckLists)
        {
            if (supplierCheckLists != null)
            {
                foreach (SupplierCheckList sp in supplierCheckLists)
                {
                    if (sp.CheckListId == checkId && sp.CheckListType == checkType && sp.StatusType == statusType)
                        return sp;
                }
            }
            return SupplierCheckListUtility.CreateObject();
        }
        #endregion

        #region Change History
        public static bool SaveFieldChange(int objectId, string historyName, int changeType, string oldContent, string newContent, string userName)
        {
            if (oldContent.Trim() != string.Empty && oldContent.Trim() != "1/1/1900" && oldContent.Trim() != newContent.Trim())
            {
                ChangeHistory changeHistory = ChangeHistoryUtility.CreateObject();
                changeHistory.ChangeTypeId = changeType;
                changeHistory.ObjectId = objectId;
                changeHistory.HistoryName = historyName;
                changeHistory.OldContent = oldContent;
                changeHistory.NewContent = newContent;
                changeHistory.UserName = userName;
                changeHistory.ActionTime = DateTime.Now;
                ChangeHistoryUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, changeHistory);
                return true; //the content is different
            }
            return false; //the content is the same
        }

        public static bool SaveAllFieldChange(int objectId, string historyName, int changeType, string oldContent, string newContent, string userName)
        {
            if (oldContent.Trim() != newContent.Trim())
            {
                ChangeHistory changeHistory = ChangeHistoryUtility.CreateObject();
                changeHistory.ChangeTypeId = changeType;
                changeHistory.ObjectId = objectId;
                changeHistory.HistoryName = historyName;
                changeHistory.OldContent = oldContent;
                changeHistory.NewContent = newContent;
                changeHistory.UserName = userName;
                changeHistory.ActionTime = DateTime.Now;
                ChangeHistoryUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, changeHistory);
                return true; //the content is different
            }
            return false; //the content is the same
        }

        public static bool SaveFileChange(int objectId, string historyName, int changeType, string oldFilename, long oldFileId, long newFileId, string userName)
        {
            Boolean bFlag = false;
            if (oldFileId > 0 && newFileId > 0)
                bFlag = true;
            else if (oldFileId > 0 && newFileId > 0 && oldFileId != newFileId)
                bFlag = true;

            if (bFlag)
            {
                ChangeHistory changeHistory = ChangeHistoryUtility.CreateObject();
                changeHistory.ChangeTypeId = changeType;
                changeHistory.ObjectId = objectId;
                changeHistory.HistoryName = historyName;
                changeHistory.FileName = oldFilename;
                changeHistory.UserName = userName;
                changeHistory.ActionTime = DateTime.Now;

                changeHistory.DocumentImageId = oldFileId;
                //changeHistory.DocumentImage = oldFile;
                ChangeHistoryUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, changeHistory);
                return true; //the file is different
            }
            return false; //the file is the same
        }

        #endregion Change History

        #region	Public Methods - Email & Fax
        public static string GetEmailFolder()
        {
            return ConfigurationManager.AppSettings["Library"] + "Email\\";
        }

        public static string GetFaxFolder()
        {
            return ConfigurationManager.AppSettings["Library"] + "Fax\\";
        }

        public static string Replace(string originalString, object[] emailableObjs)
        {
            string siteUrlLink = "<a href=\"$SITEURL$\">$SITEURL$</a>";
            string siteCeSUrlLink = "<a href=\"$CESSITEURL$\">$CESSITEURL$</a>";
            string internalUrlLink = "<a href=\"$INTERNALSITEURL$\">$INTERNALSITEURL$</a>";

            string searchUrl = "$INTERNALSITEURL$/Supplier/Supplier_Search_Results.aspx?Id=$SUPPLIERID$";
            string searchUrlLink = "<a href=\"" + searchUrl + "\">" + searchUrl + "</a>";
            originalString = originalString.Replace("$SEARCHSUPPLIERLINK$", searchUrlLink);

            string commentUrl = "$INTERNALSITEURL$/Supplier/Workflow_Supplier_Comments.aspx?Id=$SUPPLIERID$";
            string commentUrlLink = "<a href=\"" + commentUrl + "\">" + commentUrl + "</a>";
            originalString = originalString.Replace("$SUPPLIERCOMMENTLINK$", commentUrlLink);

            string responseUrl = "$SITEURL$/Supplier/Supplier_More_Info.aspx?Id=$SUPPLIERID$";
            string responseUrlLink = "<a href=\"" + responseUrl + "\">" + responseUrl + "</a>";
            originalString = originalString.Replace("$LETTERRESPONSELINK$", responseUrlLink);

            if (emailableObjs != null)
            {
                for (int i = 0; i < emailableObjs.Length; i++)
                {
                    if (emailableObjs[i] != null)
                    {
                        if (emailableObjs[i] is Subcontractor)
                        {
                            Subcontractor subcontractor = (Subcontractor)emailableObjs[i];
                            originalString = originalString.Replace("$SUPPLIERCOMPANY$", subcontractor.Company);

                            string subcontractorUrl = "$INTERNALSITEURL$/Subcontractor/Subcontractor_List.aspx?isMentor=" + subcontractor.IsMentor + "&contractNo=" + subcontractor.ContractNo.Trim() +
                                "&solicitId=" + subcontractor.SolicitId.ToString();
                            string subcontractorUrlLink = "<a href=\"" + subcontractorUrl + "\">" + subcontractorUrl + "</a>";
                            originalString = originalString.Replace("$SUBCONTRACTORLISTLINK$", subcontractorUrlLink);

                        }
                        else if (emailableObjs[i] is RfdProject)
                        {
                            string managerReviewUrl = "$INTERNALSITEURL$/Rfd/Workflow_Manager_Question.aspx?Id=$RFDPROJECTID$";
                            string managerReviewUrlLink = "<a href=\"" + managerReviewUrl + "\">this link</a>";
                            originalString = originalString.Replace("$MANAGERREVIEWLIMITEDLISTLINK$", managerReviewUrlLink);

                            string directorReviewUrl = "$INTERNALSITEURL$/Rfd/Workflow_Director_Review.aspx?Id=$RFDPROJECTID$";
                            string directorReviewUrlLink = "<a href=\"" + directorReviewUrl + "\">this link</a>";
                            originalString = originalString.Replace("$DIRECTORREVIEWLIMITEDLISTLINK$", directorReviewUrlLink);

                            string vpAdminReviewUrl = "$INTERNALSITEURL$/Rfd/Workflow_VPAdmin_Approve.aspx?Id=$RFDPROJECTID$";
                            string vpAdminReviewUrlLink = "<a href=\"" + vpAdminReviewUrl + "\">this link</a>";
                            originalString = originalString.Replace("$VPADMINREVIEWLIMITEDLISTLINK$", vpAdminReviewUrlLink);

                            string cpoReviewUrl = "$INTERNALSITEURL$/Rfd/Workflow_CPO_Approve.aspx?Id=$RFDPROJECTID$";
                            string cpoReviewUrlLink = "<a href=\"" + cpoReviewUrl + "\">this link</a>";
                            originalString = originalString.Replace("$CPOREVIEWLIMITEDLISTLINK$", cpoReviewUrlLink);

                            string vpConstMgmtReviewUrl = "$INTERNALSITEURL$/Rfd/Workflow_VPConstMgmt_Approve.aspx?Id=$RFDPROJECTID$";
                            string vpConstMgmtReviewUrlLink = "<a href=\"" + vpConstMgmtReviewUrl + "\">this link</a>";
                            originalString = originalString.Replace("$VPCMREVIEWLIMITEDLISTLINK$", vpConstMgmtReviewUrlLink);

                            string generalCounselReviewUrl = "$INTERNALSITEURL$/Rfd/Workflow_GeneralCounsel_Approve.aspx?Id=$RFDPROJECTID$";
                            string generalCounselReviewUrlLink = "<a href=\"" + generalCounselReviewUrl + "\">this link</a>";
                            originalString = originalString.Replace("$GENERALCOUNSELREVIEWLIMITEDLISTLINK$", generalCounselReviewUrlLink);

                            string presidentReviewUrl = "$INTERNALSITEURL$/Rfd/Workflow_President_Approve.aspx?Id=$RFDPROJECTID$";
                            string presidentReviewUrlLink = "<a href=\"" + presidentReviewUrl + "\">this link</a>";
                            originalString = originalString.Replace("$PRESIDENTREVIEWLIMITEDLISTLINK$", presidentReviewUrlLink);
                        }
                        else if (emailableObjs[i] is Scorecard)
                        {
                            Scorecard scorecard = (Scorecard)emailableObjs[i];

                            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, scorecard.UserId);

                            if (user != null)
                            {
                                originalString = originalString.Replace("$EVALUATIONUSERNAME$", user.FullName);
                                originalString = originalString.Replace("$EVALUATIONEMAIL$", user.Email);
                            }
                            else
                            {
                                originalString = originalString.Replace("$EVALUATIONUSERNAME$", "");
                                originalString = originalString.Replace("$EVALUATIONEMAIL$", "");
                            }

                            //string csReviewUrl = "$INTERNALSITEURL$/Scorecard/scorecard_releasereview.aspx?Id=$SCORECARDID$";
                            //string csReviewUrlLink = "<a href=\"" + csReviewUrl + "\">this link</a>";
                            //originalString = originalString.Replace("$CSREVIEWEVALUATIONLINK$", csReviewUrlLink);

                            //string evaluationUrl = "$INTERNALSITEURL$/Scorecard/scorecard_scorecategory.aspx?Id=$SCORECARDID$&UserId=$USERID$";
                            //if (scorecard.Type == "Project")
                            //    evaluationUrl = "$INTERNALSITEURL$/Scorecard/Project_Comment.aspx?Id=$SCORECARDID$";
                            //else if (scorecard.Type == "Contract")
                            //    evaluationUrl = "$INTERNALSITEURL$/Scorecard/Contract_Comment.aspx?Id=$SCORECARDID$";
                            //string evaluationUrlLink = "<a href=\"" + evaluationUrl + "\">this link</a>";
                            //originalString = originalString.Replace("$EVALUATIONLINK$", evaluationUrlLink);

                            string vpaeUrl = "$INTERNALSITEURL$/Scorecard/scorecard_vpreview.aspx?Id=$SCORECARDID$";
                            if (scorecard.Type == "Project" || scorecard.Type == "Contract")
                                vpaeUrl = "$INTERNALSITEURL$/Scorecard/contract_vpreview.aspx?Id=$SCORECARDID$";
                            string vpaeUrlLink = "<a href=\"" + vpaeUrl + "\">this link</a>";
                            originalString = originalString.Replace("$VPAEREVIEWEVALUATIONLINK$", vpaeUrlLink);

                            string vpcmUrl = "$INTERNALSITEURL$/Scorecard/scorecard_vpcmreview.aspx?Id=$SCORECARDID$";
                            if (scorecard.Type == "Mentor A Contract")
                                vpcmUrl = "$INTERNALSITEURL$/Scorecard/contract_vpreview.aspx?Id=$SCORECARDID$";
                            string vpcmUrlLink = "<a href=\"" + vpcmUrl + "\">this link</a>";
                            originalString = originalString.Replace("$VPCMREVIEWEVALUATIONLINK$", vpcmUrlLink);

                            string legalUrl = "$INTERNALSITEURL$/Scorecard/scorecard_legalreview.aspx?Id=$SCORECARDID$";
                            if (scorecard.Type == "Project" || scorecard.Type == "Contract")
                                legalUrl = "$INTERNALSITEURL$/Scorecard/contract_legalreview.aspx?Id=$SCORECARDID$";
                            else if (scorecard.Type == "Mentor A Contract")
                                legalUrl = "$INTERNALSITEURL$/Scorecard/MentorContract_LegalReview.aspx?Id=$SCORECARDID$";
                            string legalUrlLink = "<a href=\"" + legalUrl + "\">this link</a>";
                            originalString = originalString.Replace("$LEGALREVIEWEVALUATIONLINK$", legalUrlLink);

                            string cquUrl = "$INTERNALSITEURL$/Scorecard/scorecard_cqureview.aspx?Id=$SCORECARDID$";
                            if (scorecard.Type == "Project" || scorecard.Type == "Contract")
                                cquUrl = "$INTERNALSITEURL$/Scorecard/contract_cqureview.aspx?Id=$SCORECARDID$";
                            else if (scorecard.Type == "Mentor A Contract")
                                legalUrl = "$INTERNALSITEURL$/Scorecard/MentorContract_CQUReview.aspx?Id=$SCORECARDID$";
                            string cquUrlLink = "<a href=\"" + cquUrl + "\">this link</a>";
                            originalString = originalString.Replace("$CQUREVIEWEVALUATIONLINK$", cquUrlLink);

                            string evalResponseUrl = "$SITEURL$/Scorecard/Scorecard_Results.aspx?Id=$SCORECARDID$";
                            if (scorecard.Type == "Project")
                                evalResponseUrl = "$SITEURL$/Scorecard/Project_Results.aspx?Id=$SCORECARDID$";
                            else if (scorecard.Type == "Contract")
                                evalResponseUrl = "$SITEURL$/Scorecard/Contract_Results.aspx?Id=$SCORECARDID$";
                            else if (scorecard.Type == "Mentor A Contract")
                                evalResponseUrl = "$SITEURL$/Scorecard/MentorContract_Results.aspx?Id=$SCORECARDID$";

                            string evalResponseUrlLink = "<a href=\"" + evalResponseUrl + "\">this link</a>";
                            originalString = originalString.Replace("$EVALUATIONRESPONSELINK$", evalResponseUrlLink);

                            string[] results = scorecard.Result.Split('|');
                            string rfp = "";
                            if (results.Length > 6)
                                rfp = results[6];

                            originalString = originalString.Replace("$RFPNUMBER$", rfp);
                        }
                        else if (emailableObjs[i] is ScorecardInvitee)
                        {
                            ScorecardInvitee scorecardInvitee = (ScorecardInvitee)emailableObjs[i];

                            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, scorecardInvitee.UserId);
                            User supervisor = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, scorecardInvitee.SupervisorId);

                            if (user != null)
                            {
                                originalString = originalString.Replace("$EVALUATORNAME$", user.FullName);
                                originalString = originalString.Replace("$EVALUATOREMAIL$", user.Email);
                            }
                            else
                            {
                                originalString = originalString.Replace("$EVALUATORNAME$", "");
                                originalString = originalString.Replace("$EVALUATOREMAIL$", "");
                            }

                            if (supervisor != null)
                            {
                                originalString = originalString.Replace("$EVALUATORSUPERVISORNAME$", supervisor.FullName);
                                originalString = originalString.Replace("$EVALUATORSUPERVISOREMAIL$", supervisor.Email);
                            } 
                            else
                            {
                                originalString = originalString.Replace("$EVALUATORSUPERVISORNAME$", "");
                                originalString = originalString.Replace("$EVALUATORSUPERVISOREMAIL$", "");
                            }
                        }
                        else if (emailableObjs[i] is Supplier)
                        {
                            Supplier supplier = (Supplier)emailableObjs[i];

                            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "Supplier", supplier.Id.ToString());
                            VendorContact primaryContact = vendor == null ? null : GetPrimaryContact(vendor.Id);

                            originalString = originalString.Replace("$VENDORPRIMARYCONTACTUSERNAME$", primaryContact == null ? "" : primaryContact.UserName);
                            originalString = originalString.Replace("$VENDORCONTACTNAME$", primaryContact == null ? "" : primaryContact.UserName);

                            originalString = originalString.Replace("$VENDORPRIMARYCONTACTEMAIL$", primaryContact == null ? "" : primaryContact.Email);

                            originalString = originalString.Replace("$VENDORCOMPANY$", vendor == null ? "" : vendor.Company);
                            string xml = "<ArrayOfDynamicProperty>";
                            xml += "<DynamicProperty PropertyName=\"V_SD_ADDL_SENT\" />";
                            xml += "<DynamicProperty PropertyName=\"V_SD_ADDL_SENT2\" />";
                            xml += "<DynamicProperty PropertyName=\"V_SD_PREQUAL_FROM\" />";
                            xml += "<DynamicProperty PropertyName=\"V_SD_PREQUAL_TO\" />";
                            xml += "</ArrayOfDynamicProperty>";
                            string qualApprovalDate = string.Empty;
                            string qualExpDate = string.Empty;
                            DynamicPropertyCollection properties = DynamicPropertyUtility.FindByCriteria(
                                ConstantUtility.USER_DATASOURCE_NAME,
                                DynamicPropertyManager.FIND_BY_PROPERTIES,
                                new object[] { "SupplierStaticQualification", supplier.Id, xml });
                            bool is1900 = false;
                            if (properties != null)
                            {
                                foreach (DynamicProperty prop in properties)
                                {
                                    is1900 = prop.PropertyDate == new DateTime(1900, 1, 1);
                                    switch (prop.PropertyName)
                                    {
                                        case "V_SD_PREQUAL_FROM":
                                            qualApprovalDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                                            break;
                                        case "V_SD_PREQUAL_TO":
                                            qualExpDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                                            break;
                                    }
                                }
                            }
                            originalString = originalString.Replace("$VENDORQUALIFIEDEXPDATE$", supplier == null ? "" : qualExpDate);
                        }
                        else if (emailableObjs[i] is InvitationForBidLimitedList)
                        {
                            InvitationForBidLimitedList supplier = emailableObjs[i] as InvitationForBidLimitedList;

                            if (!supplier.Email.Empty())
                            {
                                originalString = originalString.Replace("$FROMCONTRACTSPECIALISTEMAIL$", supplier.Email);
                                originalString = originalString.Replace("$VENDOR_EMAIL$", supplier.Email);
                                originalString = originalString.Replace("$VENDOR_NAME$", supplier.SupplierName);
                            }

                            if (!supplier.ProjectOfficer.Empty())
                                originalString = originalString.Replace("$TOPOEMAIL$", supplier.ProjectOfficer);

                            if (!supplier.ChiefProjectOfficer.Empty())
                                originalString = originalString.Replace("$TOCPOEMAIL$", supplier.ChiefProjectOfficer);
                        }
                        else if (emailableObjs[i] is User)
                        {
                            User user = emailableObjs[i] as User;

                            originalString = originalString.Replace("$TOVENDOREMAIL$", user?.Email);
                            originalString = originalString.Replace("$VENDOR_EMAIL$", user?.Email);
                            originalString = originalString.Replace("$VENDOR_NAME$", user?.Name);

                            originalString = originalString.Replace("$USERPIN$", user?.Pin);
                        }
                        else if (emailableObjs[i] is Project)
                        {
                            Project project = emailableObjs[i] as Project;

                            if (project.PreBidMeetingDateTime != null)
                                originalString = originalString.Replace("$PREBIDATE$", project.PreBidMeetingDateTime.ToString("MM/dd/yyyy HH:mm:ss"));
                            if (project.PreBidMeetingLoc != null)
                                originalString = originalString.Replace("$PREBIDADDRESS$", project.PreBidMeetingLoc);
                            if (project.Description != null)
                                originalString = originalString.Replace("$PROJECTDESCRIPTION$", project.Description);
                            if (project.PackageNo != null)
                                originalString = originalString.Replace("$PACKAGENO$", project.PackageNo);

                            //For Hardbid projects...
                            if (project.MultiContract)
                            {
                                if (project.JmNo != null)
                                    originalString = originalString.Replace("$JMNO$", project.JmNo);
                                if (project.JmType != null)
                                    originalString = originalString.Replace("$JMTYPE$", project.JmType);
                                //NTE AMT
                                originalString = originalString.Replace("$NTEAMT$", project.NteAmt.ToString("c"));
                                originalString = originalString.Replace("$MAXBIDDERS$", project.MaxContractToAward.ToString());
                                originalString = originalString.Replace("$LIQUIDDAMAGE$", project.LiquidDamage.ToString("c"));
                            }
                            //TODO:
                        }
                        else if (emailableObjs[i] is Bidder)
                        {
                            var bidder = emailableObjs[i] as Bidder;

                            //TODO:
                            originalString = originalString.Replace("$BIDDERCOMPANY$", bidder?.SupplierName ); //# SupplierName under Bidder is company name
                            originalString = originalString.Replace("$BIDAMOUNT$", bidder?.BidAmt.ToString());
                            originalString = originalString.Replace("$BIDRANK$", bidder?.Rank.ToString());
                        }
                        else if (emailableObjs[i] is BidderRejectCollection)
                        {
                            var rejectcodes = (emailableObjs[i] as BidderRejectCollection).Cast<BidderReject>().Select(r => r.RejectCode).JoinExt("^");
                            var settings = CommonUtility.GetSettings("RejectCodes.xml").Cast<Setting>();

                            var rejectDescs = settings.Where(s => s.Value.Contains(rejectcodes)).Select(r => r.Value).JoinExt(",");

                            originalString = originalString.Replace("$BIDDERREJECTDESCRIPTION$", rejectDescs);
                            originalString = originalString.Replace("$BIDDERREJECTDATE$", DateTime.Today.ToString("MMM, dd yyyy"));

                            var rejectcodesba = (emailableObjs[i] as BidderRejectCollection).Cast<BidderReject>().Select(r => r.RejectCode).ToList();
                            var rejectDescsba = settings.Where(s => rejectcodesba.Contains(s.Value)).Select(x => x.Name).JoinExt(",");
                            originalString = originalString.Replace("$BABIDDERREJECTDESCRIPTION$", rejectDescsba);

                            return originalString;
                        }
                    }
                }
            }

            originalString = originalString.Replace("$SITELINK$", siteUrlLink);
            originalString = originalString.Replace("$CESSITELINK$", siteCeSUrlLink);
            originalString = originalString.Replace("$INTERNALSITELINK$", internalUrlLink);

            originalString = EmailUtility.Replace(originalString, emailableObjs);

            return originalString;
        }

        public static void SendFax(int historyId, string fromName, string fromNumber,
            string toName, string toNumber, string toCompany, object[] attachments)
        {
            RFCOMAPILib.FaxServer rfFaxServer = new RFCOMAPILib.FaxServer();

            rfFaxServer.ServerName = ConfigurationManager.AppSettings["FaxServer"];
            rfFaxServer.Protocol = RFCOMAPILib.CommunicationProtocolType.cpTCPIP;
            rfFaxServer.UseNTAuthentication = RFCOMAPILib.BoolType.False;
            rfFaxServer.AuthorizationUserID = ConfigurationManager.AppSettings["FaxUserName"];
            rfFaxServer.AuthorizationUserPassword = ConfigurationManager.AppSettings["FaxPassword"];

            rfFaxServer.OpenServer();

            RFCOMAPILib.Fax rfFax = (RFCOMAPILib.Fax)rfFaxServer.get_CreateObject(RFCOMAPILib.CreateObjectType.coFax);
            rfFax.UniqueID = historyId.ToString();
            rfFax.FromName = fromName;
            rfFax.FromFaxNumber = fromNumber;
            rfFax.ToName = toName;
            rfFax.ToFaxNumber = "1" + toNumber;
            rfFax.ToCompany = toCompany;
            rfFax.HasCoversheet = RFCOMAPILib.BoolType.False;

            if (attachments != null)
            {
                for (int i = 0; i < attachments.Length; i++)
                {
                    if (attachments[i] != null)
                    {
                        rfFax.Attachments.Add(attachments[i], RFCOMAPILib.BoolType.True);
                    }
                }
            }

            rfFax.Send();

            /////////////// test Fax history ///////////////////////
            //FaxHistoryCollection faxHistories = FaxHistoryUtility.FindByCriteria(ConstantUtility.USER_DATASOURCE_NAME,
            //    FaxHistoryManager.FIND_FAXHISTORY_BY_RECEIVER, new object[] { 0, 0, "EventType", "ASC", 0, -2 });

            //RFCOMAPILib.Faxes faxes = rfFaxServer.get_Faxes(ConfigurationManager.AppSettings["FaxUserName"]);
            //foreach (RFCOMAPILib.Fax fax in faxes)
            //{
            //    if (fax.FaxStatus != RFCOMAPILib.FaxStatusType.fsDoneOK
            //        && fax.FaxStatus != RFCOMAPILib.FaxStatusType.fsDoneError)
            //        continue;
            //    bool updateFlag = false;
            //    foreach (FaxHistory faxHistory in faxHistories)
            //    {
            //        if (fax.UniqueID == faxHistory.Id.ToString())
            //        {
            //            faxHistory.Status = (int)fax.FaxStatus;
            //            faxHistory.ErrorCode = fax.FaxErrorCode.ToString();
            //            faxHistory.SentTime = fax.FaxRecordDateTime;
            //            FaxHistoryUtility.Update(ConstantUtility.USER_DATASOURCE_NAME, faxHistory);
            //            updateFlag = true;
            //        }
            //    }
            //    // clean right Fax
            //    if (updateFlag)
            //        fax.Delete();
            //}

            rfFaxServer.CloseServer();
        }

        public static void SendFax(EmailMessage emailmessage, Supplier supplier, int userId,
            object[] emailableObjs, string comments)
        {
            string fileName = GetFaxFolder() + emailmessage.Filename;
            if (!File.Exists(fileName)) return;

            string downloadFolder = GetDownloadFolder(userId);
            if (!Directory.Exists(downloadFolder))
            {
                Directory.CreateDirectory(downloadFolder);
            }

            string newFileName = downloadFolder + emailmessage.Filename;
            File.Copy(fileName, newFileName, true);

            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "Supplier", supplier.Id.ToString());
            VendorContact primaryContact = GetPrimaryContact(vendor.Id);
            WordDocUtility.Replace(newFileName,
                new object[] { supplier, primaryContact, supplier.PhysicalAddress });

            string fromFax = ConfigurationManager.AppSettings["CompanyFax"];

            FaxHistory faxHistory = FaxHistoryUtility.CreateObject();
            faxHistory.EventId = supplier.Id;
            faxHistory.EventType = "Supplier";
            faxHistory.FaxName = "Fax to Supplier";
            faxHistory.FromId = userId;
            faxHistory.FromFax = fromFax;
            faxHistory.Subject = Replace(emailmessage.Subject, emailableObjs);
            faxHistory.ToId = supplier.Id;
            faxHistory.ToFax = supplier.Fax;

            FaxHistoryUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, faxHistory);

            string uploadDirectory = GetFaxHistoryFullFolder(faxHistory.Id);

            FaxAttachmentCollection faxAttachments = new FaxAttachmentCollection();

            if (!Directory.Exists(uploadDirectory))
            {
                Directory.CreateDirectory(uploadDirectory);
            }

            File.Copy(newFileName, uploadDirectory + emailmessage.Filename, true);

            FaxAttachment faxAttachment = FaxAttachmentUtility.CreateObject();
            faxAttachment.Filename = emailmessage.Filename;
            faxAttachments.Add(faxAttachment);

            FaxAttachmentUtility.UpdateCollection(ConstantUtility.USER_DATASOURCE_NAME,
                faxHistory.Id, faxAttachments);

            SendFax(faxHistory.Id,
                ConfigurationManager.AppSettings["Company"],
                fromFax,
                primaryContact.Name,
                supplier.Fax,
                supplier.Company,
                new object[] { newFileName });
        }

        public static void SendFax(EmailMessage emailmessage, Supplier supplier, Project project, int userId,
            object[] emailableObjs, string comments)
        {
            string fileName = GetFaxFolder() + emailmessage.Filename;
            if (!File.Exists(fileName)) return;

            string downloadFolder = GetDownloadFolder(userId);
            if (!Directory.Exists(downloadFolder))
            {
                Directory.CreateDirectory(downloadFolder);
            }

            string newFileName = downloadFolder + emailmessage.Filename;
            File.Copy(fileName, newFileName, true);

            string fromFax = ConfigurationManager.AppSettings["CompanyFax"];


            string[] agencies = new string[] { "Dodge", "Brown", "CDSNews" };


            foreach (string agency in agencies)
            {
                FaxHistory faxHistory = FaxHistoryUtility.CreateObject();
                faxHistory.EventId = project.Id;
                faxHistory.EventType = "Project";
                faxHistory.FaxName = "Fax to Supplier";
                faxHistory.FromId = userId;
                faxHistory.FromFax = fromFax;
                faxHistory.Subject = Replace(emailmessage.Subject, emailableObjs);
                faxHistory.ToId = supplier.Id;
                string toFax = SettingUtility.GetValueByName(ConstantUtility.COMMON_DATASOURCE_NAME, agency);
                faxHistory.ToFax = toFax;
                FaxAttachmentCollection faxAttachments = new FaxAttachmentCollection();
                FaxAttachment faxAttachment = FaxAttachmentUtility.CreateObject();
                faxAttachment.Filename = emailmessage.Filename;
                faxAttachments.Add(faxAttachment);
                FaxHistoryUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, faxHistory);
                string uploadDirectory = GetFaxHistoryFullFolder(faxHistory.Id);
                if (!Directory.Exists(uploadDirectory))
                {
                    Directory.CreateDirectory(uploadDirectory);
                }
                File.Copy(newFileName, uploadDirectory + emailmessage.Filename, true);
                FaxAttachmentUtility.UpdateCollection(ConstantUtility.USER_DATASOURCE_NAME,
                    faxHistory.Id, faxAttachments);
                SendFax(faxHistory.Id,
                    ConfigurationManager.AppSettings["Company"],
                    fromFax,
                    "",
                    toFax,
                    "",
                    new object[] { newFileName });
            }

        }

        public static EmailHistory CreateEmailHistory(EmailMessage emailmessage,
            string eventType, int eventId, string fromType, int fromId, object[] objects)
        {
            EmailHistory emailHistory = EmailHistoryUtility.CreateObject();
            emailHistory.EventType = eventType;
            emailHistory.EventId = eventId;
            emailHistory.FromId = fromId;
            emailHistory.FromType = fromType;
            emailHistory.FromEmail = Replace(emailmessage.FromEmail, objects);
            emailHistory.CcEmail = Replace(emailmessage.CcEmail, objects);
            emailHistory.EmailName = emailmessage.Name;
            emailHistory.Subject = Replace(emailmessage.Subject, objects);
            EmailHistoryUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, emailHistory);

            return emailHistory;
        }

        public static void SendEmail(string emailName, object[] emailableObjs, string eventType, int eventId)
        {
            EmailMessage emailmessage = EmailMessageUtility.GetByName(ConstantUtility.COMMON_DATASOURCE_NAME,
                emailName);
            SendEmail(emailmessage, emailableObjs, eventType, eventId);
        }

        public static void SendEmail(string emailName, object[] emailableObjs, string mergeField, string eventType, int eventId)
        {
            EmailMessage emailmessage = EmailMessageUtility.GetByName(ConstantUtility.COMMON_DATASOURCE_NAME,
                emailName);
            emailmessage.Body = emailmessage.Body.Replace("$DYNAMICMESSAGE$", mergeField);
            SendEmail(emailmessage, emailableObjs, eventType, eventId);
        }

        public static void SendEmail(EmailMessage emailmessage, object[] emailableObjs, string eventType, int eventId)
        {
            if (emailmessage == null) return;

            int toId = 0;
            string toType = "";
            if (emailableObjs != null && emailableObjs.Length > 0)
            {
                if (emailableObjs[0] is Supplier)
                {
                    toType = "Contact";
                    if (((Supplier)emailableObjs[0]).PrimaryContact != null)
                    {
                        toId = ((Supplier)emailableObjs[0]).PrimaryContact.Id;
                    }
                }
                else if (emailableObjs[0] is VendorContact)
                {
                    toType = "Contact";
                    toId = ((VendorContact)emailableObjs[0]).Id;
                }
                else if (emailableObjs[0] is User)
                {
                    toType = "User";
                    toId = ((User)emailableObjs[0]).Id;
                }
            }

            string from = Replace(emailmessage.FromEmail, emailableObjs);
            string to = Replace(emailmessage.ToEmail, emailableObjs);
            string cc = Replace(emailmessage.CcEmail, emailableObjs);
            string subject = Replace(emailmessage.Subject, emailableObjs);
            string body = Replace(emailmessage.Body, emailableObjs);
            string bcc = Replace(emailmessage.BccEmail, emailableObjs);

            object[] attachments = null;
            if (!emailmessage.Filename.Empty())
            {
                try
                {
                    string _path = $"{CommonUtility.GetEmailFolder()}{emailmessage.Filename}";
                    Attachment attachedDoc = new Attachment(_path);
                    attachments = new object[] { attachedDoc };
                }
                finally { }
            }

            EmailHistory emailHistory = EmailHistoryUtility.CreateObject();
            emailHistory.EventType = eventType;
            emailHistory.EventId = eventId;
            emailHistory.FromType = "System";
            emailHistory.EmailName = emailmessage.Name;
            emailHistory.FromEmail = from;
            emailHistory.CcEmail = cc;
            emailHistory.Subject = subject;
            if (EmailHistoryUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, emailHistory))
            {
                EmailLog emailLog = EmailLogUtility.CreateObject();
                emailLog.EmailHistoryId = emailHistory.Id;
                emailLog.ToType = toType;
                emailLog.ToId = toId;
                emailLog.ToEmail = to;
                emailLog.Body = body;
                EmailLogUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, emailLog);
            }

            EmailUtility.Send(from, to, cc, "", subject, body, bcc, false, attachments, "", emailHistory.Id);

        }

        public static int SendEmail(int senderId, EmailMessage email, ValueObjectCollectionBase recipients, bool IsLogged)
        {
            int emailCount = 0;
            if (email == null || recipients == null) return emailCount;

            EmailHistory emailHistory = EmailHistoryUtility.CreateObject();
            emailHistory.FromType = "System";
            if (senderId > 0)
            {
                if (email.Type == "ScheduleJob")
                    emailHistory.EventId = senderId;
                else
                {
                    emailHistory.FromId = senderId;
                    emailHistory.FromType = "User";
                }
            }

            object emailObject = null;
            if (recipients.Count == 1)
                foreach (object o in recipients) emailObject = o;

            emailHistory.EventType = email.Type;
            emailHistory.EmailName = email.Name;
            emailHistory.FromEmail = Replace(email.FromEmail, new object[] { emailObject });
            emailHistory.CcEmail = Replace(email.CcEmail, new object[] { emailObject });
            emailHistory.Subject = Replace(email.Subject, new object[] { emailObject });
            string emailBody = Replace(email.Body, new object[] { emailObject });

            if (IsLogged)
                EmailHistoryUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, emailHistory);


            foreach (object emailableObj in recipients)
            {
                Vendor vendor = null;
                Supplier currentSupplier = null;
                EmailLog emailLog = EmailLogUtility.CreateObject();

                if (emailableObj is Supplier)
                {
                    emailLog.ToType = "Contact";

                    if (((Supplier)emailableObj).PrimaryContact != null)
                    {
                        emailLog.ToId = ((Supplier)emailableObj).PrimaryContact.Id;
                        emailLog.ToEmail = ((Supplier)emailableObj).PrimaryContact.Email;
                        email.ToName = ((Supplier)emailableObj).PrimaryContact.Name;
                    }

                    currentSupplier = ((Supplier)emailableObj);
                }
                else if (emailableObj is VendorContact)
                {
                    emailLog.ToType = "Contact";
                    emailLog.ToId = ((VendorContact)emailableObj).Id;
                    emailLog.ToEmail = ((VendorContact)emailableObj).Email;
                    email.ToName = ((VendorContact)emailableObj).Name;

                    vendor = VendorUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                        ((VendorContact)emailableObj).VendorId);
                    if (vendor != null)
                    {
                        currentSupplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                            vendor.CurrentSupplierId);
                    }
                }
                else if (emailableObj is User)
                {
                    emailLog.ToType = "User";
                    emailLog.ToId = ((User)emailableObj).Id;
                    emailLog.ToEmail = ((User)emailableObj).Email;
                    email.ToName = ((User)emailableObj).FullName;
                }

                string emailSubject = Replace(email.Subject, new object[] { emailableObj, vendor, currentSupplier });
                string body = string.Empty;
                if (emailableObj is User)
                {
                    User user = (User)emailableObj;
                    MembershipUser membershipUser = Membership.GetUser(user.UserName);
                    

                    user.Email = membershipUser.Email;
                    user.Password = membershipUser.GetPassword();

                    body = Replace(email.Body, new object[] { user });
                }
                else
                    body = Replace(email.Body, new object[] { emailableObj, vendor, currentSupplier });

                if (emailableObj is VendorContact)
                    body = EmailReplaceRelatedUsers(email, body, currentSupplier);

                EmailUtility.Send(emailHistory.FromEmail, email.FromName, emailLog.ToEmail, email.ToName, "", "", emailSubject, body, "", false, null, "", emailHistory.Id);

                if (IsLogged)
                {
                    emailLog.EmailHistoryId = emailHistory.Id;
                    emailLog.Body = body;
                    EmailLogUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, emailLog);
                }
                emailCount++;
            }
            if (emailHistory.CcEmail != string.Empty)
            {
                EmailUtility.Send(emailHistory.FromEmail, email.FromName, emailHistory.CcEmail, "", "", "", emailHistory.Subject, emailBody, "", false, null, "", emailHistory.Id);
                emailCount++;
            }
            return emailCount;
        }

        public static void SendEmail(EmailMessage emailmessage, object emailableObj,
            object[] emailableObjs, string comments, bool IsLogged, string eventType, int eventId)
        {
            //cert appeal case
            if (emailmessage.Name == "APPEAL_DECISION_LETTER" || emailmessage.Name == "CERT_NOTICE_LETTER" || emailmessage.Name == "CERT_DENY_NOTICE_LETTER")
            {
                int supplierId = ((Supplier)emailableObj).Id;
                if (emailmessage.Name == "APPEAL_DECISION_LETTER")
                {

                    SupplierDocumentCollection docCollection = SupplierDocumentUtility.FindByCriteria(
                    ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                    SupplierDocumentManager.FIND_SUPPLIERDOCUMENT_BY_SUPPLIER,
                    new object[] { supplierId });
                    SupplierDocumentCollection documentationCollection = new SupplierDocumentCollection();
                    SupplierDocumentCollection additionalDocsCollection = new SupplierDocumentCollection();
                    SupplierDocument supplierDocument = new SupplierDocument();
                    if (docCollection != null)
                    {
                        foreach (SupplierDocument sd in docCollection)
                        {
                            if (sd.Type.IndexOf("AppealDecisionLetter") >= 0)
                                supplierDocument = sd;
                            else if (ConvertUtility.ConvertInt(sd.Type) > 0)
                                additionalDocsCollection.Add(sd);
                        }
                    }

                    supplierDocument.Attachment = SupplierDocumentUtility.GetAttachment(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierDocument.Id);
                    if (supplierDocument.Attachment != null)
                    {
                        Attachment mailAttachment = new Attachment(new MemoryStream(supplierDocument.Attachment), supplierDocument.Filename);
                        object[] attachments = null;
                        attachments = new object[] { mailAttachment };
                        SendEmail(emailmessage, emailableObj, emailableObjs, comments, IsLogged, eventType, eventId, attachments);
                    }
                    
                }
                else if (emailmessage.Name == "CERT_NOTICE_LETTER" || emailmessage.Name == "CERT_DENY_NOTICE_LETTER")
                {
                    SupplierDocumentCollection docCollection = SupplierDocumentUtility.FindByCriteria(
                     ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                     SupplierDocumentManager.FIND_SUPPLIERDOCUMENT_BY_SUPPLIER,
                     new object[] { supplierId });
                    SupplierDocumentCollection documentationCollection = new SupplierDocumentCollection();
                    SupplierDocumentCollection additionalDocsCollection = new SupplierDocumentCollection();
                    SupplierDocument supplierDocument = new SupplierDocument();
                    if (docCollection != null)
                    {
                        foreach (SupplierDocument sd in docCollection)
                        {
                            if (sd.Type.IndexOf("CertDecisionLetter") >= 0)
                                supplierDocument = sd;
                            else if (ConvertUtility.ConvertInt(sd.Type) > 0)
                                additionalDocsCollection.Add(sd);
                        }
                    }

                    supplierDocument.Attachment = SupplierDocumentUtility.GetAttachment(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierDocument.Id);
                    if (supplierDocument.Attachment != null)
                    {
                        Attachment mailAttachment = new Attachment(new MemoryStream(supplierDocument.Attachment), supplierDocument.Filename);
                        object[] attachments = null;
                        attachments = new object[] { mailAttachment };                   
                        SendEmail(emailmessage, emailableObj, emailableObjs, comments, IsLogged, eventType, eventId, attachments);
                    }
                 
                }
            }           
            else        
            {
                SendEmail(emailmessage, emailableObj, emailableObjs, comments, IsLogged, eventType, eventId, null);
            }           
        }

        public static void SendEmail(EmailMessage emailmessage, object emailableObj,
            object[] emailableObjs, string comments, bool IsLogged, string eventType, int eventId, object[] attachments, bool addBccFromWebConfig = false)
        {
            if (emailmessage == null) return;

            string fromEmail = Replace(emailmessage.FromEmail, emailableObjs);
            string fromName = Replace(emailmessage.FromName, emailableObjs);
            string toEmail = Replace(emailmessage.ToEmail, emailableObjs);
            string toName = Replace(emailmessage.ToName, emailableObjs);
            string ccEmail = Replace(emailmessage.CcEmail, emailableObjs);
            string emailSubject = Replace(emailmessage.Subject, emailableObjs);

            EmailHistory emailHistory = EmailHistoryUtility.CreateObject();
            emailHistory.EventType = eventType;
            emailHistory.EventId = eventId;
            emailHistory.EmailName = emailmessage.Name;
            emailHistory.FromEmail = fromEmail;
            emailHistory.CcEmail = ccEmail;
            emailHistory.Subject = emailSubject;

            if (IsLogged)
                EmailHistoryUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, emailHistory);

            EmailLog emailLog = EmailLogUtility.CreateObject();
            emailLog.ToEmail = toEmail;
            if (emailableObj is Supplier)
            {
                emailLog.ToType = "Contact";
                if (((Supplier)emailableObj).PrimaryContact != null)
                {
                    emailLog.ToId = ((Supplier)emailableObj).PrimaryContact.Id;
                }
            }
            else if (emailableObj is VendorContact)
            {
                emailLog.ToType = "Contact";
                emailLog.ToId = ((VendorContact)emailableObj).Id;
            }
            else if (emailableObj is User)
            {
                emailLog.ToType = "User";
                emailLog.ToId = ((User)emailableObj).Id;
            }

            string body = Replace(emailmessage.Body, emailableObjs);
            body = body.Replace("$WFCOMMENTS$", comments);
            body = body.Replace("$WORKFLOWCOMMENTS$", comments);
            body = body.Replace("$DYNAMICMESSAGE$", comments);
            body = EmailDynamicContent.ReplaceDynamicContent(emailmessage, emailableObj, emailableObjs, body);
            EmailUtility.Send(fromEmail, fromName, toEmail, toName,
                ccEmail, "", emailSubject, body, emailmessage.BccEmail, false, attachments, "", emailHistory.Id);


            if (IsLogged)
            {
                emailLog.EmailHistoryId = emailHistory.Id;
                emailLog.Body = body;
                EmailLogUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, emailLog);
            }
        }

        public static EmailMessage EmailReplaceRelatedUsers(EmailMessage emailmessage, Supplier supplier)
        {
            if (emailmessage == null) return null;
            Hashtable RelatedUsers = EmailGetReplaceRelatedUsers(emailmessage, supplier);

            emailmessage.FromEmail = ReplaceRelatedUsers(emailmessage.FromEmail, RelatedUsers);
            emailmessage.ToEmail = ReplaceRelatedUsers(emailmessage.ToEmail, RelatedUsers);
            emailmessage.ToName = ReplaceRelatedUsers(emailmessage.ToName, RelatedUsers);
            emailmessage.CcEmail = ReplaceRelatedUsers(emailmessage.CcEmail, RelatedUsers);
            emailmessage.BccEmail = ReplaceRelatedUsers(emailmessage.BccEmail, RelatedUsers);
            emailmessage.Subject = ReplaceRelatedUsers(emailmessage.Subject, RelatedUsers);
            emailmessage.Body = ReplaceRelatedUsers(emailmessage.Body, RelatedUsers);

            return emailmessage;
        }


        public static EmailMessage EmailReplaceRelatedUsers(EmailMessage emailmessage, Supplier supplier, List<SupplierCategory> catList)
        {
            if (emailmessage == null) return null;
            Hashtable RelatedUsers = EmailGetReplaceRelatedUsers(emailmessage, supplier, catList);

            emailmessage.FromEmail = ReplaceRelatedUsers(emailmessage.FromEmail, RelatedUsers);
            emailmessage.ToEmail = ReplaceRelatedUsers(emailmessage.ToEmail, RelatedUsers);
            emailmessage.ToName = ReplaceRelatedUsers(emailmessage.ToName, RelatedUsers);
            emailmessage.CcEmail = ReplaceRelatedUsers(emailmessage.CcEmail, RelatedUsers);
            emailmessage.BccEmail = ReplaceRelatedUsers(emailmessage.BccEmail, RelatedUsers);
            emailmessage.Subject = ReplaceRelatedUsers(emailmessage.Subject, RelatedUsers);
            emailmessage.Body = ReplaceRelatedUsers(emailmessage.Body, RelatedUsers);

            return emailmessage;
        }


        /// <summary>
        /// TFS# 689 Mentor limited list vendor add notification email 
        /// Release 3.0
        /// </summary>
        /// <param name="emailmessage"></param>
        /// <param name="project"></param>
        /// <param name="supplierCollection"></param>
        /// <param name="comment"></param>
        /// <param name="user"></param>
        /// <returns> EmailMessage </returns>

        public static EmailMessage EmailReplaceRelatedUsers(EmailMessage emailmessage, RfdProject project, List<string> supplierCollection, string comment, User user)
        {
            if (emailmessage == null || project == null) return null;

            Hashtable RelatedUsers = new Hashtable();

            RelatedUsers.Add("$PROJECTLISTLINK$", "<a href=\"$INTERNALSITEURL$/Rfc/Project_List.aspx?Id=" + project.Id.ToString() + "\">$INTERNALSITEURL$/Rfc/Project_List.aspx?Id=" + project.Id.ToString() + "</a>");
            RelatedUsers.Add("$PROJECTVETTINGLISTLINK$", "<a href=\"$INTERNALSITEURL$/Rfc/Vetting_Request_List.aspx?Id=" + project.Id.ToString() + "\">$INTERNALSITEURL$/Rfc/Vetting_Request_List.aspx?Id=" + project.Id.ToString() + "</a>");

            RelatedUsers.Add("$SOLICITATIONNO$", project.SolicitationNo + "-" + project.SolicitSeq.ToString());
            RelatedUsers.Add("$PROJECTDESCRIPTION$", project.Description);
            RelatedUsers.Add("$PROJECTAMOUNT$", project.Amount.ToString());
            RelatedUsers.Add("$PROJECTChiefProjectOfficer$", project.ChiefProjectOfficer);
            RelatedUsers.Add("$PROJECTCHIEFPROJECTOFFICERNAME$", project.ChiefProjectOfficerName);
            RelatedUsers.Add("$PROJECTSOLICITATIONNO$", project.SolicitationNo);
            RelatedUsers.Add("$PROJECTPACKAGE$", project.Package);
            RelatedUsers.Add("$PROJECTTYPE$", project.ProjectType);
            RelatedUsers.Add("$PROJECTLLW$", project.Items[0].LLW.ToString());
            RelatedUsers.Add("$PROJECTSCHOOL$", project.Items[0].School);
            RelatedUsers.Add("$PROJECTSCHOOLADDRESS$", project.Items[0].SchoolAddress);
            RelatedUsers.Add("$PROJECTLLWDESC$", project.Items[0].LLWDesc);
            RelatedUsers.Add("$PROJECTADDEDBY$", user.FullName);
            RelatedUsers.Add("$PROJECTCOMMENT$", comment);

            string strsupplier;
            if (supplierCollection != null)
            {
                strsupplier = "<table border='0' cellpadding='3'>";

                foreach (var item in supplierCollection)
                {
                    strsupplier += "<tr><td>&nbsp;</td><td><b><li>";
                    strsupplier += item.ToString() + "</li></b></td></tr>";
                }

                if (strsupplier != "")
                    strsupplier += "</table>";
                RelatedUsers.Add("$DYNAMICMESSAGE$", strsupplier);
            }

            emailmessage.FromEmail = ReplaceRelatedUsers(emailmessage.FromEmail, RelatedUsers);
            emailmessage.ToEmail = ReplaceRelatedUsers(emailmessage.ToEmail, RelatedUsers);
            emailmessage.ToName = ReplaceRelatedUsers(emailmessage.ToName, RelatedUsers);
            emailmessage.CcEmail = ReplaceRelatedUsers(emailmessage.CcEmail, RelatedUsers);
            emailmessage.BccEmail = ReplaceRelatedUsers(emailmessage.BccEmail, RelatedUsers);
            emailmessage.Subject = ReplaceRelatedUsers(emailmessage.Subject, RelatedUsers);
            emailmessage.Body = ReplaceRelatedUsers(emailmessage.Body, RelatedUsers);
            return emailmessage;

        }



        public static string EmailReplaceRelatedUsers(EmailMessage emailmessage, string content, Supplier supplier)
        {
            if (emailmessage == null) return null;
            Hashtable RelatedUsers = EmailGetReplaceRelatedUsers(emailmessage, supplier);

            content = ReplaceRelatedUsers(content, RelatedUsers);
            return content;
        }

        public static Hashtable EmailGetReplaceRelatedUsers(EmailMessage emailmessage, Supplier supplier)
        {
            Hashtable RelatedUsers = new Hashtable();
            if (supplier.PhysicalAddress != null)
            {
                supplier.PhysicalAddress.AddressLine1 = supplier.PhysicalAddress.AddressLine1.Replace("|", " ");
                supplier.PhysicalAddress.AddressLine2 = supplier.PhysicalAddress.AddressLine2.Trim().Length == 0 ? "" : "#" + supplier.PhysicalAddress.AddressLine2;
            }
            RelatedUsers.Add("$FEDERALID$", supplier.FederalId);
            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "Supplier", supplier.Id.ToString());
            VendorContact primaryContact = vendor == null ? null : GetPrimaryContact(vendor.Id);
            RelatedUsers.Add("$VENDORPRIMARYCONTACTUSERNAME$", primaryContact == null ? "" : primaryContact.UserName);
            RelatedUsers.Add("$VENDORCONTACTUSERNAME$", primaryContact == null ? "" : primaryContact.UserName);
            RelatedUsers.Add("$VENDORPRIMARYCONTACTEMAIL$", primaryContact == null ? "" : primaryContact.Email);
            RelatedUsers.Add("$VENDOR_EMAIL$", primaryContact == null ? "" : primaryContact.Email);
            RelatedUsers.Add("$VENDOR_NAME$", primaryContact == null ? "" : primaryContact.Name);
            RelatedUsers.Add("$VENDORCOMPANY$", vendor == null ? "" : vendor.Company);


            string appType = "";
            if (supplier.IsBoth())
                appType = "Qualification and Certification";
            else if (supplier.IsCert())
                appType = "Certification";
            else if (supplier.IsQual())
                appType = "Qualification";

            RelatedUsers.Add("$APPLICATIONTYPE$", appType);
            RelatedUsers.Add("$CQUDIVISION$", (appType.IndexOf("Qualification") < 0) ? "" : "Pre-qualification Division");
            RelatedUsers.Add("$BDDDIVISION$", (appType.IndexOf("Certification") < 0) ? "" : "Business Development Division");

            string certType = "";
            foreach (SupplierProperty sp in GetSupplierProperties("property519", supplier.SupplierProperties))
            {
                if (sp.PropertyText == "MBE" || sp.PropertyText == "WBE" || sp.PropertyText == "LBE")
                    certType += sp.PropertyText + "/";
            }
            if (certType != "")
                certType = certType.Substring(0, certType.Length - 1);
            RelatedUsers.Add("$CERTTYPE$", certType);

            SupplierStatus qualStatus = null;
            SupplierStatus certStatus = null;
            if (supplier.SupplierStatuses != null)
            {
                qualStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_QUALIFICATION);
                certStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);
            }
            bool isQualified = false;
            bool isCertified = false;
            string qualType = "";
            if (qualStatus != null && qualStatus.Status == SupplierStatusType.Qualified.Description)
                isQualified = true;
            if (certStatus != null && certStatus.Status == CertificationStatusType.Certified.Description)
                isCertified = true;
            if (isQualified && isCertified)
                qualType = "Qualified/Certified";
            else
            {
                if (isQualified)
                    qualType = "Qualified";
                if (isCertified)
                    qualType = "Certified";
            }
            RelatedUsers.Add("$QUALIFIEDTYPE$", qualType);

            string qualificationType = "qualification";
            if ((supplier.Status & 1) == 1 || (supplier.Status & 2) == 2)
                qualificationType = "requalification";
            RelatedUsers.Add("$QUALIFICATIONTYPE$", qualificationType);

            RelatedUsers.Add("$OIGDECISION$", GetSupplierProperty("property508", supplier.SupplierProperties).PropertyText);
            RelatedUsers.Add("$OIGCOMMENTS$", GetSupplierProperty("property515", supplier.SupplierProperties).PropertyText);

            User analyst = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, GetSupplierProperty("property524", supplier.SupplierProperties).PropertyText);
            RelatedUsers.Add("$BDDANALYST$", (analyst == null) ? "" : analyst.FullName);
            RelatedUsers.Add("$BDDANALYSTNAME$", (analyst == null) ? "" : analyst.FullName);
            RelatedUsers.Add("$BDDANALYSTPHONE$", (analyst == null) ? "" : analyst.Phone);
            RelatedUsers.Add("$BDDANALYSTEMAIL$", (analyst == null) ? "" : analyst.Email);
            RelatedUsers.Add("$BDDANALYSTTITLE$", (analyst == null) ? "" : analyst.Title);

            User manager = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, GetSupplierProperty("property521", supplier.SupplierProperties).PropertyText);
            RelatedUsers.Add("$CQUMANAGER$", (manager == null) ? "" : manager.FullName);
            RelatedUsers.Add("$CQUMANAGERNAME$", (manager == null) ? "" : manager.FullName);
            RelatedUsers.Add("$CQUMANAGERPHONE$", (manager == null) ? "" : manager.Phone);
            RelatedUsers.Add("$CQUMANAGEREMAIL$", (manager == null) ? "" : manager.Email);
            RelatedUsers.Add("$CQUMANAGERTITLE$", (manager == null) ? "" : manager.Title);

            User reviewer = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, GetSupplierProperty("property10", supplier.SupplierProperties).PropertyText);
            RelatedUsers.Add("$CQUREVIEWER$", (reviewer == null) ? "" : reviewer.FullName);
            RelatedUsers.Add("$CQUREVIEWERNAME$", (reviewer == null) ? "" : reviewer.FullName);
            RelatedUsers.Add("$CQUREVIEWERPHONE$", (reviewer == null) ? "" : reviewer.Phone);
            RelatedUsers.Add("$CQUREVIEWEREMAIL$", (reviewer == null) ? "" : reviewer.Email);
            RelatedUsers.Add("$CQUREVIEWERTITLE$", (reviewer == null) ? "" : reviewer.Title);

            
                LookupCollection lookups = LookupUtility.GetByType(ConstantUtility.COMMON_DATASOURCE_NAME, "BDDsupervisorEmail");
                if (lookups != null && lookups.Count > 0)
                {
                    foreach (Lookup lookup in lookups)
                    {
                    if (!RelatedUsers.Contains("$BDDSUPERVISOREMAIL$"))
                        RelatedUsers.Add("$BDDSUPERVISOREMAIL$", (lookup == null) ? "" : lookup.Value);
                    }
                }
            else
                RelatedUsers.Add("$BDDSUPERVISOREMAIL$", "");
                  
            if (certStatus != null)
            {
                lookups = LookupUtility.GetByType(ConstantUtility.COMMON_DATASOURCE_NAME, "BDDSupervisorName");
                foreach (Lookup lookup in lookups)
                {
                    if(!RelatedUsers.Contains("$BDDSUPERVISORNAME$"))
                    RelatedUsers.Add("$BDDSUPERVISORNAME$", (lookup == null) ? "" : lookup.Value);               
                }
            }
            else
            {                
                RelatedUsers.Add("$BDDSUPERVISORNAME$", "");
            }          
            string letterContact = "";
            if (appType.IndexOf("Qualification") >= 0 && reviewer != null)
                letterContact = reviewer.FullName + " at " + reviewer.Phone + " for prequalification related questions";
            if (appType.IndexOf("Certification") >= 0 && analyst != null)
                letterContact += letterContact == "" ? analyst.FullName + " at " + analyst.Phone + " for certification related questions" : " and for certification questions " + analyst.FullName + " at " + analyst.Phone;
            RelatedUsers.Add("$LETTERCONTACTINFO$", letterContact);

            SupplierPersonnel majorityOwner = null;
            SupplierPersonnelCollection keypeople = SupplierPersonnelUtility.FindByCriteria(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
            SupplierPersonnelManager.FIND_SUPPLIERPERSONNEL, new object[] { supplier.Id, "Y" });
            string strKeyperson = "";
            if (keypeople != null)
            {
                strKeyperson = "<table border='0' cellpadding='3'>";
                foreach (SupplierPersonnel sp in keypeople)
                {
                    if (sp.IsOwner == "Y")
                    {
                        if (majorityOwner == null || sp.OwnedPercentage > majorityOwner.OwnedPercentage)
                            majorityOwner = sp;
                    }

                    if (sp.IsKeyPerson == "Y" && sp.OIGReviewed == 2)
                    {
                        strKeyperson += "<tr><td>&nbsp;</td><td><b><li>";
                        strKeyperson += sp.Name.Replace("|", " ") + "</li></b></td></tr>";
                    }
                }
                if (strKeyperson != "")
                    strKeyperson += "</table>";
                RelatedUsers.Add("$DYNAMICMESSAGE$", strKeyperson);
            }
            if (majorityOwner != null)
                RelatedUsers.Add("$MAJORITYOWNER$", (majorityOwner == null) ? "" : majorityOwner.Name.Replace("|", " "));

            string qualifiedTrades = "";
            string millionTrades = "";
            if (supplier.SupplierCategories != null)
            {
                foreach (SupplierCategory sc in supplier.SupplierCategories)
                {
                    if (sc.IsApproved == "Y")
                    {
                        qualifiedTrades += "(" + sc.Category.Code + ") " + sc.CategoryName + "; ";
                        if (sc.ApprovedAverage == "under")
                            millionTrades += "(" + sc.Category.Code + ") " + sc.CategoryName + "; ";
                    }
                }
                if (qualifiedTrades.Trim().Length > 0)
                    qualifiedTrades = qualifiedTrades.Substring(0, qualifiedTrades.Length - 2);
                if (millionTrades.Trim().Length > 0)
                    millionTrades = millionTrades.Substring(0, millionTrades.Length - 2);
            }
            RelatedUsers.Add("$QUALIFIEDTRADES$", qualifiedTrades);
            RelatedUsers.Add("$1MQUALIFIEDTRADES$", millionTrades);

            int transactionId = 0;
            int certTransactionId = 0;
            string dateSubmitted = "";
            string qualExpDate = "";
            string certExpDate = "";
            string sixtyDayDate = "";
            string thirtyDayDate = "";
            string qualTenDayDate = "";
            string certTenDayDate = "";
            string closureDate = "";
            if (emailmessage != null)
            {
                if (emailmessage.Name == "30DAY_LETTER_NOTICE")
                    closureDate = DateTime.Now.AddDays(30).ToShortDateString();
                else if (emailmessage.Name.IndexOf("10DAY_LETTER_NOTICE") == 0)
                    closureDate = DateTime.Now.AddDays(10).ToShortDateString();
            }
            if (supplier.SupplierWorkflows != null)
            {
                foreach (SupplierWorkflow sw in supplier.SupplierWorkflows)
                {
                    if (sw.WorkflowId == 1)
                        transactionId = sw.TransactionId;
                    if (sw.WorkflowId == 2)
                        certTransactionId = sw.TransactionId;
                }
            }
            WorkflowHistoryCollection tempHistories = WorkflowHistoryUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                new object[] { transactionId });
            User qualDirector = null;
            string qualApprovalDate = "";
            if (tempHistories != null)
            {
                foreach (WorkflowHistory wf in tempHistories)
                {
                    if (wf.CurrentNodeName == SupplierStatusType.ApplicationSubmitted.Description)
                        dateSubmitted = wf.DateCreated.ToShortDateString();
                    if (wf.CurrentNodeName == SupplierStatusType.Qualified.Description)
                    {
                        sixtyDayDate = (wf.DateCreated.AddYears(3)).AddDays(-60).ToShortDateString();
                        qualDirector = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, wf.CreatedBy);
                    }
                }
            }
            WorkflowHistoryCollection certTempHistories = WorkflowHistoryUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                new object[] { certTransactionId });
            User director = null;
            string certApprovalDate = "";
            if (certTempHistories != null)
            {
                foreach (WorkflowHistory wf2 in certTempHistories)
                {
                    if (wf2.CurrentNodeName == CertificationStatusType.DirectorApproved.Description)
                        director = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, wf2.CreatedBy);
                }
            }

            string xml = "<ArrayOfDynamicProperty>";
            xml += "<DynamicProperty PropertyName=\"V_SD_ADDL_SENT\" />";
            xml += "<DynamicProperty PropertyName=\"V_SD_ADDL_SENT2\" />";
            xml += "<DynamicProperty PropertyName=\"V_SD_PREQUAL_FROM\" />";
            xml += "<DynamicProperty PropertyName=\"V_SD_PREQUAL_TO\" />";
            xml += "</ArrayOfDynamicProperty>";

            DynamicPropertyCollection properties = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_PROPERTIES,
                new object[] { "SupplierStaticQualification", supplier.Id, xml });
            bool is1900 = false;
            if (properties != null)
            {
                foreach (DynamicProperty prop in properties)
                {
                    is1900 = prop.PropertyDate == new DateTime(1900, 1, 1);
                    switch (prop.PropertyName)
                    {
                        case "V_SD_ADDL_SENT":
                            thirtyDayDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                            break;
                        case "V_SD_ADDL_SENT2":
                            qualTenDayDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                            break;
                        case "V_SD_PREQUAL_FROM":
                            qualApprovalDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                            break;
                        case "V_SD_PREQUAL_TO":
                            qualExpDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                            break;
                    }
                }
            }

            string xml2 = "<ArrayOfDynamicProperty>";
            DynamicPropertyCollection types = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_OBJECT,
                new object[] { "SupplierStaticCertification", supplier.Id });
            if (types != null)
            {
                foreach (DynamicProperty property in types)
                {
                    xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_INFO_LETTER_SENT_1\" />";
                    xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_INFO_LETTER_SENT_2\" />";
                    xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_CERT_DATE\" />";
                    xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_EXP_DATE\" />";
                }
            }
            xml2 += "</ArrayOfDynamicProperty>";

            DynamicPropertyCollection properties2 = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_PROPERTIES,
                new object[] { "SupplierStaticCertification", supplier.Id, xml2 });
            if (properties2 != null)
            {
                foreach (DynamicProperty prop2 in properties2)
                {
                    if (prop2.PropertyDate != new DateTime(1900, 1, 1))
                    {
                        switch (prop2.PropertyName)
                        {
                            case "V_SD_INFO_LETTER_SENT_1":
                                thirtyDayDate = prop2.PropertyDate.ToShortDateString();
                                break;
                            case "V_SD_INFO_LETTER_SENT_2":
                                certTenDayDate = prop2.PropertyDate.ToShortDateString();
                                break;
                            case "V_SD_CERT_DATE":
                                certApprovalDate = prop2.PropertyDate.ToShortDateString();
                                break;
                            case "V_SD_EXP_DATE":
                                certExpDate = prop2.PropertyDate.ToShortDateString();
                                break;
                        }
                    }
                }
            }

            string approvalDate = qualApprovalDate;
            if (approvalDate == "")
                approvalDate = certApprovalDate;
            else if (certApprovalDate != "")
                approvalDate += " (Qualification) & " + certApprovalDate + " (Certification)";
            RelatedUsers.Add("$APPROVALDATE$", approvalDate);

            RelatedUsers.Add("$DATERECEIVED$", dateSubmitted);

            string expDate = qualExpDate;
            if (expDate == "")
                expDate = certExpDate;
            else if (certExpDate != "")
                expDate += " (Qualification) & " + certExpDate + " (Certification)";
            RelatedUsers.Add("$APPEXPIRATIONDATE$", expDate);
            RelatedUsers.Add("$QUALEXPIRATIONDATE$", qualExpDate);
            RelatedUsers.Add("$CERTEXPIRATIONDATE$", certExpDate);
            RelatedUsers.Add("$60DAYDATE$", sixtyDayDate);

            string infoRequested = thirtyDayDate;
            if (qualTenDayDate != "" || certTenDayDate != "")
            {
                if (qualTenDayDate != "")
                {
                    infoRequested = qualTenDayDate;
                    if (certTenDayDate != "")
                        infoRequested += " (Qualification) & " + certTenDayDate + " (Certification)";
                }
                else
                    infoRequested = certTenDayDate;
            }
            RelatedUsers.Add("$DATEADDITIONALINFOREQUESTED$", infoRequested);
            RelatedUsers.Add("$DATE30DAYSENT$", thirtyDayDate);
            RelatedUsers.Add("$FINALCLOSUREDATE$", closureDate);

            string correspondenceNote = "";
            SupplierDocument supplierDocument = SupplierDocumentUtility.GetByType(
                ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplier.Id, "OigApproveLetter");
            if (supplierDocument != null && supplierDocument.Filename.Trim().Length > 0)
                correspondenceNote = "Correspondence has been uploaded.";
            RelatedUsers.Add("$CORRESPONDENCENOTE$", correspondenceNote);

            DateTime twodays = DateTime.Now.AddDays(2);
            while (twodays.DayOfWeek == DayOfWeek.Saturday || twodays.DayOfWeek == DayOfWeek.Sunday)
                twodays = twodays.AddDays(1);
            RelatedUsers.Add("$2BUSINESSDAYSFROMDATEASSIGNED$", twodays.ToShortDateString());

            RelatedUsers.Add("$BDDDIRECTOR$", (director == null) ? "" : director.FullName);
            RelatedUsers.Add("$BDDDIRECTORNAME$", (director == null) ? "" : director.FullName);
            RelatedUsers.Add("$BDDDIRECTORPHONE$", (director == null) ? "" : director.Phone);
            RelatedUsers.Add("$BDDDIRECTOREMAIL$", (director == null) ? "" : director.Email);
            RelatedUsers.Add("$BDDDIRECTORTITLE$", (director == null) ? "" : director.Title);
            RelatedUsers.Add("$BDDMANAGER$", (director == null) ? "" : director.FullName);
            RelatedUsers.Add("$BDDMANAGERNAME$", (director == null) ? "" : director.FullName);
            RelatedUsers.Add("$BDDMANAGERPHONE$", (director == null) ? "" : director.Phone);
            RelatedUsers.Add("$BDDMANAGEREMAIL$", (director == null) ? "" : director.Email);
            RelatedUsers.Add("$BDDMANAGERTITLE$", (director == null) ? "" : director.Title);
            RelatedUsers.Add("$CQUDIRECTOR$", (qualDirector == null) ? "" : qualDirector.FullName);
            RelatedUsers.Add("$CQUDIRECTORNAME$", (qualDirector == null) ? "" : qualDirector.FullName);
            RelatedUsers.Add("$CQUDIRECTORPHONE$", (qualDirector == null) ? "" : qualDirector.Phone);
            RelatedUsers.Add("$CQUDIRECTOREMAIL$", (qualDirector == null) ? "" : qualDirector.Email);
            RelatedUsers.Add("$CQUDIRECTORTITLE$", (qualDirector == null) ? "" : qualDirector.Title);

            SupplierCommentCollection supplierComments = SupplierCommentUtility.FindByCriteria(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                SupplierCommentManager.FIND_SUPPLIERCOMMENT, new object[] { 0, 0, "", "", supplier.Id, "External" });
            string commentString = "";
            if (supplierComments != null)
            {
                foreach (SupplierComment comment in supplierComments)
                {
                    if (comment.Submitted != "Y")
                    {
                        if (commentString == "")
                            commentString = "<table border='1' cellpadding='3'>";
                        commentString += "<tr><td><b>";
                        string section = "";
                        string filelink = comment.FileLink;
                        string type = "";
                        if (comment.FileLink.IndexOf("|") >= 0)
                        {
                            string[] filelinkArray = comment.FileLink.Split('|');
                            if (filelinkArray.Length > 0)
                                filelink = filelinkArray[0];
                            if (filelinkArray.Length > 1)
                                type = filelinkArray[1];
                        }
                        MenuCollection menus = GetRegistrationMenus(supplier, type);
                        GetCurrentMenu(menus, ConvertUtility.ConvertInt(filelink));
                        if (currentStep != null)
                        {
                            if (currentStep.Text.IndexOf("Section") >= 0)
                            {
                                foreach (SCA.VAS.ValueObjects.User.Menu menu in menus)
                                    if (menu.Id == currentStep.ParentId)
                                        section += menu.Text + ": ";
                            }
                            section += currentStep.Text;
                        }
                        commentString += section + "</b></td><td>" + comment.Comments + "</td></tr>";
                    }
                }
            }
            if (commentString != "")
                commentString += "</table>";
            RelatedUsers.Add("$DYNAMICMISSINGINFO$", commentString);

            return RelatedUsers;
        }

        
        public static Hashtable EmailGetReplaceRelatedUsers(EmailMessage emailmessage, Supplier supplier, List<SupplierCategory> catList)
        {
            Hashtable RelatedUsers = new Hashtable();
            if (supplier.PhysicalAddress != null)
            {
                supplier.PhysicalAddress.AddressLine1 = supplier.PhysicalAddress.AddressLine1.Replace("|", " ");
                supplier.PhysicalAddress.AddressLine2 = supplier.PhysicalAddress.AddressLine2.Trim().Length == 0 ? "" : "#" + supplier.PhysicalAddress.AddressLine2;
            }
            RelatedUsers.Add("$FEDERALID$", supplier.FederalId);
            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "Supplier", supplier.Id.ToString());
            VendorContact primaryContact = vendor == null ? null : GetPrimaryContact(vendor.Id);
            RelatedUsers.Add("$VENDORPRIMARYCONTACTUSERNAME$", primaryContact == null ? "" : primaryContact.UserName);
            RelatedUsers.Add("$VENDORCONTACTUSERNAME$", primaryContact == null ? "" : primaryContact.UserName);
            RelatedUsers.Add("$VENDORPRIMARYCONTACTEMAIL$", primaryContact == null ? "" : primaryContact.Email);
            RelatedUsers.Add("$VENDORCOMPANY$", vendor == null ? "" : vendor.Company);



            string appType = "";
            if (supplier.IsBoth())
                appType = "Qualification and Certification";
            else if (supplier.IsCert())
                appType = "Certification";
            else if (supplier.IsQual())
                appType = "Qualification";

            RelatedUsers.Add("$APPLICATIONTYPE$", appType);
            RelatedUsers.Add("$CQUDIVISION$", (appType.IndexOf("Qualification") < 0) ? "" : "Pre-qualification Division");
            RelatedUsers.Add("$BDDDIVISION$", (appType.IndexOf("Certification") < 0) ? "" : "Business Development Division");

            string certType = "";
            foreach (SupplierProperty sp in GetSupplierProperties("property519", supplier.SupplierProperties))
            {
                if (sp.PropertyText == "MBE" || sp.PropertyText == "WBE" || sp.PropertyText == "LBE")
                    certType += sp.PropertyText + "/";
            }
            if (certType != "")
                certType = certType.Substring(0, certType.Length - 1);
            RelatedUsers.Add("$CERTTYPE$", certType);

            SupplierStatus qualStatus = null;
            SupplierStatus certStatus = null;
            if (supplier.SupplierStatuses != null)
            {
                qualStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_QUALIFICATION);
                certStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);
            }
            bool isQualified = false;
            bool isCertified = false;
            string qualType = "";
            if (qualStatus != null && qualStatus.Status == SupplierStatusType.Qualified.Description)
                isQualified = true;
            if (certStatus != null && certStatus.Status == CertificationStatusType.Certified.Description)
                isCertified = true;
            if (isQualified && isCertified)
                qualType = "Qualified/Certified";
            else
            {
                if (isQualified)
                    qualType = "Qualified";
                if (isCertified)
                    qualType = "Certified";
            }
            RelatedUsers.Add("$QUALIFIEDTYPE$", qualType);

            string qualificationType = "qualification";
            if ((supplier.Status & 1) == 1 || (supplier.Status & 2) == 2)
                qualificationType = "requalification";
            RelatedUsers.Add("$QUALIFICATIONTYPE$", qualificationType);

            RelatedUsers.Add("$OIGDECISION$", GetSupplierProperty("property508", supplier.SupplierProperties).PropertyText);
            RelatedUsers.Add("$OIGCOMMENTS$", GetSupplierProperty("property515", supplier.SupplierProperties).PropertyText);

            User analyst = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, GetSupplierProperty("property524", supplier.SupplierProperties).PropertyText);
            RelatedUsers.Add("$BDDANALYST$", (analyst == null) ? "" : analyst.FullName);
            RelatedUsers.Add("$BDDANALYSTNAME$", (analyst == null) ? "" : analyst.FullName);
            RelatedUsers.Add("$BDDANALYSTPHONE$", (analyst == null) ? "" : analyst.Phone);
            RelatedUsers.Add("$BDDANALYSTEMAIL$", (analyst == null) ? "" : analyst.Email);
            RelatedUsers.Add("$BDDANALYSTTITLE$", (analyst == null) ? "" : analyst.Title);

            User manager = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, GetSupplierProperty("property521", supplier.SupplierProperties).PropertyText);
            RelatedUsers.Add("$CQUMANAGER$", (manager == null) ? "" : manager.FullName);
            RelatedUsers.Add("$CQUMANAGERNAME$", (manager == null) ? "" : manager.FullName);
            RelatedUsers.Add("$CQUMANAGERPHONE$", (manager == null) ? "" : manager.Phone);
            RelatedUsers.Add("$CQUMANAGEREMAIL$", (manager == null) ? "" : manager.Email);
            RelatedUsers.Add("$CQUMANAGERTITLE$", (manager == null) ? "" : manager.Title);

            User reviewer = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, GetSupplierProperty("property10", supplier.SupplierProperties).PropertyText);
            RelatedUsers.Add("$CQUREVIEWER$", (reviewer == null) ? "" : reviewer.FullName);
            RelatedUsers.Add("$CQUREVIEWERNAME$", (reviewer == null) ? "" : reviewer.FullName);
            RelatedUsers.Add("$CQUREVIEWERPHONE$", (reviewer == null) ? "" : reviewer.Phone);
            RelatedUsers.Add("$CQUREVIEWEREMAIL$", (reviewer == null) ? "" : reviewer.Email);
            RelatedUsers.Add("$CQUREVIEWERTITLE$", (reviewer == null) ? "" : reviewer.Title);

            if (certStatus != null)
            {
                LookupCollection lookups = LookupUtility.GetByType(ConstantUtility.COMMON_DATASOURCE_NAME, "BDDsupervisorEmail");
                if (lookups != null && lookups.Count > 0)
                {
                foreach (Lookup lookup in lookups)
                {
                        if (!RelatedUsers.Contains("$BDDSUPERVISOREMAIL$"))
                    RelatedUsers.Add("$BDDSUPERVISOREMAIL$", (lookup == null) ? "" : lookup.Value); 
                }
                }
                else
                    RelatedUsers.Add("$BDDSUPERVISOREMAIL$", "");

                if (certStatus != null)
                {
                lookups = LookupUtility.GetByType(ConstantUtility.COMMON_DATASOURCE_NAME, "BDDSupervisorName");
                foreach (Lookup lookup in lookups)
                {
                        if (!RelatedUsers.Contains("$BDDSUPERVISORNAME$"))
                    RelatedUsers.Add("$BDDSUPERVISORNAME$", (lookup == null) ? "" : lookup.Value);
                }
            }
            else
            {
                    RelatedUsers.Add("$BDDSUPERVISORNAME$", "");
                }
            }
            else
            {
                RelatedUsers.Add("$BDDSUPERVISOREMAIL$", "");
                RelatedUsers.Add("$BDDSUPERVISORNAME$", "");
            }

            string letterContact = "";
            if (appType.IndexOf("Qualification") >= 0 && reviewer != null)
                letterContact = reviewer.FullName + " at " + reviewer.Phone + " for prequalification related questions";
            if (appType.IndexOf("Certification") >= 0 && analyst != null)
                letterContact += letterContact == "" ? analyst.FullName + " at " + analyst.Phone + " for certification related questions" : " and for certification questions " + analyst.FullName + " at " + analyst.Phone;
            RelatedUsers.Add("$LETTERCONTACTINFO$", letterContact);

            SupplierPersonnel majorityOwner = null;
            SupplierPersonnelCollection keypeople = SupplierPersonnelUtility.FindByCriteria(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
            SupplierPersonnelManager.FIND_SUPPLIERPERSONNEL, new object[] { supplier.Id, "Y" });
            string strKeyperson = "";
            if (keypeople != null)
            {
                strKeyperson = "<table border='0' cellpadding='3'>";
                foreach (SupplierPersonnel sp in keypeople)
                {
                    if (sp.IsOwner == "Y")
                    {
                        if (majorityOwner == null || sp.OwnedPercentage > majorityOwner.OwnedPercentage)
                            majorityOwner = sp;
                    }

                    if (sp.IsKeyPerson == "Y" && sp.OIGReviewed == 2)
                    {
                        strKeyperson += "<tr><td>&nbsp;</td><td><b><li>";
                        strKeyperson += sp.Name.Replace("|", " ") + "</li></b></td></tr>";
                    }
                }
                if (strKeyperson != "")
                    strKeyperson += "</table>";
                RelatedUsers.Add("$DYNAMICMESSAGE$", strKeyperson);
            }
            if (majorityOwner != null)
                RelatedUsers.Add("$MAJORITYOWNER$", (majorityOwner == null) ? "" : majorityOwner.Name.Replace("|", " "));

            string qualifiedTrades = "";
            string millionTrades = "";
            if (supplier.SupplierCategories != null)
            {
                foreach (SupplierCategory sc in supplier.SupplierCategories)
                {
                    if (sc.IsApproved == "Y")
                    {
                        qualifiedTrades += "(" + sc.Category.Code + ") " + sc.CategoryName + "; ";
                        if (sc.ApprovedAverage == "under")
                            millionTrades += "(" + sc.Category.Code + ") " + sc.CategoryName + "; ";
                    }
                }
                if (qualifiedTrades.Trim().Length > 0)
                    qualifiedTrades = qualifiedTrades.Substring(0, qualifiedTrades.Length - 2);
                if (millionTrades.Trim().Length > 0)
                    millionTrades = millionTrades.Substring(0, millionTrades.Length - 2);
            }
            RelatedUsers.Add("$QUALIFIEDTRADES$", qualifiedTrades);
            RelatedUsers.Add("$1MQUALIFIEDTRADES$", millionTrades);

            int transactionId = 0;
            int certTransactionId = 0;
            string dateSubmitted = "";
            string qualExpDate = "";
            string certExpDate = "";
            string sixtyDayDate = "";
            string thirtyDayDate = "";
            string qualTenDayDate = "";
            string certTenDayDate = "";
            string closureDate = "";
            if (emailmessage != null)
            {
                if (emailmessage.Name == "30DAY_LETTER_NOTICE")
                    closureDate = DateTime.Now.AddDays(30).ToShortDateString();
                else if (emailmessage.Name.IndexOf("10DAY_LETTER_NOTICE") == 0)
                    closureDate = DateTime.Now.AddDays(10).ToShortDateString();
            }
            if (supplier.SupplierWorkflows != null)
            {
                foreach (SupplierWorkflow sw in supplier.SupplierWorkflows)
                {
                    if (sw.WorkflowId == 1)
                        transactionId = sw.TransactionId;
                    if (sw.WorkflowId == 2)
                        certTransactionId = sw.TransactionId;
                }
            }
            WorkflowHistoryCollection tempHistories = WorkflowHistoryUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                new object[] { transactionId });
            User qualDirector = null;
            string qualApprovalDate = "";
            if (tempHistories != null)
            {
                foreach (WorkflowHistory wf in tempHistories)
                {
                    if (wf.CurrentNodeName == SupplierStatusType.ApplicationSubmitted.Description)
                        dateSubmitted = wf.DateCreated.ToShortDateString();
                    if (wf.CurrentNodeName == SupplierStatusType.Qualified.Description)
                    {
                        sixtyDayDate = (wf.DateCreated.AddYears(3)).AddDays(-60).ToShortDateString();
                        qualDirector = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, wf.CreatedBy);
                    }
                }
            }
            WorkflowHistoryCollection certTempHistories = WorkflowHistoryUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                new object[] { certTransactionId });
            User director = null;
            string certApprovalDate = "";
            if (certTempHistories != null)
            {
                foreach (WorkflowHistory wf2 in certTempHistories)
                {
                    if (wf2.CurrentNodeName == CertificationStatusType.DirectorApproved.Description)
                        director = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, wf2.CreatedBy);
                }
            }

            string xml = "<ArrayOfDynamicProperty>";
            xml += "<DynamicProperty PropertyName=\"V_SD_ADDL_SENT\" />";
            xml += "<DynamicProperty PropertyName=\"V_SD_ADDL_SENT2\" />";
            xml += "<DynamicProperty PropertyName=\"V_SD_PREQUAL_FROM\" />";
            xml += "<DynamicProperty PropertyName=\"V_SD_PREQUAL_TO\" />";
            xml += "</ArrayOfDynamicProperty>";

            DynamicPropertyCollection properties = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_PROPERTIES,
                new object[] { "SupplierStaticQualification", supplier.Id, xml });
            bool is1900 = false;
            if (properties != null)
            {
                foreach (DynamicProperty prop in properties)
                {
                    is1900 = prop.PropertyDate == new DateTime(1900, 1, 1);
                    switch (prop.PropertyName)
                    {
                        case "V_SD_ADDL_SENT":
                            thirtyDayDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                            break;
                        case "V_SD_ADDL_SENT2":
                            qualTenDayDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                            break;
                        case "V_SD_PREQUAL_FROM":
                            qualApprovalDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                            break;
                        case "V_SD_PREQUAL_TO":
                            qualExpDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                            break;
                    }
                }
            }

            string xml2 = "<ArrayOfDynamicProperty>";
            DynamicPropertyCollection types = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_OBJECT,
                new object[] { "SupplierStaticCertification", supplier.Id });
            if (types != null)
            {
                foreach (DynamicProperty property in types)
                {
                    xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_INFO_LETTER_SENT_1\" />";
                    xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_INFO_LETTER_SENT_2\" />";
                    xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_CERT_DATE\" />";
                    xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_EXP_DATE\" />";
                }
            }
            xml2 += "</ArrayOfDynamicProperty>";

            DynamicPropertyCollection properties2 = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_PROPERTIES,
                new object[] { "SupplierStaticCertification", supplier.Id, xml2 });
            if (properties2 != null)
            {
                foreach (DynamicProperty prop2 in properties2)
                {
                    if (prop2.PropertyDate != new DateTime(1900, 1, 1))
                    {
                        switch (prop2.PropertyName)
                        {
                            case "V_SD_INFO_LETTER_SENT_1":
                                thirtyDayDate = prop2.PropertyDate.ToShortDateString();
                                break;
                            case "V_SD_INFO_LETTER_SENT_2":
                                certTenDayDate = prop2.PropertyDate.ToShortDateString();
                                break;
                            case "V_SD_CERT_DATE":
                                certApprovalDate = prop2.PropertyDate.ToShortDateString();
                                break;
                            case "V_SD_EXP_DATE":
                                certExpDate = prop2.PropertyDate.ToShortDateString();
                                break;
                        }
                    }
                }
            }

            string approvalDate = qualApprovalDate;
            if (approvalDate == "")
                approvalDate = certApprovalDate;
            else if (certApprovalDate != "")
                approvalDate += " (Qualification) & " + certApprovalDate + " (Certification)";
            RelatedUsers.Add("$APPROVALDATE$", approvalDate);

            RelatedUsers.Add("$DATERECEIVED$", dateSubmitted);

            string expDate = qualExpDate;
            if (expDate == "")
                expDate = certExpDate;
            else if (certExpDate != "")
                expDate += " (Qualification) & " + certExpDate + " (Certification)";
            RelatedUsers.Add("$APPEXPIRATIONDATE$", expDate);
            RelatedUsers.Add("$QUALEXPIRATIONDATE$", qualExpDate);
            RelatedUsers.Add("$CERTEXPIRATIONDATE$", certExpDate);
            RelatedUsers.Add("$60DAYDATE$", sixtyDayDate);

            string infoRequested = thirtyDayDate;
            if (qualTenDayDate != "" || certTenDayDate != "")
            {
                if (qualTenDayDate != "")
                {
                    infoRequested = qualTenDayDate;
                    if (certTenDayDate != "")
                        infoRequested += " (Qualification) & " + certTenDayDate + " (Certification)";
                }
                else
                    infoRequested = certTenDayDate;
            }
            RelatedUsers.Add("$DATEADDITIONALINFOREQUESTED$", infoRequested);
            RelatedUsers.Add("$DATE30DAYSENT$", thirtyDayDate);
            RelatedUsers.Add("$FINALCLOSUREDATE$", closureDate);

            string correspondenceNote = "";
            SupplierDocument supplierDocument = SupplierDocumentUtility.GetByType(
                ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplier.Id, "OigApproveLetter");
            if (supplierDocument != null && supplierDocument.Filename.Trim().Length > 0)
                correspondenceNote = "Correspondence has been uploaded.";
            RelatedUsers.Add("$CORRESPONDENCENOTE$", correspondenceNote);

            DateTime twodays = DateTime.Now.AddDays(2);
            while (twodays.DayOfWeek == DayOfWeek.Saturday || twodays.DayOfWeek == DayOfWeek.Sunday)
                twodays = twodays.AddDays(1);
            RelatedUsers.Add("$2BUSINESSDAYSFROMDATEASSIGNED$", twodays.ToShortDateString());

            RelatedUsers.Add("$BDDDIRECTOR$", (director == null) ? "" : director.FullName);
            RelatedUsers.Add("$BDDDIRECTORNAME$", (director == null) ? "" : director.FullName);
            RelatedUsers.Add("$BDDDIRECTORPHONE$", (director == null) ? "" : director.Phone);
            RelatedUsers.Add("$BDDDIRECTOREMAIL$", (director == null) ? "" : director.Email);
            RelatedUsers.Add("$BDDDIRECTORTITLE$", (director == null) ? "" : director.Title);
            RelatedUsers.Add("$BDDMANAGER$", (director == null) ? "" : director.FullName);
            RelatedUsers.Add("$BDDMANAGERNAME$", (director == null) ? "" : director.FullName);
            RelatedUsers.Add("$BDDMANAGERPHONE$", (director == null) ? "" : director.Phone);
            RelatedUsers.Add("$BDDMANAGEREMAIL$", (director == null) ? "" : director.Email);
            RelatedUsers.Add("$BDDMANAGERTITLE$", (director == null) ? "" : director.Title);
            RelatedUsers.Add("$CQUDIRECTOR$", (qualDirector == null) ? "" : qualDirector.FullName);
            RelatedUsers.Add("$CQUDIRECTORNAME$", (qualDirector == null) ? "" : qualDirector.FullName);
            RelatedUsers.Add("$CQUDIRECTORPHONE$", (qualDirector == null) ? "" : qualDirector.Phone);
            RelatedUsers.Add("$CQUDIRECTOREMAIL$", (qualDirector == null) ? "" : qualDirector.Email);
            RelatedUsers.Add("$CQUDIRECTORTITLE$", (qualDirector == null) ? "" : qualDirector.Title);

            SupplierCommentCollection supplierComments = SupplierCommentUtility.FindByCriteria(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                SupplierCommentManager.FIND_SUPPLIERCOMMENT, new object[] { 0, 0, "", "", supplier.Id, "External" });
            string commentString = "";
            if (supplierComments != null)
            {
                foreach (SupplierComment comment in supplierComments)
                {
                    if (comment.Submitted != "Y")
                    {
                        if (commentString == "")
                            commentString = "<table border='1' cellpadding='3'>";
                        commentString += "<tr><td><b>";
                        string section = "";
                        string filelink = comment.FileLink;
                        string type = "";
                        if (comment.FileLink.IndexOf("|") >= 0)
                        {
                            string[] filelinkArray = comment.FileLink.Split('|');
                            if (filelinkArray.Length > 0)
                                filelink = filelinkArray[0];
                            if (filelinkArray.Length > 1)
                                type = filelinkArray[1];
                        }
                        MenuCollection menus = GetRegistrationMenus(supplier, type);
                        GetCurrentMenu(menus, ConvertUtility.ConvertInt(filelink));
                        if (currentStep != null)
                        {
                            if (currentStep.Text.IndexOf("Section") >= 0)
                            {
                                foreach (SCA.VAS.ValueObjects.User.Menu menu in menus)
                                    if (menu.Id == currentStep.ParentId)
                                        section += menu.Text + ": ";
                            }
                            section += currentStep.Text;
                        }
                        commentString += section + "</b></td><td>" + comment.Comments + "</td></tr>";
                    }
                }
            }
            if (commentString != "")
                commentString += "</table>";
            RelatedUsers.Add("$DYNAMICMISSINGINFO$", commentString);

            /*Trade code added and removed*/



            List<SupplierCategory> catListRemoved = new List<SupplierCategory>();
            List<SupplierCategory> catListAdded = new List<SupplierCategory>();
            foreach (SupplierCategory item in catList)
            {
                catListRemoved.Add(item);
            }
            foreach (SupplierCategory sc in supplier.SupplierCategories)
            {
                catListAdded.Add(sc);
            }



            //Added trad coded
            foreach (SupplierCategory scold in catList)
            {
                foreach (SupplierCategory sc in supplier.SupplierCategories)
                {
                    if (scold.CategoryId == sc.CategoryId)
                    {
                        catListAdded.RemoveAll(c => c.CategoryId == scold.CategoryId);
                        break;
                    }
                }
            }

            //Removed trad code
            foreach (SupplierCategory sc in supplier.SupplierCategories)
            {
                foreach (SupplierCategory scold in catList)
                {
                    if (sc.CategoryId == scold.CategoryId)
                    {
                        catListRemoved.RemoveAll(c => c.CategoryId == sc.CategoryId);
                        break;
                    }

                }
            }

            string strTradeCodeAdded = "";
            string strTradeCodeRemove = "";

            if (catListAdded.Count != 0)
            {
                strTradeCodeAdded = "<table border='0' cellpadding='3'> <tr><th>Added trade code </th></tr>";

                foreach (SupplierCategory sc in catListAdded)
                {
                    strTradeCodeAdded += "<tr><td>&nbsp;</td><td><b><li>";
                    strTradeCodeAdded += sc.Category.Name + " (" + sc.Category.Code + ")" + "</li></b></td></tr>";
                }
                if (strTradeCodeAdded != "")
                    strTradeCodeAdded += "</table>";
            }

            

            if (catListRemoved.Count != 0)
            {
                strTradeCodeRemove = "<table border='0' cellpadding='3'> <tr><th>Removed trade code </th></tr>";

                foreach (SupplierCategory sc in catListRemoved)
                {
                    strTradeCodeRemove += "<tr><td>&nbsp;</td><td><b><li>";
                    strTradeCodeRemove += sc.Category.Name + " (" + sc.Category.Code + ")" + "</li></b></td></tr>";
                }
                if (strTradeCodeRemove != "")
                    strTradeCodeRemove += "</table>";
            }


            RelatedUsers.Add("$TRADECODEAMENDMENT$", strTradeCodeAdded + "<br /> " + strTradeCodeRemove);

            return RelatedUsers;
        }
         

        public static string ReplaceRelatedUsers(string content, Hashtable RelatedUsers)
        {

//            var result = RelatedUsers.Cast<DictionaryEntry>().FirstOrDefault(x => content != null && x.Key.ToString() == content);
//            content = (string)result.Value;

            foreach (object key in RelatedUsers.Keys)
            {
                try
                {
                    content = content.Replace((string) key, (string) Convert.ToString(RelatedUsers[key]) );
                }
                catch (Exception ex)
                {
                    throw;
                }
               
            }

            return content;
        }

        public static void SupplierSendEmail(Supplier supplier, WorkflowHistory workflowHistory,
            string emailMessageName, string comments, string prefixDbName)
        {
            EmailMessage emailmessage = EmailMessageUtility.GetByName(
                prefixDbName + ConstantUtility.COMMON_DATASOURCE_NAME, emailMessageName);
            if (emailmessage == null) return;

            User user = UserUtility.Get(prefixDbName + ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());
            if (supplier.PhysicalAddress != null)
            {
                supplier.PhysicalAddress.AddressLine1 = supplier.PhysicalAddress.AddressLine1.Replace("|", " ");
                supplier.PhysicalAddress.AddressLine2 = supplier.PhysicalAddress.AddressLine2.Trim().Length == 0 ? "" : "#" + supplier.PhysicalAddress.AddressLine2;
            }

            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "Supplier", supplier.Id.ToString());

            switch (emailmessage.Objects)
            {
                case "Authorized Users":
                    {
                        if (workflowHistory == null) break;
                        string nodes = XmlUtility.ToXml(workflowHistory.NextLinks);
                        UserCollection users = UserUtility.FindByCriteria(
                            prefixDbName + ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_WORKFLOWNODES,
                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                            {
                                SendEmail(emailmessage, users[i],
                                    new object[] { supplier, vendor, users[i] },
                                    comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "Supplier", supplier.Id);
                            }
                        }
                    }
                    break;
                case "Workflow Users": 
                    {

                        if (supplier.SupplierWorkflows != null)
                        {
                            UserCollection users = UserUtility.FindByCriteria(
                               ConstantUtility.USER_DATASOURCE_NAME,
                               UserManager.FIND_USER_BY_WORKFLOWTRANSACTION,
                               new object[] { supplier.SupplierWorkflows[0].TransactionId });

                            if (users != null)
                            {
                                for (int i = 0; i < users.Count; i++)
                                {
                                    SendEmail(emailmessage, users[i],
                                         new object[] { supplier, vendor, users[i] },
                                         comments,
                                         (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                         "Supplier", supplier.Id);
                                }
                            }
                        }
                    }
                    break;
                case "Users":
                    {
                        SendEmail(emailmessage, user,
                            new object[] { supplier, vendor, user }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Supplier", supplier.Id);
                    }
                    break;

                case "Supplier Related Users":
                    {
                        EmailMessage newMessage = EmailReplaceRelatedUsers(emailmessage, supplier);
                        SendEmail(newMessage, user,
                            new object[] { supplier, vendor, user }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Supplier", supplier.Id);
                    }
                    break;

                case "Suppliers":
                    {
                        EmailMessage newMessage = EmailReplaceRelatedUsers(emailmessage, supplier);
                        VendorContact primaryContact = GetPrimaryContact(vendor.Id);
                        if (primaryContact != null && primaryContact.Email.Trim().Length == 0)
                        {
                            SendFax(newMessage, supplier, user.Id, new object[] { supplier, vendor, user }, comments);
                        }
                        else
                        {
                            SendEmail(newMessage, supplier,
                                new object[] { supplier, vendor, user }, comments,
                                (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                "Supplier", supplier.Id);
                        }
                    }
                    break;

                default:
                    {
                        SendEmail(emailmessage, null,
                            new object[] { supplier, vendor, user }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Supplier", supplier.Id);
                    }
                    break;
            }
        }

        public static string GetEmailHistoryFullFolder(int historyId)
        {
            return ConfigurationManager.AppSettings["UploadDirectory"] +
                "Email\\EmailHistory" + historyId + "\\";
        }

        public static string GetFaxHistoryFullFolder(int historyId)
        {
            return ConfigurationManager.AppSettings["UploadDirectory"] +
                "Fax\\FaxHistory" + historyId + "\\";
        }

        public static string GetDownloadFolder(int userId)
        {
            string downloadFolder = ConfigurationManager.AppSettings["DownloadPath"] + "User" + userId + "\\";
            if (!Directory.Exists(downloadFolder))
            {
                Directory.CreateDirectory(downloadFolder);
            }
            return downloadFolder;
        }

        public static string GetFolder(int supplierId)
        {
            string downloadFolder = ConfigurationManager.AppSettings["DownloadPath"] + "Supplier" + supplierId + "\\";
            if (!Directory.Exists(downloadFolder))
            {
                Directory.CreateDirectory(downloadFolder);
            }
            return downloadFolder;
        }
        public static string GetProjectFolder(int projectId)
        {
            string downloadFolder = ConfigurationManager.AppSettings["DownloadPath"] + "Project" + projectId + "\\";
            if (!Directory.Exists(downloadFolder))
            {
                Directory.CreateDirectory(downloadFolder);
            }
            return downloadFolder;
        }
        #endregion

        #region	Public Methods - Other
        public static string CalculateChecksum(byte[] buffer)
        {
            MD5 md5 = MD5.Create();
            byte[] checksum = md5.ComputeHash(buffer);
            return BitConverter.ToString(checksum).Replace("-", String.Empty);
        }

        public static string RemoveSpace(string html)
        {
            Regex regex = new Regex("\\s+", RegexOptions.IgnoreCase | RegexOptions.Compiled);
            return regex.Replace(HttpUtility.HtmlDecode(html.Replace("&nbsp;", " ")), " ").ToString();
        }

        public static string StringToASCII(string source)
        {
            ASCIIEncoding ascii = new ASCIIEncoding();
            byte[] ByteArray1 = ascii.GetBytes(source);
            string keyword = "";
            for (int x = 0; x <= ByteArray1.Length - 1; x++)
            {
                keyword += "%";
                keyword += Convert.ToString(ByteArray1[x], 16);
            }
            return keyword;
        }

        public static int GetNewSupplierVersion(int supplierId, string changeUser)
        {
            Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierId);
            if (supplier == null) return 0;

            //SupplierVersion supplierVersion = SupplierVersionUtility.GetByType(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
            //    supplierId, "Current");

            //if( supplierVersion == null )
            //{
            //    SupplierVersion oldVersion = SupplierVersionUtility.CreateObject();
            //    oldVersion.SupplierId = supplierId;
            //    oldVersion.Status = 1;
            //    oldVersion.IsLocked = "Y";
            //    SupplierVersionUtility.Create(ConstantUtility.SUPPLIER_DATASOURCE_NAME, oldVersion);
            //}

            int newId = SupplierUtility.Copy(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierId, "Pre", changeUser);
            Supplier newSupplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, newId);

            if (newSupplier == null)
                return 0;

            //SupplierStatus supplierStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_QUALIFICATION);
            //if (supplierStatus != null && supplierStatus.Status == SupplierStatusType.Qualified.Description)
            //{
            //    SupplierWorkflowExec.InitialSupplierWorkflow(newSupplier, ConstantUtility.WORKFLOW_QUALIFICATION);
            //}

            //SupplierStatus certStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);
            //if (certStatus != null && certStatus.Status == CertificationStatusType.Certified.Description)
            //{
            //    SupplierWorkflowExec.InitialSupplierWorkflow(newSupplier, ConstantUtility.WORKFLOW_CERTIFICATION);
            //}

            // Reuqlification
            //SupplierUtility.UpdateStatus(ConstantUtility.SUPPLIER_DATASOURCE_NAME, newId, 2);

            return SupplierUtility.Copy(ConstantUtility.SUPPLIER_DATASOURCE_NAME, newId, "Post", changeUser);
        }

        public static int GetNewSupplierVersion(int supplierId, string changeUser, string workflowType)
        {
            Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierId);
            if (supplier == null) return 0;

            int newId = SupplierUtility.Copy(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierId, "Pre", changeUser);
            Supplier newSupplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, newId);

            if (newSupplier == null)
                return 0;

            if (SupplierUtility.CopyNewVersion(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierId, newId, workflowType) == 1)
                return newId;
            return 0;
        }

        public static int GetOldSupplierVersion(int supplierId)
        {
            int oldId = 0;
            SupplierVersion supplierVersion = null;
            SupplierVersionCollection supplierVersions = SupplierVersionUtility.FindByCriteria(
                ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                SupplierVersionManager.FIND_BY_SUPPLIER,
                new object[] { supplierId });
            if (supplierVersions != null)
            {
                foreach (SupplierVersion sv in supplierVersions)
                {
                    if (sv.Status == 0)
                    {
                        supplierVersion = sv;
                        break;
                    }
                }
                if (supplierVersion != null)
                {
                    oldId = supplierVersion.SupplierId;
                }
            }
            return oldId;
        }

        public static bool NoChangeAffidavitRequired(Supplier supplier)
        {
            if (supplier.SupplierProperties == null)
            {
                supplier.SupplierProperties = SupplierPropertyUtility.FindByCriteria(
                    ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                    SupplierPropertyManager.FIND_BY_SUPPLIER,
                    new object[] { supplier.Id });
            }
            SupplierProperty certAction = GetSupplierProperty("property3001", supplier.SupplierProperties);
            if (certAction != null && certAction.PropertyText == "Cm")
                return true;
            int oldId = GetOldSupplierVersion(supplier.Id);
            if (oldId > 0)
            {
                supplier.SupplierProperties = SupplierPropertyUtility.FindByCriteria(
                    ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                    SupplierPropertyManager.FIND_BY_SUPPLIER,
                    new object[] { oldId });
                if (supplier.SupplierProperties == null) return false;
                certAction = GetSupplierProperty("property3001", supplier.SupplierProperties);
                if (certAction != null && certAction.PropertyText == "Cm")
                    return true;
            }

            return false;
        }

        public static string IsQualificationPending(string statusName)
        {
            if (statusName == SupplierStatusType.Qualified.Name ||
                statusName == SupplierStatusType.NewPrequalification.Name ||
                statusName == SupplierStatusType.AdministrativelyClosed.Name ||
                statusName == SupplierStatusType.Inactive.Name ||
                statusName == SupplierStatusType.Withdrawn.Name ||
                statusName == SupplierStatusType.Disqualified.Name ||
                statusName == SupplierStatusType.Rescinded.Name ||
                statusName == SupplierStatusType.Suspended.Name ||
                statusName == SupplierStatusType.Deny.Name ||
                statusName == SupplierStatusType.Expired.Name)
                return "N";
            else
                return "Y";
        }

        public static string IsCertificationPending(string statusName)
        {
            if (statusName == CertificationStatusType.Certified.Name ||
                statusName == CertificationStatusType.NewCertification.Name ||
                statusName == CertificationStatusType.CertAdminClosed.Name ||
                statusName == CertificationStatusType.Withdrawn.Name ||
                statusName == CertificationStatusType.Disqualified.Name ||
                statusName == CertificationStatusType.Decertified.Name ||
                statusName == CertificationStatusType.Rescinded.Name ||
                statusName == CertificationStatusType.Suspended.Name ||
                statusName == CertificationStatusType.Deny.Name ||
                statusName == CertificationStatusType.Archived.Name ||
                statusName == CertificationStatusType.Expired.Name)
                return "N";
            else
                return "Y";
        }

        public static string GetValue(List<Extra> extraItems, string name)
        {
            if (extraItems == null) return string.Empty;

            foreach (Extra item in extraItems)
            {
                if (item.Name == name) return item.Value;
            }
            return string.Empty;
        }

        public static void AddExtraItem(List<Extra> extraItems, string name, string value)
        {
            Extra extraItem = new Extra();
            extraItem.Name = name;
            extraItem.Value = value;
            extraItems.Add(extraItem);
        }

        public static void RemoveExtraItem(List<Extra> extraItems, string name)
        {
            if (extraItems == null) return;

            foreach (Extra item in extraItems)
            {
                if (item.Name == name)
                {
                    extraItems.Remove(item);
                    break;
                }
            }
        }

        public static DateTime GetApplicationReceivedDate(Supplier supplier)
        {
            SupplierProperty sp = GetSupplierProperty("property530", supplier.SupplierProperties);
            DateTime now = DateTime.Now;
            if (sp.PropertyDate != null && sp.PropertyDate != new DateTime(1900, 1, 1))
                now = sp.PropertyDate;
            else if (supplier.ApplyDate != new DateTime(1900, 1, 1))
                now = supplier.ApplyDate;
            return now;
        }

        public static string GetIfaxType(string filename)
        {
            string strId = string.Empty;
            string strType = string.Empty;
            int index = 0;

            index = filename.IndexOf("_");
            if (index > 0)
                strId = filename.Substring(0, index);
            strId = strId.PadLeft(14, '0');
            strType = strId.Substring(3, 2);

            if (strType == ConstantUtility.INSURANCE_CERTIFICATE)
                return ConstantUtility.IFAXTYPE_SAF;

            return ConstantUtility.IFAXTYPE_SUPPLIER;
        }
        public static void DeleteDocument(LinkButton sender, string type)
        {
            int documentId = ConvertUtility.ConvertInt(sender.CommandArgument);
            bool success = false;
            switch (type)
            {
                case "Supplier":
                    success = SupplierDocumentUtility.Delete(ConstantUtility.SUPPLIER_DATASOURCE_NAME, documentId);
                    break;
                case "Rfc":
                    success = RfcDocumentUtility.Delete(ConstantUtility.RFD_DATASOURCE_NAME, documentId);
                    break;
                case "Project":
                    success = ProjectDocumentUtility.Delete(ConstantUtility.RFD_DATASOURCE_NAME, documentId);
                    break;
            }
            if (success)
                sender.Parent.Visible = false;
        }
        #endregion

        #region Qualification Matrix Check
        public static bool MatrixCheckQualRequired(SupplierStatusCollection supplierStatuses, ref DateTime qualExp, ref DateTime certExp, ref string qualStatusText)
        {
            SupplierStatus qualStatus = supplierStatuses.FindByType(ConstantUtility.WORKFLOW_QUALIFICATION);
            //SupplierStatus certStatus = supplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);

            if (qualStatus == null && qualExp <= new DateTime(1901, 1, 1)) return false;

            qualStatusText = qualStatus.Status;
            if (ConstantUtility.QualPendingDictionary.ContainsValue(qualStatus.Status))
            {
                qualStatusText = "Pending";
                qualExp = new DateTime(1900, 1, 1);
            }
            return true;
        }

        public static bool MatrixCheckCertRequired(SupplierStatusCollection supplierStatuses, ref DateTime qualExp, ref DateTime certExp, ref string certStatusText)
        {
            //SupplierStatus qualStatus = supplierStatuses.FindByType(ConstantUtility.WORKFLOW_QUALIFICATION);
            SupplierStatus certStatus = supplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);

            if (certStatus == null && certExp <= new DateTime(1901, 1, 1)) return false;

            certStatusText = certStatus.Status;
            if (ConstantUtility.CertPendingDictionary.ContainsValue(certStatus.Status))
            {
                certStatusText = "Pending";
                certExp = new DateTime(1900, 1, 1);
                return true;
            }
            return false;
        }

        public static string MatrixCheckQualCertAction(SupplierStatusCollection supplierStatuses, bool isQual, bool isCert, DateTime qualExp, DateTime certExp, ref string qualAction, ref string certAction)
        {
            SupplierStatus qualStatus = supplierStatuses.FindByType(ConstantUtility.WORKFLOW_QUALIFICATION);
            SupplierStatus certStatus = supplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);

            bool qual0 = qualExp < DateTime.Today;
            bool qual3 = qualExp.AddMonths(-3) < DateTime.Today && !qual0;
            bool qual24 = qualExp.AddMonths(-24) < DateTime.Today && !qual0 && !qual3;
            bool qual24plus = !qual0 && !qual3 && !qual24;

            bool cert0 = certExp < DateTime.Today;
            bool cert3 = certExp.AddMonths(-3) < DateTime.Today && !cert0;
            bool cert24 = certExp.AddMonths(-24) < DateTime.Today && !cert0 && !cert3;
            bool cert24plus = !cert0 && !cert3 && !cert24;

            if (isQual)
            {
                qualAction = "Qn";
                if (qualStatus != null && ConstantUtility.QualPendingDictionary.ContainsValue(qualStatus.Status))
                    qualAction = "Qc";
                else if (isCert && qual24 && qual24plus)
                    qualAction = "Qc";
            }

            if (isCert)
            {
                certAction = "Cn";
                if (certStatus != null && ConstantUtility.CertPendingDictionary.ContainsValue(certStatus.Status))
                    certAction = "Cc";
                else if (isQual && qual24)
                    certAction = "Cm";
                else if (isQual && qual24plus)
                    certAction = "Ce";
            }

            return string.Empty;
        }
        #endregion

        #region Third Party Check
        public static CookieContainer DNBSiteLogin(string userName, string password)
        {
            CookieContainer cookieContainer = new CookieContainer();

            HtmlUtility.GetHtmlPage(ConstantUtility.DNB_LOGIN_URL, cookieContainer);

            StringBuilder dataString = new StringBuilder();
            dataString.Append("requesttype=CONTRACTMENU&");
            dataString.Append("LOGINFROMHOME=N&");
            dataString.Append("STARTPAGE=/product/contract/NYC/index.htm&");
            dataString.Append("ENCRUID=&");
            dataString.Append("USERID=" + userName + "&");
            dataString.Append("ENCRPSWD=&");
            dataString.Append("USERPSWD=" + password + "&");
            dataString.Append("ENDORSEMENT=" + userName);

            PostHtmlPage(ConstantUtility.DNB_LOGIN_URL, cookieContainer, dataString.ToString(), string.Empty);

            return cookieContainer;
        }

        public static String PostHtmlPage(String url, CookieContainer container, string postingData, string referer)
        {
            try
            {
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
                webRequest.Method = "POST";
                webRequest.Accept = "*/*";
                webRequest.CookieContainer = container;
                webRequest.Referer = referer;
                webRequest.ContentLength = postingData.Length;
                webRequest.ContentType = "application/x-www-form-urlencoded";
                webRequest.AllowAutoRedirect = true;
                webRequest.KeepAlive = true;

                StreamWriter streamWriter = new StreamWriter(webRequest.GetRequestStream());
                streamWriter.Write(postingData);
                streamWriter.Close();

                HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();

                StreamReader streamReader = new StreamReader(webResponse.GetResponseStream());
                String result = streamReader.ReadToEnd();

                if (container != null && webResponse.Cookies.Count > 0)
                {
                    container.Add(webResponse.Cookies);
                }

                streamReader.Close();
                webResponse.Close();

                return result;
            }
            catch
            {
                return string.Empty;
            }
        }

        public static CookieContainer LexisNexisSiteLogin(string userName, string password)
        {
            CookieContainer cookieContainer = new CookieContainer();

            string html = HtmlUtility.GetHtmlPage(ConstantUtility.LN_LOGIN_URL, cookieContainer);

            string _session = string.Empty;
            string wchp = string.Empty;
            string _md5 = string.Empty;
            Regex regEx = new Regex("NAME=\"(?<Name>[^\"]*)\" VALUE=\"(?<Value>[^\"]*)\"");
            Match match = regEx.Match(html);
            while (match.Success) //If there is a match.
            {
                string name = match.Groups["Name"].ToString();
                string value = match.Groups["Value"].ToString();

                if (name == "_session")
                    _session = value;
                else if (name == "wchp")
                    wchp = value;
                else if (name == "_md5")
                    _md5 = value;

                match = match.NextMatch(); //Next match.
            }

            StringBuilder dataString = new StringBuilder();
            dataString.Append("USER_ID=" + userName + "&");
            dataString.Append("PASSWORD=" + password + "&");
            dataString.Append("USE_SSL=checked&");
            dataString.Append("DELIVERY_UTILITY_VERSION=1%2C1%2C0%2C2&");
            dataString.Append("INCOMING_URL=/research&");
            dataString.Append("_state=&");
            dataString.Append("_bundles=%a3forever%a6pp%a5%a6cp%a5https://www.lexis.com/research?%a6%a4&");
            dataString.Append("_session=" + _session + "&");
            dataString.Append("wchp=" + wchp + "&");
            dataString.Append("_md5=" + _md5 + "&");
            dataString.Append("SSL_FORM=ON&");
            dataString.Append("logon_attempts=1&");
            dataString.Append("LNAUTHSCHEME=CP&");
            dataString.Append("_form=signon&");
            dataString.Append("js=1&");
            dataString.Append("du=0&");
            dataString.Append("USER_AGENT=Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729");

            html = PostHtmlPage(ConstantUtility.LN_LOGIN_URL, cookieContainer, dataString.ToString(), ConstantUtility.LN_LOGIN_URL);

            return cookieContainer;
        }

        public static string GetHtml(string siteName, string url)
        {
            string html = string.Empty;
            if (siteName == "TPC_Lexis")
            {
                string userName = SettingUtility.GetValueByName(ConstantUtility.COMMON_DATASOURCE_NAME, "LNUSERNAME");
                string password = SettingUtility.GetValueByName(ConstantUtility.COMMON_DATASOURCE_NAME, "LNPASSWORD");

                CookieContainer cookie = LexisNexisSiteLogin(userName, password);

                html = HtmlUtility.GetHtmlPage(url, cookie);
            }
            else if (siteName == "TPC_DB")
            {
                string userName = SettingUtility.GetValueByName(ConstantUtility.COMMON_DATASOURCE_NAME, "DNBUSERNAME");
                string password = SettingUtility.GetValueByName(ConstantUtility.COMMON_DATASOURCE_NAME, "DNBPASSWORD");

                CookieContainer cookie = DNBSiteLogin(userName, password);

                html = ConvertWebPageToMHTString(url);
            }
            else
                html = ConvertWebPageToMHTString(url);

            return html;
        }

        public static string ConvertWebPageToMHTString(string url)
        {
            string data = String.Empty;
            try
            {

                CDO.Message msg = new CDO.Message();
                ADODB.Stream stm = null;
                
                msg.MimeFormatted = true;
                msg.CreateMHTMLBody(url, CDO.CdoMHTMLFlags.cdoSuppressNone, "", "");
                stm = msg.GetStream();
                data = stm.ReadText(stm.Size);
            }
            catch (Exception e)
            {
                _logger.Error("ConvertWebPageToMHTString", e);
                throw;
            }
            finally
            {
                //cleanup here
            }
            return data;
        }

        public static string DNBSiteScript(string url, string userName, string password)
        {
            string javacript = string.Empty;

            javacript = "<script language=\"javascript\">" +
                "document.aspnetForm.target = \"_blank\";" +
                "document.aspnetForm.method = \"post\";" +
                "document.aspnetForm.encoding = \"application/x-www-form-urlencoded\";" +
                //"document.aspnetForm.requestType.value = \"CONTRACTMENU\";" +
                //"document.aspnetForm.Endorsement.value = \"" + userName + "\";" +
                "document.aspnetForm.email.value = \"" + userName + "\";" +
                "document.aspnetForm.password.value = \"" + password + "\";" +
                "document.aspnetForm.action = \"" + ConstantUtility.DNB_LOGIN_URL + "\";" +
                "document.aspnetForm.submit();" +
                "window.location = \"" + url + "\";" +
                "</script>";

            return javacript;
        }

        public static string LexisNexisSiteScript(string url, string userName, string password)
        {
            CookieContainer cookieContainer = new CookieContainer();

            string javacript = string.Empty;
            string postUrl = string.Empty;
            string html = HtmlUtility.GetHtmlPage(ConstantUtility.LN_LOGIN_URL, cookieContainer);
            if (html != null)
            {
                Regex regEx = new Regex("0; url=(?<Url>[^\"]*)\">");
                Match match = regEx.Match(html);
                if (match.Success)
                {
                    postUrl = match.Groups["Url"].ToString();
                }

                //string _session = string.Empty;
                //string wchp = string.Empty;
                //string _md5 = string.Empty;
                //Regex regEx = new Regex("NAME=\"(?<Name>[^\"]*)\" VALUE=\"(?<Value>[^\"]*)\"");
                //Match match = regEx.Match(html);
                //while (match.Success) //If there is a match.
                //{
                //    string name = match.Groups["Name"].ToString();
                //    string value = match.Groups["Value"].ToString();

                //    if (name == "_session")
                //        _session = value;
                //    else if (name == "wchp")
                //        wchp = value;
                //    else if (name == "_md5")
                //        _md5 = value;

                //    match = match.NextMatch(); //Next match.
                //}

                //string USER_AGENT = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)";

                javacript = "<script language=\"javascript\">" +
                    "document.aspnetForm.target = \"_blank\";" +
                    "document.aspnetForm.method = \"post\";" +
                    "document.aspnetForm.encoding = \"application/x-www-form-urlencoded\";" +
                    //"document.aspnetForm.DELIVERY_UTILITY_VERSION.value = \"1, 1, 0, 2\";" +
                    //"document.aspnetForm.INCOMING_URL.value = \"/research\";" +
                    //"document.aspnetForm._state.value = \"\";" +
                    //"document.aspnetForm._bundles.value = \"%a3forever%a6pp%a5%a6cp%a5https://www.lexis.com/research?%a6%a4\";" +
                    //"document.aspnetForm._session.value = \"" + _session + "\";" +
                    //"document.aspnetForm.wchp.value = \"" + wchp + "\";" +
                    //"document.aspnetForm._md5.value = \"" + _md5 + "\";" +
                    //"document.aspnetForm.USE_SSL.value = \"checked\";" +
                    //"document.aspnetForm.SSL_FORM.value = \"ON\";" +
                    //"document.aspnetForm.logon_attempts.value = \"1\";" +
                    //"document.aspnetForm.LNAUTHSCHEME.value = \"CP\";" +
                    //"document.aspnetForm._form.value = \"signon\";" +
                    //"document.aspnetForm.js.value = \"1\";" +
                    //"document.aspnetForm.du.value = \"0\";" +
                    //"document.aspnetForm.USER_AGENT.value = \"" + USER_AGENT + "\";" +
                    "document.aspnetForm.USER_ID.value = \"" + userName + "\";" +
                    "document.aspnetForm.PASSWORD.value = \"" + password + "\";" +
                    "document.aspnetForm.action = \"" + postUrl + "\";" +
                    "document.aspnetForm.submit();" +
                    "window.location = \"" + url + "\";" +
                    "</script>";
            }
            return javacript;
        }

        //public static string LexisNexisSiteScript(string url, string userName, string password)
        //{
        //    CookieContainer cookieContainer = new CookieContainer();

        //    string javacript = string.Empty;
        //    string postUrl = string.Empty;

        //    string html = HtmlUtility.GetHtmlPage(ConstantUtility.LN_LOGIN_URL, cookieContainer);
        //    if (html != null)
        //    {
        //        Regex regEx = new Regex("0; url=(?<Url>[^\"]*)\">");
        //        Match match = regEx.Match(html);
        //        if (match.Success)
        //        {
        //            string freshUrl = match.Groups["Url"].ToString();
        //            html = HtmlUtility.GetHtmlPage(freshUrl, cookieContainer);
        //            if (html != null)
        //            {
        //                regEx = new Regex("0;URL=(?<Url>[^\"]*)\"");
        //                match = regEx.Match(html);
        //                if (match.Success)
        //                {
        //                    postUrl = match.Groups["Url"].ToString();
        //                }
        //            }
        //        }

        //        postUrl = postUrl.Replace("&event=pageTimeout", "");

        //        javacript = "<script language=\"javascript\">" +
        //            "document.aspnetForm.target = \"_blank\";" +
        //            "document.aspnetForm.method = \"post\";" +
        //            "document.aspnetForm.encoding = \"application/x-www-form-urlencoded\";" +
        //            "document.aspnetForm.USER_ID.value = \"" + userName + "\";" +
        //            "document.aspnetForm.PASSWORD.value = \"" + password + "\";" +
        //            "document.aspnetForm.action = \"" + postUrl + "\";" +
        //            "document.aspnetForm.submit();" +
        //            "window.location = \"" + url + "\";" +
        //            "</script>";
        //    }
        //    return javacript;
        //}
        #endregion

        #region Menu Method
        public static void GetCurrentMenu(MenuCollection menus, int menuId)
        {
            if (menus == null || menus.Count == 0) return;
            foreach (SCA.VAS.ValueObjects.User.Menu m in menus)
            {
                if (m.Id == menuId)
                    currentStep = m;
                GetCurrentMenu(m.SubMenus, menuId);
            }
        }
        public static string GetQuestions(string questionIdString, string sectionText)
        {
            string questionText = "";
            string itemxml = ReadFile(ConfigurationManager.AppSettings["LookupFolder"] + "ApplicationQuestions.xml");
            MenuCollection allItems = (MenuCollection)XmlUtility.Deserialize(itemxml, typeof(MenuCollection));
            string[] questionids = questionIdString.Split('|');
            if (allItems != null)
            {
                foreach (string id in questionids)
                {
                    foreach (SCA.VAS.ValueObjects.User.Menu menu in allItems)
                    {
                        if (menu.Text == sectionText && menu.SubMenus != null && menu.SubMenus.Count > 0)
                        {
                            foreach (SCA.VAS.ValueObjects.User.Menu submenu in menu.SubMenus)
                            {
                                if (submenu.SubMenus != null && submenu.SubMenus.Count > 0)
                                {
                                    foreach (SCA.VAS.ValueObjects.User.Menu subsub in submenu.SubMenus)
                                        if (subsub.Id.ToString() == id)
                                            questionText += submenu.Text + ": " + subsub.Text;
                                }
                                else if (submenu.Id.ToString() == id)
                                    questionText += submenu.Text;
                            }
                        }
                    }
                    questionText += "; ";
                }
            }
            if (questionText.LastIndexOf(';') >= 0)
                questionText = questionText.Substring(0, questionText.LastIndexOf(';'));
            return questionText;
        }
        public static MenuCollection GetRegistrationMenus(Supplier supplier, string type)
        {
            string regxml = string.Empty;
            MenuCollection menus = null;
            bool checkType = true;

            if (supplier != null)
            {
                SupplierPropertyCollection supplierProperties = supplier.SupplierProperties;
                switch (type)
                {
                    case "PaperCert":
                        regxml = ReadFile(ConfigurationManager.AppSettings["LookupFolder"] + "PaperWizardCert.xml");
                        menus = (MenuCollection)XmlUtility.Deserialize(regxml, typeof(MenuCollection));
                        break;
                    case "PaperQual":
                        regxml = ReadFile(ConfigurationManager.AppSettings["LookupFolder"] + "PaperWizardQual.xml");
                        menus = (MenuCollection)XmlUtility.Deserialize(regxml, typeof(MenuCollection));
                        break;
                    default:
                        checkType = false;
                        break;
                }

                bool IsShortForm = false;
                bool IsProfService = false;
                bool IsAE = false;
                bool IsVendor = false;
                bool IsNonapplicant = false;
                bool IsQualification = false;
                bool IsCertification = false;
                bool IsMBE = false;
                bool IsWBE = false;
                bool IsLBE = false;
                bool IsLbeArea = false;
                bool IsLbeEmployee = false;
                int numNoSafety = 0;
                int numShortForm = 0;
                int numAe = 0;
                bool flagNoSafety = false;
                bool flagAsbestosAbatement = false;
                bool flagAsbestosConsultant = false;
                bool flagLabTesting = false;
                bool flagNoApprent = false;
                int code = 0;
                string codestring = "";
                if (supplier.SupplierCategories != null && supplier.SupplierCategories.Count > 0)
                {
                    foreach (SupplierCategory cat in supplier.SupplierCategories)
                    {
                        codestring = cat.Category.Code;
                        if (cat.Category.Code.Length > 6) //remove trailing letters
                            codestring.Substring(0, 5);
                        code = ConvertUtility.ConvertInt(codestring);
                        if (code == 13285)
                            flagAsbestosAbatement = true;
                        if (code == 86031)
                            flagAsbestosConsultant = true;
                        if (code == 37100)
                            flagLabTesting = true;
                        if (code >= 31000 && code <= 34000)
                        {
                            IsAE = true;
                            numAe++;
                        }
                        if (code >= 86000 && code <= 87000)
                            IsProfService = true;
                        if ((code >= 31000 && code <= 37000) || (code >= 37001 && code <= 37117) || (code >= 80000 && code <= 84012) || (code >= 86000 && code <= 87000))
                            numNoSafety++;
                        if ((code >= 80000 && code <= 84012) || (code >= 86000 && code <= 86100 && code != 86080))
                            numShortForm++;
                        if (code >= 80000 && code <= 84012)
                            IsVendor = true;
                    }
                    if (numShortForm >= supplier.SupplierCategories.Count)
                        IsShortForm = true;
                    if (numNoSafety >= supplier.SupplierCategories.Count)
                        flagNoSafety = true;
                    if (numAe >= supplier.SupplierCategories.Count)
                        flagNoApprent = true;
                }

                if (!checkType)
                {
                    if (supplier.IsCertified == "N")
                    {
                        regxml = ReadFile(ConfigurationManager.AppSettings["LookupFolder"] + "RegistrationWizardNonapp.xml");
                        menus = (MenuCollection)XmlUtility.Deserialize(regxml, typeof(MenuCollection));
                        IsNonapplicant = true;
                    }
                    else if (supplier.IsCertified == "B")
                    {
                        IsQualification = true;
                        IsCertification = true;
                        if (IsShortForm)
                        {
                            regxml = ReadFile(ConfigurationManager.AppSettings["LookupFolder"] + "RegistrationWizardShort.xml");
                            menus = (MenuCollection)XmlUtility.Deserialize(regxml, typeof(MenuCollection));
                        }
                        else
                        {
                            regxml = ReadFile(ConfigurationManager.AppSettings["LookupFolder"] + "RegistrationWizard.xml");
                            menus = (MenuCollection)XmlUtility.Deserialize(regxml, typeof(MenuCollection));
                        }
                    }
                    else if (supplier.IsCertified == "Q")
                    {
                        IsQualification = true;
                        if (IsShortForm)
                        {
                            regxml = ReadFile(ConfigurationManager.AppSettings["LookupFolder"] + "RegistrationWizardQualShort.xml");
                            menus = (MenuCollection)XmlUtility.Deserialize(regxml, typeof(MenuCollection));
                        }
                        else
                        {
                            regxml = ReadFile(ConfigurationManager.AppSettings["LookupFolder"] + "RegistrationWizardQual.xml");
                            menus = (MenuCollection)XmlUtility.Deserialize(regxml, typeof(MenuCollection));
                        }
                    }
                    else if (supplier.IsCertified == "C")
                    {
                        IsCertification = true;
                        regxml = ReadFile(ConfigurationManager.AppSettings["LookupFolder"] + "RegistrationWizardCert.xml");
                        menus = (MenuCollection)XmlUtility.Deserialize(regxml, typeof(MenuCollection));
                    }
                    else
                    {
                        regxml = ReadFile(ConfigurationManager.AppSettings["LookupFolder"] + "RegistrationWizard.xml");
                        menus = (MenuCollection)XmlUtility.Deserialize(regxml, typeof(MenuCollection));
                    }
                }

                if (supplierProperties != null)
                {
                    foreach (SupplierProperty sp in supplierProperties)
                    {
                        if (sp.PropertyId < ConstantUtility.CHECKLISTID) continue;
                        if (sp.PropertyId == 2003)
                        {
                            if (sp.PropertyText == "MBE")
                                IsMBE = true;
                            else if (sp.PropertyText == "WBE")
                                IsWBE = true;
                            else if (sp.PropertyText == "LBE")
                                IsLBE = true;
                        }
                        if (sp.PropertyId == 2004)
                        {
                            if (sp.PropertyText == "area")
                            {
                                IsLbeArea = true;
                                IsLbeEmployee = false;
                            }
                            else if (sp.PropertyText == "employees")
                            {
                                IsLbeEmployee = true;
                                IsLbeArea = false;
                            }
                        }
                    }
                }

                if (!checkType)
                {
                    if (!flagAsbestosAbatement || !flagAsbestosConsultant || !flagLabTesting || !IsLBE || IsLbeArea || flagNoSafety || flagNoApprent)
                    {
                        for (int i = 0; i < menus.Count; i++)
                        {
                            if ((!IsLBE || IsLbeArea) && menus[i].Id == 28) //LBE Qualification
                            {
                                menus.Remove(menus[i]);
                                i--;
                            }

                            //if (menus[i].SubMenus == null || menus[i].SubMenus.Count == 0) continue;
                            if (!flagAsbestosAbatement && menus[i].Id == 12) // Qual Statement 1
                            {
                                menus.Remove(menus[i]);
                                i--;
                            }
                            if (!flagAsbestosConsultant && menus[i].Id == 13) // Qual Statement 2
                            {
                                menus.Remove(menus[i]);
                                i--;
                            }
                            if (!flagLabTesting && menus[i].Id == 14) // Qual Statement 3
                            {
                                menus.Remove(menus[i]);
                                i--;
                            }
                            if (flagNoSafety && menus[i].Id == 19)
                            {
                                menus.Remove(menus[i]);
                                i--;
                            }
                            if (flagNoApprent && menus[i].Text == "Apprenticeship")
                            {
                                menus.Remove(menus[i]);
                                i--;
                            }
                        }
                    }
                }
            }
            return menus;
        }

        private static void GetAllLevelMenu(MenuCollection menus)
        {
            foreach (Menu m in menus)
            {
                allLevelMenus.Add(m);
                if (m.SubMenus != null)
                {
                    level++;
                    GetAllLevelMenu(m.SubMenus);
                }
            }
            level--;
        }
        #endregion Menu Method

        public static int GetExternalMessageCount(Supplier supplier)
        {
            int count = 0;
            SupplierCommentCollection supplierComments = SupplierCommentUtility.FindByCriteria(
                ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                SupplierCommentManager.FIND_SUPPLIERCOMMENT,
                new object[] { 0, 0, "", "", supplier.Id, "External" });
            if (supplierComments != null && CommonUtility.LetterSent(supplier))
            {
                foreach (SupplierComment sc in supplierComments)
                {
                    if (sc.Submitted != "Y")
                        count++;
                }
            }
            SubcontractorCollection allSubs = SubcontractorUtility.FindByCriteria(
                ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                SubcontractorManager.FIND_SUBCONTRACTOR_BY_SUPPLIER,
                new object[] { 0, 0, "Company", "ASC", supplier.Id, "" });
            if (allSubs != null)
            {
                foreach (Subcontractor sub in allSubs)
                {
                    SubcontractorCommentCollection comments = SubcontractorCommentUtility.FindByCriteria(
                        ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                        SubcontractorCommentManager.FIND_SUBCONTRACTORCOMMENT,
                        new object[] { 0, 0, "", "", sub.Id, "External" });
                    if (comments != null)
                    {
                        foreach (SubcontractorComment subComment in comments)
                        {
                            if (subComment.Submitted != "Y")
                                count++;
                        }
                    }
                }
            }

            PlanCollection plans = PlanUtility.FindByCriteria(
                ConstantUtility.RFD_DATASOURCE_NAME,
                PlanManager.FIND_BY_SUPPLIER,
                new object[] { 0, 0, "Company", "ASC", supplier.Id, string.Empty });
            if (plans != null)
            {
                foreach (Plan plan in plans)
                {
                    PlanCommentCollection comments = PlanCommentUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME,
                        PlanCommentManager.FIND_PLANCOMMENT, new object[] { 0, 0, "", "", plan.Id, "External" });
                    if (comments != null)
                    {
                        foreach (PlanComment comment in comments)
                        {
                            if (comment.Submitted != "Y")
                                count++;
                        }
                    }
                }
            }

            PlanSubcontractorCollection planSubs = PlanSubcontractorUtility.FindByCriteria(
                ConstantUtility.RFD_DATASOURCE_NAME,
                PlanSubcontractorManager.FIND_BY_SUPPLIER,
                new object[] { 0, 0, "Company", "ASC", supplier.Id, string.Empty });
            if (planSubs != null)
            {
                foreach (PlanSubcontractor planSub in planSubs)
                {
                    PlanSubcontractorCommentCollection comments = PlanSubcontractorCommentUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME,
                        PlanSubcontractorCommentManager.FIND_PLANSUBCONTRACTORCOMMENT, new object[] { 0, 0, "", "", planSub.Id, "External" });
                    if (comments != null)
                    {
                        foreach (PlanSubcontractorComment comment in comments)
                        {
                            if (comment.Submitted != "Y")
                                count++;
                        }
                    }
                }
            }



            return count;
        }

        public static void ExpandAll(TreeNode node)
        {
            if (node == null) return;

            node.Expanded = true;
            while (node.Parent != null)
            {
                node = node.Parent;
                node.Expanded = true;
            }
        }

        public static TreeNode FindNode(TreeNode treeNode, string nodeText)
        {
            TreeNode n = null;
            foreach (TreeNode tn in treeNode.ChildNodes)
            {
                if (tn.Text == nodeText)
                {
                    return tn;
                }
            }
            return n;
        }


        public static void BarcodeEncryption(string strIn, int int1, int int2, out string strOut)
        {
            strOut = strIn + "-" + int1.ToString() + "-" + int2.ToString();
        }

        public static void BarcodeDecryption(string strIn, out int int1, out int int2, out string strOut)
        {
            string[] strs = strIn.Split('-');
            strOut = strs[0];
            int1 = ConvertUtility.ConvertInt(strs[1]);
            int2 = ConvertUtility.ConvertInt(strs[2]);
        }

        public static double CalculateVariance(double num1, double num2)
        {
            double variance = 0;

            if (num1 == 0 && num2 == 0)
                variance = 0;
            else if (num2 == 0)
                variance = 1;
            else
                variance = Math.Round((num1 - num2) / num2, 2);

            return variance;
        }

        public static string LimpaSqlWhere(string where)
        {
            int numFaltaFechar = 0; //unclosed parenthesis
            char[] wherearr = where.ToCharArray();
            for (int i = 0; i < wherearr.Length; i++)
            {
                if (wherearr[i] == '(') numFaltaFechar++;
                if (wherearr[i] == ')') numFaltaFechar--;

                if (numFaltaFechar < 0)
                { //if unclosed falls below 0 add '(' to the beginning   
                    where = '(' + where;
                    numFaltaFechar = 0;
                }

            }
            if (numFaltaFechar > 0)
                where = where + new String(')', numFaltaFechar); //add ')' for each unclosed   counted above 

            bool substAlgo = true;
            while (substAlgo)
            {
                substAlgo = false;
                //remove unnecessary spaces 
                while (where.IndexOf(" (") != -1)
                {
                    where = where.Replace(" (", "(");
                    substAlgo = true;
                }
                while (where.IndexOf("( ") != -1)
                {
                    where = where.Replace("( ", "(");
                    substAlgo = true;
                }
                while (where.IndexOf(" )") != -1)
                {
                    where = where.Replace(" )", ")");
                    substAlgo = true;
                }
                while (where.IndexOf(") ") != -1)
                {
                    where = where.Replace(") ", ")");
                    substAlgo = true;
                }

                //remove bad union clauses 
                while (where.IndexOf("(and ") != -1)
                {
                    where = where.Replace("(and ", "(");
                    substAlgo = true;
                }
                while (where.IndexOf("(or ") != -1)
                {
                    where = where.Replace("(or ", "(");
                    substAlgo = true;
                }
                while (where.IndexOf("and)") != -1)
                {
                    where = where.Replace("and)", ")");
                    substAlgo = true;
                }
                while (where.IndexOf("or)") != -1)
                {
                    where = where.Replace("or)", ")");
                    substAlgo = true;
                }

                //remove parentese vazio
                //while (where.IndexOf("()") != -1)
                //{
                //    where = where.Replace("()", "");
                //    substAlgo = true;
                //}

                while (where.IndexOf("(and)") != -1)
                {
                    where = where.Replace("(and)", "");
                    substAlgo = true;
                }
                while (where.IndexOf("(or)") != -1)
                {
                    where = where.Replace("(or)", "");
                    substAlgo = true;
                }
                while (where.IndexOf(")and)") != -1)
                {
                    where = where.Replace(")and)", "))");
                    substAlgo = true;
                }
                while (where.IndexOf(")or)") != -1)
                {
                    where = where.Replace(")or)", "))");
                    substAlgo = true;
                }
                while (where.IndexOf("(and(") != -1)
                {
                    where = where.Replace("(and(", "((");
                    substAlgo = true;
                }
                while (where.IndexOf("(or(") != -1)
                {
                    where = where.Replace("(or(", "((");
                    substAlgo = true;
                }
                while (where.IndexOf("andand") != -1)
                {
                    where = where.Replace("andand", "and");
                    substAlgo = true;
                }
                while (where.IndexOf("oror") != -1)
                {
                    where = where.Replace("oror", "or");
                    substAlgo = true;
                }
                while (where.IndexOf("andor") != -1)
                {
                    where = where.Replace("andor", "and");
                    substAlgo = true;
                }
                while (where.IndexOf("orand") != -1)
                {
                    where = where.Replace("orand", "or");
                    substAlgo = true;
                }
            }
            //tira sujeira que pode aparecer no inicio e no fim do where.
            if (where.EndsWith(")and") || where.EndsWith("(and") || where.EndsWith("and"))
                where = where.TrimEnd(("and".ToCharArray()));
            if (where.EndsWith(")or") || where.EndsWith("(or") || where.EndsWith(" or"))
                where = where.TrimEnd(("or".ToCharArray()));
            if (where.StartsWith("and(") || where.StartsWith("and)") || where.StartsWith("and"))
                where = where.TrimStart(("and".ToCharArray()));
            if (where.StartsWith("or(") || where.StartsWith("or)") || where.StartsWith(" or"))
                where = where.TrimStart(("or".ToCharArray()));

            if (where != "")
                return " (" + where + ") ";
            return "";
        }

        public static bool IsRenewable(Supplier supplier)
        {
            SupplierStatus supplierQualStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_QUALIFICATION);
            SupplierStatus supplierCertStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);

            DateTime qualExpDate = DateTime.MinValue;
            DateTime certExpDate = DateTime.MinValue;
            DateTime qualAdminClosedDate = DateTime.MinValue;
            DateTime certAdminClosedDate = DateTime.MinValue;
            DateTime qualDenyDate = DateTime.MinValue;
            DateTime certDenyDate = DateTime.MinValue;
            DateTime disqualEndDate = DateTime.MinValue;

            string xml = "<ArrayOfDynamicProperty>";
            xml += "<DynamicProperty PropertyName=\"QualifiedDate\" />";
            xml += "<DynamicProperty PropertyType = \"\" PropertyName=\"CertifiedDate\" />";
            xml += "<DynamicProperty PropertyName=\"QualAdminClosedDate\" />";
            xml += "<DynamicProperty PropertyName=\"CertAdminClosedDate\" />";
            xml += "<DynamicProperty PropertyName=\"QualDenyDate\" />";
            xml += "<DynamicProperty PropertyName=\"CertDenyDate\" />";
            xml += "<DynamicProperty PropertyName=\"DisqualEndDate\" />";
            xml += "</ArrayOfDynamicProperty>";
            DynamicPropertyCollection properties = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_PROPERTIES,
                new object[] { "Supplier", supplier.Id, xml });
            if (properties != null)
            {
                DynamicProperty QualifiedDate = properties.Find("QualifiedDate");
                qualExpDate = QualifiedDate.PropertyDate == new DateTime(1900, 1, 1) ? DateTime.MinValue : QualifiedDate.PropertyDate;
                DynamicProperty CertifiedDate = properties.Find("CertifiedDate");
                certExpDate = CertifiedDate.PropertyDate == new DateTime(1900, 1, 1) ? DateTime.MinValue : CertifiedDate.PropertyDate;
                DynamicProperty QualAdminClosedDate = properties.Find("QualAdminClosedDate");
                qualAdminClosedDate = QualAdminClosedDate.PropertyDate == new DateTime(1900, 1, 1) ? DateTime.MinValue : QualAdminClosedDate.PropertyDate;
                DynamicProperty CertAdminClosedDate = properties.Find("CertAdminClosedDate");
                certAdminClosedDate = CertAdminClosedDate.PropertyDate == new DateTime(1900, 1, 1) ? DateTime.MinValue : CertAdminClosedDate.PropertyDate;
                DynamicProperty QualDenyDate = properties.Find("QualDenyDate");
                qualDenyDate = QualDenyDate.PropertyDate == new DateTime(1900, 1, 1) ? DateTime.MinValue : QualDenyDate.PropertyDate;
                DynamicProperty CertDenyDate = properties.Find("CertDenyDate");
                certDenyDate = CertDenyDate.PropertyDate == new DateTime(1900, 1, 1) ? DateTime.MinValue : CertDenyDate.PropertyDate;
                DynamicProperty DisqualEndDate = properties.Find("DisqualEndDate");
                disqualEndDate = DisqualEndDate.PropertyDate == new DateTime(1900, 1, 1) ? DateTime.MinValue : DisqualEndDate.PropertyDate;
                //DynamicProperty DecertEndDate=
            }


            bool isRenew = false;

            //////if (supplierQualStatus != null)
            //////{
            //////    if (supplierCertStatus == null
            //////        || supplierCertStatus.Status == CertificationStatusType.Expired.Description
            //////        || supplierCertStatus.Status == CertificationStatusType.Decertified.Description
            //////        || supplierCertStatus.Status == CertificationStatusType.Rescinded.Description
            //////        || supplierCertStatus.Status == CertificationStatusType.Withdrawn.Description
            //////        || supplierCertStatus.Status == CertificationStatusType.Certified.Description
            //////        || supplierCertStatus.Status == CertificationStatusType.Disqualified.Description
            //////        || supplierCertStatus.Status == CertificationStatusType.CertAdminClosed.Description
            //////        || supplierCertStatus.Status == CertificationStatusType.Deny.Description)
            //////    {

            //////        if (supplierQualStatus.Status == SupplierStatusType.Expired.Description
            //////            || supplierQualStatus.Status == SupplierStatusType.Rescinded.Description
            //////            || supplierQualStatus.Status == SupplierStatusType.Withdrawn.Description)
            //////        {

            //////            isRenew = true;
            //////        }


            //////        if (supplierQualStatus.Status == SupplierStatusType.Qualified.Description
            //////            && qualExpDate != DateTime.MinValue
            //////            && qualExpDate.CompareTo(DateTime.Now.AddMonths(6)) <= 0
            //////            && disqualEndDate.CompareTo(qualExpDate) <= 0)
            //////        {
            //////            isRenew = true;

            //////        }

            //////        if (supplierQualStatus.Status == SupplierStatusType.Disqualified.Description
            //////            && disqualEndDate != DateTime.MinValue
            //////            && disqualEndDate.CompareTo(DateTime.Now.AddMonths(6)) <= 0)
            //////        {
            //////            isRenew = true;
            //////        }



            //////        if ((supplierQualStatus.Status == SupplierStatusType.AdministrativelyClosed.Description && qualAdminClosedDate.CompareTo(DateTime.Now.AddMonths(-6)) < 0)
            //////            || (supplierQualStatus.Status == SupplierStatusType.Deny.Description && qualDenyDate.CompareTo(DateTime.Now.AddMonths(-6)) < 0))
            //////        {
            //////            isRenew = true;
            //////        }
            //////    }
            //////}
            //////else if (supplierCertStatus != null)
            //////{
            //////    if (supplierCertStatus.Status == CertificationStatusType.Expired.Description
            //////        || supplierCertStatus.Status == CertificationStatusType.Decertified.Description
            //////        || supplierCertStatus.Status == CertificationStatusType.Rescinded.Description
            //////        || supplierCertStatus.Status == CertificationStatusType.Withdrawn.Description)
            //////    {

            //////        isRenew = true;
            //////    }


            //////    if (supplierCertStatus.Status == CertificationStatusType.Certified.Description
            //////        && certExpDate != DateTime.MinValue
            //////        && certExpDate.CompareTo(DateTime.Now.AddMonths(6)) <= 0
            //////        && disqualEndDate.CompareTo(certExpDate) <= 0)
            //////    {
            //////        isRenew = true;

            //////    }

            //////    if (supplierCertStatus.Status == CertificationStatusType.Disqualified.Description
            //////        && disqualEndDate != DateTime.MinValue
            //////        && disqualEndDate.CompareTo(DateTime.Now.AddMonths(6)) <= 0)
            //////    {
            //////        isRenew = true;
            //////    }

            //////    if ((supplierCertStatus.Status == CertificationStatusType.CertAdminClosed.Description && certAdminClosedDate.CompareTo(DateTime.Now.AddMonths(-6)) < 0)
            //////        || (supplierCertStatus.Status == CertificationStatusType.Deny.Description && certDenyDate.CompareTo(DateTime.Now.AddMonths(-6)) < 0))
            //////    {
            //////        isRenew = true;
            //////    }
            //////}




            //In the above scenarios the external Requal/Recert link will be available. 
            //(Current functionality). Firms with Disqualified status will be able to Requalify, Recertify within six months of the end of the 
            //Disqualification using the link on the external site.  

            if (supplierQualStatus != null)
            {
                if (isRenew == false && (
                    ((supplierQualStatus.Status == SupplierStatusType.Disqualified.Description) &&
                    disqualEndDate != DateTime.MinValue && disqualEndDate.CompareTo(DateTime.Now.AddMonths(6)) <= 0)
                    || (
                    ((supplierQualStatus.Status == SupplierStatusType.Qualified.Description) &&
                    qualExpDate != DateTime.MinValue && qualExpDate.CompareTo(DateTime.Now.AddMonths(6)) <= 0)
                || supplierQualStatus.Status == SupplierStatusType.Expired.Description)))
                {
                    isRenew = true;
                }
            }

            if (supplierCertStatus != null)
            {
                if (isRenew == false && (
                                        (supplierCertStatus.Status == CertificationStatusType.Certified.Description && certExpDate != DateTime.MinValue && certExpDate.CompareTo(DateTime.Now.AddMonths(6)) <= 0)
                                        || supplierCertStatus.Status == CertificationStatusType.Expired.Description
                    )
                    )
                {
                    isRenew = true;
                }
            }
            return isRenew;
        }


        public static string SBSCertificateToolTip(VendorSBSCertificationCollection certs)
        {
            string mbeString = string.Empty;
            string wbeString = string.Empty;
            string lbeString = string.Empty;
            string m_wbeString = string.Empty;
            string mwbeString = string.Empty;

            foreach (var certificate in certs)
            {
                VendorSBSCertification cert = (VendorSBSCertification)certificate;

                switch (cert.Certification)
                {
                    case "MBE": mbeString = GenerateCertificateMessage(cert); break;
                    case "WBE": wbeString = GenerateCertificateMessage(cert); break;
                    case "LBE": lbeString = GenerateCertificateMessage(cert); break;
                    case "M/WBE": m_wbeString = GenerateCertificateMessage(cert); break;
                    case "MWBE": mwbeString = GenerateCertificateMessage(cert); break;
                }                
            }

            return mbeString + (mbeString == string.Empty ? "" : "\n") +
                   wbeString + (wbeString == string.Empty ? "" : "\n") +
                   lbeString + (lbeString == string.Empty ? "" : "\n") +
                   m_wbeString + (m_wbeString == string.Empty ? "" : "\n") +
                   mwbeString;
        }

        private static string GenerateCertificateMessage(VendorSBSCertification cert)
        {
            return string.Format("{0}: ", cert.Certification) + 
                   (cert.CertifiedDate != new DateTime(1900, 1, 1) ? cert.CertifiedDate.ToShortDateString() : "") + " - " + 
                   (cert.ExpirationDate != new DateTime(1900, 1, 1) ? cert.ExpirationDate.ToShortDateString() : "");
        }
    }

    public static class ExtensionMethods
    {

        public static string RoleList(this VendorContact vendorContact)
        {
            if (vendorContact == null || vendorContact.Roles == null || vendorContact.Roles.Count == 0)
                return "";

            string roles = "";

            foreach (VendorContactRole role in vendorContact.Roles)
            {
                VendorContactRoleType roletype = (VendorContactRoleType)role.VendorContactRoleId;
                if (roletype == null) continue;
                roles += ", " + roletype.Description;
            }
            if (roles.Length > 2)
                roles = roles.Substring(2);
            return roles;
        }

        public static string SupplierStatusValue(this Supplier supplier, string statusName)
        {
            if (supplier == null || supplier.SupplierStatuses == null) return "";
            SupplierStatus status = supplier.SupplierStatuses.FindByType(statusName);
            if (status == null) return "";

            return status.Status;
        }

        public static bool HasAsbestosAbatement(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("HasAsbestosAbatement") == "Y")
                return true;
            return false;
        }
        public static bool HasAsbestosConsultant(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("HasAsbestosConsultant") == "Y")
                return true;
            return false;
        }
        public static bool HasLabTesting(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("HasLabTesting") == "Y")
                return true;
            return false;
        }
        public static bool IsShortForm(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsShortForm") == "Y")
                return true;
            return false;
        }
        public static bool HasMentorTrades(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("HasMentorTrades") == "Y")
                return true;
            return false;
        }
        public static bool NoSafety(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("NoSafety") == "Y")
                return true;
            return false;
        }
        public static bool IsAE(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsAE") == "Y")
                return true;
            return false;
        }
        public static bool IsAEApproved(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsAEApproved") == "Y")
                return true;
            return false;
        }
        public static bool IsProfService(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsProfService") == "Y")
                return true;
            return false;
        }
        public static bool IsProfServiceApproved(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsProfServiceApproved") == "Y")
                return true;
            return false;
        }
        public static bool HasApprenticeship(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("HasApprenticeship") == "Y")
                return true;
            return false;
        }
        public static bool HasFinancialSection1(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("HasFinancialSection1") == "Y")
                return true;
            return false;
        }
        public static bool HasFinancialSection2(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("HasFinancialSection2") == "Y")
                return true;
            return false;
        }
        public static bool HasFinancialSection3(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("HasFinancialSection3") == "Y")
                return true;
            return false;
        }
        public static bool IsPaper(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsPaper") == "Y")
                return true;
            return false;
        }
        public static bool IsPaperQual(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsPaperQual") == "Y")
                return true;
            return false;
        }
        public static bool IsPaperCert(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsPaperCert") == "Y")
                return true;
            return false;
        }
        public static bool IsQual(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsQual") == "Y")
                return true;
            return false;
        }
        public static bool IsCert(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsCert") == "Y")
                return true;
            return false;
        }
        public static bool IsBoth(this Supplier supplier)
        {
            return supplier.IsCert() && supplier.IsQual();
        }
        public static bool IsNonAppplicant(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsNonAppplicant") == "Y")
                return true;
            return false;
        }
        public static bool IsMBE(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsMBE") == "Y")
                return true;
            return false;
        }
        public static bool IsWBE(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsWBE") == "Y")
                return true;
            return false;
        }
        public static bool IsLBE(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsLBE") == "Y")
                return true;
            return false;
        }
        public static bool IsLbeArea(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsLbeArea") == "Y")
                return true;
            return false;
        }
        public static bool IsLbeEmployee(this Supplier supplier)
        {
            if (supplier.SupplierStatusValue("IsLbeEmployee") == "Y")
                return true;
            return false;
        }
        public static long FinancialCapacity(this Supplier supplier)
        {
            long financialCapacity = 0;

            try
            {
                var currencies = supplier.Currency.Split(new char[] { '|' });
                financialCapacity = ConvertUtility.ConvertLong(currencies[0]);
            }
            catch
            {
                financialCapacity = ConvertUtility.ConvertLong(supplier.Currency);
            }

            return financialCapacity;
        }
        public static string CertStatus(this Supplier supplier)
        {
            if (supplier.SupplierStatuses == null) return "";
            SupplierStatus status = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);
            if (status == null) return "";
            return status.Status;
        }
        public static bool IsCertStatus(this Supplier supplier, CertificationStatusType status)
        {
            return supplier.CertStatus() == status.Description;
        }
        public static bool IsCertComplete(this Supplier supplier)
        {
            return supplier.CertStatus() == "" || supplier.CertStatus() != CertificationStatusType.NewCertification.Description;
        }
        public static string QualStatus(this Supplier supplier)
        {
            if (supplier.SupplierStatuses == null) return "";
            SupplierStatus status = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_QUALIFICATION);
            if (status == null) return "";
            return status.Status;
        }
        public static bool IsQualStatus(this Supplier supplier, SupplierStatusType status)
        {
            return supplier.QualStatus() == status.Description;
        }
        public static bool IsQualComplete(this Supplier supplier)
        {
            return supplier.QualStatus() == "" || supplier.QualStatus() != SupplierStatusType.NewPrequalification.Description;
        }
        public static bool IsBothComplete(this Supplier supplier)
        {
            return supplier.IsCertComplete() && supplier.IsQualComplete();
        }



        public static void AddApprovalType(this Package package, string approvaltype)
        {
            package.ApprovalType += "|" + approvaltype;
            string[] approvals = package.ApprovalType.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
            package.ApprovalType = "";
            foreach (var approval in approvals.Distinct().OrderBy(a => a).ToList())
                package.ApprovalType += approval + "|";
            package.ApprovalType.Trim(new char[] { '|' });
        }
        public static void RemoveApprovalType(this Package package, string approvaltype)
        {
            package.ApprovalType = package.ApprovalType.Replace(approvaltype, "");
            string[] approvals = package.ApprovalType.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
            package.ApprovalType = "";
            foreach (var approval in approvals.Distinct().OrderBy(a => a).ToList())
                package.ApprovalType += approval + "|";
            package.ApprovalType.Trim(new char[] { '|' });
        }

        public static void RemoveMenuItem(this MenuCollection menus, int MenuItemId)
        {
            foreach (Menu m in menus)
            {
                if (m.Id == MenuItemId)
                {
                    menus.Remove(m);
                    return;
                }
                foreach (Menu mm in m.SubMenus)
                {
                    if (mm.Id == MenuItemId)
                    {
                        m.SubMenus.Remove(mm);
                        return;
                    }
                }
            }
        }
        public static void RemoveMenuItemWithText(this MenuCollection menus, string MenuText)
        {
            foreach (Menu m in menus)
            {
                if (m.Text == MenuText)
                {
                    menus.Remove(m);
                    return;
                }
                foreach (Menu mm in m.SubMenus)
                {
                    if (mm.Text == MenuText)
                    {
                        m.SubMenus.Remove(mm);
                        return;
                    }
                }
            }
        }


        public static void SetMenusComplete(this MenuCollection menus, SupplierPropertyCollection supplierProperties, int CheckListId)
        {
            if (supplierProperties == null) return;
            if (menus == null) return;

            foreach (SupplierProperty sp in supplierProperties)
            {
                if (sp.PropertyId < ConstantUtility.CHECKLISTID) continue;

                foreach (Menu m in menus)
                {
                    if (sp.PropertyId == m.Id + CheckListId)
                    {
                        if (sp.PropertyText == "Y")
                            m.ImgLeft = "~/Images/icon-complete.gif";
                        else if (sp.PropertyText == "N")
                            m.ImgLeft = "~/Images/icon-pcomplete.gif";
                        continue;
                    }
                    foreach (Menu mm in m.SubMenus)
                        if (sp.PropertyId == mm.Id + CheckListId)
                        {
                            if (sp.PropertyText == "Y")
                                mm.ImgLeft = "~/Images/icon-complete.gif";
                            else if (sp.PropertyText == "N")
                                mm.ImgLeft = "~/Images/icon-pcomplete.gif";
                        }
                }//end foreach
            }//end foreach

            foreach (Menu m in menus)
            {
                if (m.SubMenus.Count == 0) continue;

                int knt = 0;
                foreach (Menu mm in m.SubMenus)
                {
                    if (mm.ImgLeft == "~/Images/icon-complete.gif")
                        knt += 2;
                    else if (mm.ImgLeft == "~/Images/icon-pcomplete.gif")
                        knt++;
                }

                if (m.SubMenus.Count > 0 && m.SubMenus.Count * 2 == knt)
                    m.ImgLeft = "~/Images/icon-complete.gif";
                else if (knt > 0)
                    m.ImgLeft = "~/Images/icon-pcomplete.gif";
            }

        }
        //This is to datetime extension to handle 1/1/1900 values.
        public static string ToNullShortDateString(this DateTime Value)
        {
            if (Value.ToShortDateString() == "1/1/1900")
            {
                return "";
            }
            else
            {
                return Value.ToShortDateString();
            }
        }
        

    }
}
