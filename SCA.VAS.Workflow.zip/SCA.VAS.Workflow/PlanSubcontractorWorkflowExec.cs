#region Copyright
/*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Configuration;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

using SCA.VAS.BusinessLogic.Template.Utilities;
using SCA.VAS.BusinessLogic.Template;
using SCA.VAS.ValueObjects.Template;

using RfcProject = SCA.VAS.ValueObjects.Rfd.Project;
using RfcProjectUtility = SCA.VAS.BusinessLogic.Rfd.Utilities.ProjectUtility;
using PlanSubcontractor = SCA.VAS.ValueObjects.Rfd.PlanSubcontractor;
using PlanSubcontractorUtility = SCA.VAS.BusinessLogic.Rfd.Utilities.PlanSubcontractorUtility;
#endregion Reference

namespace SCA.VAS.Workflow
{
    public class PlanSubcontractorWorkflowExec
    {
        #region Private Member
        private static string prefixDbName = string.Empty;
        private static int userId = 0;
        private static string workflowType = ConstantUtility.WORKFLOW_SUP;
        public static string WorkflowType
        {
            set { workflowType = value; }
        }
        #endregion

        #region Constructor
        public PlanSubcontractorWorkflowExec()
        {
        }
        static PlanSubcontractorWorkflowExec()
        {
        }
        #endregion Constructor

        #region Private Method
        private static PlanSubcontractor GetPlanSubcontractorWorkflow(PlanSubcontractor planSubcontractor)
        {
            if (planSubcontractor == null) return planSubcontractor;

            if (planSubcontractor.WorkflowId == 0)
            {
                WorkflowList workflow = WorkflowListUtility.GetByName(
                    prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                    workflowType, 0);
                if (workflow != null)
                    planSubcontractor.WorkflowId = workflow.Id;
            }

            if (planSubcontractor.TransactionId == 0)
            {
                planSubcontractor.TransactionId = WorkflowExec.CreateWorkflowHistory(planSubcontractor.WorkflowId);
                PlanSubcontractorUtility.UpdateTransactionId(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                    planSubcontractor.Id, planSubcontractor.TransactionId);

                NodeAction(planSubcontractor, "New Workflow");
            }
            return planSubcontractor;
        }
        #endregion

        #region Workflow Control
        public static PlanSubcontractor InitialPlanSubcontractorWorkflow(PlanSubcontractor planSubcontractor, string workflowName)
        {
            workflowType = workflowName;
            return GetPlanSubcontractorWorkflow(planSubcontractor);
        }

        public static User GetLastApprover(PlanSubcontractor planSubcontractor)
        {
            planSubcontractor = GetPlanSubcontractorWorkflow(planSubcontractor);
            if (planSubcontractor == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(planSubcontractor.TransactionId);
            if (workflowHistory == null) return null;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return null;

            return UserUtility.Get(prefixDbName + ConstantUtility.USER_DATASOURCE_NAME,
                workflowHistory.ApprovalUserId);
        }

        public static int PlanSubcontractorWorkflow(PlanSubcontractor planSubcontractor, string systemAction, string comments, ref string errmsg, ref string url)
        {
            planSubcontractor = GetPlanSubcontractorWorkflow(planSubcontractor);
            if (planSubcontractor == null) return 0;

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_SYSTEMNAME,
                new object[] { planSubcontractor.WorkflowId, systemAction });
            if (workflowNodes == null || workflowNodes.Count == 0) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(planSubcontractor.TransactionId);
            if (workflowHistory == null)
                return 0;

            int actionId = 0;
            for (int i = 0; i < workflowNodes.Count; i++)
            {
                if (workflowHistory.CurrentNodeId == workflowNodes[i].NodeFromId)
                {
                    actionId = workflowNodes[i].Id;
                    break;
                }
            }
            return PlanSubcontractorWorkflow(planSubcontractor, actionId, comments, ref errmsg, ref url);
        }

        public static int PlanSubcontractorWorkflow(PlanSubcontractor planSubcontractor, int actionId, string comments, ref string errmsg, ref string url)
        {
            planSubcontractor = GetPlanSubcontractorWorkflow(planSubcontractor);
            if (planSubcontractor == null) return 0;
            if (actionId == 0) return planSubcontractor.TransactionId;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(planSubcontractor.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowNode workflowNode = WorkflowNodeUtility.Get(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
            if (workflowNode == null)
                return 0;
            if (workflowHistory.CurrentNodeId != workflowNode.NodeFromId)
                return 0;

            // condition proccessing
            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNode.Id });

            TextReader reader = XmlUtility.Serialize(planSubcontractor);
            XPathDocument doc = new XPathDocument(reader);
            XPathNavigator nav = doc.CreateNavigator();

            errmsg = string.Empty;
            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count == 0)
                    {
                        errmsg += workflowCondition.ErrorMessage + "<br>";
                    }
                }
            }
            if (errmsg != string.Empty) return 0;

            //Workflow topologic
            bool approval = true;
            switch (workflowNode.Action1)
            {
                case "One":
                    break;
                case "Owner":
                    //if (planSubcontractor.BuyerId != userId)
                    //    errmsg = "Only RFx owner / Creator can do this step";
                    break;
                case "All":
                case "Majority":
                case "Count":
                    WorkflowHistoryCollection workflowHistories = WorkflowHistoryUtility.FindByCriteria(
                        prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                        new object[] { planSubcontractor.TransactionId });

                    WorkflowHistoryCollection currentHistories = new WorkflowHistoryCollection();
                    if (workflowHistories != null)
                    {
                        for (int i = workflowHistories.Count - 1; i >= 0; i--)
                        {
                            if (workflowHistories[i].IsActive == 1) break;
                            if (workflowHistories[i].CurrentNodeId != actionId) continue;
                            if (workflowHistories[i].ApprovalUserId == userId)
                            {
                                errmsg = "You already approved this step";
                                return 0;
                            }
                            currentHistories.Add(workflowHistories[i]);
                        }
                    }

                    // Create a history from new approval
                    WorkflowHistory approvalHistory = WorkflowHistoryUtility.CreateObject();
                    approvalHistory.TransactionHeaderId = planSubcontractor.TransactionId;
                    approvalHistory.WorkflowId = planSubcontractor.WorkflowId;
                    approvalHistory.CurrentNodeId = actionId;
                    approvalHistory.ApprovalUserId = WorkflowExec.GetUserId();
                    approvalHistory.ApprovalConditionId = 1;
                    approvalHistory.CreatedBy = workflowHistory.ApprovalUserId;
                    approvalHistory.CreatedType = WorkflowExec.GetUserType();
                    WorkflowHistoryUtility.Create(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, approvalHistory);

                    int approvalKnt = currentHistories.Count + 1;
                    switch (workflowNode.Action1)
                    {
                        case "All":
                            //if (approvalKnt < planSubcontractorUsers.Count)
                            //    approval = false;
                            break;
                        case "Majority":
                            //if (approvalKnt < planSubcontractorUsers.Count / 2)
                            //    approval = false;
                            break;
                        case "Count":
                            int knt = ConvertUtility.ConvertInt(workflowNode.Action2);
                            if (approvalKnt < knt)
                                approval = false;
                            break;
                    }
                    break;

                //case "Sequence":
                //    break;
                //case "Timer":
                //    //approve7.Checked = true;
                //    //approveKnt7.Text = workflowNode.Action2;
                //    break;
            }

            if (!approval || errmsg != string.Empty) return planSubcontractor.TransactionId;

            //Action proccessing
            WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE,
                new object[] { workflowNode.Id });

            if (workflowActions != null)
            {
                foreach (WorkflowAction workflowAction in workflowActions)
                {
                    switch (workflowAction.Type)
                    {
                        //Send Email
                        case 1:
                            CommonUtility.PlanSubcontractorSendEmail(planSubcontractor, workflowHistory, workflowAction.FunctionName, comments, prefixDbName);
                            break;

                        //Action
                        case 2:
                            PlanSubcontractorAction(planSubcontractor, workflowAction.FunctionName);
                            break;

                        //Redirect page
                        case 3:
                            url = workflowAction.FunctionName;
                            break;
                    }
                }
            }

            if (workflowNode.NodeToId > 0)
            {
                WorkflowNode nextNode = WorkflowNodeUtility.Get(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode.NodeToId);
                WorkflowExec.WorkflowNextStatus(workflowNode.WorkflowId, nextNode.Name, workflowHistory.CurrentNodeId, planSubcontractor.TransactionId, comments);

                //if (comments.Trim() != string.Empty)
                //{
                //    Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.RFD_DATASOURCE_NAME,
                //        "PlanSubcontractor", planSubcontractor.Id.ToString());
                //    User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

                //    VendorComment vendorComment = VendorCommentUtility.CreateObject();
                //    vendorComment.UserId = user.Id;
                //    vendorComment.VendorId = vendor.Id;
                //    vendorComment.Comments = "Workflow Comments: " + comments;
                //    vendorComment.Type = "User";
                //    vendorComment.ChangeUser = user.FullName;

                //    VendorCommentUtility.Create(ConstantUtility.RFD_DATASOURCE_NAME, vendorComment);
                //}

                NodeAction(planSubcontractor, comments);
            }

            return planSubcontractor.TransactionId;
        }

        public static int PlanSubcontractorWorkflow(PlanSubcontractor planSubcontractor, string nextStatus, string comments)
        {
            planSubcontractor = GetPlanSubcontractorWorkflow(planSubcontractor);
            if (planSubcontractor == null) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(planSubcontractor.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowExec.WorkflowNextSystemStatus(planSubcontractor.WorkflowId, nextStatus, workflowHistory.CurrentNodeId, planSubcontractor.TransactionId, comments);

            //if (comments.Trim() != string.Empty)
            //{
            //    Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.RFD_DATASOURCE_NAME,
            //        "PlanSubcontractor", planSubcontractor.Id.ToString());
            //    User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

            //    VendorComment vendorComment = VendorCommentUtility.CreateObject();
            //    vendorComment.VendorId = vendor.Id;
            //    vendorComment.Comments = "Workflow Comments: " + comments;
            //    if (user != null)
            //    {
            //        vendorComment.UserId = user.Id;
            //        vendorComment.Type = "User";
            //        vendorComment.ChangeUser = user.FullName;
            //    }

            //    VendorCommentUtility.Create(ConstantUtility.RFD_DATASOURCE_NAME, vendorComment);
            //}

            NodeAction(planSubcontractor, comments);

            return planSubcontractor.TransactionId;
        }

        public static WorkflowConditionCollection PlanSubcontractorWorkflowConditionTest(PlanSubcontractor planSubcontractor, int workflowNodeId)
        {
            planSubcontractor = GetPlanSubcontractorWorkflow(planSubcontractor);
            if (planSubcontractor == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(planSubcontractor.TransactionId);
            if (workflowHistory == null)
                return null;

            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNodeId });

            XPathDocument doc = new XPathDocument(XmlUtility.Serialize(planSubcontractor));
            XPathNavigator nav = doc.CreateNavigator();

            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count > 0)
                        workflowCondition.Status = 1;
                }
            }
            return workflowConditions;
        }
        #endregion Workflow Control

        #region Workflow Node Action
        private static void NodeAction(PlanSubcontractor planSubcontractor, string comments)
        {
            planSubcontractor = GetPlanSubcontractorWorkflow(planSubcontractor);
            if (planSubcontractor == null) return;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(
                planSubcontractor.TransactionId);

            int status = ((PlanSubcontractorStatusType)workflowHistory.CurrentNode.Name.Trim()).Id;

            if (status == 0 || status == planSubcontractor.Status) return;
            PlanSubcontractorUtility.UpdateStatus(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME, planSubcontractor.Id, status, workflowHistory.CurrentNode.Name);

            // automatic step
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { planSubcontractor.WorkflowId, "UserStepId", "ASC" });
            if (workflowNodes != null)
            {
                for (int i = 0; i < workflowNodes.Count; i++)
                {
                    if (workflowNodes[i].Type != 1 || workflowNodes[i].TimeToSkip != 1 ||
                        workflowHistory.CurrentNodeId != workflowNodes[i].NodeFromId)
                        continue;

                    string errmsg = string.Empty;
                    string url = string.Empty;
                    PlanSubcontractorWorkflow(planSubcontractor, workflowNodes[i].Id, comments, ref errmsg, ref url);
                }
            }
        }
        #endregion Workflow Node Action

        #region Batch Jobs
        #endregion Batch Jobs

        #region PlanSubcontractor Action
        private static void PlanSubcontractorAction(PlanSubcontractor planSubcontractor, string actionName)
        {
            string msg = string.Empty;
            string url = string.Empty;
            string tempType = workflowType;

            switch (actionName)
            {
                case "DocumentsAvailableAction":
                    break;
            }
            WorkflowType = tempType;
        }
        #endregion
    }
}
