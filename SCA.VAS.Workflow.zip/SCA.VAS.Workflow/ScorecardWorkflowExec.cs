#region Copyright
/*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Configuration;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Scorecard.Utilities;
using SCA.VAS.BusinessLogic.Scorecard;
using SCA.VAS.ValueObjects.Scorecard;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

namespace SCA.VAS.Workflow
{
    public class ScorecardWorkflowExec
    {
        #region Private Member
        private static int userId = 0;
        #endregion

        #region Constructor
        public ScorecardWorkflowExec()
        {
        }
        static ScorecardWorkflowExec()
        {
        }
        #endregion Constructor

        #region Private Method
        private static int GetTransactionId(Scorecard scorecard, string comments)
        {
            if (scorecard.TransactionId == 0)
            {
                scorecard.TransactionId = WorkflowExec.CreateWorkflowHistory(scorecard.WorkflowId);
                ScorecardUtility.UpdateTransactionId(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, scorecard.TransactionId);
            }
            return scorecard.TransactionId;
        }
        #endregion Private Method

        #region Public Method
        public static User GetLastApprover(Scorecard scorecard)
        {
            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(scorecard.TransactionId);
            if (workflowHistory == null) return null;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return null;

            return UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, workflowHistory.CreatedBy);
        }
        #endregion Public Method

        #region Workflow Control
        public static int ScorecardWorkflow(Scorecard scorecard, string systemAction, string comments, ref string errmsg, ref string url)
        {
            int transactionId = GetTransactionId(scorecard, comments);

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_SYSTEMNAME,
                new object[] { scorecard.WorkflowId, systemAction });
            if (workflowNodes == null || workflowNodes.Count == 0) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(scorecard.TransactionId);
            if (workflowHistory == null)
                return 0;

            int actionId = 0;
            for (int i = 0; i < workflowNodes.Count; i++)
            {
                if (workflowHistory.CurrentNodeId == workflowNodes[i].NodeFromId)
                {
                    actionId = workflowNodes[i].Id;
                    break;
                }
            }
            return ScorecardWorkflow(scorecard, actionId, comments, ref errmsg, ref url);
        }

        public static int ScorecardWorkflow(Scorecard scorecard, int actionId, string comments, ref string errmsg, ref string url)
        {
            int transactionId = GetTransactionId(scorecard, comments);
            if (actionId == 0) return transactionId;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(scorecard.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowNode workflowNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
            if (workflowHistory.CurrentNodeId != workflowNode.NodeFromId)
                return 0;

            // condition proccessing
            errmsg = string.Empty;
            WorkflowConditionCollection workflowConditions = ScorecardConditionTest(scorecard, workflowNode.Id);
            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    if (workflowCondition.Status == 0)
                    {
                        errmsg += workflowCondition.ErrorMessage + "<br />";
                    }
                }
            }
            if (errmsg != string.Empty) return 0;

            //Workflow topologic
            bool approval = true;
            switch (workflowNode.Action1)
            {
                case "One":
                    break;
                case "Owner":
                    break;
                case "All":
                case "Majority":
                case "Count":
                    WorkflowHistoryCollection workflowHistories = WorkflowHistoryUtility.FindByCriteria(
                        ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                        new object[] { scorecard.TransactionId });

                    WorkflowHistoryCollection currentHistories = new WorkflowHistoryCollection();
                    if (workflowHistories != null)
                    {
                        for (int i = workflowHistories.Count - 1; i >= 0; i--)
                        {
                            if (workflowHistories[i].IsActive == 1) break;
                            if (workflowHistories[i].CurrentNodeId != actionId) continue;
                            if (workflowHistories[i].ApprovalUserId == userId)
                            {
                                errmsg = "You already approved this step!";
                                return 0;
                            }
                            currentHistories.Add(workflowHistories[i]);
                        }
                    }

                    // Create a history from new approval
                    WorkflowHistory approvalHistory = WorkflowHistoryUtility.CreateObject();
                    approvalHistory.TransactionHeaderId = scorecard.TransactionId;
                    approvalHistory.WorkflowId = scorecard.WorkflowId;
                    approvalHistory.CurrentNodeId = actionId;
                    approvalHistory.ApprovalUserId = WorkflowExec.GetUserId();
                    approvalHistory.ApprovalConditionId = 1;
                    approvalHistory.CreatedBy = workflowHistory.ApprovalUserId;
                    approvalHistory.CreatedType = WorkflowExec.GetUserType();
                    WorkflowHistoryUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, approvalHistory);

                    int approvalKnt = currentHistories.Count + 1;
                    switch (workflowNode.Action1)
                    {
                        case "All":
                            //if (scorecard.Invitees != null && approvalKnt < scorecard.Invitees.Count)
                            //    approval = false;
                            break;
                        case "Majority":
                            //if (approvalKnt < scorecardUsers.Count / 2)
                            //    approval = false;
                            break;
                        case "Count":
                            int knt = ConvertUtility.ConvertInt(workflowNode.Action2);
                            if (approvalKnt < knt)
                                approval = false;
                            break;
                    }
                    break;

                //case "Sequence":
                //    break;
                //case "Timer":
                //    //approve7.Checked = true;
                //    //approveKnt7.Text = workflowNode.Action2;
                //    break;
            }

            if (!approval || errmsg != string.Empty) return scorecard.TransactionId;

            //Action proccessing
            WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE,
                new object[] { workflowNode.Id });

            if (workflowActions != null)
            {
                foreach (WorkflowAction workflowAction in workflowActions)
                {
                    switch (workflowAction.Type)
                    {
                        //Send Email
                        case 1:
                            CommonUtility.ScorecardSendEmail(scorecard, workflowNode, workflowHistory, workflowAction.FunctionName, comments);
                            break;

                        //Action
                        case 2:
                            ScorecardAction(scorecard, workflowAction.FunctionName, comments);
                            break;

                        //Redirect page
                        case 3:
                            url = workflowAction.FunctionName;
                            break;
                    }
                }
            }

            if (workflowNode.NodeToId > 0)
            {
                WorkflowNode nextNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode.NodeToId);
                WorkflowExec.WorkflowNextStatus(workflowNode.WorkflowId, nextNode.Name, workflowHistory.CurrentNodeId, scorecard.TransactionId, comments);
                NodeAction(scorecard, comments);
            }

            return scorecard.TransactionId;
        }

        public static int ScorecardWorkflow(Scorecard scorecard, string nextStatus, string comments)
        {
            int transactionId = GetTransactionId(scorecard, comments);

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(scorecard.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowExec.WorkflowNextSystemStatus(scorecard.WorkflowId, nextStatus, workflowHistory.CurrentNodeId, scorecard.TransactionId, comments);
            NodeAction(scorecard, comments);

            return scorecard.TransactionId;
        }

        public static WorkflowConditionCollection ScorecardConditionTest(Scorecard scorecard, int workflowNodeId)
        {
            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNodeId });

            XPathDocument doc = new XPathDocument(XmlUtility.Serialize(scorecard));
            XPathNavigator nav = doc.CreateNavigator();

            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count > 0)
                        workflowCondition.Status = 1;
                }
            }
            return workflowConditions;
        }
        #endregion Workflow Control

        #region Workflow Node Action
        private static void NodeAction(Scorecard scorecard, string comments)
        {
            int transactionId = GetTransactionId(scorecard, comments);

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(
                scorecard.TransactionId);

            int status = 0;
            ScorecardStatusType scorecardStatusType = workflowHistory.CurrentNode.Action6.Trim();
            if (scorecardStatusType != null)
                status = scorecardStatusType.Id;
            if (status == 0 || status == scorecard.Status) return;

            if (ScorecardUtility.UpdateStatus(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id, status, workflowHistory.CurrentNodeName, WorkflowExec.GetUserId()))
                scorecard.Status = status;

            // automatic step
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { scorecard.WorkflowId, "UserStepId", "ASC" });
            if (workflowNodes != null)
            {
                for (int i = 0; i < workflowNodes.Count; i++)
                {
                    if (workflowNodes[i].Type != 1 || workflowNodes[i].TimeToSkip != 1 ||
                        workflowHistory.CurrentNodeId != workflowNodes[i].NodeFromId)
                        continue;

                    string errmsg = string.Empty;
                    string url = string.Empty;
                    ScorecardWorkflow(scorecard, workflowNodes[i].Id, comments, ref errmsg, ref url);
                }
            }

            //if (workflowHistory.CurrentNode.Action6 == ScorecardStatusType.NewEvaluation.Name)
            //{
            //    if (status == ScorecardStatusType.NewEvaluation.Id && scorecard.ReleaseDate <= DateTime.Now)
            //    {
            //        ScorecardWorkflow(scorecard, ScorecardStatusType.ReleasedEvaluation.Name, "");
            //    }
            //    if (scorecard.ReleaseDate < DateTime.Today.AddDays(1))
            //        WorkflowSchedule.AddScheduleEvent("ScorecardRelease", scorecard.ReleaseDate, scorecard.Id, 0);
            //}
        }
        #endregion Workflow Node Action

        #region Batch Jobs
        #endregion Batch Jobs

        #region Scorecard Action
        private static void ScorecardAction(Scorecard scorecard, string actionName, string comments)
        {
            if (actionName == "ResetCSEvaluation")
            {
                ScorecardInvitee scorecardInvitee = ScorecardInviteeUtility.GetByType(
                    ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id,
                    ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST);
                if (scorecardInvitee != null)
                {
                    string msg = string.Empty;
                    string url = string.Empty;
                    EvaluationWorkflowExec.EvaluationWorkflow(scorecardInvitee, EvaluationAction.Reject.Name,
                        comments, ref msg, ref url);
                }
            }
            else if (actionName == "ResetCCFUEvaluation")
            {
                ScorecardInvitee scorecardInvitee = ScorecardInviteeUtility.GetByType(
                    ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id,
                    ConstantUtility.ROLE_OPERATIONS_MANAGER);
                if (scorecardInvitee != null)
                {
                    string msg = string.Empty;
                    string url = string.Empty;
                    EvaluationWorkflowExec.EvaluationWorkflow(scorecardInvitee, EvaluationAction.Reject.Name,
                        comments, ref msg, ref url);
                }
            }
            else if (actionName == "RejectEvaluation")
            {
                if (scorecard.Invitees != null)
                {
                    foreach (ScorecardInvitee scorecardInvitee in scorecard.Invitees)
                    {
                        string msg = string.Empty;
                        string url = string.Empty;
                        EvaluationWorkflowExec.EvaluationWorkflow(scorecardInvitee, EvaluationAction.Reject.Name,
                            comments, ref msg, ref url);
                    }
                }
            }
            else if (actionName == "CompleteEvaluation")
            {
                if (scorecard.Type == "CIP" && Math.Round(scorecard.Score, 2) > 2.5)
                {
                    if (scorecard.Users != null)
                    {
                        ScorecardUserCollection scorecardUsers = new ScorecardUserCollection();
                        foreach (ScorecardUser scorecardUser in scorecard.Users)
                        {
                            if (scorecardUser.UserType == ConstantUtility.ROLE_DEPUTY_DIRECTOR ||
                                scorecardUser.UserType == ConstantUtility.ROLE_DIRECTOR)
                            {
                                scorecardUser.Status = -1;
                                scorecardUsers.Add(scorecardUser);
                            }
                        }
                        ScorecardUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                            scorecard.Id, scorecardUsers);
                    }
                }
                else if (scorecard.Type.ToLower() == "hazmat" || scorecard.Type.ToLower() == "non-hazmat")
                {
                    int status = 0;
                    if (Math.Round(scorecard.Score, 2) > 2.5)
                        status = -1;
                    if (scorecard.Users != null)
                    {
                        ScorecardUserCollection scorecardUsers = new ScorecardUserCollection();
                        foreach (ScorecardUser scorecardUser in scorecard.Users)
                        {
                            if (scorecardUser.UserType == ConstantUtility.ROLE_IEH_MANAGER ||
                                scorecardUser.UserType == ConstantUtility.ROLE_IEH_DEPUTY_DIRECTOR)
                            {
                                scorecardUser.Status = status;
                                scorecardUsers.Add(scorecardUser);
                            }
                        }
                        ScorecardUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                            scorecard.Id, scorecardUsers);
                    }
                }
            }
        }
        #endregion
    }
}
