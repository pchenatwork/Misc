#region	Copyright 2005 by AECsoft USA Inc.
/*
************************************************************************
Copyright 2005 by AECsoft USA Inc.

All	rights reserved. No	portion	of this	software or	its	content	may	be
reproduced in any form or by any means,	without	the	express	written
permission of the copyright	owner.
************************************************************************
*/
#endregion Copyright

#region	References
using System;
using System.Web.Security;
using System.Collections;
using System.Collections.Generic;

using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Scorecard.Utilities;
using SCA.VAS.BusinessLogic.Scorecard;
using SCA.VAS.ValueObjects.Scorecard;

using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template;
using SCA.VAS.ValueObjects.Scorecard.Template;

using SCA.VAS.ValueObjects.Workflow;
#endregion

namespace SCA.VAS.Workflow
{
    public partial class ConstantUtility
    {
        public const string SCORECARD_DATASOURCE_NAME = "Scorecard";

        public const string WORKFLOW_EVALUATION = "Evaluation";

        public const string WORKFLOW_CAPACITY_EVALUATION = "Capacity";
        public const string WORKFLOW_CIP_EVALUATION = "CIP";
        public const string WORKFLOW_CCFU_EVALUATION = "CCFU";
        public const string WORKFLOW_PROJECT_CONTRACT_EVALUATION = "Project/Contract";
        public const string WORKFLOW_MENTORA_EVALUATION = "Mentor A";
        public const string WORKFLOW_MENTORB_EVALUATION = "Mentor B";
        public const string WORKFLOW_MENTORA_CONTRACT_EVALUATION = "Mentor A Contract";
        public const string WORKFLOW_MENTORB_CONTRACT_EVALUATION = "Mentor B Contract";

        public const string WORKFLOW_IEH_EVALUATION = "IEH";
        public const string WORKFLOW_IEH_CONTRACT_EVALUATION = "IEH Contract";

        public const string SCORECARDTEMPLATE_CAPACITY = "Capacity";
        public const string SCORECARDTEMPLATE_CIP = "CIP";
        public const string SCORECARDTEMPLATE_MENTORA = "Mentor A";
        public const string SCORECARDTEMPLATE_MENTORB = "Mentor B";
        public const string SCORECARDTEMPLATE_CCFU = "CCFU";

        public const string SCORECARDTEMPLATE_HAZMAT = "HazMat";
        public const string SCORECARDTEMPLATE_NONHAZMAT = "Non-HazMat";
        public const string SCORECARDTEMPLATE_HAZMATCONTRACT = "HazMat Contract";
        public const string SCORECARDTEMPLATE_NONHAZMATCONTRACT = "Non-HazMat Contract";

        public const string ROLE_OPERATIONS_MANAGER = "Operations Manager";
        public const string ROLE_OPERATIONS_SUPERVISOR = "Operations Supervisor";
        public const string ROLE_OPERATIONS_DIRECTOR = "Operations Director";
        public const string ROLE_CONSTRUCTION_SPECIALIST = "Design Project Manager";
        public const string ROLE_CONTRACT_SPECIALIST = "Contract Specialist";
        public const string ROLE_PLAN_EXAMINER = "Plan Examiner";
        public const string ROLE_SENIOR_PROJECT_OFFICER = "Senior Project Officer";
        public const string ROLE_CHIEF_PROJECT_OFFICER = "Chief Project Officer";
        public const string ROLE_DESIGN_REVIEWER = "Design Reviewer";
        public const string ROLE_F_AND_E = "Furniture and Equipment Role";
        public const string ROLE_GREEN_MANAGER = "Green Manager";
        public const string ROLE_FMSI = "Facility Management System Integrator";
        public const string ROLE_TBC = "Total Building Commissioner";
        public const string ROLE_CAPITAL_PLANNING = "Capital Planning";
        public const string ROLE_PROJECT_SUPPORT = "Project Support";
        public const string ROLE_DESIGN_MANAGER = "Design Manager";
        public const string ROLE_DEPUTY_DIRECTOR = "Deputy Director";
        public const string ROLE_DIRECTOR = "Director";
        public const string ROLE_LEGAL = "Legal";
        public const string ROLE_VP_AE = "VP of A&E";
        public const string ROLE_VP_CM = "VP for Construction Mgmt";
        public const string ROLE_VP_ADMIN = "VP of Admin";
        public const string ROLE_VP_CAPITAL_PLANNING = "VP of Capital Planning";
        public const string ROLE_CQU = "CQU Director";
        public const string ROLE_CQU_MANAGER = "CQU Manager";
        public const string ROLE_CQU_REVIEWER = "CQU Reviewer";
        public const string ROLE_SENIOR_DIRECTOR_BDD = "Senior Director of BDD";
        public const string ROLE_SENIOR_DIRECTOR_BDD_SUPERVISOR = "Senior Director of BDD Supervisor";
        public const string ROLE_BRONX_CPO = "Bronx CPO";
        public const string ROLE_BROOKLYN_CPO = "Brooklyn CPO";
        public const string ROLE_MANHATTAN_CPO = "Manhattan CPO";
        public const string ROLE_QUEENS_CPO = "Queens CPO";
        public const string ROLE_STATEN_ISLAND_CPO = "Staten Island CPO";
        public const string ROLE_CONSULTANT = "Consultant";

        public const string ROLE_HYGIENIST_B = "IEH Hygienist B";
        public const string ROLE_HYGIENIST_C = "IEH Hygienist C";
        public const string ROLE_HYGIENIST_C_SUPERVISOR = "IEH Hygienist C Supervisor";
        public const string ROLE_IEH_MANAGER = "IEH Manager";
        public const string ROLE_IEH_DEPUTY_DIRECTOR = "IEH Deputy Director";
        public const string ROLE_IEH_DIRECTOR = "IEH Director";
    }

    public partial class CommonUtility
    {
        public static void EvaluationSendEmail(ScorecardInvitee scorecardInvitee, WorkflowNode node, WorkflowHistory workflowHistory,
            string emailMessageName, string comments)
        {
        }

        public static void ScorecardSendEmail(Scorecard scorecard, WorkflowNode node, WorkflowHistory workflowHistory,
            string emailMessageName, string comments)
        {
            EmailMessage emailmessage = EmailMessageUtility.GetByName(
                ConstantUtility.COMMON_DATASOURCE_NAME, emailMessageName);
            if (emailmessage == null) return;

            int userId = WorkflowExec.GetUserId();
            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, userId);

            ScorecardProject scorecardProject = ScorecardProjectUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.RefId);

            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                "FederalId", scorecardProject.TaxId);
            Supplier supplier = SupplierUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                "FederalId", vendor.FederalId);

            switch (emailmessage.Objects)
            {
                case "Node Users":
                    if (node != null)
                    {
                        WorkflowNodeCollection workflownodes = new WorkflowNodeCollection();
                        workflownodes.Add(node);
                        string nodes = XmlUtility.ToXml(workflownodes);
                        UserCollection users = UserUtility.FindByCriteria(
                            ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_WORKFLOWNODES,
                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                            {
                                SendEmail(emailmessage, users[i],
                                    new object[] { scorecard, scorecardProject, user, users[i], vendor, supplier },
                                    comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "Scorecard", scorecard.Id);
                            }
                        }
                    }
                    break;

                case "Authorized Users":
                    {
                        string nodes = XmlUtility.ToXml(workflowHistory.NextLinks);
                        UserCollection users = UserUtility.FindByCriteria(
                            ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_WORKFLOWNODES,
                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                            {
                                SendEmail(emailmessage, users[i],
                                    new object[] { scorecard, scorecardProject, user, users[i], vendor, supplier },
                                    comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "Scorecard", scorecard.Id);
                            }
                        }
                    }
                    break;

                case "Users":
                    {
                        ScorecardInvitee scorecardInvitee = ScorecardInviteeUtility.GetByUser(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                            scorecard.Id, userId);

                        SendEmail(emailmessage, user,
                            new object[] { scorecard, scorecardProject, user, scorecardInvitee, vendor, supplier }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Scorecard", scorecard.Id);
                    }
                    break;

                case "Invitees":
                    {
                        UserCollection users = null;
                        if (scorecard.InviteeId > 0)
                        {
                            users = new UserCollection();
                            User user1 = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, scorecard.InviteeId);
                            users.Add(user1);
                        }
                        else
                        {
                            users = UserUtility.FindByCriteria(
                                ConstantUtility.USER_DATASOURCE_NAME,
                                UserManager.FIND_USER_BY_POST,
                                new object[] { 0, 0, "LastName", "ASC", scorecard.Id, "ScorecardInvitee" });
                        }

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                            {
                                SendEmail(emailmessage, users[i],
                                    new object[] { scorecard, scorecardProject, user, users[i], vendor, supplier },
                                    comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "Scorecard", scorecard.Id);
                            }
                        }
                    }
                    break;

                case "Approver":
                    {
                        User approver = ScorecardWorkflowExec.GetLastApprover(scorecard);

                        SendEmail(emailmessage, user,
                            new object[] { scorecard, scorecardProject, user, approver, vendor, supplier }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Scorecard", scorecard.Id);
                    }
                    break;

                case "FinalUser":
                    {
                        VendorContact vendorContact = null;
                        if (vendor != null)
                            vendorContact = vendor.PrimaryContact;

                        User finalUser = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, scorecard.FinalUserId);

                        SendEmail(emailmessage, user,
                            new object[] { scorecard, scorecardProject, user, finalUser, vendor, vendorContact, supplier }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Scorecard", scorecard.Id);
                    }
                    break;

                case "Suppliers":
                    {
                        VendorContact vendorContact = null;
                        if (vendor != null)
                            vendorContact = vendor.PrimaryContact;

                        SendEmail(emailmessage, vendorContact,
                            new object[] { scorecard, scorecardProject, user, vendor, vendorContact, supplier }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Scorecard", scorecard.Id);
                    }
                    break;

                default:
                    {
                        SendEmail(emailmessage, null,
                            new object[] { scorecard, scorecardProject, user, vendor, supplier }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Scorecard", scorecard.Id);
                    }
                    break;
            }
        }

        public static int GetTemplateId(string type)
        {
            ScorecardTemplateCollection templates = ScorecardTemplateUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardTemplateManager.FIND_ACTIVE_SCORECARDTEMPLATE,
                new object[] { 0, type });
            if (templates != null && templates.Count > 0)
                return templates[0].Id;
            return 0;
        }

        public static User AddSupervisor(CesUser cesUser, string roleName)
        {
            if (cesUser == null) return null;

            User user1 = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, cesUser.UserName);
            try
            {
                if (user1 == null)
                {
                    MembershipUser membershipUser = Membership.CreateUser(cesUser.UserName, "password", cesUser.Email);
                    string password = membershipUser.ResetPassword();

                    user1 = UserUtility.CreateObject();

                    user1.UserName = cesUser.UserName;
                    user1.ApplicationName = Membership.ApplicationName;
                    user1.Email = cesUser.Email;
                    user1.FirstName = cesUser.FirstName;
                    user1.LastName = cesUser.LastName;
                    user1.Country = ConstantUtility.DEFAULT_COUNTRY;
                    user1.TimeZone = ConstantUtility.DEFAULT_TIMEZONE;

                    UserUtility.Update(ConstantUtility.USER_DATASOURCE_NAME, user1);

                    Roles.AddUserToRole(cesUser.UserName, roleName);

                    membershipUser.Email = cesUser.Email;
                    membershipUser.IsApproved = true;
                    Membership.UpdateUser(membershipUser);

                    user1 = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, cesUser.UserName);
                }
            }
            catch { }

            return user1;
        }

        public static User AddUser(CesUser cesUser, string roleName, string supervisorRoleName, int userId)
        {
            if (cesUser.Status != "A")
            {
                CesUser cesUser1 = CesUserUtility.GetByName(ConstantUtility.RFD_DATASOURCE_NAME, cesUser.FirstName, cesUser.LastName);
                if (cesUser1 != null)
                    cesUser = cesUser1;
            }

            User user1 = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, cesUser.UserName);
            try
            {
                if (user1 == null)
                {
                    MembershipUser membershipUser = Membership.CreateUser(cesUser.UserName, "password", cesUser.Email);
                    string password = membershipUser.ResetPassword();

                    user1 = UserUtility.CreateObject();

                    user1.UserName = cesUser.UserName;
                    user1.ApplicationName = Membership.ApplicationName;
                    user1.Email = cesUser.Email;
                    user1.FirstName = cesUser.FirstName;
                    user1.LastName = cesUser.LastName;
                    user1.Country = ConstantUtility.DEFAULT_COUNTRY;
                    user1.TimeZone = ConstantUtility.DEFAULT_TIMEZONE;

                    UserUtility.Update(ConstantUtility.USER_DATASOURCE_NAME, user1);

                    Roles.AddUserToRole(cesUser.UserName, roleName);

                    membershipUser.Email = cesUser.Email;
                    membershipUser.IsApproved = (cesUser.Status == "A");
                    Membership.UpdateUser(membershipUser);

                    user1 = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, cesUser.UserName);

                    if (cesUser != null && cesUser.Supervisor.Trim().Length > 0)
                    {
                        User supervisor = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME,
                            cesUser.Supervisor);
                        if (supervisor == null)
                        {
                            CesUser cesSupervisor = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME,
                                cesUser.Supervisor);
                            supervisor = AddSupervisor(cesSupervisor, supervisorRoleName);
                        }
                    }
                }
                else
                {
                    if (!Roles.IsUserInRole(cesUser.UserName, roleName))
                        Roles.AddUserToRole(cesUser.UserName, roleName);

                    MembershipUser mUser = Membership.GetUser(cesUser.UserName);
                    if (cesUser.Status == "A" && !mUser.IsApproved)
                    {
                        mUser.IsApproved = true;
                        Membership.UpdateUser(mUser);
                    }
                    else if (cesUser.Status != "A" && mUser.IsApproved)
                    {
                        mUser.IsApproved = false;
                        Membership.UpdateUser(mUser);

                        // Send Email to A&E Coordinators

                        //DeactivateUser(cesUser.UserName, userId);
                    }
                }
            }
            catch { }
            return user1;
        }

        public static void DeactivateUser(string userName, int userId)
        {
            User user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, userName);

            string errmsg = string.Empty;
            string url = string.Empty;
            ScorecardInviteeCollection invitees = ScorecardInviteeUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardInviteeManager.FIND_SCORECARDINVITEE_BY_USER,
                new object[] { user.Id, -1 });
            if (invitees != null)
            {
                foreach (ScorecardInvitee invitee in invitees)
                {
                    ForwardEvaluation(invitee, invitee.SupervisorId, "User is inactive", 0);
                }
            }
        }

        public static ScorecardProjectUser AddProjectUser(ref ScorecardProjectUserCollection projectUsers, 
            string userName, string roleName, string supervisorName, string supervisorRole, int userId)
        {
            ScorecardProjectUser projectUser = null;

            User user = null;
            CesUser cesUser = null;
            User supervisor = null;
            if (userName.Trim().Length > 0)
            {
                cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, userName);
                if (cesUser != null)
                    user = AddUser(cesUser, roleName, supervisorRole, userId);
            }
            if (supervisorName.Trim().Length  == 0 && cesUser != null && cesUser.Supervisor.Trim().Length > 0)
                supervisorName = cesUser.Supervisor.Trim();
            
            if (supervisorName.Trim().Length > 0)
            {
                if (supervisorRole.Trim().Length == 0)
                    supervisorRole = roleName;
                cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, supervisorName);
                if (cesUser != null)
                    supervisor = AddSupervisor(cesUser, supervisorRole);
            }

            bool add = false;
            projectUser = projectUsers.Find(roleName);
            if (projectUser == null)
            {
                add = true;
                projectUser = ScorecardProjectUserUtility.CreateObject();
            }
            if (user != null)
                projectUser.UserId = user.Id;
            projectUser.UserType = roleName;
            if (supervisor != null)
                projectUser.SupervisorId = supervisor.Id;

            if (add)
                projectUsers.Add(projectUser);

            return projectUser;
        }

        public static void ForwardEvaluation(ScorecardInviteeCollection invitees)
        {
            if (invitees == null) return;

            foreach (ScorecardInvitee invitee in invitees)
            {
                string errmsg = string.Empty;
                string url = string.Empty;
                invitee.TransactionId = EvaluationWorkflowExec.EvaluationWorkflow(invitee, 0,
                    "", ref errmsg, ref url);

                User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, invitee.UserId);
                if (user != null)
                {
                    MembershipUser mUser = Membership.GetUser(user.UserName);

                    if (mUser != null && !mUser.IsApproved && invitee.SupervisorId > 0)
                    {
                        ForwardEvaluation(invitee, invitee.SupervisorId, "User is inactive", 0);
                    }
                    else if (user.EmailNotification == "Y" && invitee.SupervisorId > 0)
                    {
                        ForwardEvaluation(invitee, invitee.SupervisorId, "User is out of office", 0);
                    }
                }
            }
        }

        public static void ForwardEvaluation(ScorecardInvitee invitee, int inviteeId, string comments, int userId)
        {
            if (invitee == null) return;

            if (invitee != null)
            {
                invitee.UserId = inviteeId;

                User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, inviteeId);

                if (user != null)
                {
                    CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, user.UserName);

                    if (cesUser != null && cesUser.Supervisor.Trim().Length > 0)
                    {
                        User supervisor = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME,
                            cesUser.Supervisor);
                        if (supervisor == null)
                        {
                            CesUser cesSupervisor = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME,
                                cesUser.Supervisor);
                            supervisor = AddSupervisor(cesSupervisor, invitee.SupervisorType);
                        }
                        if (supervisor != null)
                            invitee.SupervisorId = supervisor.Id;
                    }

                    if (invitee.WorkflowId == 0)
                        invitee.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_EVALUATION);

                    ScorecardInviteeUtility.Update(ConstantUtility.SCORECARD_DATASOURCE_NAME, invitee);

                    User changeUser = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, userId);
                    if (changeUser == null)
                    {
                        changeUser = UserUtility.CreateObject();
                        changeUser.LastName = "System";
                        changeUser.Email = "System";
                    }
                    string evaluationComments = string.Empty;
                    if (invitee.Status == EvaluationStatusType.Declined.Id)
                        evaluationComments = changeUser.FullName + " reassigns evaluation to " + user.FullName;
                    else
                        evaluationComments = changeUser.FullName + " forwards evaluation to " + user.FullName;

                    string errmsg = string.Empty;
                    string url = string.Empty;
                    if (invitee.Status == EvaluationStatusType.Declined.Id)
                        invitee.TransactionId = EvaluationWorkflowExec.EvaluationWorkflow(invitee, EvaluationAction.Reassign.Name,
                            comments, ref errmsg, ref url);
                    else
                        invitee.TransactionId = EvaluationWorkflowExec.EvaluationWorkflow(invitee, EvaluationAction.ForwardEvaluation.Name,
                            comments, ref errmsg, ref url);

                    Scorecard scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        invitee.ScorecardId);
                    if ((invitee.UserType == ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST &&
                        (scorecard.Type == "Capacity" || scorecard.Type == "CIP")) ||
                        (invitee.UserType == ConstantUtility.ROLE_SENIOR_PROJECT_OFFICER &&
                        scorecard.Type == "Mentor A"))
                    {
                        scorecard.UserId = inviteeId;
                        ScorecardUtility.Update(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard);

                        ScorecardUserCollection users = new ScorecardUserCollection();
                        ScorecardUser scorecardUser = ScorecardUserUtility.CreateObject();
                        scorecardUser.UserId = inviteeId;
                        scorecardUser.UserType = invitee.UserType;
                        users.Add(scorecardUser);
                        ScorecardUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                            scorecard.Id, users);
                    }

                    ScorecardStatusType statusType = (ScorecardStatusType)scorecard.Status;
                    if (statusType != null)
                        ScorecardWorkflowExec.ScorecardWorkflow(scorecard, statusType.Name, evaluationComments);
                }
            }
        }

        public static void ForwardEvaluation(ScorecardUser user, int inviteeId, string comments, int userId)
        {
            if (user != null)
            {
                ScorecardUserCollection users = new ScorecardUserCollection();
                ScorecardUser scorecardUser = ScorecardUserUtility.CreateObject();
                scorecardUser.UserId = inviteeId;
                scorecardUser.UserType = user.UserType;
                users.Add(scorecardUser);
                ScorecardUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    user.ScorecardId, users);

                User user1 = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, inviteeId);

                User changeUser = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, userId);
                if (changeUser == null)
                {
                    changeUser = UserUtility.CreateObject();
                    changeUser.LastName = "System";
                    changeUser.Email = "System";
                }
                string evaluationComments = changeUser.FullName + " reassigns to " + user1.FullName + "<br />" + comments;

                Scorecard scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    user.ScorecardId);
                ScorecardStatusType statusType = (ScorecardStatusType)scorecard.Status;
                if (statusType != null)
                    ScorecardWorkflowExec.ScorecardWorkflow(scorecard, statusType.Name, evaluationComments);
            }
        }

        public static int GetFiscalYear(DateTime date)
        {
            if (date.Month >= 7)
                return date.Year;
            else
                return date.Year - 1;
        }

        public static string EvaluationPeriod(int scorecardYear)
        {
            if (scorecardYear == 0)
                return string.Empty;

            DateTime beginDate = new DateTime(scorecardYear, 7, 1);
            DateTime endDate = new DateTime(scorecardYear + 1, 6, 30);

            return beginDate.ToString("MMM dd yyyy") + " - " + endDate.ToString("MMM dd yyyy");
        }

        #region Capacity Evaluation
        public static ScorecardProject CreateScorecardProject(CapacityContract capacityContract,
            ScorecardTemplate scorecardTemplate, string userName, int userId)
        {
            ScorecardProject scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, "Capacity",
                capacityContract.TaxId, capacityContract.ContractNo, capacityContract.ProjectNo, "");
            if (scorecardProject == null)
            {
                scorecardProject = ScorecardProjectUtility.CreateObject();
                scorecardProject.Type = scorecardTemplate.Type;
                scorecardProject.TaxId = capacityContract.TaxId;
                scorecardProject.ContractNo = capacityContract.ContractNo;
                scorecardProject.ProjectNo = capacityContract.ProjectNo;
                scorecardProject.Boro = capacityContract.Boro;
                scorecardProject.School = capacityContract.School;
                scorecardProject.Building = capacityContract.Building;
                scorecardProject.ChangeUser = userName;

                ScorecardProjectUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardProject);
            }

            ScorecardProjectUserCollection projectUsers = new ScorecardProjectUserCollection();

            User user;
            ScorecardTemplateUserTypeCollection userTypes = ScorecardTemplateUserTypeUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardTemplateUserTypeManager.FIND_SCORECARDTEMPLATEUSERTYPE_BY_TEMPLATE,
                new object[] { scorecardTemplate.Id, "" });
            if (userTypes != null)
            {
                foreach (ScorecardTemplateUserType templateUserType in userTypes)
                {
                    ScorecardProjectUser scorecardProjectUser = ScorecardProjectUserUtility.CreateObject();
                    scorecardProjectUser.UserId = templateUserType.UserId;
                    scorecardProjectUser.UserType = templateUserType.UserType;
                    if (templateUserType.UserId > 0)
                    {
                        user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
                            templateUserType.UserId);

                        CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, user.UserName);
                        if (cesUser != null && cesUser.Supervisor.Trim().Length > 0)
                        {
                            cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, cesUser.Supervisor.Trim());
                            User supervisor = AddSupervisor(cesUser, templateUserType.UserType + " Supervisor");
                            if (supervisor != null)
                                scorecardProjectUser.SupervisorId = supervisor.Id;
                        }
                    }
                    projectUsers.Add(scorecardProjectUser);
                }
            }

            // Design Manager
            ScorecardProjectUser projectUser = AddProjectUser(ref projectUsers,
                capacityContract.DesignManager, ConstantUtility.ROLE_DESIGN_MANAGER,
                string.Empty, string.Empty, userId);

            // Design Project Manager
            projectUser = AddProjectUser(ref projectUsers,
                capacityContract.ConstructionSpecialist, ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST,
                capacityContract.DesignManager, ConstantUtility.ROLE_DESIGN_MANAGER, userId);

            // CCFU
            projectUser = AddProjectUser(ref projectUsers,
                capacityContract.OpsManager, ConstantUtility.ROLE_OPERATIONS_MANAGER,
                capacityContract.OpsManagerSupervisor, ConstantUtility.ROLE_OPERATIONS_SUPERVISOR, userId);

            // Contract Specialist
            projectUser = AddProjectUser(ref projectUsers,
                capacityContract.ContractSpecialist, ConstantUtility.ROLE_CONTRACT_SPECIALIST,
                capacityContract.ContractSpecialistSupervisor, ConstantUtility.ROLE_CONTRACT_SPECIALIST + " Supervisor", userId);

            // Plan Examiner
            projectUser = AddProjectUser(ref projectUsers,
                capacityContract.PlanExaminer, ConstantUtility.ROLE_PLAN_EXAMINER,
                capacityContract.PlanExaminerSupervisor, ConstantUtility.ROLE_PLAN_EXAMINER + " Supervisor", userId);

            // FMSI
            projectUser = AddProjectUser(ref projectUsers,
                capacityContract.Fmsi, ConstantUtility.ROLE_FMSI,
                capacityContract.FmsiSupervisor, ConstantUtility.ROLE_FMSI + " Supervisor", userId);

            // Senior Project Officer
            projectUser = AddProjectUser(ref projectUsers,
                capacityContract.SeniorProjectOfficer, ConstantUtility.ROLE_SENIOR_PROJECT_OFFICER,
                capacityContract.SeniorProjectOfficerSupervisor, ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER, userId);

            // Deputy Director
            projectUser = AddProjectUser(ref projectUsers,
                capacityContract.StudioDeputyDirector, ConstantUtility.ROLE_DEPUTY_DIRECTOR,
                string.Empty, string.Empty, userId);

            // Director
            projectUser = AddProjectUser(ref projectUsers,
                capacityContract.StudioDirector, ConstantUtility.ROLE_DIRECTOR,
                string.Empty, string.Empty, userId);

            ScorecardProjectUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardProject.Id, projectUsers);

            scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, "Capacity",
                capacityContract.TaxId, capacityContract.ContractNo, capacityContract.ProjectNo, "");

            return scorecardProject;
        }

        public static int CreateScorecard(CapacityContract capacityContract, ScorecardTemplate scorecardTemplate,
            ScorecardTemplateCategory templateCategory, string userName, string type, int userId)
        {
            ScorecardProject scorecardProject = CreateScorecardProject(capacityContract, scorecardTemplate, userName, userId);
            if (scorecardProject == null)
            {
                return 0;
            }

            Scorecard scorecard = null;

            if (type == "N")
            {
                scorecard = ScorecardUtility.GetByRef(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecardProject.Id, templateCategory.Id, "Y");

                if (scorecard != null && scorecard.CreateDate.AddDays(30) > DateTime.Now)
                {
                    ScorecardWorkflowExec.ScorecardWorkflow(scorecard, ScorecardStatusType.Obsolete.Name, "");
                }
            }

            scorecard = ScorecardUtility.GetByRef(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardProject.Id, templateCategory.Id, "");
            if (scorecard != null)
            {
                return -scorecard.Id;
            }

            if (type == "N")
            {
                ScorecardTemplateCategory templateCategory1 = null;
                if (templateCategory.Name == "Design Development (30%)")
                {
                    templateCategory1 = scorecardTemplate.Categories.FindByName("Pre-Schematic and Schematic Design");
                }
                else if (templateCategory.Name == "Contract Documents (60% and 100%)")
                {
                    templateCategory1 = scorecardTemplate.Categories.FindByName("Design Development (30%)");
                }
                else if (templateCategory.Name == "Bid and Award")
                {
                    templateCategory1 = scorecardTemplate.Categories.FindByName("Contract Documents (60% and 100%)");
                }
                if (templateCategory1 != null)
                {
                    Scorecard scorecard1 = ScorecardUtility.GetByRef(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        scorecardProject.Id, templateCategory1.Id, "");
                    if (scorecard1 != null)
                    {
                        TimeSpan ts = DateTime.Now - scorecard1.CreateDate;
                        if (ts.Days < 14)
                            return 0;
                    }
                }
            }

            if (scorecard == null)
            {
                scorecard = ScorecardUtility.CreateObject();
                scorecard.Type = scorecardTemplate.Type;
                scorecard.RefId = scorecardProject.Id;
                scorecard.TemplateId = scorecardTemplate.Id;
                scorecard.CategoryId = templateCategory.Id;
                scorecard.Name = scorecardTemplate.Name;
                scorecard.IsTest = type;
                scorecard.ScoreYear = GetFiscalYear(DateTime.Now);

                if (scorecardProject.Users != null)
                {
                    ScorecardProjectUser projectUser = scorecardProject.Users.Find(ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST);
                    if (projectUser != null)
                    {
                        User cs = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, projectUser.UserId);
                        if (cs != null)
                        {
                            scorecard.UserId = cs.Id;
                            scorecard.Email = cs.Email;
                            scorecard.Contact = cs.FullName;
                        }
                    }
                }
                scorecard.ReleaseDate = DateTime.Now.AddDays(2);
                scorecard.EvaluationDate = DateTime.Now.AddDays(7);
                scorecard.CloseDate = DateTime.Now.AddDays(21);
                scorecard.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_CAPACITY_EVALUATION);
                //scorecard.Status = ScorecardStatusType.NewEvaluation.Id;

                ScorecardUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard);

                ScorecardCategoryUtility.CopyFromTemplate(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, templateCategory.Id);

                scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id);

                ForwardEvaluation(scorecard.Invitees);

                scorecard.TransactionId = ScorecardWorkflowExec.ScorecardWorkflow(scorecard,
                    ScorecardStatusType.NewEvaluation.Name, "");
            }
            return scorecard.Id;
        }

        public static int CreateProjectScorecard(CapacityContract capacityContract, string adHoc)
        {
            ScorecardProject scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, "Capacity", capacityContract.TaxId,
                capacityContract.ContractNo, capacityContract.ProjectNo, "");
            if (scorecardProject == null)
                return 0;

            int scoreYear = GetFiscalYear(DateTime.Now);

            List<Extra> searchItems = new List<Extra>();

            Extra extraItem = new Extra();
            extraItem.Name = "TaxId";
            extraItem.Value = capacityContract.TaxId;
            searchItems.Add(extraItem);

            extraItem = new Extra();
            extraItem.Name = "ContractNo";
            extraItem.Value = capacityContract.ContractNo;
            searchItems.Add(extraItem);
        
            extraItem = new Extra();
            extraItem.Name = "ProjectNo";
            extraItem.Value = capacityContract.ProjectNo;
            searchItems.Add(extraItem);
            
            string extraXml = XmlUtility.ToXml(searchItems);

            string scorecardIds = "<ArrayOfScorecard>";
            ScorecardCollection scorecards = ScorecardUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardManager.FIND_SCORECARD,
                new object[] 
                { 
                    scoreYear, 0, "Capacity", ScorecardStatusType.Complete.Id, string.Empty, extraXml 
                });
            if (scorecards != null && scorecards.Count > 0)
            {
                foreach (Scorecard s in scorecards)
                {
                    scorecardIds += "<Scorecard Id=\"" + s.Id.ToString() + "\" />";
                }
            }
            scorecardIds += "</ArrayOfScorecard>";
            
            Scorecard scorecard = ScorecardUtility.CreateObject();
            scorecard.Type = "Project";
            scorecard.RefId = scorecardProject.Id;
            scorecard.Name = capacityContract.ProjectNo;
            scorecard.IsTest = adHoc;
            scorecard.ScoreYear = scoreYear;

            ScorecardUserCollection scorecardUsers = ScorecardUserUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardUserManager.SEARCH_SCORECARDUSER,
                new object[] { scorecardIds, ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST });
            if (scorecardUsers != null && scorecardUsers.Count > 0)
            {
                User cs = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, scorecardUsers[0].UserId);
                if (cs != null)
                {
                    scorecard.UserId = cs.Id;
                    scorecard.Email = cs.Email;
                    scorecard.Contact = cs.FullName;
                }
            }

            scorecard.CreateDate = DateTime.Now;
            scorecard.EvaluationDate = DateTime.Now.AddDays(7);
            scorecard.CloseDate = DateTime.Now.AddDays(14);
            scorecard.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_PROJECT_CONTRACT_EVALUATION);
            //scorecard.Status = ScorecardStatusType.NewEvaluation.Id;

            ScorecardUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard);

            if (scorecard.Id > 0)
            {
                try
                {
                    if (scorecards != null)
                    {
                        LinkedScorecardCollection linkedScorecards = new LinkedScorecardCollection();

                        foreach (Scorecard s in scorecards)
                        {
                            LinkedScorecard linkedScorecard = LinkedScorecardUtility.CreateObject();
                            linkedScorecard.LinkedId = s.Id;
                            linkedScorecards.Add(linkedScorecard);
                        }

                        LinkedScorecardUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                            scorecard.Id, linkedScorecards);
                    }
                } catch 
                {
                    // scorecards != null should be catching the null reference, but it was still failing. Unsure why & difficult to test.
                }

                ScorecardUserCollection evaluators = new ScorecardUserCollection();
                // DPM
                if (scorecardUsers != null && scorecardUsers.Count > 0)
                {
                    ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                    evaluator.UserId = scorecardUsers[0].UserId;
                    evaluator.UserType = ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST;
                    evaluators.Add(evaluator);
                }

                // Design Manager
                scorecardUsers = ScorecardUserUtility.FindByCriteria(
                    ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    ScorecardUserManager.SEARCH_SCORECARDUSER,
                    new object[] { scorecardIds, ConstantUtility.ROLE_DESIGN_MANAGER });
                if (scorecardUsers != null && scorecardUsers.Count > 0)
                {
                    ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                    evaluator.UserId = scorecardUsers[0].UserId;
                    evaluator.UserType = ConstantUtility.ROLE_DESIGN_MANAGER;
                    evaluators.Add(evaluator);
                }

                // Deputy Director
                scorecardUsers = ScorecardUserUtility.FindByCriteria(
                    ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    ScorecardUserManager.SEARCH_SCORECARDUSER,
                    new object[] { scorecardIds, ConstantUtility.ROLE_DEPUTY_DIRECTOR });
                if (scorecardUsers != null && scorecardUsers.Count > 0)
                {
                    ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                    evaluator.UserId = scorecardUsers[0].UserId;
                    evaluator.UserType = ConstantUtility.ROLE_DEPUTY_DIRECTOR;
                    evaluators.Add(evaluator);
                }
                   
                // Director
                scorecardUsers = ScorecardUserUtility.FindByCriteria(
                    ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    ScorecardUserManager.SEARCH_SCORECARDUSER,
                    new object[] { scorecardIds, ConstantUtility.ROLE_DIRECTOR });
                if (scorecardUsers != null && scorecardUsers.Count > 0)
                {
                    ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                    evaluator.UserId = scorecardUsers[0].UserId;
                    evaluator.UserType = ConstantUtility.ROLE_DIRECTOR;
                    evaluators.Add(evaluator);
                }
                ScorecardUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, evaluators);

                double avgScore = ScorecardUtility.GetAverageScore(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, 0);
                ScorecardUtility.UpdateScore(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id, avgScore);

                scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id);

                scorecard.TransactionId = ScorecardWorkflowExec.ScorecardWorkflow(scorecard,
                    ScorecardStatusType.NewEvaluation.Name, "");

                return scorecard.Id;
            }
            else
            {
                return 0;
            }
        }
        #endregion

        #region CIP Evaluation
        public static ScorecardProject CreateScorecardProject(CipContract cipContract,
            ScorecardTemplate scorecardTemplate, string userName, int userId)
        {
            ScorecardProject scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, "CIP",
                cipContract.TaxId, cipContract.ContractNo, cipContract.DesignCode, "");
            if (scorecardProject == null)
            {
                scorecardProject = ScorecardProjectUtility.CreateObject();
                scorecardProject.Type = scorecardTemplate.Type;
                scorecardProject.TaxId = cipContract.TaxId;
                scorecardProject.ContractNo = cipContract.ContractNo;
                scorecardProject.ProjectNo = cipContract.DesignCode;
                scorecardProject.Description = cipContract.Description;
                scorecardProject.Resoa = cipContract.Resoa;
                scorecardProject.Duration = cipContract.ConstructionDuration;
                scorecardProject.Estimate = cipContract.ConstructionEstimate;
                scorecardProject.Boro = cipContract.Boro;
                scorecardProject.School = cipContract.School;
                scorecardProject.Building = cipContract.Building;
                scorecardProject.ChangeUser = userName;

                ScorecardProjectUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardProject);
            }

            ScorecardProjectUserCollection projectUsers = new ScorecardProjectUserCollection();

            string categoryType = "CIP";
            if (cipContract.Resoa == 1)
                categoryType = "RESO A";

            User user;
            ScorecardTemplateUserTypeCollection userTypes = ScorecardTemplateUserTypeUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardTemplateUserTypeManager.FIND_SCORECARDTEMPLATEUSERTYPE_BY_TEMPLATE,
                new object[] { scorecardTemplate.Id, categoryType });
            if (userTypes != null)
            {
                foreach (ScorecardTemplateUserType templateUserType in userTypes)
                {
                    ScorecardProjectUser scorecardProjectUser = ScorecardProjectUserUtility.CreateObject();
                    scorecardProjectUser.UserId = templateUserType.UserId;
                    scorecardProjectUser.UserType = templateUserType.UserType;
                    if (templateUserType.UserId > 0)
                    {
                        user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
                            templateUserType.UserId);

                        CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, user.UserName);
                        if (cesUser != null && cesUser.Supervisor.Trim().Length > 0)
                        {
                            cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, cesUser.Supervisor.Trim());
                            User supervisor = AddSupervisor(cesUser, templateUserType.UserType + " Supervisor");
                            if (supervisor != null)
                                scorecardProjectUser.SupervisorId = supervisor.Id;
                        }
                    }
                    projectUsers.Add(scorecardProjectUser);
                }
            }

            // Design Project Manager
            ScorecardProjectUser projectUser = AddProjectUser(ref projectUsers,
               cipContract.ConstructionSpecialist, ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST,
               cipContract.DesignManager, ConstantUtility.ROLE_DESIGN_MANAGER, userId);

            // Design Manager
            projectUser = AddProjectUser(ref projectUsers,
                cipContract.DesignManager, ConstantUtility.ROLE_DESIGN_MANAGER,
                string.Empty, string.Empty, userId);

            // CCFU
            projectUser = AddProjectUser(ref projectUsers,
                cipContract.OpsManager, ConstantUtility.ROLE_OPERATIONS_MANAGER,
                cipContract.OpsManagerSupervisor, ConstantUtility.ROLE_OPERATIONS_SUPERVISOR, userId);

            // Contract Specialist
            projectUser = AddProjectUser(ref projectUsers,
                cipContract.ContractSpecialist, ConstantUtility.ROLE_CONTRACT_SPECIALIST,
                cipContract.ContractSpecialistSupervisor, ConstantUtility.ROLE_CONTRACT_SPECIALIST + " Supervisor", userId);

            // FID feedback will be provided only for projects with a Current Construction Estimate above $1M
            if (cipContract.ConstructionEstimate > 1000000)
            {
                // Plan Examiner
                projectUser = AddProjectUser(ref projectUsers,
                    cipContract.PlanExaminer, ConstantUtility.ROLE_PLAN_EXAMINER,
                    cipContract.PlanExaminerSupervisor, ConstantUtility.ROLE_PLAN_EXAMINER + " Supervisor", userId);
            }

            // Project Support
            projectUser = AddProjectUser(ref projectUsers,
                cipContract.ProjectSupport, ConstantUtility.ROLE_PROJECT_SUPPORT,
                cipContract.ProjectSupportSupervisor, ConstantUtility.ROLE_PROJECT_SUPPORT + " Supervisor", userId);

            // Senior Project Officer
            projectUser = AddProjectUser(ref projectUsers,
                cipContract.SeniorProjectOfficer, ConstantUtility.ROLE_SENIOR_PROJECT_OFFICER,
                cipContract.SeniorProjectOfficerSupervisor, ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER, userId);

            // Deputy Director
            projectUser = AddProjectUser(ref projectUsers,
                cipContract.StudioDeputyDirector, ConstantUtility.ROLE_DEPUTY_DIRECTOR,
                string.Empty, string.Empty, userId);

            // Director
            projectUser = AddProjectUser(ref projectUsers,
                cipContract.StudioDirector, ConstantUtility.ROLE_DIRECTOR,
                string.Empty, string.Empty, userId);

            ScorecardProjectUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardProject.Id, projectUsers);

            scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, "CIP",
                cipContract.TaxId, cipContract.ContractNo, cipContract.DesignCode, "");

            return scorecardProject;
        }
        
        public static int CreateScorecard(CipContract cipContract, ScorecardTemplate scorecardTemplate,
            ScorecardTemplateCategory templateCategory, string userName, string type, int userId)
        {
            ScorecardProject scorecardProject = CreateScorecardProject(cipContract, scorecardTemplate, userName, userId);
            if (scorecardProject == null)
            {
                return 0;
            }

            Scorecard scorecard = null;

            if (type == "N")
            {
                scorecard = ScorecardUtility.GetByRef(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecardProject.Id, templateCategory.Id, "Y");

                if (scorecard != null && scorecard.CreateDate.AddDays(30) > DateTime.Now)
                {
                    ScorecardWorkflowExec.ScorecardWorkflow(scorecard, ScorecardStatusType.Obsolete.Name, "");
                }
            }

            scorecard = ScorecardUtility.GetByRef(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardProject.Id, templateCategory.Id, "");
            if (scorecard != null)
            {
                return -scorecard.Id;
            }

            if (type == "N")
            {
                ScorecardTemplateCategory templateCategory1 = null;
                if (templateCategory.Name == "Design - Contract Documents")
                {
                    templateCategory1 = scorecardTemplate.Categories.FindByName("Scope");
                }
                else if (templateCategory.Name == "Bid and Award")
                {
                    templateCategory1 = scorecardTemplate.Categories.FindByName("Design - Contract Documents");
                }
                if (templateCategory1 != null)
                {
                    Scorecard scorecard1 = ScorecardUtility.GetByRef(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        scorecardProject.Id, templateCategory1.Id, "");
                    if (scorecard1 != null)
                    {
                        TimeSpan ts = DateTime.Now - scorecard1.CreateDate;
                        if (ts.Days < 14)
                            return 0;
                    }
                }
            }

            if (scorecard == null)
            {
                scorecard = ScorecardUtility.CreateObject();
                scorecard.Type = scorecardTemplate.Type;
                scorecard.RefId = scorecardProject.Id;
                scorecard.TemplateId = scorecardTemplate.Id;
                scorecard.CategoryId = templateCategory.Id;
                scorecard.Name = scorecardTemplate.Name;
                scorecard.IsTest = type;
                scorecard.ScoreYear = GetFiscalYear(DateTime.Now);

                if (scorecardProject.Users != null)
                {
                    ScorecardProjectUser projectUser = scorecardProject.Users.Find(ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST);
                    if (projectUser != null)
                    {
                        User cs = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, projectUser.UserId);
                        if (cs != null)
                        {
                            scorecard.UserId = cs.Id;
                            scorecard.Email = cs.Email;
                            scorecard.Contact = cs.FullName;
                        }
                    }
                }
                scorecard.ReleaseDate = DateTime.Now.AddDays(2);
                scorecard.EvaluationDate = DateTime.Now.AddDays(7);
                scorecard.CloseDate = DateTime.Now.AddDays(21);
                scorecard.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_CIP_EVALUATION);
                //scorecard.Status = ScorecardStatusType.NewEvaluation.Id;

                ScorecardUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard);

                ScorecardCategoryUtility.CopyFromTemplate(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, templateCategory.Id);

                scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id);

                ForwardEvaluation(scorecard.Invitees);
                
                scorecard.TransactionId = ScorecardWorkflowExec.ScorecardWorkflow(scorecard,
                    ScorecardStatusType.NewEvaluation.Name, "");
            }
            return scorecard.Id;
        }

        public static int CreateProjectScorecard(CipContract cipContract, string adHoc)
        {
            ScorecardProject scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, "CIP", cipContract.TaxId,
                cipContract.ContractNo, cipContract.DesignCode, "");
            if (scorecardProject == null)
                return 0;

            int scoreYear = GetFiscalYear(DateTime.Now);
            
            List<Extra> searchItems = new List<Extra>();

            Extra extraItem = new Extra();
            extraItem.Name = "TaxId";
            extraItem.Value = cipContract.TaxId;
            searchItems.Add(extraItem);

            extraItem = new Extra();
            extraItem.Name = "ContractNo";
            extraItem.Value = cipContract.ContractNo;
            searchItems.Add(extraItem);

            extraItem = new Extra();
            extraItem.Name = "ProjectNo";
            extraItem.Value = cipContract.DesignCode;
            searchItems.Add(extraItem);
            
            string extraXml = XmlUtility.ToXml(searchItems);

            string scorecardIds = "<ArrayOfScorecard>";
            ScorecardCollection scorecards = ScorecardUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardManager.FIND_SCORECARD,
                new object[] 
                { 
                    scoreYear, 0, "CIP", ScorecardStatusType.Complete.Id, string.Empty, extraXml 
                });
            if (scorecards != null && scorecards.Count > 0)
            {
                foreach (Scorecard s in scorecards)
                {
                    scorecardIds += "<Scorecard Id=\"" + s.Id.ToString() + "\" />";
                }
            }
            scorecardIds += "</ArrayOfScorecard>";

            Scorecard scorecard = ScorecardUtility.CreateObject();
            scorecard.Type = "Project";
            scorecard.RefId = scorecardProject.Id;
            scorecard.Name = cipContract.DesignCode;
            scorecard.IsTest = adHoc;
            scorecard.ScoreYear = scoreYear;

            ScorecardUserCollection scorecardUsers = ScorecardUserUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardUserManager.SEARCH_SCORECARDUSER,
                new object[] { scorecardIds, ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST });
            if (scorecardUsers != null && scorecardUsers.Count > 0)
            {
                User cs = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, scorecardUsers[0].UserId);
                if (cs != null)
                {
                    scorecard.UserId = cs.Id;
                    scorecard.Email = cs.Email;
                    scorecard.Contact = cs.FullName;
                }
            }

            scorecard.CreateDate = DateTime.Now;
            scorecard.EvaluationDate = DateTime.Now.AddDays(7);
            scorecard.CloseDate = DateTime.Now.AddDays(14);
            scorecard.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_PROJECT_CONTRACT_EVALUATION);
            //scorecard.Status = ScorecardStatusType.NewEvaluation.Id;

            ScorecardUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard);

            if (scorecard.Id > 0)
            {
                if (scorecards != null && scorecards.Count > 0)
                {
                    LinkedScorecardCollection linkedScorecards = new LinkedScorecardCollection();
                    foreach (Scorecard s in scorecards)
                    {
                        LinkedScorecard linkedScorecard = LinkedScorecardUtility.CreateObject();
                        linkedScorecard.LinkedId = s.Id;
                        linkedScorecards.Add(linkedScorecard);
                    }
                    LinkedScorecardUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        scorecard.Id, linkedScorecards);

                    ScorecardUserCollection evaluators = new ScorecardUserCollection();
                    // DPM
                    if (scorecardUsers != null && scorecardUsers.Count > 0)
                    {
                        ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                        evaluator.UserId = scorecardUsers[0].UserId;
                        evaluator.UserType = ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST;
                        evaluators.Add(evaluator);
                    }

                    // Design Manager
                    scorecardUsers = ScorecardUserUtility.FindByCriteria(
                        ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        ScorecardUserManager.SEARCH_SCORECARDUSER,
                        new object[] { scorecardIds, ConstantUtility.ROLE_DESIGN_MANAGER });
                    if (scorecardUsers != null && scorecardUsers.Count > 0)
                    {
                        ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                        evaluator.UserId = scorecardUsers[0].UserId;
                        evaluator.UserType = ConstantUtility.ROLE_DESIGN_MANAGER;
                        evaluators.Add(evaluator);
                    }

                    // Deputy Director
                    scorecardUsers = ScorecardUserUtility.FindByCriteria(
                        ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        ScorecardUserManager.SEARCH_SCORECARDUSER,
                        new object[] { scorecardIds, ConstantUtility.ROLE_DEPUTY_DIRECTOR });
                    if (scorecardUsers != null && scorecardUsers.Count > 0)
                    {
                        ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                        evaluator.UserId = scorecardUsers[0].UserId;
                        evaluator.UserType = ConstantUtility.ROLE_DEPUTY_DIRECTOR;
                        evaluators.Add(evaluator);
                    }

                    // Director
                    scorecardUsers = ScorecardUserUtility.FindByCriteria(
                        ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        ScorecardUserManager.SEARCH_SCORECARDUSER,
                        new object[] { scorecardIds, ConstantUtility.ROLE_DIRECTOR });
                    if (scorecardUsers != null && scorecardUsers.Count > 0)
                    {
                        ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                        evaluator.UserId = scorecardUsers[0].UserId;
                        evaluator.UserType = ConstantUtility.ROLE_DIRECTOR;
                        evaluators.Add(evaluator);
                    }
                    ScorecardUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        scorecard.Id, evaluators);
                }

                double avgScore = ScorecardUtility.GetAverageScore(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, 0);
                ScorecardUtility.UpdateScore(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id, avgScore);
                
                scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id);

                scorecard.TransactionId = ScorecardWorkflowExec.ScorecardWorkflow(scorecard,
                    ScorecardStatusType.NewEvaluation.Name, "");

                return scorecard.Id;
            }
            else
            {
                return 0;
            }
        }
        #endregion

        #region Mentor Evaluation
        public static ScorecardProject CreateScorecardProjectA(MentorContract mentorContract,
            ScorecardTemplate scorecardTemplate, string userName, int userId)
        {
            ScorecardProject scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, "Mentor",
                mentorContract.TaxId, mentorContract.ContractNo, mentorContract.ProjectCode, mentorContract.Subcontractor);
            if (scorecardProject == null)
            {
                scorecardProject = ScorecardProjectUtility.CreateObject();
                scorecardProject.Type = "Mentor";
                scorecardProject.TaxId = mentorContract.TaxId;
                scorecardProject.ContractNo = mentorContract.ContractNo;
                scorecardProject.ProjectNo = mentorContract.ProjectCode;
                scorecardProject.Description = mentorContract.Description;
                scorecardProject.Boro = mentorContract.Boro;
                scorecardProject.School = mentorContract.School;
                scorecardProject.Building = mentorContract.Building;
                scorecardProject.Subcontractor = mentorContract.Subcontractor;
                scorecardProject.ChangeUser = userName;

                ScorecardProjectUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardProject);
            }

            User user;

            ScorecardProjectUserCollection projectUsers = new ScorecardProjectUserCollection();

            ScorecardTemplateUserTypeCollection userTypes = ScorecardTemplateUserTypeUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardTemplateUserTypeManager.FIND_SCORECARDTEMPLATEUSERTYPE_BY_TEMPLATE,
                new object[] { scorecardTemplate.Id, "" });
            if (userTypes != null)
            {
                foreach (ScorecardTemplateUserType templateUserType in userTypes)
                {
                    ScorecardProjectUser scorecardProjectUser = ScorecardProjectUserUtility.CreateObject();
                    scorecardProjectUser.UserId = templateUserType.UserId;
                    scorecardProjectUser.UserType = templateUserType.UserType;
                    if (templateUserType.UserId > 0)
                    {
                        user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
                            templateUserType.UserId);

                        CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, user.UserName);
                        if (cesUser != null && cesUser.Supervisor.Trim().Length > 0)
                        {
                            cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, cesUser.Supervisor.Trim());
                            User supervisor = AddSupervisor(cesUser, templateUserType.UserType + " Supervisor");
                            if (supervisor != null)
                                scorecardProjectUser.SupervisorId = supervisor.Id;
                        }
                    }
                    projectUsers.Add(scorecardProjectUser);
                }
            }

            // Senior Project Officer
            ScorecardProjectUser projectUser = AddProjectUser(ref projectUsers,
                mentorContract.SeniorProjectOfficer, ConstantUtility.ROLE_SENIOR_PROJECT_OFFICER,
                mentorContract.ChiefProjectOfficer, ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER, userId); 

            // Chief Project Officer
            projectUser = AddProjectUser(ref projectUsers,
                mentorContract.ChiefProjectOfficer, ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER,
                string.Empty, string.Empty, userId);

            SettingCollection settings = SettingUtility.FindByCriteria(
                ConstantUtility.COMMON_DATASOURCE_NAME,
                SettingManager.FIND_SETTING_BY_TYPE,
                new object[] { "ScorecardRoleUser" });
            string vpcmUser = string.Empty;
            if (settings != null)
            {
                Setting setting = settings.Find(ConstantUtility.ROLE_VP_CM);
                if (setting != null)
                    vpcmUser = setting.Name;
            }

            // VP of CM
            user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME,
                vpcmUser);
            if (user != null)
            {
                projectUser = ScorecardProjectUserUtility.CreateObject();
                projectUser.UserId = user.Id;
                projectUser.UserType = ConstantUtility.ROLE_VP_CM;
                projectUsers.Add(projectUser);
            }

            ScorecardProjectUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardProject.Id, projectUsers);

            scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, "Mentor",
                mentorContract.TaxId, mentorContract.ContractNo, mentorContract.ProjectCode, mentorContract.Subcontractor);

            return scorecardProject;
        }

        public static ScorecardProject CreateScorecardProjectB(MentorContract mentorContract,
            ScorecardTemplate scorecardTemplate, string userName, int userId)
        {
            ScorecardProject scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, "Mentor",
                mentorContract.TaxId, mentorContract.ContractNo, string.Empty, string.Empty);
            if (scorecardProject == null)
            {
                scorecardProject = ScorecardProjectUtility.CreateObject();
                scorecardProject.Type = "Mentor";
                scorecardProject.TaxId = mentorContract.TaxId;
                scorecardProject.ContractNo = mentorContract.ContractNo;
                scorecardProject.ChangeUser = userName;

                ScorecardProjectUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardProject);
            }

            User user;

            ScorecardProjectUserCollection projectUsers = new ScorecardProjectUserCollection();

            ScorecardTemplateUserTypeCollection userTypes = ScorecardTemplateUserTypeUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardTemplateUserTypeManager.FIND_SCORECARDTEMPLATEUSERTYPE_BY_TEMPLATE,
                new object[] { scorecardTemplate.Id, "" });
            if (userTypes != null)
            {
                foreach (ScorecardTemplateUserType templateUserType in userTypes)
                {
                    ScorecardProjectUser scorecardProjectUser = ScorecardProjectUserUtility.CreateObject();
                    scorecardProjectUser.UserId = templateUserType.UserId;
                    scorecardProjectUser.UserType = templateUserType.UserType;
                    if (templateUserType.UserId > 0)
                    {
                        user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
                            templateUserType.UserId);

                        CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, user.UserName);
                        if (cesUser != null && cesUser.Supervisor.Trim().Length > 0)
                        {
                            cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, cesUser.Supervisor.Trim());
                            User supervisor = AddSupervisor(cesUser, templateUserType.UserType + " Supervisor");
                            if (supervisor != null)
                                scorecardProjectUser.SupervisorId = supervisor.Id;
                        }
                    }
                    projectUsers.Add(scorecardProjectUser);
                }
            }

            SettingCollection settings = SettingUtility.FindByCriteria(
                ConstantUtility.COMMON_DATASOURCE_NAME,
                SettingManager.FIND_SETTING_BY_TYPE,
                new object[] { "ScorecardRoleUser" });

            //----------- new VP of Capital Planning position, consolodated existing serial code into this loop -jw ----------------
            if (settings != null)
            {
                // list of user types we're adding
                List<string> searchtypes = new List<string>{
                    ConstantUtility.ROLE_VP_CM,
                    ConstantUtility.ROLE_VP_ADMIN,
                    ConstantUtility.ROLE_VP_CAPITAL_PLANNING
                };

                foreach (string usertype in searchtypes)
                {
                    // if this type is in settings,
                    Setting setting = settings.Find(usertype);
                    if (setting != null)
                    {
                        // add this user object to the project
                        user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, setting.Name);
                        if (user != null)
                        {
                            ScorecardProjectUser projectUser = ScorecardProjectUserUtility.CreateObject();
                            projectUser.UserId = user.Id;
                            projectUser.UserType = usertype;
                            projectUsers.Add(projectUser);
                        }
                    }
                }
            }

            //---------------------------------------------

            #region Code Replaced By Above



            //string vpcmUser = string.Empty;
            //if (settings != null)
            //{
            //    Setting setting = settings.Find(ConstantUtility.ROLE_VP_CM);
            //    if (setting != null)
            //        vpcmUser = setting.Name;
            //}

            //// VP of CM
            //user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME,
            //    vpcmUser);
            //if (user != null)
            //{
            //    ScorecardProjectUser projectUser = ScorecardProjectUserUtility.CreateObject();
            //    projectUser.UserId = user.Id;
            //    projectUser.UserType = ConstantUtility.ROLE_VP_CM;
            //    projectUsers.Add(projectUser);
            //}

            //string vpAdminUser = string.Empty;
            //if (settings != null)
            //{
            //    Setting setting = settings.Find(ConstantUtility.ROLE_VP_ADMIN);
            //    if (setting != null)
            //        vpAdminUser = setting.Name;
            //}

            //// VP of Admin
            //user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME,
            //    vpAdminUser);
            //if (user != null)
            //{
            //    ScorecardProjectUser projectUser = ScorecardProjectUserUtility.CreateObject();
            //    projectUser.UserId = user.Id;
            //    projectUser.UserType = ConstantUtility.ROLE_VP_ADMIN;
            //    projectUsers.Add(projectUser);
            //}

            #endregion

            ScorecardProjectUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardProject.Id, projectUsers);

            scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, "Mentor",
                mentorContract.TaxId, mentorContract.ContractNo, "", "");

            return scorecardProject;
        }

        public static int CreateScorecardA(MentorContract mentorContract, int templateId, string userName, string type, int userId)
        {
            ScorecardTemplate scorecardTemplate = ScorecardTemplateUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, templateId);
            if (scorecardTemplate == null)
                return 0;

            ScorecardProject scorecardProject = CreateScorecardProjectA(mentorContract, scorecardTemplate, userName, userId);
            if (scorecardProject == null)
                return 0;

            Scorecard scorecard = ScorecardUtility.GetByRef(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardProject.Id, templateId, "Mentor A");

            if (scorecard != null)
            {
                return -scorecard.Id;
            }

            if (scorecard == null)
            {
                scorecard = ScorecardUtility.CreateObject();
                scorecard.Type = ConstantUtility.SCORECARDTEMPLATE_MENTORA;
                scorecard.RefId = scorecardProject.Id;
                scorecard.TemplateId = scorecardTemplate.Id;
                scorecard.Name = scorecardTemplate.Name;
                scorecard.IsTest = type;
                scorecard.ScoreYear = GetFiscalYear(DateTime.Now);

                if (scorecardProject.Users != null)
                {
                    ScorecardProjectUser projectUser = scorecardProject.Users.Find(ConstantUtility.ROLE_SENIOR_PROJECT_OFFICER);
                    if (projectUser != null)
                    {
                        User cs = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, projectUser.UserId);
                        if (cs != null)
                        {
                            scorecard.UserId = cs.Id;
                            scorecard.Email = cs.Email;
                            scorecard.Contact = cs.FullName;
                        }
                    }
                }
                scorecard.ReleaseDate = DateTime.Now;
                scorecard.EvaluationDate = DateTime.Now.AddDays(7);
                scorecard.CloseDate = DateTime.Now.AddDays(21);
                scorecard.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_MENTORA_EVALUATION);
                //scorecard.Status = ScorecardStatusType.NewEvaluation.Id;

                ScorecardUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard);

                ScorecardUtility.CopyFromTemplate(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, templateId);

                scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id);

                ForwardEvaluation(scorecard.Invitees);

                scorecard.TransactionId = ScorecardWorkflowExec.ScorecardWorkflow(scorecard,
                    ScorecardStatusType.NewEvaluation.Name, "");
            }
            return scorecard.Id;
        }

        public static int CreateScorecardB(MentorContract mentorContract, int templateId, string userName, string type, int userId)
        {
            ScorecardTemplate scorecardTemplate = ScorecardTemplateUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, templateId);
            if (scorecardTemplate == null)
                return 0;

            ScorecardProject scorecardProject = CreateScorecardProjectB(mentorContract, scorecardTemplate, userName, userId);
            if (scorecardProject == null)
                return 0;

            Scorecard scorecard = ScorecardUtility.GetByRef(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardProject.Id, templateId, "Mentor B");

            if (scorecard != null)
            {
                return -scorecard.Id;
            }

            if (scorecard == null)
            {
                scorecard = ScorecardUtility.CreateObject();
                scorecard.Type = scorecardTemplate.Type;
                scorecard.RefId = scorecardProject.Id;
                scorecard.TemplateId = scorecardTemplate.Id;
                scorecard.Name = scorecardTemplate.Name;
                scorecard.IsTest = type;
                scorecard.ReleaseDate = DateTime.Now;
                scorecard.EvaluationDate = DateTime.Now.AddDays(7);
                scorecard.CloseDate = DateTime.Now.AddDays(21);
                scorecard.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_MENTORB_EVALUATION);
                //scorecard.Status = ScorecardStatusType.NewEvaluation.Id;
                scorecard.ScoreYear = GetFiscalYear(DateTime.Now);

                ScorecardUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard);

                ScorecardUtility.CopyFromTemplate(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, templateId);

                scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id);

                ForwardEvaluation(scorecard.Invitees);

                scorecard.TransactionId = ScorecardWorkflowExec.ScorecardWorkflow(scorecard,
                    ScorecardStatusType.NewEvaluation.Name, "");
            }
            return scorecard.Id;
        }
        #endregion

        #region Contract Level Evaluation
        public static int CreateCCFUScorecard(string type, string taxId, string contractNo, string adHoc)
        {
            ScorecardProject scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, type, taxId, contractNo, "", "");
            if (scorecardProject == null)
            {
                scorecardProject = ScorecardProjectUtility.CreateObject();
                scorecardProject.Type = type;
                scorecardProject.TaxId = taxId;
                scorecardProject.ContractNo = contractNo;
                ScorecardProjectUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardProject);
            }

            ScorecardProjectUserCollection projectUsers = new ScorecardProjectUserCollection();

            ScorecardProjectUser projectUser = null;

            SettingCollection settings = SettingUtility.FindByCriteria(
                ConstantUtility.COMMON_DATASOURCE_NAME,
                SettingManager.FIND_SETTING_BY_TYPE,
                new object[] { "ScorecardRoleUser" });
            string ccfuUser = string.Empty;
            if (settings != null)
            {
                Setting setting = settings.Find(ConstantUtility.ROLE_OPERATIONS_DIRECTOR);
                if (setting != null)
                    ccfuUser = setting.Name;
            }

            // CCFU Director
            User user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME,
                ccfuUser);
            if (user != null)
            {
                projectUser = ScorecardProjectUserUtility.CreateObject();
                projectUser.UserId = user.Id;
                projectUser.UserType = ConstantUtility.ROLE_OPERATIONS_DIRECTOR;
                projectUsers.Add(projectUser);
            }

            ScorecardProjectUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardProject.Id, projectUsers);

            int scoreYear = GetFiscalYear(DateTime.Now);

            List<Extra> searchItems = new List<Extra>();

            Extra extraItem = new Extra();
            extraItem.Name = "TaxId";
            extraItem.Value = scorecardProject.TaxId;
            searchItems.Add(extraItem);

            extraItem = new Extra();
            extraItem.Name = "ContractNo";
            extraItem.Value = scorecardProject.ContractNo;
            searchItems.Add(extraItem);

            extraItem = new Extra();
            extraItem.Name = "EvaluationType";
            extraItem.Value = type;
            searchItems.Add(extraItem);

            extraItem = new Extra();
            extraItem.Name = "ScoreYear";
            extraItem.Value = scoreYear.ToString();
            searchItems.Add(extraItem);

            string extraXml = XmlUtility.ToXml(searchItems);

            string projectIds = "<ArrayOfScorecardProject>";
            ScorecardProjectCollection projects = ScorecardProjectUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardProjectManager.FIND_SCORECARDPROJECT,
                new object[]
                    {
                        extraXml 
                    });
            if (projects != null && projects.Count > 0)
            {
                foreach (ScorecardProject p in projects)
                {
                    projectIds += "<ScorecardProject Id=\"" + p.Id.ToString() + "\" />";
                }
            }
            projectIds += "</ArrayOfScorecardProject>";

            projectUser = null;
            ScorecardProjectUserCollection scorecardProjectUsers = ScorecardProjectUserUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardProjectUserManager.SEARCH_SCORECARDPROJECTUSER,
                new object[] { projectIds, ConstantUtility.ROLE_OPERATIONS_MANAGER });
            if (scorecardProjectUsers != null && scorecardProjectUsers.Count > 0)
            {
                projectUser = scorecardProjectUsers[0];
            }

            int templateId = GetTemplateId(ConstantUtility.SCORECARDTEMPLATE_CCFU);

            ScorecardTemplate scorecardTemplate = ScorecardTemplateUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, templateId);
            if (scorecardTemplate.Categories != null && scorecardTemplate.Categories.Count > 0)
            {
                Scorecard scorecard = ScorecardUtility.CreateObject();
                scorecard.Type = scorecardTemplate.Type;
                scorecard.RefId = scorecardProject.Id;
                scorecard.TemplateId = scorecardTemplate.Id;
                scorecard.CategoryId = scorecardTemplate.Categories[0].Id;
                scorecard.Name = scorecardTemplate.Name;
                scorecard.IsTest = adHoc;
                scorecard.ScoreYear = scoreYear;

                if (projectUser != null)
                {
                    User cs = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, projectUser.UserId);
                    if (cs != null)
                    {
                        scorecard.UserId = cs.Id;
                        scorecard.Email = cs.Email;
                        scorecard.Contact = cs.FullName;
                    }
                }
                scorecard.EvaluationDate = DateTime.Now.AddDays(7);
                scorecard.CloseDate = DateTime.Now.AddDays(21);
                scorecard.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_CCFU_EVALUATION);
                //scorecard.Status = ScorecardStatusType.NewEvaluation.Id;

                ScorecardUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard);

                ScorecardCategoryUtility.CopyFromTemplate(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, scorecardTemplate.Categories[0].Id);

                if (projectUser != null)
                {
                    // Evaluators
                    ScorecardInvitee scorecardInvitee = ScorecardInviteeUtility.CreateObject();
                    scorecardInvitee.ScorecardId = scorecard.Id;
                    scorecardInvitee.UserId = projectUser.UserId;
                    scorecardInvitee.UserType = ConstantUtility.ROLE_OPERATIONS_MANAGER;
                    scorecardInvitee.SupervisorId = projectUser.SupervisorId;
                    scorecardInvitee.Status = 0;
                    scorecardInvitee.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_EVALUATION);
                    ScorecardInviteeUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardInvitee);
                
                    // Users
                    ScorecardUserCollection scorecardUsers = new ScorecardUserCollection();
                    ScorecardUser scorecardUser = ScorecardUserUtility.CreateObject();
                    scorecardUser.UserId = projectUser.SupervisorId;
                    scorecardUser.UserType = ConstantUtility.ROLE_OPERATIONS_SUPERVISOR;
                    scorecardUsers.Add(scorecardUser);
                    ScorecardUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        scorecard.Id, scorecardUsers);
                }

                scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id);

                ForwardEvaluation(scorecard.Invitees);

                scorecard.TransactionId = ScorecardWorkflowExec.ScorecardWorkflow(scorecard,
                    ScorecardStatusType.NewEvaluation.Name, "");

                return scorecard.Id;
            }
            else
                return 0;
        }

        public static int CreateContractScorecard(string type, string taxId, string contractNo, string adHoc)
        {
            ScorecardProject scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, type, taxId, contractNo, "", "");
            if (scorecardProject == null)
            {
                scorecardProject = ScorecardProjectUtility.CreateObject();
                scorecardProject.Type = type;
                scorecardProject.TaxId = taxId;
                scorecardProject.ContractNo = contractNo;
                ScorecardProjectUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardProject);
            }

            int scoreYear = GetFiscalYear(DateTime.Now);

            List<Extra> searchItems = new List<Extra>();

            Extra extraItem = new Extra();
            extraItem.Name = "TaxId";
            extraItem.Value = scorecardProject.TaxId;
            searchItems.Add(extraItem);

            extraItem = new Extra();
            extraItem.Name = "ContractNo";
            extraItem.Value = scorecardProject.ContractNo;
            searchItems.Add(extraItem);

            string extraXml = XmlUtility.ToXml(searchItems);

            string scorecardIds = "<ArrayOfScorecard>";
            ScorecardCollection scorecards = ScorecardUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardManager.FIND_SCORECARD,
                new object[] 
                { 
                    scoreYear, 0, scorecardProject.Type, ScorecardStatusType.Complete.Id, string.Empty, extraXml 
                });
            if (scorecards != null && scorecards.Count > 0)
            {
                foreach (Scorecard s in scorecards)
                {
                    scorecardIds += "<Scorecard Id=\"" + s.Id.ToString() + "\" />";
                }
            }
            scorecardIds += "</ArrayOfScorecard>";

            Scorecard scorecard = ScorecardUtility.CreateObject();
            scorecard.Type = "Contract";
            scorecard.RefId = scorecardProject.Id;
            scorecard.Name = scorecardProject.ContractNo;
            scorecard.IsTest = adHoc;
            scorecard.ScoreYear = scoreYear;

            ScorecardUserCollection scorecardUsers = ScorecardUserUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardUserManager.SEARCH_SCORECARDUSER,
                new object[] { scorecardIds, ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST });
            if (scorecardUsers != null && scorecardUsers.Count > 0)
            {
                User cs = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, scorecardUsers[0].UserId);
                if (cs != null)
                {
                    scorecard.UserId = cs.Id;
                    scorecard.Email = cs.Email;
                    scorecard.Contact = cs.FullName;
                }
            }

            scorecard.CreateDate = DateTime.Now;
            scorecard.EvaluationDate = DateTime.Now.AddDays(7);
            scorecard.CloseDate = DateTime.Now.AddDays(14);
            scorecard.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_PROJECT_CONTRACT_EVALUATION);
            //scorecard.Status = ScorecardStatusType.NewEvaluation.Id;

            ScorecardUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard);

            if (scorecard.Id > 0)
            {
                if (scorecards != null && scorecards.Count > 0)
                {
                    LinkedScorecardCollection linkedScorecards = new LinkedScorecardCollection();
                    foreach (Scorecard s in scorecards)
                    {
                        LinkedScorecard linkedScorecard = LinkedScorecardUtility.CreateObject();
                        linkedScorecard.LinkedId = s.Id;
                        linkedScorecards.Add(linkedScorecard);
                    }

                    // CCFU
                    searchItems = new List<Extra>();

                    extraItem = new Extra();
                    extraItem.Name = "TaxId";
                    extraItem.Value = scorecardProject.TaxId;
                    searchItems.Add(extraItem);

                    extraItem = new Extra();
                    extraItem.Name = "ContractNo";
                    extraItem.Value = scorecardProject.ContractNo;
                    searchItems.Add(extraItem);

                    extraXml = XmlUtility.ToXml(searchItems);

                    ScorecardCollection ccfuScorecards = ScorecardUtility.FindByCriteria(
                        ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        ScorecardManager.FIND_SCORECARD,
                        new object[] 
                        { 
                            scoreYear, 0, "CCFU", 0, string.Empty, extraXml 
                        });
                    if (ccfuScorecards != null && ccfuScorecards.Count > 0)
                    {
                        foreach (Scorecard ccfuScorecard in ccfuScorecards)
                        {
                            LinkedScorecard linkedScorecard = LinkedScorecardUtility.CreateObject();
                            linkedScorecard.LinkedId = ccfuScorecard.Id;
                            linkedScorecards.Add(linkedScorecard);

                        }
                    }

                    LinkedScorecardUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        scorecard.Id, linkedScorecards);

                    ScorecardUserCollection evaluators = new ScorecardUserCollection();
                    // DPM
                    if (scorecardUsers != null && scorecardUsers.Count > 0)
                    {
                        ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                        evaluator.UserId = scorecardUsers[0].UserId;
                        evaluator.UserType = ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST;
                        evaluators.Add(evaluator);
                    }

                    // Design Manager
                    scorecardUsers = ScorecardUserUtility.FindByCriteria(
                        ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        ScorecardUserManager.SEARCH_SCORECARDUSER,
                        new object[] { scorecardIds, ConstantUtility.ROLE_DESIGN_MANAGER });
                    if (scorecardUsers != null && scorecardUsers.Count > 0)
                    {
                        ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                        evaluator.UserId = scorecardUsers[0].UserId;
                        evaluator.UserType = ConstantUtility.ROLE_DESIGN_MANAGER;
                        evaluators.Add(evaluator);
                    }

                    // Deputy Director
                    scorecardUsers = ScorecardUserUtility.FindByCriteria(
                        ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        ScorecardUserManager.SEARCH_SCORECARDUSER,
                        new object[] { scorecardIds, ConstantUtility.ROLE_DEPUTY_DIRECTOR });
                    if (scorecardUsers != null && scorecardUsers.Count > 0)
                    {
                        ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                        evaluator.UserId = scorecardUsers[0].UserId;
                        evaluator.UserType = ConstantUtility.ROLE_DEPUTY_DIRECTOR;
                        evaluators.Add(evaluator);
                    }

                    // Director
                    scorecardUsers = ScorecardUserUtility.FindByCriteria(
                        ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        ScorecardUserManager.SEARCH_SCORECARDUSER,
                        new object[] { scorecardIds, ConstantUtility.ROLE_DIRECTOR });
                    if (scorecardUsers != null && scorecardUsers.Count > 0)
                    {
                        ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                        evaluator.UserId = scorecardUsers[0].UserId;
                        evaluator.UserType = ConstantUtility.ROLE_DIRECTOR;
                        evaluators.Add(evaluator);
                    }
                    ScorecardUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        scorecard.Id, evaluators);
                }

                double avgScore = ScorecardUtility.GetAverageScore(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, 0);
                ScorecardUtility.UpdateScore(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id, avgScore);

                scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id);

                scorecard.TransactionId = ScorecardWorkflowExec.ScorecardWorkflow(scorecard,
                    ScorecardStatusType.NewEvaluation.Name, "");

                return scorecard.Id;
            }
            else
            {
                return 0;
            }
        }

        public static int CreateMentorAContractScorecard(string taxId, string contractNo, string designTaxId, string adHoc)
        {
            ScorecardProject scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, "Mentor", taxId, contractNo, "", "");
            if (scorecardProject == null)
            {
                scorecardProject = ScorecardProjectUtility.CreateObject();
                scorecardProject.Type = "Mentor";
                scorecardProject.TaxId = taxId;
                scorecardProject.ContractNo = contractNo;
                ScorecardProjectUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardProject);
            }

            int scoreYear = GetFiscalYear(DateTime.Now);

            List<Extra> searchItems = new List<Extra>();

            Extra extraItem = new Extra();
            extraItem.Name = "TaxId";
            extraItem.Value = scorecardProject.TaxId;
            searchItems.Add(extraItem);

            extraItem = new Extra();
            extraItem.Name = "ContractNo";
            extraItem.Value = scorecardProject.ContractNo;
            searchItems.Add(extraItem);

            string extraXml = XmlUtility.ToXml(searchItems);
            DateTime releaseDate = new DateTime(1900, 1, 1);

            string scorecardIds = "<ArrayOfScorecard>";
            ScorecardCollection scorecards = ScorecardUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardManager.FIND_SCORECARD,
                new object[] 
                { 
                    scoreYear, 0, "Mentor A", ScorecardStatusType.EvaluationCompleted.Id, string.Empty, extraXml 
                });
            if (scorecards != null && scorecards.Count > 0)
            {
                foreach (Scorecard s in scorecards)
                {
                    scorecardIds += "<Scorecard Id=\"" + s.Id.ToString() + "\" />";
                    releaseDate = s.ReleaseDate;
                }
            }
            scorecardIds += "</ArrayOfScorecard>";

            Scorecard scorecard = ScorecardUtility.CreateObject();
            scorecard.Type = "Mentor A Contract";
            scorecard.RefId = scorecardProject.Id;
            scorecard.Name = scorecardProject.ContractNo;
            scorecard.IsTest = adHoc;
            scorecard.ScoreYear = scoreYear;
            scorecard.ReleaseDate = releaseDate;

            ScorecardUserCollection scorecardUsers = ScorecardUserUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardUserManager.SEARCH_SCORECARDUSER,
                new object[] { scorecardIds, ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER });
            if (scorecardUsers != null && scorecardUsers.Count > 0)
            {
                User cs = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, scorecardUsers[0].UserId);
                if (cs != null)
                {
                    scorecard.UserId = cs.Id;
                    scorecard.Email = cs.Email;
                    scorecard.Contact = cs.FullName;
                }
            }

            scorecard.CreateDate = DateTime.Now;
            scorecard.EvaluationDate = DateTime.Now.AddDays(7);
            scorecard.CloseDate = DateTime.Now.AddDays(14);
            scorecard.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_MENTORA_CONTRACT_EVALUATION);
            //scorecard.Status = ScorecardStatusType.NewEvaluation.Id;

            ScorecardUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard);

            if (scorecard.Id > 0)
            {
                if (scorecards != null && scorecards.Count > 0)
                {
                    LinkedScorecardCollection linkedScorecards = new LinkedScorecardCollection();
                    foreach (Scorecard s in scorecards)
                    {
                        LinkedScorecard linkedScorecard = LinkedScorecardUtility.CreateObject();
                        linkedScorecard.LinkedId = s.Id;
                        linkedScorecards.Add(linkedScorecard);
                    }

                    LinkedScorecardUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        scorecard.Id, linkedScorecards);

                    ScorecardUser scorecardUser = null;

                    ScorecardUserCollection evaluators = new ScorecardUserCollection();
                    // CPO
                    if (scorecardUsers != null && scorecardUsers.Count > 0)
                    {
                        // URS
                        if (taxId == "11-1445800")
                        {
                            // Queens CPO
                            scorecardUser = scorecardUsers.Find("Queens", ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER);
                            if (scorecardUser != null)
                            {
                                ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                                evaluator.UserId = scorecardUser.UserId;
                                evaluator.UserType = ConstantUtility.ROLE_QUEENS_CPO;
                                evaluators.Add(evaluator);
                            }

                            // Manhattan & Bronx CPO
                            scorecardUser = scorecardUsers.Find("Manhattan", ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER);
                            if (scorecardUser != null)
                            {
                                ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                                evaluator.UserId = scorecardUser.UserId;
                                evaluator.UserType = ConstantUtility.ROLE_MANHATTAN_CPO;
                                evaluators.Add(evaluator);
                            }

                            scorecardUser = scorecardUsers.Find("Bronx", ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER);
                            if (scorecardUser != null)
                            {
                                ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                                evaluator.UserId = scorecardUser.UserId;
                                evaluator.UserType = ConstantUtility.ROLE_BRONX_CPO;
                                evaluators.Add(evaluator);
                            }
                        }
                        // TDX
                        else if (taxId == "13-3039254")
                        {
                            // Brooklyn and Staten Island CPO
                            scorecardUser = scorecardUsers.Find("Brooklyn", ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER);
                            if (scorecardUser != null)
                            {
                                ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                                evaluator.UserId = scorecardUser.UserId;
                                evaluator.UserType = ConstantUtility.ROLE_BROOKLYN_CPO;
                                evaluators.Add(evaluator);
                            }

                            scorecardUser = scorecardUsers.Find("Staten Island", ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER);
                            if (scorecardUser != null)
                            {
                                ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                                evaluator.UserId = scorecardUser.UserId;
                                evaluator.UserType = ConstantUtility.ROLE_STATEN_ISLAND_CPO;
                                evaluators.Add(evaluator);
                            }
                        }
                        // STV
                        else if (taxId == "26-2372568")
                        {
                            // Manhattan & Bronx CPO
                            scorecardUser = scorecardUsers.Find("Manhattan", ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER);
                            if (scorecardUser != null)
                            {
                                ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                                evaluator.UserId = scorecardUser.UserId;
                                evaluator.UserType = ConstantUtility.ROLE_MANHATTAN_CPO;
                                evaluators.Add(evaluator);
                            }

                            scorecardUser = scorecardUsers.Find("Bronx", ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER);
                            if (scorecardUser != null)
                            {
                                ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                                evaluator.UserId = scorecardUser.UserId;
                                evaluator.UserType = ConstantUtility.ROLE_BRONX_CPO;
                                evaluators.Add(evaluator);
                            }
                        }
                        else
                        {
                            ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                            evaluator.UserId = scorecardUsers[0].UserId;
                            evaluator.UserType = ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER;
                            evaluators.Add(evaluator);
                        }
                    }

                    // VP of CM
                    scorecardUsers = ScorecardUserUtility.FindByCriteria(
                        ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        ScorecardUserManager.SEARCH_SCORECARDUSER,
                        new object[] { scorecardIds, ConstantUtility.ROLE_VP_CM });
                    if (scorecardUsers != null && scorecardUsers.Count > 0)
                    {
                        ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                        evaluator.UserId = scorecardUsers[0].UserId;
                        evaluator.UserType = ConstantUtility.ROLE_VP_CM;
                        evaluators.Add(evaluator);
                    }
                    ScorecardUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        scorecard.Id, evaluators);
                }

                double avgScore = ScorecardUtility.GetAverageScore(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, 0);
                ScorecardUtility.UpdateScore(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id, avgScore);

                scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id);

                scorecard.TransactionId = ScorecardWorkflowExec.ScorecardWorkflow(scorecard,
                    ScorecardStatusType.NewEvaluation.Name, "");

                return scorecard.Id;
            }
            else
            {
                return 0;
            }
        }

        public static int CreateMentorBContractScorecard(string taxId, string contractNo, string adHoc)
        {
            ScorecardProject scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, "Mentor", taxId, contractNo, "", "");
            if (scorecardProject == null)
            {
                scorecardProject = ScorecardProjectUtility.CreateObject();
                scorecardProject.Type = "Mentor";
                scorecardProject.TaxId = taxId;
                scorecardProject.ContractNo = contractNo;
                ScorecardProjectUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardProject);
            }

            int scoreYear = GetFiscalYear(DateTime.Now);

            List<Extra> searchItems = new List<Extra>();

            Extra extraItem = new Extra();
            extraItem.Name = "TaxId";
            extraItem.Value = scorecardProject.TaxId;
            searchItems.Add(extraItem);

            extraItem = new Extra();
            extraItem.Name = "ContractNo";
            extraItem.Value = scorecardProject.ContractNo;
            searchItems.Add(extraItem);

            string extraXml = XmlUtility.ToXml(searchItems);

            string scorecardIds = "<ArrayOfScorecard>";
            ScorecardCollection scorecards = ScorecardUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardManager.FIND_SCORECARD,
                new object[] 
                { 
                    scoreYear, 0, "Mentor B", ScorecardStatusType.Complete.Id, string.Empty, extraXml 
                });
            if (scorecards != null && scorecards.Count > 0)
            {
                foreach (Scorecard s in scorecards)
                {
                    scorecardIds += "<Scorecard Id=\"" + s.Id.ToString() + "\" />";
                }
            }
            scorecardIds += "</ArrayOfScorecard>";

            Scorecard scorecard = ScorecardUtility.CreateObject();
            scorecard.Type = "Mentor B Contract";
            scorecard.RefId = scorecardProject.Id;
            scorecard.Name = scorecardProject.ContractNo;
            scorecard.IsTest = adHoc;
            scorecard.ScoreYear = scoreYear;

            ScorecardUserCollection scorecardUsers = ScorecardUserUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardUserManager.SEARCH_SCORECARDUSER,
                new object[] { scorecardIds, ConstantUtility.ROLE_SENIOR_DIRECTOR_BDD });
            if (scorecardUsers != null && scorecardUsers.Count > 0)
            {
                User cs = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, scorecardUsers[0].UserId);
                if (cs != null)
                {
                    scorecard.UserId = cs.Id;
                    scorecard.Email = cs.Email;
                    scorecard.Contact = cs.FullName;
                }
            }

            scorecard.CreateDate = DateTime.Now;
            scorecard.EvaluationDate = DateTime.Now.AddDays(7);
            scorecard.CloseDate = DateTime.Now.AddDays(14);
            scorecard.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_MENTORB_CONTRACT_EVALUATION);
            //scorecard.Status = ScorecardStatusType.NewEvaluation.Id;

            ScorecardUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard);

            if (scorecard.Id > 0)
            {
                if (scorecards != null && scorecards.Count > 0)
                {
                    LinkedScorecardCollection linkedScorecards = new LinkedScorecardCollection();
                    foreach (Scorecard s in scorecards)
                    {
                        LinkedScorecard linkedScorecard = LinkedScorecardUtility.CreateObject();
                        linkedScorecard.LinkedId = s.Id;
                        linkedScorecards.Add(linkedScorecard);
                    }

                    LinkedScorecardUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        scorecard.Id, linkedScorecards);

                    ScorecardUserCollection evaluators = new ScorecardUserCollection();
                    // VP of CM
                    scorecardUsers = ScorecardUserUtility.FindByCriteria(
                        ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        ScorecardUserManager.SEARCH_SCORECARDUSER,
                        new object[] { scorecardIds, ConstantUtility.ROLE_VP_CM });

                    if (scorecardUsers != null && scorecardUsers.Count > 0)
                    {
                        ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                        evaluator.UserId = scorecardUsers[0].UserId;
                        evaluator.UserType = ConstantUtility.ROLE_VP_CM;
                        evaluators.Add(evaluator);
                    }

                    // VP of Admin
                    if (scorecardUsers != null && scorecardUsers.Count > 0)
                    {
                        ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                        evaluator.UserId = scorecardUsers[0].UserId;
                        evaluator.UserType = ConstantUtility.ROLE_VP_ADMIN;
                        evaluators.Add(evaluator);
                    }

                    // VP of Capital Planning
                    if (scorecardUsers != null && scorecardUsers.Count > 0)
                    {
                        ScorecardUser evaluator = ScorecardUserUtility.CreateObject();
                        evaluator.UserId = scorecardUsers[0].UserId;
                        evaluator.UserType = ConstantUtility.ROLE_VP_CAPITAL_PLANNING;
                        evaluators.Add(evaluator);
                    }

                    ScorecardUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        scorecard.Id, evaluators);
                }

                double avgScore = ScorecardUtility.GetAverageScore(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, 0);
                ScorecardUtility.UpdateScore(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id, avgScore);

                scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id);

                scorecard.TransactionId = ScorecardWorkflowExec.ScorecardWorkflow(scorecard,
                    ScorecardStatusType.NewEvaluation.Name, "");

                return scorecard.Id;
            }
            else
            {
                return 0;
            }
        }
        #endregion

        #region IEH Evaluation
        public static ScorecardProject CreateScorecardProject(IehContract iehContract,
            ScorecardTemplate scorecardTemplate, string userName, int userId)
        {
            if (string.Compare(iehContract.ContractType, "HazMat", true) != 0)
                iehContract.ContractType = "Non-HazMat";
            ScorecardProject scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, iehContract.ContractType,
                iehContract.TaxId.Trim(), iehContract.ContractNo.Trim(), iehContract.RfpNo.Trim(), iehContract.JobNo.Trim() + "|" + iehContract.ProjectCode.Trim());
            if (scorecardProject == null)
            {
                scorecardProject = ScorecardProjectUtility.CreateObject();
                scorecardProject.Type = iehContract.ContractType;
                scorecardProject.TaxId = iehContract.TaxId.Trim();
                scorecardProject.ContractNo = iehContract.ContractNo.Trim();
                scorecardProject.ProjectNo = iehContract.RfpNo.Trim();
                scorecardProject.Subcontractor = iehContract.JobNo.Trim() + "|" + iehContract.ProjectCode.Trim();
                scorecardProject.Boro = iehContract.Boro.Trim();
                scorecardProject.School = iehContract.School.Trim();
                scorecardProject.Building = iehContract.FacilityCode.Trim();
                scorecardProject.Description = iehContract.ApprovalDate.ToString(ConstantUtility.DATE_FORMAT);
                scorecardProject.ChangeUser = userName;

                ScorecardProjectUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardProject);
            }

            ScorecardProjectUserCollection projectUsers = new ScorecardProjectUserCollection();

            User user;
            ScorecardTemplateUserTypeCollection userTypes = ScorecardTemplateUserTypeUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardTemplateUserTypeManager.FIND_SCORECARDTEMPLATEUSERTYPE_BY_TEMPLATE,
                new object[] { scorecardTemplate.Id, string.Empty });
            if (userTypes != null)
            {
                foreach (ScorecardTemplateUserType templateUserType in userTypes)
                {
                    ScorecardProjectUser scorecardProjectUser = ScorecardProjectUserUtility.CreateObject();
                    scorecardProjectUser.UserId = templateUserType.UserId;
                    scorecardProjectUser.UserType = templateUserType.UserType;
                    if (templateUserType.UserId > 0)
                    {
                        user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
                            templateUserType.UserId);

                        CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, user.UserName);
                        if (cesUser != null && cesUser.Supervisor.Trim().Length > 0)
                        {
                            cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, cesUser.Supervisor.Trim());
                            User supervisor = AddSupervisor(cesUser, templateUserType.UserType + " Supervisor");
                            if (supervisor != null)
                                scorecardProjectUser.SupervisorId = supervisor.Id;
                        }
                    }
                    projectUsers.Add(scorecardProjectUser);
                }
            }

            // Evaluator, changed the supervisor from evaluator supervisor to hygienist c reviewer
            ScorecardProjectUser projectUser = AddProjectUser(ref projectUsers,
               iehContract.Evaluator, ConstantUtility.ROLE_HYGIENIST_B,
               iehContract.Reviewer, ConstantUtility.ROLE_HYGIENIST_C, userId);

            // Reviewer
            projectUser = AddProjectUser(ref projectUsers,
               iehContract.Reviewer, ConstantUtility.ROLE_HYGIENIST_C,
               iehContract.ReviewerSupervisor, ConstantUtility.ROLE_HYGIENIST_C_SUPERVISOR, userId);

            // Senior Project Officer
            projectUser = AddProjectUser(ref projectUsers,
                iehContract.SeniorProjectOfficer, ConstantUtility.ROLE_SENIOR_PROJECT_OFFICER,
                iehContract.ChiefProjectOfficer, ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER, userId);

            ScorecardProjectUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardProject.Id, projectUsers);

            scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, iehContract.ContractType,
                iehContract.TaxId.Trim(), iehContract.ContractNo.Trim(), iehContract.RfpNo.Trim(), iehContract.JobNo.Trim() + "|" + iehContract.ProjectCode.Trim());

            return scorecardProject;
        }

        public static int CreateScorecard(IehContract iehContract, ScorecardTemplate scorecardTemplate,
            int categoryId, string userName, string type, int userId)
        {
            ScorecardProject scorecardProject = CreateScorecardProject(iehContract, scorecardTemplate, userName, userId);
            if (scorecardProject == null)
            {
                return 0;
            }

            Scorecard scorecard = null;

            if (type == "N")
            {
                scorecard = ScorecardUtility.GetByRef(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecardProject.Id, categoryId, "Y");

                if (scorecard != null && scorecard.CreateDate.AddDays(30) > DateTime.Now)
                {
                    ScorecardWorkflowExec.ScorecardWorkflow(scorecard, ScorecardStatusType.Obsolete.Name, "");
                }
            }

            scorecard = ScorecardUtility.GetByRef(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardProject.Id, categoryId, "");
            if (scorecard != null)
            {
                return -scorecard.Id;
            }

            if (scorecard == null)
            {
                scorecard = ScorecardUtility.CreateObject();
                scorecard.Type = scorecardTemplate.Type;
                scorecard.RefId = scorecardProject.Id;
                scorecard.TemplateId = scorecardTemplate.Id;
                scorecard.CategoryId = categoryId;
                scorecard.Name = scorecardTemplate.Name;
                scorecard.IsTest = type;
                scorecard.ScoreYear = GetFiscalYear(DateTime.Now);

                if (scorecardProject.Users != null)
                {
                    ScorecardProjectUser projectUser = scorecardProject.Users.Find(ConstantUtility.ROLE_HYGIENIST_B);
                    if (projectUser != null)
                    {
                        User cs = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, projectUser.UserId);
                        if (cs != null)
                        {
                            scorecard.UserId = cs.Id;
                            scorecard.Email = cs.Email;
                            scorecard.Contact = cs.FullName;
                        }
                    }
                }
                //scorecard.ReleaseDate = DateTime.Now.AddDays(2);
                scorecard.EvaluationDate = DateTime.Now.AddDays(7);
                scorecard.CloseDate = DateTime.Now.AddDays(21);
                scorecard.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_IEH_EVALUATION);
                //scorecard.Status = ScorecardStatusType.NewEvaluation.Id;

                ScorecardUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard);

                if (categoryId > 0)
                    ScorecardCategoryUtility.CopyFromTemplate(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        scorecard.Id, categoryId);

                string roleName = ConstantUtility.ROLE_IEH_DEPUTY_DIRECTOR;
                if (string.Compare(scorecard.Type, "Non-HazMat", true) == 0)
                    roleName = ConstantUtility.ROLE_IEH_MANAGER;
                UserCollection users = UserUtility.FindByCriteria(
                    ConstantUtility.USER_DATASOURCE_NAME,
                    UserManager.FIND_USER_BY_POST,
                    new object[] { 0, 0, "LastName", "ASC", 0, roleName });

                ScorecardUserCollection reviewers = new ScorecardUserCollection();
                
                // Manager or Deputy Director
                if (users != null && users.Count > 0)
                {
                    ScorecardUser reviewer = ScorecardUserUtility.CreateObject();
                    reviewer.UserId = users[0].Id;
                    reviewer.UserType = roleName;
                    reviewer.Status = -1;
                    reviewers.Add(reviewer);
                }

                ScorecardUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, reviewers);

                scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id);

                ForwardEvaluation(scorecard.Invitees);
                
                scorecard.TransactionId = ScorecardWorkflowExec.ScorecardWorkflow(scorecard,
                    ScorecardStatusType.NewEvaluation.Name, "");
            }
            return scorecard.Id;
        }

        public static ScorecardProject CreateScorecardProjectIEHContract(IehContract iehContract,
            ScorecardTemplate scorecardTemplate, string userName, int userId)
        {
            if (string.Compare(iehContract.ContractType, "HazMat", true) != 0)
                iehContract.ContractType = "Non-HazMat";
            ScorecardProject scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, iehContract.ContractType,
                iehContract.TaxId, iehContract.ContractNo, "", "");
            if (scorecardProject == null)
            {
                scorecardProject = ScorecardProjectUtility.CreateObject();
                scorecardProject.Type = iehContract.ContractType;
                scorecardProject.TaxId = iehContract.TaxId;
                scorecardProject.ContractNo = iehContract.ContractNo;
                scorecardProject.ChangeUser = userName;

                ScorecardProjectUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardProject);
            }

            ScorecardProjectUserCollection projectUsers = new ScorecardProjectUserCollection();

            string categoryType = "Non-HazMat";
            if (iehContract.ContractType.ToLower() == "hazmat")
                categoryType = "HazMat";

            User user;
            ScorecardTemplateUserTypeCollection userTypes = ScorecardTemplateUserTypeUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardTemplateUserTypeManager.FIND_SCORECARDTEMPLATEUSERTYPE_BY_TEMPLATE,
                new object[] { scorecardTemplate.Id, categoryType });
            if (userTypes != null)
            {
                foreach (ScorecardTemplateUserType templateUserType in userTypes)
                {
                    ScorecardProjectUser scorecardProjectUser = ScorecardProjectUserUtility.CreateObject();
                    scorecardProjectUser.UserId = templateUserType.UserId;
                    scorecardProjectUser.UserType = templateUserType.UserType;
                    if (templateUserType.UserId > 0)
                    {
                        user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
                            templateUserType.UserId);

                        CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, user.UserName);
                        if (cesUser != null && cesUser.Supervisor.Trim().Length > 0)
                        {
                            cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, cesUser.Supervisor.Trim());
                            User supervisor = AddSupervisor(cesUser, templateUserType.UserType + " Supervisor");
                            if (supervisor != null)
                                scorecardProjectUser.SupervisorId = supervisor.Id;
                        }
                    }
                    projectUsers.Add(scorecardProjectUser);
                }
            }

            // Senior Project Officer
            ScorecardProjectUser projectUser = AddProjectUser(ref projectUsers,
                iehContract.SeniorProjectOfficer, ConstantUtility.ROLE_SENIOR_PROJECT_OFFICER,
                iehContract.ChiefProjectOfficer, ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER, userId);

            ScorecardProjectUserUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardProject.Id, projectUsers);

            scorecardProject = ScorecardProjectUtility.GetByContract(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, iehContract.ContractType,
                iehContract.TaxId, iehContract.ContractNo, "", "");

            return scorecardProject;
        }

        public static int CreateContractScorecard(string scorecardType, IehContract iehContract, int templateId, string userName, string type, int userId)
        {
            ScorecardTemplate scorecardTemplate = ScorecardTemplateUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, templateId);
            if (scorecardTemplate == null)
                return 0;

            ScorecardProject scorecardProject = CreateScorecardProjectIEHContract(iehContract, scorecardTemplate, userName, userId);
            if (scorecardProject == null)
                return 0;

            Scorecard scorecard = ScorecardUtility.GetByRef(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardProject.Id, templateId, scorecardType);

            if (scorecard != null)
            {
                return -scorecard.Id;
            }

            if (scorecard == null)
            {
                scorecard = ScorecardUtility.CreateObject();
                scorecard.Type = scorecardType;
                scorecard.RefId = scorecardProject.Id;
                scorecard.TemplateId = scorecardTemplate.Id;
                scorecard.Name = scorecardTemplate.Name;
                scorecard.IsTest = type;
                scorecard.ScoreYear = GetFiscalYear(DateTime.Now);

                if (scorecardProject.Users != null)
                {
                    string roleName = ConstantUtility.ROLE_IEH_DEPUTY_DIRECTOR;
                    if (iehContract.ContractType.ToLower() == "non-hazmat")
                        roleName = ConstantUtility.ROLE_IEH_MANAGER;
                    ScorecardProjectUser projectUser = scorecardProject.Users.Find(roleName);
                    if (projectUser != null)
                    {
                        User cs = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, projectUser.UserId);
                        if (cs != null)
                        {
                            scorecard.UserId = cs.Id;
                            scorecard.Email = cs.Email;
                            scorecard.Contact = cs.FullName;
                        }
                    }
                }
                scorecard.CreateDate = DateTime.Now;
                scorecard.EvaluationDate = DateTime.Now.AddDays(7);
                scorecard.CloseDate = DateTime.Now.AddDays(21);
                scorecard.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_IEH_CONTRACT_EVALUATION);
                //scorecard.Status = ScorecardStatusType.NewEvaluation.Id;

                ScorecardUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard);

                List<Extra> searchItems = new List<Extra>();

                Extra extraItem = new Extra();
                extraItem.Name = "TaxId";
                extraItem.Value = iehContract.TaxId.Trim();
                searchItems.Add(extraItem);

                extraItem = new Extra();
                extraItem.Name = "ContractNo";
                extraItem.Value = iehContract.ContractNo.Trim();
                searchItems.Add(extraItem);

                string extraXml = XmlUtility.ToXml(searchItems);

                ScorecardCollection scorecards = ScorecardUtility.FindByCriteria(
                    ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    ScorecardManager.FIND_SCORECARD,
                    new object[] 
                    { 
                        0, 0, scorecardType, 0, string.Empty, extraXml 
                    });

                if (scorecards != null)
                {
                    LinkedScorecardCollection linkedScorecards = new LinkedScorecardCollection();
                    foreach (Scorecard s in scorecards)
                    {
                        LinkedScorecard linkedScorecard = LinkedScorecardUtility.CreateObject();
                        linkedScorecard.LinkedId = s.Id;
                        linkedScorecards.Add(linkedScorecard);
                    }
                    LinkedScorecardUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                        scorecard.Id, linkedScorecards);
                }

                ScorecardUtility.CopyFromTemplate(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecard.Id, templateId);

                scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id);

                ForwardEvaluation(scorecard.Invitees);

                scorecard.TransactionId = ScorecardWorkflowExec.ScorecardWorkflow(scorecard,
                    ScorecardStatusType.NewEvaluation.Name, "");
            }
            return scorecard.Id;
        }
        #endregion

        public static string EvaluatorComments(ScorecardInviteeCollection invitees, 
            ScorecardScoreCollection scorecardScores, int categoryId, int questionId)
        {
            string allComments = string.Empty;
            if (invitees != null && scorecardScores != null)
            {
                SettingCollection settings = GetSettings("EvaluationUserType.xml");

                foreach (ScorecardInvitee invitee in invitees)
                {
                    foreach (ScorecardScore scorecardScore in scorecardScores)
                    {
                        if (scorecardScore.UserId == invitee.UserId && scorecardScore.CategoryId == categoryId &&
                            scorecardScore.QuestionId == questionId)
                        {
                            Setting setting = settings.Find(invitee.UserType);
                            if (setting != null)
                                allComments += setting.Name;
                            else
                                allComments += invitee.UserType;
                            if (categoryId == 0 || questionId == 0)
                                allComments += " - " + scorecardScore.Score.ToString("f2") + " - ";
                            else
                                allComments += " - " + scorecardScore.Score.ToString("f0") + " - ";
                            //allComments += " - ";
                            if (scorecardScore.Comment.Trim().Length > 0)
                            {
                                allComments += scorecardScore.Comment + " (" + scorecardScore.Type + ")";
                            }
                            ScorecardAttachmentCollection attachments = ScorecardAttachmentUtility.FindByCriteria(
                                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                                ScorecardAttachmentManager.FIND_SCORECARDATTACHMENT,
                                new object[] { scorecardScore.ScorecardId, "ScorecardScore", scorecardScore.Id });
                            if (attachments != null && attachments.Count > 0)
                            {
                                allComments += "<br />";
                                allComments += "<a href=\"GetScorecardAttachment.aspx?Id=" + attachments[0].Id.ToString() +
                                    "\">" + attachments[0].FileName + "</a>";
                            }
                            allComments += "<br />";
                            break;
                        }
                    }
                }
            }
            return allComments;
        }

        public static string EvaluatorExternalComments(ScorecardInviteeCollection invitees, 
            ScorecardScoreCollection scorecardScores, int categoryId, int questionId)
        {
            string allComments = string.Empty;
            if (invitees != null && scorecardScores != null)
            {
                foreach (ScorecardInvitee invitee in invitees)
                {
                    foreach (ScorecardScore scorecardScore in scorecardScores)
                    {
                        if (scorecardScore.UserId == invitee.UserId && scorecardScore.CategoryId == categoryId &&
                            scorecardScore.QuestionId == questionId && scorecardScore.Comment.Trim().Length > 0 && 
                            scorecardScore.Type == "External")
                        {
                            allComments += scorecardScore.Comment;
                            allComments += "\r\n";
                            break;
                        }
                    }
                }
            }
            return allComments;
        }

        public static string ReviewerComments(ScorecardUserCollection users,
            ScorecardCommentCollection scorecardComments, int categoryId, int questionId)
        {
            string allComments = string.Empty;
            if (users != null && scorecardComments != null)
            {
                SettingCollection settings = GetSettings("EvaluationUserType.xml");

                foreach (ScorecardComment scorecardComment in scorecardComments)
                {
                    if (scorecardComment.Status == 2) continue;

                    foreach (ScorecardUser user in users)
                    {
                        if (scorecardComment.UserType == user.UserType && scorecardComment.CategoryId == categoryId &&
                            scorecardComment.QuestionId == questionId && scorecardComment.Comment.Trim().Length > 0)
                        {
                            Setting setting = settings.Find(user.UserType);
                            if (setting != null)
                                allComments += setting.Name;
                            else
                                allComments += user.UserType;
                            allComments += " - ";
                            allComments += scorecardComment.Comment;
                            allComments += "<br />";

                            ScorecardAttachmentCollection attachments = ScorecardAttachmentUtility.FindByCriteria(
                                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                                ScorecardAttachmentManager.FIND_SCORECARDATTACHMENT,
                                new object[] { scorecardComment.ScorecardId, "ScorecardComment", scorecardComment.Id });
                            if (attachments != null && attachments.Count > 0)
                            {
                                allComments += "<a href=\"GetScorecardAttachment.aspx?Id=" + attachments[0].Id.ToString() +
                                    "\">" + attachments[0].FileName + "</a>";
                                allComments += "<br />";
                            }
                            break;
                        }
                    }
                }
            }
            return allComments;
        }

        public static string ReviewerComments(ScorecardInviteeCollection invitees,
            ScorecardCommentCollection scorecardComments, int categoryId, int questionId)
        {
            string allComments = string.Empty;
            if (invitees != null && scorecardComments != null)
            {
                SettingCollection settings = GetSettings("EvaluationUserType.xml");

                foreach (ScorecardComment scorecardComment in scorecardComments)
                {
                    if (scorecardComment.Status == 2) continue;

                    foreach (ScorecardInvitee invitee in invitees)
                    {
                        if (scorecardComment.UserType == invitee.UserType && scorecardComment.CategoryId == categoryId &&
                            scorecardComment.QuestionId == questionId && scorecardComment.Comment.Trim().Length > 0)
                        {
                            Setting setting = settings.Find(invitee.UserType);
                            if (setting != null)
                                allComments += setting.Name;
                            else
                                allComments += invitee.UserType;
                            allComments += " - ";
                            allComments += scorecardComment.Comment;
                            allComments += "<br />";

                            ScorecardAttachmentCollection attachments = ScorecardAttachmentUtility.FindByCriteria(
                                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                                ScorecardAttachmentManager.FIND_SCORECARDATTACHMENT,
                                new object[] { scorecardComment.ScorecardId, "ScorecardComment", scorecardComment.Id });
                            if (attachments != null && attachments.Count > 0)
                            {
                                allComments += "<a href=\"GetScorecardAttachment.aspx?Id=" + attachments[0].Id.ToString() +
                                    "\">" + attachments[0].FileName + "</a>";
                                allComments += "<br />";
                            }
                            break;
                        }
                        else if (scorecardComment.UserType == invitee.SupervisorType && scorecardComment.CategoryId == categoryId &&
                            scorecardComment.QuestionId == questionId && scorecardComment.Comment.Trim().Length > 0)
                        {
                            Setting setting = settings.Find(invitee.SupervisorType);
                            if (setting != null)
                                allComments += setting.Name;
                            else
                                allComments += invitee.SupervisorType;
                            allComments += " - ";
                            allComments += scorecardComment.Comment;
                            allComments += "<br />";

                            ScorecardAttachmentCollection attachments = ScorecardAttachmentUtility.FindByCriteria(
                                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                                ScorecardAttachmentManager.FIND_SCORECARDATTACHMENT,
                                new object[] { scorecardComment.ScorecardId, "ScorecardComment", scorecardComment.Id });
                            if (attachments != null && attachments.Count > 0)
                            {
                                allComments += "<a href=\"GetScorecardAttachment.aspx?Id=" + attachments[0].Id.ToString() +
                                    "\">" + attachments[0].FileName + "</a>";
                                allComments += "<br />";
                            }
                            break;
                        }
                    }
                }
            }
            return allComments;
        }

        public static string ReviewerLastComments(ScorecardUserCollection users,
            ScorecardCommentCollection scorecardComments, int categoryId, int questionId)
        {
            string allComments = string.Empty;
            if (users != null && scorecardComments != null)
            {
                foreach (ScorecardUser user in users)
                {
                    foreach (ScorecardComment scorecardComment in scorecardComments)
                    {
                        if (scorecardComment.UserType == user.UserType && scorecardComment.CategoryId == categoryId &&
                            scorecardComment.QuestionId == questionId && scorecardComment.Comment.Trim().Length > 0)
                        {
                            allComments += scorecardComment.Comment;
                            break;
                        }
                    }
                }
            }
            return allComments;
        }

        public static string EvaluatorComments(ScorecardScoreHistoryCollection scorecardScores,
            int categoryId, int questionId)
        {
            string allComments = string.Empty;
            SettingCollection settings = GetSettings("EvaluationUserType.xml");
            if (scorecardScores != null)
            {
                foreach (ScorecardScoreHistory scorecardScore in scorecardScores)
                {
                    if (scorecardScore.CategoryId == categoryId && scorecardScore.QuestionId == questionId)
                    {
                        Setting setting = settings.Find(scorecardScore.UserType);
                        if (setting != null)
                            allComments += setting.Name;
                        else
                            allComments += scorecardScore.UserType;
                        //if (categoryId == 0 || questionId == 0)
                        //    allComments += " - " + scorecardScore.Score.ToString("f2") + " - ";
                        //else
                        //    allComments += " - " + scorecardScore.Score.ToString("f0") + " - ";
                        allComments += " - ";
                        allComments += scorecardScore.Comment;
                        allComments += "<br />";

                        ScorecardAttachmentCollection attachments = ScorecardAttachmentUtility.FindByCriteria(
                            ConstantUtility.SCORECARD_DATASOURCE_NAME,
                            ScorecardAttachmentManager.FIND_SCORECARDATTACHMENT,
                            new object[] { scorecardScore.ScorecardId, "ScorecardScore" + scorecardScore.Version.ToString(), scorecardScore.ScorecardScoreId });
                        if (attachments != null && attachments.Count > 0)
                        {
                            allComments += "<a href=\"GetScorecardAttachment.aspx?Id=" + attachments[0].Id.ToString() +
                                "\">" + attachments[0].FileName + "</a>";
                            allComments += "<br />";
                        }
                    }
                }
            }
            return allComments;
        }

        public static string EvaluatorComments(ScorecardScoreCollection scorecardScores,
            int categoryId, int questionId)
        {
            string allComments = string.Empty;
            SettingCollection settings = GetSettings("EvaluationUserType.xml");
            if (scorecardScores != null)
            {
                foreach (ScorecardScore scorecardScore in scorecardScores)
                {
                    if (scorecardScore.CategoryId == categoryId && scorecardScore.QuestionId == questionId)
                    {
                        Setting setting = settings.Find(scorecardScore.UserType);
                        if (setting != null)
                            allComments += setting.Name;
                        else
                            allComments += scorecardScore.UserType;
                        //if (categoryId == 0 || questionId == 0)
                        //    allComments += " - " + scorecardScore.Score.ToString("f2") + " - ";
                        //else
                        //    allComments += " - " + scorecardScore.Score.ToString("f0") + " - ";
                        allComments += " - ";
                        allComments += scorecardScore.Comment;
                        allComments += "<br />";

                        ScorecardAttachmentCollection attachments = ScorecardAttachmentUtility.FindByCriteria(
                            ConstantUtility.SCORECARD_DATASOURCE_NAME,
                            ScorecardAttachmentManager.FIND_SCORECARDATTACHMENT,
                            new object[] { scorecardScore.ScorecardId, "ScorecardScore", scorecardScore.Id });
                        if (attachments != null && attachments.Count > 0)
                        {
                            allComments += "<a href=\"GetScorecardAttachment.aspx?Id=" + attachments[0].Id.ToString() +
                                "\">" + attachments[0].FileName + "</a>";
                            allComments += "<br />";
                        }
                    }
                }
            }
            return allComments;
        }

        public static string SupervisorComments(ScorecardCommentCollection scorecardComments, 
            int categoryId, int questionId)
        {
            string allComments = string.Empty;
            SettingCollection settings = GetSettings("EvaluationUserType.xml");
            if (scorecardComments != null)
            {
                foreach (ScorecardComment scorecardComment in scorecardComments)
                {
                    if (scorecardComment.CategoryId == categoryId && scorecardComment.QuestionId == questionId)
                    {
                        Setting setting = settings.Find(scorecardComment.UserType);
                        if (setting != null)
                            allComments += setting.Name;
                        else
                            allComments += scorecardComment.UserType;
                        allComments += " - ";
                        allComments += scorecardComment.Comment;
                        allComments += "<br />";

                        ScorecardAttachmentCollection attachments = ScorecardAttachmentUtility.FindByCriteria(
                            ConstantUtility.SCORECARD_DATASOURCE_NAME,
                            ScorecardAttachmentManager.FIND_SCORECARDATTACHMENT,
                            new object[] { scorecardComment.ScorecardId, "ScorecardComment", scorecardComment.Id });
                        if (attachments != null && attachments.Count > 0)
                        {
                            allComments += "<a href=\"GetScorecardAttachment.aspx?Id=" + attachments[0].Id.ToString() +
                                "\">" + attachments[0].FileName + "</a>";
                            allComments += "<br />";
                        }
                    }
                }
            }
            return allComments;
        }

        public static string ReviewComments(ScorecardScore scorecardScore)
        {
            string allComments = string.Empty;
            SettingCollection settings = GetSettings("EvaluationUserType.xml");
            Setting setting = settings.Find(scorecardScore.UserType);
            if (setting != null)
                allComments += setting.Name;
            else
                allComments += scorecardScore.UserType;
            allComments += " - ";
            allComments += scorecardScore.Comment;
            allComments += "<br />";

            ScorecardAttachmentCollection attachments = ScorecardAttachmentUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardAttachmentManager.FIND_SCORECARDATTACHMENT,
                new object[] { scorecardScore.ScorecardId, "ScorecardScore", scorecardScore.Id });
            if (attachments != null && attachments.Count > 0)
            {
                allComments += "<a href=\"GetScorecardAttachment.aspx?Id=" + attachments[0].Id.ToString() +
                    "\">" + attachments[0].FileName + "</a>";
                allComments += "<br />";
            }

            return allComments;
        }

        public static string ReviewComments(ScorecardComment scorecardComment)
        {
            string allComments = string.Empty;
            SettingCollection settings = GetSettings("EvaluationUserType.xml");
            Setting setting = settings.Find(scorecardComment.UserType);
            if (setting != null)
                allComments += setting.Name;
            else
                allComments += scorecardComment.UserType;
            allComments += " - ";
            allComments += scorecardComment.Comment;
            allComments += "<br />";

            ScorecardAttachmentCollection attachments = ScorecardAttachmentUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardAttachmentManager.FIND_SCORECARDATTACHMENT,
                new object[] { scorecardComment.ScorecardId, "ScorecardComment", scorecardComment.Id });
            if (attachments != null && attachments.Count > 0)
            {
                allComments += "<a href=\"GetScorecardAttachment.aspx?Id=" + attachments[0].Id.ToString() +
                    "\">" + attachments[0].FileName + "</a>";
                allComments += "<br />";
            }

            return allComments;
        }

        public static string ExternalComments(ScorecardInviteeCollection invitees,
            ScorecardUserCollection users, ScorecardScoreCollection scorecardScores,
            ScorecardCommentCollection scorecardComments, int categoryId, int questionId)
        {
            string allComments = string.Empty;
            if (invitees != null && scorecardScores != null)
            {
                foreach (ScorecardInvitee invitee in invitees)
                {
                    foreach (ScorecardScore scorecardScore in scorecardScores)
                    {
                        if ((scorecardScore.UserId == invitee.UserId || scorecardScore.UserId == invitee.SupervisorId)
                            && scorecardScore.CategoryId == categoryId && scorecardScore.QuestionId == questionId)
                        {
                            if (scorecardScore.Type == "External" && scorecardScore.Comment.Trim().Length > 0)
                            {
                                allComments += invitee.UserType;
                                allComments += "<br />";
                                allComments += "Comments: " + scorecardScore.Comment;
                                allComments += "<br />";
                            
                                ScorecardAttachmentCollection attachments = ScorecardAttachmentUtility.FindByCriteria(
                                    ConstantUtility.SCORECARD_DATASOURCE_NAME,
                                    ScorecardAttachmentManager.FIND_SCORECARDATTACHMENT,
                                    new object[] { scorecardScore.ScorecardId, "ScorecardScore", scorecardScore.Id });
                                if (attachments != null && attachments.Count > 0)
                                {
                                    if (attachments[0].Type == "External")
                                    {
                                        allComments += "<a href=\"GetScorecardAttachment.aspx?Id=" + attachments[0].Id.ToString() +
                                            "\">" + attachments[0].FileName + "</a>";
                                        allComments += "<br />";
                                    }
                                }
                            }
                            break;
                        }
                    }

                    if (scorecardComments != null)
                    {
                        foreach (ScorecardComment scorecardComment in scorecardComments)
                        {
                            if (scorecardComment.Status == 2) continue;

                            if (scorecardComment.UserId == invitee.SupervisorId && scorecardComment.CategoryId == categoryId &&
                                scorecardComment.QuestionId == questionId)
                            {
                                if (scorecardComment.Type == "External" && scorecardComment.Comment.Trim().Length > 0)
                                {
                                    allComments += scorecardComment.UserType;
                                    allComments += "<br />";
                                    allComments += "Comments: " + scorecardComment.Comment;
                                    allComments += "<br />";

                                    ScorecardAttachmentCollection attachments = ScorecardAttachmentUtility.FindByCriteria(
                                        ConstantUtility.SCORECARD_DATASOURCE_NAME,
                                        ScorecardAttachmentManager.FIND_SCORECARDATTACHMENT,
                                        new object[] { scorecardComment.ScorecardId, "ScorecardComment", scorecardComment.Id });
                                    if (attachments != null && attachments.Count > 0)
                                    {
                                        if (attachments[0].Type == "External")
                                        {
                                            allComments += "<a href=\"GetScorecardAttachment.aspx?Id=" + attachments[0].Id.ToString() +
                                                "\">" + attachments[0].FileName + "</a>";
                                            allComments += "<br />";
                                        }
                                    }
                                }
                                break;
                            }
                        }
                    }
                }
            }
           
            if (users != null && scorecardComments != null)
            {
                foreach (ScorecardUser user in users)
                {
                    foreach (ScorecardComment scorecardComment in scorecardComments)
                    {
                        if (scorecardComment.Status == 2) continue;

                        if (scorecardComment.UserType == user.UserType && scorecardComment.CategoryId == categoryId &&
                            scorecardComment.QuestionId == questionId)
                        {
                            if (scorecardComment.Type == "External" && scorecardComment.Comment.Trim().Length > 0)
                            {
                                allComments += user.UserType;
                                allComments += "<br />";
                                allComments += "Comments: " + scorecardComment.Comment;
                                allComments += "<br />";

                                ScorecardAttachmentCollection attachments = ScorecardAttachmentUtility.FindByCriteria(
                                    ConstantUtility.SCORECARD_DATASOURCE_NAME,
                                    ScorecardAttachmentManager.FIND_SCORECARDATTACHMENT,
                                    new object[] { scorecardComment.ScorecardId, "ScorecardComment", scorecardComment.Id });
                                if (attachments != null && attachments.Count > 0)
                                {
                                    if (attachments[0].Type == "External")
                                    {
                                        allComments += "<a href=\"GetScorecardAttachment.aspx?Id=" + attachments[0].Id.ToString() +
                                            "\">" + attachments[0].FileName + "</a>";
                                        allComments += "<br />";
                                    }
                                }
                            }
                            break;
                        }
                    }
                }
            }
            return allComments;
        }

        public static string ExternalComments(ScorecardCommentCollection scorecardComments, int categoryId, int questionId)
        {
            string allComments = string.Empty;

            if (scorecardComments != null)
            {
                foreach (ScorecardComment scorecardComment in scorecardComments)
                {
                    if (scorecardComment.Status == 2) continue;

                    if (scorecardComment.CategoryId == categoryId && scorecardComment.QuestionId == questionId)
                    {
                        if (scorecardComment.Status == 1 && scorecardComment.Type == "External" && scorecardComment.Comment.Trim().Length > 0)
                        {
                            allComments += scorecardComment.Comment;
                            allComments += "<br />";

                            ScorecardAttachmentCollection attachments = ScorecardAttachmentUtility.FindByCriteria(
                                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                                ScorecardAttachmentManager.FIND_SCORECARDATTACHMENT,
                                new object[] { scorecardComment.ScorecardId, "ScorecardComment", scorecardComment.Id });
                            if (attachments != null && attachments.Count > 0)
                            {
                                allComments += "<a href=\"GetScorecardAttachment.aspx?Id=" + attachments[0].Id.ToString() +
                                    "\">" + attachments[0].FileName + "</a>";
                                allComments += "<br />";
                            }
                        }
                        break;
                    }
                }
            }
            return allComments;
        }

        public static string GetProjectNo(ScorecardProject project)
        {
            if (project.Type == "Capacity")
                return "LLW-" + project.ProjectNo;
            else if (project.Type == "CIP")
                return "DGN-" + project.ProjectNo;
            else if (project.Type.Contains("Mentor"))
                return "PKG-" + project.ProjectNo;
            else
                return project.ProjectNo;
        }
    }
}
