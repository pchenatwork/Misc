using System;
using SCA.VAS.Common.Utilities;
using System.Web.Security;
using SCA.VAS.Common.Sessions;

namespace SCA.VAS.Workflow
{
	/// <summary>
	/// Summary description for ExtPage.
	/// </summary>
    public class ExtPage : System.Web.UI.Page
    {
        public ExtPage()
        {
        }

        public static int GetUserId()
        {
            ExtPage page = new ExtPage();

            if (page.Context != null)
            {
                //window auth
                var userinfo = SessionManager.Get<UserSession>(SessionVars.UserInfo);
                return userinfo?.UserId ?? 0;
                //string name = page.Context.User.Identity.Name;
                //string[] names = name.Split('|');
                //if (names.Length > 0)
                //    return ConvertUtility.ConvertInt(names[0]);
                //else
            }

            return 0;
        }

        public static string GetUserName()
        {
            ExtPage page = new ExtPage();

            if (Membership.ApplicationName.ToLower().IndexOf("internal") >= 0 && page.Context != null)
            {
                string name = page.Context.User.Identity.Name;
                string[] names = name.Split('\\');
                if (names.Length == 2)
                    return names[1];
                else
                    return string.Empty;
            }
            else
                return string.Empty;
        }

        public static string GetUserType()
        {
            if (Membership.ApplicationName.ToLower().IndexOf("internal") >= 0)
            {
                return "User";
            }
            else
            {
                return "Supplier";
            }
        }
    }
}
