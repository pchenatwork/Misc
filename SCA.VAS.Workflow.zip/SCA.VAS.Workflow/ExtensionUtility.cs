﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.BusinessLogic.Rfd.Utilities;

namespace SCA.VAS.Workflow
{
    public static class ExtensionUtility
    {
        public static string GetInvoiceNumber(this ProjectTransaction transaction) { 
            return transaction.Id.ToString().PadLeft(8, '0');
        }
        public static string Boro(this ProjectItem item)
        {
            string boro = "";
            switch (item.Boro.Trim()) {
                case "K":
                    boro = "Brooklyn";
                    break;
                case "Q":
                    boro = "Queens";
                    break;
                case "M":
                    boro = "Manhattan";
                    break;
                case "X":
                    boro = "Bronx";
                    break;
                case "S":
                    boro = "Staten Island";
                    break;
                default:
                    boro = "";
                    break;
            }
            return boro;
        }

        public static T ToEnum<T>(this string str, T defaultValue = default(T)) where T : struct
        {
            T res = defaultValue;
            try
            {
                res = (T)Enum.Parse(typeof(T), str);
            }
            catch
            {
                res = defaultValue;
            }


            return res;
        }
    }
}
