#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ProjectRoutingBDDStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ProjectRoutingBDDStatusConverter))]
    public class ProjectRoutingBDDStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        // Routing to BDD Workflow 
        public static readonly ProjectRoutingBDDStatusType NewRoutingtoBDD = new ProjectRoutingBDDStatusType(0, "NewRoutingtoBDD", "New Routing to BDD");
        public static readonly ProjectRoutingBDDStatusType PendingBDDReview = new ProjectRoutingBDDStatusType(1, "PendingBDDReview", "Pending BDD Review");
        public static readonly ProjectRoutingBDDStatusType BDDApproval = new ProjectRoutingBDDStatusType(2, "BDDApproval", "BDD Approval");
        public static readonly ProjectRoutingBDDStatusType BDDReviewCompleted = new ProjectRoutingBDDStatusType(3, "BDDReviewCompleted", "BDD Review Completed");
        public static readonly ProjectRoutingBDDStatusType BDDOnHold = new ProjectRoutingBDDStatusType(4, "BDDOnHold", "BDD On Hold");
        #endregion

        #region Constructors
        public ProjectRoutingBDDStatusType()
        {
        }

        private ProjectRoutingBDDStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectRoutingBDDStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ProjectRoutingBDDStatus.  
        /// </summary>
        public static ProjectRoutingBDDStatusType Default
        {
            get
            {
                return (ProjectRoutingBDDStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectRoutingBDDStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }

        public static List<ProjectRoutingBDDStatusType> GetList()
        {
            return _list.Cast<ProjectRoutingBDDStatusType>().OrderBy(e => e.Id).ToList();
        }

        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((ProjectRoutingBDDStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectRoutingBDDStatus object.
        /// It allows a string to be assigned to a ProjectRoutingBDDStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ProjectRoutingBDDStatusType(int id)
        {
            return (ProjectRoutingBDDStatusType)EnumerationBase.FindById(id, ProjectRoutingBDDStatusType._list);
        }
        public static implicit operator ProjectRoutingBDDStatusType(string name)
        {
            for (int i = 0; i < ProjectRoutingBDDStatusType._list.Count; i++)
            {
                if (((ProjectRoutingBDDStatusType)ProjectRoutingBDDStatusType._list[i]).Description == name)
                    return (ProjectRoutingBDDStatusType)ProjectRoutingBDDStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectRoutingBDDStatus objects.
    /// It's very useful when binding ProjectRoutingBDDStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ProjectRoutingBDDStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ProjectRoutingBDDStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectRoutingBDDStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ProjectRoutingBDDStatusType._list.Count; i++)
            {
                list.Add(((ProjectRoutingBDDStatusType)ProjectRoutingBDDStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
