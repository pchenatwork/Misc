﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Net.Mail;
using System.Configuration;

using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;
using System.Collections;
using SCA.VAS.Common.ValueObjects;


namespace SCA.VAS.Workflow
{
    #region ConstantUtility
    public partial class ConstantUtility
    {
        public const string WORKFLOW_SUP_MONITORING = "SUP Supplier Monitoring Workflow";
    }
    #endregion ConstantUtility

    public partial class CommonUtility
    {
        #region Pubulic Method
        public static string GetPlanSubcontractorStatusName(string workflowType, int statusint)
        {
            EnumerationBase status = GetPlanSubcontractorStatus(workflowType, statusint);
            if (status != null) return status.Description;
            return string.Empty;
        }

        public static int GetPlanSubcontractorStatusId(string workflowType, string statusstr)
        {
            EnumerationBase status = GetPlanSubcontractorStatus(workflowType, statusstr);
            if (status != null) return status.Id;
            return 0;
        }

        private static EnumerationBase GetPlanSubcontractorStatus(string workflowType, object status)
        {
            switch (workflowType)
            {
                case ConstantUtility.WORKFLOW_SUP:
                    PlanSubcontractorStatusType planSubcontractorStatus = status.ToString();
                    if (status is int) planSubcontractorStatus = (int)status;
                    return planSubcontractorStatus;
            }
            return null;
        }
        #endregion Pubulic Method

        #region Email Method

        public static void SendEmailtoOIG(int userid, int supplierId)
        {
            Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierId);
            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, userid);
            EmailMessage emailmessage = EmailMessageUtility.GetByName(ConstantUtility.COMMON_DATASOURCE_NAME, "KEY_PERSON_OIG_REVIEW");


            EmailMessage newMessage = EmailReplaceRelatedUsers(emailmessage, supplier);

            //EmailMessage emailmessage = EmailMessageUtility.GetByName(ConstantUtility.COMMON_DATASOURCE_NAME, "KEY_PERSON_OIG_REVIEW");
            //CommonUtility.SendEmail(emailmessage, user, new object[] { supplier, user }, "", true, "Supplier", supplier.Id);

            UserCollection users = UserUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                UserManager.FIND_USER_BY_TYPE,
                new object[] 
				{ 
					0,
					0,
					"Name",
					"ASC",
					"OIG"
				});


            if (users != null)
            {
                for (int i = 0; i < users.Count; i++)
                {

                    CommonUtility.SendEmail(newMessage, user, new object[] { supplier, users[i] }, "", true, "Supplier", supplier.Id);
                    //SendEmail(emailmessage, users[i],
                    //    new object[] { planSubcontractor, users[i], supplier, vendor },
                    //    comments,
                    //    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                    //    "PlanSubcontractor", planSubcontractor.Id);
                }
            }



        }


        public static void SendEmailtoCQU(int userid, int supplierId, List<SupplierCategory> catList)
        {
            Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierId);
            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, userid);
            EmailMessage emailmessage = EmailMessageUtility.GetByName(ConstantUtility.COMMON_DATASOURCE_NAME, "CQU_NEWTRADECODE_ALERT");

            EmailMessage newMessage = EmailReplaceRelatedUsers(emailmessage, supplier, catList);




            UserCollection users = UserUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                UserManager.FIND_USER_BY_TYPE,
                new object[] 
				{ 
					0,
					0,
					"Name",
					"ASC",
					"OIG"
				});


            if (users != null)
            {
                for (int i = 0; i < users.Count; i++)
                {

                    CommonUtility.SendEmail(newMessage, user, new object[] { supplier, users[i] }, "", true, "Supplier", supplier.Id);

                }
            }



        }






        //TFS# 689 Mentor limited list vendor add notification email 
        public static void EmailNotificationtoMLL(int userid, List<string> supplierCollection, Guid projectId, string comment)
        {

            RfdProject project = RfdProjectUtility.GetById(ConstantUtility.RFD_DATASOURCE_NAME, projectId);

            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, userid);
            EmailMessage emailmessage = EmailMessageUtility.GetByName(ConstantUtility.COMMON_DATASOURCE_NAME, "Mentor_limited_list_vendor_add_notification");



            EmailMessage newMessage = EmailReplaceRelatedUsers(emailmessage, project, supplierCollection, comment, user);
            UserCollection users = UserUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                UserManager.FIND_USER_BY_TYPE,
                new object[] 
				{ 
					0,
					0,
					"Name",
					"ASC",
					"BDD"
				});


            if (users != null)
            {
                for (int i = 0; i < users.Count; i++)
                {
                    CommonUtility.SendEmail(newMessage, user, new object[] { project, users[i] }, "", true, "Project", project.Id);

                }
            }


        }

        public static void PlanSubcontractorSendEmail(PlanSubcontractor planSubcontractor, WorkflowHistory workflowHistory,
            string emailMessageName, string comments, string prefixDbName)
        {
            EmailMessage emailmessage = EmailMessageUtility.GetByName(
                ConstantUtility.COMMON_DATASOURCE_NAME, emailMessageName);
            if (emailmessage == null) return;

            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "FederalId", planSubcontractor.TaxId);
            User user = UserUtility.Get(prefixDbName + ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

            Supplier supplier = null;
            if (vendor != null)
            {
                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendor.CurrentSupplierId);
            }

            if (supplier == null) return;

            EmailMessage newMessage = EmailReplaceRelatedUsers(emailmessage, planSubcontractor);

            switch (emailmessage.Objects)
            {
                case "Authorized Users":
                    {
                        string nodes = XmlUtility.ToXml(workflowHistory.NextLinks);
                        UserCollection users = UserUtility.FindByCriteria(
                            ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_WORKFLOWNODES,
                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                            {
                                SendEmail(emailmessage, users[i],
                                    new object[] { planSubcontractor, users[i], supplier, vendor },
                                    comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "PlanSubcontractor", planSubcontractor.Id);
                            }
                        }
                    }
                    break;

                case "Users":
                    {
                        SendEmail(emailmessage, user,
                            new object[] { planSubcontractor, user, supplier, vendor }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "PlanSubcontractor", planSubcontractor.Id);
                    }
                    break;

                case "Suppliers":
                    {
                        SendEmail(emailmessage, supplier,
                            new object[] { planSubcontractor, user, supplier, vendor }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "PlanSubcontractor", planSubcontractor.Id);
                    }
                    break;

                default:
                    {
                        SendEmail(emailmessage, null,
                            new object[] { planSubcontractor, user, supplier, vendor }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "PlanSubcontractor", planSubcontractor.Id);
                    }
                    break;
            }
        }

        public static EmailMessage EmailReplaceRelatedUsers(EmailMessage emailmessage, PlanSubcontractor planSubcontractor)
        {

            if (emailmessage == null) return null;

            Hashtable RelatedUsers = new Hashtable();

            PlanSubcontractorPropertyCollection planSubcontractorProperties = PlanSubcontractorPropertyUtility.FindByCriteria(
                ConstantUtility.RFD_DATASOURCE_NAME,
                PlanSubcontractorPropertyManager.FIND_BY_PLANSUBCONTRACTOR,
                new object[] { planSubcontractor.Id });


            //replace plan info
            Plan plan = PlanUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, planSubcontractor.PlanId);

            EmailMessage newemailmessage = emailmessage;
            if (plan != null)
            {
                newemailmessage = EmailReplaceRelatedUsers(emailmessage, plan);
            }


            //supplier/subcontractor info
            RelatedUsers.Add("$PLANSUBFEDERALID$", planSubcontractor.FederalId);
            RelatedUsers.Add("$PLANSUBCOMPANYNAME$", planSubcontractor.Company);
            RelatedUsers.Add("$PLANSUBADDRESS$", planSubcontractor.AddressLine1.Replace("|", " ") + "," + planSubcontractor.AddressLine2);
            RelatedUsers.Add("$PLANSUBCITY$", planSubcontractor.City);
            RelatedUsers.Add("$PLANSUBSTATE$", planSubcontractor.State);

            //plan sub missing info
            PlanSubcontractorCommentCollection planSubcontractorComments = PlanSubcontractorCommentUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME,
              PlanSubcontractorCommentManager.FIND_PLANSUBCONTRACTORCOMMENT, new object[] { 0, 0, "", "", planSubcontractor.Id, "External" });
            string commentString = "";
            if (planSubcontractorComments != null)
            {
                foreach (PlanComment comment in planSubcontractorComments)
                {
                    if (comment.Submitted != "Y")
                    {
                        if (commentString == "")
                            commentString = "<table border='1' cellpadding='3'>";
                        commentString += "<tr><td><b>";
                        string section = "";
                        switch (comment.FileLink)
                        {
                            case "0":
                                section = "Subcontractor Information";
                                break;
                        }
                        commentString += section + "</b></td><td>" + comment.Comments + "</td></tr>";
                    }
                }
            }
            if (commentString != "")
                commentString += "</table>";
            RelatedUsers.Add("$PLANSUBDYNAMICMISSINGINFO$", commentString);

            //plan sub deny reason
            string denyreason = string.Empty;
            denyreason = GetPlanSubcontractorProperty("property11", planSubcontractorProperties).PropertyText;

            if (denyreason == "Other:")
                denyreason += " " + GetPlanSubcontractorProperty("property12", planSubcontractorProperties).PropertyText;

            RelatedUsers.Add("$PLANSUBDENYREASON$", denyreason);


            //replace
            newemailmessage.FromEmail = ReplaceRelatedUsers(newemailmessage.FromEmail, RelatedUsers);
            newemailmessage.ToEmail = ReplaceRelatedUsers(newemailmessage.ToEmail, RelatedUsers);
            newemailmessage.ToName = ReplaceRelatedUsers(newemailmessage.ToName, RelatedUsers);
            newemailmessage.CcEmail = ReplaceRelatedUsers(newemailmessage.CcEmail, RelatedUsers);
            newemailmessage.BccEmail = ReplaceRelatedUsers(newemailmessage.BccEmail, RelatedUsers);
            newemailmessage.Subject = ReplaceRelatedUsers(newemailmessage.Subject, RelatedUsers);
            newemailmessage.Body = ReplaceRelatedUsers(newemailmessage.Body, RelatedUsers);

            return newemailmessage;
        }
        #endregion Email Method


        public static void AddPlanSubcontractorUser(string userName, string roleName, int userId)
        {
            if (userName.Trim().Length > 0)
            {
                CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, userName);
                if (cesUser != null)
                    AddUser(cesUser, roleName, "", userId);
            }
        }


        #region PlanSubcontractorProperty functions
        public static PlanSubcontractorProperty CreatePlanSubcontractorProperty(Control control, string value, Type type, Control parent, string changeUser)
        {
            PlanSubcontractorProperty planSubcontractorProperty = CreatePlanSubcontractorProperty(control, value, type, parent);
            planSubcontractorProperty.ChangeUser = changeUser;
            return planSubcontractorProperty;
        }

        public static PlanSubcontractorProperty CreatePlanSubcontractorProperty(Control control, string value, Type type, Control parent)
        {
            PlanSubcontractorProperty planSubcontractorProperty = PlanSubcontractorPropertyUtility.CreateObject();
            planSubcontractorProperty.PropertyId = ConvertUtility.ConvertInt(control.ID.Substring(8));
            if (parent != null) planSubcontractorProperty.ParentId = planSubcontractorProperty.PropertyId;
            switch (type.Name)
            {
                case "Int32":
                    planSubcontractorProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    planSubcontractorProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    planSubcontractorProperty.PropertyText = value;
                    break;
            }
            return planSubcontractorProperty;
        }


        public static PlanSubcontractorProperty CreatePlanSubcontractorProperty(Control control, string attachmentName, byte[] attachment)
        {
            PlanSubcontractorProperty planSubcontractorProperty = PlanSubcontractorPropertyUtility.CreateObject();
            planSubcontractorProperty.PropertyId = ConvertUtility.ConvertInt(control.ID.Substring(8));
            planSubcontractorProperty.AttachmentName = attachmentName;
            planSubcontractorProperty.Attachment = attachment;
            return planSubcontractorProperty;
        }

        public static PlanSubcontractorProperty CreatePlanSubcontractorProperty(int propertyId, string value)
        {
            PlanSubcontractorProperty planSubcontractorProperty = CreatePlanSubcontractorProperty(propertyId, value, typeof(String));
            return planSubcontractorProperty;
        }

        public static PlanSubcontractorProperty CreatePlanSubcontractorProperty(int propertyId, string value, Type type)
        {
            PlanSubcontractorProperty planSubcontractorProperty = PlanSubcontractorPropertyUtility.CreateObject();
            planSubcontractorProperty.PropertyId = propertyId;
            switch (type.Name)
            {
                case "Int32":
                    planSubcontractorProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    planSubcontractorProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    planSubcontractorProperty.PropertyText = value;
                    break;
            }
            return planSubcontractorProperty;
        }

        public static PlanSubcontractorPropertyCollection AddPlanSubcontractorProperty(PlanSubcontractor planSubcontractor, PlanSubcontractorProperty planSubcontractorProperty)
        {
            PlanSubcontractorPropertyCollection planSubcontractorProperties = new PlanSubcontractorPropertyCollection();
            planSubcontractorProperties.Add(planSubcontractorProperty);
            return AddPlanSubcontractorProperty(planSubcontractor, planSubcontractorProperties);
        }

        public static PlanSubcontractorPropertyCollection AddPlanSubcontractorProperty(PlanSubcontractor planSubcontractor, PlanSubcontractorPropertyCollection planSubcontractorProperties)
        {
            PlanSubcontractorPropertyCollection currentProperties = PlanSubcontractorPropertyUtility.FindByCriteria(
                ConstantUtility.RFD_DATASOURCE_NAME,
                PlanSubcontractorPropertyManager.FIND_BY_PLANSUBCONTRACTOR,
                new object[] { planSubcontractor.Id });
            if (currentProperties == null)
                currentProperties = new PlanSubcontractorPropertyCollection();

            foreach (PlanSubcontractorProperty sp in planSubcontractorProperties)
            {
                if (sp.ParentId == 0)
                {
                    bool isChange = false;
                    foreach (PlanSubcontractorProperty sp1 in currentProperties)
                    {
                        if (sp1.PropertyId == sp.PropertyId)
                        {
                            sp1.PropertyValue = sp.PropertyValue;
                            sp1.PropertyText = sp.PropertyText;
                            sp1.PropertyDate = sp.PropertyDate;
                            isChange = true;
                        }
                    }
                    if (!isChange)
                        currentProperties.Add(sp);
                }
                else
                {
                    //Multi values
                    currentProperties.Add(sp);
                }
            }
            return currentProperties;
        }

        public static PlanSubcontractorProperty GetPlanSubcontractorProperty(Control control, PlanSubcontractorPropertyCollection planSubcontractorProperties)
        {
            if (planSubcontractorProperties == null) return PlanSubcontractorPropertyUtility.CreateObject();
            foreach (PlanSubcontractorProperty sp in planSubcontractorProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(control.ID.Substring(8)))
                    return sp;
            }
            return PlanSubcontractorPropertyUtility.CreateObject();
        }
        public static PlanSubcontractorProperty GetPlanSubcontractorProperty(string propertyId, PlanSubcontractorPropertyCollection planSubcontractorProperties)
        {
            if (planSubcontractorProperties == null) return PlanSubcontractorPropertyUtility.CreateObject();
            foreach (PlanSubcontractorProperty sp in planSubcontractorProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(propertyId.Substring(8)))
                    return sp;
            }
            return PlanSubcontractorPropertyUtility.CreateObject();
        }
        public static PlanSubcontractorPropertyCollection GetPlanSubcontractorProperties(Control control, PlanSubcontractorPropertyCollection planSubcontractorProperties)
        {
            PlanSubcontractorPropertyCollection localPlanSubcontractorProperties = new PlanSubcontractorPropertyCollection();
            if (planSubcontractorProperties == null) return localPlanSubcontractorProperties;
            foreach (PlanSubcontractorProperty sp in planSubcontractorProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(control.ID.Substring(8)))
                    localPlanSubcontractorProperties.Add(sp);
            }
            return localPlanSubcontractorProperties;
        }
        public static PlanSubcontractorPropertyCollection GetPlanSubcontractorProperties(string controlId, PlanSubcontractorPropertyCollection planSubcontractorProperties)
        {
            PlanSubcontractorPropertyCollection localPlanSubcontractorProperties = new PlanSubcontractorPropertyCollection();
            if (planSubcontractorProperties == null) return localPlanSubcontractorProperties;
            foreach (PlanSubcontractorProperty sp in planSubcontractorProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(controlId.Substring(8)))
                    localPlanSubcontractorProperties.Add(sp);
            }
            return localPlanSubcontractorProperties;
        }

        #endregion PlanSubcontractorProperty functions


        #region Package Functions
        #endregion
    }
}
