using System;
using System.Reflection;
using log4net;

using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Scorecard.Utilities;
using SCA.VAS.BusinessLogic.Scorecard;
using SCA.VAS.ValueObjects.Scorecard;

using SCA.VAS.ValueObjects.Workflow;

namespace SCA.VAS.Workflow
{
    public class WorkflowSchedule
    {
        #region Private Member
        private static ScheduleEventCollection scheduleEvents = null;
        private static DateTime today = DateTime.Today;
        private static ILog _logger = LoggingUtility.GetLogger(typeof(WorkflowSchedule).FullName);
        #endregion Private Member

        #region Public Method
        public static void SetInitialValue()
        {
            if (scheduleEvents != null) scheduleEvents.Clear();
            today = DateTime.Today;
            if (scheduleEvents == null)
                scheduleEvents = new ScheduleEventCollection();
            FindScorecardSchedule();

            _logger.Info("Auto Schedule Started");
        }

        public static void AutoSchedule()
        {
            if (today != DateTime.Today) SetInitialValue();
            if (scheduleEvents == null) return;

            for (int i = 0; i < scheduleEvents.Count; i++)
            {
                if (scheduleEvents[i].EventTime > DateTime.Now) continue;

                try
                {
                    Type type = typeof(WorkflowSchedule);
                    type.InvokeMember(scheduleEvents[i].EventName, BindingFlags.InvokeMethod, null, null,
                        new object[] { scheduleEvents[i].ReferenceId });
                }
                catch
                {
                    _logger.Info("Auto Schedule Failed: " + scheduleEvents[i].EventName + " - " + scheduleEvents[i].EventTime.ToString()
                        + " - Ref ID: " + scheduleEvents[i].ReferenceId.ToString());
                }

                _logger.Info("Auto Schedule: " + scheduleEvents[i].EventName + " - " + scheduleEvents[i].EventTime.ToString()
                    + " - Ref ID: " + scheduleEvents[i].ReferenceId.ToString());
                scheduleEvents.Remove(scheduleEvents[i--]);
            }
        }

        public static void AddScheduleEvent(string eventName, DateTime eventTime, int referenceId, int actionId)
        {
            ScheduleEvent scheduleEvent = new ScheduleEvent();
            scheduleEvent.EventName = eventName;
            scheduleEvent.EventTime = eventTime;
            scheduleEvent.ReferenceId = referenceId;
            scheduleEvent.ActionId = actionId;
            if (scheduleEvents == null)
                scheduleEvents = new ScheduleEventCollection();
            scheduleEvents.Add(scheduleEvent);
        }
        #endregion Public Method

        public static ScheduleEventCollection ScheduledEvents
        {
            get
            {
                return scheduleEvents;
            }
        }

        #region Private Method
        private static void FindScorecardSchedule()
        {
            // Release Scorecard
            ScorecardCollection scorecards = ScorecardUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardManager.FIND_SCORECARD_BY_EVENT, 
                new object[] { "ScorecardRelease" });

            if (scorecards != null)
            {
                foreach (Scorecard scorecard in scorecards)
                {
                    ScheduleEvent scheduleEvent = new ScheduleEvent();
                    scheduleEvent.EventName = "ScorecardRelease";
                    scheduleEvent.EventTime = scorecard.ReleaseDate;
                    scheduleEvent.ReferenceId = scorecard.Id;

                    scheduleEvents.Add(scheduleEvent);
                }
                scorecards.Clear();
            }

            // Complete Scorecard
            scorecards = ScorecardUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardManager.FIND_SCORECARD_BY_EVENT,
                new object[] { "ScorecardComplete" });

            if (scorecards != null)
            {
                foreach (Scorecard scorecard in scorecards)
                {
                    ScheduleEvent scheduleEvent = new ScheduleEvent();
                    scheduleEvent.EventName = "ScorecardComplete";
                    scheduleEvent.EventTime = scorecard.CloseDate;
                    scheduleEvent.ReferenceId = scorecard.Id;

                    scheduleEvents.Add(scheduleEvent);
                }
                scorecards.Clear();
            }

            // Evaluation Overdue
            ScorecardInviteeCollection invitees = ScorecardInviteeUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardInviteeManager.FIND_SCORECARDINVITEE_BY_EVENT,
                new object[] { "EvaluatorOverdue" });
            if (invitees != null)
            {
                foreach (ScorecardInvitee invitee in invitees)
                {
                    ScheduleEvent scheduleEvent = new ScheduleEvent();
                    scheduleEvent.EventName = "EvaluatorOverdue";
                    scheduleEvent.EventTime = invitee.DueDate;
                    scheduleEvent.ReferenceId = invitee.Id;

                    scheduleEvents.Add(scheduleEvent);
                }
                invitees.Clear();
            }

            invitees = ScorecardInviteeUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardInviteeManager.FIND_SCORECARDINVITEE_BY_EVENT,
                new object[] { "SupervisorOverdue" });
            if (invitees != null)
            {
                foreach (ScorecardInvitee invitee in invitees)
                {
                    ScheduleEvent scheduleEvent = new ScheduleEvent();
                    scheduleEvent.EventName = "SupervisorOverdue";
                    scheduleEvent.EventTime = invitee.DueDate;
                    scheduleEvent.ReferenceId = invitee.Id;

                    scheduleEvents.Add(scheduleEvent);
                }
                invitees.Clear();
            }

            invitees = ScorecardInviteeUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardInviteeManager.FIND_SCORECARDINVITEE_BY_EVENT,
                new object[] { "EvaluationExpire" });
            if (invitees != null)
            {
                foreach (ScorecardInvitee invitee in invitees)
                {
                    ScheduleEvent scheduleEvent = new ScheduleEvent();
                    scheduleEvent.EventName = "EvaluationExpire";
                    scheduleEvent.EventTime = invitee.DueDate;
                    scheduleEvent.ReferenceId = invitee.Id;

                    scheduleEvents.Add(scheduleEvent);
                }
                invitees.Clear();
            }
        }
        #endregion Private Method

        #region Batch Jobs
        public static void ScorecardRelease(int scorecardId)
        {
            Scorecard scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardId);
            if (scorecard.Status == ScorecardStatusType.NewEvaluation.Id && scorecard.ReleaseDate <= DateTime.Now)
            {
                ScorecardWorkflowExec.ScorecardWorkflow(scorecard, ScorecardStatusType.ReleasedEvaluation.Name, "");
            }
        }

        public static void ScorecardComplete(int scorecardId)
        {
            Scorecard scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardId);
            if (scorecard.Status == ScorecardStatusType.EvaluationInProgress.Id && scorecard.CloseDate <= DateTime.Now)
            {
                if (scorecard.Invitees != null)
                {
                    bool bComplete = false;
                    foreach (ScorecardInvitee invitee in scorecard.Invitees)
                    {
                        if (invitee.UserType == ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST &&
                            (invitee.Status == EvaluationStatusType.Complete.Id || invitee.Status == EvaluationStatusType.Approved.Id))
                        {
                            bComplete = true;
                            break;
                        }
                    }
                    if (bComplete)
                    {
                        ScorecardWorkflowExec.ScorecardWorkflow(scorecard, ScorecardStatusType.EvaluationCompleted.Name, "");

                        double avgScore = ScorecardUtility.GetAverageScore(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                            scorecard.Id, 0);
                        ScorecardUtility.UpdateScore(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecard.Id, avgScore);
                    }
                }
            }
        }

        public static void EvaluatorOverdue(int inviteeId)
        {
            ScorecardInvitee invitee = ScorecardInviteeUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, inviteeId);
            Scorecard scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, invitee.ScorecardId);
            if ((invitee.Status == EvaluationStatusType.New.Id || invitee.Status == EvaluationStatusType.Forwarded.Id) && 
                scorecard.EvaluationDate <= DateTime.Now)
            {
                EvaluationWorkflowExec.EvaluationWorkflow(invitee, EvaluationStatusType.Overdue.Name, "");
            }
        }

        public static void SupervisorOverdue(int inviteeId)
        {
            ScorecardInvitee invitee = ScorecardInviteeUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, inviteeId);
            Scorecard scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, invitee.ScorecardId);
            if ((invitee.Status == EvaluationStatusType.New.Id || invitee.Status == EvaluationStatusType.Forwarded.Id ||
                invitee.Status == EvaluationStatusType.Overdue.Id) && scorecard.EvaluationDate.AddDays(7) <= DateTime.Now)
            {
                EvaluationWorkflowExec.EvaluationWorkflow(invitee, EvaluationStatusType.SupervisorOverdue.Name, "");
            }
        }

        public static void EvaluationExpire(int inviteeId)
        {
            ScorecardInvitee invitee = ScorecardInviteeUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, inviteeId);
            Scorecard scorecard = ScorecardUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, invitee.ScorecardId);
            if (scorecard.Type == "Capacity" || scorecard.Type == "CIP")
            {
                if ((invitee.Status == EvaluationStatusType.New.Id || invitee.Status == EvaluationStatusType.Forwarded.Id ||
                    invitee.Status == EvaluationStatusType.Overdue.Id || invitee.Status == EvaluationStatusType.SupervisorOverdue.Id) && 
                    scorecard.CloseDate <= DateTime.Now && invitee.UserType != ConstantUtility.ROLE_CONSTRUCTION_SPECIALIST)
                {
                    EvaluationWorkflowExec.EvaluationWorkflow(invitee, EvaluationStatusType.Expired.Name, "");
                }
            }
            else if (scorecard.Type == "Mentor A")
            {
                if ((invitee.Status == EvaluationStatusType.New.Id || invitee.Status == EvaluationStatusType.Forwarded.Id ||
                    invitee.Status == EvaluationStatusType.Overdue.Id || invitee.Status == EvaluationStatusType.SupervisorOverdue.Id) && 
                    scorecard.CloseDate <= DateTime.Now && invitee.UserType != ConstantUtility.ROLE_SENIOR_PROJECT_OFFICER)
                {
                    EvaluationWorkflowExec.EvaluationWorkflow(invitee, EvaluationStatusType.Expired.Name, "");
                }
            }
        }
        #endregion Batch Jobs 

    }
}
