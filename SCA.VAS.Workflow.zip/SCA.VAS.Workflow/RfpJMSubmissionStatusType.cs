using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of RfpJMSubmissionStatusType:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(RfpJMSubmissionStatusConverter))]
    public class RfpJMSubmissionStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements

        public static readonly RfpJMSubmissionStatusType NewJMSubmission = new RfpJMSubmissionStatusType(1, "NewJMSubmission", "New JM Submission");
        public static readonly RfpJMSubmissionStatusType JMSubmitted = new RfpJMSubmissionStatusType(2, "JMSubmitted", "JM Submitted");
        public static readonly RfpJMSubmissionStatusType JMApproved = new RfpJMSubmissionStatusType(3, "JMApproved", "JM Approved");
        public static readonly RfpJMSubmissionStatusType JMRejected = new RfpJMSubmissionStatusType(4, "JMRejected", "JM Rejected");
        public static readonly RfpJMSubmissionStatusType JMReviewed = new RfpJMSubmissionStatusType(5, "JMReviewed", "JM Reviewed");
        public static readonly RfpJMSubmissionStatusType JMCCUNegotiatorApproved = new RfpJMSubmissionStatusType(6, "JMCCUNegotiatorApproved", "JM CCU Negotiator Approved");
        public static readonly RfpJMSubmissionStatusType JMCCUNegotiatorRejected = new RfpJMSubmissionStatusType(7, "JMCCUNegotiatorRejected", "JM CCU Negotiator Rejected");
        public static readonly RfpJMSubmissionStatusType JMRevised = new RfpJMSubmissionStatusType(8, "JMRevised", "JM Revised");
        public static readonly RfpJMSubmissionStatusType Tier2ApprovalInitiated = new RfpJMSubmissionStatusType(9, "Tier2ApprovalInitiated", "Pending Through Review");
        public static readonly RfpJMSubmissionStatusType Tier2ApprovalCompleted = new RfpJMSubmissionStatusType(10, "Tier2ApprovalCompleted", "Tier2 Approval Process Completed");
        public static readonly RfpJMSubmissionStatusType Tier4ApprovalInitiated = new RfpJMSubmissionStatusType(11, "Tier4ApprovalInitiated", "Tier4 Approval Process Initiated");
        public static readonly RfpJMSubmissionStatusType Tier4ApprovalCompleted = new RfpJMSubmissionStatusType(12, "Tier4ApprovalCompleted", "Tier4 Approval Process Completed");
 
        public static readonly RfpJMSubmissionStatusType PendingPresidentReview = new RfpJMSubmissionStatusType(16, "PendingPresidentReview", "Pending President Review");
        public static readonly RfpJMSubmissionStatusType PresidentApproved = new RfpJMSubmissionStatusType(17, "PresidentApproved", "President Approved");
        public static readonly RfpJMSubmissionStatusType PresidentRejected = new RfpJMSubmissionStatusType(18, "PresidentRejected", "President Rejected");

        public static readonly RfpJMSubmissionStatusType JMCCUManagerApproved = new RfpJMSubmissionStatusType(26, "JMCCUManagerApproved", "JM CCU Manager Approved");
        public static readonly RfpJMSubmissionStatusType JMCCUManagerRejected = new RfpJMSubmissionStatusType(27, "JMCCUManagerRejected", "JM CCU Manager Rejected");

        public static readonly RfpJMSubmissionStatusType JMCCUDirectorApproved = new RfpJMSubmissionStatusType(28, "JMCCUDirectorApproved", "JM CCU Director Approved");
        public static readonly RfpJMSubmissionStatusType JMCCUDirectorRejected = new RfpJMSubmissionStatusType(29, "JMCCUDirectorRejected", "JM CCU Director Rejected");

        public static readonly RfpJMSubmissionStatusType JMCCUDirectorApproved2 = new RfpJMSubmissionStatusType(30, "JMCCUDirectorApproved2", "JM CCU Director Approved2");
        public static readonly RfpJMSubmissionStatusType JMCCUDirectorRejected2 = new RfpJMSubmissionStatusType(31, "JMCCUDirectorRejected2", "JM CCU Director Rejected2");

        public static readonly RfpJMSubmissionStatusType JMVPDeptApproved = new RfpJMSubmissionStatusType(32, "JMVPDeptApproved", "JM Dept. VP Approved");
        public static readonly RfpJMSubmissionStatusType JMVPDeptRejected = new RfpJMSubmissionStatusType(33, "JMVPDeptRejected", "JM Dept. VP Rejected");

        public static readonly RfpJMSubmissionStatusType PendingFinancialReview = new RfpJMSubmissionStatusType(13, "PendingFinancialReview", "Pending Financial Review");
        public static readonly RfpJMSubmissionStatusType FinancialReviewed = new RfpJMSubmissionStatusType(14, "FinancialReviewed", "Financial Reviewed");
        public static readonly RfpJMSubmissionStatusType FinancialRejected = new RfpJMSubmissionStatusType(15, "FinancialRejected", "Financial Rejected");

        public static readonly RfpJMSubmissionStatusType PendingFinancialVPApprove = new RfpJMSubmissionStatusType(34, "PendingFinancialVPApprove", "Pending Financial VP Approve");
        public static readonly RfpJMSubmissionStatusType FinanciaVPApproved = new RfpJMSubmissionStatusType(35, "FinancialVPApproved", "Financial VP Approved");
        public static readonly RfpJMSubmissionStatusType FinancialVPRejected = new RfpJMSubmissionStatusType(36, "FinancialVPRejected", "Financial VP Rejected");

        public static readonly RfpJMSubmissionStatusType Tier2CompletedWithoutThrough = new RfpJMSubmissionStatusType(37, "Tier2CompletedWithoutThrough", "Tier2 Process Completed Without Through");

        public static readonly RfpJMSubmissionStatusType PendingJMReview = new RfpJMSubmissionStatusType(38, "PendingJMReview", "Pending JM Review");

        public static readonly RfpJMSubmissionStatusType PendingCCUNegotiatorJMReview = new RfpJMSubmissionStatusType(39, "PendingCCUNegotiatorJMReview", "Pending CCU Negotiator JM Review");
        public static readonly RfpJMSubmissionStatusType PendingCCUManagerJMReview = new RfpJMSubmissionStatusType(40, "PendingCCUManagerJMReview", "Pending CCU Manager JM Review");

        public static readonly RfpJMSubmissionStatusType PendingCCUDirectorJMReview = new RfpJMSubmissionStatusType(41, "PendingCCUDirectorJMReview", "Pending CCU Director JM Review");
        public static readonly RfpJMSubmissionStatusType PendingCCUDirectorJMReview2 = new RfpJMSubmissionStatusType(42, "PendingCCUDirectorJMReview2", "Pending CCU Director JM 2nd Review");
        public static readonly RfpJMSubmissionStatusType PendingDeptJMReview = new RfpJMSubmissionStatusType(43, "PendingDeptJMReview", "Pending Dept. VP JM Review");

        #endregion

        #region Constructors
        public RfpJMSubmissionStatusType()
        {
        }

        private RfpJMSubmissionStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in PlanSubcontractorStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of PlanSubcontractorStatus.  
        /// </summary>
        public static RfpJMSubmissionStatusType Default
        {
            get
            {
                return (RfpJMSubmissionStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for RfpJMSubmissionStatusType class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((RfpJMSubmissionStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }

        public static bool IsFinal(int status)
        {
            if (status == 4 || status == 11) return true;
            else return false;
        }

        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a PlanSubcontractorStatus object.
        /// It allows a string to be assigned to a PlanSubcontractorStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator RfpJMSubmissionStatusType(int id)
        {
            return (RfpJMSubmissionStatusType)EnumerationBase.FindById(id, RfpJMSubmissionStatusType._list);
        }
        public static implicit operator RfpJMSubmissionStatusType(string name)
        {
            for (int i = 0; i < RfpJMSubmissionStatusType._list.Count; i++)
            {
                if (((RfpJMSubmissionStatusType)RfpJMSubmissionStatusType._list[i]).Description == name)
                    return (RfpJMSubmissionStatusType)RfpJMSubmissionStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and PlanSubcontractorStatus objects.
    /// It's very useful when binding PlanSubcontractorStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class RfpJMSubmissionStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, RfpJMSubmissionStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the PlanSubcontractorStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < RfpJMSubmissionStatusType._list.Count; i++)
            {
                list.Add(((RfpJMSubmissionStatusType)RfpJMSubmissionStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }


    
}
 