﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

namespace SCA.VAS.Workflow
{
    public class VendorContactExternalRoleType
    {
        public int Id{ get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public VendorContactExternalRoleType()
        {
        }
        public static ArrayList GetEnumList()
        {
            ArrayList list = new ArrayList();
            
            LookupCollection lookups = LookupUtility.GetByType(ConstantUtility.COMMON_DATASOURCE_NAME, "VENDORCONTACTEXTERNALROLE");
            foreach (Lookup lookup in lookups)
            {
                VendorContactExternalRoleType vendorContactExternalRoleType = new VendorContactExternalRoleType();
                vendorContactExternalRoleType.Id = ConvertUtility.ConvertInt(lookup.Value);
                vendorContactExternalRoleType.Name = lookup.Description;
                vendorContactExternalRoleType.Description = lookup.Description;
                list.Add(vendorContactExternalRoleType);
            }

            return list;
        }
    }


}
