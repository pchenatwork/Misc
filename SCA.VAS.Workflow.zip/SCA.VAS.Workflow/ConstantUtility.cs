using System;
using System.Collections.Generic;

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// Summary description for ConstantUtility.
    /// </summary>
    public partial class ConstantUtility
    {
        #region Constructor
        static ConstantUtility()
        {
            DocTypeDictionary.Add("50", "APPENDIX_A");
            DocTypeDictionary.Add("51", "BANK_SIGNATURE_CARD");
            DocTypeDictionary.Add("52", "PROOF_OF_INVESTMENTS");
            DocTypeDictionary.Add("53", "PROOF_OF_ETHNICITY");
            DocTypeDictionary.Add("54", "PROOF_OF_CITIZENSHIP");
            DocTypeDictionary.Add("55", "PROOF_OF_ALIEN_STATUS");
            DocTypeDictionary.Add("56", "LEASE_AGREEMENT");
            DocTypeDictionary.Add("57", "THIRD_PARTY_AGREEMENTS");
            DocTypeDictionary.Add("58", "EMPLOYMENT_AGREEMENTS");
            DocTypeDictionary.Add("59", "VEHICLE_REGISTRATION");
            DocTypeDictionary.Add("60", "CERTIFICATION_OR_DENIAL");
            DocTypeDictionary.Add("61", "PROOF_OF_8A");
            DocTypeDictionary.Add("62", "REQUEST_FOR_EXEMPTION");
            DocTypeDictionary.Add("63", "OPERATING_AGREEMENTS");
            DocTypeDictionary.Add("64", "BUSINESS_TRADE_NAME");
            DocTypeDictionary.Add("65", "BUSINESS_CERTIFICATE");
            DocTypeDictionary.Add("66", "CERTIFICATE_OF_REGISTRATION");
            DocTypeDictionary.Add("67", "PARTNERSHIP_AGREEMENT");
            DocTypeDictionary.Add("68", "BUYOUT_RIGHTS");
            DocTypeDictionary.Add("69", "ARTICLES_OF_ORGANIZATION");
            DocTypeDictionary.Add("70", "FIRST_MEETING_MINUTES");
            DocTypeDictionary.Add("71", "STOCK_CERTIFICATES");
            DocTypeDictionary.Add("72", "STOCK_LEDGER");
            DocTypeDictionary.Add("73", "STOCK_AGREEMENTS");
            DocTypeDictionary.Add("74", "BOARD_OF_DIRECTORS");
            DocTypeDictionary.Add("75", "GROSS_RECEIPTS");
            DocTypeDictionary.Add("76", "PROOF_OF_PARTNERSHIP");
            DocTypeDictionary.Add("77", "PROOF_OF_INCORPORATION");
            DocTypeDictionary.Add("78", "AUDITED_STATEMENTS");
            DocTypeDictionary.Add("79", "REVIEWED_STATEMENTS");
            DocTypeDictionary.Add("80", "CORPORATION_TAX_RETURN");
            DocTypeDictionary.Add("81", "STATE_CITY_TAX_RETURNS");
            DocTypeDictionary.Add("82", "CERTIFICATION_DOCUMENT");
            DocTypeDictionary.Add("83", "CERTIFICATION_AFFIDAVIT");
            DocTypeDictionary.Add("84", "ADDITIONAL_INFORMATION");
            DocTypeDictionary.Add("100", "CERTIFICATION_APPLICATION");

            QualPendingDictionary.Add(SupplierStatusType.NewPrequalification.Id.ToString(), SupplierStatusType.NewPrequalification.Description);
            QualPendingDictionary.Add(SupplierStatusType.ApplicationSubmitted.Id.ToString(), SupplierStatusType.ApplicationSubmitted.Description);
            QualPendingDictionary.Add(SupplierStatusType.ManagerReviewed.Id.ToString(), SupplierStatusType.ManagerReviewed.Description);
            QualPendingDictionary.Add(SupplierStatusType.ReviewerReviewed.Id.ToString(), SupplierStatusType.ReviewerReviewed.Description);
            QualPendingDictionary.Add(SupplierStatusType.RequestMoreInfoPending.Id.ToString(), SupplierStatusType.RequestMoreInfoPending.Description);
            QualPendingDictionary.Add(SupplierStatusType.RequestMoreInfo.Id.ToString(), SupplierStatusType.RequestMoreInfo.Description);
            QualPendingDictionary.Add(SupplierStatusType.AdditionalInfoSubmitted.Id.ToString(), SupplierStatusType.AdditionalInfoSubmitted.Description);
            QualPendingDictionary.Add(SupplierStatusType.ReferenceReviewed.Id.ToString(), SupplierStatusType.ReferenceReviewed.Description);
            QualPendingDictionary.Add(SupplierStatusType.FinacialReviewed.Id.ToString(), SupplierStatusType.FinacialReviewed.Description);
            QualPendingDictionary.Add(SupplierStatusType.AllReviewed.Id.ToString(), SupplierStatusType.AllReviewed.Description);
            QualPendingDictionary.Add(SupplierStatusType.OIGApproved.Id.ToString(), SupplierStatusType.OIGApproved.Description);
            QualPendingDictionary.Add(SupplierStatusType.QualifiedPending.Id.ToString(), SupplierStatusType.QualifiedPending.Description);
            QualPendingDictionary.Add(SupplierStatusType.PreDeny.Id.ToString(), SupplierStatusType.PreDeny.Description);
            QualPendingDictionary.Add(SupplierStatusType.AdministrativelyClosed.Id.ToString(), SupplierStatusType.AdministrativelyClosed.Description);
            QualPendingDictionary.Add(SupplierStatusType.DirectorClosePending.Id.ToString(), SupplierStatusType.DirectorClosePending.Description);
            QualPendingDictionary.Add(SupplierStatusType.DirectorClosed.Id.ToString(), SupplierStatusType.DirectorClosed.Description);
            QualPendingDictionary.Add(SupplierStatusType.OIGReviewed.Id.ToString(), SupplierStatusType.OIGReviewed.Description);
            QualPendingDictionary.Add(SupplierStatusType.RequestMoreInfo2.Id.ToString(), SupplierStatusType.RequestMoreInfo2.Description);
            QualPendingDictionary.Add(SupplierStatusType.AdditionalInfoSubmitted2.Id.ToString(), SupplierStatusType.AdditionalInfoSubmitted2.Description);

            CertPendingDictionary.Add(CertificationStatusType.NewCertification.Id.ToString(), CertificationStatusType.NewCertification.Description);
            CertPendingDictionary.Add(CertificationStatusType.CertAppSubmitted.Id.ToString(), CertificationStatusType.CertAppSubmitted.Description);
            CertPendingDictionary.Add(CertificationStatusType.CertAnalystReviewed.Id.ToString(), CertificationStatusType.CertAnalystReviewed.Description);
            CertPendingDictionary.Add(CertificationStatusType.RequestMoreCertInfoPending.Id.ToString(), CertificationStatusType.RequestMoreCertInfoPending.Description);
            CertPendingDictionary.Add(CertificationStatusType.RequestMoreCertInfo.Id.ToString(), CertificationStatusType.RequestMoreCertInfo.Description);
            CertPendingDictionary.Add(CertificationStatusType.AdditionalCertInfoSubmitted.Id.ToString(), CertificationStatusType.AdditionalCertInfoSubmitted.Description);
            CertPendingDictionary.Add(CertificationStatusType.MWBEReviewed.Id.ToString(), CertificationStatusType.MWBEReviewed.Description);
            CertPendingDictionary.Add(CertificationStatusType.LBEReviewed.Id.ToString(), CertificationStatusType.LBEReviewed.Description);
            CertPendingDictionary.Add(CertificationStatusType.CertAnalystApproved.Id.ToString(), CertificationStatusType.CertAnalystApproved.Description);
            CertPendingDictionary.Add(CertificationStatusType.DirectorApprovalPending.Id.ToString(), CertificationStatusType.DirectorApprovalPending.Description);
            CertPendingDictionary.Add(CertificationStatusType.DirectorApproved.Id.ToString(), CertificationStatusType.DirectorApproved.Description);
            CertPendingDictionary.Add(CertificationStatusType.CertAnalystClosed.Id.ToString(), CertificationStatusType.CertAnalystClosed.Description);
            CertPendingDictionary.Add(CertificationStatusType.CertClosed.Id.ToString(), CertificationStatusType.CertClosed.Description);
            CertPendingDictionary.Add(CertificationStatusType.CertAdminClosed.Id.ToString(), CertificationStatusType.CertAdminClosed.Description);
            CertPendingDictionary.Add(CertificationStatusType.RequestMoreCertInfo2.Id.ToString(), CertificationStatusType.RequestMoreCertInfo2.Description);
            CertPendingDictionary.Add(CertificationStatusType.AdditionalCertInfoSubmitted2.Id.ToString(), CertificationStatusType.AdditionalCertInfoSubmitted2.Description);
            CertPendingDictionary.Add(CertificationStatusType.CertAnalystAssigned.Id.ToString(), CertificationStatusType.CertAnalystAssigned.Description);
            CertPendingDictionary.Add(CertificationStatusType.ConditionallyCertified.Id.ToString(), CertificationStatusType.ConditionallyCertified.Description);

            ProjectRevisionDictionary.Add(ProjectBidAwardStatusType.CSReviewed.Id.ToString(), ProjectBidAwardStatusType.CSReviewed.Description);
            ProjectRevisionDictionary.Add(ProjectBidAwardStatusType.PendingMgrSolicitationReview.Id.ToString(), ProjectBidAwardStatusType.PendingMgrSolicitationReview.Description);
            ProjectRevisionDictionary.Add(ProjectBidAwardStatusType.CSRevised.Id.ToString(), ProjectBidAwardStatusType.CSRevised.Description);
            ProjectRevisionDictionary.Add(ProjectBidAwardStatusType.PendingDirSolicitationReview.Id.ToString(), ProjectBidAwardStatusType.PendingDirSolicitationReview.Description);
            ProjectRevisionDictionary.Add(ProjectBidAwardStatusType.PendingCSRevision.Id.ToString(), ProjectBidAwardStatusType.PendingCSRevision.Description);
            ProjectRevisionDictionary.Add(ProjectBidAwardStatusType.PendingIFBIssuance.Id.ToString(), ProjectBidAwardStatusType.PendingIFBIssuance.Description);
        }
        #endregion

        #region Constants
        public const int BARCODE_NUMBER_LENGTH = 10;

        public const string COMMON_DATASOURCE_NAME = "Common";
        public const string SUPPLIER_DATASOURCE_NAME = "Supplier";
        public const string CONTENT_DATASOURCE_NAME = "Content";
        public const string USER_DATASOURCE_NAME = "User";
        public const string USER_DATASOURCE_DBREFRESH = "DbReftrsh";
                
        public const string QA_DATASOURCE_NAME = "QA";
        public const string QENGINE_DATASOURCE_NAME = "QEngine";
        public const string WORKFLOW_DATASOURCE_NAME = "Workflow";
        public const string RFD_DATASOURCE_NAME = "Rfd";
        public const string HB_DATASOURCE_NAME = "Hb";
        public const string TEMPLATE_DATASOURCE_NAME = "Template";

        public const string RFP_DATASOURCE_NAME = "Rfp";

        public const string INVITATION_FOR_BIDAWARD_EMAIL_TEMPLATE = "INVITATION_FOR_BID_LETTER";
        public const string INVITATION_FOR_BIDAWARD_FOR_POCPO_EMAIL_TEMPLATE = "INVITATION_FOR_BID_LETTER_POCPO";

        public const string BA_BP_ADVAGENCIES_IFBISSUED_EMAIL_TEMPLATE = "BA_BP_ADVAGENCIES_IFBISSUED";
        public const string BA_BP_LLVENDORS_IFBISSUED_EMAIL_TEMPLATE = "BA_BP_LLVENDORS_IFBISSUED";

        public const string BIDAWARD_BIDREAKDOWN_EMAIL_TEMPLATE = "BA_BIDBREAKDOWN";
        public const string BA_BIDDER_REJECTION_EMAIL_TEMPLATE = "BA_BIDDER_REJECTION";
        public const string BA_PREAWARD_VETTING_MANAGER_FINAL_REVIEW_DENY = "BA_PREAWARD_VETTING_MANAGER_FINAL_REVIEW_DENY";
        public const string BIDAWARD_BIDRESULTS_EMAIL_TEMPLATE = "BA_BIDRESULTS";
        public const string BIDAWARD_BIDRESULTS_FYI_EMAIL_TEMPLATE = "BA_BIDRESULTS_FYI";
        public const string LOOKUP_INVITATIONFORBID_ATTACHMENT_TEMPALTE = "BAA_INVITATIONFORBID_ATTACHMENTTEMPLATE";
        public const string LOOKUP_BIDCHECKLIST_ATTACHMENT_TEMPALTE = "BAA_BIDCHECKLIST_ATTACHMENTTEMPLATE";
        public const string LOOKUP_S1PACKAGE_ATTACHMENT_TEMPALTE = "BAA_S1PACKAGE_ATTACHMENTTEMPLATE";
        public const string LOOKUP_ADVERTISE_VENDORS = "ADVERTISE_VENDORS";
        public const string LOOKUP_ADVERTISE_AGENCY = "ADVERTISE_AGENCY";
        public const string BA_BP_PROJ_CREATED = "BA_BP_PROJ_CREATED";

        public const string LOOKUP_HB_JUSTIFICATIONMEMO_TYPE = "HARDBID_JUSTIFICATION_MEMO_TYPES";

        public const string EXTERNAL_SITE = "/NYCSCA";
        public const string INTERNAL_SITE = "/NYCSCA/Internal";

        public const string APPLICATION_NAME = "NYCSCA";

        public const string CUSTOMER_CODE = "014";
        public const int ANSWER_COUNT = 6;
        public const int CERTIFICATION_COUNT = 3;
        public const int CERTIFICATION_NOTICE_DAY = 30;
        public const int PASSWORD_LENGTH = 6;
        public const int CHECKLISTID = 1000;
        public const int APPROVEQUALCHECKLISTID = 1200;
        public const int APPROVECERTCHECKLISTID = 1400;
        public const int PAPERQUALCHECKLISTID = 1600;
        public const int PAPERCERTCHECKLISTID = 1800;
        public const int SUBCONTRACTORCHECKLISTID = 1000;
        public const int SUBCONTRACTORINSURANCECHECKLISTID = 1200;
        public const int SUBCONTRACTORAPPRENTCHECKLISTID = 1201;
        public const int SUBCONTRACTORREVIEWCHECKLISTID = 1500;

        public const string APPENDIX_A = "50";
        public const string BANK_SIGNATURE_CARD = "51";
        public const string PROOF_OF_INVESTMENTS = "52";
        public const string PROOF_OF_ETHNICITY = "53";
        public const string PROOF_OF_CITIZENSHIP = "54";
        public const string PROOF_OF_ALIEN_STATUS = "55";
        public const string LEASE_AGREEMENT = "56";
        public const string THIRD_PARTY_AGREEMENTS = "57";
        public const string EMPLOYMENT_AGREEMENTS = "58";
        public const string VEHICLE_REGISTRATION = "59";
        public const string CERTIFICATION_OR_DENIAL = "60";
        public const string PROOF_OF_8A = "61";
        public const string REQUEST_FOR_EXEMPTION = "62";
        public const string OPERATING_AGREEMENTS = "63";
        public const string BUSINESS_TRADE_NAME = "64";
        public const string BUSINESS_CERTIFICATE = "65";
        public const string CERTIFICATE_OF_REGISTRATION = "66";
        public const string PARTNERSHIP_AGREEMENT = "67";
        public const string BUYOUT_RIGHTS = "68";
        public const string ARTICLES_OF_ORGANIZATION = "69";
        public const string FIRST_MEETING_MINUTES = "70";
        public const string STOCK_CERTIFICATES = "71";
        public const string STOCK_LEDGER = "72";
        public const string STOCK_AGREEMENTS = "73";
        public const string BOARD_OF_DIRECTORS = "74";
        public const string GROSS_RECEIPTS = "75";
        public const string PROOF_OF_PARTNERSHIP = "76";
        public const string PROOF_OF_INCORPORATION = "77";
        public const string CERTIFICATION_DOCUMENT = "78";
        public const string CERTIFICATION_AFFIDAVIT = "79";
        public const string AUDITED_STATEMENTS = "80";
        public const string REVIEWED_STATEMENTS = "81";
        public const string CORPORATION_TAX_RETURN = "82";
        public const string STATE_CITY_TAX_RETURNS = "83";
        public const string ADDITIONAL_INFORMATION = "84";
        public const string INSURANCE_CERTIFICATE = "85";
        public const string INSURANCE_CERTIFICATE_STRING = "Insurance";
        public const string KEYPERSON_APPENDIX_A = "86";
        public const string MORE_INFO = "87";
        public const string CERTIFICATION_APPLICATION = "100";
        public const string AFFIDAVIT_NO_CHANGE = "101";

        public static Dictionary<string, string> DocTypeDictionary = new Dictionary<string, string>();
        public static Dictionary<string, string> QualPendingDictionary = new Dictionary<string, string>();
        public static Dictionary<string, string> CertPendingDictionary = new Dictionary<string, string>();
        public static Dictionary<string, string> ProjectRevisionDictionary = new Dictionary<string, string>();

        public const string DATE_FORMAT = "MM/dd/yyyy";
        public const string DEFAULT_COUNTRY = "USA";
        public const string DEFAULT_TIMEZONE = "Eastern Standard Time";
        public const string DEFAULT_VERSION = "1.0";

        public const int SYSTEM_PERMISSION = 1;
        public const int WORKFLOW_PERMISSION = 3;

        public const string WORKFLOW_DIVERSITY = "Diversity";
        public const string WORKFLOW_QUALIFICATION = "Supplier Prequalification";
        public const string WORKFLOW_OIG_QUALIFICATION = "OIG Qualification";
        public const string WORKFLOW_CERTIFICATION = "Supplier Certification";
        public const string WORKFLOW_MENTOR = "Mentor Workflow";
        public const string WORKFLOW_AMENDED_TRADE_CODE = "Amended Trade Code";
        public const string WORKFLOW_OVER_1MM = "Qualification Over 1MM";
        public const string WORKFLOW_CHANGE_IN_APPLICATION = "Change in Application";
        public const string WORKFLOW_PREAWARD_VETTING = "Pre-Award Vetting Workflow";
        public const string SUPPLIERTYPE_SUPPLIER = "Supplier";
        public const string SUPPLIERTYPE_PAPER_QUAL = "PaperQual";
        public const string SUPPLIERTYPE_PAPER_REQUAL = "PaperRequal";
        public const string SUPPLIERTYPE_PAPER_CERT = "PaperCert";
        public const string SUPPLIERTYPE_PAPER_RECERT = "PaperRecert";
        public const string SUPPLIERTYPE_ONLINE = "Online";
        public const string SUPPLIERTYPE_AD_HOC = "AdHoc";
        public const string SUPPLIERTYPE_PASS_THROUGH = "PassThrough";
        public const string SUPPLIERTYPE_DISQUALIFIED = "Disqualified";

        public const string SUPPLIER_CERTIFICATION_SUBMITTED = "Certification Submitted";
        public const string SUPPLIER_APPLICATION_SUBMITTED = "Application Submitted";

        public const string DOCUMENTT_CHECKLIST = "CHECKLIST";
        public const string DOCUMENTT_TRIP = "TRIP";
        public const string DOCUMENTT_COA = "COA";
        public const string DOCUMENTT_INDUSTRY_INFO = "INDUSTRY_INFO";
        public const string DOCUMENTT_WEB_LINK = "WEB_LINK";
        public const string DOCUMENTT_FOLLOW_UP = "FOLLOW_UP";

        public const int MENUITEM_ID_LBEQUAL = 28;
        public const int MENUITEM_ID_QUALSTATEMENT1 = 12;
        public const int MENUITEM_ID_QUALSTATEMENT2 = 13;
        public const int MENUITEM_ID_QUALSTATEMENT3 = 14;
        public const int MENUITEM_ID_FINANCIAL1 = 16;
        public const int MENUITEM_ID_FINANCIAL2 = 17;
        public const int MENUITEM_ID_FINANCIAL3 = 18;
        public const int MENUITEM_ID_SAFETY = 19;

        public static string[] RULE_STATUS = 
	    {	
		    "Unknown",
		    "Required",
		    "Not Required",
		    "Disabled"
	    };

        public static string[] TIN_STATUS = 
		{	
			"Matched",
			"Wrong ID",
			"Not Exist",
			"Not Match",
			"Invalid",
			"Duplicate",
			"N/A"
		};

        // Password Status
        public const string PASSWORD_STATUS_NOT_SET = "0";
        public const string PASSWORD_STATUS_CURRENT = "1";
        public const string PASSWORD_STATUS_EXPIRED = "2";
        public const string PASSWORD_STATUS_FIRSTLOGIN = "3";
        public const string PASSWORD_STATUS_IMPORTED = "5";

        public const string VERIFY_STR = "I have reviewed all of the above information and verify it is correct.";
        public const string NOT_SPECIFIED_STR = "<em>NOT SPECIFIED</em>";
        public const string REQUIRED_FIELD_STR = "<span class=\"error\">REQUIRED FIELD</span>";

        public const int MAX_FILE_SIZE = 5120;
        public const string FILE_TYPE_REGEX = "(.*((\\.([gG][iI][fF]))|(\\.([jJ][pP][gG]))|(\\.([pP][nN][gG]))|(\\.([bB][mM][pP]))|(\\.([tT][iI][fF]))|(\\.([dD][oO][cC]))|(\\.([dD][oO][cC][xX]))|(\\.([xX][lL][sS]))|(\\.([xX][lL][sS][xX]))|(\\.([pP][pP][tT]))|(\\.([pP][pP][tT][xX]))|(\\.([pP][dD][fF]))|(\\.([rR][tT][fF]))|(\\.([zZ][iI][pP]))|(\\.([vV][sS][dD]))|(\\.([mM][pP][pP]))|(\\.([dD][wW][gG]))|(\\.([cC][sS][vV]))|(\\.([tT][xX][tT])))$)";
        public const string FILE_TYPE_ERR_MSG = "File must be one of the following types: .gif, .jpg, .png, .bmp, .tif, .doc, .xls, .xslx, .ppt, .pptx, .pdf, .rtf, .zip, .vsd, .mpp, .dwg, .docx, .csv, .txt.";

        public const string FILE_TYPE_REGEX_IMG = "(.*((\\.([gG][iI][fF]))|(\\.([jJ][pP][gG]))|(\\.([pP][nN][gG]))|(\\.([bB][mM][pP]))|(\\.([tT][iI][fF])))$)";
        public const string FILE_TYPE_ERR_MSG_IMG = "File must be one of the following types: .gif, .jpg, .png, .bmp, .tif";

        // Third Party Check
        //public const string DNB_LOGIN_URL = "https://www.dnb.com/scripts/ProductRetriever.asp";

        public const string DNB_LOGIN_URL = "https://dnb.onelogin.com/sessions";
        public const string LN_HOME_URL = "https://www.lexis.com";
        public const string LN_LOGIN_URL = "https://www.lexis.com/research";

        // Change History
        public static string[] CHANGETYPE_ARRAY = new string[] { "Supplier", "SupplierAddress", 
            "VendorContact", "SupplierDocument", "SupplierBusinessMixedInfo", "SupplierRelatedFirm", 
            "SupplierPersonnel", "SupplierPersonnelMixedInfo", "License", "SupplierProject", 
            "SupplierProjectStatistics", "SupplierAccount", "SupplierSurety", "SupplierInsurance", 
            "SupplierInsuranceClaim", "SupplierCredit", "SupplierDebt", "SupplierDebtEvent", 
            "SupplierPayemnt", "SupplierFailedContract", "SupplierOSHAStatistics", 
            "SupplierApprenticeshipProgram", "SupplierPersonnelGovernmentAgency", 
            "SupplierGovernAction", "SupplierLawsuit", "SupplierLawAction", "SupplierUnethicalPractice",
            "SupplierDisadvantagedEmployee", "Certification", "SupplierCertificationAppeal", "Service" };
        public const int CHANGETYPE_SUPPLIER = 1;
        public const int CHANGETYPE_SUPPLIERADDRESS = 2;
        public const int CHANGETYPE_VENDORCONTACT = 3;
        public const int CHANGETYPE_SUPPLIERDOCUMENT = 4;
        public const int CHANGETYPE_SUPPLIERBUSINESSMIXEDINFO = 5;
        public const int CHANGETYPE_SUPPLIERRELATEDFIRM = 6;
        public const int CHANGETYPE_SUPPLIERPERSONNEL = 7;
        public const int CHANGETYPE_SUPPLIERPERSONNELMIXEDINFO = 8;
        public const int CHANGETYPE_SUPPLIERLICENSE = 9;
        public const int CHANGETYPE_SUPPLIERPROJECT = 10;
        public const int CHANGETYPE_SUPPLIERPROJECTSTATISTICS = 11;
        public const int CHANGETYPE_SUPPLIERACCOUNT = 12;
        public const int CHANGETYPE_SUPPLIERSURETY = 13;
        public const int CHANGETYPE_SUPPLIERINSURANCE = 14;
        public const int CHANGETYPE_SUPPLIERINSURANCECLAIM = 15;
        public const int CHANGETYPE_SUPPLIERCREDIT = 16;
        public const int CHANGETYPE_SUPPLIERDEBT = 17;
        public const int CHANGETYPE_SUPPLIERDEBTEVENT = 18;
        public const int CHANGETYPE_SUPPLIERPAYMENT = 19;
        public const int CHANGETYPE_SUPPLIERFAILEDCONTRACT = 20;
        public const int CHANGETYPE_SUPPLIEROSHASTATISTICS = 21;
        public const int CHANGETYPE_SUPPLIERAPPRENTICESHIPPROGRAM = 22;
        public const int CHANGETYPE_SUPPLIERPERSONNELGOVERNMENTAGENCY = 23;
        public const int CHANGETYPE_SUPPLIERGOVERNACTION = 24;
        public const int CHANGETYPE_SUPPLIERLAWSUIT = 25;
        public const int CHANGETYPE_SUPPLIERLAWACTION = 26;
        public const int CHANGETYPE_SUPPLIERUNETHICALPRACTICE = 27;
        public const int CHANGETYPE_SUPPLIERDISADVANTAGEDEMPLOYEE = 28;
        public const int CHANGETYPE_SUPPLIERCERTIFICATION = 29;
        public const int CHANGETYPE_SUPPLIERCERTIFICATIONAPPEAL = 30;
        public const int CHANGETYPE_SUPPLIERSERVICE = 31;

        public const int WICKS_AMOUNT_LIMIT = 10000;

        public const string VETTYPE_QUALIFICATION = "";
        public const string VETTYPE_SAF = "SAF";
        public const string VETTYPE_LIMITEDLIST = "Rfd";
        public const string VETTYPE_BIDAWARD = "Rfc";
        public const string VETTYPE_CONTRACTS = "Contracts";
        public const string VETTYPE_HARDBID = "Hb";
        public const string SAF_EMERGENCY_CONTRACTS = "32";
        #endregion

        public static string[] WICKS_TRADES = new string[] {
            "13800", "13850", "13900", "15000", "15050", "15080", "15180", "15190", 
            "15230", "15300", "15400", "15500", "15530", "15600", "15700", "15780", 
            "15800", "15810", "15850", "15900", "15935", "16000", "16050", 
            "16080", "16100", "16200", "16300", "16400", "16500", "16550", "16700", 
            "16710", "16800", "16810"};

        public const string IFAXTYPE_SUPPLIER = "Supplier";
        public const string IFAXTYPE_SAF = "SAF";

        public static string[] CLASSIFICATION_ARRAY = 
	    {	
            "MBE",
            "WBE",
            "LBE"
	    };

        public enum Rfc_DcoType
        {
            EngineerEstimate,
            EstIncluded,
            TransAvailable,
            ChecklistAvailable,
            TurnoverSheet,
            IFBInfoSheet,
            BuildingCodeCompliance,
            PMPBond,
            BidBond
        }

        public enum Rfc_Wicks_PropertyID : Int32
        {
            WICKS_HAVAC = 110,
            WICKS_ELECTRICAL,
            WICKS_PLUMBING,
            WICKS_LESS10000,
            WICKS_NOTRADES
        }

        public enum JM_DocType
        {
            EngineerEstimate,
            EstIncluded,
            TransAvailable,
            ChecklistAvailable,
            TurnoverSheet,
            IFBInfoSheet,
            BuildingCodeCompliance,
            PMPBond,
            BidBond,


            s01010,
            s01500,
            PrincipalLetter,
            S1,
            RevisedEstimate,
            BAFO
        }

        public enum JM_Wicks_PropertyID : Int32
        {
            WICKS_HAVAC = 110,
            WICKS_ELECTRICAL,
            WICKS_PLUMBING,
            WICKS_LESS10000,
            WICKS_NOTRADES
        }

        public static Dictionary<string, string> Boroughs = new Dictionary<string, string>()
                {
                    { "M", "Manhattan" },
                    { "Q", "Queens" },
                    { "X", "Bronx" },
                    { "K", "Brooklyn" },
                    { "R", "Staten Island"}
                };
    }
}
