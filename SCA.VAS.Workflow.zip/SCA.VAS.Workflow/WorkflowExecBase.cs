﻿using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.ValueObjects.Workflow;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.XPath;

namespace SCA.VAS.Workflow
{
    public abstract class WorkflowExecBase<T> where T: IWorkflowable
    {
        private string prefixDbName = string.Empty;
        private static int userId = 0;
        protected string _WORKFLOW_TYPE_ = ConstantUtility.WORKFLOW_SUP;
        #region Constructor
        public WorkflowExecBase(string WorkFlowType)
        {
            _WORKFLOW_TYPE_ = WorkFlowType;
        }
        static WorkflowExecBase()
        {
        }
        #endregion Constructor

        protected abstract bool UpdateTransactionId(int WorkflowableObjId, int Transactionid);
        protected abstract bool UpdateStatus(int WorkflowableObjId, int status, string statusName);
        protected abstract void DoWorkflowEmail(T wfable, WorkflowNode node, WorkflowHistory workflowHistory,
            string emailMessageName, string comments);
        protected abstract void DoAction(string actionName);

        #region Private Method
        private T GetWorkflow(T wfable)
        {
            if (wfable == null) return wfable;

            if (wfable.WorkflowId <= 0)
            {
                WorkflowList workflow = WorkflowListUtility.GetByName(
                    ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                    _WORKFLOW_TYPE_, 0);
                if (workflow != null)
                    wfable.WorkflowId = workflow.Id;
            }

            if (wfable.TransactionId <= 0)
            {
                wfable.TransactionId = WorkflowExec.CreateWorkflowHistory(wfable.WorkflowId);
                //////PlanUtility.UpdateTransactionId(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                //////    plan.Id, plan.TransactionId);
                UpdateTransactionId(wfable.Id, wfable.TransactionId);

                ///****/  NodeAction(workflowable, "New Workflow");
            }
            return wfable;
        }
        #endregion

        #region workflow control
        public T InitialWorkflow(T wfable)
        {
            return GetWorkflow(wfable);
        }
        public User GetLastApprover(T wfable)
        {
            wfable = GetWorkflow(wfable);
            if (wfable == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(wfable.TransactionId);
            if (workflowHistory == null) return null;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return null;

            return UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
                workflowHistory.ApprovalUserId);
        }

        public int PlanWorkflow(T wfable, string systemAction, string comments, ref string errmsg, ref string url)
        {
            wfable = GetWorkflow(wfable);
            if (wfable == null) return 0;

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_SYSTEMNAME,
                new object[] { wfable.WorkflowId, systemAction });
            if (workflowNodes == null || workflowNodes.Count == 0) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(wfable.TransactionId);
            if (workflowHistory == null)
                return 0;

            int actionId = 0;
            for (int i = 0; i < workflowNodes.Count; i++)
            {
                if (workflowHistory.CurrentNodeId == workflowNodes[i].NodeFromId)
                {
                    actionId = workflowNodes[i].Id;
                    break;
                }
            }
            return PlanWorkflow(wfable, actionId, comments, ref errmsg, ref url);
        }

        public int PlanWorkflow(T wfable, int actionId, string comments, ref string errmsg, ref string url)
        {
            wfable = GetWorkflow(wfable);
            if (wfable == null) return 0;
            if (actionId == 0) return wfable.TransactionId;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(wfable.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowNode workflowNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
            if (workflowNode == null)
                return 0;
            if (workflowHistory.CurrentNodeId != workflowNode.NodeFromId)
                return 0;

            // condition proccessing
            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNode.Id });

            TextReader reader = XmlUtility.Serialize(wfable);
            XPathDocument doc = new XPathDocument(reader);
            XPathNavigator nav = doc.CreateNavigator();

            errmsg = string.Empty;
            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count == 0)
                    {
                        errmsg += workflowCondition.ErrorMessage + "<br>";
                    }
                }
            }
            if (errmsg != string.Empty) return 0;

            //Workflow topologic
            bool approval = true;
            switch (workflowNode.Action1)
            {
                case "One":
                    break;
                case "Owner":
                    //if (plan.BuyerId != userId)
                    //    errmsg = "Only RFx owner / Creator can do this step";
                    break;
                case "All":
                case "Majority":
                case "Count":
                    WorkflowHistoryCollection workflowHistories = WorkflowHistoryUtility.FindByCriteria(
                        prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                        new object[] { wfable.TransactionId });

                    WorkflowHistoryCollection currentHistories = new WorkflowHistoryCollection();
                    if (workflowHistories != null)
                    {
                        for (int i = workflowHistories.Count - 1; i >= 0; i--)
                        {
                            if (workflowHistories[i].IsActive == 1) break;
                            if (workflowHistories[i].CurrentNodeId != actionId) continue;
                            if (workflowHistories[i].ApprovalUserId == userId)
                            {
                                errmsg = "You already approved this step";
                                return 0;
                            }
                            currentHistories.Add(workflowHistories[i]);
                        }
                    }

                    // Create a history from new approval
                    WorkflowHistory approvalHistory = WorkflowHistoryUtility.CreateObject();
                    approvalHistory.TransactionHeaderId = wfable.TransactionId;
                    approvalHistory.WorkflowId = wfable.WorkflowId;
                    approvalHistory.CurrentNodeId = actionId;
                    approvalHistory.ApprovalUserId = WorkflowExec.GetUserId();
                    approvalHistory.ApprovalConditionId = 1;
                    approvalHistory.CreatedBy = workflowHistory.ApprovalUserId;
                    approvalHistory.CreatedType = WorkflowExec.GetUserType();
                    WorkflowHistoryUtility.Create(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, approvalHistory);

                    int approvalKnt = currentHistories.Count + 1;
                    switch (workflowNode.Action1)
                    {
                        case "All":
                            //if (approvalKnt < planUsers.Count)
                            //    approval = false;
                            break;
                        case "Majority":
                            //if (approvalKnt < planUsers.Count / 2)
                            //    approval = false;
                            break;
                        case "Count":
                            int knt = ConvertUtility.ConvertInt(workflowNode.Action2);
                            if (approvalKnt < knt)
                                approval = false;
                            break;
                    }
                    break;

                    //case "Sequence":
                    //    break;
                    //case "Timer":
                    //    //approve7.Checked = true;
                    //    //approveKnt7.Text = workflowNode.Action2;
                    //    break;
            }

            if (!approval || errmsg != string.Empty) return wfable.TransactionId;

            //Action proccessing
            WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE,
                new object[] { workflowNode.Id });

            if (workflowActions != null)
            {
                foreach (WorkflowAction workflowAction in workflowActions)
                {
                    switch (workflowAction.Type)
                    {
                        //Send Email
                        case 1:
                            //CommonUtility.PlanSendEmail(plan, workflowNode, workflowHistory, workflowAction.FunctionName, comments, prefixDbName);
                            DoWorkflowEmail(wfable, workflowNode, workflowHistory, workflowAction.FunctionName, comments);
                            break;

                        //Action
                        case 2:
                            DoAction(workflowAction.FunctionName);
                            break;

                        //Redirect page
                        case 3:
                            url = workflowAction.FunctionName;
                            break;
                    }
                }
            }

            if (workflowNode.NodeToId > 0)
            {
                WorkflowNode nextNode = WorkflowNodeUtility.Get(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode.NodeToId);
                WorkflowExec.WorkflowNextStatus(workflowNode.WorkflowId, nextNode.Name, workflowHistory.CurrentNodeId, wfable.TransactionId, comments);

                // ?? Should we create a DoComment() virtual method ?? 
                //if (comments.Trim() != string.Empty)
                //{
                //    Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.RFD_DATASOURCE_NAME,
                //        "Plan", plan.Id.ToString());
                //    User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

                //    VendorComment vendorComment = VendorCommentUtility.CreateObject();
                //    vendorComment.UserId = user.Id;
                //    vendorComment.VendorId = vendor.Id;
                //    vendorComment.Comments = "Workflow Comments: " + comments;
                //    vendorComment.Type = "User";
                //    vendorComment.ChangeUser = user.FullName;

                //    VendorCommentUtility.Create(ConstantUtility.RFD_DATASOURCE_NAME, vendorComment);
                //}

                NodeAction(wfable, comments);
            }

            return wfable.TransactionId;
        }

        public int PlanWorkflow(T wfable, string nextStatus, string comments)
        {
            wfable = GetWorkflow(wfable);
            if (wfable == null) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(wfable.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowExec.WorkflowNextSystemStatus(wfable.WorkflowId, nextStatus, workflowHistory.CurrentNodeId, wfable.TransactionId, comments);

            // ?? Should we create a DoComment() Virtual Method ??
            //if (comments.Trim() != string.Empty)
            //{
            //    Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.RFD_DATASOURCE_NAME,
            //        "Plan", plan.Id.ToString());
            //    User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

            //    VendorComment vendorComment = VendorCommentUtility.CreateObject();
            //    vendorComment.VendorId = vendor.Id;
            //    vendorComment.Comments = "Workflow Comments: " + comments;
            //    if (user != null)
            //    {
            //        vendorComment.UserId = user.Id;
            //        vendorComment.Type = "User";
            //        vendorComment.ChangeUser = user.FullName;
            //    }

            //    VendorCommentUtility.Create(ConstantUtility.RFD_DATASOURCE_NAME, vendorComment);
            //}

            NodeAction(wfable, comments);

            return wfable.TransactionId;
        }

        public WorkflowConditionCollection PlanWorkflowConditionTest(T wfable, int workflowNodeId)
        {
            wfable = GetWorkflow(wfable);
            if (wfable == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(wfable.TransactionId);
            if (workflowHistory == null)
                return null;

            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNodeId });

            XPathDocument doc = new XPathDocument(XmlUtility.Serialize(wfable));
            XPathNavigator nav = doc.CreateNavigator();

            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count > 0)
                        workflowCondition.Status = 1;
                }
            }
            return workflowConditions;
        }

        #endregion workflow control


        #region Workflow Node Action
        private void NodeAction(T wfable, string comments)
        {
            wfable = GetWorkflow(wfable);
            if (wfable == null) return;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(
                wfable.TransactionId);

            ////int status = ((PlanStatusType)workflowHistory.CurrentNode.Name.Trim()).Id;
            ///status id should be workflownode UserStepId
            int status = workflowHistory.CurrentNode.UserStepId;

            if (status == 0 || status == wfable.Status) return;
            //////PlanUtility.UpdateStatus(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME, plan.Id, status, workflowHistory.CurrentNode.Name);
            UpdateStatus(wfable.Id, status, workflowHistory.CurrentNode.Name);

            // automatic step
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { wfable.WorkflowId, "UserStepId", "ASC" });
            if (workflowNodes != null)
            {
                for (int i = 0; i < workflowNodes.Count; i++)
                {
                    if (workflowNodes[i].Type != 1 || workflowNodes[i].TimeToSkip != 1 ||
                        workflowHistory.CurrentNodeId != workflowNodes[i].NodeFromId)
                        continue;

                    string errmsg = string.Empty;
                    string url = string.Empty;
                    // ?? Was comment out in PlanWorkflowExec but not with SupplierWorkflowExec ?? Why??
                    PlanWorkflow(wfable, workflowNodes[i].Id, comments, ref errmsg, ref url);
                }
            }
        }
        #endregion Workflow Node Action

    }
}
