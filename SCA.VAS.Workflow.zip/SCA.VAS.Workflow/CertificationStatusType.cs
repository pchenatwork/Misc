#region Copyright (C) 2006 - 2007 SCA.VAS USA, Inc.
///==========================================================================
/// Copyright (C) 2006 SCA.VAS USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of CertificationStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(CertificationStatusConverter))]
    public class CertificationStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly CertificationStatusType NewCertification = new CertificationStatusType(0, "NewCertification", "New Certification");
        public static readonly CertificationStatusType CertAppSubmitted = new CertificationStatusType(1, "CertAppSubmitted", "Certification Submitted");
        public static readonly CertificationStatusType CertAnalystReviewed = new CertificationStatusType(2, "CertAnalystReviewed", "Certification Analyst Reviewed");
        public static readonly CertificationStatusType RequestMoreCertInfoPending = new CertificationStatusType(3, "RequestMoreCertInfoPending", "Request More Certification Info Pending");
        public static readonly CertificationStatusType RequestMoreCertInfo = new CertificationStatusType(4, "RequestMoreCertInfo", "Request More Certification Info");
        public static readonly CertificationStatusType AdditionalCertInfoSubmitted = new CertificationStatusType(5, "AdditionalCertInfoSubmitted", "Additional Certification Info Submitted");
        public static readonly CertificationStatusType MWBEReviewed = new CertificationStatusType(6, "MWBEReviewed", "MWBE Reviewed");
        public static readonly CertificationStatusType LBEReviewed = new CertificationStatusType(7, "LBEReviewed", "LBE Reviewed");
        public static readonly CertificationStatusType CertAnalystApproved = new CertificationStatusType(8, "CertAnalystApproved", "Certification Analyst Recommended");
        public static readonly CertificationStatusType DirectorApprovalPending = new CertificationStatusType(9, "DirectorApprovalPending", "Director Review Pending");
        public static readonly CertificationStatusType DirectorApproved = new CertificationStatusType(10, "DirectorApproved", "Director Reviewed");
        public static readonly CertificationStatusType Certified = new CertificationStatusType(11, "Certified", "Certified");
        public static readonly CertificationStatusType CertAnalystClosed = new CertificationStatusType(12, "CertAnalystClosed", "Certification Analyst Closed");
        public static readonly CertificationStatusType CertClosed = new CertificationStatusType(13, "CertClosed", "Certification Closed");
        public static readonly CertificationStatusType Deny = new CertificationStatusType(14, "Deny", "Deny");
        public static readonly CertificationStatusType Disqualified = new CertificationStatusType(15, "Disqualified", "Disqualified");
        public static readonly CertificationStatusType CertAdminClosed = new CertificationStatusType(16, "CertAdminClosed", "Certification Admin Closed");
        public static readonly CertificationStatusType Withdrawn = new CertificationStatusType(17, "Withdrawn", "Withdrawn");
        public static readonly CertificationStatusType Rescinded = new CertificationStatusType(18, "Rescinded", "Rescinded");
        public static readonly CertificationStatusType Suspended = new CertificationStatusType(19, "Suspended", "Suspended");
        public static readonly CertificationStatusType Decertified = new CertificationStatusType(20, "Decertified", "Decertified");
        public static readonly CertificationStatusType RequestMoreCertInfo2 = new CertificationStatusType(21, "RequestMoreCertInfo2", "Request More Certification Info 2");
        public static readonly CertificationStatusType AdditionalCertInfoSubmitted2 = new CertificationStatusType(22, "AdditionalCertInfoSubmitted2", "Additional Certification Info Submitted 2");
        public static readonly CertificationStatusType CertAnalystAssigned = new CertificationStatusType(23, "CertAnalystAssigned", "Certification Analyst Assigned");
        public static readonly CertificationStatusType Expired = new CertificationStatusType(24, "Expired", "Expired");
        public static readonly CertificationStatusType Archived = new CertificationStatusType(25, "Archived", "Archived");
        public static readonly CertificationStatusType ConditionallyCertified = new CertificationStatusType(26, "ConditionallyCertified", "Conditionally Certified");
        // TFS *** 1275
        public static readonly CertificationStatusType AppendixAPending = new CertificationStatusType(27, "AppendixAPending", "Appendix A Pending");
        public static readonly CertificationStatusType Ineligible = new CertificationStatusType(28, "Ineligible", "Ineligible");

        //Certification Appeal Process
        public static readonly CertificationStatusType CertificationAppeal = new CertificationStatusType(29, "Appeal Submitted", "Appeal Submitted");
        public static readonly CertificationStatusType GeneralCounselRecommended = new CertificationStatusType(30, "GeneralCounselRecommended", "General Counsel Recommended");

        public static readonly CertificationStatusType SupervisorRecommend = new CertificationStatusType(31, "Supervisor Appeal Recommended", "Supervisor Appeal Recommended");
        public static readonly CertificationStatusType SupervisorReInterview = new CertificationStatusType(32, "Supervisor Appeal Re-Interviewed", "Supervisor Appeal Re-Interviewed");
        public static readonly CertificationStatusType CertificationPending = new CertificationStatusType(33, "Certification Final Review Pending", "Certification Final Review Pending");

        //TFS ***1890 New Reject Status
        public static readonly CertificationStatusType Rejected = new CertificationStatusType(34, "Rejected", "Rejected");
        #endregion

        #region Constructors
        public CertificationStatusType()
        {
        }

        private CertificationStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in CertificationStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of CertificationStatus.  
        /// </summary>
        public static CertificationStatusType Default
        {
            get
            {
                return (CertificationStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for CertificationStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((CertificationStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a CertificationStatus object.
        /// It allows a string to be assigned to a CertificationStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator CertificationStatusType(int id)
        {
            return (CertificationStatusType)EnumerationBase.FindById(id, CertificationStatusType._list);
        }
        public static implicit operator CertificationStatusType(string name)
        {
            for (int i = 0; i < CertificationStatusType._list.Count; i++)
            {
                if (((CertificationStatusType)CertificationStatusType._list[i]).Name == name)
                    return (CertificationStatusType)CertificationStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and CertificationStatus objects.
    /// It's very useful when binding CertificationStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class CertificationStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, CertificationStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the CertificationStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < CertificationStatusType._list.Count; i++)
            {
                list.Add(((CertificationStatusType)CertificationStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
