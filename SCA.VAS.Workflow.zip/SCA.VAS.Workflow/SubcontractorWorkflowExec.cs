#region Copyright
/*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Configuration;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.Supplier.Subcontractor.Utilities;
using SCA.VAS.BusinessLogic.Supplier.Subcontractor;
using SCA.VAS.ValueObjects.Supplier.Subcontractor;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

namespace SCA.VAS.Workflow
{
    public class SubcontractorWorkflowExec
    {
        #region Private Member
        private static int userId = 0;
        private static string prefixDbName = string.Empty;
        private static string workflowType = ConstantUtility.WORKFLOW_SUBCONTRACTOR;
        public static string WorkflowType
        {
            set { workflowType = value; }
        }
        #endregion

        #region Constructor
        public SubcontractorWorkflowExec()
        {
        }
        static SubcontractorWorkflowExec()
        {
        }
        #endregion Constructor

        #region Private Method
        private static int GetTransactionId(Subcontractor subcontractor, string comments)
        {
            if (subcontractor.TransactionId == 0)
            {
                subcontractor.TransactionId = WorkflowExec.CreateWorkflowHistory(subcontractor.WorkflowId);
                SubcontractorUtility.UpdateTransactionId(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                    subcontractor.Id, subcontractor.TransactionId);
            }
            return subcontractor.TransactionId;
        }
        #endregion Private Method

        #region Public Method
        public static User GetLastApprover(Subcontractor subcontractor)
        {
            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(subcontractor.TransactionId);
            if (workflowHistory == null) return null;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return null;

            return UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, workflowHistory.CreatedBy);
        }

        public static DateTime GetLastApproveDate(Subcontractor subcontractor)
        {
            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(subcontractor.TransactionId);
            if (workflowHistory == null) return DateTime.MinValue;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return DateTime.MinValue;

            return workflowHistory.DateCreated;
        }
        #endregion Public Method

        #region Workflow Control
        public static int SubcontractorWorkflow(Subcontractor subcontractor, string systemAction, string comments, ref string errmsg, ref string url)
        {
            int transactionId = GetTransactionId(subcontractor, comments);

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_SYSTEMNAME,
                new object[] { subcontractor.WorkflowId, systemAction });
            if (workflowNodes == null || workflowNodes.Count == 0) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(subcontractor.TransactionId);
            if (workflowHistory == null)
                return 0;

            int actionId = 0;
            for (int i = 0; i < workflowNodes.Count; i++)
            {
                if (workflowHistory.CurrentNodeId == workflowNodes[i].NodeFromId)
                {
                    actionId = workflowNodes[i].Id;
                    break;
                }
            }
            return SubcontractorWorkflow(subcontractor, actionId, comments, ref errmsg, ref url);
        }

        public static int SubcontractorWorkflow(Subcontractor subcontractor, int actionId, string comments, ref string errmsg, ref string url)
        {
            int transactionId = GetTransactionId(subcontractor, comments);
            if (actionId == 0) return transactionId;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(subcontractor.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowNode workflowNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
            if (workflowHistory.CurrentNodeId != workflowNode.NodeFromId)
                return 0;

            // condition proccessing
            errmsg = string.Empty;
            WorkflowConditionCollection workflowConditions = SubcontractorConditionTest(subcontractor, workflowNode.Id);
            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    if (workflowCondition.Status == 0)
                    {
                        errmsg += workflowCondition.ErrorMessage + "<br />";
                    }
                }
            }
            if (errmsg != string.Empty) return 0;

            //Workflow topologic
            bool approval = true;
            switch (workflowNode.Action1)
            {
                case "One":
                    break;
                case "Owner":
                    break;
                case "All":
                case "Majority":
                case "Count":
                    WorkflowHistoryCollection workflowHistories = WorkflowHistoryUtility.FindByCriteria(
                        ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                        new object[] { subcontractor.TransactionId });

                    WorkflowHistoryCollection currentHistories = new WorkflowHistoryCollection();
                    if (workflowHistories != null)
                    {
                        for (int i = workflowHistories.Count - 1; i >= 0; i--)
                        {
                            if (workflowHistories[i].IsActive == 1) break;
                            if (workflowHistories[i].CurrentNodeId != actionId) continue;
                            if (workflowHistories[i].ApprovalUserId == userId)
                            {
                                errmsg = "You already approved this step!";
                                return 0;
                            }
                            currentHistories.Add(workflowHistories[i]);
                        }
                    }

                    // Create a history from new approval
                    WorkflowHistory approvalHistory = WorkflowHistoryUtility.CreateObject();
                    approvalHistory.TransactionHeaderId = subcontractor.TransactionId;
                    approvalHistory.WorkflowId = subcontractor.WorkflowId;
                    approvalHistory.CurrentNodeId = actionId;
                    approvalHistory.ApprovalUserId = WorkflowExec.GetUserId();
                    approvalHistory.ApprovalConditionId = 1;
                    approvalHistory.CreatedBy = workflowHistory.ApprovalUserId;
                    approvalHistory.CreatedType = WorkflowExec.GetUserType();
                    WorkflowHistoryUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, approvalHistory);

                    int approvalKnt = currentHistories.Count + 1;
                    switch (workflowNode.Action1)
                    {
                        case "All":
                            //if (approvalKnt < subcontractorUsers.Count)
                            //    approval = false;
                            break;
                        case "Majority":
                            //if (approvalKnt < subcontractorUsers.Count / 2)
                            //    approval = false;
                            break;
                        case "Count":
                            int knt = ConvertUtility.ConvertInt(workflowNode.Action2);
                            if (approvalKnt < knt)
                                approval = false;
                            break;
                    }
                    break;

                //case "Sequence":
                //    break;
                //case "Timer":
                //    //approve7.Checked = true;
                //    //approveKnt7.Text = workflowNode.Action2;
                //    break;
            }

            if (!approval || errmsg != string.Empty) return subcontractor.TransactionId;

            //Action proccessing
            WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE,
                new object[] { workflowNode.Id });

            if (workflowActions != null)
            {
                foreach (WorkflowAction workflowAction in workflowActions)
                {
                    switch (workflowAction.Type)
                    {
                        //Send Email
                        case 1:
                            CommonUtility.SubcontractorSendEmail(subcontractor, workflowHistory, workflowAction.FunctionName, comments);
                            break;

                        //Action
                        case 2:
                            SubcontractorAction(subcontractor, workflowAction.FunctionName);
                            break;

                        //Redirect page
                        case 3:
                            url = workflowAction.FunctionName;
                            break;
                    }
                }
            }

            if (workflowNode.NodeToId > 0)
            {
                WorkflowNode nextNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode.NodeToId);
                WorkflowExec.WorkflowNextStatus(workflowNode.WorkflowId, nextNode.Name, workflowHistory.CurrentNodeId, subcontractor.TransactionId, comments);
                NodeAction(subcontractor, comments);
            }

            return subcontractor.TransactionId;
        }

        public static int SubcontractorWorkflow(Subcontractor subcontractor, string nextStatus, string comments)
        {
            int transactionId = GetTransactionId(subcontractor, comments);

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(subcontractor.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowExec.WorkflowNextSystemStatus(subcontractor.WorkflowId, nextStatus, workflowHistory.CurrentNodeId, subcontractor.TransactionId, comments);
            NodeAction(subcontractor, comments);

            return subcontractor.TransactionId;
        }

        public static WorkflowConditionCollection SubcontractorConditionTest(Subcontractor subcontractor, int workflowNodeId)
        {
            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNodeId });

            XPathDocument doc = new XPathDocument(XmlUtility.Serialize(subcontractor));
            XPathNavigator nav = doc.CreateNavigator();

            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count > 0)
                        workflowCondition.Status = 1;
                }
            }
            return workflowConditions;
        }
        #endregion Workflow Control

        #region Workflow Node Action
        private static void NodeAction(Subcontractor subcontractor, string comments)
        {
            int transactionId = GetTransactionId(subcontractor, comments);

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(
                subcontractor.TransactionId);

            int status = -1;
            string statusName = string.Empty;
            SubcontractorStatusType subcontractorStatusType = workflowHistory.CurrentNode.Action6.Trim();
            if (subcontractorStatusType != null)
            {
                status = subcontractorStatusType.Id;
                statusName = subcontractorStatusType.Description;
            }
            if (status == -1 || status == subcontractor.Status) return;

            if (SubcontractorUtility.UpdateStatus(ConstantUtility.SUPPLIER_DATASOURCE_NAME, subcontractor.Id, status, statusName))
                subcontractor.Status = status;

            // automatic step
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { subcontractor.WorkflowId, "UserStepId", "ASC" });
            if (workflowNodes != null)
            {
                for (int i = 0; i < workflowNodes.Count; i++)
                {
                    if (workflowNodes[i].Type != 1 || workflowNodes[i].TimeToSkip != 1 ||
                        workflowHistory.CurrentNodeId != workflowNodes[i].NodeFromId)
                        continue;

                    string errmsg = string.Empty;
                    string url = string.Empty;
                    SubcontractorWorkflow(subcontractor, workflowNodes[i].Id, comments, ref errmsg, ref url);
                }
            }
        }
        #endregion Workflow Node Action

        #region Batch Jobs
        #endregion Batch Jobs

        #region Subcontractor Action
        private static void SubcontractorAction(Subcontractor subcontractor, string actionName)
        {
            string msg = string.Empty;
            string url = string.Empty;
            switch (actionName)
            {
                case "WillisAppoveAction":
                    User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());
                    SubcontractorUtility.UpdateByType(ConstantUtility.SUPPLIER_DATASOURCE_NAME, subcontractor.Id, "Willis Approve Action", 0, user != null ? user.UserName : string.Empty);
                    break;
                case "ManagerPendingAction":
                    if (CommonUtility.GetSubcontractorProperty("property21", subcontractor.SubcontractorProperties).PropertyText == "Approve")
                    {
                        SubcontractorWorkflowExec.SubcontractorWorkflow(subcontractor, SCA.VAS.Workflow.SubcontractorAction.SubManagerFinalApprove.Name, "", ref msg, ref url);
                        SubcontractorWorkflowExec.SubcontractorWorkflow(subcontractor, SCA.VAS.Workflow.SubcontractorAction.SubManagerFinalApprove2.Name, "", ref msg, ref url);
                    }
                    if (CommonUtility.GetSubcontractorProperty("property21", subcontractor.SubcontractorProperties).PropertyText == "Pending")
                    {
                        SubcontractorWorkflowExec.SubcontractorWorkflow(subcontractor, SCA.VAS.Workflow.SubcontractorAction.SubPendingAction.Name, "", ref msg, ref url);
                    }
                    break;
                case "CheckRS1Finished":

                    if (subcontractor.ContractNo != "" || subcontractor.SolicitNo == "") break; //Not part of a project workflow process

                    List<Extra> searchItems = new List<Extra>();
                    Extra extraItem = new Extra();
                    extraItem.Name = "SolicitNo";
                    extraItem.Value = subcontractor.SolicitNo;
                    searchItems.Add(extraItem);
                    extraItem = new Extra();
                    extraItem.Name = "SolicitSeq";
                    extraItem.Value = "Max";
                    searchItems.Add(extraItem);
                    string extraXml = XmlUtility.ToXml(searchItems);


                    ProjectCollection projects = ProjectUtility.FindByCriteria(
                        ConstantUtility.RFD_DATASOURCE_NAME,
                        ProjectManager.SEARCH_PROJECT,
                        new object[] 
				        {
					        0,0,"","",
					        0,
                            -1,
					        extraXml
				        });

                    if (projects != null && projects.Count > 0)
                    {
                        searchItems = new List<Extra>
                        {
                            new Extra {Name = "CreateSupplierId", Value = projects[0].AwardSupplierId.ToString()}
                        };

                        extraXml = XmlUtility.ToXml(searchItems);

                        var subcontractors = SubcontractorUtility.FindByCriteria(
                            ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                            SubcontractorManager.SEARCH_SUBCONTRACTOR,
                            new object[]
                               {
                                         0,0,"","",
                                         "",
                                         subcontractor.SolicitNo,
                                         "",
                                         "RS-1",
                                         "",
                                         "",
                                         "",
                                         "",
                                         new DateTime(1900, 1,1),
                                         new DateTime(1900, 1,1),
                                         -1,
                                         0,
                                         extraXml
                               });

                        if (subcontractors == null) break;

                        bool finished = true;
                        bool remediated = false;

                        var bidderWicks = BidderWicksUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME,
                                    BidderWicksManager.FIND_BY_BIDDER, new object[] { projects[0].AwardBidderId });

                        var currentWickSupplierIds = new List<Tuple<int,string>>{
                                                        Tuple.Create( bidderWicks[0].ElectricalSupplierId, "Electrical"),
                                                        Tuple.Create( bidderWicks[0].PlumbingSupplierId, "Plumbing") ,
                                                        Tuple.Create( bidderWicks[0].HVACSupplierId, "HVAC") 
                                                  };

                        foreach (Subcontractor sub in subcontractors)
                        {
                            if(currentWickSupplierIds.Contains(Tuple.Create(sub.SupplierId, sub.WorkDescription)))
                            {
                                finished &= sub.Status == SubcontractorStatusType.SubCQUApproved;
                                remediated |= sub.Status == SubcontractorStatusType.SubDeny;
                            }
                        }

                        if (!finished && !remediated) break; //not all rs1's are SubInsurancePending or deny

                        if (finished)
                        {
                            ProjectWorkflowExec.WorkflowType = ConstantUtility.WORKFLOW_RS1_VETTING;
                            ProjectWorkflowExec.ProjectWorkflow(projects[0], ProjectRS1VettingStatusType.RS1VettingFinished.Name, "");

                            break;
                        }

                       //  otherwise Remediated
                            ProjectWorkflowExec.WorkflowType = ConstantUtility.WORKFLOW_RS1_VETTING;
                            ProjectWorkflowExec.ProjectWorkflow(projects[0], ProjectRS1VettingStatusType.RS1VettingRemediate.Name, "");
                    }

                    break;
            }
        }
        #endregion
    }
}
