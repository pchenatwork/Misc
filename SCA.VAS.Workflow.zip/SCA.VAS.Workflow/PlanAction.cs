#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of PlanAction:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(PlanActionConverter))]
    public class PlanAction : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly PlanAction SubmitPlan = new PlanAction(1, "SubmitPlan", "Submit Plan");
        public static readonly PlanAction WaiverRequest = new PlanAction(2, "WaiverRequest", "Waiver Request");

        public static readonly PlanAction AnaystWaiverReview = new PlanAction(3, "AnaystWaiverReview", "Anayst Waiver Review");
        public static readonly PlanAction ManagerWaiverReview = new PlanAction(4, "ManagerWaiverReview", "Manager Waiver Review");  
        public static readonly PlanAction DirectorWaiverReview = new PlanAction(6, "DirectorWaiverReview", "Director Waiver Review");
        public static readonly PlanAction WaiverMoreInfo = new PlanAction(7, "WaiverMoreInfo", "Waiver More Info");
        public static readonly PlanAction WaiverInfoSubmit = new PlanAction(8, "WaiverInfoSubmit", "Waiver Info Submit");

        public static readonly PlanAction AnalystApprove = new PlanAction(9, "AnalystApprove", "Analyst Approve");
        public static readonly PlanAction AnalystReject = new PlanAction(10, "AnalystReject", "Analyst Reject");
        public static readonly PlanAction ManagerReview = new PlanAction(11, "ManagerReview", "Manager Review");

        public static readonly PlanAction RejectPlan = new PlanAction(11, "RejectPlan", "Reject Plan");

        public static readonly PlanAction ReSubmitPlan = new PlanAction(12, "ReSubmitPlan", "ReSubmit Plan");
        public static readonly PlanAction ReWaiverRequest = new PlanAction(13, "ReWaiverRequest", "ReWaiver Request");

        public static readonly PlanAction Monitoring1 = new PlanAction(14, "Monitoring1", "Monitoring1");
        public static readonly PlanAction Monitoring2 = new PlanAction(15, "Monitoring2", "Monitoring2");

        public static readonly PlanAction DirectorCommitmentReview1 = new PlanAction(16, "DirectorCommitmentReview1", "Director Commitment Review1");
        public static readonly PlanAction DirectorCommitmentReview2 = new PlanAction(17, "DirectorCommitmentReview2", "Director Commitment Review2");
        public static readonly PlanAction SrDirectorCommitmentReview1 = new PlanAction(18, "SrDirectorCommitmentReview1", "Sr Director Commitment Review1");
        public static readonly PlanAction SrDirectorCommitmentReview2 = new PlanAction(19, "SrDirectorCommitmentReview2", "Sr Director Commitment Review2");
        public static readonly PlanAction AnalystCommitmentCloseOut = new PlanAction(21, "AnalystCommitmentCloseOut", "Analyst Commitment Close Out");
        public static readonly PlanAction VPCommitmentReview = new PlanAction(20, "VPCommitmentReview", "VP Commitment Review");

        // PCHEN 202004: Added for Professional/Serive contract SUP
        public static readonly PlanAction DirectorCommitmentReview3 = new PlanAction(22, "DirectorCommitmentReview3", "Director Commitment Review Closeout");
        public static readonly PlanAction AnalystCommitmentReview1 = new PlanAction(23, "AnalystCommitmentReview1", "Analyst Commitment Review 1");

        //Supplier Monitoring Action
        public static readonly PlanAction SubmitSupplierMonitoring = new PlanAction(51, "SubmitSupplierMonitoring", "Submit Supplier Monitoring");

        public static readonly PlanAction SupplierMonitoringAnalystReview = new PlanAction(52, "SupplierMonitoringAnalystReview", "Supplier Monitoring Analyst Review");
        public static readonly PlanAction SupplierMonitoringManagerReview = new PlanAction(53, "SupplierMonitoringManagerReview", "Supplier Monitoring Manager Review");  
        public static readonly PlanAction SupplierMonitoringDirectorReview = new PlanAction(54, "SupplierMonitoringDirectorReview", "Supplier Monitoring Director Review");

        public static readonly PlanAction SupplierMonitoringMoreInfo = new PlanAction(55, "SupplierMonitoringMoreInfo", "Supplier Monitoring More Info");
        public static readonly PlanAction SupplierMonitoringInfoSubmit = new PlanAction(56, "SupplierMonitoringInfoSubmit", "Supplier Monitoring Info Submit");
        

        public static readonly PlanAction RejectSupplierMonitoring = new PlanAction(57, "RejectSupplierMonitoring", "Reject Supplier Monitoring");
        public static readonly PlanAction AdministrativeClosed = new PlanAction(58, "AdministrativeClosed", "AdministrativeClosed");
      
        #endregion

        #region Constructors
        public PlanAction()
        {
        }

        private PlanAction(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in PlanAction class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of PlanAction.  
        /// </summary>
        public static PlanAction Default
        {
            get
            {
                return (PlanAction)_list[0];
            }
        }
        #endregion/

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for PlanAction class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a PlanAction object.
        /// It allows a string to be assigned to a PlanAction object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator PlanAction(int id)
        {
            return (PlanAction)EnumerationBase.FindById(id, PlanAction._list);
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and PlanAction objects.
    /// It's very useful when binding PlanAction objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class PlanActionConverter : TypeConverter
    {

        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, PlanAction._list);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the PlanAction enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < PlanAction._list.Count; i++)
            {
                list.Add(((PlanAction)PlanAction._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
