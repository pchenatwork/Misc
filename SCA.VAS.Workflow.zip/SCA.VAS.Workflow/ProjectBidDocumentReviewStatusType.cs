#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ProjectBidDocumentReviewStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ProjectBidDocumentReviewStatusConverter))]
    public class ProjectBidDocumentReviewStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly ProjectBidDocumentReviewStatusType NewPrequalification = new ProjectBidDocumentReviewStatusType(0, "NewPrequalification", "New Qualification");
        public static readonly ProjectBidDocumentReviewStatusType ApplicationSubmitted = new ProjectBidDocumentReviewStatusType(1, "ApplicationSubmitted", "Application Submitted");
        public static readonly ProjectBidDocumentReviewStatusType ManagerReviewed = new ProjectBidDocumentReviewStatusType(2, "ManagerReviewed", "Manager Reviewed");
        public static readonly ProjectBidDocumentReviewStatusType ReviewerReviewed = new ProjectBidDocumentReviewStatusType(3, "ReviewerReviewed", "Reviewer Reviewed");
        public static readonly ProjectBidDocumentReviewStatusType RequestMoreInfoPending = new ProjectBidDocumentReviewStatusType(4, "RequestMoreInfoPending", "Request More Info Pending");
        public static readonly ProjectBidDocumentReviewStatusType RequestMoreInfo = new ProjectBidDocumentReviewStatusType(5, "RequestMoreInfo", "Request More Info");
        public static readonly ProjectBidDocumentReviewStatusType AdditionalInfoSubmitted = new ProjectBidDocumentReviewStatusType(6, "AdditionalInfoSubmitted", "Additional Info Submitted");
        public static readonly ProjectBidDocumentReviewStatusType ReferenceReviewed = new ProjectBidDocumentReviewStatusType(7, "ReferenceReviewed", "Reference Reviewed");
        public static readonly ProjectBidDocumentReviewStatusType FinacialReviewed = new ProjectBidDocumentReviewStatusType(8, "FinacialReviewed", "Financial Reviewed");
        public static readonly ProjectBidDocumentReviewStatusType AllReviewed = new ProjectBidDocumentReviewStatusType(9, "AllReviewed", "Reference and Financial Reviewed");
        public static readonly ProjectBidDocumentReviewStatusType OIGApproved = new ProjectBidDocumentReviewStatusType(10, "OIGApproved", "OIG Approved");
        public static readonly ProjectBidDocumentReviewStatusType QualifiedPending = new ProjectBidDocumentReviewStatusType(11, "QualifiedPending", "Qualified Pending");
        public static readonly ProjectBidDocumentReviewStatusType Qualified = new ProjectBidDocumentReviewStatusType(12, "Qualified", "Qualified");
        public static readonly ProjectBidDocumentReviewStatusType PreDeny = new ProjectBidDocumentReviewStatusType(13, "PreDeny", "PreDeny");
        public static readonly ProjectBidDocumentReviewStatusType AdministrativelyClosed = new ProjectBidDocumentReviewStatusType(14, "AdministrativelyClosed", "Administratively Closed");
        public static readonly ProjectBidDocumentReviewStatusType DirectorClosePending = new ProjectBidDocumentReviewStatusType(15, "DirectorClosePending", "Director Close Pending");
        public static readonly ProjectBidDocumentReviewStatusType DirectorClosed = new ProjectBidDocumentReviewStatusType(16, "DirectorClosed", "Director Closed");
        public static readonly ProjectBidDocumentReviewStatusType Inactive = new ProjectBidDocumentReviewStatusType(17, "Inactive", "Inactive");
        public static readonly ProjectBidDocumentReviewStatusType Disqualified = new ProjectBidDocumentReviewStatusType(18, "Disqualified", "Disqualified");
        public static readonly ProjectBidDocumentReviewStatusType Withdrawn = new ProjectBidDocumentReviewStatusType(19, "Withdrawn", "Withdrawn");
        public static readonly ProjectBidDocumentReviewStatusType OIGReviewed = new ProjectBidDocumentReviewStatusType(20, "OIGReviewed", "OIG Reviewed");
        public static readonly ProjectBidDocumentReviewStatusType Rescinded = new ProjectBidDocumentReviewStatusType(21, "Rescinded", "Rescinded");
        public static readonly ProjectBidDocumentReviewStatusType Suspended = new ProjectBidDocumentReviewStatusType(22, "Suspended", "Suspended");
        public static readonly ProjectBidDocumentReviewStatusType RequestMoreInfo2 = new ProjectBidDocumentReviewStatusType(23, "RequestMoreInfo2", "Request More Info 2");
        public static readonly ProjectBidDocumentReviewStatusType AdditionalInfoSubmitted2 = new ProjectBidDocumentReviewStatusType(24, "AdditionalInfoSubmitted2", "Additional Info Submitted 2");
        public static readonly ProjectBidDocumentReviewStatusType Deny = new ProjectBidDocumentReviewStatusType(25, "Deny", "Deny");
        public static readonly ProjectBidDocumentReviewStatusType Expired = new ProjectBidDocumentReviewStatusType(26, "Expired", "Expired");
        public static readonly ProjectBidDocumentReviewStatusType OIGPending = new ProjectBidDocumentReviewStatusType(27, "OIGPending", "OIG Pending");
        #endregion

        #region Constructors
        public ProjectBidDocumentReviewStatusType()
        {
        }

        private ProjectBidDocumentReviewStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectBidDocumentReviewStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ProjectBidDocumentReviewStatus.  
        /// </summary>
        public static ProjectBidDocumentReviewStatusType Default
        {
            get
            {
                return (ProjectBidDocumentReviewStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectBidDocumentReviewStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((ProjectBidDocumentReviewStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectBidDocumentReviewStatus object.
        /// It allows a string to be assigned to a ProjectBidDocumentReviewStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ProjectBidDocumentReviewStatusType(int id)
        {
            return (ProjectBidDocumentReviewStatusType)EnumerationBase.FindById(id, ProjectBidDocumentReviewStatusType._list);
        }
        public static implicit operator ProjectBidDocumentReviewStatusType(string name)
        {
            for (int i = 0; i < ProjectBidDocumentReviewStatusType._list.Count; i++)
            {
                if (((ProjectBidDocumentReviewStatusType)ProjectBidDocumentReviewStatusType._list[i]).Description == name)
                    return (ProjectBidDocumentReviewStatusType)ProjectBidDocumentReviewStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectBidDocumentReviewStatus objects.
    /// It's very useful when binding ProjectBidDocumentReviewStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ProjectBidDocumentReviewStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ProjectBidDocumentReviewStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectBidDocumentReviewStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ProjectBidDocumentReviewStatusType._list.Count; i++)
            {
                list.Add(((ProjectBidDocumentReviewStatusType)ProjectBidDocumentReviewStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
