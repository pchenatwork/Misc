#region Copyright
/*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Configuration;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Scorecard.Utilities;
using SCA.VAS.BusinessLogic.Scorecard;
using SCA.VAS.ValueObjects.Scorecard;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

namespace SCA.VAS.Workflow
{
    public class EvaluationWorkflowExec
    {
        #region Private Member
        private static int userId = 0;
        #endregion

        #region Constructor
        public EvaluationWorkflowExec()
        {
        }
        static EvaluationWorkflowExec()
        {
        }
        #endregion Constructor

        #region Private Method
        private static int GetTransactionId(ScorecardInvitee scorecardInvitee, string comments)
        {
            if (scorecardInvitee.TransactionId == 0)
            {
                scorecardInvitee.TransactionId = WorkflowExec.CreateWorkflowHistory(scorecardInvitee.WorkflowId);
                ScorecardInviteeUtility.UpdateTransactionId(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                    scorecardInvitee.Id, scorecardInvitee.TransactionId);
            }
            return scorecardInvitee.TransactionId;
        }
        #endregion Private Method

        #region Public Method
        public static User GetLastApprover(ScorecardInvitee scorecardInvitee)
        {
            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(scorecardInvitee.TransactionId);
            if (workflowHistory == null) return null;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return null;

            return UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, workflowHistory.CreatedBy);
        }
        #endregion Public Method

        #region Workflow Control
        public static int EvaluationWorkflow(ScorecardInvitee scorecardInvitee, string systemAction, string comments, ref string errmsg, ref string url)
        {
            int transactionId = GetTransactionId(scorecardInvitee, comments);

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_SYSTEMNAME,
                new object[] { scorecardInvitee.WorkflowId, systemAction });
            if (workflowNodes == null || workflowNodes.Count == 0) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(scorecardInvitee.TransactionId);
            if (workflowHistory == null)
                return 0;

            int actionId = 0;
            for (int i = 0; i < workflowNodes.Count; i++)
            {
                if (workflowHistory.CurrentNodeId == workflowNodes[i].NodeFromId)
                {
                    actionId = workflowNodes[i].Id;
                    break;
                }
            }
            return EvaluationWorkflow(scorecardInvitee, actionId, comments, ref errmsg, ref url);
        }

        public static int EvaluationWorkflow(ScorecardInvitee scorecardInvitee, int actionId, string comments, ref string errmsg, ref string url)
        {
            int transactionId = GetTransactionId(scorecardInvitee, comments);
            if (actionId == 0) return transactionId;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(scorecardInvitee.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowNode workflowNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
            if (workflowHistory.CurrentNodeId != workflowNode.NodeFromId)
                return 0;

            // condition proccessing
            errmsg = string.Empty;
            WorkflowConditionCollection workflowConditions = EvaluationConditionTest(scorecardInvitee, workflowNode.Id);
            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    if (workflowCondition.Status == 0)
                    {
                        errmsg += workflowCondition.ErrorMessage + "<br />";
                    }
                }
            }
            if (errmsg != string.Empty) return 0;

            //Workflow topologic
            bool approval = true;
            switch (workflowNode.Action1)
            {
                case "One":
                    break;
                case "Owner":
                    break;
                case "All":
                case "Majority":
                case "Count":
                    WorkflowHistoryCollection workflowHistories = WorkflowHistoryUtility.FindByCriteria(
                        ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                        new object[] { scorecardInvitee.TransactionId });

                    WorkflowHistoryCollection currentHistories = new WorkflowHistoryCollection();
                    if (workflowHistories != null)
                    {
                        for (int i = workflowHistories.Count - 1; i >= 0; i--)
                        {
                            if (workflowHistories[i].IsActive == 1) break;
                            if (workflowHistories[i].CurrentNodeId != actionId) continue;
                            if (workflowHistories[i].ApprovalUserId == userId)
                            {
                                errmsg = "You already approved this step!";
                                return 0;
                            }
                            currentHistories.Add(workflowHistories[i]);
                        }
                    }

                    // Create a history from new approval
                    WorkflowHistory approvalHistory = WorkflowHistoryUtility.CreateObject();
                    approvalHistory.TransactionHeaderId = scorecardInvitee.TransactionId;
                    approvalHistory.WorkflowId = scorecardInvitee.WorkflowId;
                    approvalHistory.CurrentNodeId = actionId;
                    approvalHistory.ApprovalUserId = WorkflowExec.GetUserId();
                    approvalHistory.ApprovalConditionId = 1;
                    approvalHistory.CreatedBy = workflowHistory.ApprovalUserId;
                    approvalHistory.CreatedType = WorkflowExec.GetUserType();
                    WorkflowHistoryUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, approvalHistory);

                    int approvalKnt = currentHistories.Count + 1;
                    switch (workflowNode.Action1)
                    {
                        case "All":
                            //if (scorecard.Invitees != null && approvalKnt < scorecard.Invitees.Count)
                            //    approval = false;
                            break;
                        case "Majority":
                            //if (approvalKnt < scorecardUsers.Count / 2)
                            //    approval = false;
                            break;
                        case "Count":
                            int knt = ConvertUtility.ConvertInt(workflowNode.Action2);
                            if (approvalKnt < knt)
                                approval = false;
                            break;
                    }
                    break;

                //case "Sequence":
                //    break;
                //case "Timer":
                //    //approve7.Checked = true;
                //    //approveKnt7.Text = workflowNode.Action2;
                //    break;
            }

            if (!approval || errmsg != string.Empty) return scorecardInvitee.TransactionId;

            //Action proccessing
            WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE,
                new object[] { workflowNode.Id });

            if (workflowActions != null)
            {
                foreach (WorkflowAction workflowAction in workflowActions)
                {
                    switch (workflowAction.Type)
                    {
                        //Send Email
                        case 1:
                            CommonUtility.EvaluationSendEmail(scorecardInvitee, workflowNode, workflowHistory, workflowAction.FunctionName, comments);
                            break;

                        //Action
                        case 2:
                            EvaluationAction(scorecardInvitee, workflowAction.FunctionName);
                            break;

                        //Redirect page
                        case 3:
                            url = workflowAction.FunctionName;
                            break;
                    }
                }
            }

            if (workflowNode.NodeToId > 0)
            {
                WorkflowNode nextNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode.NodeToId);
                WorkflowExec.WorkflowNextStatus(workflowNode.WorkflowId, nextNode.Name, workflowHistory.CurrentNodeId, scorecardInvitee.TransactionId, comments);
                NodeAction(scorecardInvitee, comments);
            }

            return scorecardInvitee.TransactionId;
        }

        public static int EvaluationWorkflow(ScorecardInvitee scorecardInvitee, string nextStatus, string comments)
        {
            int transactionId = GetTransactionId(scorecardInvitee, comments);

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(scorecardInvitee.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowExec.WorkflowNextSystemStatus(scorecardInvitee.WorkflowId, nextStatus, workflowHistory.CurrentNodeId, scorecardInvitee.TransactionId, comments);
            NodeAction(scorecardInvitee, comments);

            return scorecardInvitee.TransactionId;
        }

        public static WorkflowConditionCollection EvaluationConditionTest(ScorecardInvitee scorecardInvitee, int workflowNodeId)
        {
            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNodeId });

            XPathDocument doc = new XPathDocument(XmlUtility.Serialize(scorecardInvitee));
            XPathNavigator nav = doc.CreateNavigator();

            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count > 0)
                        workflowCondition.Status = 1;
                }
            }
            return workflowConditions;
        }
        #endregion Workflow Control

        #region Workflow Node Action
        private static void NodeAction(ScorecardInvitee scorecardInvitee, string comments)
        {
            int transactionId = GetTransactionId(scorecardInvitee, comments);

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(
                scorecardInvitee.TransactionId);

            int status = 0;
            EvaluationStatusType evaluationStatusType = workflowHistory.CurrentNode.Action6.Trim();
            if (evaluationStatusType != null)
                status = evaluationStatusType.Id;
            if (status == 0 || status == scorecardInvitee.Status) return;

            if (ScorecardInviteeUtility.UpdateStatus(ConstantUtility.SCORECARD_DATASOURCE_NAME, 
                scorecardInvitee.ScorecardId, scorecardInvitee.Id, status))
                scorecardInvitee.Status = status;

            // automatic step
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { scorecardInvitee.WorkflowId, "UserStepId", "ASC" });
            if (workflowNodes != null)
            {
                for (int i = 0; i < workflowNodes.Count; i++)
                {
                    if (workflowNodes[i].Type != 1 || workflowNodes[i].TimeToSkip != 1 ||
                        workflowHistory.CurrentNodeId != workflowNodes[i].NodeFromId)
                        continue;

                    string errmsg = string.Empty;
                    string url = string.Empty;
                    EvaluationWorkflow(scorecardInvitee, workflowNodes[i].Id, comments, ref errmsg, ref url);
                }
            }
        }
        #endregion Workflow Node Action

        #region Batch Jobs
        #endregion Batch Jobs

        #region Evaluation Action
        private static void EvaluationAction(ScorecardInvitee scorecardInvitee, string actionName)
        {
        }
        #endregion
    }
}
