#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ScorecardAction:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ScorecardActionConverter))]
    public class ScorecardAction : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly ScorecardAction ReleaseEvaluation = new ScorecardAction(1, "ReleaseEvaluation", "Release Evaluation");
        public static readonly ScorecardAction SaveProgress = new ScorecardAction(2, "SaveProgress", "Evaluator Save Progress");
        public static readonly ScorecardAction CompleteEvaluation = new ScorecardAction(3, "CompleteEvaluation", "Evaluators Complete Evaluation");
        public static readonly ScorecardAction CSReviewEvaluation = new ScorecardAction(4, "CSReviewEvaluation", "Design Project Manager Review Evaluation");
        public static readonly ScorecardAction DirectorReviewEvaluation = new ScorecardAction(5, "DirectorReviewEvaluation", "Director Review Evaluation");
        public static readonly ScorecardAction DMApproveEvaluation = new ScorecardAction(6, "DMApproveEvaluation", "Design Manager Approve Evaluation");
        public static readonly ScorecardAction DMRejectEvaluation = new ScorecardAction(7, "DMRejectEvaluation", "Design Manager Reject Evaluation");
        public static readonly ScorecardAction DepDirApproveEvaluation = new ScorecardAction(8, "DepDirApproveEvaluation", "Deputy Director Approve Evaluation");
        public static readonly ScorecardAction DepDirRejectEvaluation = new ScorecardAction(9, "DepDirRejectEvaluation", "Deputy Director Reject Evaluation");
        public static readonly ScorecardAction DirectorApproveEvaluation = new ScorecardAction(10, "DirectorApproveEvaluation", "Director Approve Evaluation");
        public static readonly ScorecardAction DirectorRejectEvaluation = new ScorecardAction(11, "DirectorRejectEvaluation", "Director Reject Evaluation");
        public static readonly ScorecardAction LegalApproveEvaluation = new ScorecardAction(12, "LegalApproveEvaluation", "Legal Approve Evaluation");
        public static readonly ScorecardAction LegalRejectEvaluation = new ScorecardAction(13, "LegalRejectEvaluation", "Legal Reject Evaluation");
        public static readonly ScorecardAction CCFUSupervisorApproveEvaluation = new ScorecardAction(14, "CCFUSupervisorApproveEvaluation", "CCFU Supervisor Approve Evaluation");
        public static readonly ScorecardAction CCFUSupervisorRejectEvaluation = new ScorecardAction(15, "CCFUSupervisorRejectEvaluation", "CCFU Supervisor Reject Evaluation");
        public static readonly ScorecardAction CCFUDirectorApproveEvaluation = new ScorecardAction(16, "CCFUDirectorApproveEvaluation", "CCFU Director Approve Evaluation");
        public static readonly ScorecardAction CCFUDirectorRejectEvaluation = new ScorecardAction(17, "CCFUDirectorRejectEvaluation", "CCFU Director Reject Evaluation");
        public static readonly ScorecardAction VPAEApproveEvaluation = new ScorecardAction(18, "VPAEApproveEvaluation", "VP of A&E Approve Evaluation");
        public static readonly ScorecardAction VPAERejectEvaluation = new ScorecardAction(19, "VPAERejectEvaluation", "VP of A&E Reject Evaluation");
        public static readonly ScorecardAction SendInvitationEmail = new ScorecardAction(20, "SendInvitationEmail", "Send Evaluation Invitation Email");
        public static readonly ScorecardAction SendCompletionEmail = new ScorecardAction(21, "SendCompletionEmail", "Send Evaluation Completion Email");
        public static readonly ScorecardAction NotifyConsultant = new ScorecardAction(23, "NotifyConsultant", "Notify Consultant");
        public static readonly ScorecardAction DoNotNotifyConsultant = new ScorecardAction(24, "DoNotNotifyConsultant", "Do Not Notify Consultant");
        public static readonly ScorecardAction SendForLegalReview = new ScorecardAction(25, "SendForLegalReview", "Send For Legal Review");
        public static readonly ScorecardAction SendForVPAEReview = new ScorecardAction(26, "SendForVPAEReview", "Send For VP of A&E Review");
        public static readonly ScorecardAction DMNotifyConsultant = new ScorecardAction(27, "DMNotifyConsultant", "Design Manager Notify Consultant");
        public static readonly ScorecardAction DepDirSendBack = new ScorecardAction(28, "DepDirSendBack", "Deputy Director Send Back");
        public static readonly ScorecardAction VPCMApproveEvaluation = new ScorecardAction(29, "VPCMApproveEvaluation", "VP of CM Approve Evaluation");
        public static readonly ScorecardAction VPCMRejectEvaluation = new ScorecardAction(30, "VPCMRejectEvaluation", "VP of CM Reject Evaluation");
        public static readonly ScorecardAction CPOReviewEvaluation = new ScorecardAction(31, "CPOReviewEvaluation", "Chief Project Officer Review Evaluation");
        public static readonly ScorecardAction CPOApproveEvaluation = new ScorecardAction(32, "CPOApproveEvaluation", "Chief Project Officer Approve Evaluation");
        public static readonly ScorecardAction CPORejectEvaluation = new ScorecardAction(33, "CPORejectEvaluation", "Chief Project Officer Reject Evaluation");
        public static readonly ScorecardAction DMReviewEvaluation = new ScorecardAction(34, "DMReviewEvaluation", "Design Manager Review Evaluation");
        public static readonly ScorecardAction DeputyDirectorReviewEvaluation = new ScorecardAction(35, "DeputyDirectorReviewEvaluation", "Deputy Director Review Evaluation");
        public static readonly ScorecardAction VPAdminApproveEvaluation = new ScorecardAction(36, "VPAdminApproveEvaluation", "VP of Admin Approve Evaluation");
        public static readonly ScorecardAction VPAdminRejectEvaluation = new ScorecardAction(37, "VPAdminRejectEvaluation", "VP of Admin Reject Evaluation");
        public static readonly ScorecardAction CQUApproveEvaluation = new ScorecardAction(38, "CQUApproveEvaluation", "CQU Approve Evaluation");
        public static readonly ScorecardAction CQURejectEvaluation = new ScorecardAction(39, "CQURejectEvaluation", "CQU Reject Evaluation");
        public static readonly ScorecardAction VPCMReviewEvaluation = new ScorecardAction(40, "VPCMReviewEvaluation", "VP of CM Review Evaluation");
        public static readonly ScorecardAction VPAdminReviewEvaluation = new ScorecardAction(41, "VPAdminReviewEvaluation", "VP of Admin Review Evaluation");
        public static readonly ScorecardAction SendConsultantResponse = new ScorecardAction(42, "SendConsultantResponse", "Send Consultant Response");
        public static readonly ScorecardAction HygienistCApproveEvaluation = new ScorecardAction(43, "HygienistCApproveEvaluation", "Hygienist C Approve Evaluation");
        public static readonly ScorecardAction HygienistCRejectEvaluation = new ScorecardAction(44, "HygienistCRejectEvaluation", "Hygienist C Reject Evaluation");
        public static readonly ScorecardAction IEHApproveEvaluation = new ScorecardAction(45, "IEHApproveEvaluation", "IEH Approve Evaluation");
        public static readonly ScorecardAction IEHRejectEvaluation = new ScorecardAction(46, "IEHRejectEvaluation", "IEH Reject Evaluation");
        public static readonly ScorecardAction IEHReviewEvaluation = new ScorecardAction(47, "IEHReviewEvaluation", "IEH Manager Review Evaluation");

        public static readonly ScorecardAction VPCapitalPlanningApproveEvaluation = new ScorecardAction(48, "VPCapitalPlanningApproveEvaluation", "VP Capital Planning Approve Evaluation");
        public static readonly ScorecardAction VPCapitalPlanningRejectEvaluation = new ScorecardAction(49, "VPCapitalPlanningRejectEvaluation", "VP Capital Planning Reject Evaluation");
        public static readonly ScorecardAction VPCapitalPlanningReviewEvaluation = new ScorecardAction(50, "VPCapitalPlanningReviewEvaluation", "VP Capital Planning Review Evaluation");

        #endregion  

        #region Constructors
        public ScorecardAction()
        {
        }

        private ScorecardAction(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ScorecardAction class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ScorecardAction.  
        /// </summary>
        public static ScorecardAction Default
        {
            get
            {
                return (ScorecardAction)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ScorecardAction class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        #endregion
        
        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ScorecardAction object.
        /// It allows a string to be assigned to a ScorecardAction object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ScorecardAction(int id)
        {
            return (ScorecardAction)EnumerationBase.FindById(id, ScorecardAction._list);
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ScorecardAction objects.
    /// It's very useful when binding ScorecardAction objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ScorecardActionConverter : TypeConverter
    {

        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ScorecardAction._list);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ScorecardAction enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ScorecardAction._list.Count; i++)
            {
                list.Add(((ScorecardAction)ScorecardAction._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }

}
