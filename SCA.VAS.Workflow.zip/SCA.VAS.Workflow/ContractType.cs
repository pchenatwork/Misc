#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of Contract:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ContractConverter))]
    public class ContractType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly ContractType A = new ContractType(1, "A", "Miscellaneous Agreement");
        public static readonly ContractType AC = new ContractType(2, "AC", "Design/CIP");
        public static readonly ContractType AE = new ContractType(3, "AE", "Design");
        public static readonly ContractType AL = new ContractType(4, "AL", "Design/Line");
        public static readonly ContractType AM = new ContractType(5, "AM", "Design/Miscellaneous");
        public static readonly ContractType AP = new ContractType(6, "AP", "Design/Project Specific");
        public static readonly ContractType AR = new ContractType(7, "AR", "Art");
        public static readonly ContractType AS = new ContractType(8, "AS", "Admin. Personal/Prof. Service");
        public static readonly ContractType AV = new ContractType(9, "AV", "Design/Environmental");
        public static readonly ContractType C = new ContractType(10, "C", "Capital Improvement");
        public static readonly ContractType CM = new ContractType(11, "CM", "Construction Manager");
        public static readonly ContractType CR = new ContractType(12, "CR", "CIP Construction Management");
        public static readonly ContractType L = new ContractType(13, "L", "Line Contract");
        public static readonly ContractType LG = new ContractType(14, "LG", "Legal");
        public static readonly ContractType M = new ContractType(15, "M", "Maintenance");
        public static readonly ContractType ME = new ContractType(16, "ME", "Mentor");
        public static readonly ContractType MG = new ContractType(17, "MG", "CIP / Mentor Graduate");
        public static readonly ContractType OL = new ContractType(18, "OL", "Old BOE");
        public static readonly ContractType P = new ContractType(19, "P", "Const. Related Pers./Prof. Ser");
        public static readonly ContractType PR = new ContractType(20, "PR", "Purchase Requirements");
        public static readonly ContractType R2 = new ContractType(21, "R2", "Second Requirements");
        #endregion

        #region Constructors
        public ContractType()
        {
        }

        private ContractType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in Contract class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of Contract.  
        /// </summary>
        public static ContractType Default
        {
            get
            {
                return (ContractType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for Contract class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        public static ContractType GetByName(string name)
        {
            for (int i = 0; i < ContractType._list.Count; i++)
            {
                if (((ContractType)ContractType._list[i]).Name == name)
                    return (ContractType)ContractType._list[i];
            }
            return null;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a Contract object.
        /// It allows a string to be assigned to a Contract object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ContractType(int id)
        {
            return (ContractType)EnumerationBase.FindById(id, ContractType._list);
        }
        public static implicit operator ContractType(string name)
        {
            for (int i = 0; i < ContractType._list.Count; i++)
            {
                if (((ContractType)ContractType._list[i]).Name == name)
                    return (ContractType)ContractType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and Contract objects.
    /// It's very useful when binding Contract objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ContractConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ContractType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the Contract enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ContractType._list.Count; i++)
            {
                list.Add(((ContractType)ContractType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
