#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of FaxHistoryStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(FaxHistoryStatusConverter))]
    public class FaxHistoryStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly FaxHistoryStatusType fsUnborn = new FaxHistoryStatusType(0, "fsUnborn", "Not yet created");
        public static readonly FaxHistoryStatusType fsNeedsFCS = new FaxHistoryStatusType(1, "fsNeedsFCS", "Needs fax cover sheet");
        public static readonly FaxHistoryStatusType fsNeedsConversion = new FaxHistoryStatusType(2, "fsNeedsConversion", "Needs conversion to an image file");
        public static readonly FaxHistoryStatusType fsNeedsToBeSent = new FaxHistoryStatusType(3, "fsNeedsToBeSent", "fsNeedsToBeSent");
        public static readonly FaxHistoryStatusType fslnConversion = new FaxHistoryStatusType(4, "fslnConversion", "In process of being converted to an image file");
        public static readonly FaxHistoryStatusType fslnSend = new FaxHistoryStatusType(5, "fslnSend", "Needs fax cover sheet");
        public static readonly FaxHistoryStatusType fsDoneOK = new FaxHistoryStatusType(6, "fsDoneOK", "Successfully sent or received");
        public static readonly FaxHistoryStatusType fsManualFCS = new FaxHistoryStatusType(7, "fsManualFCS", "Uses a manual fax cover sheet");
        public static readonly FaxHistoryStatusType fsInSchedule = new FaxHistoryStatusType(8, "fsInSchedule", "Awaiting scheduled send time");
        public static readonly FaxHistoryStatusType fsDoneError = new FaxHistoryStatusType(9, "fsDoneError", "Too many errors, will not be retried");
        public static readonly FaxHistoryStatusType fsDuplicate = new FaxHistoryStatusType(10, "fsDuplicate", "fsDuplicate");
        public static readonly FaxHistoryStatusType fsError = new FaxHistoryStatusType(11, "fsError", "fsError");
        public static readonly FaxHistoryStatusType fsNeedsAttention = new FaxHistoryStatusType(12, "fsNeedsAttention", "fsNeedsAttention");
        public static readonly FaxHistoryStatusType fsNeedsAttachment = new FaxHistoryStatusType(13, "fsNeedsAttachment", "fsNeedsAttachment");
        public static readonly FaxHistoryStatusType fsHeldForPreview = new FaxHistoryStatusType(14, "fsHeldForPreview", "fsHeldForPreview");
        public static readonly FaxHistoryStatusType fsInOCR = new FaxHistoryStatusType(15, "fsInOCR", "DfsInOCR");
        public static readonly FaxHistoryStatusType fsInPrint = new FaxHistoryStatusType(16, "fsInPrint", "fsInPrint");
        public static readonly FaxHistoryStatusType fsQueuedForPrinting = new FaxHistoryStatusType(17, "fsQueuedForPrinting", "fsQueuedForPrinting");
        public static readonly FaxHistoryStatusType fsQueuedForOCR = new FaxHistoryStatusType(18, "fsQueuedForOCR", "fsQueuedForOCR");
        public static readonly FaxHistoryStatusType fsInValidation = new FaxHistoryStatusType(19, "fsInValidation", "fsInValidation");
        public static readonly FaxHistoryStatusType fsInApproval = new FaxHistoryStatusType(20, "fsInApproval", "fsInApproval");
        #endregion

        #region Constructors
        public FaxHistoryStatusType()
        {
        }

        private FaxHistoryStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in FaxHistoryStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of FaxHistoryStatus.  
        /// </summary>
        public static FaxHistoryStatusType Default
        {
            get
            {
                return (FaxHistoryStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for FaxHistoryStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((FaxHistoryStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a FaxHistoryStatus object.
        /// It allows a string to be assigned to a FaxHistoryStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator FaxHistoryStatusType(int id)
        {
            return (FaxHistoryStatusType)EnumerationBase.FindById(id, FaxHistoryStatusType._list);
        }
        public static implicit operator FaxHistoryStatusType(string name)
        {
            for (int i = 0; i < FaxHistoryStatusType._list.Count; i++)
            {
                if (((FaxHistoryStatusType)FaxHistoryStatusType._list[i]).Name == name)
                    return (FaxHistoryStatusType)FaxHistoryStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and FaxHistoryStatus objects.
    /// It's very useful when binding FaxHistoryStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class FaxHistoryStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, FaxHistoryStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the FaxHistoryStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < FaxHistoryStatusType._list.Count; i++)
            {
                list.Add(((FaxHistoryStatusType)FaxHistoryStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }

    /// <summary>
    /// This Class defines the various enumerated values of FaxHistoryErrorCode:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(FaxHistoryErrorCodeConverter))]
    public class FaxHistoryErrorCodeType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly FaxHistoryErrorCodeType fecNone = new FaxHistoryErrorCodeType(0, "fecNone", "No error");
        public static readonly FaxHistoryErrorCodeType fecBusy = new FaxHistoryErrorCodeType(1, "fecBusy", "Fax number was busy");
        public static readonly FaxHistoryErrorCodeType fecTransmissionError = new FaxHistoryErrorCodeType(2, "fecTransmissionError", "Fax was not sent/received");
        public static readonly FaxHistoryErrorCodeType fecPoorQuality = new FaxHistoryErrorCodeType(3, "fecPoorQuality", "The fax board returned a message indicating that although the fax was received, it contained errors");
        public static readonly FaxHistoryErrorCodeType fecNoAnswer = new FaxHistoryErrorCodeType(4, "fecNoAnswer", "The destination number did not answer the phone");
        public static readonly FaxHistoryErrorCodeType fecBadFCS = new FaxHistoryErrorCodeType(5, "fecBadFCS", "Bad File Cover Sheet");
        public static readonly FaxHistoryErrorCodeType fecBadConvert = new FaxHistoryErrorCodeType(6, "fecBadConvert", "NThe fax could not be converted to an image file");
        public static readonly FaxHistoryErrorCodeType fecMakeFCS = new FaxHistoryErrorCodeType(7, "fecMakeFCS", "Error while creating Fax Cover Sheet");
        public static readonly FaxHistoryErrorCodeType fecCantSchedule = new FaxHistoryErrorCodeType(8, "fecCantSchedule", "Fax was not sent because fax transmission schedule full");
        public static readonly FaxHistoryErrorCodeType fecUnknown = new FaxHistoryErrorCodeType(9, "fecUnknown", "Unknown error report by fax board");
        public static readonly FaxHistoryErrorCodeType fecHuman = new FaxHistoryErrorCodeType(10, "fecHuman", "A human answered the phone");
        public static readonly FaxHistoryErrorCodeType fecGroup2 = new FaxHistoryErrorCodeType(11, "fecGroup2", "Reached a Group2 machine");
        public static readonly FaxHistoryErrorCodeType fecLocalInUse = new FaxHistoryErrorCodeType(12, "fecLocalInUse", "The destination fax number is unable to receive");
        public static readonly FaxHistoryErrorCodeType fecLineProblem = new FaxHistoryErrorCodeType(13, "fecLineProblem", "Communications line between the two fax numbers not working correctly");
        public static readonly FaxHistoryErrorCodeType fecBadPaper = new FaxHistoryErrorCodeType(14, "fecBadPaper", "Invalid FormType specified");
        public static readonly FaxHistoryErrorCodeType fecBadSignature = new FaxHistoryErrorCodeType(15, "fecBadSignature", "Invalid signature file specified");
        public static readonly FaxHistoryErrorCodeType fecNoSignatureAuthorization = new FaxHistoryErrorCodeType(16, "fecNoSignatureAuthorization", "The fax required but did not receive signature authorization");
        public static readonly FaxHistoryErrorCodeType fecDiscarded = new FaxHistoryErrorCodeType(18, "fecDiscarded", "Canceled by user");
        public static readonly FaxHistoryErrorCodeType fecBadPhone = new FaxHistoryErrorCodeType(19, "fecBadPhone", "Invalid characters in fax number");
        public static readonly FaxHistoryErrorCodeType fecInvalidCode = new FaxHistoryErrorCodeType(21, "fecInvalidCode", "Invalid BillingCode");
        public static readonly FaxHistoryErrorCodeType fecBadCode = new FaxHistoryErrorCodeType(22, "fecBadCode", "Error in an embedded code");
        public static readonly FaxHistoryErrorCodeType fecBadOCR = new FaxHistoryErrorCodeType(23, "fecBadOCR", "OCR operation failed");
        public static readonly FaxHistoryErrorCodeType fecBadPrint = new FaxHistoryErrorCodeType(24, "fecBadPrint", "Print operation failed");
        public static readonly FaxHistoryErrorCodeType fecNoLibraryDocumentAuthorization = new FaxHistoryErrorCodeType(25, "fecNoLibraryDocumentAuthorization", "Unauthorized user attempting to create a new library document");
        public static readonly FaxHistoryErrorCodeType fecViewStar1 = new FaxHistoryErrorCodeType(26, "fecViewStar1", "ViewStar imaging system import error");
        public static readonly FaxHistoryErrorCodeType fecDisapproved = new FaxHistoryErrorCodeType(27, "fecDisapproved", "The fax was disapproved for transmission");
        public static readonly FaxHistoryErrorCodeType fecEmailDeliveryError = new FaxHistoryErrorCodeType(28, "fecEmailDeliveryError", "The fax document could not be sent to the specified e-mail address");
        #endregion

        #region Constructors
        public FaxHistoryErrorCodeType()
        {
        }

        private FaxHistoryErrorCodeType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in FaxHistoryErrorCode class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of FaxHistoryErrorCode.  
        /// </summary>
        public static FaxHistoryErrorCodeType Default
        {
            get
            {
                return (FaxHistoryErrorCodeType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for FaxHistoryErrorCode class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((FaxHistoryErrorCodeType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a FaxHistoryErrorCode object.
        /// It allows a string to be assigned to a FaxHistoryErrorCode object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator FaxHistoryErrorCodeType(int id)
        {
            return (FaxHistoryErrorCodeType)EnumerationBase.FindById(id, FaxHistoryErrorCodeType._list);
        }
        public static implicit operator FaxHistoryErrorCodeType(string name)
        {
            for (int i = 0; i < FaxHistoryErrorCodeType._list.Count; i++)
            {
                if (((FaxHistoryErrorCodeType)FaxHistoryErrorCodeType._list[i]).Name == name)
                    return (FaxHistoryErrorCodeType)FaxHistoryErrorCodeType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and FaxHistoryErrorCode objects.
    /// It's very useful when binding FaxHistoryErrorCode objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class FaxHistoryErrorCodeConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, FaxHistoryErrorCodeType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the FaxHistoryErrorCode enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < FaxHistoryErrorCodeType._list.Count; i++)
            {
                list.Add(((FaxHistoryErrorCodeType)FaxHistoryErrorCodeType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }

}
