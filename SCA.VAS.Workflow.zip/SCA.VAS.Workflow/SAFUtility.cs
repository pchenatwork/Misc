﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.Supplier.Subcontractor.Utilities;
using SCA.VAS.ValueObjects.Supplier.Subcontractor;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;
using System.Collections;
using SCA.VAS.BusinessLogic.Supplier.Subcontractor;
using SCA.VAS.BusinessLogic.Supplier;

namespace SCA.VAS.Workflow
{
    public partial class ConstantUtility
    {
        public const string WORKFLOW_SUBCONTRACTOR = "SAF";
    }

    public partial class CommonUtility
    {
        public static void SubcontractorSendEmail(Subcontractor subcontractor, WorkflowHistory workflowHistory,
            string emailMessageName, string comments)
        {
            EmailMessage emailmessage = EmailMessageUtility.GetByName(
                ConstantUtility.COMMON_DATASOURCE_NAME, emailMessageName);
            if (emailmessage == null) return;

            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

            Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, subcontractor.SupplierId);
            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "Supplier", supplier.Id.ToString());
            EmailMessage newMessage = EmailReplaceRelatedUsers(EmailReplaceRelatedUsers(emailmessage, supplier), subcontractor);

            switch (emailmessage.Objects)
            {
                case "Authorized Users":
                    {
                        string nodes = XmlUtility.ToXml(workflowHistory.NextLinks);
                        UserCollection users = UserUtility.FindByCriteria(
                            ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_WORKFLOWNODES,
                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                            {
                                SendEmail(emailmessage, users[i],
                                    new object[] { subcontractor, users[i], supplier, vendor },
                                    comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "Subcontractor", subcontractor.Id);
                            }
                        }
                    }
                    break;

                case "Users":
                    {
                        SendEmail(emailmessage, user,
                            new object[] { subcontractor, user, supplier, vendor }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Subcontractor", subcontractor.Id);
                    }
                    break;


                case "Supplier Related Users":
                    {
                        EmailMessage newEmailMessage = EmailReplaceRelatedUsers(emailmessage, subcontractor);
                        SendEmail(newEmailMessage, user,
                            new object[] { subcontractor, user, supplier, vendor }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Subcontractor", subcontractor.Id);
                    }
                    break;


                case "Suppliers":
                    {
                        SendEmail(emailmessage, supplier,
                            new object[] { subcontractor, user, supplier, vendor }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Subcontractor", subcontractor.Id);
                    }
                    break;

                default:
                    {
                        SendEmail(emailmessage, null,
                            new object[] { subcontractor, user, supplier, vendor }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Subcontractor", subcontractor.Id);
                    }
                    break;
            }
        }

        public static EmailMessage EmailReplaceRelatedUsers(EmailMessage emailmessage, Subcontractor subcontractor)
        {
            if (emailmessage == null) return null;

            Hashtable RelatedUsers = new Hashtable();

            RelatedUsers.Add("$CONTRACTNUMBER$", subcontractor.ContractNo);
            RelatedUsers.Add("$JOBDESCRIPTION$", subcontractor.WorkDescription);

            //RfcCollection rfcs = RfcUtility.FindByCriteria(
            //                ConstantUtility.RFD_DATASOURCE_NAME,
            //                RfcManager.SEARCH_RFC,
            //                new object[]
            //                    { 
            //                        rfcGrid.PageSize,
            //                        rfcGrid.CurrentPageIndex,
            //                        ViewState["SortField"].ToString(),
            //                        ViewState["SortSequence"].ToString(),
            //                        UserId,
            //                        search.Type,
            //                        search.ExtraXml
            //                    }); 


            SolicitContract contract = SolicitContractUtility.Get(
                ConstantUtility.RFD_DATASOURCE_NAME, subcontractor.IsMentor, subcontractor.ContractNo,
                subcontractor.SolicitId);
            string poEmail = string.Empty;
            string cpoEmail = string.Empty;
            string spoEmail = string.Empty;
            string primeEmail = string.Empty;
            string primeName = string.Empty;
            string mentorPrimeEmail = string.Empty;
            string mentorPrimeName = string.Empty;
            if (contract != null)
            {
                User po = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, contract.OfficerCode);
                if (po != null) poEmail = po.Email;
                User cpo = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, contract.ChiefProjOfficerCode);
                if (cpo != null) cpoEmail = cpo.Email;
                User spo = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, contract.SrProjOfficerCode);
                if (spo != null) spoEmail = spo.Email;
                Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "FederalId", contract.VendorId);
                if (vendor != null)
                {
                    VendorContact contact = CommonUtility.GetPrimaryContact(vendor.Id);
                    if (contact != null)
                    {
                        primeEmail = contact.Email;
                        primeName = contact.Name;
                    }
                }
                Vendor mentorVendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "FederalId", contract.MentorVendorId);
                if (mentorVendor != null)
                {
                    VendorContact mentorContact = CommonUtility.GetPrimaryContact(mentorVendor.Id);
                    if (mentorContact != null)
                    {
                        mentorPrimeEmail = mentorContact.Email;
                        mentorPrimeName = mentorContact.Name;
                    }
                }
            }


            RelatedUsers.Add("$SAFPOEMAIL$", poEmail);
            RelatedUsers.Add("$SAFCPOEMAIL$", cpoEmail);
            RelatedUsers.Add("$SAFSPOEMAIL$", spoEmail);
            RelatedUsers.Add("$SAFPRIMEEMAIL$", primeEmail);
            RelatedUsers.Add("$SAFPRIMENAME$", primeName);
            RelatedUsers.Add("$SAFMENTORPRIMEEMAIL$", mentorPrimeEmail);
            RelatedUsers.Add("$SAFMENTORPRIMENAME$", mentorPrimeName);


            string school = string.Empty;
            string llw_list = string.Empty;


            if (subcontractor != null && subcontractor.Items != null && subcontractor.Items.Count > 0)
            {
                foreach (SubcontractorItem item in subcontractor.Items)
                {
                    if(school.IndexOf(item.School)<0)
                        school = school + item.School + ", " ;

                    if (llw_list.IndexOf(item.LLW) < 0)
                        llw_list = llw_list + item.LLW + ", ";
                }
                
            }
            if (school.Length >= 1)
            {
                RelatedUsers.Add("$SAFSCHOOL$", school.Substring(0, (school.Length -2)));
            }
            else
                RelatedUsers.Add("$SAFSCHOOL$", "NOT SPECIFIED");

            if (llw_list.Length >= 1)
            {
                RelatedUsers.Add("$LLW_LIST$", llw_list.Substring(0, (llw_list.Length - 2)));
            }
            else
                RelatedUsers.Add("$LLW_LIST$", "NOT SPECIFIED");


            subcontractor.SubcontractorProperties = SubcontractorPropertyUtility.FindByCriteria(
                ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                SubcontractorPropertyManager.FIND_BY_SUBCONTRACTOR,
                new object[] { subcontractor.Id });
            if (subcontractor.SubcontractorProperties == null)
                subcontractor.SubcontractorProperties = new SubcontractorPropertyCollection();

            string requestorEmail = string.Empty;
            requestorEmail = GetSubcontractorProperty("property3", subcontractor.SubcontractorProperties).PropertyText;
            RelatedUsers.Add("$REQUESTOREMAIL$", requestorEmail);

            string requestorPhone = string.Empty;
            requestorPhone = GetSubcontractorProperty("property9", subcontractor.SubcontractorProperties).PropertyText;
            RelatedUsers.Add("$REQUESTORPHONE$", requestorPhone);

            string requestorName = string.Empty;
            requestorName = GetSubcontractorProperty("property43", subcontractor.SubcontractorProperties).PropertyText;
            RelatedUsers.Add("$REQUESTORNAME$", requestorName);

            string cmFederalId = string.Empty;
            string cmEmail = string.Empty;
            string cmName = string.Empty;
            cmFederalId = GetSubcontractorProperty("property48", subcontractor.SubcontractorProperties).PropertyText;
            Vendor CMVendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "FederalId", cmFederalId);
            if (CMVendor != null)
            {
                VendorContact contact = CommonUtility.GetPrimaryContact(CMVendor.Id);
                if (contact != null)
                {
                    cmEmail = contact.Email;
                    cmName = contact.Name;
                }
            }
            RelatedUsers.Add("$CMEMAIL$", cmEmail);
            RelatedUsers.Add("$CMNAME$", cmName);

            string disapproveReason = string.Empty;
            disapproveReason = GetSubcontractorProperty("property28", subcontractor.SubcontractorProperties).PropertyText;
            if (disapproveReason == "Other:" || disapproveReason.IndexOf("not satisfactory for contract number:") >= 0)
                disapproveReason += " " + GetSubcontractorProperty("property29", subcontractor.SubcontractorProperties).PropertyText;
            RelatedUsers.Add("$SAFDISAPPROVEREASON$", disapproveReason);


            string denyReason = string.Empty;
            denyReason = GetSubcontractorProperty("property46", subcontractor.SubcontractorProperties).PropertyText;
            if (denyReason == "Other:" || denyReason.IndexOf("not satisfactory for contract number:") >= 0)
                denyReason += " " + GetSubcontractorProperty("property47", subcontractor.SubcontractorProperties).PropertyText;
            RelatedUsers.Add("$SAFDENYREASON$", denyReason);

            string pendingReason = string.Empty;
            pendingReason = GetSubcontractorProperty("property30", subcontractor.SubcontractorProperties).PropertyText;

            if (pendingReason == "Other:")
                pendingReason += " " + GetSubcontractorProperty("property31", subcontractor.SubcontractorProperties).PropertyText;
            RelatedUsers.Add("$SAFPENDINGREASON$", pendingReason);


            string incorrectDesc = string.Empty;
            incorrectDesc = GetSubcontractorProperty("property44", subcontractor.SubcontractorProperties).PropertyText;
            RelatedUsers.Add("$SAFINCORRECTDESC$", incorrectDesc);


            string safEmail = string.Empty;
            safEmail = GetSubcontractorProperty("property39", subcontractor.SubcontractorProperties).PropertyText;
            RelatedUsers.Add("$SAFEMAIL$", safEmail);

            string safPhone = string.Empty;
            safPhone = GetSubcontractorProperty("property40", subcontractor.SubcontractorProperties).PropertyText;
            RelatedUsers.Add("$SAFPHONE$", safPhone);

            string safName = string.Empty;
            safName = GetSubcontractorProperty("property41", subcontractor.SubcontractorProperties).PropertyText;
            RelatedUsers.Add("$SAFNAME$", safName);


            SubcontractorCommentCollection subcontractorComments = SubcontractorCommentUtility.FindByCriteria(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                SubcontractorCommentManager.FIND_SUBCONTRACTORCOMMENT, new object[] { 0, 0, "", "", subcontractor.Id, "External" });
            string commentString = "";
            if (subcontractorComments != null)
            {
                foreach (SubcontractorComment comment in subcontractorComments)
                {
                    if (comment.Submitted != "Y")
                    {
                        if (commentString == "")
                            commentString = "<table border='1' cellpadding='3'>";
                        commentString += "<tr><td><b>";
                        string section = "";
                        switch (comment.FileLink)
                        {
                            case "0":
                                section = "Company Information";
                                break;
                            case "1":
                                section = "Apprenticeship Information";
                                break;
                            case "2":
                                section = "License Information";
                                break;
                            case "3":
                                section = "Insurance Information";
                                break;
                        }
                        commentString += section + "</b></td><td>" + comment.Comments + "</td></tr>";
                    }
                }
            }
            if (commentString != "")
                commentString += "</table>";
            RelatedUsers.Add("$SAFDYNAMICMISSINGINFO$", commentString);


            User safReviewer = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, GetSubcontractorProperty("property1", subcontractor.SubcontractorProperties).PropertyText);
            if (safReviewer != null)
            {
                RelatedUsers.Add("$SAFREVIEWER$", (safReviewer == null) ? "" : safReviewer.FullName);
                RelatedUsers.Add("$SAFREVIEWERNAME$", (safReviewer == null) ? "" : safReviewer.FullName);
                RelatedUsers.Add("$SAFREVIEWERPHONE$", (safReviewer == null) ? "" : safReviewer.Phone);
                RelatedUsers.Add("$SAFREVIEWEREMAIL$", (safReviewer == null) ? "" : safReviewer.Email);
                RelatedUsers.Add("$SAFREVIEWERTITLE$", (safReviewer == null) ? "" : safReviewer.Title);
            }
            //RelatedUsers = AddRelatedUsersInRole("SAF Reviewer", "$SAFREVIEWEREMAIL$", RelatedUsers);

            emailmessage.FromEmail = ReplaceRelatedUsers(emailmessage.FromEmail, RelatedUsers);
            emailmessage.ToEmail = ReplaceRelatedUsers(emailmessage.ToEmail, RelatedUsers);
            emailmessage.ToName = ReplaceRelatedUsers(emailmessage.ToName, RelatedUsers);
            emailmessage.CcEmail = ReplaceRelatedUsers(emailmessage.CcEmail, RelatedUsers);
            emailmessage.BccEmail = ReplaceRelatedUsers(emailmessage.BccEmail, RelatedUsers);
            emailmessage.Subject = ReplaceRelatedUsers(emailmessage.Subject, RelatedUsers);
            emailmessage.Body = ReplaceRelatedUsers(emailmessage.Body, RelatedUsers);

            return emailmessage;
        }

        public static Hashtable AddRelatedUsersInRole(string roleName, string mergeField, Hashtable RelatedUsers)
        {
            UserCollection reviewers = UserUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                UserManager.SEARCH_USER,
                new object[] 
			            { 
				            0,
				            0,
				            string.Empty,
				            string.Empty,
				            string.Empty, 
				            -1,
				            string.Empty,
				            string.Empty,
				            roleName,
				            string.Empty,
				            string.Empty,
			            });
            if (reviewers != null && reviewers.Count > 0)
            {
                string emailStr = string.Empty;
                foreach (User reviewer in reviewers)
                {
                    emailStr = emailStr + reviewer.Email + ";";
                }
                RelatedUsers.Add(mergeField, emailStr);
            }
            return RelatedUsers;
        }

        public static SubcontractorProperty CreateSubcontractorProperty(Control control, string value, Type type, Control parent, string changeUser)
        {
            SubcontractorProperty subcontractorProperty = CreateSubcontractorProperty(control, value, type, parent);
            subcontractorProperty.ChangeUser = changeUser;
            return subcontractorProperty;
        }

        public static RS1SubcontractorProperty CreateRS1SubcontractorProperty(Control control, string value, Type type, Control parent, string changeUser)
        {
            RS1SubcontractorProperty RS1subcontractorProperty = CreateRS1SubcontractorProperty(control, value, type, parent);
            RS1subcontractorProperty.ChangeUser = changeUser;
            return RS1subcontractorProperty;
        }

        public static SubcontractorProperty CreateSubcontractorProperty(Control control, string value, Type type, Control parent)
        {
            SubcontractorProperty subcontractorProperty = SubcontractorPropertyUtility.CreateObject();
            subcontractorProperty.PropertyId = ConvertUtility.ConvertInt(control.ID.Substring(8));
            if (parent != null) subcontractorProperty.ParentId = subcontractorProperty.PropertyId;
            switch (type.Name)
            {
                case "Int32":
                    subcontractorProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    subcontractorProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    subcontractorProperty.PropertyText = value;
                    break;
            }
            return subcontractorProperty;
        }


        public static RS1SubcontractorProperty CreateRS1SubcontractorProperty(Control control, string value, Type type, Control parent)
        {
            RS1SubcontractorProperty subcontractorProperty = RS1SubcontractorPropertyUtility.CreateObject();
            subcontractorProperty.PropertyId = ConvertUtility.ConvertInt(control.ID.Substring(8));
            if (parent != null) subcontractorProperty.ParentId = subcontractorProperty.PropertyId;
            switch (type.Name)
            {
                case "Int32":
                    subcontractorProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    subcontractorProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    subcontractorProperty.PropertyText = value;
                    break;
            }
            return subcontractorProperty;
        }


        public static SubcontractorProperty CreateSubcontractorProperty(Control control, string attachmentName, byte[] attachment)
        {
            SubcontractorProperty subcontractorProperty = SubcontractorPropertyUtility.CreateObject();
            subcontractorProperty.PropertyId = ConvertUtility.ConvertInt(control.ID.Substring(8));
            subcontractorProperty.AttachmentName = attachmentName;
            subcontractorProperty.Attachment = attachment;
            return subcontractorProperty;
        }

        public static RS1SubcontractorProperty CreateRS1SubcontractorProperty(Control control, string attachmentName, byte[] attachment)
        {
            RS1SubcontractorProperty subcontractorProperty = RS1SubcontractorPropertyUtility.CreateObject();
            subcontractorProperty.PropertyId = ConvertUtility.ConvertInt(control.ID.Substring(8));
            subcontractorProperty.AttachmentName = attachmentName;
            subcontractorProperty.Attachment = attachment;
            return subcontractorProperty;
        }

        public static SubcontractorProperty CreateSubcontractorProperty(int propertyId, string value)
        {
            SubcontractorProperty subcontractorProperty = CreateSubcontractorProperty(propertyId, value, typeof(String));
            return subcontractorProperty;
        }

        public static RS1SubcontractorProperty CreateRS1SubcontractorProperty(int propertyId, string value)
        {
            RS1SubcontractorProperty subcontractorProperty = CreateRS1SubcontractorProperty(propertyId, value, typeof(String));
            return subcontractorProperty;
        }

        public static SubcontractorProperty CreateSubcontractorProperty(int propertyId, string value, Type type)
        {
            SubcontractorProperty subcontractorProperty = SubcontractorPropertyUtility.CreateObject();
            subcontractorProperty.PropertyId = propertyId;
            switch (type.Name)
            {
                case "Int32":
                    subcontractorProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    subcontractorProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    subcontractorProperty.PropertyText = value;
                    break;
            }
            return subcontractorProperty;
        }

        public static RS1SubcontractorProperty CreateRS1SubcontractorProperty(int propertyId, string value, Type type)
        {
            RS1SubcontractorProperty subcontractorProperty = RS1SubcontractorPropertyUtility.CreateObject();
            subcontractorProperty.PropertyId = propertyId;
            switch (type.Name)
            {
                case "Int32":
                    subcontractorProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    subcontractorProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    subcontractorProperty.PropertyText = value;
                    break;
            }
            return subcontractorProperty;
        }

        public static SubcontractorPropertyCollection AddSubcontractorProperty(Subcontractor subcontractor, SubcontractorProperty subcontractorProperty)
        {
            SubcontractorPropertyCollection subcontractorProperties = new SubcontractorPropertyCollection();
            subcontractorProperties.Add(subcontractorProperty);
            return AddSubcontractorProperty(subcontractor, subcontractorProperties);
        }

        public static RS1SubcontractorPropertyCollection AddRS1SubcontractorProperty(RS1Subcontractor subcontractor, RS1SubcontractorProperty subcontractorProperty)
        {
            RS1SubcontractorPropertyCollection subcontractorProperties = new RS1SubcontractorPropertyCollection();
            subcontractorProperties.Add(subcontractorProperty);
            return AddRS1SubcontractorProperty(subcontractor, subcontractorProperties);
        }


        public static SubcontractorPropertyCollection AddSubcontractorProperty(Subcontractor subcontractor, SubcontractorPropertyCollection subcontractorProperties)
        {
            if (subcontractor.SubcontractorProperties == null)
                subcontractor.SubcontractorProperties = new SubcontractorPropertyCollection();

            foreach (SubcontractorProperty sp in subcontractorProperties)
            {
                if (sp.ParentId == 0)
                {
                    bool isChange = false;
                    foreach (SubcontractorProperty sp1 in subcontractor.SubcontractorProperties)
                    {
                        if (sp1.PropertyId == sp.PropertyId)
                        {
                            sp1.PropertyValue = sp.PropertyValue;
                            sp1.PropertyText = sp.PropertyText;
                            sp1.PropertyDate = sp.PropertyDate;
                            isChange = true;
                        }
                    }
                    if (!isChange)
                        subcontractor.SubcontractorProperties.Add(sp);
                }
                else
                {
                    //Multi values
                    subcontractor.SubcontractorProperties.Add(sp);
                }
            }
            return subcontractor.SubcontractorProperties;
        }

        public static RS1SubcontractorPropertyCollection AddRS1SubcontractorProperty(RS1Subcontractor subcontractor, RS1SubcontractorPropertyCollection subcontractorProperties)
        {
            if (subcontractor.RS1SubcontractorProperties == null)
                subcontractor.RS1SubcontractorProperties = new RS1SubcontractorPropertyCollection();

            foreach (RS1SubcontractorProperty sp in subcontractorProperties)
            {
                if (sp.ParentId == 0)
                {
                    bool isChange = false;
                    foreach (RS1SubcontractorProperty sp1 in subcontractor.RS1SubcontractorProperties)
                    {
                        if (sp1.PropertyId == sp.PropertyId)
                        {
                            sp1.PropertyValue = sp.PropertyValue;
                            sp1.PropertyText = sp.PropertyText;
                            sp1.PropertyDate = sp.PropertyDate;
                            isChange = true;
                        }
                    }
                    if (!isChange)
                        subcontractor.RS1SubcontractorProperties.Add(sp);
                }
                else
                {
                    //Multi values
                    subcontractor.RS1SubcontractorProperties.Add(sp);
                }
            }
            return subcontractor.RS1SubcontractorProperties;
        }


        public static SubcontractorProperty GetSubcontractorProperty(Control control, SubcontractorPropertyCollection subcontractorProperties)
        {
            if (subcontractorProperties == null) return SubcontractorPropertyUtility.CreateObject();
            foreach (SubcontractorProperty sp in subcontractorProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(control.ID.Substring(8)))
                    return sp;
            }
            return SubcontractorPropertyUtility.CreateObject();
        }



        public static RS1SubcontractorProperty GetRS1SubcontractorProperty(Control control, RS1SubcontractorPropertyCollection subcontractorProperties)
        {
            if (subcontractorProperties == null) return RS1SubcontractorPropertyUtility.CreateObject();
            foreach (RS1SubcontractorProperty sp in subcontractorProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(control.ID.Substring(8)))
                    return sp;
            }
            return RS1SubcontractorPropertyUtility.CreateObject();
        }
        public static SubcontractorProperty GetSubcontractorProperty(string propertyId, SubcontractorPropertyCollection subcontractorProperties)
        {
            if (subcontractorProperties == null) return SubcontractorPropertyUtility.CreateObject();
            foreach (SubcontractorProperty sp in subcontractorProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(propertyId.Substring(8)))
                    return sp;
            }
            return SubcontractorPropertyUtility.CreateObject();
        }


        public static RS1SubcontractorProperty GetRS1SubcontractorProperty(string propertyId, RS1SubcontractorPropertyCollection subcontractorProperties)
        {
            if (subcontractorProperties == null) return RS1SubcontractorPropertyUtility.CreateObject();
            foreach (RS1SubcontractorProperty sp in subcontractorProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(propertyId.Substring(8)))
                    return sp;
            }
            return RS1SubcontractorPropertyUtility.CreateObject();
        }
        public static SubcontractorPropertyCollection GetSubcontractorProperties(Control control, SubcontractorPropertyCollection subcontractorProperties)
        {
            SubcontractorPropertyCollection localSubcontractorProperties = new SubcontractorPropertyCollection();
            if (subcontractorProperties == null) return localSubcontractorProperties;
            foreach (SubcontractorProperty sp in subcontractorProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(control.ID.Substring(8)))
                    localSubcontractorProperties.Add(sp);
            }
            return localSubcontractorProperties;
        }

        public static RS1SubcontractorPropertyCollection GetRS1SubcontractorProperties(Control control, RS1SubcontractorPropertyCollection subcontractorProperties)
        {
            RS1SubcontractorPropertyCollection localSubcontractorProperties = new RS1SubcontractorPropertyCollection();
            if (subcontractorProperties == null) return localSubcontractorProperties;
            foreach (RS1SubcontractorProperty sp in subcontractorProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(control.ID.Substring(8)))
                    localSubcontractorProperties.Add(sp);
            }
            return localSubcontractorProperties;
        }
        public static SubcontractorPropertyCollection GetSubcontractorProperties(string controlId, SubcontractorPropertyCollection subcontractorProperties)
        {
            SubcontractorPropertyCollection localSubcontractorProperties = new SubcontractorPropertyCollection();
            if (subcontractorProperties == null) return localSubcontractorProperties;
            foreach (SubcontractorProperty sp in subcontractorProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(controlId.Substring(8)))
                    localSubcontractorProperties.Add(sp);
            }
            return localSubcontractorProperties;
        }

        public static RS1SubcontractorPropertyCollection GetRS1SubcontractorProperties(string controlId, RS1SubcontractorPropertyCollection subcontractorProperties)
        {
            RS1SubcontractorPropertyCollection localSubcontractorProperties = new RS1SubcontractorPropertyCollection();
            if (subcontractorProperties == null) return localSubcontractorProperties;
            foreach (RS1SubcontractorProperty sp in subcontractorProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(controlId.Substring(8)))
                    localSubcontractorProperties.Add(sp);
            }
            return localSubcontractorProperties;
        }

        public static void CreateSubcontractor(SolicitContract contract, string vendorId, string subVendorId, string subType)
        {
            Subcontractor subcontractor = SubcontractorUtility.CreateObject();

            subcontractor.Type = "RS-1";
            if (contract.TypeCode == "ME")
                subcontractor.IsMentor = "Y";
            else
                subcontractor.IsMentor = "N";
            subcontractor.TaxId = vendorId;
            subcontractor.ContractNo = contract.Contract;
            subcontractor.SolicitId = contract.SolicitSeq;
            subcontractor.SolicitNo = contract.Solicit;
            subcontractor.ScaProjectOfficer = contract.OfficerCode;
            subcontractor.FederalId = subVendorId;
            subcontractor.WorkDescription = subType;
            switch (subType.ToLower())
            {
                case "plumbing":
                    subcontractor.EstValue = contract.PlumbingValue;
                    break;
                case "hvac":
                    subcontractor.EstValue = contract.HvacValue;
                    break;
                case "electrical":
                    subcontractor.EstValue = contract.ElectricalValue;
                    break;
            }
            subcontractor.IsWicks = "Y";

            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                "FederalId", subVendorId);
            if (vendor != null)
            {
                subcontractor.SupplierId = vendor.CurrentSupplierId;

                Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                    vendor.CurrentSupplierId);

                subcontractor.Company = supplier.Company;
                if (supplier.PhysicalAddress != null)
                {
                    subcontractor.AddressLine1 = supplier.PhysicalAddress.AddressLine1.Replace("|", " ");
                    subcontractor.AddressLine2 = supplier.PhysicalAddress.AddressLine2.Trim().Length == 0 ? "" : "#" + supplier.PhysicalAddress.AddressLine2;
                    subcontractor.City = supplier.PhysicalAddress.City;
                    subcontractor.State = supplier.PhysicalAddress.State;
                    subcontractor.ZipCode = supplier.PhysicalAddress.ZipCode;
                    subcontractor.Country = supplier.PhysicalAddress.Country;
                    subcontractor.Phone = supplier.Phone;
                    subcontractor.Fax = supplier.Fax;
                }

                int transactionId = 0;
                if (supplier.SupplierWorkflows != null)
                {
                    foreach (SupplierWorkflow sw in supplier.SupplierWorkflows)
                    {
                        if (sw.WorkflowId == 2)
                            transactionId = sw.TransactionId;
                    }
                }
                WorkflowHistoryCollection tempHistories = WorkflowHistoryUtility.FindByCriteria(
                    ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                    WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                    new object[] { transactionId });
                bool hasApproval = false;
                if (tempHistories != null)
                {
                    foreach (WorkflowHistory wf in tempHistories)
                    {
                        if (wf.CurrentNodeName == CertificationStatusType.DirectorApproved.Description)
                            hasApproval = true;
                    }
                }
                bool pException = false;
                SupplierStatus certStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);
                if (certStatus != null)
                {
                    if (certStatus.Status == CertificationStatusType.Certified.Description)
                        hasApproval = true;
                    if (certStatus.Status == CertificationStatusType.CertAnalystClosed.Description ||
                        certStatus.Status == CertificationStatusType.CertClosed.Description ||
                        certStatus.Status == CertificationStatusType.Deny.Description ||
                        certStatus.Status == CertificationStatusType.Decertified.Description ||
                        certStatus.Status == CertificationStatusType.Disqualified.Description ||
                        certStatus.Status == CertificationStatusType.Withdrawn.Description ||
                        certStatus.Status == CertificationStatusType.Rescinded.Description ||
                        certStatus.Status == CertificationStatusType.Decertified.Description ||
                        certStatus.Status == CertificationStatusType.Expired.Description)
                        pException = true;
                }

                string[] classArray = new string[] { "MBE", "WBE", "LBE" };
                string[] classArrayValues = new string[] { "N", "N", "N" };

                string xml = "<ArrayOfDynamicProperty>";
                DynamicPropertyCollection types = DynamicPropertyUtility.FindByCriteria(
                    ConstantUtility.USER_DATASOURCE_NAME,
                    DynamicPropertyManager.FIND_BY_OBJECT,
                    new object[] { "SupplierStaticCertification", supplier.Id });
                if (types != null)
                {
                    foreach (DynamicProperty property in types)
                    {
                        xml += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"IsApplied\" />";
                        xml += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"IsRecommendedByDirector\" />";
                    }
                }
                xml += "</ArrayOfDynamicProperty>";

                DynamicPropertyCollection properties = DynamicPropertyUtility.FindByCriteria(
                    ConstantUtility.USER_DATASOURCE_NAME,
                    DynamicPropertyManager.FIND_BY_PROPERTIES,
                    new object[] { "SupplierStaticCertification", supplier.Id, xml });
                if (properties != null)
                {
                    foreach (DynamicProperty property in properties)
                    {
                        switch (property.PropertyName)
                        {
                            case "IsApplied":
                                if (property.PropertyText == "Y" && !pException)
                                {
                                    switch (property.PropertyType)
                                    {
                                        case "M":
                                            if (classArrayValues[0] != "Y")
                                                classArrayValues[0] = "P";
                                            break;
                                        case "W":
                                            if (classArrayValues[1] != "Y")
                                                classArrayValues[1] = "P";
                                            break;
                                        case "L":
                                            if (classArrayValues[2] != "Y")
                                                classArrayValues[2] = "P";
                                            break;
                                    }
                                }
                                break;
                            case "IsRecommendedByDirector":
                                if (hasApproval)
                                {
                                    switch (property.PropertyType)
                                    {
                                        case "M":
                                            classArrayValues[0] = property.PropertyText;
                                            break;
                                        case "W":
                                            classArrayValues[1] = property.PropertyText;
                                            break;
                                        case "L":
                                            classArrayValues[2] = property.PropertyText;
                                            break;
                                    }
                                }
                                break;
                        }
                    }
                }
                subcontractor.Mbe = classArrayValues[0];
                subcontractor.Wbe = classArrayValues[1];
                subcontractor.Lbe = classArrayValues[2];
            }

            subcontractor.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_SUBCONTRACTOR);

            if (SubcontractorUtility.Create(ConstantUtility.SUPPLIER_DATASOURCE_NAME, subcontractor))
            {
                AddSAFUser(contract.OfficerCode, "User", 0);

                SubcontractorUtility.Copy(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                    subcontractor.Id, subVendorId);
            }
        }

        /// <summary>
        /// Called by RS1 SAF from Bid-n-award Wicks firm selected
        /// </summary>
        /// <param name="project"></param>
        /// <param name="prime">Supplier - General Contractor</param>
        /// <param name="supplier">Supplier - Subcontractor</param>
        /// <param name="subType">Wicks Type</param>
        /// <param name="wicksBidAmount"></param>
        /// <returns>[Subcontractor].Id</returns>
        public static int CreateSubcontractor(Project project, Supplier prime, Supplier supplier, string subType,int wicksBidAmount=0)
        {
            /* ** *
             * 20200225 PCHEN Change method signature from return void to int ( newly created SubcontractorId )
             * ** */
            Subcontractor subcontractor = SubcontractorUtility.CreateObject();

            subcontractor.Type = "RS-1";
            if (project.Type.Equals("Mentor")) // Note: 'Mentor Grad' != IsMentor
                subcontractor.IsMentor = "Y";
            else
                subcontractor.IsMentor = "N";
            subcontractor.TaxId = prime.FederalId;
            subcontractor.SolicitNo = project.SolicitationNo;
            subcontractor.SolicitId = project.SolicitId;// solicitation primary key
            subcontractor.FederalId = supplier.FederalId;
            subcontractor.WorkDescription = subType;
            subcontractor.EstValue = wicksBidAmount; //add wicks bid amount 
            subcontractor.IsWicks = "Y";

            subcontractor.SupplierId = supplier.Id;
            subcontractor.CreateSupplierId = prime.Id;
            
            subcontractor.ScaProjectOfficer = project.PO;
            subcontractor.ParentCompany = prime.Company;

            subcontractor.Company = supplier.Company;
            if (supplier.PhysicalAddress != null)
            {
                subcontractor.AddressLine1 = supplier.PhysicalAddress.AddressLine1.Replace("|", " ");
                subcontractor.AddressLine2 = supplier.PhysicalAddress.AddressLine2.Trim().Length == 0 ? "" : "#" + supplier.PhysicalAddress.AddressLine2;
                subcontractor.City = supplier.PhysicalAddress.City;
                subcontractor.State = supplier.PhysicalAddress.State;
                subcontractor.ZipCode = supplier.PhysicalAddress.ZipCode;
                subcontractor.Country = supplier.PhysicalAddress.Country;
                subcontractor.Phone = supplier.Phone;
                subcontractor.Fax = supplier.Fax;
            }

            int transactionId = 0;
            if (supplier.SupplierWorkflows != null)
            {
                foreach (SupplierWorkflow sw in supplier.SupplierWorkflows)
                {
                    if (sw.WorkflowId == 2)
                        transactionId = sw.TransactionId;
                }
            }
            WorkflowHistoryCollection tempHistories = WorkflowHistoryUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                new object[] { transactionId });
            bool hasApproval = false;
            if (tempHistories != null)
            {
                foreach (WorkflowHistory wf in tempHistories)
                {
                    if (wf.CurrentNodeName == CertificationStatusType.DirectorApproved.Description)
                        hasApproval = true;
                }
            }
            bool pException = false;
            SupplierStatus certStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);
            if (certStatus != null)
            {
                if (certStatus.Status == CertificationStatusType.Certified.Description)
                    hasApproval = true;
                if (certStatus.Status == CertificationStatusType.CertAnalystClosed.Description ||
                    certStatus.Status == CertificationStatusType.CertClosed.Description ||
                    certStatus.Status == CertificationStatusType.Deny.Description ||
                    certStatus.Status == CertificationStatusType.Decertified.Description ||
                    certStatus.Status == CertificationStatusType.Disqualified.Description ||
                    certStatus.Status == CertificationStatusType.Withdrawn.Description ||
                    certStatus.Status == CertificationStatusType.Rescinded.Description ||
                    certStatus.Status == CertificationStatusType.Decertified.Description ||
                    certStatus.Status == CertificationStatusType.Expired.Description)
                    pException = true;
            }

            string[] classArray = new string[] { "MBE", "WBE", "LBE" };
            string[] classArrayValues = new string[] { "N", "N", "N" };

            string xml = "<ArrayOfDynamicProperty>";
            DynamicPropertyCollection types = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_OBJECT,
                new object[] { "SupplierStaticCertification", supplier.Id });
            if (types != null)
            {
                foreach (DynamicProperty property in types)
                {
                    xml += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"IsApplied\" />";
                    xml += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"IsRecommendedByDirector\" />";
                }
            }
            xml += "</ArrayOfDynamicProperty>";

            DynamicPropertyCollection properties = DynamicPropertyUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                DynamicPropertyManager.FIND_BY_PROPERTIES,
                new object[] { "SupplierStaticCertification", supplier.Id, xml });
            if (properties != null)
            {
                foreach (DynamicProperty property in properties)
                {
                    switch (property.PropertyName)
                    {
                        case "IsApplied":
                            if (property.PropertyText == "Y" && !pException)
                            {
                                switch (property.PropertyType)
                                {
                                    case "M":
                                        if (classArrayValues[0] != "Y")
                                            classArrayValues[0] = "P";
                                        break;
                                    case "W":
                                        if (classArrayValues[1] != "Y")
                                            classArrayValues[1] = "P";
                                        break;
                                    case "L":
                                        if (classArrayValues[2] != "Y")
                                            classArrayValues[2] = "P";
                                        break;
                                }
                            }
                            break;
                        case "IsRecommendedByDirector":
                            if (hasApproval)
                            {
                                switch (property.PropertyType)
                                {
                                    case "M":
                                        classArrayValues[0] = property.PropertyText;
                                        break;
                                    case "W":
                                        classArrayValues[1] = property.PropertyText;
                                        break;
                                    case "L":
                                        classArrayValues[2] = property.PropertyText;
                                        break;
                                }
                            }
                            break;
                    }
                }
            }
            subcontractor.Mbe = classArrayValues[0];
            subcontractor.Wbe = classArrayValues[1];
            subcontractor.Lbe = classArrayValues[2];

            subcontractor.WorkflowId = WorkflowExec.GetWorkflowId(ConstantUtility.WORKFLOW_SUBCONTRACTOR);

            if (SubcontractorUtility.Create(ConstantUtility.SUPPLIER_DATASOURCE_NAME, subcontractor))
            {
                // 20200225 PCH note: take last enterred License/Apprenticeship/Insurance etc from the same TaxId 
                SubcontractorUtility.Copy(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                    subcontractor.Id, supplier.FederalId);
            }

            #region pre-Populate SAF contact for known GC (lowest bidder) and SUB (selected wicks firm)
            // 20200225 PCH added logic to populate SAF contacts from Prime and Sub Vendor
            VendorContact gcContact = null;
            VendorContact subContact = null;

            Vendor gcVendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                "FederalId", prime.FederalId.Trim());
            VendorContactCollection gcContacts = VendorContactUtility.FindByCriteria(
                ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                VendorContactManager.FIND_CONTACT_BY_VENDOR,
                new object[] { gcVendor.Id});
            if (gcContacts != null) foreach(VendorContact c in gcContacts)
            {
                if (c.ContactType.Equals(VendorContactRoleType.SAF.Name))
                {
                    gcContact = c; break;
                }
            }
            if (gcContact == null) gcContact = gcVendor.PrimaryContact;

            Vendor subVendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                "FederalId", supplier.FederalId.Trim());
            VendorContactCollection subContacts = VendorContactUtility.FindByCriteria(
                ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                VendorContactManager.FIND_CONTACT_BY_VENDOR,
                new object[] { subVendor.Id });
            if (subContacts != null) foreach (VendorContact c in subContacts)
            {
                if (c.ContactType.Equals(VendorContactRoleType.SAF.Name))
                {
                    subContact = c; break;
                }
            }
            if (subContact == null) subContact = subVendor.PrimaryContact;

            SubcontractorPropertyCollection subcontractorProperties = new SubcontractorPropertyCollection();
            subcontractorProperties.Add(CommonUtility.CreateSubcontractorProperty(3, gcContact.Email));  // Prime SAF Contact Emal
            subcontractorProperties.Add(CommonUtility.CreateSubcontractorProperty(9, gcContact.Phone));  // Prime SAF Contact Phone
            subcontractorProperties.Add(CommonUtility.CreateSubcontractorProperty(43, gcContact.Name));  // Prime SAF Contact Name
            subcontractorProperties.Add(CommonUtility.CreateSubcontractorProperty(45, subContact.Id.ToString()));  // Subcontractor SAF Contact VendorContactId
            
            SubcontractorPropertyUtility.UpdateCollection(ConstantUtility.SUPPLIER_DATASOURCE_NAME, subcontractor.Id, subcontractorProperties);
            #endregion
            
            return subcontractor.Id;
        }

        public static void AddSAFUser(string userName, string roleName, int userId)
        {
            if (userName != null && userName.Trim().Length > 0)
            {
                CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, userName);
                if (cesUser != null)
                    AddUser(cesUser, roleName, "", userId);
            }
        }

        public static string GetSubcontractorStatus(SubcontractorStatusType statusType)
        {
            if (statusType == null) return "N/A";

            if (statusType.Id == SubcontractorStatusType.NewSubcontractor ||
                statusType.Id == SubcontractorStatusType.SubDeny ||
                statusType.Id == SubcontractorStatusType.SubApproved ||
                statusType.Id == SubcontractorStatusType.SubDisapproved ||
                statusType.Id == SubcontractorStatusType.SubInactive ||
                statusType.Id == SubcontractorStatusType.SubClosed)
                return statusType.Description;
            else
                return "Under Review";
        }
    }
}
