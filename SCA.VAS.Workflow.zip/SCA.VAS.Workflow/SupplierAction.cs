#region Copyright (C) 2006 - 2007 SCA.VAS USA, Inc.
///==========================================================================
/// Copyright (C) 2006 SCA.VAS USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of SupplierAction:
    /// Invite, CompleteRegistration, APReview, ApproveSuppier, RejectSupplier.
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(SupplierActionConverter))]
    public class SupplierAction : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly SupplierAction Invite = new SupplierAction(1, "Invite", "Invite Supplier");
        public static readonly SupplierAction CompleteRegistration = new SupplierAction(2, "CompleteRegistration", "Complete Registration");
        public static readonly SupplierAction CheckCertMissingItem = new SupplierAction(3, "CheckCertMissingItem", "Check Certification Missing Item");
        public static readonly SupplierAction SubmitMissingItem = new SupplierAction(4, "SubmitMissingItem", "Submit Missing Item");
        public static readonly SupplierAction CompleteCertification = new SupplierAction(5, "CompleteCertification", "Complete Certification Form");
        public static readonly SupplierAction CheckRegMissingItem = new SupplierAction(6, "CheckRegMissingItem", "Check Registration Missing Item");
        public static readonly SupplierAction SubmitCertMissingItem = new SupplierAction(7, "SubmitCertMissingItem", "Submit Certification Missing Item");
        public static readonly SupplierAction PredenyAction = new SupplierAction(8, "PredenyAction", "Pre Deny Action");
        public static readonly SupplierAction ManagerReview = new SupplierAction(9, "ManagerReview", "Manager Review");
        public static readonly SupplierAction ReviewerReview = new SupplierAction(10, "ReviewerReview", "Reviewer Review");
        public static readonly SupplierAction RequestMissItem = new SupplierAction(11, "RequestMissItem", "Request Missing Item");
        public static readonly SupplierAction ApproveMissItem = new SupplierAction(12, "ApproveMissItem", "Approve Missing Item");
        public static readonly SupplierAction RequestMissItem2 = new SupplierAction(13, "RequestMissItem2", "Request Missing Item 2");
        public static readonly SupplierAction ReferenceApprove = new SupplierAction(14, "ReferenceApprove", "Reference Approve");
        public static readonly SupplierAction ReferenceApprove2 = new SupplierAction(15, "ReferenceApprove2", "Reference Approve 2");
        public static readonly SupplierAction FinancialApprove = new SupplierAction(16, "FinancialApprove", "Financial Approve");
        public static readonly SupplierAction FinancialApprove2 = new SupplierAction(16, "FinancialApprove2", "Financial Approve 2");
        public static readonly SupplierAction OIGApprove = new SupplierAction(17, "OIGApprove", "OIG Approve");
        public static readonly SupplierAction OIGDeny = new SupplierAction(18, "OIGDeny", "OIG Deny");
        public static readonly SupplierAction DirectorApprove = new SupplierAction(19, "DirectorApprove", "Director Approve");
        public static readonly SupplierAction ReviewerApprove = new SupplierAction(20, "ReviewerApprove", "Reviewer Approve");
        public static readonly SupplierAction CertReviewerApprove = new SupplierAction(21, "CertReviewerApprove", "Cert Reviewer Approve");
        public static readonly SupplierAction CertRequestMissItem = new SupplierAction(22, "CertRequestMissItem", "Request Missing Item");
        public static readonly SupplierAction CertApproveMissItem = new SupplierAction(23, "CertApproveMissItem", "Cert Approve Missing Item");
        public static readonly SupplierAction CertRequestMissItem2 = new SupplierAction(24, "CertRequestMissItem2", "Cert Request Missing Item 2");
        public static readonly SupplierAction CertMWBEApprove = new SupplierAction(25, "CertMWBEApprove", "Cert MWBE Approve");
        public static readonly SupplierAction CertSupervisorApprove = new SupplierAction(26, "CertSupervisorApprove", "Cert Supervisor Approve");
        public static readonly SupplierAction CertDirectorApprove = new SupplierAction(27, "CertDirectorApprove", "Cert Director Approve");
        public static readonly SupplierAction TerminateApplication = new SupplierAction(28, "TerminateApplication", "Terminate Application");
        public static readonly SupplierAction NoFinancialReview = new SupplierAction(29, "NoFinancialReview", "No Financial Review");
        public static readonly SupplierAction CertFinalApprove = new SupplierAction(30, "CertFinalApprove", "Cert Final Approve");
        public static readonly SupplierAction TerminateApplication2 = new SupplierAction(31, "TerminateApplication2", "Terminate Application 2");
        public static readonly SupplierAction MentorSupplierInterest = new SupplierAction(32, "MentorSupplierInterest", "Mentor Supplier Interest");
        public static readonly SupplierAction MentorSupplierDeny = new SupplierAction(33, "MentorSupplierDeny", "Mentor Supplier Deny");
        public static readonly SupplierAction MentorInterviewApprove = new SupplierAction(34, "MentorInterviewApprove", "Mentor Interview Approve");
        public static readonly SupplierAction MentorUploadAgreement = new SupplierAction(35, "MentorUploadAgreement", "Mentor Upload Agreement");
        public static readonly SupplierAction MentorFinalApprove = new SupplierAction(36, "MentorFinalApprove", "Mentor Final Approve");
        public static readonly SupplierAction AmendedTradeCodeSubmit = new SupplierAction(37, "AmendedTradeCodeSubmit", "Amended TradeCode Submit");
        public static readonly SupplierAction AmendedTradeCodeManagerReview = new SupplierAction(38, "AmendedTradeCodeManagerReview", "Amended Trade Code Manager Review");
        public static readonly SupplierAction AmendedTradeCodeReviewerReview = new SupplierAction(39, "AmendedTradeCodeReviewerReview", "Amended Trade Code Reviewer Review");
        public static readonly SupplierAction AmendedTradeCodeMoreInfo = new SupplierAction(40, "AmendedTradeCodeMoreInfo", "Amended Trade Code More Info");
        public static readonly SupplierAction AmendedTradeCodeInfoSubmit = new SupplierAction(41, "AmendedTradeCodeInfoSubmit", "Amended Trade Code Info Submit");
        public static readonly SupplierAction AmendedTradeCodeApprove = new SupplierAction(42, "AmendedTradeCodeApprove", "Amended Trade Code Approve");
        public static readonly SupplierAction MentorNew = new SupplierAction(43, "MentorNew", "New Mentor Supplier");
        public static readonly SupplierAction KeyChangeSubmit = new SupplierAction(44, "KeyChangeSubmit", "Key Change Submit");
        public static readonly SupplierAction KeyOIGApprove = new SupplierAction(45, "KeyOIGApprove", "Key OIG Approve");
        public static readonly SupplierAction Over1MMSubmit = new SupplierAction(46, "Over1MMSubmit", "Over 1MM Submit");
        public static readonly SupplierAction Over1MMReferenceApprove = new SupplierAction(47, "Over1MMReferenceApprove", "Over 1MM Reference Approve");
        public static readonly SupplierAction Over1MMReferenceApprove2 = new SupplierAction(48, "Over1MMReferenceApprove2", "Over 1MM Reference Approve 2");
        public static readonly SupplierAction Over1MMFinancialApprove = new SupplierAction(49, "Over1MMFinancialApprove", "Over 1MM Financial Approve");
        public static readonly SupplierAction Over1MMFinancialApprove2 = new SupplierAction(50, "Over1MMFinancialApprove2", "Over 1MM Financial Approve 2");
        public static readonly SupplierAction Over1MMReviewerApprove = new SupplierAction(51, "Over1MMReviewerApprove", "Over 1MM Reviewer Approve");
        public static readonly SupplierAction Over1MMManagerApprove = new SupplierAction(52, "Over1MMManagerApprove", "Over 1MM Manager Approve");
        public static readonly SupplierAction OIGResponse = new SupplierAction(53, "OIGResponse", "OIG Response");
        public static readonly SupplierAction QualWithdraw = new SupplierAction(54, "QualWithdraw", "QualWithdraw");
        public static readonly SupplierAction QualRescind = new SupplierAction(55, "QualRescind", "QualRescind");
        public static readonly SupplierAction QualDisqualify = new SupplierAction(56, "QualDisqualify", "QualDisqualify");
        public static readonly SupplierAction QualSuspend = new SupplierAction(57, "QualSuspend", "QualSuspend");
        public static readonly SupplierAction QualAdminClose = new SupplierAction(58, "QualAdminClose", "QualAdminClose");
        public static readonly SupplierAction QualDeny = new SupplierAction(59, "QualDeny", "QualDeny");
        public static readonly SupplierAction QualReopen = new SupplierAction(60, "QualReopen", "QualReopen");
        public static readonly SupplierAction CertWithdraw = new SupplierAction(61, "CertWithdraw", "CertWithdraw");
        public static readonly SupplierAction CertRescind = new SupplierAction(62, "CertRescind", "CertRescind");
        public static readonly SupplierAction CertDecertify = new SupplierAction(63, "CertDecertify", "CertDecertify");
        public static readonly SupplierAction MentorSuspend = new SupplierAction(64, "MentorSuspend", "MentorSuspend");
        public static readonly SupplierAction CertAdminClose = new SupplierAction(65, "CertAdminClose", "CertAdminClose");
        public static readonly SupplierAction CertDeny = new SupplierAction(66, "CertDeny", "CertDeny");
        public static readonly SupplierAction CertReopen = new SupplierAction(67, "CertReopen", "CertReopen");
        public static readonly SupplierAction Over1MMFinalApprove = new SupplierAction(68, "Over1MMFinalApprove", "Over 1MM Final Approve");
        public static readonly SupplierAction SubmitMissingItem2 = new SupplierAction(69, "SubmitMissingItem2", "Submit Missing Item 2");
        public static readonly SupplierAction SubmitCertMissingItem2 = new SupplierAction(70, "SubmitCertMissingItem2", "Submit Certification Missing Item 2");
        public static readonly SupplierAction ApproveMissItem2 = new SupplierAction(71, "ApproveMissItem2", "Approve Missing Item 2");
        public static readonly SupplierAction CertApproveMissItem2 = new SupplierAction(72, "CertApproveMissItem2", "Cert Approve Missing Item 2");
        public static readonly SupplierAction TransferDataCMS = new SupplierAction(73, "TransferDataCMS", "Transfer Data CMS");
        public static readonly SupplierAction CertAssignAnalyst = new SupplierAction(74, "CertAssignAnalyst", "Cert Assign Analyst");
        public static readonly SupplierAction AmendQual = new SupplierAction(75, "AmendQual", "Amend New Qualification");
        public static readonly SupplierAction AmendCert = new SupplierAction(76, "AmendCert", "Amend New Certification");
        public static readonly SupplierAction QualExpire = new SupplierAction(77, "QualExpire", "QualExpire");
        public static readonly SupplierAction CertExpire = new SupplierAction(78, "CertExpire", "CertExpire");
        public static readonly SupplierAction CertInterviewRecommended = new SupplierAction(79, "CertInterviewRecommended", "Cert Interview Recommended");
        public static readonly SupplierAction CertConditionApprove = new SupplierAction(80, "CertConditionApprove", "Cert Condition Approve");
        public static readonly SupplierAction CertConditionFinalApprove = new SupplierAction(81, "CertConditionFinalApprove", "Cert Condition Final Approve");
        public static readonly SupplierAction KeyOIGLetterOfConcernAction = new SupplierAction(82, "KeyOIGLetterOfConcernAction", "KeyOIGLetterOfConcernAction");
        public static readonly SupplierAction OIGPendingAction = new SupplierAction(83, "OIGPendingAction", "OIG Pending Action");
        public static readonly SupplierAction OIGPendingApprove = new SupplierAction(84, "OIGPendingApprove", "OIG Pending Approve");
        public static readonly SupplierAction OIGChangeAction = new SupplierAction(85, "OIGChangeAction", "OIG Change Action");
        public static readonly SupplierAction Cert30DayLetter = new SupplierAction(86, "Cert30DayLetter", "Cert 30 Day Letter");
        public static readonly SupplierAction AdministrativelyClosedAutomatic = new SupplierAction(87, "AdministrativelyClosedAutomatic", "Administratively Closed Automatic");
        public static readonly SupplierAction QualReopenNotifyCert = new SupplierAction(88, "QualReopenNotifyCert", "Qual Reopen Notify Cert");
        public static readonly SupplierAction AppendixAPending = new SupplierAction(89, "AppendixAPending", "Appendix A Pending");
        

        public static readonly SupplierAction OIGIncompleteAction = new SupplierAction(201, "OIGIncompleteAction", "OIG Incomplete Action");
        public static readonly SupplierAction OIGCompleteAction = new SupplierAction(202, "OIGCompleteAction", "OIG Complete Action");
        public static readonly SupplierAction OIGOIGReviewAction = new SupplierAction(203, "OIGOIGReviewAction", "OIG OIG Review Action");
        public static readonly SupplierAction OIGOIGApproveAction = new SupplierAction(204, "OIGOIGApproveAction", "OIG OIG Approve Action");

        public static readonly SupplierAction QualIneligible = new SupplierAction(90, "QualIneligible", "QualIneligible");
        public static readonly SupplierAction CertIneligible = new SupplierAction(205, "CertIneligible", "CertIneligible");

        public static readonly SupplierAction CertificationAppeal = new SupplierAction(206, "CertificationAppeal", "CertificationAppeal");

        public static readonly SupplierAction AppealAction = new SupplierAction(207, "AppealAction", "AppealAction");
        public static readonly SupplierAction AppealDecisionEmail = new SupplierAction(208, "AppealDecisionEmail", "AppealDecisionEmail");
        public static readonly SupplierAction SendCertificationEmail = new SupplierAction(209, "SendCertificationEmail", "Send Certification Email");

        #endregion

        #region Constructors
        public SupplierAction()
        {
        }

        private SupplierAction(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in SupplierAction class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of SupplierAction.  
        /// </summary>
        public static SupplierAction Default
        {
            get
            {
                return (SupplierAction)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for SupplierAction class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a SupplierAction object.
        /// It allows a string to be assigned to a SupplierAction object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator SupplierAction(int id)
        {
            return (SupplierAction)EnumerationBase.FindById(id, SupplierAction._list);
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and SupplierAction objects.
    /// It's very useful when binding SupplierAction objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class SupplierActionConverter : TypeConverter
    {

        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, SupplierAction._list);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the SupplierAction enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < SupplierAction._list.Count; i++)
            {
                list.Add(((SupplierAction)SupplierAction._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }

    public class WorkflowSession
    {
        #region Private Membe
        private string _url;
        private int _supplierId;
        private string _type;
        #endregion Private Membe

        public WorkflowSession(string url, int supplierId, string type)
        {
            _url = url;
            _supplierId = supplierId;
            _type = type;
        }

        #region Public Property
        public string Url
        {
            get { return this._url; }
            set { this._url = value; }
        }
        public int SupplierId
        {
            get { return this._supplierId; }
            set { this._supplierId = value; }
        }
        public string Type
        {
            get { return this._type; }
            set { this._type = value; }
        }
        #endregion Public Property
    }

}
