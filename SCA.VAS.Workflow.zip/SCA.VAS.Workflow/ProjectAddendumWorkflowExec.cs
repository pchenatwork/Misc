#region Copyright
/*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Configuration;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

namespace SCA.VAS.Workflow
{
    public class ProjectAddendumWorkflowExec
    {
        #region Private Member
        private static string prefixDbName = string.Empty;
        private static int userId = 0;
        private static string workflowType = string.Empty;
        public static string WorkflowType
        {
            set { workflowType = value; }
        }
        #endregion

        #region Constructor
        public ProjectAddendumWorkflowExec()
        {
        }
        static ProjectAddendumWorkflowExec()
        {
        }
        #endregion Constructor

        #region Private Method
        private static ProjectAddendum GetProjectAddendum(ProjectAddendum projectAddendum)
        {
            if (projectAddendum == null) return null;
            if (projectAddendum.TransactionId == 0)
            {
                WorkflowList workflow = WorkflowListUtility.GetByName(
                    prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                    workflowType, 0);
                if (workflow != null)
                {
                    projectAddendum.WorkflowId = workflow.Id;
                    projectAddendum.TransactionId = WorkflowExec.CreateWorkflowHistory(projectAddendum.WorkflowId);
                    ProjectAddendumUtility.Update(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME, projectAddendum);
                    ProjectAddendumUtility.UpdateTransactionId(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                        projectAddendum.Id, projectAddendum.TransactionId);
                    NodeAction(projectAddendum, "New Workflow");
                }
            }
            return projectAddendum;
        }
        #endregion

        #region Workflow Control
        public static ProjectAddendum InitialProjectAddendum(ProjectAddendum projectAddendum, string workflowName)
        {
            workflowType = workflowName;
            return GetProjectAddendum(projectAddendum);
        }

        public static User GetLastApprover(ProjectAddendum projectAddendum)
        {
            projectAddendum = GetProjectAddendum(projectAddendum);
            if (projectAddendum == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectAddendum.TransactionId);
            if (workflowHistory == null) return null;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return null;

            return UserUtility.Get(prefixDbName + ConstantUtility.USER_DATASOURCE_NAME,
                workflowHistory.ApprovalUserId);
        }

        public static int ProjectAddendumWorkflow(ProjectAddendum projectAddendum, string systemAction, string comments, ref string errmsg, ref string url)
        {
            projectAddendum = GetProjectAddendum(projectAddendum);
            if (projectAddendum == null) return 0;

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_SYSTEMNAME,
                new object[] { projectAddendum.WorkflowId, systemAction });
            if (workflowNodes == null || workflowNodes.Count == 0) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectAddendum.TransactionId);
            if (workflowHistory == null)
                return 0;

            int actionId = 0;
            for (int i = 0; i < workflowNodes.Count; i++)
            {
                if (workflowHistory.CurrentNodeId == workflowNodes[i].NodeFromId)
                {
                    actionId = workflowNodes[i].Id;
                    break;
                }
            }
            return ProjectAddendumWorkflow(projectAddendum, actionId, comments, ref errmsg, ref url);
        }

        public static int ProjectAddendumWorkflow(ProjectAddendum projectAddendum, int actionId, string comments, ref string errmsg, ref string url)
        {
            projectAddendum = GetProjectAddendum(projectAddendum);
            if (projectAddendum == null || actionId == 0) return projectAddendum.TransactionId;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectAddendum.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowNode workflowNode = WorkflowNodeUtility.Get(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
            if (workflowNode == null)
                return 0;
            if (workflowHistory.CurrentNodeId != workflowNode.NodeFromId)
                return 0;

            // condition proccessing
            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNode.Id });

            TextReader reader = XmlUtility.Serialize(projectAddendum);
            XPathDocument doc = new XPathDocument(reader);
            XPathNavigator nav = doc.CreateNavigator();

            errmsg = string.Empty;
            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count == 0)
                    {
                        errmsg += workflowCondition.ErrorMessage + "<br>";
                    }
                }
            }
            if (errmsg != string.Empty) return 0;

            //Workflow topologic
            bool approval = true;
            switch (workflowNode.Action1)
            {
                case "One":
                    break;
                case "Owner":
                    //if (projectAddendum.BuyerId != userId)
                    //    errmsg = "Only RFx owner / Creator can do this step";
                    break;
                case "All":
                case "Majority":
                case "Count":
                    WorkflowHistoryCollection workflowHistories = WorkflowHistoryUtility.FindByCriteria(
                        prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                        new object[] { projectAddendum.TransactionId });

                    WorkflowHistoryCollection currentHistories = new WorkflowHistoryCollection();
                    if (workflowHistories != null)
                    {
                        for (int i = workflowHistories.Count - 1; i >= 0; i--)
                        {
                            if (workflowHistories[i].IsActive == 1) break;
                            if (workflowHistories[i].CurrentNodeId != actionId) continue;
                            if (workflowHistories[i].ApprovalUserId == userId)
                            {
                                errmsg = "You already approved this step";
                                return 0;
                            }
                            currentHistories.Add(workflowHistories[i]);
                        }
                    }

                    // Create a history from new approval
                    WorkflowHistory approvalHistory = WorkflowHistoryUtility.CreateObject();
                    approvalHistory.TransactionHeaderId = projectAddendum.TransactionId;
                    approvalHistory.WorkflowId = projectAddendum.WorkflowId;
                    approvalHistory.CurrentNodeId = actionId;
                    approvalHistory.ApprovalUserId = WorkflowExec.GetUserId();
                    approvalHistory.ApprovalConditionId = 1;
                    approvalHistory.CreatedBy = workflowHistory.ApprovalUserId;
                    approvalHistory.CreatedType = WorkflowExec.GetUserType();
                    WorkflowHistoryUtility.Create(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, approvalHistory);

                    int approvalKnt = currentHistories.Count + 1;
                    switch (workflowNode.Action1)
                    {
                        case "All":
                            //if (approvalKnt < projectAddendumUsers.Count)
                            //    approval = false;
                            break;
                        case "Majority":
                            //if (approvalKnt < projectAddendumUsers.Count / 2)
                            //    approval = false;
                            break;
                        case "Count":
                            int knt = ConvertUtility.ConvertInt(workflowNode.Action2);
                            if (approvalKnt < knt)
                                approval = false;
                            break;
                    }
                    break;

                //case "Sequence":
                //    break;
                //case "Timer":
                //    //approve7.Checked = true;
                //    //approveKnt7.Text = workflowNode.Action2;
                //    break;
            }

            if (!approval || errmsg != string.Empty) return projectAddendum.TransactionId;

            //Action proccessing
            WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE,
                new object[] { workflowNode.Id });

            if (workflowActions != null)
            {
                foreach (WorkflowAction workflowAction in workflowActions)
                {
                    switch (workflowAction.Type)
                    {
                        //Send Email
                        case 1:
                            break;

                        //Action
                        case 2:
                            ProjectAddendumAction(projectAddendum, workflowAction.FunctionName);
                            break;

                        //Redirect page
                        case 3:
                            url = workflowAction.FunctionName;
                            break;
                    }
                }
            }

            if (workflowNode.NodeToId > 0)
            {
                WorkflowNode nextNode = WorkflowNodeUtility.Get(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode.NodeToId);
                WorkflowExec.WorkflowNextStatus(workflowNode.WorkflowId, nextNode.Name, workflowHistory.CurrentNodeId, projectAddendum.TransactionId, comments);

                //if (comments.Trim() != string.Empty)
                //{
                //    Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.RFD_DATASOURCE_NAME,
                //        "ProjectAddendum", projectAddendum.Id.ToString());
                //    User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

                //    VendorComment vendorComment = VendorCommentUtility.CreateObject();
                //    vendorComment.UserId = user.Id;
                //    vendorComment.VendorId = vendor.Id;
                //    vendorComment.Comments = "Workflow Comments: " + comments;
                //    vendorComment.Type = "User";
                //    vendorComment.ChangeUser = user.FullName;

                //    VendorCommentUtility.Create(ConstantUtility.RFD_DATASOURCE_NAME, vendorComment);
                //}

                NodeAction(projectAddendum, comments);
            }

            return projectAddendum.TransactionId;
        }

        public static int ProjectAddendumWorkflow(ProjectAddendum projectAddendum, string nextStatus, string comments)
        {
            projectAddendum = GetProjectAddendum(projectAddendum);
            if (projectAddendum == null) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectAddendum.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowExec.WorkflowNextSystemStatus(projectAddendum.WorkflowId, nextStatus, workflowHistory.CurrentNodeId, projectAddendum.TransactionId, comments);

            //if (comments.Trim() != string.Empty)
            //{
            //    Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.RFD_DATASOURCE_NAME,
            //        "ProjectAddendum", projectAddendum.Id.ToString());
            //    User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

            //    VendorComment vendorComment = VendorCommentUtility.CreateObject();
            //    vendorComment.VendorId = vendor.Id;
            //    vendorComment.Comments = "Workflow Comments: " + comments;
            //    if (user != null)
            //    {
            //        vendorComment.UserId = user.Id;
            //        vendorComment.Type = "User";
            //        vendorComment.ChangeUser = user.FullName;
            //    }

            //    VendorCommentUtility.Create(ConstantUtility.RFD_DATASOURCE_NAME, vendorComment);
            //}

            NodeAction(projectAddendum, comments);

            return projectAddendum.TransactionId;
        }

        public static WorkflowConditionCollection ProjectAddendumConditionTest(ProjectAddendum projectAddendum, int workflowNodeId)
        {
            projectAddendum = GetProjectAddendum(projectAddendum);
            if (projectAddendum == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectAddendum.TransactionId);
            if (workflowHistory == null)
                return null;

            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNodeId });

            XPathDocument doc = new XPathDocument(XmlUtility.Serialize(projectAddendum));
            XPathNavigator nav = doc.CreateNavigator();

            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count > 0)
                        workflowCondition.Status = 1;
                }
            }
            return workflowConditions;
        }
        #endregion Workflow Control

        #region Workflow Node Action
        private static void NodeAction(ProjectAddendum projectAddendum, string comments)
        {
            projectAddendum = GetProjectAddendum(projectAddendum);
            if (projectAddendum == null) return;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(
                projectAddendum.TransactionId);

            int status = CommonUtility.GetProjectStatusId(workflowType, workflowHistory.CurrentNode.Name.Trim());
            //switch (workflowType)
            //{
            //    case ConstantUtility.WORKFLOW_BID_AWARD_GENERAL:
            //        ProjectAddendumBidAwardStatusType projectAddendumBidAwardStatusType = workflowHistory.CurrentNode.Name.Trim();
            //        if (projectAddendumBidAwardStatusType != null)
            //            status = projectAddendumBidAwardStatusType.Id;
            //        break;
            //}

            if (status == 0 || status == projectAddendum.Status) return;
            //ProjectAddendumUtility.UpdateStatus(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME, projectAddendum.Id, status);
            projectAddendum.Status = status;
            projectAddendum.StatusName = ((ProjectAddendumStatusType)status).Description;
            ProjectAddendumUtility.UpdateStatus(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME, projectAddendum.Id, status,
                projectAddendum.StatusName);

            // automatic step
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { projectAddendum.WorkflowId, "UserStepId", "ASC" });
            if (workflowNodes != null)
            {
                for (int i = 0; i < workflowNodes.Count; i++)
                {
                    if (workflowNodes[i].Type != 1 || workflowNodes[i].TimeToSkip != 1 ||
                        workflowHistory.CurrentNodeId != workflowNodes[i].NodeFromId)
                        continue;

                    string errmsg = string.Empty;
                    string url = string.Empty;
                    ProjectAddendumWorkflow(projectAddendum, workflowNodes[i].Id, comments, ref errmsg, ref url);
                }
            }
        }
        #endregion Workflow Node Action

        #region Batch Jobs
        #endregion Batch Jobs

        #region ProjectAddendum Action
        private static void ProjectAddendumAction(ProjectAddendum projectAddendum, string actionName)
        {
            string msg = string.Empty;
            string url = string.Empty;
            string tempType = workflowType;

            switch (actionName)
            {
                case "SampleAction":
                    //Action Here
                    break;
            }
            WorkflowType = tempType;
        }
        #endregion
    }
}
