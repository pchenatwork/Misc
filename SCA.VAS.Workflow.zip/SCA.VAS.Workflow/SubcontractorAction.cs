#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of SubcontractorAction:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(SubcontractorActionConverter))]
    public class SubcontractorAction : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly SubcontractorAction SubSubmitApplication = new SubcontractorAction(1, "SubSubmitApplication", "Subcontractor Submit Application");
        public static readonly SubcontractorAction SubReviewSubcontractor = new SubcontractorAction(2, "SubReviewSubcontractor", "Subcontractor Review Subcontractor");
        public static readonly SubcontractorAction SubcontractorSignForm = new SubcontractorAction(3, "SubcontractorSignForm", "Subcontractor Sign Form");
        public static readonly SubcontractorAction SubVASInternalPrepare = new SubcontractorAction(4, "SubVASInternalPrepare", "Subcontractor VAS Internal Prepare");
        public static readonly SubcontractorAction SubCompleteCertification = new SubcontractorAction(5, "SubCompleteCertification", "Subcontractor Complete Certification Form");
        public static readonly SubcontractorAction SubManagerReview = new SubcontractorAction(6, "SubManagerReview", "Subcontractor Manager Review");
        public static readonly SubcontractorAction SubReviewerVet = new SubcontractorAction(7, "SubReviewerVet", "Subcontractor Reviewer Vet");
        public static readonly SubcontractorAction SubRequestMissItem = new SubcontractorAction(8, "SubRequestMissItem", "Subcontractor Request Missing Item");
        public static readonly SubcontractorAction SubSubmitMissItem = new SubcontractorAction(9, "SubSubmitMissItem", "Subcontractor Submit Missing Item");
        public static readonly SubcontractorAction SubManagerAssign = new SubcontractorAction(10, "SubManagerAssign", "Subcontractor Manager Assign Reviewer");
        public static readonly SubcontractorAction SubReviewerRecommend = new SubcontractorAction(11, "SubeviewerRecommend", "Subcontractor Reviewer Recommend");
        public static readonly SubcontractorAction SubCQUApprove = new SubcontractorAction(12, "SubCQUApprove", "Subcontractor CQU Approve");
        public static readonly SubcontractorAction SubOIGApprove = new SubcontractorAction(13, "SubOIGApprove", "Subcontractor OIG Approve");
        public static readonly SubcontractorAction SubNoSupplierIdAction = new SubcontractorAction(14, "SubNoSupplierIdAction", "Subcontractor No SupplierId Action");
        public static readonly SubcontractorAction SubPendingAction = new SubcontractorAction(15, "SubPendingAction", "Subcontractor Pending Action");
        public static readonly SubcontractorAction SubApprovePending = new SubcontractorAction(16, "SubApprovePending", "Subcontractor Approve Pending");
        public static readonly SubcontractorAction SubWillisAction = new SubcontractorAction(17, "SubWillisAction", "Subcontractor Willis Action");
        public static readonly SubcontractorAction SubPendingNotify = new SubcontractorAction(18, "SubPendingNotify", "Subcontractor Pending Notify");
        public static readonly SubcontractorAction SubMoreInfoApprove = new SubcontractorAction(19, "SubMoreInfoApprove", "Subcontractor MoreInfo Approve");
        public static readonly SubcontractorAction SubOIGDenyAction = new SubcontractorAction(20, "SubOIGDenyAction", "Subcontractor OIG Deny Action");
        public static readonly SubcontractorAction SubReviewerDenyAction = new SubcontractorAction(21, "SubReviewerDenyAction", "Subcontractor Reviewer Deny Action");
        public static readonly SubcontractorAction SubOIGReviewedPendingAction = new SubcontractorAction(22, "SubOIGReviewedPendingAction", "Subcontractor OIG Reviewed Pending Action");
        public static readonly SubcontractorAction SubReviewerApproveAction = new SubcontractorAction(23, "SubReviewerApproveAction", "Subcontractor Reviewer Approve Action");
        public static readonly SubcontractorAction SubOIGManagerDenyAction = new SubcontractorAction(24, "SubOIGManagerDenyAction", "Subcontractor OIG Manager Deny Action");
        public static readonly SubcontractorAction SubInsuranceEntryComplete = new SubcontractorAction(25, "SubInsuranceEntryComplete", "Subcontractor Insurance Entry Complete");
        public static readonly SubcontractorAction SubManagerFinalApprove = new SubcontractorAction(26, "SubManagerFinalApprove", "Subcontractor Manager Final Approve");
        public static readonly SubcontractorAction SubManagerFinalApprove2 = new SubcontractorAction(27, "SubManagerFinalApprove2", "Subcontractor Manager Final Approve 2");
        //public static readonly SubcontractorAction SubOIGDenyAction2 = new SubcontractorAction(26, "SubOIGDenyAction2", "Subcontractor OIG Deny Action 2");
        //public static readonly SubcontractorAction SubOIGReviewedPendingAction2 = new SubcontractorAction(27, "SubOIGReviewedPendingAction2", "Subcontractor OIG Reviewed Pending Action 2");
        //public static readonly SubcontractorAction SubReviewerApproveAction2 = new SubcontractorAction(28, "SubReviewerApproveAction2", "Subcontractor Reviewer Approve Action 2");
        //public static readonly SubcontractorAction SubOIGApprove2 = new SubcontractorAction(29, "SubOIGApprove2", "Subcontractor OIG Approve 2");

        public static readonly SubcontractorAction SubSendEmailAction = new SubcontractorAction(28, "SubSendEmailAction", "Subcontractor Send Email Action");

        #endregion  

        #region Constructors
        public SubcontractorAction()
        {
        }

        private SubcontractorAction(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in SubcontractorAction class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of SubcontractorAction.  
        /// </summary>
        public static SubcontractorAction Default
        {
            get
            {
                return (SubcontractorAction)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for SubcontractorAction class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a SubcontractorAction object.
        /// It allows a string to be assigned to a SubcontractorAction object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator SubcontractorAction(int id)
        {
            return (SubcontractorAction)EnumerationBase.FindById(id, SubcontractorAction._list);
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and SubcontractorAction objects.
    /// It's very useful when binding SubcontractorAction objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class SubcontractorActionConverter : TypeConverter
    {

        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, SubcontractorAction._list);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the SubcontractorAction enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < SubcontractorAction._list.Count; i++)
            {
                list.Add(((SubcontractorAction)SubcontractorAction._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }

}
