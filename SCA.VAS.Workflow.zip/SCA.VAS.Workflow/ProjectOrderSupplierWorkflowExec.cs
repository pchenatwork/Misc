#region Copyright
/*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Configuration;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

using SCA.VAS.BusinessLogic.Template.Utilities;
using SCA.VAS.BusinessLogic.Template;
using SCA.VAS.ValueObjects.Template;

using RfcProject = SCA.VAS.ValueObjects.Rfd.Project;
using RfcProjectUtility = SCA.VAS.BusinessLogic.Rfd.Utilities.ProjectUtility;
using ProjectOrderSupplier = SCA.VAS.ValueObjects.Rfd.ProjectOrderSupplier;
using ProjectOrderSupplierUtility = SCA.VAS.BusinessLogic.Rfd.Utilities.ProjectOrderSupplierUtility;
#endregion Reference

namespace SCA.VAS.Workflow
{
    public class ProjectOrderSupplierWorkflowExec
    {
        #region Private Member
        private static string prefixDbName = string.Empty;
        private static int userId = 0;
        private static string workflowType = ConstantUtility.WORKFLOW_BID_REPRODUCTION_ORDER_SUPPLIER;
        public static string WorkflowType
        {
            set { workflowType = value; }
        }
        #endregion

        #region Constructor
        public ProjectOrderSupplierWorkflowExec()
        {
        }
        static ProjectOrderSupplierWorkflowExec()
        {
        }
        #endregion Constructor

        #region Private Method
        private static ProjectOrderSupplier GetProjectOrderSupplierWorkflow(ProjectOrderSupplier projectOrderSupplier)
        {
            if (projectOrderSupplier == null) return projectOrderSupplier;

            if (projectOrderSupplier.WorkflowId == 0)
            {
                WorkflowList workflow = WorkflowListUtility.GetByName(
                    prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                    workflowType, 0);
                if (workflow != null) 
                    projectOrderSupplier.WorkflowId = workflow.Id;
            }

            if (projectOrderSupplier.TransactionId == 0)
            {
                projectOrderSupplier.TransactionId = WorkflowExec.CreateWorkflowHistory(projectOrderSupplier.WorkflowId);
                ProjectOrderSupplierUtility.UpdateTransactionId(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                    projectOrderSupplier.Id, projectOrderSupplier.TransactionId);

                NodeAction(projectOrderSupplier, "New Workflow");
            }
            return projectOrderSupplier;
        }
        #endregion

        #region Workflow Control
        public static ProjectOrderSupplier InitialProjectOrderSupplierWorkflow(ProjectOrderSupplier projectOrderSupplier, string workflowName)
        {
            workflowType = workflowName;
            return GetProjectOrderSupplierWorkflow(projectOrderSupplier);
        }

        public static User GetLastApprover(ProjectOrderSupplier projectOrderSupplier)
        {
            projectOrderSupplier = GetProjectOrderSupplierWorkflow(projectOrderSupplier);
            if (projectOrderSupplier == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectOrderSupplier.TransactionId);
            if (workflowHistory == null) return null;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return null;

            return UserUtility.Get(prefixDbName + ConstantUtility.USER_DATASOURCE_NAME,
                workflowHistory.ApprovalUserId);
        }

        public static int ProjectOrderSupplierWorkflow(ProjectOrderSupplier projectOrderSupplier, string systemAction, string comments, ref string errmsg, ref string url)
        {
            projectOrderSupplier = GetProjectOrderSupplierWorkflow(projectOrderSupplier);
            if (projectOrderSupplier == null) return 0;

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_SYSTEMNAME,
                new object[] { projectOrderSupplier.WorkflowId, systemAction });
            if (workflowNodes == null || workflowNodes.Count == 0) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectOrderSupplier.TransactionId);
            if (workflowHistory == null)
                return 0;

            int actionId = 0;
            for (int i = 0; i < workflowNodes.Count; i++)
            {
                if (workflowHistory.CurrentNodeId == workflowNodes[i].NodeFromId)
                {
                    actionId = workflowNodes[i].Id;
                    break;
                }
            }
            return ProjectOrderSupplierWorkflow(projectOrderSupplier, actionId, comments, ref errmsg, ref url);
        }

        public static int ProjectOrderSupplierWorkflow(ProjectOrderSupplier projectOrderSupplier, int actionId, string comments, ref string errmsg, ref string url)
        {
            projectOrderSupplier = GetProjectOrderSupplierWorkflow(projectOrderSupplier);
            if (projectOrderSupplier == null) return 0;
            if (actionId == 0) return projectOrderSupplier.TransactionId;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectOrderSupplier.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowNode workflowNode = WorkflowNodeUtility.Get(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
            if (workflowNode == null)
                return 0;
            if (workflowHistory.CurrentNodeId != workflowNode.NodeFromId)
                return 0;

            // condition proccessing
            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNode.Id });

            TextReader reader = XmlUtility.Serialize(projectOrderSupplier);
            XPathDocument doc = new XPathDocument(reader);
            XPathNavigator nav = doc.CreateNavigator();

            errmsg = string.Empty;
            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count == 0)
                    {
                        errmsg += workflowCondition.ErrorMessage + "<br>";
                    }
                }
            }
            if (errmsg != string.Empty) return 0;

            //Workflow topologic
            bool approval = true;
            switch (workflowNode.Action1)
            {
                case "One":
                    break;
                case "Owner":
                    //if (projectOrderSupplier.BuyerId != userId)
                    //    errmsg = "Only RFx owner / Creator can do this step";
                    break;
                case "All":
                case "Majority":
                case "Count":
                    WorkflowHistoryCollection workflowHistories = WorkflowHistoryUtility.FindByCriteria(
                        prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                        new object[] { projectOrderSupplier.TransactionId });

                    WorkflowHistoryCollection currentHistories = new WorkflowHistoryCollection();
                    if (workflowHistories != null)
                    {
                        for (int i = workflowHistories.Count - 1; i >= 0; i--)
                        {
                            if (workflowHistories[i].IsActive == 1) break;
                            if (workflowHistories[i].CurrentNodeId != actionId) continue;
                            if (workflowHistories[i].ApprovalUserId == userId)
                            {
                                errmsg = "You already approved this step";
                                return 0;
                            }
                            currentHistories.Add(workflowHistories[i]);
                        }
                    }

                    // Create a history from new approval
                    WorkflowHistory approvalHistory = WorkflowHistoryUtility.CreateObject();
                    approvalHistory.TransactionHeaderId = projectOrderSupplier.TransactionId;
                    approvalHistory.WorkflowId = projectOrderSupplier.WorkflowId;
                    approvalHistory.CurrentNodeId = actionId;
                    approvalHistory.ApprovalUserId = WorkflowExec.GetUserId();
                    approvalHistory.ApprovalConditionId = 1;
                    approvalHistory.CreatedBy = workflowHistory.ApprovalUserId;
                    approvalHistory.CreatedType = WorkflowExec.GetUserType();
                    WorkflowHistoryUtility.Create(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, approvalHistory);

                    int approvalKnt = currentHistories.Count + 1;
                    switch (workflowNode.Action1)
                    {
                        case "All":
                            //if (approvalKnt < projectOrderSupplierUsers.Count)
                            //    approval = false;
                            break;
                        case "Majority":
                            //if (approvalKnt < projectOrderSupplierUsers.Count / 2)
                            //    approval = false;
                            break;
                        case "Count":
                            int knt = ConvertUtility.ConvertInt(workflowNode.Action2);
                            if (approvalKnt < knt)
                                approval = false;
                            break;
                    }
                    break;

                //case "Sequence":
                //    break;
                //case "Timer":
                //    //approve7.Checked = true;
                //    //approveKnt7.Text = workflowNode.Action2;
                //    break;
            }

            if (!approval || errmsg != string.Empty) return projectOrderSupplier.TransactionId;

            //Action proccessing
            WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE,
                new object[] { workflowNode.Id });

            if (workflowActions != null)
            {
                foreach (WorkflowAction workflowAction in workflowActions)
                {
                    switch (workflowAction.Type)
                    {
                        //Send Email
                        case 1:
                            break;

                        //Action
                        case 2:
                            ProjectOrderSupplierAction(projectOrderSupplier, workflowAction.FunctionName);
                            break;

                        //Redirect page
                        case 3:
                            url = workflowAction.FunctionName;
                            break;
                    }
                }
            }

            if (workflowNode.NodeToId > 0)
            {
                WorkflowNode nextNode = WorkflowNodeUtility.Get(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode.NodeToId);
                WorkflowExec.WorkflowNextStatus(workflowNode.WorkflowId, nextNode.Name, workflowHistory.CurrentNodeId, projectOrderSupplier.TransactionId, comments);

                //if (comments.Trim() != string.Empty)
                //{
                //    Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.RFD_DATASOURCE_NAME,
                //        "ProjectOrderSupplier", projectOrderSupplier.Id.ToString());
                //    User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

                //    VendorComment vendorComment = VendorCommentUtility.CreateObject();
                //    vendorComment.UserId = user.Id;
                //    vendorComment.VendorId = vendor.Id;
                //    vendorComment.Comments = "Workflow Comments: " + comments;
                //    vendorComment.Type = "User";
                //    vendorComment.ChangeUser = user.FullName;

                //    VendorCommentUtility.Create(ConstantUtility.RFD_DATASOURCE_NAME, vendorComment);
                //}

                NodeAction(projectOrderSupplier, comments);
            }

            return projectOrderSupplier.TransactionId;
        }

        public static int ProjectOrderSupplierWorkflow(ProjectOrderSupplier projectOrderSupplier, string nextStatus, string comments)
        {
            projectOrderSupplier = GetProjectOrderSupplierWorkflow(projectOrderSupplier);
            if (projectOrderSupplier == null) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectOrderSupplier.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowExec.WorkflowNextSystemStatus(projectOrderSupplier.WorkflowId, nextStatus, workflowHistory.CurrentNodeId, projectOrderSupplier.TransactionId, comments);

            //if (comments.Trim() != string.Empty)
            //{
            //    Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.RFD_DATASOURCE_NAME,
            //        "ProjectOrderSupplier", projectOrderSupplier.Id.ToString());
            //    User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

            //    VendorComment vendorComment = VendorCommentUtility.CreateObject();
            //    vendorComment.VendorId = vendor.Id;
            //    vendorComment.Comments = "Workflow Comments: " + comments;
            //    if (user != null)
            //    {
            //        vendorComment.UserId = user.Id;
            //        vendorComment.Type = "User";
            //        vendorComment.ChangeUser = user.FullName;
            //    }

            //    VendorCommentUtility.Create(ConstantUtility.RFD_DATASOURCE_NAME, vendorComment);
            //}

            NodeAction(projectOrderSupplier, comments);

            return projectOrderSupplier.TransactionId;
        }

        public static WorkflowConditionCollection ProjectOrderSupplierWorkflowConditionTest(ProjectOrderSupplier projectOrderSupplier, int workflowNodeId)
        {
            projectOrderSupplier = GetProjectOrderSupplierWorkflow(projectOrderSupplier);
            if (projectOrderSupplier == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectOrderSupplier.TransactionId);
            if (workflowHistory == null)
                return null;

            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNodeId });

            XPathDocument doc = new XPathDocument(XmlUtility.Serialize(projectOrderSupplier));
            XPathNavigator nav = doc.CreateNavigator();

            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count > 0)
                        workflowCondition.Status = 1;
                }
            }
            return workflowConditions;
        }
        #endregion Workflow Control

        #region Workflow Node Action
        private static void NodeAction(ProjectOrderSupplier projectOrderSupplier, string comments)
        {
            projectOrderSupplier = GetProjectOrderSupplierWorkflow(projectOrderSupplier);
            if (projectOrderSupplier == null) return;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(
                projectOrderSupplier.TransactionId);

            int status = ((ProjectOrderSupplierStatusType)workflowHistory.CurrentNode.Name.Trim()).Id;


            if (status == 0 || status == projectOrderSupplier.Status) return;
            ProjectOrderSupplierUtility.UpdateStatus(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME, projectOrderSupplier.Id, status, workflowHistory.CurrentNode.Name);

            // automatic step
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { projectOrderSupplier.WorkflowId, "UserStepId", "ASC" });
            if (workflowNodes != null)
            {
                for (int i = 0; i < workflowNodes.Count; i++)
                {
                    if (workflowNodes[i].Type != 1 || workflowNodes[i].TimeToSkip != 1 ||
                        workflowHistory.CurrentNodeId != workflowNodes[i].NodeFromId)
                        continue;

                    string errmsg = string.Empty;
                    string url = string.Empty;
                    ProjectOrderSupplierWorkflow(projectOrderSupplier, workflowNodes[i].Id, comments, ref errmsg, ref url);
                }
            }
        }
        #endregion Workflow Node Action

        #region Batch Jobs
        #endregion Batch Jobs

        #region ProjectOrderSupplier Action
        private static void ProjectOrderSupplierAction(ProjectOrderSupplier projectOrderSupplier, string actionName)
        {
            string msg = string.Empty;
            string url = string.Empty;
            string tempType = workflowType;

            switch (actionName)
            {
                case "VendorPickUp":

                    RfcProject project = RfcProjectUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, projectOrderSupplier.ProjectId);
                    ProjectOrder projectOrder = ProjectOrderUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, projectOrderSupplier.ProjectOrderId);

                    ProjectOrderWorkflowExec.ProjectOrderWorkflow(projectOrder, ProjectOrderAction.VendorPickUp.Name, string.Empty, ref msg, ref url);
                    ProjectWorkflowExec.ProjectWorkflow(project, ProjectOrderAction.VendorPickUp.Name, string.Empty, ref msg, ref url);

                    break;

                case "VendorDropOff":

                    project = RfcProjectUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, projectOrderSupplier.ProjectId);
                    projectOrder = ProjectOrderUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, projectOrderSupplier.ProjectOrderId);

                    ProjectOrderWorkflowExec.ProjectOrderWorkflow(projectOrder, ProjectOrderAction.VendorDropOff.Name, string.Empty, ref msg, ref url);
                    ProjectWorkflowExec.ProjectWorkflow(project, ProjectOrderAction.VendorDropOff.Name, string.Empty, ref msg, ref url);

                    break;

            }
            WorkflowType = tempType;
        }
        #endregion
    }
}
