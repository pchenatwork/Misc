#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ProjectPreAwardVettingStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ProjectPreAwardVettingStatusConverter))]
    public class ProjectPreAwardVettingStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly ProjectPreAwardVettingStatusType NewPreAwardVetting = new ProjectPreAwardVettingStatusType(0, "NewPreAwardVetting", "New Pre Award Vetting");
        public static readonly ProjectPreAwardVettingStatusType AwardVettingRequested = new ProjectPreAwardVettingStatusType(1, "AwardVettingRequested", "Award Vetting Requested");
        public static readonly ProjectPreAwardVettingStatusType PendingTradeVerification = new ProjectPreAwardVettingStatusType(2, "PendingTradeVerification", "Pending Trade Verification");
        public static readonly ProjectPreAwardVettingStatusType TradesIssues = new ProjectPreAwardVettingStatusType(3, "TradesIssues", "Trades Issues");
        public static readonly ProjectPreAwardVettingStatusType TradesVerified = new ProjectPreAwardVettingStatusType(4, "TradesVerified", "Trades Verified");
        public static readonly ProjectPreAwardVettingStatusType TradeCodesRemediated = new ProjectPreAwardVettingStatusType(5, "TradeCodesRemediated", "Trade Codes Remediated");
        public static readonly ProjectPreAwardVettingStatusType TradeRemediationFailed = new ProjectPreAwardVettingStatusType(6, "TradeRemediationFailed", "Trade Remediation Failed");
        public static readonly ProjectPreAwardVettingStatusType VettingIssues = new ProjectPreAwardVettingStatusType(7, "VettingIssues", "Vetting Issues");
        public static readonly ProjectPreAwardVettingStatusType VettingRevision = new ProjectPreAwardVettingStatusType(8, "VettingRevision", "Vetting Revision");
        public static readonly ProjectPreAwardVettingStatusType PendingLowBidderSelection = new ProjectPreAwardVettingStatusType(9, "PendingLowBidderSelection", "Pending Low Bidder Selection");
        public static readonly ProjectPreAwardVettingStatusType PendingReviewerVetting = new ProjectPreAwardVettingStatusType(10, "PendingReviewerVetting", "Pending Reviewer Vetting");
        public static readonly ProjectPreAwardVettingStatusType ManagerFinancialReview = new ProjectPreAwardVettingStatusType(11, "ManagerFinancialReview", "Manager Financial Review");
        public static readonly ProjectPreAwardVettingStatusType ManagerBidBondReview = new ProjectPreAwardVettingStatusType(12, "ManagerBidBondReview", "Manager Bid Bond Review");
        public static readonly ProjectPreAwardVettingStatusType FinancialBidBondReviewComplete = new ProjectPreAwardVettingStatusType(13, "FinancialBidBondReviewComplete", "Financial Bid Bond Review Complete");
        public static readonly ProjectPreAwardVettingStatusType PendingManagerFinalReview = new ProjectPreAwardVettingStatusType(14, "PendingManagerFinalReview", "Pending Manager Final Review");
        public static readonly ProjectPreAwardVettingStatusType ReturntoReviewer = new ProjectPreAwardVettingStatusType(15, "ReturntoReviewer", "Return to Reviewer");
        public static readonly ProjectPreAwardVettingStatusType PendingReviewerTradeRemediation = new ProjectPreAwardVettingStatusType(16, "PendingReviewerTradeRemediation", "Pending Reviewer Trade Remediation");

 
        // MUST BE CONSISTENT WITH ProjectPreAwardVettingMentorStatusType
        public static readonly ProjectPreAwardVettingStatusType AwardVettingDisapproved = new ProjectPreAwardVettingStatusType(20, "AwardVettingDisapproved", "Award Vetting Disapproved");
        public static readonly ProjectPreAwardVettingStatusType AwardVettingOnHold = new ProjectPreAwardVettingStatusType(21, "AwardVettingOnHold", "Award Vetting On Hold");
        public static readonly ProjectPreAwardVettingStatusType AwardVettingApproved = new ProjectPreAwardVettingStatusType(22, "AwardVettingApproved", "Award Vetting Approved");
        public static readonly ProjectPreAwardVettingStatusType AwardVettingFinished = new ProjectPreAwardVettingStatusType(23, "AwardVettingFinished", "Award Vetting Finished");
    
        #endregion

        #region Constructors
        public ProjectPreAwardVettingStatusType()
        {
        }

        private ProjectPreAwardVettingStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectPreAwardVettingStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ProjectPreAwardVettingStatus.  
        /// </summary>
        public static ProjectPreAwardVettingStatusType Default
        {
            get
            {
                return (ProjectPreAwardVettingStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectPreAwardVettingStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }

        public static List<ProjectPreAwardVettingStatusType> GetList()
        {
            return _list.Cast<ProjectPreAwardVettingStatusType>().OrderBy(e => e.Id).ToList();
        }


        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((ProjectPreAwardVettingStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectPreAwardVettingStatus object.
        /// It allows a string to be assigned to a ProjectPreAwardVettingStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ProjectPreAwardVettingStatusType(int id)
        {
            return (ProjectPreAwardVettingStatusType)EnumerationBase.FindById(id, ProjectPreAwardVettingStatusType._list);
        }
        public static implicit operator ProjectPreAwardVettingStatusType(string name)
        {
            for (int i = 0; i < ProjectPreAwardVettingStatusType._list.Count; i++)
            {
                if (((ProjectPreAwardVettingStatusType)ProjectPreAwardVettingStatusType._list[i]).Description == name)
                    return (ProjectPreAwardVettingStatusType)ProjectPreAwardVettingStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectPreAwardVettingStatus objects.
    /// It's very useful when binding ProjectPreAwardVettingStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ProjectPreAwardVettingStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ProjectPreAwardVettingStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectPreAwardVettingStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ProjectPreAwardVettingStatusType._list.Count; i++)
            {
                list.Add(((ProjectPreAwardVettingStatusType)ProjectPreAwardVettingStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
