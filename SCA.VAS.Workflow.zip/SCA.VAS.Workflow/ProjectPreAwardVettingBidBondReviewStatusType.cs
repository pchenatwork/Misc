﻿#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    [Serializable]
    [TypeConverter(typeof(ProjectPreAwardVettingBidBondReviewStatusTypeConverter))]
    public class ProjectPreAwardVettingBidBondReviewStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
     
        public static readonly ProjectPreAwardVettingBidBondReviewStatusType NewBidBondVetting = new ProjectPreAwardVettingBidBondReviewStatusType(0, "NewBidBondVetting", "New Bid Bond Vetting");
        public static readonly ProjectPreAwardVettingBidBondReviewStatusType PendingBidBondVetting = new ProjectPreAwardVettingBidBondReviewStatusType(1, "PendingBidBondVetting", "Pending Bid Bond Vetting");
        public static readonly ProjectPreAwardVettingBidBondReviewStatusType PendingBidBondReview = new ProjectPreAwardVettingBidBondReviewStatusType(2, "PendingBidBondReview", "Pending Bid Bond Review");
        public static readonly ProjectPreAwardVettingBidBondReviewStatusType BidBondApproved = new ProjectPreAwardVettingBidBondReviewStatusType(3, "BidBondApproved", "Bid Bond Approved");
        public static readonly ProjectPreAwardVettingBidBondReviewStatusType PendingBidBondRemediation = new ProjectPreAwardVettingBidBondReviewStatusType(4, "PendingBidBondRemediation", "Pending Bid Bond Remediation");
        public static readonly ProjectPreAwardVettingBidBondReviewStatusType RemediationFailed = new ProjectPreAwardVettingBidBondReviewStatusType(5, "RemediationFailed", "Bid Bond Remediation Failed");
        public static readonly ProjectPreAwardVettingBidBondReviewStatusType PendingManagerRecommendation = new ProjectPreAwardVettingBidBondReviewStatusType(6, "PendingManagerRecommendation", "Pending Manager Recommendation - Bid Bond");
        public static readonly ProjectPreAwardVettingBidBondReviewStatusType ManagerRecommendationApproved = new ProjectPreAwardVettingBidBondReviewStatusType(7, "ManagerRecommendationApproved", "Manager Recommendation Approved - Bid Bond");
        public static readonly ProjectPreAwardVettingBidBondReviewStatusType ManagerRecommendationFailed = new ProjectPreAwardVettingBidBondReviewStatusType(8, "ManagerRecommendationFailed", "Manager Recommendation Failed - Bid Bond");
        public static readonly ProjectPreAwardVettingBidBondReviewStatusType AwardVettingFinished = new ProjectPreAwardVettingBidBondReviewStatusType(9, "AwardVettingFinished", "Award Vetting Finished - Bid Bond");




        #endregion

        #region Constructors
        public ProjectPreAwardVettingBidBondReviewStatusType()
        {
        }

        private ProjectPreAwardVettingBidBondReviewStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion


        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectPreAwardVettingBidBondReviewStatusType class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }


        /// <summary>
        /// Define the default value of ProjectPreAwardVettingBidBondReviewStatusType.  
        /// </summary>
        public static ProjectPreAwardVettingBidBondReviewStatusType Default
        {
            get
            {
                return (ProjectPreAwardVettingBidBondReviewStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectPreAwardVettingBidBondReviewStatusType class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }

        public static List<ProjectPreAwardVettingBidBondReviewStatusType> GetList()
        {
            return _list.Cast<ProjectPreAwardVettingBidBondReviewStatusType>().OrderBy(e => e.Id).ToList();
        }

        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((ProjectPreAwardVettingBidBondReviewStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectPreAwardVettingBidBondReviewStatusType object.
        /// It allows a string to be assigned to a ProjectPreAwardVettingBidBondReviewStatusType object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ProjectPreAwardVettingBidBondReviewStatusType(int id)
        {
            return (ProjectPreAwardVettingBidBondReviewStatusType)EnumerationBase.FindById(id, ProjectPreAwardVettingBidBondReviewStatusType._list);
        }
        public static implicit operator ProjectPreAwardVettingBidBondReviewStatusType(string name)
        {
            for (int i = 0; i < ProjectPreAwardVettingBidBondReviewStatusType._list.Count; i++)
            {
                if (((ProjectPreAwardVettingBidBondReviewStatusType)ProjectPreAwardVettingBidBondReviewStatusType._list[i]).Description == name)
                    return (ProjectPreAwardVettingBidBondReviewStatusType)ProjectPreAwardVettingBidBondReviewStatusType._list[i];
            }
            return null;
        }
        #endregion
    }


    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectPreAwardVettingBidBondReviewStatusType objects.
    /// It's very useful when binding ProjectPreAwardVettingBidBondReviewStatusType objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ProjectPreAwardVettingBidBondReviewStatusTypeConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ProjectPreAwardVettingBidBondReviewStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectPreAwardVettingBidBondReviewStatusType enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ProjectPreAwardVettingBidBondReviewStatusType._list.Count; i++)
            {
                list.Add(((ProjectPreAwardVettingBidBondReviewStatusType)ProjectPreAwardVettingBidBondReviewStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
