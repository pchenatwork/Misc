#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ProjectBidMentorStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ProjectBidMentorStatusConverter))]
    public class ProjectBidMentorStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly ProjectBidMentorStatusType NewBidAndAwardMentor = new ProjectBidMentorStatusType(0, "NewBidAndAwardMentor", "New Bid and Award Mentor");
        public static readonly ProjectBidMentorStatusType PendingFinancingVerification = new ProjectBidMentorStatusType(1, "PendingFinancingVerification", "Pending Financing Verification");
        public static readonly ProjectBidMentorStatusType FinancingInfoRequest = new ProjectBidMentorStatusType(2, "FinancingInfoRequest", "Financing Info Request");
        public static readonly ProjectBidMentorStatusType FinancingInfoSubmitted = new ProjectBidMentorStatusType(3, "FinancingInfoSubmitted", "Financing Info Submitted");
        public static readonly ProjectBidMentorStatusType FinancingVerified = new ProjectBidMentorStatusType(4, "FinancingVerified", "Financing Verified");
        public static readonly ProjectBidMentorStatusType InsufficientFunding = new ProjectBidMentorStatusType(5, "InsufficientFunding", "Budget Not Available");
        public static readonly ProjectBidMentorStatusType PendingMentorCMReview = new ProjectBidMentorStatusType(6, "PendingMentorCMReview", "Pending Mentor CM Review");
        public static readonly ProjectBidMentorStatusType PendingMentorCPOReview = new ProjectBidMentorStatusType(7, "PendingMentorCPOReview", "Pending Mentor CPO Review");

        public static readonly ProjectBidMentorStatusType PendingTurnoverToMentorCM = new ProjectBidMentorStatusType(15, "PendingTurnoverToMentorCM", "Pending Turnover to Mentor CM Review");



        public static readonly ProjectBidMentorStatusType ContractAwarded = new ProjectBidMentorStatusType(8, "ContractAwarded", "Contract Awarded");
        public static readonly ProjectBidMentorStatusType MentorProjectOnHold = new ProjectBidMentorStatusType(9, "MentorProjectOnHold", "RMentor Project On Hold");
        public static readonly ProjectBidMentorStatusType PendingLowBidderSelection = new ProjectBidMentorStatusType(10, "PendingLowBidderSelection", "Pending Low Bidder Selection");
        public static readonly ProjectBidMentorStatusType PendingCancellation = new ProjectBidMentorStatusType(11, "PendingCancellation", "Pending Cancellation");
        public static readonly ProjectBidMentorStatusType PendingBudgetAdjustment = new ProjectBidMentorStatusType(12, "PendingBudgetAdjustment", "Pending Budget Adjustment");
        public static readonly ProjectBidMentorStatusType BudgetAdjustmentSubmitted = new ProjectBidMentorStatusType(13, "BudgetAdjustmentSubmitted", "Budget Adjustment Submitted");
        public static readonly ProjectBidMentorStatusType Canceled = new ProjectBidMentorStatusType(14, "MentorCanceled", "Canceled");
        #endregion

        #region Constructors
        public ProjectBidMentorStatusType()
        {
        }

        private ProjectBidMentorStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectBidMentorStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ProjectBidMentorStatus.  
        /// </summary>
        public static ProjectBidMentorStatusType Default
        {
            get
            {
                return (ProjectBidMentorStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectBidMentorStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((ProjectBidMentorStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectBidMentorStatus object.
        /// It allows a string to be assigned to a ProjectBidMentorStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ProjectBidMentorStatusType(int id)
        {
            return (ProjectBidMentorStatusType)EnumerationBase.FindById(id, ProjectBidMentorStatusType._list);
        }
        public static implicit operator ProjectBidMentorStatusType(string name)
        {
            for (int i = 0; i < ProjectBidMentorStatusType._list.Count; i++)
            {
                if (((ProjectBidMentorStatusType)ProjectBidMentorStatusType._list[i]).Description == name)
                    return (ProjectBidMentorStatusType)ProjectBidMentorStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectBidMentorStatus objects.
    /// It's very useful when binding ProjectBidMentorStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ProjectBidMentorStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ProjectBidMentorStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectBidMentorStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ProjectBidMentorStatusType._list.Count; i++)
            {
                list.Add(((ProjectBidMentorStatusType)ProjectBidMentorStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
