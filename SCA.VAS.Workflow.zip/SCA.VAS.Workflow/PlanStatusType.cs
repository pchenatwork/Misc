#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of PlanStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(PlanStatusConverter))]
    public class PlanStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly PlanStatusType NewPlan = new PlanStatusType(0, "NewPlan", "New Plan");

        public static readonly PlanStatusType PlanSubmitted = new PlanStatusType(1, "PlanSubmitted", "Plan Submitted");
        public static readonly PlanStatusType PlanComplianceAnalystReviewed = new PlanStatusType(2, "PlanComplianceAnalystReviewed", "Plan Compliance Analyst Reviewed");

        public static readonly PlanStatusType PendingPlanWaiverRequest = new PlanStatusType(3, "PendingPlanWaiverRequest", "Pending Plan Waiver Request");
        public static readonly PlanStatusType PlanComplianceAnalystReviewedwithWaiver = new PlanStatusType(4, "PlanComplianceAnalystReviewedwithWaiver", "Plan Compliance Analyst Reviewed with Waiver");
        public static readonly PlanStatusType PlanComplianceManagerReviewedwithWaiver = new PlanStatusType(5, "PlanComplianceManagerReviewedwithWaiver", "Plan Compliance Manager Reviewed with Waiver");

        public static readonly PlanStatusType PlanComplianceVerified = new PlanStatusType(6, "PlanComplianceVerified", "Plan Compliance Verified");

        public static readonly PlanStatusType WaiverRequestMoreInfo = new PlanStatusType(7, "WaiverRequestMoreInfo", "Waiver Request More Info");
        public static readonly PlanStatusType WaiverMoreInfoSubmitted = new PlanStatusType(8, "WaiverMoreInfoSubmitted", "Waiver More Info Submitted");

        public static readonly PlanStatusType PlanRejected = new PlanStatusType(11, "PlanRejected", "Plan Rejected");

        public static readonly PlanStatusType PlanPendingAnalystCommitmentReview = new PlanStatusType(12, "PlanPendingAnalystCommitmentReview", "Plan Pending Analyst Commitment Review");
        public static readonly PlanStatusType PlanPendingDirectorCommitmentReview = new PlanStatusType(13, "PlanPendingDirectorCommitmentReview", "Plan Pending Director Commitment Review");
        public static readonly PlanStatusType PlanPendingSrDirectorCommitmentReview = new PlanStatusType(14, "PlanPendingSrDirectorCommitmentReview", "Plan Pending Sr Director Commitment Review");
        public static readonly PlanStatusType PlanPendingVPCommitmentReview = new PlanStatusType(15, "PlanPendingVPCommitmentReview", "Plan Pending VP Commitment Review");

        public static readonly PlanStatusType CloseOut = new PlanStatusType(16, "CloseOut", "Close Out");
        public static readonly PlanStatusType AdministrativeClosed = new PlanStatusType(17, "AdministrativeClosed", "Administrative Closed");
        #endregion

        #region Constructors
        public PlanStatusType()
        {
        }

        private PlanStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in PlanStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of PlanStatus.  
        /// </summary>
        public static PlanStatusType Default
        {
            get
            {
                return (PlanStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for PlanStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((PlanStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a PlanStatus object.
        /// It allows a string to be assigned to a PlanStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator PlanStatusType(int id)
        {
            return (PlanStatusType)EnumerationBase.FindById(id, PlanStatusType._list);
        }
        public static implicit operator PlanStatusType(string name)
        {
            for (int i = 0; i < PlanStatusType._list.Count; i++)
            {
                if (((PlanStatusType)PlanStatusType._list[i]).Description == name)
                    return (PlanStatusType)PlanStatusType._list[i];
            }
            return null;
        }

        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and PlanStatus objects.
    /// It's very useful when binding PlanStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class PlanStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, PlanStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the PlanStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < PlanStatusType._list.Count; i++)
            {
                list.Add(((PlanStatusType)PlanStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
