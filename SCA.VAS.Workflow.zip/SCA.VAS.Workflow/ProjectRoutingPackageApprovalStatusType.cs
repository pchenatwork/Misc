#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ProjectRoutingPackageApprovalStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ProjectRoutingPackageApprovalStatusConverter))]
    public class ProjectRoutingPackageApprovalStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly ProjectRoutingPackageApprovalStatusType NewPrequalification = new ProjectRoutingPackageApprovalStatusType(0, "NewPrequalification", "New Qualification");
        public static readonly ProjectRoutingPackageApprovalStatusType ApplicationSubmitted = new ProjectRoutingPackageApprovalStatusType(1, "ApplicationSubmitted", "Application Submitted");
        public static readonly ProjectRoutingPackageApprovalStatusType ManagerReviewed = new ProjectRoutingPackageApprovalStatusType(2, "ManagerReviewed", "Manager Reviewed");
        public static readonly ProjectRoutingPackageApprovalStatusType ReviewerReviewed = new ProjectRoutingPackageApprovalStatusType(3, "ReviewerReviewed", "Reviewer Reviewed");
        public static readonly ProjectRoutingPackageApprovalStatusType RequestMoreInfoPending = new ProjectRoutingPackageApprovalStatusType(4, "RequestMoreInfoPending", "Request More Info Pending");
        public static readonly ProjectRoutingPackageApprovalStatusType RequestMoreInfo = new ProjectRoutingPackageApprovalStatusType(5, "RequestMoreInfo", "Request More Info");
        public static readonly ProjectRoutingPackageApprovalStatusType AdditionalInfoSubmitted = new ProjectRoutingPackageApprovalStatusType(6, "AdditionalInfoSubmitted", "Additional Info Submitted");
        public static readonly ProjectRoutingPackageApprovalStatusType ReferenceReviewed = new ProjectRoutingPackageApprovalStatusType(7, "ReferenceReviewed", "Reference Reviewed");
        public static readonly ProjectRoutingPackageApprovalStatusType FinacialReviewed = new ProjectRoutingPackageApprovalStatusType(8, "FinacialReviewed", "Financial Reviewed");
        public static readonly ProjectRoutingPackageApprovalStatusType AllReviewed = new ProjectRoutingPackageApprovalStatusType(9, "AllReviewed", "Reference and Financial Reviewed");
        public static readonly ProjectRoutingPackageApprovalStatusType OIGApproved = new ProjectRoutingPackageApprovalStatusType(10, "OIGApproved", "OIG Approved");
        public static readonly ProjectRoutingPackageApprovalStatusType QualifiedPending = new ProjectRoutingPackageApprovalStatusType(11, "QualifiedPending", "Qualified Pending");
        public static readonly ProjectRoutingPackageApprovalStatusType Qualified = new ProjectRoutingPackageApprovalStatusType(12, "Qualified", "Qualified");
        public static readonly ProjectRoutingPackageApprovalStatusType PreDeny = new ProjectRoutingPackageApprovalStatusType(13, "PreDeny", "PreDeny");
        public static readonly ProjectRoutingPackageApprovalStatusType AdministrativelyClosed = new ProjectRoutingPackageApprovalStatusType(14, "AdministrativelyClosed", "Administratively Closed");
        public static readonly ProjectRoutingPackageApprovalStatusType DirectorClosePending = new ProjectRoutingPackageApprovalStatusType(15, "DirectorClosePending", "Director Close Pending");
        public static readonly ProjectRoutingPackageApprovalStatusType DirectorClosed = new ProjectRoutingPackageApprovalStatusType(16, "DirectorClosed", "Director Closed");
        public static readonly ProjectRoutingPackageApprovalStatusType Inactive = new ProjectRoutingPackageApprovalStatusType(17, "Inactive", "Inactive");
        public static readonly ProjectRoutingPackageApprovalStatusType Disqualified = new ProjectRoutingPackageApprovalStatusType(18, "Disqualified", "Disqualified");
        public static readonly ProjectRoutingPackageApprovalStatusType Withdrawn = new ProjectRoutingPackageApprovalStatusType(19, "Withdrawn", "Withdrawn");
        public static readonly ProjectRoutingPackageApprovalStatusType OIGReviewed = new ProjectRoutingPackageApprovalStatusType(20, "OIGReviewed", "OIG Reviewed");
        public static readonly ProjectRoutingPackageApprovalStatusType Rescinded = new ProjectRoutingPackageApprovalStatusType(21, "Rescinded", "Rescinded");
        public static readonly ProjectRoutingPackageApprovalStatusType Suspended = new ProjectRoutingPackageApprovalStatusType(22, "Suspended", "Suspended");
        public static readonly ProjectRoutingPackageApprovalStatusType RequestMoreInfo2 = new ProjectRoutingPackageApprovalStatusType(23, "RequestMoreInfo2", "Request More Info 2");
        public static readonly ProjectRoutingPackageApprovalStatusType AdditionalInfoSubmitted2 = new ProjectRoutingPackageApprovalStatusType(24, "AdditionalInfoSubmitted2", "Additional Info Submitted 2");
        public static readonly ProjectRoutingPackageApprovalStatusType Deny = new ProjectRoutingPackageApprovalStatusType(25, "Deny", "Deny");
        public static readonly ProjectRoutingPackageApprovalStatusType Expired = new ProjectRoutingPackageApprovalStatusType(26, "Expired", "Expired");
        public static readonly ProjectRoutingPackageApprovalStatusType OIGPending = new ProjectRoutingPackageApprovalStatusType(27, "OIGPending", "OIG Pending");
        #endregion

        #region Constructors
        public ProjectRoutingPackageApprovalStatusType()
        {
        }

        private ProjectRoutingPackageApprovalStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectRoutingPackageApprovalStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ProjectRoutingPackageApprovalStatus.  
        /// </summary>
        public static ProjectRoutingPackageApprovalStatusType Default
        {
            get
            {
                return (ProjectRoutingPackageApprovalStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectRoutingPackageApprovalStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }

        public static List<ProjectRoutingPackageApprovalStatusType> GetList()
        {
            return _list.Cast<ProjectRoutingPackageApprovalStatusType>().OrderBy(e => e.Id).ToList();
        }

        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((ProjectRoutingPackageApprovalStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectRoutingPackageApprovalStatus object.
        /// It allows a string to be assigned to a ProjectRoutingPackageApprovalStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ProjectRoutingPackageApprovalStatusType(int id)
        {
            return (ProjectRoutingPackageApprovalStatusType)EnumerationBase.FindById(id, ProjectRoutingPackageApprovalStatusType._list);
        }
        public static implicit operator ProjectRoutingPackageApprovalStatusType(string name)
        {
            for (int i = 0; i < ProjectRoutingPackageApprovalStatusType._list.Count; i++)
            {
                if (((ProjectRoutingPackageApprovalStatusType)ProjectRoutingPackageApprovalStatusType._list[i]).Description == name)
                    return (ProjectRoutingPackageApprovalStatusType)ProjectRoutingPackageApprovalStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectRoutingPackageApprovalStatus objects.
    /// It's very useful when binding ProjectRoutingPackageApprovalStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ProjectRoutingPackageApprovalStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ProjectRoutingPackageApprovalStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectRoutingPackageApprovalStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ProjectRoutingPackageApprovalStatusType._list.Count; i++)
            {
                list.Add(((ProjectRoutingPackageApprovalStatusType)ProjectRoutingPackageApprovalStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
