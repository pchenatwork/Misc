using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Net.Mail;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Xml;

using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting;
using SCA.VAS.ValueObjects.Template.Vetting;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Supplier.Vetting.Utilities;
using SCA.VAS.BusinessLogic.Supplier.Vetting;
using SCA.VAS.ValueObjects.Supplier.Vetting;

using SCA.VAS.DataAccess;
using UNLV.IAP.WebControls;
using BaseIDataSource = SCA.VAS.DataAccess.IDataSource;

namespace SCA.VAS.Workflow
{
    public partial class ConstantUtility
    {

        public const int VETTING_SUB_EVAL = 1;
        public const int VETTING_PRIME_EVAL = 2;
        public const int VETTING_SUPPLIER_EVAL = 3;
        public const string VETTING_NODE = "V"; 
        public const string VETTING_NODE_NAME = "Vettings";
        
        public const string VETTING_WORKFLOW = "Vetting";
        public const string SUPPLIERVETTINGGROUP_WORKFLOW = "Qualification";

        public const string VETTING_REF_MSG = "<br />VETTING ID: $SUPPLIERVETTINGID$.";
        public const string VETTINGGROUP_REF_MSG = "<br />VETTING GROUP ID: $SUPPLIERVETTINGGROUPID$.";
    }

    public partial class CommonUtility
    {
        public static void VettingSendEmail(EmailMessage emailmessage, object[] emailableObjs,
            EmailHistory emailHistory, string toType, int toId, string comments, string refMessage, int vettingId)
        {
            if (emailmessage != null)
            {
                string fromEmail = Replace(emailmessage.FromEmail, emailableObjs);
                string fromName = Replace(emailmessage.FromName, emailableObjs);
                string toEmail = Replace(emailmessage.ToEmail, emailableObjs);
                string toName = Replace(emailmessage.ToName, emailableObjs);
                string ccEmail = Replace(emailmessage.CcEmail, emailableObjs);
                string subject = Replace(emailmessage.Subject, emailableObjs);
                string body = emailmessage.Body + refMessage;
                body = body.Replace("$WORKFLOWCOMMENT$", comments);
                body = Replace(body, emailableObjs);
                body = Replace(body, emailableObjs);
                string bcc = Replace(emailmessage.BccEmail, emailableObjs);

                object[] attachments = null;
                if (emailmessage.Filename.Trim().Length > 0)
                {
                    if (emailmessage.Filename.Trim() == "$VETTINGATTACHMENTS$")
                    {
                        VettingAttachmentCollection vettingAttachments = VettingAttachmentUtility.FindByCriteria(
                            ConstantUtility.TEMPLATE_DATASOURCE_NAME,
                            VettingAttachmentManager.FIND_VETTINGATTACHMENT_BY_VETTING,
                            new object[] { vettingId });
                        if (vettingAttachments != null)
                        {
                            foreach (VettingAttachment vettingAttachment in vettingAttachments)
                            {
                                byte[] attachment = VettingAttachmentUtility.GetAttachment(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
                                    vettingAttachment.Id);
                                System.IO.Stream s = new MemoryStream(attachment);
                                Attachment mailAttachment = new Attachment(s, vettingAttachment.Filename);
                                attachments = new object[] { mailAttachment };
                            }
                        }
                    }
                    else
                    {
                        Attachment mailAttachment = new Attachment(GetEmailFolder() + emailmessage.Filename);
                        attachments = new object[] { mailAttachment };
                    }
                }

                int emailHistoryID = emailHistory == null ? 0 : emailHistory.Id;
                EmailUtility.Send(fromEmail, fromName, toEmail, toName, ccEmail, "", subject, body, bcc, false, attachments, "", emailHistoryID);

                if (emailHistory != null)
                {
                    EmailLog emailLog = EmailLogUtility.CreateObject();
                    emailLog.EmailHistoryId = emailHistory.Id;
                    emailLog.ToType = toType;
                    emailLog.ToId = toId;
                    emailLog.ToEmail = toEmail;
                    emailLog.Body = body;
                    EmailLogUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, emailLog);
                }
            }
        }

        public static bool GetSupplierVettingStatus(SqlWhereBuilder swb1, VettingGroupStatus vettingGroupStatus, int supplierId)
        {
            swb1.Conditions = (SqlWhereBuilderConditionCollection)XmlUtility.Deserialize(vettingGroupStatus.ConditionXml, typeof(SqlWhereBuilderConditionCollection));
            DataSet cds = new DataSet();

            string countString = "Select count(*) From Supplier Where Id = " + supplierId.ToString();
            SqlConnection connection = null;
            SqlCommand cmd = null;
            int totalNumber = 0;

            try
            {
                BaseIDataSource ds1 = DataSourceFactory.CreateInstance(ConstantUtility.SUPPLIER_DATASOURCE_NAME);
                connection = (SqlConnection)ds1.CreateConnection();
                cmd = new SqlCommand();
                cmd.Connection = connection;

                // get the where clause with parameters
                string sWhere = swb1.GetWhereClauseWithParameters(cmd);
                sWhere = LimpaSqlWhere(sWhere);
                if (sWhere.Length > 0)
                    countString += " AND (" + sWhere + ")";

                // execute the query
                cmd.CommandText = countString;
                SqlDataAdapter cda = new SqlDataAdapter(cmd);
                cda.Fill(cds);

                totalNumber = (int)cds.Tables[0].Rows[0].ItemArray[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (connection != null)
                {
                    connection.Close();
                    connection.Dispose();
                }
            }

            return (totalNumber > 0);
        }

        public static int GetVettingStatusCount(SqlWhereBuilder swb1, VettingGroupStatus vettingGroupStatus)
        {
            swb1.Conditions = (SqlWhereBuilderConditionCollection)XmlUtility.Deserialize(vettingGroupStatus.ConditionXml, typeof(SqlWhereBuilderConditionCollection));
            DataSet cds = new DataSet();

            string countString = "Select count(*) From Supplier Where Id in (Select SupplierId From SupplierVettingGroup Where VettingGroupId = " + vettingGroupStatus.VettingGroupId + ")";
            SqlConnection connection = null;
            SqlCommand cmd = null;
            int totalNumber = 0;

            try
            {
                BaseIDataSource ds1 = DataSourceFactory.CreateInstance(ConstantUtility.SUPPLIER_DATASOURCE_NAME);
                connection = (SqlConnection)ds1.CreateConnection();
                cmd = new SqlCommand();
                cmd.Connection = connection;

                // get the where clause with parameters
                string sWhere = swb1.GetWhereClauseWithParameters(cmd);
                sWhere = LimpaSqlWhere(sWhere);
                if (sWhere.Length > 0)
                    countString += " AND (" + sWhere + ")";

                // execute the query
                cmd.CommandText = countString;
                SqlDataAdapter cda = new SqlDataAdapter(cmd);
                cda.Fill(cds);

                totalNumber = (int)cds.Tables[0].Rows[0].ItemArray[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (connection != null)
                {
                    connection.Close();
                    connection.Dispose();
                }
            }

            return totalNumber;
        }

        public static string GetExtra(int count)
        {
            if (count > 1)
                return "s";
            else
                return "";
        }

        public static string GetScheduleInfo(VettingSchedule vettingSchedule)
        {
            if (vettingSchedule == null) return string.Empty;

            if (vettingSchedule.Frequency == "ADHOC")
            {
                return "Ad Hoc";
            }

            string scheduleInfo = "Due Date: ";
            if (vettingSchedule.DueType == 0)
                scheduleInfo += vettingSchedule.DueDate.ToString(ConstantUtility.DATE_FORMAT);
            else
            {
                if (vettingSchedule.DueNumber >= 0)
                    scheduleInfo += vettingSchedule.DueNumber + " " + vettingSchedule.DuePeriod + GetExtra(vettingSchedule.DueNumber) + " After " + vettingSchedule.DueEvent + " Date";
                else
                    scheduleInfo += String.Format("{0:d}", -1 * vettingSchedule.DueNumber) + " " + vettingSchedule.DuePeriod + GetExtra(vettingSchedule.DueNumber) + " Before " + vettingSchedule.DueEvent + " Date";
            }

            scheduleInfo += "<br />Repeat: " + vettingSchedule.Frequency;

            if (vettingSchedule.Frequency == JobSchedule.WEEK_SCHEDULE)
            {
                scheduleInfo += "<br /> Every " + vettingSchedule.RepeatNumber.ToString() + " " + vettingSchedule.Frequency + GetExtra(vettingSchedule.RepeatNumber) + " on";
                string[] weekDays = vettingSchedule.WeekDays.Split(',');
                for (int i = 0; i < weekDays.Length; i++)
                {
                    switch (weekDays[i].Trim())
                    {
                        case "0":
                            scheduleInfo += " Sunday,";
                            break;
                        case "1":
                            scheduleInfo += " Monday,";
                            break;
                        case "2":
                            scheduleInfo += " Tuesday,";
                            break;
                        case "3":
                            scheduleInfo += " Wednesday,";
                            break;
                        case "4":
                            scheduleInfo += " Thursday,";
                            break;
                        case "5":
                            scheduleInfo += " Friday,";
                            break;
                        case "6":
                            scheduleInfo += " Saturday,";
                            break;
                        default:
                            break;
                    }
                }
                scheduleInfo = scheduleInfo.TrimEnd(new char[] { ',' });
            }
            else if (vettingSchedule.Frequency == JobSchedule.MONTH_SCHEDULE)
            {
                if (vettingSchedule.ScheduleType == 0)
                {
                    scheduleInfo += "<br />Day " + vettingSchedule.WeekDays + " of";
                }
                else if (vettingSchedule.ScheduleType == 1)
                {
                    scheduleInfo += "<br />The ";
                    switch (vettingSchedule.WeekNumber)
                    {
                        case 1:
                            scheduleInfo += "first";
                            break;
                        case 2:
                            scheduleInfo += "second";
                            break;
                        case 3:
                            scheduleInfo += "third";
                            break;
                        case 4:
                            scheduleInfo += "fourth";
                            break;
                        case 0:
                            scheduleInfo += "last";
                            break;
                        default:
                            break;
                    }
                    scheduleInfo += " ";
                    switch (vettingSchedule.WeekDays.Trim())
                    {
                        case "0":
                            scheduleInfo += "Sunday ";
                            break;
                        case "1":
                            scheduleInfo += "Monday ";
                            break;
                        case "2":
                            scheduleInfo += "Tuesday ";
                            break;
                        case "3":
                            scheduleInfo += "Wednesday ";
                            break;
                        case "4":
                            scheduleInfo += "Thursday ";
                            break;
                        case "5":
                            scheduleInfo += "Friday ";
                            break;
                        case "6":
                            scheduleInfo += "Saturday ";
                            break;
                        default:
                            break;
                    }
                    scheduleInfo += "of";
                }

                string monthInfo = string.Empty;
                string[] selectedMonths = vettingSchedule.SelectedMonths.Split(',');
                for (int i = 0; i < selectedMonths.Length; i++)
                {
                    if (selectedMonths[i].Trim().Length > 0)
                        monthInfo += " " + GetMonthName(ConvertUtility.ConvertInt(selectedMonths[i].Trim()), false) + ",";
                }
                monthInfo = monthInfo.TrimEnd(new char[] { ',' });
                scheduleInfo += monthInfo;
            }

            scheduleInfo += "<br />Repeat Until: ";
            if (vettingSchedule.EndType == 0)
            {
                if (vettingSchedule.EndDate == new DateTime(1900, 1, 1))
                    scheduleInfo += "No End";
                else
                    scheduleInfo += vettingSchedule.EndDate.ToString(ConstantUtility.DATE_FORMAT);
            }
            else
            {
                if (vettingSchedule.EndNumber >= 0)
                    scheduleInfo += vettingSchedule.EndNumber + " " + vettingSchedule.EndPeriod + GetExtra(vettingSchedule.EndNumber) + " After " + vettingSchedule.EndEvent + " Date";
                else
                    scheduleInfo += String.Format("{0:d}", -1 * vettingSchedule.EndNumber) + " " + vettingSchedule.EndPeriod + GetExtra(vettingSchedule.EndNumber) + " Before " + vettingSchedule.EndEvent + " Date";
            }

            scheduleInfo += "<br />Remind Date:";
            scheduleInfo += vettingSchedule.RemindNumber.ToString() + " " + vettingSchedule.RemindPeriod + GetExtra(vettingSchedule.RemindNumber) + " before due date";

            return scheduleInfo;
        }

        public static string GetVettingUrl(VettingList vetting)
        {
            if (vetting.Url.Trim().Length > 0)
            {
                return "~/Vetting/" + vetting.Url.Trim();
            }
            else
            {
                return "~/Vetting/VettingForm.aspx";
            }
        }

        public static string GetViewVettingUrl(VettingList vetting)
        {
            if (vetting.Url.Trim().Length > 0)
            {
                return "~/Vetting/View" + vetting.Url.Trim();
            }
            else
            {
                return "~/Vetting/ViewVettingForm.aspx";
            }
        }

        public static string GetVettingRedirectUrl(string type, string groupId)
        {
            switch (type)
            {
                case "1":
                    return "~/Vetting/VettingGroup_Outlook.aspx?reload=true";
                default:
                    return "~/Vetting/VettingGroup_List.aspx?groupId=" + groupId + "&reload=true";
            }
        }

        public static bool WorkflowNeedVerify(int workflowId)
        {
            bool ret = false;

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { workflowId, "UserStepId", "ASC" });

            if (workflowNodes != null)
            {
                foreach (WorkflowNode wn in workflowNodes)
                {
                    if (wn.Type != 1)
                    {
                        if (string.Compare(wn.Name, "Verified") == 0)
                        {
                            return true;
                        }
                    }
                }
            }
            return ret;
        }

        public static bool WorkflowNeedApprove(int workflowId)
        {
            bool ret = false;

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { workflowId, "UserStepId", "ASC" });

            if (workflowNodes != null)
            {
                foreach (WorkflowNode wn in workflowNodes)
                {
                    if (wn.Type != 1)
                    {
                        if (string.Compare(wn.Name, "Approved") == 0)
                        {
                            return true;
                        }
                    }
                }
            }
            return ret;
        }

        public static int GetVettingGroupStep(int vettingGroupId, int supplierId, string step,
            VettingListCollection vettings, SqlWhereBuilder swb1)
        {
            int status = 0;
            switch (step)
            {
                case "Supplier Input":
                    if (vettings == null) return 0;
                    foreach (VettingList vetting in vettings)
                    {
                        if (vetting.Status == 0 && vetting.InternalUse != "Y")
                            status = 1;
                    }
                    break;
                case "Vetting Completion":
                case "Internal Verification":
                    {
                        VettingGroupStatus vettingGroupStatus = VettingGroupStatusUtility.GetBySystemName(
                            ConstantUtility.TEMPLATE_DATASOURCE_NAME, vettingGroupId, step);
                        if (vettingGroupStatus != null)
                        {
                            return GetSupplierVettingStatus(swb1, vettingGroupStatus, supplierId) ? 1 : 0;
                        }
                    }
                    break;
            }
            return status;
        }



        public static string GetSupplierVettingFields(VettingListCollection vettings)
        {
            string xml = "<configuration>";
            if (vettings != null)
            {
                foreach (VettingList vetting in vettings)
                {
                    StringBuilder sb = new StringBuilder(vetting.Name);
                    StringUtility.FormatXml(sb);
                    xml += "<field id=\"Id in (Select SupplierId From SupplierVetting Where VettingId = "
                        + vetting.Id.ToString() + " AND Status\" text=\"" + sb.ToString()
                        + "\" operatorList=\"formstatus\" parameterDataType=\"Decimal\" />";
                }
            }
            xml += "</configuration>";

            return xml;
        }

        public static string GetSupplierVettingFields(VettingQuestionCollection questions)
        {
            string xml = "<configuration>";

            xml += "<field id=\"\" text=\"\" operatorList=\"par\" parameterDataType=\"String\" />";
            xml += "<field id=\"SupplierId in (Select a.SupplierId From SupplierAddress a Where a.AddressType = 'PHYSICAL' and a.Country\" text=\"Location\" operatorList=\"country\" parameterDataType=\"String\" />\r\n";
            xml += "<field id=\"SupplierId in (Select a.SupplierId From GroupUser g Where g.GroupId\" text=\"Supplier Group\" operatorList=\"suppliergroup\" parameterDataType=\"Decimal\" />\r\n";

            if (questions != null)
            {
                foreach (VettingQuestion question in questions)
                {
                    if (question.QuestionType == QuestionType.HEADER || question.QuestionType == QuestionType.UPLOAD)
                        continue;

                    string questionName = question.QuestionName;
                    if (questionName.Trim().Length == 0)
                        questionName = "Question " + question.Sequence.ToString();
                    StringBuilder sb = new StringBuilder(questionName);
                    StringUtility.FormatXml(sb);
                    switch (question.QuestionType)
                    {
                        case QuestionType.SINGLE_LINE_QUESTION:
                        case QuestionType.MULTI_LINE_QUESTION:
                            xml += "<field id=\"SupplierId in (Select r.SupplierId From SupplierVettingResponse r "
                                + "Where r.QuestionId = "
                                + question.Id.ToString() + " AND r.ResponseText\" text=\"" + sb.ToString()
                                + "\" operatorList=\"datatype_ntext\" parameterDataType=\"String\" />";
                            break;
                        case QuestionType.CHECKBOX_QUESTION:
                        case QuestionType.DROPDOWN_MENU:
                        case QuestionType.RADIOBUTTON_QUESTION:
                            xml += "<field id=\"SupplierId in (Select r.SupplierId From SupplierVettingResponse r "
                                + "Where r.QuestionId = "
                                + question.Id.ToString() + " AND r.AnswerId\" text=\"" + sb.ToString()
                                + "\" operatorList=\"answer" + question.Id.ToString() + "\" parameterDataType=\"Decimal\" />";
                            break;
                        default:
                            break;
                    }
                }
            }
            xml += "</configuration>";

            return xml;
        }

        public static string GetSupplierVettingOperatorLists(VettingQuestionCollection questions)
        {
            string xml = "<configuration>\r\n";

            xml += "<operatorList id=\"datatype_text\">\r\n";
            xml += "<operator id=\"datatype_text_is\" text=\"Is\" valueEntry=\"onetext\" sqlTemplate=\"#FIELD# = #onetext_1#)\" />\r\n";
            xml += "<operator id=\"datatype_text_isnot\" text=\"Is Not\" valueEntry=\"onetext\" sqlTemplate=\"#FIELD# != #onetext_1#)\" />\r\n";
            xml += "<operator id=\"datatype_text_contains\" text=\"Contains\" valueEntry=\"onetext\" sqlTemplate=\"#FIELD# LIKE '%' + #onetext_1# + '%')\" />\r\n";
            xml += "<operator id=\"datatype_text_doesnotcontain\" text=\"Does Not Contain\" valueEntry=\"onetext\" sqlTemplate=\"#FIELD# NOT LIKE '%' + #onetext_1# + '%')\" />\r\n";
            xml += "<operator id=\"datatype_text_startswith\" text=\"Starts With\" valueEntry=\"onetext\" sqlTemplate=\"#FIELD# LIKE #onetext_1# + '%')\" />\r\n";
            xml += "<operator id=\"datatype_text_endswith\" text=\"Ends With\" valueEntry=\"onetext\" sqlTemplate=\"#FIELD# LIKE '%' + #onetext_1#)\" />\r\n";
            xml += "<operator id=\"datatype_text_isnull\" text=\"Is Null\" valueEntry=\"blank\" sqlTemplate=\"#FIELD# IS NULL)\" />\r\n";
            xml += "<operator id=\"datatype_text_isnotnull\" text=\"Is Not Null\" valueEntry=\"blank\" sqlTemplate=\"#FIELD# IS NOT NULL)\" />\r\n";
            xml += "</operatorList>\r\n";

            xml += "<operatorList id=\"datatype_ntext\">\r\n";
            xml += "<operator id=\"datatype_text_contains\" text=\"Contains\" valueEntry=\"onetext\" sqlTemplate=\"#FIELD# LIKE '%' + #onetext_1# + '%')\" />\r\n";
            xml += "<operator id=\"datatype_text_doesnotcontain\" text=\"Does Not Contain\" valueEntry=\"onetext\" sqlTemplate=\"#FIELD# NOT LIKE '%' + #onetext_1# + '%')\" />\r\n";
            xml += "<operator id=\"datatype_text_isnull\" text=\"Is Null\" valueEntry=\"blank\" sqlTemplate=\"#FIELD# IS NULL)\" />\r\n";
            xml += "<operator id=\"datatype_text_isnotnull\" text=\"Is Not Null\" valueEntry=\"blank\" sqlTemplate=\"#FIELD# IS NOT NULL)\" />\r\n";
            xml += "</operatorList>\r\n";

            xml += "<operatorList id=\"datatype_numeric\">\r\n";
            xml += "<operator id=\"datatype_numeric_equals\" text=\"Equals\" valueEntry=\"onetext\" sqlTemplate=\"#FIELD# = #onetext_1#)\" />\r\n";
            xml += "<operator id=\"datatype_numeric_notequals\" text=\"Does Not Equal\" valueEntry=\"onetext\" sqlTemplate=\"#FIELD# != #onetext_1#)\" />\r\n";
            xml += "<operator id=\"datatype_numeric_greaterthan\" text=\"Is Greater Than\" valueEntry=\"onetext\" sqlTemplate=\"#FIELD# &gt; #onetext_1#)\" />\r\n";
            xml += "<operator id=\"datatype_numeric_lessthan\" text=\"Is Less Than\" valueEntry=\"onetext\" sqlTemplate=\"#FIELD# &lt; #onetext_1#)\" />\r\n";
            xml += "<operator id=\"datatype_numeric_isbetween\" text=\"Is Between\" valueEntry=\"twotext\" sqlTemplate=\"(#FIELD# &gt;= #twotext_1# AND #FIELD# &lt;= #twotext_2#))\" />\r\n";
            xml += "<operator id=\"datatype_numeric_isnotbetween\" text=\"Is Not Between\" valueEntry=\"twotext\" sqlTemplate=\"NOT (#FIELD# &gt;= #twotext_1# AND #FIELD# &lt;= #twotext_2#))\" />\r\n";
            xml += "<operator id=\"datatype_numeric_isnull\" text=\"Is Null\" valueEntry=\"blank\" sqlTemplate=\"#FIELD# IS NULL)\" />\r\n";
            xml += "<operator id=\"datatype_numeric_isnotnull\" text=\"Is Not Null\" valueEntry=\"blank\" sqlTemplate=\"#FIELD# IS NOT NULL)\" />\r\n";
            xml += "</operatorList>\r\n";

            xml += "<operatorList id=\"datatype_date\">\r\n";
            xml += "<operator id=\"datatype_date_ison\" text=\"Is On\" valueEntry=\"onedate\" sqlTemplate=\"#FIELD# = #onedate_1#)\" />\r\n";
            xml += "<operator id=\"datatype_date_isnoton\" text=\"Is Not On\" valueEntry=\"onedate\" sqlTemplate=\"#FIELD# != #onedate_1#)\" />\r\n";
            xml += "<operator id=\"datatype_date_isbetween\" text=\"Is Between\" valueEntry=\"betweendate\" sqlTemplate=\"(#FIELD# &gt;= #betweendate_1# AND #FIELD# &lt;= #betweendate_2#))\" />\r\n";
            xml += "<operator id=\"datatype_date_isnotbetween\" text=\"Is Not Between\" valueEntry=\"betweendate\" sqlTemplate=\"NOT (#FIELD# &gt;= #betweendate_1# AND #FIELD# &lt;= #betweendate_2#))\" />\r\n";
            xml += "<operator id=\"datatype_date_isonorafter\" text=\"Is On or After\" valueEntry=\"onedate\" sqlTemplate=\"#FIELD# &gt;= #onedate_1#)\" />\r\n";
            xml += "<operator id=\"datatype_date_isonorbefore\" text=\"Is On or Before\" valueEntry=\"onedate\" sqlTemplate=\"#FIELD# &lt;= #onedate_1#)\" />\r\n";
            xml += "<operator id=\"datatype_date_isafter\" text=\"Is After\" valueEntry=\"onedate\" sqlTemplate=\"#FIELD# &gt; #onedate_1#)\" />\r\n";
            xml += "<operator id=\"datatype_date_isbefore\" text=\"Is Before\" valueEntry=\"onedate\" sqlTemplate=\"#FIELD# &lt; #onedate_1#)\" />\r\n";
            xml += "<operator id=\"datatype_date_isnull\" text=\"Is Null\" valueEntry=\"blank\" sqlTemplate=\"#FIELD# IS NULL)\" />\r\n";
            xml += "<operator id=\"datatype_date_isnotnull\" text=\"Is Not Null\" valueEntry=\"blank\" sqlTemplate=\"#FIELD# IS NOT NULL)\" />\r\n";
            xml += "</operatorList>\r\n";

            xml += "<operatorList id=\"datatype_bool\">\r\n";
            xml += "<operator id=\"datatype_bool_true\" text=\"Is True\" valueEntry=\"blank\" sqlTemplate=\"#FIELD# = 'Y'\" />\r\n";
            xml += "<operator id=\"datatype_bool_false\" text=\"Is False\" valueEntry=\"blank\" sqlTemplate=\"#FIELD# = 'N'\" />\r\n";
            xml += "</operatorList>\r\n";

            xml += "<operatorList id=\"par\">\r\n";
            xml += "<operator id=\"datatype_boolean_true\" text=\"(\" valueEntry=\"blank\" sqlTemplate=\"(\" />\r\n";
            xml += "<operator id=\"datatype_boolean_false\" text=\")\" valueEntry=\"blank\" sqlTemplate=\")\" />\r\n";
            xml += "</operatorList>\r\n";

            xml += "<operatorList id=\"expirationdate\">\r\n";
            xml += "<operator id=\"expirationdate_passed\" text=\"Expired\" valueEntry=\"blank\" sqlTemplate=\"#FIELD# &lt; getutcdate())\" />\r\n";
            xml += "<operator id=\"expirationdate_is\" text=\"Will Expire In\" valueEntry=\"dayfield\" sqlTemplate=\"#FIELD# &lt; dateadd(day, #daytext#, getutcdate()) and ExpirationDate >= getutcdate())\" />\r\n";
            xml += "</operatorList>\r\n";

            xml += "<operatorList id=\"country\">\r\n";
            xml += "<operator id=\"country_is\" text=\"Is\" valueEntry=\"country\" sqlTemplate=\"#FIELD# = #ctl00_content_search_country_ddcountry#)\" />\r\n";
            xml += "<operator id=\"country_isnot\" text=\"Is Not\" valueEntry=\"country\" sqlTemplate=\"#FIELD# != #ctl00_content_search_country_ddcountry#)\" />\r\n";
            xml += "</operatorList>\r\n";

            xml += "<operatorList id=\"suppliergroup\">\r\n";
            xml += "<operator id=\"suppliergroup_is\" text=\"Is\" valueEntry=\"suppliergroup\" sqlTemplate=\"#FIELD# = #ctl00_content_search_suppliergroup_ddsuppliergroup#))\" />\r\n";
            xml += "<operator id=\"suppliergroup_isnot\" text=\"Is Not\" valueEntry=\"suppliergroup\" sqlTemplate=\"#FIELD# != #ctl00_contentsearch_suppliergroup_ddsuppliergroup#))\" />\r\n";
            xml += "</operatorList>\r\n";

            if (questions != null)
            {
                foreach (VettingQuestion question in questions)
                {
                    switch (question.QuestionType)
                    {
                        case QuestionType.CHECKBOX_QUESTION:
                        case QuestionType.DROPDOWN_MENU:
                        case QuestionType.RADIOBUTTON_QUESTION:
                            string operatorName = "answer" + question.Id.ToString();
                            xml += "<operatorList id=\"" + operatorName + "\">\r\n";
                            xml += "<operator id=\"" + operatorName + "_is\" text=\"Is\" valueEntry=\"" + operatorName + "\"\r\n";
                            xml += "sqlTemplate=\"#FIELD# = #" + operatorName + "_select#)\" />\r\n";

                            xml += "<operator id=\"" + operatorName + "_isnot\" text=\"Is Not\" valueEntry=\"" + operatorName + "\"\r\n";
                            xml += "sqlTemplate=\"#FIELD# != #" + operatorName + "_select#)\" />\r\n";
                            xml += "</operatorList>\r\n";
                            break;
                        default:
                            break;
                    }
                }
            }
            xml += "</configuration>";

            return xml;
        }

        public static string GetSupplierVettingValueEntryDivs(VettingQuestionCollection questions)
        {
            string xml = "<configuration>\r\n";

            xml += "<valueEntry id=\"onetext\">\r\n";
            xml += "<input type=\"text\" id=\"onetext_1\" size=\"20\" />\r\n";
            xml += "</valueEntry>\r\n";

            xml += "<valueEntry id=\"twotext\">\r\n";
            xml += "<input type=\"text\" id=\"twotext_1\" size=\"20\" />\r\n";
            xml += "and\r\n";
            xml += "<input type=\"text\" id=\"twotext_2\" size=\"20\" />\r\n";
            xml += "</valueEntry>\r\n";

            xml += "<valueEntry id=\"onedate\">\r\n";
            xml += "<input type=\"text\" id=\"onedate_1\" size=\"11\" />\r\n";
            xml += "<span style=\"font-size: 8pt; color: lightGray;\">\r\n";
            xml += "mm/dd/yyyy\r\n";
            xml += "</span>\r\n";
            xml += "</valueEntry>\r\n";

            xml += "<valueEntry id=\"betweendate\">\r\n";
            xml += "<input type=\"text\" id=\"betweendate_1\" size=\"11\" />\r\n";
            xml += "and\r\n";
            xml += "<input type=\"text\" id=\"betweendate_2\" size=\"11\" />\r\n";

            xml += "<span style=\"font-size: 8pt; color: lightGray;\">\r\n";
            xml += "mm/dd/yyyy\r\n";
            xml += "</span>\r\n";
            xml += "</valueEntry>\r\n";

            xml += "<valueEntry id=\"blank\">\r\n";
            xml += "</valueEntry>\r\n";

            xml += "<valueEntry id=\"dayfield\">\r\n";
            xml += "<input type=\"text\" id=\"daytext\" size=\"4\" />\r\n";
            xml += "<span class=\"table2\">\r\n";
            xml += "days\r\n";
            xml += "</span>\r\n";
            xml += "</valueEntry>\r\n";

            xml += "<valueEntry id=\"country\" userControl=\"~/QEngine/SupplierVettingSearch/CountryDropDown.ascx\" />\r\n";
            xml += "<valueEntry id=\"suppliergroup\" userControl=\"~/QEngine/SupplierVettingSearch/SupplierGroupDropDown.ascx\" />\r\n";

            if (questions != null)
            {
                foreach (VettingQuestion question in questions)
                {
                    switch (question.QuestionType)
                    {
                        case QuestionType.CHECKBOX_QUESTION:
                        case QuestionType.DROPDOWN_MENU:
                        case QuestionType.RADIOBUTTON_QUESTION:
                            xml += "<valueEntry id=\"answer" + question.Id.ToString() + "\">\r\n";
                            xml += "<select id=\"answer" + question.Id.ToString() + "_select\">\r\n";
                            if (question.Answers != null)
                            {
                                foreach (VettingAnswer answer in question.Answers)
                                {
                                    StringBuilder sb = new StringBuilder(answer.AnswerText);
                                    StringUtility.FormatXml(sb);
                                    xml += "<option value=\"" + answer.Id.ToString() + "\">" + sb.ToString() + "</option>\r\n";
                                }
                            }
                            xml += "</select>\r\n";
                            xml += "</valueEntry>\r\n";
                            break;
                        default:
                            break;
                    }
                }
            }
            xml += "</configuration>";

            return xml;
        }

        public static SupplierVettingResponseCollection GetSupplierVettingResponses(VettingResponseCollection responses)
        {
            SupplierVettingResponseCollection supplierResponses = new SupplierVettingResponseCollection();

            foreach (VettingResponse response in responses)
            {
                SupplierVettingResponse supplierResponse = SupplierVettingResponseUtility.CreateObject();
                supplierResponse.Id = response.Id;
                supplierResponse.QuestionId = response.QuestionId;
                supplierResponse.AnswerId = response.AnswerId;
                supplierResponse.Selected = response.Selected;
                supplierResponse.ResponseText = response.ResponseText;
                supplierResponse.Attachment = response.Attachment;
                supplierResponse.AttachmentName = response.AttachmentName;
                supplierResponses.Add(supplierResponse);
            }

            return supplierResponses;
        }


        public static void AddSupplierToVetting(int vettingId, int supplierId, int contactId, int userId)
        {
            string errmsg = string.Empty;
            string url = string.Empty;

            SupplierVetting supplierVetting = SupplierVettingUtility.GetByVetting(
                ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierId, vettingId);
            if (supplierVetting == null)
            {
                supplierVetting = SupplierVettingUtility.CreateObject();
                supplierVetting.SupplierId = supplierId;
                supplierVetting.ContactId = contactId;
                supplierVetting.UserId = userId;
                supplierVetting.VettingId = vettingId;
                SupplierVettingUtility.Create(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierVetting);
                supplierVetting = SupplierVettingUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                    supplierVetting.Id);
            }
            else
            {
                if (supplierVetting.ContactId != contactId)
                {
                    supplierVetting.ContactId = contactId;
                    SupplierVettingUtility.UpdateContact(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                        supplierVetting.Id, contactId);
                }
            }
            if (supplierVetting.TransactionId == 0)
                supplierVetting.TransactionId = SupplierVettingWorkflowExec.SupplierVettingWorkflow(
                    supplierVetting, 0, "", ref errmsg, ref url);
        }

        public static bool MatchExtension(string fileName, string extensions)
        {
            string[] split = fileName.Split('.');
            string pFileExt = (split.Length > 0) ? split[split.Length - 1] : string.Empty;

            string[] fileExtensions = extensions.Split('|');
            bool ind = false;
            foreach (string str in fileExtensions)
            {
                if (string.Compare(str, pFileExt, true) == 0)
                {
                    ind = true;
                    break;
                }
            }
            return ind;
        }

        public static string GetShortName(string name)
        {
            if (name.Length > 40)
                return name.Substring(0, 40) + "...";
            else
                return name;
        }

        #region private methods
        /// <summary>
        /// Converts the given month int to month name
        /// </summary>
        /// <param name="month">month in</param>
        /// <param name="abbrev">return abbreviated or not</param>
        /// <returns>Short or long month name</returns>
        private static string GetMonthName(int month, bool abbrev)
        {
            DateTime date = new DateTime(1900, month, 1);
            if (abbrev) return date.ToString("MMM");
            return date.ToString("MMMM");
        }
        #endregion private methods
    }
}
