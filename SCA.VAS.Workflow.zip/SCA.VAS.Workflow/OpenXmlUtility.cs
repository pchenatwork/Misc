﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using DocumentFormat.OpenXml.Packaging;
using System.Configuration;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;

namespace SCA.VAS.Workflow
{
    public class OpenXmlUtility
    {
        public static byte[] MergeWordDoc(byte[] doc, Dictionary<string, string> fields)
        {
            byte[] newDoc = null;
            using (MemoryStream stream = new MemoryStream())
            {
                stream.Write(doc, 0, doc.Length);
                using (WordprocessingDocument docx = WordprocessingDocument.Open(stream, true))
                {
                    Regex regEx = new Regex(@"^[\s]*MERGEFIELD[\s]+(?<fieldname>[#\w]*){1}?",
                        RegexOptions.Compiled | RegexOptions.CultureInvariant | RegexOptions.ExplicitCapture | RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace | RegexOptions.Singleline);
                    //replace each merge field
                    foreach (var mergefield in docx.MergeFields())
                    {
                        Match m = regEx.Match(mergefield.Instruction);
                        if (m.Success)
                        {
                            string fieldname = regEx.Match(mergefield.Instruction).Groups["fieldname"].ToString().Trim();
                            if (fields.ContainsKey(fieldname))
                                mergefield.Replace(fields[fieldname]);
                            else
                                mergefield.Replace("######");
                        }
                    }
                    docx.MainDocumentPart.Document.Save(); //save replaces to doc object
                }

                stream.Seek(0, SeekOrigin.Begin);
                newDoc = stream.ToArray();
            }

            return newDoc;
        }
        public static byte[] HTMLtoWordDoc(string htmlstr)
        {
            string file = ConfigurationManager.AppSettings["DownloadPath"] +  "_temp.docx";
            if (File.Exists(file))
                File.Delete(file);
            XNamespace w = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
            XNamespace r = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
            using (WordprocessingDocument myDoc = WordprocessingDocument.Create(file, WordprocessingDocumentType.Document, true))
            {
                MainDocumentPart mainPart = myDoc.AddMainDocumentPart();
                mainPart.Document = new Document();
                mainPart.Document.Body = new Body();
                mainPart.Document.Save();
            }

            using (WordprocessingDocument myDoc = WordprocessingDocument.Open(file, true))
            {
                string altChunkId = "AltChunkId1";
                MainDocumentPart mainPart = myDoc.MainDocumentPart;
                AlternativeFormatImportPart chunk = mainPart.AddAlternativeFormatImportPart(
                    "application/xhtml+xml", altChunkId);
                using (Stream chunkStream = chunk.GetStream(FileMode.Create, FileAccess.Write))
                using (StreamWriter stringStream = new StreamWriter(chunkStream))
                    stringStream.Write(htmlstr);

                XElement altChunk = new XElement(w + "altChunk", new XAttribute(r + "id", altChunkId));
                XDocument mainDocumentXDoc = GetXDocument(myDoc);
                mainDocumentXDoc.Root
                    .Element(w + "body")
                    .AddFirst(altChunk);
                SaveXDocument(myDoc, mainDocumentXDoc);
            }
            return File.ReadAllBytes(file);
        }

        private static void SaveXDocument(WordprocessingDocument myDoc, XDocument mainDocumentXDoc)
        {
            // Serialize the XDocument back into the part
            using (Stream str = myDoc.MainDocumentPart.GetStream(
                FileMode.Create, FileAccess.Write))
            using (XmlWriter xw = XmlWriter.Create(str))
                mainDocumentXDoc.Save(xw);
        }

        private static XDocument GetXDocument(WordprocessingDocument myDoc)
        {
            // Load the main document part into an XDocument
            XDocument mainDocumentXDoc;
            using (Stream str = myDoc.MainDocumentPart.GetStream())
            using (XmlReader xr = XmlReader.Create(str))
                mainDocumentXDoc = XDocument.Load(xr);
            return mainDocumentXDoc;
        }
    }
    public static class OpenXmlUtilityExtensionFunctions
    {
        public static List<SimpleField> MergeFields(this WordprocessingDocument doc)
        {
            return doc.MainDocumentPart.Document.Descendants<SimpleField>().ToList<SimpleField>();
        }
        public static void Replace(this SimpleField mergefield, string text)
        {
            mergefield.Parent.ReplaceChild<SimpleField>(GetRunElementForText(text, mergefield), mergefield);
        }
        private static Run GetRunElementForText(string text, SimpleField placeHolder)
        {
            if (text == null)
                text = "";
            string rpr = null;
            if (placeHolder != null)
                foreach (RunProperties placeholderrpr in placeHolder.Descendants<RunProperties>())
                {
                    rpr = placeholderrpr.OuterXml;
                    break;  // break at first
                }

            Run r = new Run();
            if (!string.IsNullOrEmpty(rpr))
                r.Append(new RunProperties(rpr));

            if (!string.IsNullOrEmpty(text))
            {
                // first process line breaks
                string[] split = text.Split(new string[] { "\n" }, StringSplitOptions.None);
                bool first = true;
                foreach (string s in split)
                {
                    if (!first)
                        r.Append(new Break());

                    first = false;

                    // then process tabs
                    bool firsttab = true;
                    string[] tabsplit = s.Split(new string[] { "\t" }, StringSplitOptions.None);
                    foreach (string tabtext in tabsplit)
                    {
                        if (!firsttab)
                        {
                            r.Append(new TabChar());
                        }

                        r.Append(new Text(tabtext));
                        firsttab = false;
                    }
                }
            }

            return r;
        }
    }
}
