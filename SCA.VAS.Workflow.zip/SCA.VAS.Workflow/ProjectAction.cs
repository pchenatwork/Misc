#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ProjectAction:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ProjectActionConverter))]
    public class ProjectAction : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements

 



        public static readonly ProjectAction CreateList = new ProjectAction(1, "CreateList", "Create List For Review");
        public static readonly ProjectAction CAUIntake = new ProjectAction(2, "CAUIntake", "CAU Intake");
        public static readonly ProjectAction CSReview = new ProjectAction(3, "CSReview", "CS Review");
        public static readonly ProjectAction CreateSolicitationPackage = new ProjectAction(4, "CreateSolicitationPackage", "Create Solicitation Package");

        public static readonly ProjectAction MgrSolicitationApprove = new ProjectAction(5, "MgrSolicitationApprove", "Mgr Solicitation Approve");
        public static readonly ProjectAction MgrSolicitationReturn = new ProjectAction(6, "MgrSolicitationReturn", "Mgr Solicitation Return");
        public static readonly ProjectAction ReviseCSReview = new ProjectAction(7, "ReviseCSReview", "Revise CS Review");
        public static readonly ProjectAction MgrSolicitationApprove1 = new ProjectAction(8, "MgrSolicitationApprove1", "Mgr Solicitation Approve 1");
        public static readonly ProjectAction MgrSolicitationReturn1 = new ProjectAction(9, "MgrSolicitationReturn1", "Mgr Solicitation Return 1");
        
        public static readonly ProjectAction DirectorSolicitationApprove = new ProjectAction(10, "DirectorSolicitationApprove", "Director Solicitation Approve");
        public static readonly ProjectAction DirectorSolicitationReturn = new ProjectAction(11, "DirectorSolicitationReturn", "Director Solicitation Return");
        public static readonly ProjectAction ReviseCSReview1 = new ProjectAction(12, "ReviseCSReview1", "Revise CS Review 1");
        public static readonly ProjectAction DirectorSolicitationAppove1 = new ProjectAction(13, "DirectorSolicitationApprove1", "Director Solicitation Approve 1");
        public static readonly ProjectAction DirectorSolicitationReturn1 = new ProjectAction(14, "DirectorSolicitationReturn1", "Director Solicitation Return 1");
        
        public static readonly ProjectAction IssueInvitationtoBidLetter = new ProjectAction(15, "IssueInvitationtoBidLetter", "Issue Invitation to Bid Letter");
        public static readonly ProjectAction SelectVendorforProduction = new ProjectAction(16, "SelectVendorforProduction", "Select Vendor for Production");
        public static readonly ProjectAction BidOpening = new ProjectAction(17, "BidOpening", "Bid Opening");

        // RFI Submission / Processing Workflow 
        public static readonly ProjectAction ReviewRFISubmission = new ProjectAction(21, "ReviewRFISubmission", "Review RFI Submission");
        public static readonly ProjectAction RespondtoRFI = new ProjectAction(22, "RespondtoRFI", "Respond to RFI");
        public static readonly ProjectAction ReviewRFIResponse = new ProjectAction(23, "ReviewRFIResponse", "Review RFI Response");

        // Addendum Workflow 
        public static readonly ProjectAction CreateAddendum = new ProjectAction(31, "CreateAddendum", "Create Addendum");

        public static readonly ProjectAction MgrAddendumReturn = new ProjectAction(32, "MgrAddendumReturn", "Mgr Addendum Return");
        public static readonly ProjectAction MgrAddendumApprove = new ProjectAction(33, "MgrAddendumApprove", "Mgr Addendum Approve");
        public static readonly ProjectAction MgrAddendumMentorApprove = new ProjectAction(46, "MgrAddendumMentorApprove", "Mgr Addendum Mentor Approve");
        public static readonly ProjectAction ReviseAddendum = new ProjectAction(34, "ReviseAddendum", "Revise Addendum");
        public static readonly ProjectAction MgrAddendumReturn1 = new ProjectAction(35, "MgrAddendumReturn1", "Mgr Addendum Return 1");
        public static readonly ProjectAction MgrAddendumApprove1 = new ProjectAction(36, "MgrAddendumApprove1", "Mgr Addendum Approve 1");
        public static readonly ProjectAction MgrAddendumMentorApprove1 = new ProjectAction(47, "MgrAddendumMentorApprove1", "Mgr Addendum Mentor Approve 1");

        public static readonly ProjectAction DirectorAddendumReturn = new ProjectAction(37, "DirectorAddendumReturn", "Director Addendum Return");
        public static readonly ProjectAction DirectorAddendumApprove = new ProjectAction(38, "DirectorAddendumApprove", "Director Addendum Approve");
        public static readonly ProjectAction ReviseAddendum1 = new ProjectAction(39, "ReviseAddendum1", "Revise Addendum 1");
        public static readonly ProjectAction DirectorAddendumReturn1 = new ProjectAction(40, "DirectorAddendumReturn1", "Director Addendum Return 1");
        public static readonly ProjectAction DirectorAddendumApprove1 = new ProjectAction(41, "DirectorAddendumApprove1", "Director Addendum Approve 1");
      
        // Bid Recording Workflow
        public static readonly ProjectAction RecordBidders = new ProjectAction(42, "RecordBidders", "Record Bidders");
        public static readonly ProjectAction OpenBid = new ProjectAction(43, "OpenBid", "Open Bid");
        public static readonly ProjectAction CertifyBidTab = new ProjectAction(44, "CertifyBidTab", "Certify Bid Tab");
        public static readonly ProjectAction ReviewBidResults = new ProjectAction(45, "ReviewBidResults", "Review Bid Results");




        // Pre-Award Vetting Workflow

        public static readonly ProjectAction BidBondApproved = new ProjectAction(401, "BidBondApproved", "Bid Bond Approved");
        public static readonly ProjectAction PendingBidBondRemediation = new ProjectAction(402, "PendingBidBondRemediation", "Pending Bid Bond Remediation");
        public static readonly ProjectAction RemediationFailed = new ProjectAction(403, "RemediationFailed", "Remediation Failed");

        public static readonly ProjectAction FinancialApproved = new ProjectAction(404, "FinancialApproved", "Financial Approved");
        public static readonly ProjectAction PendingFinancialRemediation = new ProjectAction(405, "PendingFinancialRemediation", "Pending Financial Remediation");


        public static readonly ProjectAction AssignReviewer4TradeVerification = new ProjectAction(121, "AssignReviewer4TradeVerification", "Assign Reviewer for Trade Verification");
        public static readonly ProjectAction AssignReviewer4ReviewerVetting = new ProjectAction(121, "AssignReviewer4ReviewerVetting", "Assign Reviewer for Reviewer Vetting");
        public static readonly ProjectAction ReviewVettingApprove = new ProjectAction(122, "ReviewVettingApprove", "Review Vetting Approve");
        public static readonly ProjectAction ReviewVettingIssues = new ProjectAction(123, "ReviewVettingIssues", "Review Vetting Issues");
        public static readonly ProjectAction VettingRevision = new ProjectAction(124, "VettingRevision", "Vetting Revision");
        public static readonly ProjectAction VettingRevisionDisapprove = new ProjectAction(125, "VettingRevisionDisapprove", "Vetting Revision Disapprove");
        public static readonly ProjectAction ReviewTrades = new ProjectAction(126, "ReviewTrades", "Review Trades");
        public static readonly ProjectAction TradesVerified = new ProjectAction(127, "TradesVerified", "Trades Verified");
        public static readonly ProjectAction ReviewTradesIssues = new ProjectAction(528, "ReviewTradesIssues", "Review Trades Issues");
        public static readonly ProjectAction TradeRemediationFailed = new ProjectAction(529, "TradeRemediationFailed", "Trade Remediation Failed");
        public static readonly ProjectAction TradeCodesRemediated = new ProjectAction(530, "TradeCodesRemediated", "Trade Codes Remediated");
        public static readonly ProjectAction ReturntoReviewer = new ProjectAction(531, "ReturntoReviewer", "Return to Reviewer");

        public static readonly ProjectAction ManagerFinalReview = new ProjectAction(131, "ManagerFinalReview", "Manager Final Review");
        public static readonly ProjectAction ManagerFinalReviewApprove = new ProjectAction(127, "ManagerFinalReviewApprove", "Manager Final Review Approve");
        public static readonly ProjectAction ManagerFinalReviewDeny = new ProjectAction(128, "ManagerFinalReviewDeny", "Manager Final Review Deny");
        public static readonly ProjectAction ManagerFinalReviewOnHold = new ProjectAction(128, "ManagerFinalReviewOnHold", "Manager Final Review On Hold");

        public static readonly ProjectAction ResolveVettingIssue = new ProjectAction(129, "ResolveVettingIssue", "Resolve Vetting Issue");
        public static readonly ProjectAction RequestNextLowBidder = new ProjectAction(130, "RequestNextLowBidder", "Request Next Low Bidder");
        public static readonly ProjectAction VettingDisapprove = new ProjectAction(140, "VettingDisapprove", "Vetting Disapprove");
        public static readonly ProjectAction VettingFinished = new ProjectAction(221, "VettingFinished", "Vetting Finished");

        public static readonly ProjectAction VettingDirectorReview = new ProjectAction(550, "VettingDirectorReview", "Vetting Director Review");

        public static readonly ProjectAction VettingDirectorApproved = new ProjectAction(551, "VettingDirectorApproved", "Vetting Director Approved");
        public static readonly ProjectAction VettingDirectorDisapproved = new ProjectAction(552, "VettingDirectorDisapproved", "Vetting Director Disapproved");
        public static readonly ProjectAction VettingDirectorRequestToReVett = new ProjectAction(553, "VettingDirectorRequestToReVett", "Vetting Director Request To Re-Vett");


        public static readonly ProjectAction ManagerFinancialReviewApproved = new ProjectAction(301, "FinancialManagerReviewApproved", "Financial Manager Review - Approved");
        public static readonly ProjectAction ManagerFinancialReviewDenied = new ProjectAction(303, "ManagerFinancialReviewDenied", "Manager Financial Review - Denied");

        public static readonly ProjectAction ManagerBidBondReviewApproved = new ProjectAction(302, "BidBondManagerReviewApproved", "Bid Bonds Manager Review - Approved");
        public static readonly ProjectAction ManagerBidBondReviewDenied = new ProjectAction(304, "ManagerRecommendationFailed", "Bid Bonds Manager Review - Denied");

        
            

        // adding a new step to merge the CQU vetting and send request to CAU to pick the next bidder because CQU rejected first bidder
        public static readonly ProjectAction CompleteNextLowBidderRequest = new ProjectAction(227, "CompleteNextLowBidderRequest", "Complete Next Low Bidder Request");


        public static readonly ProjectAction FinancialReview = new ProjectAction(130, "FinancialReview", "Financial Review");
        public static readonly ProjectAction ReviewBidBonds = new ProjectAction(131, "ReviewBidBonds", "Review Bid Bonds");
        public static readonly ProjectAction FinancialReview2 = new ProjectAction(132, "FinancialReview2", "Financial Review 2");
        public static readonly ProjectAction ReviewBidBonds2 = new ProjectAction(133, "ReviewBidBonds2", "Review Bid Bonds 2");
        public static readonly ProjectAction FinancialFailed = new ProjectAction(134, "FinancialFailed", "Financial Failed");
        public static readonly ProjectAction FinancialFailed2 = new ProjectAction(135, "FinancialFailed2", "Financial Failed 2");
        public static readonly ProjectAction BondIssues = new ProjectAction(136, "BondIssues", "Bond Issues");

        // new actions
        public static readonly ProjectAction RemediateFailedFinancials = new ProjectAction(139, "RemediateFailedFinancials", "Remediate Failed Financials");
        public static readonly ProjectAction RemediateBondIssues = new ProjectAction(141, "RemediateBondIssues", "Remediate Bond Issues");


        public static readonly ProjectAction BondIssues2 = new ProjectAction(137, "BondIssues2", "Bond Issues 2");
        public static readonly ProjectAction BondMerge2 = new ProjectAction(138, "BondMerge2", "Bond Merge 2");
        public static readonly ProjectAction RemediateRS1Vetting = new ProjectAction(231, "RemediateRS1Vetting", "RS1 Vetting Remediate");
        public static readonly ProjectAction CompeleteRemediateRS1Vetting = new ProjectAction(232, "CompeleteRemediateRS1Vetting", "RS1 Vetting Remediate - Compelete");


        // Bid Breakdown Analysis Workflow
        public static readonly ProjectAction EnterBidBreakdown = new ProjectAction(51, "EnterBidBreakdown", "Enter Bid Breakdown");
        public static readonly ProjectAction ProvideBidBreakdownAnalysis = new ProjectAction(52, "ProvideBidBreakdownAnalysis", "Provide Bid Breakdown Analysis");
        public static readonly ProjectAction EstimatingMgrReview = new ProjectAction(53, "EstimatingMgrReview", "Estimating Mgr Review");
        public static readonly ProjectAction ReviewBidAnalysisResultsReturn = new ProjectAction(54, "ReviewBidAnalysisResultsReturn", "Review Bid Analysis Results Return");
        public static readonly ProjectAction ReviewBidAnalysisResultsApprove1 = new ProjectAction(55, "ReviewBidAnalysisResultsApprove1", "Review Bid Analysis Results Approve 1");
        public static readonly ProjectAction ReviewBidAnalysisResultsApprove2 = new ProjectAction(56, "ReviewBidAnalysisResultsApprove2", "Review Bid Analysis Results Approve 2");
        public static readonly ProjectAction ReviewBidAnalysisResultsApprove3 = new ProjectAction(57, "ReviewBidAnalysisResultsApprove3", "Review Bid Analysis Results Approve 3"); 
        public static readonly ProjectAction ReviewCSComments = new ProjectAction(58, "ReviewCSComments", "Review CS Comments");
        public static readonly ProjectAction EnterBAFOAmount = new ProjectAction(59, "EnterBAFOAmount", "Enter BAFO Amount");
        public static readonly ProjectAction EnterBAFOAmountAllow = new ProjectAction(60, "EnterBAFOAmountAllow", "Enter BAFO Amount Allow");
        public static readonly ProjectAction VPofCMBidUnderReview = new ProjectAction(194, "VPofCMBidUnderReview", "VP of CM Bid Under Review");
        public static readonly ProjectAction VPofCMBidReturn = new ProjectAction(61, "VPofCMBidReturn", "VP of CM Bid Return");
        public static readonly ProjectAction VPofCMBidApprove = new ProjectAction(62, "VPofCMBidApprove", "VP of CM Bid Approve");
        public static readonly ProjectAction VPofCMBidReturn2 = new ProjectAction(195, "VPofCMBidReturn2", "VP of CM Bid Return 2");
        public static readonly ProjectAction VPofCMBidApprove2 = new ProjectAction(196, "VPofCMBidApprove2", "VP of CM Bid Approve 2");
        public static readonly ProjectAction CSBidApprove = new ProjectAction(63, "CSBidApprove", "CS Bid Approve");
        public static readonly ProjectAction PresidentBidReturn = new ProjectAction(64, "PresidentBidReturn", "President Bid Return");
        public static readonly ProjectAction PresidentBidApprove = new ProjectAction(65, "PresidentBidApprove", "President Bid Approve");
        public static readonly ProjectAction EnterVPofCMRecommendation = new ProjectAction(66, "EnterVPofCMRecommendation", "Enter VP of CM Recommendation");
        public static readonly ProjectAction FinishVettingBreakdown = new ProjectAction(67, "FinishVettingBreakdown", "Finish Vetting and Breakdown");
        public static readonly ProjectAction FinancingVerification = new ProjectAction(68, "FinancingVerification", "Financing Verification");
        public static readonly ProjectAction EstimatingMgrReturn = new ProjectAction(69, "EstimatingMgrReturn", "Estimating Mgr Return");
        public static readonly ProjectAction ReviewBidAnalysisResultsApprove4 = new ProjectAction(70, "ReviewBidAnalysisResultsApprove4", "Review Bid Analysis Results Approve 4");
        public static readonly ProjectAction NotifyCSEstimateRevision = new ProjectAction(224, "NotifyCSEstimateRevision", "Notify CS Estimate Revision"); 


        // New Bid Breakdown Analysis Workflow
        public static readonly ProjectAction ProceedWithProject = new ProjectAction(1901, "ProceedWithProject", "Proceed With Project");
        public static readonly ProjectAction PutProjectOnHold = new ProjectAction(1902, "PutProjectOnHold", "Put Project on hold");
        public static readonly ProjectAction BypassBidBreakdown      = new ProjectAction(1903, "BypassBidBreakdown", "Bypass Bid Breakdown");
        public static readonly ProjectAction BAFOAnalysis = new ProjectAction(1904, "BAFOAnalysis", "Pending BAFO Analysis");
        public static readonly ProjectAction BAFOApproved = new ProjectAction(1905, "BAFOApproved", "BAFO Approved");
        public static readonly ProjectAction BAFORejected= new ProjectAction(1906, "BAFORejected", "BAFO Rejected");
        public static readonly ProjectAction ReBidFromBreakdown= new ProjectAction(1907, "ReBidFromBreakDown", "ReBid From Breakdown");
        public static readonly ProjectAction ProjectCancelFromBreakdown = new ProjectAction(1908, "ProjectCancelFromBreakdown", "Project Cancel From Breakdown");

        // Contract Package Creation Workflow 
        public static readonly ProjectAction CreateRoutingPackage = new ProjectAction(71, "CreateRoutingPackage", "Create Routing Package");

        public static readonly ProjectAction MgrRoutingPackageReturn = new ProjectAction(72, "MgrRoutingPackageReturn", "Mgr Routing Package Return");
        public static readonly ProjectAction MgrRoutingPackageApprove = new ProjectAction(73, "MgrRoutingPackageApprove", "Mgr Routing Package Approve");
        public static readonly ProjectAction ReviseRoutingPackage = new ProjectAction(74, "ReviseRoutingPackage", "Revise Routing Package");
        public static readonly ProjectAction MgrRoutingPackageReturn1 = new ProjectAction(75, "MgrRoutingPackageReturn1", "Mgr Routing Package Return 1");
        public static readonly ProjectAction MgrRoutingPackageApprove1 = new ProjectAction(76, "MgrRoutingPackageApprove1", "Mgr Routing Package Approve 1");
        public static readonly ProjectAction DirectorRoutingPackageReturn = new ProjectAction(77, "DirectorRoutingPackageReturn", "Director Routing Package Return");
        public static readonly ProjectAction DirectorRoutingPackageApprove = new ProjectAction(78, "DirectorRoutingPackageApprove", "Director Routing Package Approve");
        public static readonly ProjectAction ReviseRoutingPackage1 = new ProjectAction(79, "ReviseRoutingPackage1", "Revise Routing Package 1");
        public static readonly ProjectAction DirectorRoutingPackageReturn1 = new ProjectAction(80, "DirectorRoutingPackageReturn1", "Director Routing Package Return 1");
        public static readonly ProjectAction DirectorRoutingPackageApprove1 = new ProjectAction(81, "DirectorRoutingPackageApprove1", "Director Routing Package Approve 1");


        public static readonly ProjectAction IssueIntenttoAwardNotice = new ProjectAction(85, "IssueIntenttoAwardNotice", "Issue Intent to Award Notice");


        // Routing Package Approval Workflow
        public static readonly ProjectAction RoutingPackageApprovalComplete = new ProjectAction(200, "RoutingPackageApprovalComplete", "Routing Package Approval Complete");

        // Routing to Finance Workflow 
        // 20181119 PCH Redefine RinanceRoutingXXX ProjectAction
        public static readonly ProjectAction FinanceRoutingApprove1 = new ProjectAction(201, "FinanceRoutingApprove1", "Finance Routing Approve 1");
        //public static readonly ProjectAction FinanceRoutingApprove1a = new ProjectAction(202, "FinanceRoutingApprove1a", "Finance Routing Approve 1 a");
        public static readonly ProjectAction FinanceRoutingApprove2 = new ProjectAction(203, "FinanceRoutingApprove2", "Finance Routing Approve 2");
       // public static readonly ProjectAction FinanceRoutingApprove2a = new ProjectAction(204, "FinanceRoutingApprove2a", "Finance Routing Approve 2 a");
        public static readonly ProjectAction FinanceRoutingApprove3 = new ProjectAction(205, "FinanceRoutingApprove3", "Finance Routing Approve 3");
        // public static readonly ProjectAction FinanceRoutingApprove3a = new ProjectAction(206, "FinanceRoutingApprove3a", "Finance Routing Approve 3 a");
        public static readonly ProjectAction FinanceRoutingDeny = new ProjectAction(206, "FinanceRoutingDeny", "Finance Routing Deny");
        public static readonly ProjectAction FinanceRoutingHold1 = new ProjectAction(207, "FinanceRoutingHold1", "Finance Routing Hold 1");
        public static readonly ProjectAction FinanceRoutingHold2 = new ProjectAction(208, "FinanceRoutingHold2", "Finance Routing Hold 2");
        //public static readonly ProjectAction FinanceRoutingHold3 = new ProjectAction(209, "FinanceRoutingHold3", "Finance Routing Hold 3");
        public static readonly ProjectAction FinanceRoutingReturn1= new ProjectAction(209, "FinanceRoutingReturn1", "Finance Routing Return 1");
      
        // Routing to OIG Workflow 
        public static readonly ProjectAction OIGBidderApprove = new ProjectAction(210, "OIGBidderApprove", "OIG Bidder Approve");
        public static readonly ProjectAction OIGReviewBidderIssue = new ProjectAction(211, "OIGReviewBidderIssue", "OIG Review Bidder Issue");
        public static readonly ProjectAction ReturnToOIG = new ProjectAction(225, "ReturnToOIG", "Return To OIG");

        // Routing to CQU Workflow 
        public static readonly ProjectAction CQURoutingApprove = new ProjectAction(212, "Pre-qualificationRoutingApprove", "Pre-qualification Routing Approve");
        public static readonly ProjectAction CQURoutingApprove1 = new ProjectAction(213, "Pre-qualificationRoutingApprove1", "Pre-qualification Routing Approve 1");
        public static readonly ProjectAction CQURoutingHold = new ProjectAction(214, "Pre-qualificationRoutingHold", "Pre-qualification Routing Hold");

        public static readonly ProjectAction AdminRoutingApprove = new ProjectAction(218, "AdminRoutingApprove", "Admin Routing Approve");
        public static readonly ProjectAction AdminRoutingApprove1 = new ProjectAction(219, "AdminRoutingApprove1", "Admin Routing Approve 1");
        public static readonly ProjectAction AdminRoutingHold = new ProjectAction(220, "AdminRoutingHold", "Admin Routing Approve Hold");


        // Routing to VPCM Workflow 
        public static readonly ProjectAction VPCMRoutingApprove = new ProjectAction(212, "VPCMRoutingApprove", "VPCM Routing Approve");
        public static readonly ProjectAction VPCMRoutingApprove1 = new ProjectAction(213, "VPCMRoutingApprove1", "VPCM Routing Approve 1");
        public static readonly ProjectAction VPCMRoutingDisapprove = new ProjectAction(218, "VPCMRoutingDisapprove", "VPCM Routing Disapprove");
        public static readonly ProjectAction VPCMRoutingDisapprove1 = new ProjectAction(219, "VPCMRoutingDisapprove1", "VPCM Routing Disapprove 1");
        
        public static readonly ProjectAction VPCMRoutingHold = new ProjectAction(214, "VPCMRoutingHold", "VPCM Routing Hold");

        // Routing to BDD Workflow 
        public static readonly ProjectAction BDDRoutingApprove = new ProjectAction(215, "BDDRoutingApprove", "BDD Routing Approve");
        public static readonly ProjectAction BDDRoutingApprove1 = new ProjectAction(216, "BDDRoutingApprov1e", "BDD Routing Approve 1");
        public static readonly ProjectAction BDDRoutingHold = new ProjectAction(217, "BDDRoutingHold", "BDD Routing Hold");

        
        // Contract Execution Workflow
        public static readonly ProjectAction CreateExecutionPackage = new ProjectAction(101, "CreateExecutionPackage", "Create Execution Package");
        public static readonly ProjectAction ExecutionPackageOnHold = new ProjectAction(102, "ExecutionPackageOnHold", "Execution Package On Hold");
        public static readonly ProjectAction ReleaseExecutionPackage = new ProjectAction(103, "ReleaseExecutionPackage", "Release Execution Package");
        public static readonly ProjectAction LegalExecutionPackageReview = new ProjectAction(104, "LegalExecutionPackageReview", "Legal Execution Package Review");
        public static readonly ProjectAction LegalExecutionPackageReturn = new ProjectAction(105, "LegalExecutionPackageReturn", "Legal Execution Package Return");
        public static readonly ProjectAction LegalExecutionPackageReview1 = new ProjectAction(107, "LegalExecutionPackageReview1", "Legal Execution Package Review 1");

        public static readonly ProjectAction VPCPExecutionPackageReview = new ProjectAction(314, "VPCPExecutionPackageReview", "VP CP Execution Package Review");
        public static readonly ProjectAction VPCPExecutionPackageReturn = new ProjectAction(315, "VPCPExecutionPackageReturn", "VP CP Execution Package Return");
        public static readonly ProjectAction VPCPExecutionPackageReview1 = new ProjectAction(316, "VPCPExecutionPackageReview1", "VP CP Execution Package Review 1");


        public static readonly ProjectAction EVPExecutionPackageReview = new ProjectAction(317, "EVPExecutionPackageReview", "EVP Execution Package Review");
        public static readonly ProjectAction EVPExecutionPackageReturn = new ProjectAction(318, "EVPExecutionPackageReturn", "EVP Execution Package Return");
        public static readonly ProjectAction EVPExecutionPackageReview1 = new ProjectAction(319, "EVPExecutionPackageReview1", "EVP Execution Package Review 1");

        public static readonly ProjectAction ReviseExecutionPackage2 = new ProjectAction(326, "ReviseExecutionPackage2", "Revise Execution Package 2");
        public static readonly ProjectAction ReviseExecutionPackage3 = new ProjectAction(327, "ReviseExecutionPackage3", "Revise Execution Package 3");



        public static readonly ProjectAction SrDirectorExecutionPackageReview = new ProjectAction(164, "SrDirectorExecutionPackageReview", "SrDirector Execution Package Review");
        public static readonly ProjectAction SrDirectorExecutionPackageReturn = new ProjectAction(165, "SrDirectorExecutionPackageReturn", "SrDirector Execution Package Return");



        public static readonly ProjectAction ReviseExecutionPackage = new ProjectAction(106, "ReviseExecutionPackage", "Revise Execution Package");
        public static readonly ProjectAction ReviseExecutionPackage1 = new ProjectAction(166, "ReviseExecutionPackage1", "Revise Execution Package 1");


        public static readonly ProjectAction SrDirectorExecutionPackageReview1 = new ProjectAction(167, "SrDirectorExecutionPackageReview1", "SrDirector Execution Package Review 1");

        public static readonly ProjectAction PresidentExecutionPackageReview = new ProjectAction(108, "PresidentExecutionPackageReview", "President Execution Package Review");
        public static readonly ProjectAction PresidentExecutionPackageReview1 = new ProjectAction(109, "PresidentExecutionPackageReview1", "President Execution Package Review 1");
        public static readonly ProjectAction PresidentExecutionPackagePending = new ProjectAction(110, "PresidentExecutionPackagePending", "President Execution Package Pending");
        public static readonly ProjectAction IssueNoticeofAward = new ProjectAction(111, "IssueNoticeofAward", "Issue Notice of Award");
        public static readonly ProjectAction IssueNoticeofAwardReturn = new ProjectAction(112, "IssueNoticeofAwardReturn", "Issue Notice of Award Return");
        public static readonly ProjectAction OIGApprove = new ProjectAction(113, "OIGApprove", "OIG Approve");
        public static readonly ProjectAction PresidentCancel = new ProjectAction(114, "PresidentCancel", "President Cancel");

        // Mentor Pre-Award Vetting Workflow
        public static readonly ProjectAction MentorAssignAnalyst = new ProjectAction(151, "MentorAssignAnalyst", "Mentor Assign Analyst");
        public static readonly ProjectAction MentorReviewVettingApprove = new ProjectAction(152, "MentorReviewVettingApprove", "Mentor Review Vetting Approve");
        public static readonly ProjectAction MentorReviewVettingIssues = new ProjectAction(153, "MentorReviewVettingIssues", "Mentor Review Vetting Issues");
        public static readonly ProjectAction MentorVettingRevision = new ProjectAction(154, "MentorVettingRevision", "Mentor Vetting Revision");
        public static readonly ProjectAction MentorSelectNextLowBidder = new ProjectAction(155, "MentorSelectNextLowBidder", "Mentor Select Next Low Bidder");
        public static readonly ProjectAction MentorReviewTrades = new ProjectAction(156, "MentorReviewTrades", "Mentor Review Trades");
        public static readonly ProjectAction MentorManagerFinalReviewApprove = new ProjectAction(158, "MentorManagerFinalReviewApprove", "Mentor Manager Final Review Approve");
        public static readonly ProjectAction MentorManagerFinalReviewDeny = new ProjectAction(159, "MentorManagerFinalReviewDeny", "Mentor Manager Final Review Deny");
        public static readonly ProjectAction MentorManagerFinalReviewOnHold = new ProjectAction(160, "MentorManagerFinalReviewOnHold", "Mentor Manager Final Review On Hold");
        public static readonly ProjectAction MentorResolveVettingIssue = new ProjectAction(161, "MentorResolveVettingIssue", "Mentor Resolve Vetting Issue");
        public static readonly ProjectAction MentorVettingDisapprove = new ProjectAction(162, "MentorVettingDisapprove", "Mentor Vetting Disapprove");
        public static readonly ProjectAction MentorVettingComplete = new ProjectAction(222, "MentorVettingComplete", "Mentor Vetting Complete");
        public static readonly ProjectAction MentorVettingFinished = new ProjectAction(223, "MentorVettingFinished", "Mentor Vetting Finished");

        public static readonly ProjectAction MentorFinancialReview = new ProjectAction(170, "MentorFinancialReview", "Mentor Financial Review");
        public static readonly ProjectAction MentorReviewBidBonds = new ProjectAction(171, "MentorReviewBidBonds", "Mentor Review Bid Bonds");
        public static readonly ProjectAction MentorFinancialReview2 = new ProjectAction(172, "MentorFinancialReview2", "Mentor Financial Review 2");
        public static readonly ProjectAction MentorReviewBidBonds2 = new ProjectAction(173, "MentorReviewBidBonds2", "Mentor Review Bid Bonds 2");
        public static readonly ProjectAction MentorFinancialFailed = new ProjectAction(174, "MentorFinancialFailed", "Mentor Financial Failed");
        public static readonly ProjectAction MentorFinancialFailed2 = new ProjectAction(175, "MentorFinancialFailed2", "Mentor Financial Failed 2");
        public static readonly ProjectAction MentorBondIssues = new ProjectAction(176, "MentorBondIssues", "Mentor Bond Issues");
        public static readonly ProjectAction MentorBondIssues2 = new ProjectAction(177, "MentorBondIssues2", "Mentor Bond Issues 2");
        public static readonly ProjectAction MentorBondMerge2 = new ProjectAction(178, "MentorBondMerge2", "Mentor Bond Merge 2");

        public static readonly ProjectAction MentorFinancialVerify = new ProjectAction(180, "MentorFinancialVerify", "Mentor Financial Verify");
        public static readonly ProjectAction MentorFinancialRequestMoreInfo = new ProjectAction(181, "MentorFinancialRequestMoreInfo", "Mentor Financial Request More Info");
        public static readonly ProjectAction MentorFinancialInsuffcientFunding = new ProjectAction(182, "MentorFinancialInsuffcientFunding", "Mentor Financial Insuffcient Funding");
        public static readonly ProjectAction MentorFinancialMoreInfoSubmit = new ProjectAction(183, "MentorFinancialMoreInfoSubmit", "Mentor Financial More Info Submit");
        public static readonly ProjectAction MentorBudgetAdjustmentRequired = new ProjectAction(283, "MentorBudgetAdjustmentRequired", "Mentor Budget Adjustment Required");
        public static readonly ProjectAction MentorBudgetAdjustmentSubmit = new ProjectAction(284, "MentorBudgetAdjustmentSubmit", "Budget Adjustment Submit");

        public static readonly ProjectAction MentorCMAward = new ProjectAction(184, "MentorCMAward", "Mentor CM Award");
        public static readonly ProjectAction MentorCMSelectNextLowBidder = new ProjectAction(185, "MentorCMSelectNextLowBidder", "Mentor CM Select Next Low Bidder");
        public static readonly ProjectAction MentorCPOAward = new ProjectAction(186, "MentorCPOAward", "Mentor CPO Award");
        public static readonly ProjectAction TurnoverToMentorCMAward = new ProjectAction(198, "TurnoverToMentorCMAward", "Turnover To Mentor CM Award");
        public static readonly ProjectAction MentorCPOSelectNextLowBidder = new ProjectAction(187, "MentorCPOSelectNextLowBidder", "Mentor CPO Select Next Low Bidder");
        public static readonly ProjectAction MentorCanceled = new ProjectAction(188, "MentorCanceled", "Canceled");
        public static readonly ProjectAction MentorCPOOnHold = new ProjectAction(189, "MentorCPOOnHold", "Mentor CPO On Hold");
        public static readonly ProjectAction MentorFinancialNew = new ProjectAction(190, "MentorFinancialNew", "Mentor Financial New");

        public static readonly ProjectAction PendingMentorFinancingAction = new ProjectAction(191, "PendingMentorFinancingAction", "Pending Mentor Financing Action");
        public static readonly ProjectAction PendingMentorCPOReviewAction = new ProjectAction(192, "PendingMentorCPOReviewAction", "Pending Mentor CPO Review Action");
        public static readonly ProjectAction MentorAwardAction = new ProjectAction(193, "MentorAwardAction", "Mentor Award Action");
        public static readonly ProjectAction PendingMentorReviewsAction = new ProjectAction(194, "PendingMentorReviewsAction", "Pending Mentor Reviews Action");

   

        #endregion

        #region Constructors
        public ProjectAction()
        {
        }

        private ProjectAction(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectAction class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ProjectAction.  
        /// </summary>
        public static ProjectAction Default
        {
            get
            {
                return (ProjectAction)_list[0];
            }
        }
        #endregion/

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectAction class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectAction object.
        /// It allows a string to be assigned to a ProjectAction object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ProjectAction(int id)
        {
            return (ProjectAction)EnumerationBase.FindById(id, ProjectAction._list);
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectAction objects.
    /// It's very useful when binding ProjectAction objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ProjectActionConverter : TypeConverter
    {

        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ProjectAction._list);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectAction enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ProjectAction._list.Count; i++)
            {
                list.Add(((ProjectAction)ProjectAction._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
   
}
