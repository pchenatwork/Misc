#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of RfdProjectStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(RfdProjectStatusConverter))]
    public class RfdProjectStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly RfdProjectStatusType NewProject = new RfdProjectStatusType(0, "NewProject", "New Project");
        public static readonly RfdProjectStatusType PendingCPOApproval = new RfdProjectStatusType(1, "PendingCPOApproval", "Pending CPO Approval");
        public static readonly RfdProjectStatusType PendingVPCMApproval = new RfdProjectStatusType(2, "PendingVPCMApproval", "Pending VP for Construction Mgmt Approval");
        public static readonly RfdProjectStatusType PendingVPAdminApproval = new RfdProjectStatusType(3, "PendingVPAdminApproval", "Pending VP of Admin Approval");
        public static readonly RfdProjectStatusType ReadyForReview = new RfdProjectStatusType(4, "ReadyForReview", "Ready For Review");
        public static readonly RfdProjectStatusType RequestMoreInfo = new RfdProjectStatusType(5, "RequestMoreInfo", "Request More Info");
        public static readonly RfdProjectStatusType InfoReady = new RfdProjectStatusType(6, "InfoReady", "Info Ready");
        public static readonly RfdProjectStatusType ReviewerReviewed = new RfdProjectStatusType(7, "ReviewerReviewed", "Reviewer Reviewed");
        public static readonly RfdProjectStatusType QuestionFromManager = new RfdProjectStatusType(8, "QuestionFromManager", "Question From Manager");
        public static readonly RfdProjectStatusType ManagerApproved = new RfdProjectStatusType(9, "ManagerApproved", "Manager Approved");
        public static readonly RfdProjectStatusType QuestionFromDirector = new RfdProjectStatusType(10, "QuestionFromDirector", "Question From Director");
        public static readonly RfdProjectStatusType DirectorApproved = new RfdProjectStatusType(11, "DirectorApproved", "Director Approved");
        public static readonly RfdProjectStatusType VPAdminApproved = new RfdProjectStatusType(12, "VPAdminApproved", "VP of Admin Approved");
        public static readonly RfdProjectStatusType CPOApproved = new RfdProjectStatusType(13, "CPOApproved", "Chief Project Officer Approved");
        public static readonly RfdProjectStatusType VPCMApproved = new RfdProjectStatusType(14, "VPCMApproved", "VP for Construction Mgmt Approved");
        public static readonly RfdProjectStatusType GCApproved = new RfdProjectStatusType(15, "GCApproved", "General Counsel Approved");
        public static readonly RfdProjectStatusType PresidentApproved = new RfdProjectStatusType(16, "PresidentApproved", "President Approved");
        public static readonly RfdProjectStatusType Approved = new RfdProjectStatusType(17, "Approved", "Approved");
        public static readonly RfdProjectStatusType CMSelected = new RfdProjectStatusType(18, "CMSelected", "Construction Management Selected");
        public static readonly RfdProjectStatusType CriteriaRejected = new RfdProjectStatusType(19, "CriteriaRejected", "Criteria Rejected");
        public static readonly RfdProjectStatusType CriteriaPendingApproval = new RfdProjectStatusType(20, "CriteriaPendingApproval", "Criteria Pending Approval");
        public static readonly RfdProjectStatusType PendingDirectorMentorApproval = new RfdProjectStatusType(21, "PendingDirectorMentorApproval", "Pending Director of Mentor Program Approval");
        public static readonly RfdProjectStatusType PendingVetting = new RfdProjectStatusType(22, "PendingVetting", "Pending Vetting");
        public static readonly RfdProjectStatusType AnalystReviewed = new RfdProjectStatusType(23, "AnalystReviewed", "Analyst Reviewed");
        public static readonly RfdProjectStatusType BDDDirectorApproved = new RfdProjectStatusType(24, "BDDDirectorApproved", "BDD Director Approved");
        public static readonly RfdProjectStatusType PendingRefresh = new RfdProjectStatusType(25, "PendingRefresh", "Pending Refresh");
        public static readonly RfdProjectStatusType PendingReview = new RfdProjectStatusType(26, "PendingReview", "Pending Review");
        public static readonly RfdProjectStatusType ReviewerRefreshed = new RfdProjectStatusType(27, "ReviewerRefreshed", "Reviewer Refreshed");
        public static readonly RfdProjectStatusType ManagerRefreshed = new RfdProjectStatusType(28, "ManagerRefreshed", "Manager Refreshed");
        public static readonly RfdProjectStatusType DirectorRefreshed = new RfdProjectStatusType(29, "DirectorRefreshed", "Director Refreshed");
        public static readonly RfdProjectStatusType AnalystRefreshed = new RfdProjectStatusType(30, "AnalystRefreshed", "Analyst Refreshed");

        public static readonly RfdProjectStatusType PendingVPCapitalPlanningApproval = new RfdProjectStatusType(31, "PendingVPCapitalPlanningApproval", "Pending VP of Capital Planning Approval");
        public static readonly RfdProjectStatusType VPCapitalPlanningApproved = new RfdProjectStatusType(32, "VPCapitalPlanningApproved", "VP of Capital Planning Approved");

        public static readonly RfdProjectStatusType Canceled = new RfdProjectStatusType(98, "Canceled", "Canceled");
        public static readonly RfdProjectStatusType Closed = new RfdProjectStatusType(99, "Closed", "Closed");
        public static readonly RfdProjectStatusType Inactive = new RfdProjectStatusType(100, "Inactive", "Inactive");
        #endregion

        #region Constructors
        public RfdProjectStatusType()
        {
        }

        private RfdProjectStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in RfdProjectStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of RfdProjectStatus.  
        /// </summary>
        public static RfdProjectStatusType Default
        {
            get
            {
                return (RfdProjectStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for RfdProjectStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a RfdProjectStatus object.
        /// It allows a string to be assigned to a RfdProjectStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator RfdProjectStatusType(int id)
        {
            return (RfdProjectStatusType)EnumerationBase.FindById(id, RfdProjectStatusType._list);
        }
        public static implicit operator RfdProjectStatusType(string name)
        {
            for (int i = 0; i < RfdProjectStatusType._list.Count; i++)
            {
                if (((RfdProjectStatusType)RfdProjectStatusType._list[i]).Name == name)
                    return (RfdProjectStatusType)RfdProjectStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and RfdProjectStatus objects.
    /// It's very useful when binding RfdProjectStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class RfdProjectStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, RfdProjectStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the RfdProjectStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < RfdProjectStatusType._list.Count; i++)
            {
                list.Add(((RfdProjectStatusType)RfdProjectStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
