﻿using System;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.BusinessLogic.Rfd.Utilities;

namespace SCA.VAS.Workflow
{
    #region ConstantUtility
    public partial class ConstantUtility
    {
    }
    #endregion ConstantUtility

    public partial class CommonUtility
    {
        #region Pubulic Method

        #region DocumentProperty functions       

        public static DocumentProperty CreateRfdDocumentProperty(int propertyId, string propertyText, string changeUser)
        {
            DocumentProperty DocumentProperty = CreateRfdDocumentProperty(propertyId, propertyText, typeof(String), changeUser);
            return DocumentProperty;
        }

        public static DocumentProperty CreateRfdDocumentProperty(int propertyId, string value, Type type, string changeUser)
        {
            DocumentProperty DocumentProperty = DocumentPropertyUtility.CreateObject();
            DocumentProperty.PropertyId = propertyId;
            DocumentProperty.ChangeUser = changeUser;
            switch (type.Name)
            {
                case "Int32":
                    DocumentProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    DocumentProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    DocumentProperty.PropertyText = value;
                    break;
            }
            return DocumentProperty;
        }
        public static DocumentProperty GetRfdDocumentProperty(int propertyId, CommonCollection<DocumentProperty> DocumentProperties)
        {
            if (DocumentProperties == null) return DocumentPropertyUtility.CreateObject();
            foreach (DocumentProperty p in DocumentProperties)
            {
                if (p.PropertyId == propertyId)
                    return p;
            }
            return DocumentPropertyUtility.CreateObject();
        }

        #endregion DocumentProperty functions


        #region BidderProperty functions       

        public static BidderProperty CreateBidderProperty(int propertyId, string propertyText, string changeUser)
        {
            BidderProperty BidderProperty = CreateBidderProperty(propertyId, propertyText, typeof(String), changeUser);
            return BidderProperty;
        }
        public static BidderProperty CreateBidderProperty(int propertyId, int parentId, string propertyText, string changeUser)
        {
            BidderProperty BidderProperty = CreateBidderProperty(propertyId, parentId, propertyText, typeof(String), changeUser);
            return BidderProperty;
        }

        public static BidderProperty CreateBidderProperty(int propertyId, string propertyText, int documentId, string changeUser)
        {
            BidderProperty bidderProperty = CreateBidderProperty(propertyId, 0, propertyText, typeof(String), changeUser);
            bidderProperty.DocumentId = documentId;
            return bidderProperty;
        }

        public static BidderProperty CreateBidderProperty(int propertyId, string value, Type type, string changeUser)
        {
            BidderProperty bidderProperty = CreateBidderProperty(propertyId, 0, value, type, changeUser);
            return bidderProperty;
        }

        public static BidderProperty CreateBidderProperty(int propertyId, int parentId, string value, Type type, string changeUser)
        {
            BidderProperty BidderProperty = BidderPropertyUtility.CreateObject();
            BidderProperty.PropertyId = propertyId;
            BidderProperty.ParentId = parentId;
            BidderProperty.ChangeUser = changeUser;
            switch (type.Name)
            {
                case "Int32":
                    BidderProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    BidderProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    BidderProperty.PropertyText = value;
                    break;
            }
            return BidderProperty;
        }
        public static BidderProperty GetBidderProperty(int propertyId, CommonCollection<BidderProperty> BidderProperties)
        {
            if (BidderProperties == null) return BidderPropertyUtility.CreateObject();
            foreach (BidderProperty sp in BidderProperties)
            {
                if (sp.PropertyId == propertyId)
                    return sp;
            }
            return BidderPropertyUtility.CreateObject();
        }

        #endregion BidderProperty functions


        #endregion Public Mentod
    }
}
