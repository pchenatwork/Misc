﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Net.Mail;
using System.Configuration;

using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;
using System.Collections;
using SCA.VAS.Common.ValueObjects;


namespace SCA.VAS.Workflow
{
    public partial class CommonUtility
    {
        #region Email Method

        public static void SendEmailtoBDD(int userid, int supplierId)
        {
            Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierId);           
            User user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, CommonUtility.GetSupplierProperty("property524", supplier.SupplierProperties).PropertyText);
            EmailMessage emailmessage = EmailMessageUtility.GetByName(ConstantUtility.COMMON_DATASOURCE_NAME, "KEY_PERSON_BDD_NOTIFICATION");
            
            EmailMessage newMessage = EmailReplaceRelatedUsers(emailmessage, supplier);

            CommonUtility.SendEmail(newMessage, user, new object[] { supplier, user }, "", true, "Supplier", supplier.Id);
            
        }
        
        #endregion Email Method
       
    }
}
