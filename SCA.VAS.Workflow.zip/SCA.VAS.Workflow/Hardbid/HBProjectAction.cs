#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

using ProjectAction = SCA.VAS.Workflow.HBProjectAction;

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ProjectAction:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(HBProjectActionConverter))]
    public class HBProjectAction : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly HBProjectAction NoStatus = new HBProjectAction(0, "NoStatus", "No Status");
        public static readonly HBProjectAction CreateList = new HBProjectAction(1, "CreateList", "Create List For Review");
        public static readonly HBProjectAction CAUIntake = new HBProjectAction(2, "CAUIntake", "CAU Intake");
        public static readonly HBProjectAction CSReview = new HBProjectAction(3, "CSReview", "CS Review");
        public static readonly HBProjectAction CreateSolicitationPackage = new HBProjectAction(4, "CreateSolicitationPackage", "Create Solicitation Package");

        public static readonly HBProjectAction MgrSolicitationApprove = new HBProjectAction(5, "MgrSolicitationApprove", "Mgr Solicitation Approve");
        public static readonly HBProjectAction MgrSolicitationReturn = new HBProjectAction(6, "MgrSolicitationReturn", "Mgr Solicitation Return");
        public static readonly HBProjectAction ReviseCSReview = new HBProjectAction(7, "ReviseCSReview", "Revise CS Review");
        public static readonly HBProjectAction MgrSolicitationApprove1 = new HBProjectAction(8, "MgrSolicitationApprove1", "Mgr Solicitation Approve 1");
        public static readonly HBProjectAction MgrSolicitationReturn1 = new HBProjectAction(9, "MgrSolicitationReturn1", "Mgr Solicitation Return 1");
        
        public static readonly HBProjectAction DirectorSolicitationApprove = new HBProjectAction(10, "DirectorSolicitationApprove", "Director Solicitation Approve");
        public static readonly HBProjectAction DirectorSolicitationReturn = new HBProjectAction(11, "DirectorSolicitationReturn", "Director Solicitation Return");
        public static readonly HBProjectAction ReviseCSReview1 = new HBProjectAction(12, "ReviseCSReview1", "Revise CS Review 1");
        public static readonly HBProjectAction DirectorSolicitationAppove1 = new HBProjectAction(13, "DirectorSolicitationApprove1", "Director Solicitation Approve 1");
        public static readonly HBProjectAction DirectorSolicitationReturn1 = new HBProjectAction(14, "DirectorSolicitationReturn1", "Director Solicitation Return 1");
        
        public static readonly HBProjectAction IssueInvitationtoBidLetter = new HBProjectAction(15, "IssueInvitationtoBidLetter", "Issue Invitation to Bid Letter");
        public static readonly HBProjectAction SelectVendorforProduction = new HBProjectAction(16, "SelectVendorforProduction", "Select Vendor for Production");
        public static readonly HBProjectAction BidOpening = new HBProjectAction(17, "BidOpening", "Bid Opening");

        // RFI Submission / Processing Workflow 
        public static readonly HBProjectAction ReviewRFISubmission = new HBProjectAction(21, "ReviewRFISubmission", "Review RFI Submission");
        public static readonly HBProjectAction RespondtoRFI = new HBProjectAction(22, "RespondtoRFI", "Respond to RFI");
        public static readonly HBProjectAction ReviewRFIResponse = new HBProjectAction(23, "ReviewRFIResponse", "Review RFI Response");

        // Addendum Workflow 
        public static readonly HBProjectAction CreateAddendum = new HBProjectAction(31, "CreateAddendum", "Create Addendum");

        public static readonly HBProjectAction MgrAddendumReturn = new HBProjectAction(32, "MgrAddendumReturn", "Mgr Addendum Return");
        public static readonly HBProjectAction MgrAddendumApprove = new HBProjectAction(33, "MgrAddendumApprove", "Mgr Addendum Approve");
        public static readonly HBProjectAction MgrAddendumMentorApprove = new HBProjectAction(46, "MgrAddendumMentorApprove", "Mgr Addendum Mentor Approve");
        public static readonly HBProjectAction ReviseAddendum = new HBProjectAction(34, "ReviseAddendum", "Revise Addendum");
        public static readonly HBProjectAction MgrAddendumReturn1 = new HBProjectAction(35, "MgrAddendumReturn1", "Mgr Addendum Return 1");
        public static readonly HBProjectAction MgrAddendumApprove1 = new HBProjectAction(36, "MgrAddendumApprove1", "Mgr Addendum Approve 1");
        public static readonly HBProjectAction MgrAddendumMentorApprove1 = new HBProjectAction(47, "MgrAddendumMentorApprove1", "Mgr Addendum Mentor Approve 1");

        public static readonly HBProjectAction DirectorAddendumReturn = new HBProjectAction(37, "DirectorAddendumReturn", "Director Addendum Return");
        public static readonly HBProjectAction DirectorAddendumApprove = new HBProjectAction(38, "DirectorAddendumApprove", "Director Addendum Approve");
        public static readonly HBProjectAction ReviseAddendum1 = new HBProjectAction(39, "ReviseAddendum1", "Revise Addendum 1");
        public static readonly HBProjectAction DirectorAddendumReturn1 = new HBProjectAction(40, "DirectorAddendumReturn1", "Director Addendum Return 1");
        public static readonly HBProjectAction DirectorAddendumApprove1 = new HBProjectAction(41, "DirectorAddendumApprove1", "Director Addendum Approve 1");

        //Project Complete & Cancelled
        public static readonly HBProjectAction ProjectCompleted = new HBProjectAction(446, "ProjectCompleted", "Project Completed");
        public static readonly HBProjectAction ProjectCancelled = new HBProjectAction(447, "ProjectCancelled", "Project Cancelled");
        public static readonly HBProjectAction ProjectOnHold = new HBProjectAction(448, "ProjectOnHold", "Project OnHold");

        // Bid Recording Workflow
        public static readonly HBProjectAction RecordBidders = new HBProjectAction(42, "RecordBidders", "Record Bidders");
        public static readonly HBProjectAction OpenBid = new HBProjectAction(43, "OpenBid", "Open Bid");
        public static readonly HBProjectAction CertifyBidTab = new HBProjectAction(44, "CertifyBidTab", "Certify Bid Tab");
        public static readonly HBProjectAction ReviewBidResults = new HBProjectAction(45, "ReviewBidResults", "Review Bid Results");

        // Pre-Award Vetting Workflow

        public static readonly HBProjectAction BidBondApproved = new HBProjectAction(401, "BidBondApproved", "Bid Bond Approved");
        public static readonly HBProjectAction PendingBidBondRemediation = new HBProjectAction(402, "PendingBidBondRemediation", "Pending Bid Bond Remediation");
        public static readonly HBProjectAction RemediationFailed = new HBProjectAction(403, "RemediationFailed", "Remediation Failed");

        public static readonly HBProjectAction FinancialApproved = new HBProjectAction(404, "FinancialApproved", "Financial Approved");
        public static readonly HBProjectAction PendingFinancialRemediation = new HBProjectAction(405, "PendingFinancialRemediation", "Pending Financial Remediation");


        public static readonly HBProjectAction AssignReviewer4TradeVerification = new HBProjectAction(121, "AssignReviewer4TradeVerification", "Assign Reviewer for Trade Verification");
        public static readonly HBProjectAction AssignReviewer4ReviewerVetting = new HBProjectAction(121, "AssignReviewer4ReviewerVetting", "Assign Reviewer for Reviewer Vetting");
        public static readonly HBProjectAction ReviewVettingApprove = new HBProjectAction(122, "ReviewVettingApprove", "Review Vetting Approve");
        public static readonly HBProjectAction ReviewVettingIssues = new HBProjectAction(123, "ReviewVettingIssues", "Review Vetting Issues");
        public static readonly HBProjectAction VettingRevision = new HBProjectAction(124, "VettingRevision", "Vetting Revision");
        public static readonly HBProjectAction VettingRevisionDisapprove = new HBProjectAction(125, "VettingRevisionDisapprove", "Vetting Revision Disapprove");
        public static readonly HBProjectAction ReviewTrades = new HBProjectAction(126, "ReviewTrades", "Review Trades");
        public static readonly HBProjectAction TradesVerified = new HBProjectAction(127, "TradesVerified", "Trades Verified");
        public static readonly HBProjectAction ReviewTradesIssues = new HBProjectAction(528, "ReviewTradesIssues", "Review Trades Issues");
        public static readonly HBProjectAction TradeRemediationFailed = new HBProjectAction(529, "TradeRemediationFailed", "Trade Remediation Failed");
        public static readonly HBProjectAction TradeCodesRemediated = new HBProjectAction(530, "TradeCodesRemediated", "Trade Codes Remediated");
        public static readonly HBProjectAction ReturntoReviewer = new HBProjectAction(531, "ReturntoReviewer", "Return to Reviewer");

        public static readonly HBProjectAction ManagerFinalReview = new HBProjectAction(131, "ManagerFinalReview", "Manager Final Review");
        public static readonly HBProjectAction ManagerFinalReviewApprove = new HBProjectAction(127, "ManagerFinalReviewApprove", "Manager Final Review Approve");
        public static readonly HBProjectAction ManagerFinalReviewDeny = new HBProjectAction(128, "ManagerFinalReviewDeny", "Manager Final Review Deny");
        public static readonly HBProjectAction ManagerFinalReviewOnHold = new HBProjectAction(128, "ManagerFinalReviewOnHold", "Manager Final Review On Hold");

        public static readonly HBProjectAction ResolveVettingIssue = new HBProjectAction(129, "ResolveVettingIssue", "Resolve Vetting Issue");
        public static readonly HBProjectAction RequestNextLowBidder = new HBProjectAction(130, "RequestNextLowBidder", "Request Next Low Bidder");
        public static readonly HBProjectAction VettingDisapprove = new HBProjectAction(140, "VettingDisapprove", "Vetting Disapprove");
        public static readonly HBProjectAction VettingFinished = new HBProjectAction(221, "VettingFinished", "Vetting Finished");

        public static readonly HBProjectAction VettingDirectorReview = new HBProjectAction(550, "VettingDirectorReview", "Vetting Director Review");

        public static readonly HBProjectAction VettingDirectorApproved = new HBProjectAction(551, "VettingDirectorApproved", "Vetting Director Approved");
        public static readonly HBProjectAction VettingDirectorDisapproved = new HBProjectAction(552, "VettingDirectorDisapproved", "Vetting Director Disapproved");
        public static readonly HBProjectAction VettingDirectorRequestToReVett = new HBProjectAction(553, "VettingDirectorRequestToReVett", "Vetting Director Request To Re-Vett");
        public static readonly HBProjectAction VettingDirectorApprovedFinishVetting = new HBProjectAction(554, "VettingDirectorApprovedFinishVetting", "Vetting Director Approved- Finish Vetting");


        public static readonly HBProjectAction ManagerFinancialReviewApproved = new HBProjectAction(301, "FinancialManagerReviewApproved", "Financial Manager Review - Approved");
        public static readonly HBProjectAction ManagerFinancialReviewDenied = new HBProjectAction(303, "ManagerFinancialReviewDenied", "Manager Financial Review - Denied");

        public static readonly HBProjectAction ManagerBidBondReviewApproved = new HBProjectAction(302, "BidBondManagerReviewApproved", "Bid Bonds Manager Review - Approved");
        public static readonly HBProjectAction ManagerBidBondReviewDenied = new HBProjectAction(304, "ManagerRecommendationFailed", "Bid Bonds Manager Review - Denied");

        

        // adding a new step to merge the CQU vetting and send request to CAU to pick the next bidder because CQU rejected first bidder
        public static readonly HBProjectAction CompleteNextLowBidderRequest = new HBProjectAction(227, "CompleteNextLowBidderRequest", "Complete Next Low Bidder Request");


        public static readonly HBProjectAction FinancialReview = new HBProjectAction(130, "FinancialReview", "Financial Review");
        public static readonly HBProjectAction ReviewBidBonds = new HBProjectAction(131, "ReviewBidBonds", "Review Bid Bonds");
        public static readonly HBProjectAction FinancialReview2 = new HBProjectAction(132, "FinancialReview2", "Financial Review 2");
        public static readonly HBProjectAction ReviewBidBonds2 = new HBProjectAction(133, "ReviewBidBonds2", "Review Bid Bonds 2");
        public static readonly HBProjectAction FinancialFailed = new HBProjectAction(134, "FinancialFailed", "Financial Failed");
        public static readonly HBProjectAction FinancialFailed2 = new HBProjectAction(135, "FinancialFailed2", "Financial Failed 2");
        public static readonly HBProjectAction BondIssues = new HBProjectAction(136, "BondIssues", "Bond Issues");

        // new actions
        public static readonly HBProjectAction RemediateFailedFinancials = new HBProjectAction(139, "RemediateFailedFinancials", "Remediate Failed Financials");
        public static readonly HBProjectAction RemediateBondIssues = new HBProjectAction(141, "RemediateBondIssues", "Remediate Bond Issues");


        public static readonly HBProjectAction BondIssues2 = new HBProjectAction(137, "BondIssues2", "Bond Issues 2");
        public static readonly HBProjectAction BondMerge2 = new HBProjectAction(138, "BondMerge2", "Bond Merge 2");
        public static readonly HBProjectAction RemediateRS1Vetting = new HBProjectAction(231, "RemediateRS1Vetting", "RS1 Vetting Remediate");
        public static readonly HBProjectAction CompeleteRemediateRS1Vetting = new HBProjectAction(232, "CompeleteRemediateRS1Vetting", "RS1 Vetting Remediate - Compelete");


        // BAFO Analysis Workflow
        public static readonly HBProjectAction BAFONotReceivedProceedWithAward = new HBProjectAction(1901, "BAFONotReceivedProceedWithAward", "BAFO Not Received Proceed With Award");
        public static readonly HBProjectAction BAFONotReceivedNoAward = new HBProjectAction(1902, "BAFONotReceivedNoAward", "BAFO Not Received No Award");
        public static readonly HBProjectAction BAFOBypass      = new HBProjectAction(1903, "BAFOBypass", "BAFO Bypass");
        public static readonly HBProjectAction BAFOAnalysis = new HBProjectAction(1904, "BAFOPendingAnalysis", "BAFO Pending Analysis");
        public static readonly HBProjectAction BAFOApproved = new HBProjectAction(1905, "BAFOApproved", "BAFO Approved");
        public static readonly HBProjectAction BAFORejected= new HBProjectAction(1906, "BAFORejected", "BAFO Rejected");        
        public static readonly HBProjectAction BAFOSelectNextBidder = new HBProjectAction(1910, "BAFOSelectNextBidder", "BAFO Select Next Bidder");
        public static readonly HBProjectAction BafoNotRequested = new HBProjectAction(1903, "BAFONotRequested", "BAFO Not Requested");

        #region ^Routing Package ...

        // Contract Package Creation Workflow 
        public static readonly HBProjectAction CreateRoutingPackage = new HBProjectAction(71, "CreateRoutingPackage", "Create Routing Package");
        public static readonly HBProjectAction RoutingManagerPending = new HBProjectAction(82, "ManagerRoutingPending", "Manager Routing Pending");
        public static readonly HBProjectAction DirectorRoutingPending = new HBProjectAction(83, "DirectorRoutingPending", "Director Routing Pending");
        public static readonly HBProjectAction MgrRoutingPackageReturn = new HBProjectAction(72, "MgrRoutingPackageReturn", "Mgr Routing Package Return");
        public static readonly HBProjectAction MgrRoutingPackageApprove = new HBProjectAction(73, "MgrRoutingPackageApprove", "Mgr Routing Package Approve");
        public static readonly HBProjectAction ReviseRoutingPackage = new HBProjectAction(74, "ReviseRoutingPackage", "Revise Routing Package");
        public static readonly HBProjectAction MgrRoutingPackageReturn1 = new HBProjectAction(75, "MgrRoutingPackageReturn1", "Mgr Routing Package Return 1");
        public static readonly HBProjectAction MgrRoutingPackageApprove1 = new HBProjectAction(76, "MgrRoutingPackageApprove1", "Mgr Routing Package Approve 1");
        public static readonly HBProjectAction DirectorRoutingPackageReturn = new HBProjectAction(77, "DirectorRoutingPackageReturn", "Director Routing Package Return");
        public static readonly HBProjectAction DirectorRoutingPackageApprove = new HBProjectAction(78, "DirectorRoutingPackageApprove", "Director Routing Package Approve");
        public static readonly HBProjectAction ReviseRoutingPackage1 = new HBProjectAction(79, "ReviseRoutingPackage1", "Revise Routing Package 1");
        public static readonly HBProjectAction DirectorRoutingPackageReturn1 = new HBProjectAction(80, "DirectorRoutingPackageReturn1", "Director Routing Package Return 1");
        public static readonly HBProjectAction DirectorRoutingPackageApprove1 = new HBProjectAction(81, "DirectorRoutingPackageApprove1", "Director Routing Package Approve 1");


        public static readonly HBProjectAction IssueIntenttoAwardNotice = new HBProjectAction(85, "IssueIntenttoAwardNotice", "Issue Intent to Award Notice");


        // Routing Package Approval Workflow
        public static readonly HBProjectAction RoutingPackageApprovalComplete = new HBProjectAction(200, "RoutingPackageApprovalComplete", "Routing Package Approval Complete");

        // Routing to Finance Workflow      
        public static readonly HBProjectAction FinRoutingBudgetTeamApprovalAtReview = new HBProjectAction           (201, "FinRoutingBudgetTeamApprovalOnReview"                    , "Fin Routing Budget Team Approval On Review");
        public static readonly HBProjectAction FinRoutingBudgetTeamApprovalAtOnHold = new HBProjectAction           (443, "FinRoutingBudgetTeamApprovalOnHold"                      , "Fin Routing Budget Team Approval On Hold");
        public static readonly HBProjectAction FinanceRoutingEncumbranceApproval = new HBProjectAction              (203, "FinanceRoutingEncumbranceApproval"                       , "Financal Routing Encumbrance Approval");

        public static readonly HBProjectAction FinanceRoutingApprovedAndCompleted = new HBProjectAction             (205, "FinanceRoutingApprovedAndCompleted"                      , "Finance Routing Approved And Completed");
        public static readonly HBProjectAction FinanceRoutingDeny = new HBProjectAction                             (206, "FinanceRoutingDeny"                                      , "Finance Routing Deny");

        public static readonly HBProjectAction FinanceRoutingHold1 = new HBProjectAction                            (207, "FinanceRoutingHold1"                                     , "Finance Routing Hold 1");
        public static readonly HBProjectAction FinanceRoutingEncumbranceOnHold = new HBProjectAction                (208, "FinanceRoutingEncumbranceOnHold"                         , "Finance Routing Encumbrance OnHold");

        public static readonly HBProjectAction FinanceRoutingEcumbranceReturn = new HBProjectAction                 (209, "FinanceRoutingEcumbranceReturn"                          , "Finance Routing Encumbrance Return");

        public static readonly HBProjectAction FinRoutingOperatingBudgetTeamOnHold = new HBProjectAction            (400, "FinRoutingOprBudgetTeamOnHold"                           , "Fin Routing Opr Budget Team OnHold");
        public static readonly HBProjectAction FinRoutingOperatingBudgetTeamApproval = new HBProjectAction          (401, "FinRoutingOprBudgetTeamApproval"                         , "Fin Routing Opr Budget Team Approval");
        public static readonly HBProjectAction FinRoutingOperatingBudgetTeamApprovalOnHold = new HBProjectAction    (444, "FinRoutingOprBudgetTeamApprovalOnHold"                   , "Fin Routing Opr Budget Team Approval On Hold");
        public static readonly HBProjectAction FinRoutingOperatingBudgetTeamReturn = new HBProjectAction            (402, "FinRoutingOprBudgetTeamReturn"                           , "Fin Routing Opr Budget Team Return");
        public static readonly HBProjectAction FinRoutingOperatingBudgetTeamReturnOnHold = new HBProjectAction      (445, "FinRoutingOprBudgetTeamReturnonHold"                     , "Fin Routing Opr Budget Team Return On Hold");

        public static readonly HBProjectAction FinRoutingForwardToOprBudgetTeam = new HBProjectAction               (404, "FinRoutingForwardToOprBudgetTeam"                        , "Fin Routing Forward To Opr Budget Team");
        public static readonly HBProjectAction FinRoutingOnHoldToOprBudgetTeam = new HBProjectAction                (405, "FinRoutingForwardToOprBudgetTeam"                        , "Fin Routing OnHold To Opr Budget Team");

        public static readonly HBProjectAction FinanceRoutingEncumReviewEncumReturn = new HBProjectAction           (420, "FinanceRoutingEncumReviewEncumReturn"                    , "Finance Routing Encum. Review After Return");
        public static readonly HBProjectAction FinanceRoutingOprBgdTeamReviewEncumReturn = new HBProjectAction      (421, "FinanceRoutingOprBgdTeamReviewEncumReturn"               , "Finance Routing Opr. Bgd. Team Encum. Return");
        public static readonly HBProjectAction FinanceRoutingBgdOnHoldfterReturn = new HBProjectAction              (422, "FinanceRoutingBdgOnHoldEncumReturn"                      , "Finance Routing Bgd. On Hold Encum. Return");
        public static readonly HBProjectAction FinRoutingOprBdgTeamRetToPendingFinRev = new HBProjectAction         (423, "FinRoutingOprBdgTeamRetToPendingFinRev"                  , "Fin Routing Opr Bdg Team Ret. To Pending Fin Rev");
        public static readonly HBProjectAction FinRoutingEncumbranceReview = new HBProjectAction                    (424, "FinRoutingEncumbranceReview"                             , "Finance Routing Encumbrance Review");
        public static readonly HBProjectAction FinRoutingEncumbranceOnHold = new HBProjectAction                    (425, "FinRoutingEncumbranceOnHold"                             , "Finance Routing Encumbrance On Hold");
        public static readonly HBProjectAction FinRoutingForwardToEncumbrance = new HBProjectAction                 (426, "FinRoutingForwardToEncumbrance"                          , "Finance Routing Forward To Encumbrance");
        public static readonly HBProjectAction FinRoutingEncumReturnByVP = new HBProjectAction                      (427, "FinRoutingEncumReturnByVP"                               , "Finance Routing Encumbrance Return By VP");
        public static readonly HBProjectAction FinRoutingEncumbranceApprovalOnHold = new HBProjectAction            (428, "FinRoutingEncumApprovalOnHold"                           , "Finance Routing Encumbrance Approval On Hold");
        public static readonly HBProjectAction FinRoutingEncumReturnToBudgetTeam = new HBProjectAction              (429, "FinRoutingEncumReturnToBudgetTeam"                       , "Finance Routing Encumbrance Return To Budget Team");
        public static readonly HBProjectAction FinRoutingEncumReturnToBudgetTeamAtOnHold = new HBProjectAction      (430, "FinRoutingEncumReturnToBudgetTeamAtOnHold"               , "Finance Routing Encumbrance Return To Budget Team At OnHold");
        public static readonly HBProjectAction FinRoutingBudgetTeamReturn = new HBProjectAction                     (431, "FinRoutingBudgetTeamReturn"                              , "Finance Routing Budget Team Return");
                
        // Routing to OIG Workflow 
        public static readonly HBProjectAction OIGBidderApprove = new HBProjectAction(210, "OIGBidderApprove", "OIG Bidder Approve");
        public static readonly HBProjectAction OIGReviewBidderIssue = new HBProjectAction(211, "OIGReviewBidderIssue", "OIG Review Bidder Issue");
        public static readonly HBProjectAction ReturnToOIG = new HBProjectAction(225, "ReturnToOIG", "Return To OIG");
        public static readonly HBProjectAction RoutingOIGWithdrawBidder = new HBProjectAction(432, "RoutingOIGWithdrawBidder", "Routing OIG Withdraw Bidder");

        // Routing to CQU Workflow 
        public static readonly HBProjectAction CQURoutingApprove = new HBProjectAction(212, "Pre-qualificationRoutingApprove", "Pre-qualification Routing Approve");
        public static readonly HBProjectAction CQURoutingApprove1 = new HBProjectAction(213, "Pre-qualificationRoutingApprove1", "Pre-qualification Routing Approve 1");
        public static readonly HBProjectAction CQURoutingHold = new HBProjectAction(214, "Pre-qualificationRoutingHold", "Pre-qualification Routing Hold");

        public static readonly HBProjectAction AdminRoutingApprove = new HBProjectAction(218, "AdminRoutingApprove", "Admin Routing Approve");
        public static readonly HBProjectAction AdminRoutingApprove1 = new HBProjectAction(219, "AdminRoutingApprove1", "Admin Routing Approve 1");
        public static readonly HBProjectAction AdminRoutingHold = new HBProjectAction(220, "AdminRoutingHold", "Admin Routing Approve Hold");


        // Routing to VPCM Workflow 
        public static readonly HBProjectAction VPCMRoutingApprove = new HBProjectAction(212, "VPCMRoutingApprove", "VPCM Routing Approve");
        public static readonly HBProjectAction VPCMRoutingApprove1 = new HBProjectAction(213, "VPCMRoutingApprove1", "VPCM Routing Approve 1");
        public static readonly HBProjectAction VPCMRoutingDisapprove = new HBProjectAction(218, "VPCMRoutingDisapprove", "VPCM Routing Disapprove");
        public static readonly HBProjectAction VPCMRoutingDisapprove1 = new HBProjectAction(219, "VPCMRoutingDisapprove1", "VPCM Routing Disapprove 1");
        
        public static readonly HBProjectAction VPCMRoutingHold = new HBProjectAction(214, "VPCMRoutingHold", "VPCM Routing Hold");


        //Routing to IEH Workflow   
        public static readonly HBProjectAction VPIEHRoutingApprove = new HBProjectAction(433,       "VPIEHRoutingApprove",       "VPIEH Routing Approve");
        public static readonly HBProjectAction VPIEHRoutingApprove1 = new HBProjectAction(434,      "VPIEHRoutingApprove1",      "VPIEH Routing Approve 1");
        public static readonly HBProjectAction VPIEHRoutingDisapprove = new HBProjectAction(435,    "VPIEHRoutingDisapprove",    "VPIEH Routing Disapprove");
        public static readonly HBProjectAction VPIEHRoutingDisapprove1 = new HBProjectAction(436,   "VPIEHRoutingDisapprove1",   "VPIEH Routing Disapprove 1");
                                               
        public static readonly HBProjectAction VPIEHRoutingHold = new HBProjectAction(437,          "VPIEHMRoutingHold",          "VPIEH Routing Hold");

        //Routing to AE Workflow   
        public static readonly HBProjectAction VPAERoutingApprove = new HBProjectAction(438,        "VPAERoutingApprove",       "VPAE Routing Approve");
        public static readonly HBProjectAction VPAERoutingApprove1 = new HBProjectAction(439,       "VPAERoutingApprove1",      "VPAE Routing Approve 1");
        public static readonly HBProjectAction VPAERoutingDisapprove = new HBProjectAction(440,     "VPAERoutingDisapprove",    "VPAE Routing Disapprove");
        public static readonly HBProjectAction VPAERoutingDisapprove1 = new HBProjectAction(441,    "VPAERoutingDisapprove1",   "VPAE Routing Disapprove 1");

        public static readonly HBProjectAction VPAERoutingHold = new HBProjectAction(442, "VPAEMRoutingHold", "VPIEH Routing Hold");


        // Routing to BDD Workflow 
        public static readonly HBProjectAction BDDRoutingApprove = new HBProjectAction(215, "BDDRoutingApprove", "BDD Routing Approve");
        public static readonly HBProjectAction BDDRoutingApprove1 = new HBProjectAction(216, "BDDRoutingApprov1e", "BDD Routing Approve 1");
        public static readonly HBProjectAction BDDRoutingHold = new HBProjectAction(217, "BDDRoutingHold", "BDD Routing Hold");

        //For all Routing
        public static readonly HBProjectAction RoutingSelectNextBidder = new HBProjectAction(403, "RoutingSelectNextBidder", "Routing Select Next Bidder");

        #endregion ~Routing Package ...

        // Contract Execution Workflow
        public static readonly HBProjectAction ExecutionPackageCreation = new HBProjectAction(101, "ExecutionPackageCreation", "Execution Package Creation");
        public static readonly HBProjectAction ExecutionPackageOnHold = new HBProjectAction(102, "ExecutionPackageOnHold", "Execution Package On Hold");
        public static readonly HBProjectAction ExecutionPackageReleaseToSrDirector = new HBProjectAction(103, "ExecutionPackageReleaseToSrDirector", "Execution Package Release To Sr. Director");

        public static readonly HBProjectAction LegalExecutionPackageReview = new HBProjectAction(104, "LegalExecutionPackageReview", "Legal Execution Package Review");
        public static readonly HBProjectAction LegalExecutionPackageReturn = new HBProjectAction(105, "LegalExecutionPackageReturn", "Legal Execution Package Return");
        public static readonly HBProjectAction LegalExecutionPackageApproved = new HBProjectAction(107, "LegalExecutionPackageApproved", "Legal Execution Package Approved");
        public static readonly HBProjectAction LegalExecutionPackageRevision = new HBProjectAction(410, "LegalExecutionPackageRevision", "Legal Execution Package Revision");
        public static readonly HBProjectAction LegalExecutionPackageRevisionUponApproval = new HBProjectAction(411, "LegalExecutionPackageRevisionUponApproval", "Legal Execution Package Revision Upon Approval");
        public static readonly HBProjectAction LegalExecutionPackageResume = new HBProjectAction(412, "LegalExecutionPackageResume", "Legal Execution Package Resume");

        public static readonly HBProjectAction VPCPExecutionPackageReview = new HBProjectAction(314, "VPCPExecutionPackageReview", "VPCP Execution Package Review");
        public static readonly HBProjectAction VPCPExecutionPackageReturn = new HBProjectAction(315, "VPCPExecutionPackageReturn", "VPCP Execution Package Return");
        public static readonly HBProjectAction VPCPExecutionPackageApproved = new HBProjectAction(316, "VPCPExecutionPackageApproved", "VPCP Execution Package Approved");
        public static readonly HBProjectAction VPCPExecutionPackageRevision = new HBProjectAction(413, "VPCPExecutionPackageRevision", "VPCP Execution Package Revision");
        public static readonly HBProjectAction VPCPExecutionPackageRevisionUponApproval = new HBProjectAction(414, "VPCPExecutionPackageRevisionUponAppoval", "VPCP Execution Package Revision Upon Approval");
        public static readonly HBProjectAction VPCPExecutionPackageResume = new HBProjectAction(415, "VPCPExecutionPackageResume", "VP CP Execution Package Resume");

        public static readonly HBProjectAction EVPExecutionPackageReview = new HBProjectAction(317, "EVPExecutionPackageReview", "EVP Execution Package Review");
        public static readonly HBProjectAction EVPExecutionPackageReturn = new HBProjectAction(318, "EVPExecutionPackageReturn", "EVP Execution Package Return");
        public static readonly HBProjectAction EVPExecutionPackageApproved = new HBProjectAction(319, "EVPExecutionPackageApproved", "EVP Execution Package Approved");
        public static readonly HBProjectAction EVPExecutionPackageRevision = new HBProjectAction(416, "EVPExecutionPackageRevision", "EVP Execution Package Revision");
        public static readonly HBProjectAction EVPExecutionPackageRevisionUponApproval = new HBProjectAction(417, "EVPExecutionPackageRevisionUponApproval", "EVP Execution Package RevisionUponApproval");
        public static readonly HBProjectAction EVPExecutionPackageResume = new HBProjectAction(418, "EVPExecutionPackageResume", "EVP Execution Package Resume");

        public static readonly HBProjectAction ReviseExecutionPackage2 = new HBProjectAction(326, "ReviseExecutionPackage2", "Revise Execution Package 2");
        public static readonly HBProjectAction ReviseExecutionPackage3 = new HBProjectAction(327, "ReviseExecutionPackage3", "Revise Execution Package 3");

        public static readonly HBProjectAction ExecutionPackageReviewSrDirector = new HBProjectAction(164, "ExecutionPackageReviewSrDirector", "Execution Package Review SrDirector");
        public static readonly HBProjectAction ExecutionPackageReturnSrDirector = new HBProjectAction(165, "ExecutionPackageReturnSrDirector", "Execution Package Return SrDirector");

        public static readonly HBProjectAction ExecutionPackageReviewSrMgm = new HBProjectAction(406, "ExecutionPackageReviewSrMgm", "Execution Package Review SrManagement");
        public static readonly HBProjectAction ExecutionPackageApprovedSrMgm = new HBProjectAction(407, "ExecutionPackageApprovedSrMgm", "Execution Package Approved SrManagement");
        public static readonly HBProjectAction ExecutionPackageReturnSrMgm = new HBProjectAction(408, "ExecutionPackageReturnSrMgm", "Execution Package Return SrManagement");

        public static readonly HBProjectAction ReviseExecutionPackage = new HBProjectAction(106, "ReviseExecutionPackage", "Revise Execution Package");
        public static readonly HBProjectAction ReviseExecutionPackage1 = new HBProjectAction(166, "ReviseExecutionPackage1", "Revise Execution Package 1");

        //public static readonly HBProjectAction SrDirectorExecutionPackageReview1 = new HBProjectAction(167, "ExecutionPackageReviewSrDirector", "Execution Package Review Sr Director");

        public static readonly HBProjectAction ExecutionPackagePresidentReview = new HBProjectAction(108, "ExecutionPackagePresidentReview", "Execution Package President Review");
        public static readonly HBProjectAction ExecutionPackagePresidentApproval = new HBProjectAction(109, "PresidentExecutionPresidentApproval", "President Execution President Approval");
        public static readonly HBProjectAction ExecutionPackagePresidentReturn = new HBProjectAction(110, "ExecutionPackagePresidentReturn", "Execution Package President Return");

        public static readonly HBProjectAction IssueNoticeofAward = new HBProjectAction(111, "IssueNoticeofAward", "Issue Notice of Award");
        public static readonly HBProjectAction IssueNoticeofAwardReturn = new HBProjectAction(112, "IssueNoticeofAwardReturn", "Issue Notice of Award Return");
        public static readonly HBProjectAction OIGApprove = new HBProjectAction(113, "OIGApprove", "OIG Approve");


        public static readonly HBProjectAction PresidentCancel = new HBProjectAction(114, "PresidentCancel", "President Cancel");
        public static readonly HBProjectAction ExecutionPackageContractAwarded = new HBProjectAction(409, "ExecutionPackageContractAwarded", "Execution Package Contract Awarded");

       


        #endregion

        #region Constructors
        public HBProjectAction()
        {
        }

        private HBProjectAction(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectAction class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ProjectAction.  
        /// </summary>
        public static HBProjectAction Default
        {
            get
            {
                return (HBProjectAction)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectAction class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectAction object.
        /// It allows a string to be assigned to a ProjectAction object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator HBProjectAction(int id)
        {
            return (HBProjectAction)EnumerationBase.FindById(id, HBProjectAction._list);
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectAction objects.
    /// It's very useful when binding ProjectAction objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class HBProjectActionConverter : TypeConverter
    {

        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, HBProjectAction._list);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectAction enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < HBProjectAction._list.Count; i++)
            {
                list.Add(((HBProjectAction)HBProjectAction._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}