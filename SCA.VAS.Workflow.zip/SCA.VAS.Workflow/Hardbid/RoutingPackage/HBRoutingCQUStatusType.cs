#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of HBRoutingCQUStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(HBRoutingCQUStatusConverter))]
    public class HBRoutingCQUStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        // Routing to Pre-qualification Workflow 
        public static readonly HBRoutingCQUStatusType NewRoutingtoCQU = new HBRoutingCQUStatusType      (0, "NewRoutingtoPre-qualification"     , "New Routing to Pre-qualification");
        public static readonly HBRoutingCQUStatusType PendingCQUReview = new HBRoutingCQUStatusType     (1, "PendingPre-qualificationReview"    , "Pending Pre-qualification Review");
        public static readonly HBRoutingCQUStatusType CQUApproval = new HBRoutingCQUStatusType          (2, "Pre-qualificationApproval"         , "Pre-qualification Approval");
        public static readonly HBRoutingCQUStatusType CQUReviewCompleted = new HBRoutingCQUStatusType   (3, "Pre-qualificationReviewCompleted"  , "Pre-qualification Review Completed");
        public static readonly HBRoutingCQUStatusType CQUOnHold = new HBRoutingCQUStatusType            (4, "Pre-qualificationOnHold"           , "Pre-qualification On Hold");
        #endregion

        #region Constructors
        public HBRoutingCQUStatusType()
        {
        }

        private HBRoutingCQUStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in HBRoutingCQUStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of HBRoutingCQUStatus.  
        /// </summary>
        public static HBRoutingCQUStatusType Default
        {
            get
            {
                return (HBRoutingCQUStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for HBRoutingCQUStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }

        public static List<HBRoutingCQUStatusType> GetList()
        {
            return _list.Cast<HBRoutingCQUStatusType>().OrderBy(e => e.Id).ToList();
        }

        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((HBRoutingCQUStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a HBRoutingCQUStatus object.
        /// It allows a string to be assigned to a HBRoutingCQUStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator HBRoutingCQUStatusType(int id)
        {
            return (HBRoutingCQUStatusType)EnumerationBase.FindById(id, HBRoutingCQUStatusType._list);
        }
        public static implicit operator HBRoutingCQUStatusType(string name)
        {
            for (int i = 0; i < HBRoutingCQUStatusType._list.Count; i++)
            {
                if (((HBRoutingCQUStatusType)HBRoutingCQUStatusType._list[i]).Description == name)
                    return (HBRoutingCQUStatusType)HBRoutingCQUStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and HBRoutingCQUStatus objects.
    /// It's very useful when binding HBRoutingCQUStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class HBRoutingCQUStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, HBRoutingCQUStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the HBRoutingCQUStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < HBRoutingCQUStatusType._list.Count; i++)
            {
                list.Add(((HBRoutingCQUStatusType)HBRoutingCQUStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
