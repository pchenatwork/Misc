#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of HBRoutingVPIEHStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(HBRoutingVPIEHStatusConverter))]
    public class HBRoutingVPIEHStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        // Routing to VPIEH Workflow 
        public static readonly HBRoutingVPIEHStatusType NewRoutingtoVPIEH = new HBRoutingVPIEHStatusType                       (0, "NewRoutingtoVPIEH"                  , "New Routing to VP of IEH");
        public static readonly HBRoutingVPIEHStatusType PendingVPIEHReview = new HBRoutingVPIEHStatusType                      (1, "PendingVPIEHReview"                 , "Pending VP of IEH Review");
        public static readonly HBRoutingVPIEHStatusType VPIEHApproval = new HBRoutingVPIEHStatusType                           (2, "VPIEHApproval"                      , "VP of IEH Approval");
        public static readonly HBRoutingVPIEHStatusType VPIEHReviewCompleted = new HBRoutingVPIEHStatusType                    (3, "VPIEHReviewCompleted"               , "VP of IEH Review Completed");
        public static readonly HBRoutingVPIEHStatusType VPIEHOnHold = new HBRoutingVPIEHStatusType                             (4, "VPIEHOnHold"                        , "VP of IEH On Hold");
        public static readonly HBRoutingVPIEHStatusType VPIEHDisapproval = new HBRoutingVPIEHStatusType                        (5, "VPIEHDisapproval"                   , "VP of IEH Disapproval");
        public static readonly HBRoutingVPIEHStatusType VPIEHPendingNextRankedBidderSelection = new HBRoutingVPIEHStatusType   (6, "PendingNextRankedBidderSelection"  , "Pending Next Ranked Bidder Selection");
        public static readonly HBRoutingVPIEHStatusType VPIEHNoProceed = new HBRoutingVPIEHStatusType                          (7, "DoNotProceed"                      , "Do Not Proceed");

        #endregion

        #region Constructors
        public HBRoutingVPIEHStatusType()
        {
        }

        private HBRoutingVPIEHStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in HBRoutingVPIEHStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of HBRoutingVPIEHStatus.  
        /// </summary>
        public static HBRoutingVPIEHStatusType Default
        {
            get
            {
                return (HBRoutingVPIEHStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for HBRoutingVPIEHStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((HBRoutingVPIEHStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a HBRoutingVPIEHStatus object.
        /// It allows a string to be assigned to a HBRoutingVPIEHStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator HBRoutingVPIEHStatusType(int id)
        {
            return (HBRoutingVPIEHStatusType)EnumerationBase.FindById(id, HBRoutingVPIEHStatusType._list);
        }
        public static implicit operator HBRoutingVPIEHStatusType(string name)
        {
            for (int i = 0; i < HBRoutingVPIEHStatusType._list.Count; i++)
            {
                if (((HBRoutingVPIEHStatusType)HBRoutingVPIEHStatusType._list[i]).Description == name)
                    return (HBRoutingVPIEHStatusType)HBRoutingVPIEHStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and HBRoutingVPIEHStatus objects.
    /// It's very useful when binding HBRoutingVPIEHStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class HBRoutingVPIEHStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, HBRoutingVPIEHStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the HBRoutingVPIEHStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < HBRoutingVPIEHStatusType._list.Count; i++)
            {
                list.Add(((HBRoutingVPIEHStatusType)HBRoutingVPIEHStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
