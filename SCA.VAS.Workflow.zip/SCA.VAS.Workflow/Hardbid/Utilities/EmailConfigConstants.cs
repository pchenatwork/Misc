﻿
namespace SCA.VAS.Workflow.Hardbid.Utilities
{
    public class EmailConfigConstants
    {
        internal const string JMTYPE_TEMPLATES = "JMTypeTemplates";        
        internal const string HARDBID_VP_TEMPLATES = "HardbidVPTemplates";

        internal const string JMTYPE_ASB_TEMPLATES = "JmTypeASBTemplates";
        internal const string JMTYPE_SRD_TEMPLATES = "JmTypeSRDTemplates";
        internal const string JMTYPE_SWK_TEMPLATES = "JmTypeSWKTemplates";
        internal const string JMTYPE_JOC_TEMPLATES = "JmTypeJOCTemplates";

        internal const string ATTACHMENT_TEMPLATES = "AttachmentTemplates";

        internal const string JM_TEMPLATE_TYPE = "JM";
        internal const string VP_TEMPLATE_TYPE = "VP";
    }
}
