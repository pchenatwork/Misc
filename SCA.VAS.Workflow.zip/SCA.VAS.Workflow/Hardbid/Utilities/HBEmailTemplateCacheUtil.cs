﻿using SCA.VAS.Common.BidSetListServiceProxy;
using SCA.VAS.Common.Caching;
using SCA.VAS.Common.Caching.Models;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Supplier;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCA.VAS.Workflow.Hardbid.Utilities
{
    public sealed partial class HBEmailTemplateCacheUtil : WebCacheInCodeBase<EmailTemplateConfig>
    {
        /// <summary>
        /// New way of thread safe Instance Singleton creation via Lazy[] load.
        /// </summary>
        private static readonly Lazy<HBEmailTemplateCacheUtil> _factory = new Lazy<HBEmailTemplateCacheUtil>(() => new HBEmailTemplateCacheUtil());
        private HBEmailTemplateCacheUtil() : base("../Hardbid/ConfigContent/HBEmailTemplateConfigurations.json") { }

        static HBEmailTemplateCacheUtil Me
        {
            get { return _factory.Value; }
        }


        internal static List<string> Templates(string type, params string[] names)
        {
            return Me.GetTemplates(type, names);
        }

        internal static List<string> EmailPlaceHolders(string type, params string[] names)
        {
            return Me.GetPlaceHolders(type, names);
        }

        internal static List<string> NamePlaceHolders(string type, params string[] names)
        {
            return Me.GetNamePlaceHolders(type, names);
        }

        internal static List<string>  NamePlaceHolders(List<string> emailPlaceholders)
        {
            return Me.GetNamePlaceHoldersBasedOnEmailPlaceHolders(emailPlaceholders);
        }

        internal static Tuple<List<string>, List<string>> PlaceHolders(string type, params string[] names)
        {
            var _emails = Me.GetPlaceHolders(type, names);
            var _names = Me.GetNamePlaceHoldersBasedOnEmailPlaceHolders(_emails);

            return new Tuple<List<string>, List<string>>(_emails, _names);
        }

        internal static EmailTemplateConfig GetConfig(string name)
        {
            return Me.Get(name);
        }
    }

    partial class HBEmailTemplateCacheUtil
    {

        private List<string> GetTemplates(string type, params string[] names)
        {
            var list = new List<string>();

            foreach (var name in names)
            {
                var _temps = Me.Get(name)?.TemplateInfo.Where(t => t.Type == (type.Empty()? t.Type : type) )?.SelectMany(t => t.Templates);
                if (_temps != null) list.AddRange(_temps);
            }

            return list;
        }

        private List<string> GetPlaceHolders(string type, params string[] names)
        {
            var list = new List<string>();

            foreach (var name in names)
            {
                var _temps = Me.Get(name)?.TemplateInfo?.Where(t => t.Type == (type.Empty() ? t.Type : type))?.SelectMany(t => t.PlaceHolders);
                if (_temps != null) list.AddRange(_temps);
            }

            return list;
        }

        private List<string> GetNamePlaceHolders(string type, params string[] names)
        {
            return GetNamePlaceHoldersBasedOnEmailPlaceHolders(GetPlaceHolders(type, names));
        }

        private List<string> GetNamePlaceHoldersBasedOnEmailPlaceHolders(List<string> emailPlaceHolders)
        {
            return emailPlaceHolders
                    ?.Select(p => p.Replace("_EMAIL", "_NAME"))
                     .ToList();
        }
    }
}
