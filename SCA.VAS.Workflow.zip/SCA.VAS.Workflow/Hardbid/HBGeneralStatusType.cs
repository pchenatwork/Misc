#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ProjectBidAwardStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(HBProjectStatusConverter))]
    public class HBGeneralStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly HBGeneralStatusType NewHardbid = new HBGeneralStatusType                                 (0, "NewHardbid"                                , "New Hardbid");
        public static readonly HBGeneralStatusType JMPrepared = new HBGeneralStatusType                                 (1, "JMPrepared"                                , "Pending Project Assignment");
        public static readonly HBGeneralStatusType ProjectAssigned = new HBGeneralStatusType                            (2, "ProjectAssigned"                           , "Pending CS Review");
        public static readonly HBGeneralStatusType CSReviewed = new HBGeneralStatusType                                 (3, "CSReviewed"                                , "Pending Solicitation Pkg creation");
        public static readonly HBGeneralStatusType PendingMgrSolicitationReview = new HBGeneralStatusType               (4, "PendingMgrSolicitationReview"              , "Pending Mgr Solicitation Review");
        public static readonly HBGeneralStatusType PendingCSRevision = new HBGeneralStatusType                          (5, "PendingCSRevision"                         , "Solicitation Pkg returned by Mgr");
        public static readonly HBGeneralStatusType CSRevised = new HBGeneralStatusType                                  (6, "CSRevised"                                 , "Revised CS Review");
        public static readonly HBGeneralStatusType PendingDirSolicitationReview = new HBGeneralStatusType               (7, "PendingDirSolicitationReview"              , "Pending Dir Solicitation Review");
        public static readonly HBGeneralStatusType PendingCSRevision1 = new HBGeneralStatusType                         (8, "PendingCSRevision1"                        , "Solicitation Pkg returned by Director");
        public static readonly HBGeneralStatusType CSRevised1 = new HBGeneralStatusType                                 (9, "CSRevised1"                                , "Revised CS Review 1");
        public static readonly HBGeneralStatusType PendingIFBIssuance = new HBGeneralStatusType                         (10, "PendingIFBIssuance"                       , "Pending IFB Issuance");
        public static readonly HBGeneralStatusType PendingReproduction = new HBGeneralStatusType                        (11, "PendingReproduction"                      , "Pending Reproduction");
        public static readonly HBGeneralStatusType DocumentsAvailable = new HBGeneralStatusType                         (12, "DocumentsAvailable"                       , "Pending Recording of Bidders");

        //Bid Document Review/Approval Workflow
        public static readonly HBGeneralStatusType TradesSelected = new HBGeneralStatusType                             (13, "TradesSelected"                           , "Trades Selected");

        // Bid Pending Next low 
        public static readonly HBGeneralStatusType PendingNextBidderSelection = new HBGeneralStatusType                 (14, "PendingNextBidderSelection"               , "Pending Next Low Bidder Selection");

        // Bid Recording Workflow
        public static readonly HBGeneralStatusType PendingBidOpening = new HBGeneralStatusType                          (30, "PendingBidOpening"                        , "Pending Bid Opening");
        public static readonly HBGeneralStatusType BiddingClosed = new HBGeneralStatusType                              (31, "BiddingClosed"                            , "Pending Bid Certification");
        public static readonly HBGeneralStatusType PendingBidReview = new HBGeneralStatusType                           (32, "PendingBidReview"                         , "Pending Bid Review");
        public static readonly HBGeneralStatusType BidderSubWorkflowAnalysis = new HBGeneralStatusType                  (33, "BidderSubWorkflowAnalysis"                , "Bidder Sub-Workflow Analysis");

        public static readonly HBGeneralStatusType ProjectComplete = new HBGeneralStatusType                            (69, "ProjectComplete"                          , "ProjectComplete");        
        public static readonly HBGeneralStatusType Canceled = new HBGeneralStatusType                                   (76, "Canceled"                                 , "Canceled");       
        public static readonly HBGeneralStatusType OnHold = new HBGeneralStatusType                                     (77, "OnHold"                                   , "On Hold");


        public static readonly HBGeneralStatusType CanceledProjectDuringBidderSubWorkflow = new HBGeneralStatusType     (167, "CanceledProjectDuringBidderSubWorkflow"  , "Project Canceled During Bidder Sub-Workflow");
        //public static readonly HBGeneralStatusType RebidProjectFromBreakDown = new HBGeneralStatusType                (168, "RebidProjectFromBreakDown"               , "Rebid From Bid BreakDown Analysis");
        //public static readonly HBGeneralStatusType Rebid  = new HBGeneralStatusType                                   (169, "Rebid"                                   , "Rebid");

        //public static readonly HBGeneralStatusType PendingVettingDirectorReview = new HBGeneralStatusType             (170, "PendingVettingDirectorReview"            , "Pending Vetting Director Review");
        //public static readonly HBGeneralStatusType VettingDirectorRequestToReVett = new HBGeneralStatusType           (171, "VettingDirectorRequestToReVett"          , "Vetting Director Request To Re-Vett");
        //public static readonly HBGeneralStatusType VettingDirectorApproved = new HBGeneralStatusType                  (172, "VettingDirectorApproved"                 , "Vetting Director Approved");
        //public static readonly HBGeneralStatusType VettingDirectorDisapproved = new HBGeneralStatusType               (173, "VettingDirectorDisapproved"              , "Vetting Director Disapproved");



        #endregion

        #region Constructors
        public HBGeneralStatusType()
        {
        }

        private HBGeneralStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectBidAwardStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ProjectBidAwardStatus.  
        /// </summary>
        public static HBGeneralStatusType Default
        {
            get
            {
                return (HBGeneralStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectBidAwardStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }

        public static List<HBGeneralStatusType> GetList()
        {
            return _list.Cast<HBGeneralStatusType>().OrderBy(e => e.Name).ToList();
        }

        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((HBGeneralStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectBidAwardStatus object.
        /// It allows a string to be assigned to a ProjectBidAwardStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator HBGeneralStatusType(int id)
        {
            return (HBGeneralStatusType)EnumerationBase.FindById(id, HBGeneralStatusType._list);
        }
        public static implicit operator HBGeneralStatusType(string name)
        {
            for (int i = 0; i < HBGeneralStatusType._list.Count; i++)
            {
                if (((HBGeneralStatusType)HBGeneralStatusType._list[i]).Description == name)
                    return (HBGeneralStatusType)HBGeneralStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectBidAwardStatus objects.
    /// It's very useful when binding ProjectBidAwardStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class HBProjectStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, HBGeneralStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectBidAwardStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < HBGeneralStatusType._list.Count; i++)
            {
                list.Add(((HBGeneralStatusType)HBGeneralStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
