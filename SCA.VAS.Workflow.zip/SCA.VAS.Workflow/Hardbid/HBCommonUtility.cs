﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Net.Mail;
using System.Configuration;

using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.ValueObjects.Workflow;
using System.Collections;
using SCA.VAS.Common.ValueObjects;
using System.Linq;
using System.Security.RightsManagement;
using System.Web.WebSockets;
using SCA.VAS.Workflow.Hardbid.Utilities;

namespace SCA.VAS.Workflow
{
    public partial class CommonUtility
    {
        #region Pubulic Method
        public static string HBGetProjectStatusName(string workflowType, int statusint)
        {
            EnumerationBase status = GetHBProjectStatus(workflowType, statusint);
            if (status != null) return status.Description;
            return string.Empty;
        }

        public static int HBGetProjectStatusId(string workflowType, string statusstr)
        {
            EnumerationBase status = GetHBProjectStatus(workflowType, statusstr);
            if (status != null) return status.Id;
            return 0;
        }
        
        //Need to change it to HBWorkflow once created...
        private static EnumerationBase GetHBProjectStatus(string workflowType, object status)
        {
            EnumerationBase enumType = null;

            string _status_str = status.ToString();
            int _status_int = _status_str.ToInt32(true);

            switch (workflowType)
            {
                case ConstantUtility.WORKFLOW_HB_GENERAL:
                    enumType = _status_int != Int32.MinValue ? (HBGeneralStatusType)_status_int : (HBGeneralStatusType)_status_str; 
                    //GetEnumBaseType<HBGeneralStatusType>(status);
                    break;
                case ConstantUtility.WORKFLOW_HB_ADDENDUM:                    
                    //enumType = (HBProjectAddendumStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_RFI_SUBMISSION_PROCESSING:
                    //enumType = (HBProjectRfiSubmissionStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_BAFO:
                    enumType = _status_int != Int32.MinValue ? (HBBidderBafoStatusType)_status_int : (HBBidderBafoStatusType)_status_str;
                    //enumType = GetEnumBaseType<HBBidderBafoStatusType>(status);
                    break;
                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_PRIME:
                    enumType = _status_int != Int32.MinValue ? (HBPreAwardVettingPrimeStatusType)_status_int : (HBPreAwardVettingPrimeStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_BIDBOND:
                    enumType = _status_int != Int32.MinValue ? (HBPreAwardVettingBidBondStatusType)_status_int : (HBPreAwardVettingBidBondStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_FINANCIAL:
                    enumType = _status_int != Int32.MinValue ? (HBPreAwardVettingFinancialStatusType)_status_int : (HBPreAwardVettingFinancialStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_ROUTING_PACKAGE:
                    enumType = _status_int != Int32.MinValue ? (HBRoutingPackageStatusType)_status_int : (HBRoutingPackageStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_ROUTING_OIG:
                    enumType = _status_int != Int32.MinValue ? (HBRoutingOIGStatusType)_status_int : (HBRoutingOIGStatusType)_status_str; 
                    break;
                case ConstantUtility.WORKFLOW_HB_ROUTING_FINANCE:
                    enumType = _status_int != Int32.MinValue ? (HBRoutingFinanceStatusType)_status_int : (HBRoutingFinanceStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_ROUTING_CQU:
                    enumType = _status_int != Int32.MinValue ? (HBRoutingCQUStatusType)_status_int : (HBRoutingCQUStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_ROUTING_VPCM:
                    enumType = _status_int != Int32.MinValue ? (HBRoutingVPCMStatusType)_status_int : (HBRoutingVPCMStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_ROUTING_VPIEH:
                    enumType = _status_int != Int32.MinValue ? (HBRoutingVPIEHStatusType)_status_int : (HBRoutingVPIEHStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_ROUTING_VPAE:
                    enumType = _status_int != Int32.MinValue ? (HBRoutingVPAEStatusType)_status_int : (HBRoutingVPAEStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_BID_DOCUMENT_REPRODUCTION:
                    //enumType = (HBProjectBidDocumentReproductionStatusType)_status_str;
                    break;                
                case ConstantUtility.WORKFLOW_HB_RS1_VETTING:
                    //enumType = (HBProjectRS1VettingStatusType)_status_str;
                    break;

                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE:
                    enumType = _status_int != Int32.MinValue ? (HBExecutionPackageStatusType)_status_int : (HBExecutionPackageStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_LEGAL:
                    enumType = _status_int != Int32.MinValue ? (HBExecutionPackageLegalStatusType)_status_int : (HBExecutionPackageLegalStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_VPCP:
                    enumType = _status_int != Int32.MinValue ? (HBExecutionPackageVPCPStatusType)_status_int : (HBExecutionPackageVPCPStatusType)_status_str;
                    break;
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_EVP:
                    enumType = _status_int != Int32.MinValue ? (HBExecutionPackageEVPStatusType)_status_int : (HBExecutionPackageEVPStatusType)_status_str;
                    break;
            }
                        
            //if (status is int) enumType = (int)status;
            return enumType;
        }
        #endregion Pubulic Method

        #region Email Method
        public static void HBProjectSendEmail(Project project, Bidder bidder, WorkflowNode node, WorkflowHistory workflowHistory,
            string emailMessageName, string comments, ProjectBidderWorkflowExec.AssociateWorkflows asstWflows)
        {
            EmailMessage emailmessage = EmailMessageUtility.GetByName(
                ConstantUtility.COMMON_DATASOURCE_NAME, emailMessageName);
            if (emailmessage == null) return;

            Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, (bidder?.SupplierId).ToInt());
            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "Supplier", (supplier?.Id).ToInt().ToString());
            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());


            var attachments = GetAttachments(emailmessage.Body, emailMessageName, bidder);
            EmailRecepientRefactor(emailmessage, emailMessageName,  project);
            HBEmailReplaceRelatedUsers(emailmessage, project, bidder, asstWflows);

            switch (emailmessage.Objects)
            {
                case "Node Users":
                    if (node != null)
                    {
                        WorkflowNodeCollection workflownodes = new WorkflowNodeCollection();
                        workflownodes.Add(node);
                        string nodes = XmlUtility.ToXml(workflownodes);
                        UserCollection users = UserUtility.FindByCriteria(
                            ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_WORKFLOWNODES,
                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)                                                            
                                InvokeEmail(users[i], null, true);                            
                        }
                    }
                    break;
                case "Authorized Users":
                    {
                        string nodes = XmlUtility.ToXml(workflowHistory.NextLinks);
                        UserCollection users = UserUtility.FindByCriteria(
                            ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_WORKFLOWNODES,
                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                                InvokeEmail(users[i], null, true);                            
                        }
                    }
                    break;

                case "Users":
                    InvokeEmail(user, attachments); break;

                case "Bidders":
                    {
                        BidderCollection bidders = BidderUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME,
                            BidderManager.FIND_BY_PROJECT, new object[] { project.Id });

                        if (bidders != null && bidders.Count > 0)
                        {
                            foreach (Bidder bidd in bidders)
                            {
                                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, bidd.SupplierId);
                                vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "Supplier", supplier.Id.ToString());

                                //Email with Attachment                                 
                                InvokeEmail(supplier, HBGetEmailAttatchments(emailmessage, project, bidd, supplier), false, bidd);
                            }
                        }

                    }
                    break;               
                default:                                           
                        InvokeEmail(null, attachments);                    
                        break;
            }

            void InvokeEmail(object emailUser, object[] attachmentObjs, bool emailUerAsLoggingUser = false, params object[] extras)
            {
                var flag_IsPasswordKeywordExists = emailMessageName.ToUpper().Contains("PASSWORD"); 
                
                var objs = new List<object> { project, emailUerAsLoggingUser ? emailUser : user, supplier, vendor };
                if (extras != null) foreach (var ext in extras) objs.Add(ext);
                
                SendEmail(emailmessage, emailUser,  objs.ToArray(), comments, !flag_IsPasswordKeywordExists, "Project", project.Id, attachmentObjs);
            }
        }

        public static object[] GetAttachments(string body, string template, Bidder bidder)
        {
            var objs = new List<object>();
            
            var attTemps = HBEmailTemplateCacheUtil.Templates("", EmailConfigConstants.ATTACHMENT_TEMPLATES).ToArray();

            if ((template?.In(attTemps)).ToBool())
            {
                var _att = HBEmailTemplateCacheUtil.GetConfig(EmailConfigConstants.ATTACHMENT_TEMPLATES).Attachments?.FirstOrDefault(a => a.Template == template);

                if (_att != null)
                {
                    var docs = ProjectDocumentUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME, ProjectDocumentManager.FIND_PROJECTDOCUMENT_BY_TYPE,
                                                    new object[] { bidder.ProjectId, _att.IsBidder? bidder.Id: 0, _att.VASDocumentType })?.Cast<ProjectDocument>().ToList();

                    docs.ForEach(d =>
                    {
                        var _content = ProjectDocumentUtility.GetAttachment(ConstantUtility.RFD_DATASOURCE_NAME, d.Id);

                        if (_content != null)
                        {
                            var mem = new MemoryStream(_content);
                            objs.Add(new Attachment(mem, d.FileName));
                        }
                    });
                }
            }

            return objs.Where(o => o != null).ToArray();
        }

        public static void EmailRecepientRefactor(EmailMessage message, string template,Project project)
        {
            Func<List<string>, List<string>, bool, Tuple<bool, List<string>>> Remove = (List<string> emails, List<string> placeholders, bool isOfType) =>
            {
                bool _available = false;

                if (isOfType)
                    _available = emails.RemoveAll(e => placeholders.Any(p => p == e)) > 0;
                
                return new Tuple<bool, List<string>>(_available, emails);
            };

            Func<List<string>, List<string>, bool, List<string>> Stack = (List<string> emailStack, List<string> placeholder, bool wasAvailable) =>
            {
                if (wasAvailable && placeholder.Any())                
                    emailStack.AddRange(placeholder.Where(p => p!=null));

                return emailStack;
            };

            var jmTemplates = HBEmailTemplateCacheUtil.Templates("",EmailConfigConstants.JMTYPE_TEMPLATES);
            var vpTemplates = HBEmailTemplateCacheUtil.Templates("",EmailConfigConstants.HARDBID_VP_TEMPLATES);

            if (jmTemplates != null && vpTemplates != null)
            {
                bool flag_JMTypes = jmTemplates.Any(t => t == template);
                bool flag_VPTypes = vpTemplates.Any(t => t == template);

                //If the assiciate templates are not within two types - then just return
                if (!flag_JMTypes && !flag_VPTypes) return;

                var jmPalceholders = HBEmailTemplateCacheUtil.PlaceHolders(EmailConfigConstants.JM_TEMPLATE_TYPE,
                                                                                  EmailConfigConstants.JMTYPE_ASB_TEMPLATES,
                                                                                  EmailConfigConstants.JMTYPE_JOC_TEMPLATES,
                                                                                  EmailConfigConstants.JMTYPE_SRD_TEMPLATES,
                                                                                  EmailConfigConstants.JMTYPE_SWK_TEMPLATES);
                var vpPlaceholders = HBEmailTemplateCacheUtil.PlaceHolders(EmailConfigConstants.VP_TEMPLATE_TYPE,
                                                                                  EmailConfigConstants.JMTYPE_ASB_TEMPLATES,
                                                                                  EmailConfigConstants.JMTYPE_JOC_TEMPLATES,
                                                                                  EmailConfigConstants.JMTYPE_SRD_TEMPLATES,
                                                                                  EmailConfigConstants.JMTYPE_SWK_TEMPLATES);
                var jmNames = jmPalceholders.Item2;
                var vpNames = vpPlaceholders.Item2;

                //Get all emails and names into list.
                var _tupjmTOemails = Remove(message.ToEmail.SplitEx(";").Select(s => s.Trim()).ToList(), jmPalceholders.Item1, flag_JMTypes);
                var _tupvpTOemails = Remove(_tupjmTOemails.Item2, vpPlaceholders.Item1, flag_VPTypes);

                var _tupjmCCemails = Remove(message.CcEmail.SplitEx(";").Select(s => s.Trim()).ToList(), jmPalceholders.Item1, flag_JMTypes);
                var _tupvpCCemails = Remove(_tupjmCCemails.Item2, vpPlaceholders.Item1, flag_VPTypes);

                var _tupJMNames = Remove(message.ToName.SplitEx(";").ToList(), jmNames, flag_JMTypes);
                var _tupVPNames = Remove(_tupJMNames.Item2, vpNames, flag_VPTypes);

                {
                    //Remove all names which are there in the template...
                    var _toemails = _tupvpTOemails.Item2.Select(i => i).ToList();
                    var _ccemails = _tupvpCCemails.Item2.Select(i => i).ToList();
                    var _names = _tupVPNames.Item2.Select(i => i).ToList();


                    Func<string, int> AggregatePlaceHolders = (string configTemplate) =>
                    {
                        var _jmPlaceholds = HBEmailTemplateCacheUtil.PlaceHolders(EmailConfigConstants.JM_TEMPLATE_TYPE, configTemplate);
                        var _vpPlaceholds = HBEmailTemplateCacheUtil.PlaceHolders(EmailConfigConstants.VP_TEMPLATE_TYPE, configTemplate);

                        _toemails = Stack(_toemails, _jmPlaceholds.Item1, _tupjmTOemails.Item1);
                        _toemails = Stack(_toemails, _vpPlaceholds.Item1, _tupvpTOemails.Item1);

                        _ccemails = Stack(_ccemails, _jmPlaceholds.Item1, _tupjmCCemails.Item1);
                        _ccemails = Stack(_ccemails, _vpPlaceholds.Item1, _tupvpCCemails.Item1);

                        _names = Stack(_names, _jmPlaceholds.Item2, _tupJMNames.Item1);
                        _names = Stack(_names, _vpPlaceholds.Item2, _tupVPNames.Item1);

                        return 0;
                    };

                    switch (project.JmType)
                    {
                        case ConstantUtility.JMTYPE_ASB: AggregatePlaceHolders(EmailConfigConstants.JMTYPE_ASB_TEMPLATES); break;
                        case ConstantUtility.JMTYPE_SRD: AggregatePlaceHolders(EmailConfigConstants.JMTYPE_SRD_TEMPLATES); break;
                        case ConstantUtility.JMTYPE_SWB: AggregatePlaceHolders(EmailConfigConstants.JMTYPE_SWK_TEMPLATES); break;
                        case ConstantUtility.JMTYPE_JOC: AggregatePlaceHolders(EmailConfigConstants.JMTYPE_JOC_TEMPLATES); break;
                    }

                    message.ToEmail = _toemails.Where(e => !e.Empty()).JoinExt(";");
                    message.CcEmail = _ccemails.Where(e => !e.Empty()).JoinExt(";");
                    message.ToName = _names.Where(e => !e.Empty()).JoinExt(";");
                }
            }
            
        }

        public static object[] HBGetEmailAttatchments(EmailMessage emailmessage, Project project, Bidder bidder, Supplier supplier)
        {
            string downloadPath = ConfigurationManager.AppSettings["DownloadPath"];
            switch (emailmessage.Name)
            {
                case "HB_INVITATION_TO_BID_LETTER":
                    Attachment pickupTicket = new Attachment(Path.Combine(downloadPath,
                        "PickupTicket_" + project.Id + "_" + bidder.SupplierId + ".pdf"));
                    return new object[] { pickupTicket };
            }
            return null;
        }

        /// <summary>
        /// Get settings from current project "~\Data\Settings\{fileName.xml}". 
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static SettingCollection HBGetSettingsFromProjectData(string fileName)
        {
            //string path = HttpContext.Current.Server.MapPath(null);
            string path = HttpContext.Current.Server.MapPath("~");
            string xmlFileName = Path.Combine(Path.Combine(Path.Combine(path, "Data"), "Settings"), Path.GetFileName(fileName));
            string s = ReadFile(xmlFileName);
            return (SettingCollection)XmlUtility.Deserialize(s, typeof(SettingCollection));
        }

        public static EmailMessage HBEmailReplaceRelatedUsers(EmailMessage emailmessage, Bidder bidder)
        {
            if (emailmessage == null || bidder == null) return null;
            Hashtable RelatedUsers = new Hashtable();
            RelatedUsers.Add("$REJECTEDBIDDER$", bidder == null ? "" : bidder.SupplierName);
            emailmessage.FromEmail = ReplaceRelatedUsers(emailmessage.FromEmail, RelatedUsers);
            emailmessage.FromName = ReplaceRelatedUsers(emailmessage.FromName, RelatedUsers);
            emailmessage.ToEmail = ReplaceRelatedUsers(emailmessage.ToEmail, RelatedUsers);
            emailmessage.ToName = ReplaceRelatedUsers(emailmessage.ToName, RelatedUsers);
            emailmessage.CcEmail = ReplaceRelatedUsers(emailmessage.CcEmail, RelatedUsers);
            emailmessage.BccEmail = ReplaceRelatedUsers(emailmessage.BccEmail, RelatedUsers);
            emailmessage.Subject = ReplaceRelatedUsers(emailmessage.Subject, RelatedUsers);
            emailmessage.Body = ReplaceRelatedUsers(emailmessage.Body, RelatedUsers);

            return emailmessage;
        }
        public static EmailMessage HBEmailReplaceRelatedUsers(EmailMessage emailmessage, Project project, Bidder bidder, ProjectBidderWorkflowExec.AssociateWorkflows asstWflows)
        {
            if (emailmessage == null || project == null) return null;

            Hashtable RelatedUsers = new Hashtable();

            RelatedUsers.Add("$PROJECTLISTLINK$", "<a href=\"$INTERNALSITEURL$/Hardbid/Project_List.aspx?Id=" + project.Id.ToString() + "\">$INTERNALSITEURL$/Rfc/Project_List.aspx?Id=" + project.Id.ToString() + "</a>");
            RelatedUsers.Add("$PROJECTVETTINGLISTLINK$", "<a href=\"$INTERNALSITEURL$/Hardbid/Vetting_Request_List.aspx?Id=" + project.Id.ToString() + "\">$INTERNALSITEURL$/Rfc/Vetting_Request_List.aspx?Id=" + project.Id.ToString() + "</a>");

            RelatedUsers.Add("$JMTYPE$", project.JmType);
            RelatedUsers.Add("$SOLICITATIONNO$", project.SolicitationNo + "-" + project.SolicitSeq.ToString());
            RelatedUsers.Add("$PROJECTDESCRIPTION$", project.Description);
            RelatedUsers.Add("$PROJECTDESIGNNO$", project.DesignNo);
            RelatedUsers.Add("$BIDDERCONTRACTNO$", bidder.KeyItems.ContractNo);
            RelatedUsers.Add("$PREBIDMEETINGLOC$", project.PreBidMeetingLoc);
            RelatedUsers.Add("$PROJECTCOSTESTAMT$", project.CostEstAmt.ToString("c"));
            RelatedUsers.Add("$PROJECTREVCOSTESTAMT$", project.RevisedCostEstAmt.ToString("c"));
            RelatedUsers.Add("$PROJECTCOSTAMT$", project.CostAmt.ToString("c"));
            RelatedUsers.Add("$SOLICITPKGRCVDDATE$", project.SolicitPkgRcvdDate.ToShortDateString());
            RelatedUsers.Add("$PERFORMANCEPERIOD$", project.KeyItems.Duration.ToString("#.0"));
            RelatedUsers.Add("$PROJECTRANGE$", "$" + project.AdsMinAmt.ToString() + " - " + "$" + project.AdsMaxAmt.ToString());
            RelatedUsers.Add("$CONTRACTDOCSPRICE$", "$" + project.DocsPrice.ToString());
            RelatedUsers.Add("$DOCSAVAILABLE$", project.DocsAvailableDate.ToString());
            RelatedUsers.Add("$PREBIDDATE$", project.PreBidMeetingDateTime.Date.ToShortDateString());
            RelatedUsers.Add("$PREBIDTIME$", project.PreBidMeetingDateTime.ToShortTimeString());
            RelatedUsers.Add("$WORKFLOWCOMMENTS$", project.Comments);
            RelatedUsers.Add("$NTEBIDDERAMOUNT$", bidder.KeyItems.NTEAmount.ToString("c"));


            string clickhereLink = @"<a href=" + "\"" + ConfigurationManager.AppSettings["InternalSiteUrl"].ToString() + "/Dashboard/CAU_Dashboard.aspx" + "\"" + ">" + " here </a>";
            RelatedUsers.Add("$HERE$", clickhereLink);

            string addressInfo = "";
            string boroughName = "";
            ConstantUtility.Boroughs.TryGetValue(project.Boro, out boroughName);
            addressInfo = project.AddressLine1 + ",\r\n" + project.AddressLine2 + ",\r\n" + boroughName + ",\r\n" +
                            project.City + ",\r\n" + project.State + ",\r\n" + project.ZipCode;
            RelatedUsers.Add("$ADDRESS$", addressInfo);

            RelatedUsers.Add("$BID_ROOM$", project.Room);

            
            RelatedUsers.Add("$SCHOOL$", project.KeyItems?.School);

            string cmFirmName = "";
            SettingCollection settings = CommonUtility.GetSettings("MentorCMFirms.xml");
            foreach (Setting setting in settings)
            {
                if (project.CMRep == setting.Value)
                {
                    cmFirmName = setting.Name;
                    break;
                }
            }
            RelatedUsers.Add("$CMFIRMNAME$", cmFirmName);

            DateTime openingDate = project.PlanedBidOpeningDateTime;

            if (project.RevisedBidOpeningDateTime != new DateTime(1900, 1, 1))
            {
                openingDate = project.RevisedBidOpeningDateTime;
            }
            if (project.ActualBidOpeningDateTime != new DateTime(1900, 1, 1))
            {
                openingDate = project.ActualBidOpeningDateTime;
            }

            RelatedUsers.Add("$BIDOPENINGDATE$", openingDate.Date.ToShortDateString());
            RelatedUsers.Add("$BIDOPENINGTIME$", openingDate.ToShortTimeString());
            RelatedUsers.Add("$IFBDATE$", project.IFBDate.ToString());

            RelatedUsers.Add("$DRAWINGCOMMENTS$", project.DrawingComments);
            RelatedUsers.Add("$S01010COMMENTS$", project.S01010Comments);
            RelatedUsers.Add("$S01500COMMENTS$", project.S01500Comments);
            RelatedUsers.Add("$S01900COMMENTS$", project.S01900Comments);
            RelatedUsers.Add("$FIDCOMMENTS$", project.FIDComments);
            RelatedUsers.Add("$OTHERCOMMENTS$", project.Comments);

            ProjectPropertyCollection projectProperties = ProjectPropertyUtility.FindByCriteria(
            ConstantUtility.RFD_DATASOURCE_NAME,
            ProjectPropertyManager.FIND_BY_PROJECT,
            new object[] { project.Id });

            User reviewer = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, GetProjectProperty("property45", projectProperties).PropertyText);
            RelatedUsers.Add("$CQUREVIEWER$", (reviewer == null) ? "" : reviewer.FullName);
            RelatedUsers.Add("$CQUREVIEWERNAME$", (reviewer == null) ? "" : reviewer.FullName);
            RelatedUsers.Add("$CQUREVIEWERPHONE$", (reviewer == null) ? "" : reviewer.Phone);
            RelatedUsers.Add("$CQUREVIEWEREMAIL$", (reviewer == null) ? "" : reviewer.Email);
            RelatedUsers.Add("$CQUREVIEWERTITLE$", (reviewer == null) ? "" : reviewer.Title);

            User contractSpecialist = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, project.ContractSpecialist);
            RelatedUsers.Add("$CONTSPECEMAIL$", contractSpecialist == null ? "" : contractSpecialist.Email);
            RelatedUsers.Add("$CONTSPECNAME$", contractSpecialist == null ? "" : contractSpecialist.Name);
            RelatedUsers.Add("$CONTSPECPHONE$", contractSpecialist == null ? "" : contractSpecialist.Phone);
            RelatedUsers.Add("$CONTSPECFAX$", contractSpecialist == null ? "" : contractSpecialist.Fax);

            Rfc rfc = RfcUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, project.RfcId);
            RelatedUsers.Add("$LIQUIDATEDDAMAGES$", rfc == null ? "" : rfc.LiquidDamagesAmt.ToString("c"));

            //inprogress
             var bafoDecision = asstWflows?.BafoWorkflow?.StatusName.ToEmpty();
             RelatedUsers.Add("$BAFODECISION$", bafoDecision);
            //end

            // on the bid break down analysis, the status of the decision is 
            //stored into the projet statusname field.
            RelatedUsers.Add("$BRKDOWNDECISION$", project.StatusName);

            // This is current date when the user submits that triggers
            // Two emails 1. award notice with attachment 
            // 2. contract award date for template: HB_CONTRACT_EXECUTION_SCA
            RelatedUsers.Add("$CONTRACTAWARDEDDATE$", DateTime.Today.ToShortDateString());

            // HB_PROJECT_CANCELLED  email template is used
            RelatedUsers.Add("$AWARDAMT$",  (project.CostEstAmt > 0.00d ? project.CostEstAmt : project.NteAmt).ToString("c"));

            string ProjectCancelReason = CommonUtility.GetProjectProperty(130, projectProperties)?.PropertyText;

            if (ProjectCancelReason != null)
            {
                ProjectCancelReasonCollection projectCancelReasons = ProjectCancelReasonUtility.FindByCriteria(
                ConstantUtility.RFD_DATASOURCE_NAME, ProjectCancelReasonManager.FIND, new object[] { });
                var CancelReasonDescription = projectCancelReasons?.ToList().Where(x => x.C_REASON_CODE == ProjectCancelReason)?.FirstOrDefault()?.C_REASON_DESC;
                RelatedUsers.Add("$CANCEL_REASON$", CancelReasonDescription != null ? CancelReasonDescription.ToString() : "");
            }

            string ProjectCancelComments = CommonUtility.GetProjectProperty(131, projectProperties)?.PropertyText;
            RelatedUsers.Add("$WFCOMMENTS_CANCEL$", ProjectCancelComments != null ? ProjectCancelComments.ToString() : "");

            //END

            string Breakdowncomments = CommonUtility.GetProjectProperty(13, projectProperties)?.PropertyText;
            RelatedUsers.Add("$COMMENTS$", Breakdowncomments != null ? Breakdowncomments.ToString() : "");

            //fetch design manager 

            var rfcBid = RfcUtility.GetByNumber(ConstantUtility.RFD_DATASOURCE_NAME, project.TransNumber, "Bid"); 

            RelatedUsers.Add("$DMEMAIL$", "");
            RelatedUsers.Add("$DMNAME$", "");

            RelatedUsers.Add("$DPMEMAIL$", "");
            RelatedUsers.Add("$DPMNAME$", "");

            RelatedUsers.Add("$POEMAIL$", project.KeyItems.POEmail.ToEmpty());
            RelatedUsers.Add("$PONAME$", project.KeyItems.PO.ToEmpty());

            RelatedUsers.Add("$SPOEMAIL$", project.KeyItems.SPOEmail.ToEmpty());
            RelatedUsers.Add("$SPONAME$", project.KeyItems.SPO.ToEmpty());

            RelatedUsers.Add("$CPOEMAIL$", project.KeyItems.CPOEmail.ToEmpty());
            RelatedUsers.Add("$CPONAME$", project.KeyItems.CPO.ToEmpty());

            Dictionary<string, string> emailDetails = GetEmailIdNamesForRole("Contract Specialist");
            RelatedUsers.Add("$ALL_CS$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CAU Manager");
            RelatedUsers.Add("$CAU_MGR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CAU_MGR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));


            emailDetails = GetEmailIdNamesForRole("CPO");
            RelatedUsers.Add("$CPO_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CPO_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CAU Director");
            RelatedUsers.Add("$CAU_DIR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CAU_DIR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("VP for Construction Mgmt");
            RelatedUsers.Add("$VP_CM_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$VP_CM_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CQU Director");
            RelatedUsers.Add("$CQU_DIR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CQU_DIR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CQU Manager");
            RelatedUsers.Add("$CQU_MGR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CQU_MGR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CQU Financial Manager");
            RelatedUsers.Add("$CQU_FINANCIAL_MGR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CQU_FINANCIAL_MGR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CQU Financial Analyst");
            RelatedUsers.Add("$CQU_FINANCIAL_ANALYST_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CQU_FINANCIAL_ANALYST_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CQU Reviewer");
            RelatedUsers.Add("$CQU_REVIEWER_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CQU_REVIEWER_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CAU Intake Specialist");
            RelatedUsers.Add("$CAU_INTAKE_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CAU_INTAKE_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("VP of Capital Planning");
            RelatedUsers.Add("$VP_CP_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$VP_CP_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("VP of A&E");
            RelatedUsers.Add("$VP_AnE_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$VP_AnE_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("VP of IEH");
            RelatedUsers.Add("$VP_IEH_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$VP_IEH_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("Email_Requirements_ASB");
            RelatedUsers.Add("$Email_Requirements_ASB_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$Email_Requirements_ASB_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("Email_Requirements_JOC");
            RelatedUsers.Add("$Email_Requirements_JOC_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$Email_Requirements_JOC_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("Email_Requirements_SRD");
            RelatedUsers.Add("$Email_Requirements_SRD_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$Email_Requirements_SRD_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("Email_Requirements_SWK");
            RelatedUsers.Add("$Email_Requirements_SWK_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$Email_Requirements_SWK_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("EVP BA");
            RelatedUsers.Add("$EVP_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$EVP_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            //NO ESO Account for HB Projects            
            RelatedUsers.Add("$RESOA_EMAIL$", "");
            RelatedUsers.Add("$RESOA_TEXT$", "");
            

            emailDetails = GetEmailIdNamesForRole("Sr Director - Capital Planning");
            RelatedUsers.Add("$CP_SRDIR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CP_SRDIR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("BA Budget Group");
            RelatedUsers.Add("$BA_BUDGET_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$BA_BUDGET_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("BA Encumbrance Group");
            RelatedUsers.Add("$BA_BUDGET_ENCUMBRANCE_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$BA_BUDGET_ENCUMBRANCE_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("President");
            RelatedUsers.Add("$PRESIDENT_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$PRESIDENT_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("OIG User BA");
            RelatedUsers.Add("$OIG_BA_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$OIG_BA_USER_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("SAF Manager");
            RelatedUsers.Add("$SAF_MGR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$SAF_MGR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("Legal");
            RelatedUsers.Add("$LEGAL_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$LEGAL_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("VP of Finance");
            RelatedUsers.Add("$VP_FINANCE_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$VP_FINANCE_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));
                        
            //emailDetails = GetEmailIdNamesForRole("Director of Mentor Program BA");
            //RelatedUsers.Add("$DIRECTOR_MENTOR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            //RelatedUsers.Add("$DIRECTOR_MENTOR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            //Bug/Story #2025  control the  template placeholders based on the project type and the roles to be included or deleted
            HBControlPlaceHolderTemplateForRoles(emailmessage, project, RelatedUsers);

            // end

            //$BUDGETNUMBER$ - 
            RelatedUsers.Add("$BUDGETNUMBER$", project.CostAmt.ToString("c"));

            //$$ENGINEERESTIMATE$
            RelatedUsers.Add("$ENGINEERESTIMATE$", project.CostEstAmt.ToString("c"));

            BidderCollection bidders = BidderUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME, BidderManager.FIND_BY_PROJECT, new object[] { project.Id });

            //Special Case...
            RelatedUsers.Add("$ATTACHMENTS$", "");

            //creating bidder list of emails to be notified about bid results. ref email template: HB_BO_BID_RESULT_NOTIFY
            emailDetails.Clear();
            List<Bidder> listofbidders = bidders?.ToList().Where(x => x.IsBidReceived == "Y")?.ToList();
            if (listofbidders != null)
            {
                foreach (Bidder item in listofbidders)
                {
                    var supplierdetail = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, item.SupplierId);
                    if (supplierdetail != null && supplierdetail.Email != string.Empty &&
                            supplierdetail.Company != string.Empty && !emailDetails.ContainsKey(supplierdetail.Email))
                    {
                        emailDetails.Add(supplierdetail.Email, supplierdetail.Company);
                    }
                }
                RelatedUsers.Add("$VENDORS_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
                RelatedUsers.Add("$VENDORS_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));
            }
            //end
            Bidder lowBidder = null;
            Bidder secondLowBidder = null;
            Bidder thirdLowBidder = null;
            Supplier supplier = null;

            double VarianceBidamount = 0.0;
            double VarianceBidamountPercentage = 0;

            if (listofbidders != null && listofbidders.Count > 0)
            {
                lowBidder = listofbidders.Count > 0 ? listofbidders[0] : null;
                secondLowBidder = listofbidders.Count > 1 ? listofbidders[1] : null;
                thirdLowBidder = listofbidders.Count > 2 ? listofbidders[2] : null;

                /*HB: Variance Calculation not required for Hardbid*/
                //foreach (Bidder b in listofbidders)
                //{                   
                //    if (b.Id == project.AwardBidderId)
                //    {
                //        VarianceBidamount = b.BidAmt - project.CostEstAmt;
                //        VarianceBidamountPercentage = b.Variance;
                //    }
                //}
            }

            //bidder variance and amounts - $$VARIANCEBIDAMOUNT$	($VARIANCEBIDAMOUNTPERCENTAGE$%) $ESTIMATEBARVALUE$
            RelatedUsers.Add("$VARIANCEBIDAMOUNT$", VarianceBidamount.ToString("c"));
            RelatedUsers.Add("$VARIANCEBIDAMOUNTPERCENTAGE$", VarianceBidamountPercentage.ToString() + "%");

            if (VarianceBidamount > 0)// variance is above engineers estimate
            {
                RelatedUsers.Add("$ESTIMATEBARVALUE$", "above");
            }
            if (VarianceBidamount < 0)
            {
                RelatedUsers.Add("$ESTIMATEBARVALUE$", "below");
            }
            if (VarianceBidamount == 0)
            {
                RelatedUsers.Add("$ESTIMATEBARVALUE$", "same as");
            }
            //end

            //AT HB: there is no concept of lower bidder but what ever bidder is passed becomes bidder on action....
            lowBidder = bidder;
            if (lowBidder != null)
            {
                RelatedUsers.Add("$APPARENTLOWBIDVARIANCE$", lowBidder == null ? "" : lowBidder.Variance.ToString() + "%");
                RelatedUsers.Add("$APPARENTLOWBIDREVISEDVARIANCE$", lowBidder == null ? "" : lowBidder.RevisedVariance.ToString() + "%");
                RelatedUsers.Add("$APPARENTLOWBASEAMOUNT$", lowBidder == null ? "" : lowBidder.BaseAmt.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT1$", lowBidder == null ? "" : lowBidder.AlternateAmt1.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT2$", lowBidder == null ? "" : lowBidder.AlternateAmt2.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT3$", lowBidder == null ? "" : lowBidder.AlternateAmt3.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT4$", lowBidder == null ? "" : lowBidder.AlternateAmt4.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT5$", lowBidder == null ? "" : lowBidder.AlternateAmt5.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT6$", lowBidder == null ? "" : lowBidder.AlternateAmt6.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT7$", lowBidder == null ? "" : lowBidder.AlternateAmt7.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT8$", lowBidder == null ? "" : lowBidder.AlternateAmt8.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT9$", lowBidder == null ? "" : lowBidder.AlternateAmt9.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT10$", lowBidder == null ? "" : lowBidder.AlternateAmt10.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWAMOUNTADJUSTMENT$", lowBidder == null ? "" : lowBidder.AmtAdjustment.ToString("c"));

                RelatedUsers.Add("$APPARENTLOWBIDAMOUNT$", lowBidder == null ? "" : lowBidder.BidAmt.ToString("c"));
                RelatedUsers.Add("$BIDRANK1_LUMPSUMAMOUNT$", lowBidder == null ? "" : lowBidder.BaseAmt.ToString("c"));
                RelatedUsers.Add("$BIDRANK1_LUMPSUMRANK$", "Rank 1");

                //RelatedUsers.Add("$REJECTEDBIDDER$", lowBidder == null ? "" : lowBidder.SupplierName);
                RelatedUsers.Add("$REJECTIONREASON$", lowBidder == null ? "" : lowBidder.RejectComments);


                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, lowBidder.SupplierId);
                RelatedUsers.Add("$APPARENTLOWBIDDER$", supplier == null ? "" : supplier.Company.ToString());
                RelatedUsers.Add("$APPARENTLOWBIDDERTAXID$", supplier == null ? "" : supplier.FederalId.ToString());
                RelatedUsers.Add("$APPARENTLOWBIDDERNAME$", supplier == null || supplier.PrimaryContact == null ? "" : supplier.PrimaryContact.Name.ToString());
                RelatedUsers.Add("$APPARENTLOWBIDDEREMAIL$", supplier == null || supplier.PrimaryContact == null ? "" : supplier.PrimaryContact.Email.ToString());

                RelatedUsers.Add("$BIDRANK1_COMPANY$", supplier == null ? "" : supplier.Company.ToString());
            }
            else
            {
                RelatedUsers.Add("$APPARENTLOWBIDDER$", "");
                RelatedUsers.Add("$APPARENTLOWBIDAMOUNT$", "");
            }

            if (secondLowBidder != null)
            {
                RelatedUsers.Add("$SECONDLOWBIDVARIANCE$", secondLowBidder == null ? "" : secondLowBidder.ToString() + "%");
                RelatedUsers.Add("$SECONDLOWBIDREVISEDVARIANCE$", secondLowBidder == null ? "" : secondLowBidder.RevisedVariance.ToString() + "%");

                RelatedUsers.Add("$SECONDLOWBASEAMOUNT$", secondLowBidder == null ? "" : secondLowBidder.BaseAmt.ToString("c"));

                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT1$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt1.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT2$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt2.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT3$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt3.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT4$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt4.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT5$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt5.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT6$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt6.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT7$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt7.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT8$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt8.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT9$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt9.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT10$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt10.ToString("c"));
                RelatedUsers.Add("$SECONDLOWAMOUNTADJUSTMENT$", secondLowBidder == null ? "" : secondLowBidder.AmtAdjustment.ToString("c"));

                RelatedUsers.Add("$SECONDLOWBIDAMOUNT$", secondLowBidder == null ? "" : secondLowBidder.BidAmt.ToString("c"));
                RelatedUsers.Add("$BIDRANK2_LUMPSUMAMOUNT$", secondLowBidder == null ? "" : secondLowBidder.BaseAmt.ToString("c"));

                RelatedUsers.Add("$BIDRANK2_LUMPSUMRANK$", "Rank 2");

                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, secondLowBidder.SupplierId);
                RelatedUsers.Add("$SECONDLOWBIDDER$", supplier == null ? "" : supplier.Company.ToString());
                RelatedUsers.Add("$SECONDLOWBIDDERTAXID$", supplier == null ? "" : supplier.FederalId.ToString());
                RelatedUsers.Add("$SECONDLOWBIDDERNAME$", supplier == null || supplier.PrimaryContact == null ? "" : supplier.PrimaryContact.Name.ToString());
                RelatedUsers.Add("$SECONDLOWBIDDEREMAIL$", supplier == null || supplier.PrimaryContact == null ? "" : supplier.PrimaryContact.Email.ToString());

                RelatedUsers.Add("$BIDRANK2_COMPANY$", supplier == null ? "" : supplier.Company.ToString());
            }
            else
            {
                RelatedUsers.Add("$SECONDLOWBIDDER$", "");
                RelatedUsers.Add("$SECONDLOWBIDAMOUNT$", "");
            }

            if (thirdLowBidder != null)
            {
                RelatedUsers.Add("$THIRDLOWBIDVARIANCE$", thirdLowBidder == null ? "" : thirdLowBidder.Variance.ToString() + "%");
                RelatedUsers.Add("$THIRDLOWBIDREVISEDVARIANCE$", thirdLowBidder == null ? "" : thirdLowBidder.RevisedVariance.ToString() + "%");

                RelatedUsers.Add("$THIRDLOWBASEAMOUNT$", thirdLowBidder == null ? "" : thirdLowBidder.BaseAmt.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT1$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt1.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT2$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt2.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT3$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt3.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT4$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt4.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT5$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt5.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT6$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt6.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT7$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt7.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT8$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt8.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT9$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt9.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT10$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt10.ToString("c"));
                RelatedUsers.Add("$THIRDLOWAMOUNTADJUSTMENT$", thirdLowBidder == null ? "" : thirdLowBidder.AmtAdjustment.ToString("c"));

                RelatedUsers.Add("$THIRDLOWBIDAMOUNT$", thirdLowBidder == null ? "" : thirdLowBidder.BidAmt.ToString("c"));
                RelatedUsers.Add("$BIDRANK3_LUMPSUMAMOUNT$", thirdLowBidder == null ? "" : thirdLowBidder.BaseAmt.ToString("c"));
                RelatedUsers.Add("$BIDRANK3_LUMPSUMRANK$", "Rank 3");

                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, thirdLowBidder.SupplierId);
                RelatedUsers.Add("$THIRDLOWBIDDER$", supplier == null ? "" : supplier.Company.ToString());
                RelatedUsers.Add("$THIRDLOWBIDDERTAXID$", supplier == null ? "" : supplier.FederalId.ToString());
                RelatedUsers.Add("$THIRDLOWBIDDERNAME$", supplier == null || supplier.PrimaryContact == null ? "" : supplier.PrimaryContact.Name.ToString());
                RelatedUsers.Add("$THIRDLOWBIDDEREMAIL$", supplier == null || supplier.PrimaryContact == null ? "" : supplier.PrimaryContact.Email.ToString());

                RelatedUsers.Add("$BIDRANK3_COMPANY$", supplier == null ? "" : supplier.Company.ToString());
            }
            else
            {
                RelatedUsers.Add("$THIRDLOWBIDDER$", "");
                RelatedUsers.Add("$THIRDLOWBIDAMOUNT$", "");
            }

            Bidder awardBidder = bidder;
            RelatedUsers.Add("$FINALBIDVARIANCE$", awardBidder == null ? "" : bidder.Variance.ToString() + "%");
            RelatedUsers.Add("$FINALBIDREVISEDVARIANCE$", awardBidder == null ? "" : bidder.RevisedVariance.ToString() + "%");

            double finalBidAmount = 0;
            if (awardBidder != null)
            {
                if (awardBidder.FinalAmt > 0)
                {
                    finalBidAmount = awardBidder.FinalAmt;
                }
                else
                {
                    finalBidAmount = awardBidder.BidAmt;
                }
            }

            RelatedUsers.Add("$FINALBIDAMOUNT$", awardBidder == null ? "" : finalBidAmount.ToString("c"));
            Supplier awardSupplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, bidder.SupplierId);
            RelatedUsers.Add("$AWARDBIDDER$", awardSupplier == null ? "" : awardSupplier.Company.ToString());
            RelatedUsers.Add("$AWARDBIDDERTAXID$", awardSupplier == null ? "" : awardSupplier.FederalId.ToString());
            RelatedUsers.Add("$AWARDBIDDERNAME$", awardSupplier == null || awardSupplier.PrimaryContact == null ? "" : awardSupplier.PrimaryContact.Name.ToString());
            RelatedUsers.Add("$AWARDBIDDEREMAIL$", awardSupplier == null || awardSupplier.PrimaryContact == null ? "" : awardSupplier.PrimaryContact.Email.ToString());

            /*HB: Wicks not part of hardbid right now*/
            //BidderWicksCollection bws = new BidderWicksCollection();
            //if (awardBidder != null)
            //{
            //    bws = BidderWicksUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME,
            //        BidderWicksManager.FIND_BY_BIDDER, new object[] { awardBidder.Id });
            //}

            //if (bws != null && bws.Count > 0)
            //{
            //    supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, bws[0].PlumbingSupplierId);
            //    RelatedUsers.Add("$WICKSUBPLUMB$", supplier == null ? "" : supplier.Company);
            //    RelatedUsers.Add("$WICKSUBPLUMBTAXID$", supplier == null ? "" : supplier.FederalId);
            //    supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, bws[0].ElectricalSupplierId);
            //    RelatedUsers.Add("$WICKSUBELEC$", supplier == null ? "" : supplier.Company);
            //    RelatedUsers.Add("$WICKSIBELECTAXID$", supplier == null ? "" : supplier.FederalId);
            //    supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, bws[0].HVACSupplierId);
            //    RelatedUsers.Add("$WICKSUBHVAC$", supplier == null ? "" : supplier.Company);
            //    RelatedUsers.Add("$WICKSUBHVACTAXID$", supplier == null ? "" : supplier.FederalId);
            //}


            emailmessage.FromEmail = ReplaceRelatedUsers(emailmessage.FromEmail, RelatedUsers);
            emailmessage.FromName = ReplaceRelatedUsers(emailmessage.FromName, RelatedUsers);
            emailmessage.ToEmail = ReplaceRelatedUsers(emailmessage.ToEmail, RelatedUsers);
            emailmessage.ToName = ReplaceRelatedUsers(emailmessage.ToName, RelatedUsers);
            emailmessage.CcEmail = ReplaceRelatedUsers(emailmessage.CcEmail, RelatedUsers);
            emailmessage.BccEmail = ReplaceRelatedUsers(emailmessage.BccEmail, RelatedUsers);
            emailmessage.Subject = ReplaceRelatedUsers(emailmessage.Subject, RelatedUsers);
            emailmessage.Body = ReplaceRelatedUsers(emailmessage.Body, RelatedUsers);

            return emailmessage;
        }

        /// <summary>
        /// This function does apply new business logic according to the userStory #2025
        /// 
        /// </summary>
        /// <param name="emailMessage"></param>
        /// <param name="project"></param>
        /// <param name="RelatedUsers"></param>
        private static void HBControlPlaceHolderTemplateForRoles(EmailMessage emailMessage, Project project, Hashtable RelatedUsers)
        {
            Dictionary<string, string> emailDetails = new Dictionary<string, string>();

            switch (emailMessage.Name.Trim())
            {
                case "HB_BP_PODM_PREBID":
                case "HB_BO_BIDDER_REJECTED":
                case "HB_BO_BIDRESULTS_CM_WBRKDWN":
                case "HB_BO_BIDRESULTS_CM_WOBRKDWN":
                case "HB_BAFO_RESULT_NOTIFY":
                case "HB_BIDBRKDN_BYPASS_BAFO_NEXTBIDDER":
                case "HB_BIDBRKDN_PROCEED_HOLD":
                case "HB_BIDBRKDN_REBID_CANCEL":
                case "HB_CONTRACT_EXECUTION_SCA":
                case "HB_PROJECT_CANCELLED":
                case "HB_PROJECT_REBID":                   
                    break;

                case "HB_RP_NOTIFY_OIG_FIN_CQU_VPCM":
                case "HB_RP_VPCM_DISAPPROVED":
                case "HB_EP_PRESIDENT_CANCEL":
                   
                    break;

                case "HB_ADDENDUM_SCA_INTERNAL":
                     
                    break;
                default: break;
            }
        }
        #endregion Email Method
       
        public static void SetHBUsers(Project proj, int userId)
        {
            if (proj != null)
            {
                HBAddProjectUser(proj.PO, ConstantUtility.ROLE_PROJECT_OFFICER, userId);
                HBAddProjectUser(proj.SPO, ConstantUtility.ROLE_SENIOR_PROJECT_OFFICER, userId);
                HBAddProjectUser(proj.CPO, ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER, userId);
                HBAddProjectUser(proj.ContractSpecialist, ConstantUtility.ROLE_CONTRACT_SPECIALIST, userId);
            }
        }

        public static void HBAddProjectUser(string userName, string roleName, int userId)
        {
            if (userName.Trim().Length > 0)
            {
                CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, userName);
                if (cesUser != null)
                    AddUser(cesUser, roleName, "", userId);
            }
        }
        /*
        public static void HBGetAllLevelBreakdown(BreakdownCollection breakdowns, ref BreakdownCollection allLevelBreakdowns, ref int level)
        {
            if (breakdowns != null)
            {
                foreach (Breakdown m in breakdowns)
                {
                    string toolTip = "";
                    for (int i = 1; i < level; i++)
                        //toolTip += "  ";
                        toolTip += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    //toolTip += "<a href=\"javascript:SelectBreakdown(" + m.Id + ", '" + m.Name.Replace("'", "\\'") + "');\">" + m.Name + "</a>";

                    m.Name = toolTip + m.Name;
                    if (level != 0)
                        allLevelBreakdowns.Add(m);
                    if (m.SubBreakdowns != null)
                    {
                        level++;
                        HBGetAllLevelBreakdown(m.SubBreakdowns, ref allLevelBreakdowns, ref level);
                    }
                }
            }
            level--;

        }
        */
        #region Package Functions
        /*
        public static byte[] HBReplace(Project project, Package package, Rfc rfc, ProjectAddendum addendum)
        {
            byte[] attachment = package.Attachment;


            Dictionary<string, string> fields = new Dictionary<string, string>();
            fields["Date"] = DateTime.Today.ToString("MMMM dd, yyyy");

            if (project != null)
            {
                fields["ProjectType"] = project.Type;
                fields["SolicitationNo"] = project.SolicitationNo + "-" + project.SolicitSeq;
                fields["Description"] = project.Description.Trim();
                fields["DesignNo"] = project.DesignNo;
                fields["PackageNo"] = project.PackageNo;
                fields["ContractNo"] = project.ContractNo;
                fields["PerformancePeriod"] = project.ProjectDuration.ToString();
                fields["ContractDocsPrice"] = project.DocsPrice.ToString("c");
                fields["PreBidDate"] = project.PreBidMeetingDateTime.ToString("MMMM dd, yyyy");
                fields["PreBidTime"] = project.PreBidMeetingDateTime.ToShortTimeString();
                fields["PreBidLocation"] = project.PreBidMeetingLoc;
                fields["BOD"] = project.PlanedBidOpeningDateTime.ToString("MMMM dd, yyyy");
                fields["BOT"] = project.PlanedBidOpeningDateTime.ToShortTimeString();
                fields["DocsAvailable"] = project.DocsAvailableDate.ToString("MMMM dd, yyyy");
                fields["CostEstAmt"] = project.CostEstAmt.ToString("c");
                fields["RevisedCostEstAmt"] = project.RevisedCostEstAmt.ToString("c");
                fields["CostAmt"] = project.CostAmt.ToString("c");
                fields["SolicitPkgRcvdDate"] = project.SolicitPkgRcvdDate.ToString("MMMM dd, yyyy");
                fields["IFBDate"] = project.IFBDate.ToString("MMMM dd, yyyy");
                fields["ProjectRange"] = project.MinAmt.ToString("c") + " - " + project.MaxAmt.ToString("c");

                fields["CMFIRMNAME"] = "";
                SettingCollection settings = CommonUtility.GetSettings("MentorCMFirms.xml");
                foreach (Setting setting in settings)
                {
                    if (project.CMRep == setting.Value)
                    {
                        fields["CMFIRMNAME"] = setting.Name;
                        break;
                    }
                }

                int finalCompletionDays = 0;
                if (project.Type == "Line")
                    finalCompletionDays = project.ProjectDuration + 120;
                else if (project.ProjectDuration <= 365)
                    finalCompletionDays = project.ProjectDuration + 30;
                else if (project.ProjectDuration > 365 && project.ProjectDuration <= 730)
                    finalCompletionDays = project.ProjectDuration + 60;
                else if (project.ProjectDuration > 730)
                    finalCompletionDays = project.ProjectDuration + 90;

                fields["FinalCompletionDays"] = finalCompletionDays.ToString();

                User contractSpecialist = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, project.ContractSpecialist);
                if (contractSpecialist != null)
                {
                    fields["ContSpecName"] = contractSpecialist.FullName;
                    fields["ContSpecEmail"] = contractSpecialist.Email;
                    fields["ContSpecPhone"] = contractSpecialist.Phone;
                }
                User po = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, project.PO);
                if (po != null)
                {
                    fields["PO"] = po.FullName;
                }
                User spo = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, project.SPO);
                if (spo != null)
                {
                    fields["SPO"] = spo.FullName;
                }
                User cpo = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, project.CPO);
                if (cpo != null)
                {
                    fields["CPO"] = cpo.FullName;
                }

                Bidder lowBidder = null;
                Bidder secondLowBidder = null;
                Bidder thirdLowBidder = null;
                BidderCollection bidders = BidderUtility.FindByCriteria(
                    ConstantUtility.RFD_DATASOURCE_NAME,
                    BidderManager.FIND_BY_PROJECT,
                    new object[] { project.Id });

                if (bidders != null)
                {
                    foreach (Bidder b in bidders)
                    {
                        if (b.Rank == 1)
                            lowBidder = b;
                        else if (b.Rank == 2)
                            secondLowBidder = b;
                        else if (b.Rank == 3)
                            thirdLowBidder = b;
                    }
                    fields["BIDDERSNO"] = bidders.Count.ToString();
                }

                if (lowBidder != null)
                {
                    fields["APPARENTLOWBIDAMOUNT"] = lowBidder.BidAmt.ToString("c");
                    fields["APPARENTLOWBIDDERVARIANCE"] = lowBidder.Variance.ToString("0.00");

                    Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, lowBidder.SupplierId);
                    if (supplier != null)
                    {
                        fields["APPARENTLOWBIDDER"] = supplier.Company;
                        fields["APPARENTLOWBIDDERTAXID"] = supplier.FederalId;

                        if (supplier.PrimaryContact != null)
                        {
                            fields["APPARENTLOWBIDDERNAME"] = supplier.PrimaryContact.Name;
                            fields["APPARENTLOWBIDDEREMAIL"] = supplier.PrimaryContact.Email;
                        }
                    }
                }
                if (secondLowBidder != null)
                {
                    fields["SECONDLOWBIDAMOUNT"] = secondLowBidder.BidAmt.ToString("c");
                    fields["SECONDLOWBIDDERVARIANCE"] = secondLowBidder.Variance.ToString("0.00");

                    Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, secondLowBidder.SupplierId);
                    if (supplier != null)
                    {
                        fields["SECONDLOWBIDDER"] = supplier.Company;
                        fields["SECONDLOWBIDDERTAXID"] = supplier.FederalId;

                        if (supplier.PrimaryContact != null)
                        {
                            fields["SECONDLOWBIDDERNAME"] = supplier.PrimaryContact.Name;
                            fields["SECONDLOWBIDDEREMAIL"] = supplier.PrimaryContact.Email;
                        }
                    }
                }
                if (thirdLowBidder != null)
                {
                    fields["THIRDLOWBIDAMOUNT"] = thirdLowBidder.BidAmt.ToString("c");
                    fields["THIRDLOWBIDDERVARIANCE"] = thirdLowBidder.Variance.ToString("0.00");

                    Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, thirdLowBidder.SupplierId);
                    if (supplier != null)
                    {
                        fields["THIRDLOWBIDDER"] = supplier.Company;
                        fields["THIRDLOWBIDDERTAXID"] = supplier.FederalId;

                        if (supplier.PrimaryContact != null)
                        {
                            fields["THIRDLOWBIDDERNAME"] = supplier.PrimaryContact.Name;
                            fields["THIRDLOWBIDDEREMAIL"] = supplier.PrimaryContact.Email;
                        }
                    }
                }

                Bidder awardBidder = BidderUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, project.AwardBidderId);
                if (awardBidder != null)
                {
                    fields["FINALBIDAMOUNT"] = awardBidder.FinalAmt.ToString("c");

                    Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, project.AwardSupplierId);
                    if (supplier != null)
                    {
                        fields["AWARDBIDDER"] = supplier.Company;
                        fields["AWARDBIDDERTAXID"] = supplier.FederalId;

                        if (supplier.PrimaryContact != null)
                        {
                            fields["AWARDBIDDERNAME"] = supplier.PrimaryContact.Name;
                            fields["AWARDBIDDEREMAIL"] = supplier.PrimaryContact.Email;
                        }

                        if (supplier.PhysicalAddress != null)
                        {
                            fields["AWARDBIDDERADDRESS"] =
                                supplier.PhysicalAddress.AddressLine1.Replace("|", " ") + " " +
                                supplier.PhysicalAddress.AddressLine2.Replace("|", " ") + " " +
                                supplier.PhysicalAddress.City + ", " +
                                supplier.PhysicalAddress.State + " " +
                                supplier.PhysicalAddress.ZipCode;
                        }
                    }
                }
            }
            if (package != null)
            {
                fields["DocumentName"] = package.Name;
            }
            if (addendum != null)
            {
                fields["AddendumDescription"] = addendum.Description;
                fields["AddendumComments"] = addendum.Comments;
                fields["NumberOfPages"] = addendum.NumberOfPages.ToString();
                fields["NumberOfSheets"] = addendum.NumberOfSheets.ToString();
                fields["PickupDate"] = addendum.PickupDate.ToString("MMMM dd, yyyy");
                fields["PickupTime"] = addendum.PickupDate.ToShortTimeString();
            }

            if (project.Items != null && project.Items.Count > 0)
            {
                string schools = "";
                string schoolsAddr = "";
                string llws = "";
                foreach (ProjectItem item in project.Items)
                {
                    if (schools.IndexOf(item.School.Trim()) >= 0) continue;
                    schools += "," + item.School.Trim() + " (" + item.Boro() + ")"; ;
                    schoolsAddr += "/" + item.SchoolAddressLine1.Trim() + " " + item.SchoolAddressLine2.Trim();

                }
                foreach (ProjectItem item in project.Items)
                {
                    if (llws.IndexOf(item.LLW.Trim()) >= 0) continue;
                    llws += "," + item.LLW.Trim();
                }
                schools = schools.Substring(1);
                schoolsAddr = schoolsAddr.Substring(1);
                llws = llws.Substring(1);

                fields["School"] = schools;
                fields["SchoolAddress"] = schoolsAddr;
                fields["LLW"] = llws;
            }

            if (rfc != null)
            {
                fields["LiquidatedDamages"] = rfc.Result;

                User designManager = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, rfc.DesignManager);
                if (designManager != null)
                {
                    fields["DesignMgr"] = designManager.FullName;
                }
            }

            return OpenXmlUtility.MergeWordDoc(attachment, fields);
        }


        public static void HBMergePackage(Package package, int userId)
        {
            Project project = ProjectUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME,
                package.ProjectId);

            Rfc rfc = null;
            if (project.RfcId > 0)
                rfc = RfcUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, project.RfcId);
            else
                rfc = RfcUtility.GetByNumber(ConstantUtility.RFD_DATASOURCE_NAME, project.TransNumber, "Bid");

            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, userId);

            ProjectAddendum addendum = ProjectAddendumUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, package.AddendumId);

            package.Attachment = Replace(project, package, rfc, addendum);
            package.Version = HBGetNextMinorVersion(package.Version);
            package.ChangeUser = user.UserName;
        }

        public static string HBGetNextMajorVersion(string version)
        {
            int majorVersion = 0;
            string[] versions = version.Split('.');
            if (versions.Length > 0)
            {
                majorVersion = ConvertUtility.ConvertInt(versions[0]);
            }
            majorVersion += 1;
            return majorVersion.ToString() + ".0";
        }
        
        public static string HBGetNextMinorVersion(string version)
        {
            int majorVersion = 0;
            int minorVersion = 0;
            string[] versions = version.Split('.');
            if (versions.Length > 1)
            {
                majorVersion = ConvertUtility.ConvertInt(versions[0]);
                minorVersion = ConvertUtility.ConvertInt(versions[1]);
            }
            if (majorVersion == 0)
                majorVersion = 1;
            minorVersion += 1;
            return majorVersion.ToString() + "." + minorVersion.ToString();
        }
        */
        
        
        #endregion
    }
}

