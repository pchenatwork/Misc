#region Copyright
/*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System.Xml;
using System.Xml.XPath;
using System.IO;
using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using System.Linq;
using System;
using System.Web.UI;
using SCA.VAS.Common.ValueObjects;

#endregion Reference

namespace SCA.VAS.Workflow
{
    public class ProjectBidderWorkflowExec
    {
        #region Private Member        
        private static int userId = 0;
        private static string workflowType = string.Empty;
        public static string WorkflowType
        {
            set { workflowType = value; }
        }

        #endregion

        #region Constructor
        public ProjectBidderWorkflowExec()
        {
        }
        static ProjectBidderWorkflowExec()
        {
        }
        #endregion Constructor

        #region Private Method

        #endregion

        #region Workflow Control
        public static AssociateWorkflows GetAssociatedWorkflows(Bidder bidder)
        {
            return GetAssociatedWorkflows(bidder.ProjectId, bidder.Id);

        }

        public static AssociateWorkflows GetAssociatedWorkflows(int projectId, int bidderId)
        {
            var _associate = new AssociateWorkflows
            {

                Workflows = ProjectBidderWorkflowUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME, ProjectBidderWorkflowManager.FIND_WORKFLOW_BY_BIDDER,
                                                                     new object[] { projectId, bidderId })
            };


            return _associate;

        }

        public static ProjectBidderWorkflow InitialProjectBidderWorkflow(Project project, Bidder bidder, string workflowTypeName)
        {
            workflowType = workflowTypeName;
            return GetProjectBidderWorkflow(project, bidder);
        }

        public static void DeleteProjectBidderWorkflow(ProjectBidderWorkflow workflow)
        {
            ProjectBidderWorkflowUtility.Delete(ConstantUtility.RFD_DATASOURCE_NAME, workflow.Id);
        }


        public static int ProjectBidderWorkflow(Project project, Bidder bidder, string systemAction, string comments, ref string errmsg, ref string url)
        {
            ProjectBidderWorkflow projectWorkflow = GetProjectBidderWorkflow(project, bidder);
            if (projectWorkflow == null) return 0;

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria( ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                                                                                       WorkflowNodeManager.FIND_WORKFLOWNODE_BY_SYSTEMNAME,
                                                                                       new object[] { projectWorkflow.WorkflowId, systemAction });
            if (workflowNodes == null || workflowNodes.Count == 0) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectWorkflow.TransactionId);
            if (workflowHistory == null)
                return 0;

            //Finding the Id from WorkflowNodes where FromId of WorkflowNode belongs to Current Bidders WorkflowHistory CurrentNodeID
            int actionId = (workflowNodes.Cast<WorkflowNode>().FirstOrDefault(w => w.NodeFromId == workflowHistory.CurrentNodeId)?.Id).ToInt();
            
            return ProjectBidderWorkflow(project, bidder, actionId, comments, ref errmsg, ref url);
        }

        public static int ProjectBidderWorkflow(Project project, Bidder bidder, int actionId, string comments, ref string errmsg, ref string url)
        {
            ProjectBidderWorkflow bidderWorkflow = GetProjectBidderWorkflow(project, bidder );
            if (bidderWorkflow == null) return 0;
            if (actionId == 0) return bidderWorkflow.TransactionId;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(bidderWorkflow.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowNode workflowNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
            if (workflowNode == null)
                return 0;
            if (workflowHistory.CurrentNodeId != workflowNode.NodeFromId)
                return 0;

            // condition proccessing
            /* //HB: For now Stopping Condition Processing 
            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(   ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                                                                                                        WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                                                                                                        new object[] { workflowNode.Id });

            TextReader reader = XmlUtility.Serialize(project);
            XPathDocument doc = new XPathDocument(reader);
            XPathNavigator nav = doc.CreateNavigator();

            errmsg = string.Empty;
            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count == 0)
                    {
                        errmsg += workflowCondition.ErrorMessage + "<br>";
                    }
                }
            }
            if (errmsg != string.Empty) return 0;
            */

            //Workflow topologic
            bool approval = true;
            switch (workflowNode.Action1)
            {
                case "One":
                    break;
                case "Owner":
                    break;
                case "All":
                case "Majority":
                case "Count":
                    WorkflowHistoryCollection workflowHistories = WorkflowHistoryUtility.FindByCriteria(
                        ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                        new object[] { bidderWorkflow.TransactionId });

                    WorkflowHistoryCollection currentHistories = new WorkflowHistoryCollection();
                    if (workflowHistories != null)
                    {
                        for (int i = workflowHistories.Count - 1; i >= 0; i--)
                        {
                            if (workflowHistories[i].IsActive == 1) break;
                            if (workflowHistories[i].CurrentNodeId != actionId) continue;
                            if (workflowHistories[i].ApprovalUserId == userId)
                            {
                                errmsg = "You already approved this step";
                                return 0;
                            }
                            currentHistories.Add(workflowHistories[i]);
                        }
                    }

                    // Create a history from new approval
                    WorkflowHistory approvalHistory = WorkflowHistoryUtility.CreateObject();
                    approvalHistory.TransactionHeaderId = bidderWorkflow.TransactionId;
                    approvalHistory.WorkflowId = bidderWorkflow.WorkflowId;
                    approvalHistory.CurrentNodeId = actionId;
                    approvalHistory.ApprovalUserId = WorkflowExec.GetUserId();
                    approvalHistory.ApprovalConditionId = 1;
                    approvalHistory.CreatedBy = workflowHistory.ApprovalUserId;
                    approvalHistory.CreatedType = WorkflowExec.GetUserType();
                    WorkflowHistoryUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, approvalHistory);

                    int approvalKnt = currentHistories.Count + 1;
                    switch (workflowNode.Action1)
                    {
                        case "All":
                            break;
                        case "Majority":
                            break;
                        case "Count":
                            int knt = ConvertUtility.ConvertInt(workflowNode.Action2);
                            if (approvalKnt < knt)
                                approval = false;
                            break;
                    }
                    break;
            }

            if (!approval || errmsg != string.Empty) return bidderWorkflow.TransactionId;

            //Action proccessing
            WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE,
                new object[] { workflowNode.Id });

            if (workflowActions != null)
            {
                foreach (WorkflowAction workflowAction in workflowActions)
                {
                    switch (workflowAction.Type)
                    {
                        //Send Email
                        case 1:

                            var emailTask = System.Threading.Tasks.Task.Run(() =>
                            {
                                    /*BIDDER RELATE THINGS LATER NEED TO COME BACK */
                                    CommonUtility.HBProjectSendEmail(project, bidder, workflowNode, workflowHistory,workflowAction.FunctionName, comments, GetAssociatedWorkflows(bidder));
                            });
                            emailTask.ConfigureAwait(false);
                            break;

                        //Action
                        case 2:
                            ProjectAction(project, bidder, workflowAction.FunctionName);
                            break;

                        //Redirect page
                        case 3:
                            url = workflowAction.FunctionName;
                            break;
                    }
                }
            }

            if (workflowNode.NodeToId > 0)
            {
                WorkflowNode nextNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode.NodeToId);
                WorkflowExec.WorkflowNextStatus(workflowNode.WorkflowId, nextNode.Name, workflowHistory.CurrentNodeId, bidderWorkflow.TransactionId, comments);

                NodeAction(project, bidder, comments);
            }

            return bidderWorkflow.TransactionId;
        }

        public static int ProjectBidderWorkflow(Project project, Bidder bidder, string nextStatus, string comments)
        {
            ProjectBidderWorkflow projectWorkflow = GetProjectBidderWorkflow(project, bidder);
            if (projectWorkflow == null) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectWorkflow.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowExec.WorkflowNextSystemStatus(projectWorkflow.WorkflowId, nextStatus, workflowHistory.CurrentNodeId, projectWorkflow.TransactionId, comments);

            NodeAction(project, bidder, comments);

            return projectWorkflow.TransactionId;
        }

        public static WorkflowConditionCollection ProjectBidderWorkflowConditionTest(Project project, Bidder bidder, int workflowNodeId)
        {            
            ProjectBidderWorkflow projectWorkflow = GetProjectBidderWorkflow(project, bidder);
            if (projectWorkflow == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectWorkflow.TransactionId);
            if (workflowHistory == null)
                return null;

            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(ConstantUtility.WORKFLOW_DATASOURCE_NAME, 
                                                                                                     WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                                                                                                     new object[] { workflowNodeId });

            XPathDocument doc = new XPathDocument(XmlUtility.Serialize(project));
            XPathNavigator nav = doc.CreateNavigator();

            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count > 0)
                        workflowCondition.Status = 1;
                }
            }
            return workflowConditions;
        }

        public static void BackwardUpdateStatus(Project project, Bidder bidder, string newWorkflowStatusValue, string comments)
        {
            ProjectBidderWorkflow projectWorkflow = GetProjectBidderWorkflow(project, bidder);
            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectWorkflow.TransactionId);
            
            int status = CommonUtility.HBGetProjectStatusId(workflowType, workflowHistory.CurrentNode.Name.Trim());

            if ( status == 0 ) return;
            ProjectBidderWorkflowUtility.UpdateStatus(ConstantUtility.RFD_DATASOURCE_NAME, projectWorkflow.Id, status, workflowHistory.CurrentNode.Name.Trim());

            ProjectBidderWorkflow(project, bidder, newWorkflowStatusValue, comments);
        }
        #endregion Workflow Control

        #region Workflow Node Action
        private static void NodeAction(Project project, Bidder bidder, string comments)
        {
            ProjectBidderWorkflow projectWorkflow = GetProjectBidderWorkflow(project, bidder);
            if (projectWorkflow == null) return;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectWorkflow.TransactionId);

            int status = CommonUtility.HBGetProjectStatusId(workflowType, workflowHistory.CurrentNode.Name.Trim()); //HB: need to go inside Method and fix Satus...

            if (status == 0 || status == projectWorkflow.Status) return;
            ProjectBidderWorkflowUtility.UpdateStatus(ConstantUtility.RFD_DATASOURCE_NAME, projectWorkflow.Id, status, workflowHistory.CurrentNode.Name.Trim());

            // automatic step
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { projectWorkflow.WorkflowId, "UserStepId", "ASC" });
            if (workflowNodes != null)
            {
                for (int i = 0; i < workflowNodes.Count; i++)
                {
                    if (workflowNodes[i].Type != 1 || workflowNodes[i].TimeToSkip != 1 ||
                        workflowHistory.CurrentNodeId != workflowNodes[i].NodeFromId)
                        continue;

                    string errmsg = string.Empty;
                    string url = string.Empty;
                    ProjectBidderWorkflow(project, bidder, workflowNodes[i].Id, comments, ref errmsg, ref url);
                }
            }
        }
        #endregion Workflow Node Action

        #region ^Get Project Bidder Current Workflow List
        private static ProjectBidderWorkflow GetProjectBidderWorkflow(Project project, Bidder bidder)
        {
            bool isNewWorkflow = false;
            ProjectBidderWorkflow bidderWorkflow = GetAssociatedWorkflows(bidder).CurrentWorkflow;

            if (bidderWorkflow == null)
            {
                bidderWorkflow = new ProjectBidderWorkflow { ProjectId = project.Id, BidderId = bidder.Id };
                WorkflowList workflow = WorkflowListUtility.GetByName(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowType, 0);
                if (workflow != null)
                {
                    bidderWorkflow.WorkflowId = workflow.Id;
                    bidderWorkflow.WorkflowType = workflow.Type;
                    isNewWorkflow = true;
                }
            }

            if (bidderWorkflow.TransactionId == 0)
            {
                bidderWorkflow.TransactionId = WorkflowExec.CreateWorkflowHistory(bidderWorkflow.WorkflowId);
                if (bidderWorkflow.TransactionId == 0) return null;
                if (bidder.Workflows == null)
                    bidder.Workflows = new ProjectBidderWorkflowCollection();
                bidder.Workflows.Add(bidderWorkflow);
                ProjectBidderWorkflowUtility.UpdateCollection(ConstantUtility.RFD_DATASOURCE_NAME, project.Id, bidder.Id, bidder.Workflows);

                if (isNewWorkflow)
                    bidder.Workflows = GetAssociatedWorkflows(bidder).Workflows;
                   
                NodeAction(project, bidder, "New Workflow");
            }
            return bidderWorkflow;
        }
        #endregion ~End of Get Project Bidder Current Workflow List

        #region Project Action

        private static void ProjectAction(Project project, Bidder bidder, string actionName)
        {
            string msg = string.Empty;
            string url = string.Empty;
            string tempType = workflowType;
        
            var _asct = GetAssociatedWorkflows(bidder);
            bidder.Workflows = _asct.Workflows;

            switch (actionName)
            {
                case "SampleAction":
                    //Action Here
                    break;

                case "BafoDone_IfVettingFinished_MoveBidderForward":
                case "AwardVettingMerge":              
                case "VettingDirectorApproved":

                    ForwardBidderFromBafoAndPreAwardVetting(project, bidder, _asct, ref msg, ref url);
                    break;

                //case "CheckMentorFinancing":

                //    workflowType = ConstantUtility.WORKFLOW_HB_BAFO;
                //    ProjectBidderWorkflow(project, bidder, SCA.VAS.Workflow.ProjectAction.FinancingVerification.Name, "No need for Financing Verification", ref msg, ref url);
                //    break;
                case "Bypass_President":
                    break;


                /*  //HB: WICKS PART NOT FOR THIS RELEASE 
                case "CreateRS1Subcontractors":                   
                    
                    BidderWicksCollection wicks = BidderWicksUtility.FindByCriteria(
                        ConstantUtility.RFD_DATASOURCE_NAME,
                        BidderWicksManager.FIND_BY_BIDDER,
                        new object[] { bidder.Id });

                    Supplier prime = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, bidder.SupplierId);


                    if (wicks != null)
                    {
                        Supplier supplier = null;
                        if (wicks[0].ElectricalSupplierId > 0)
                        {
                            supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, wicks[0].ElectricalSupplierId);
                            if (supplier != null)
                                CommonUtility.CreateSubcontractor(project, prime, supplier, "Electrical", wicks[0].ElectricalBidAmount);
                        }

                        if (wicks[0].PlumbingSupplierId > 0)
                        {
                            supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, wicks[0].PlumbingSupplierId);
                            if (supplier != null)
                                CommonUtility.CreateSubcontractor(project, prime, supplier, "Plumbing", wicks[0].PlumbingBidAmount);
                        }

                        if (wicks[0].HVACSupplierId > 0)
                        {
                            supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, wicks[0].HVACSupplierId);
                            if (supplier != null)
                                CommonUtility.CreateSubcontractor(project, prime, supplier, "HVAC", wicks[0].HVACBidAmount);
                        }
                    }
                    */

                    //break;
                                
                case "Routing_Approval_Start":

                    //VP To be decided based on JMType.
                    switch (project.JmType)
                    {
                        case ConstantUtility.JMTYPE_ASB:
                            workflowType = ConstantUtility.WORKFLOW_HB_ROUTING_VPIEH;
                            ProjectBidderWorkflow(project, bidder, HBRoutingVPIEHStatusType.PendingVPIEHReview.Name, "");
                            break;

                        case ConstantUtility.JMTYPE_SRD:
                            workflowType = ConstantUtility.WORKFLOW_HB_ROUTING_VPAE;
                            ProjectBidderWorkflow(project, bidder, HBRoutingVPAEStatusType.PendingVPAEReview.Name, "");
                            break;

                        default:
                            workflowType = ConstantUtility.WORKFLOW_HB_ROUTING_VPCM;
                            ProjectBidderWorkflow(project, bidder, HBRoutingVPCMStatusType.PendingVPCMReview.Name, "");
                            break;
                    }

                    workflowType = ConstantUtility.WORKFLOW_HB_ROUTING_FINANCE;
                    ProjectBidderWorkflow(project, bidder, HBRoutingFinanceStatusType.PendingFinanceReview.Name, "");
                    
                    workflowType = ConstantUtility.WORKFLOW_HB_ROUTING_OIG;
                    ProjectBidderWorkflow(project, bidder, HBRoutingOIGStatusType.PendingOIGBidderReview.Name, "");

                    workflowType = ConstantUtility.WORKFLOW_HB_ROUTING_CQU;
                    ProjectBidderWorkflow(project, bidder, HBRoutingCQUStatusType.PendingCQUReview.Name, "");

                    break;

                case "VPDisapprovalRemoveAllRoutingFlows":
                    RemoveAllRoutingSubWorkflows(project, bidder, _asct);
                    break;

                case "Routing_Approval_Complete":
                    if (_asct.IsRoutingApproved)
                    {
                        workflowType = ConstantUtility.WORKFLOW_HB_ROUTING_PACKAGE;
                        ProjectBidderWorkflow(project, bidder, HBProjectAction.RoutingPackageApprovalComplete.Name , "", ref msg, ref url);

                        workflowType = ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE;
                        ProjectBidderWorkflow(project, bidder, HBExecutionPackageStatusType.ExecutionPackagePending.Name, ""); //, ref msg, ref url);
                    }                    
                    break;

                case "SeniorManagment(Legal/VPCP/EVP)ToReview":  //Check if legal/vpcp/evp workflow exists, if exists call Resume or ApprovalResume else create all 3 sub workflows.
                    SetExecutionPackageProgressOnSeniorManagement(project, bidder, _asct, ref msg, ref url);
                    break;

                case "SeniorManagementApproval":  //Push the Execution package to "Senior Management Approval Complete"
                    ExecutionPackageMoveForwardFromSeniorManagmentToPresident(project, bidder, _asct, ref msg, ref url);
                    break;
                case "CheckForProjectCompleteFromAllBidders":
                    ExecutionPackageFinishedCheckForProjectComplete(project, bidder, ref msg, ref url);
                    break;


            }
            WorkflowType = tempType;
        }

        /// <summary>
        /// Check if legal/vpcp/evp workflow exists, if exists call Resume or ApprovalResume else create all 3 sub workflows.
        /// </summary>     
        private static void SetExecutionPackageProgressOnSeniorManagement(Project project, Bidder bidder, AssociateWorkflows asct, ref string msg, ref string url)
        {
            var _isExists = asct.IsExistsExecutionSeniorManagementWorkflows();
            var _actions = new string[] 
            { 
                (_isExists ? HBProjectAction.LegalExecutionPackageResume : (EnumerationBase)HBExecutionPackageLegalStatusType.ExecutionPackageLegalPending).Name,
                (_isExists ? HBProjectAction.VPCPExecutionPackageResume :  (EnumerationBase)HBExecutionPackageVPCPStatusType.ExecutionPackageVPCPPending).Name,
                (_isExists ? HBProjectAction.EVPExecutionPackageResume : (EnumerationBase)HBExecutionPackageEVPStatusType.ExecutionPackageEVPPending).Name,
            };

            workflowType = ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_LEGAL;
            var res = _isExists ? ProjectBidderWorkflow(project, bidder, _actions[0], "", ref msg, ref url) : ProjectBidderWorkflow(project, bidder, _actions[0], "");

            workflowType = ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_VPCP;
            res = _isExists ? ProjectBidderWorkflow(project, bidder, _actions[1], "", ref msg, ref url) : ProjectBidderWorkflow(project, bidder, _actions[1], "");

            workflowType = ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_EVP;
            res = _isExists ? ProjectBidderWorkflow(project, bidder, _actions[2], "", ref msg, ref url) : ProjectBidderWorkflow(project, bidder, _actions[2], "");
        }

        ///Push the Execution package to "Senior Management Approval Complete"
        private static void ExecutionPackageMoveForwardFromSeniorManagmentToPresident(Project project, Bidder bidder, AssociateWorkflows asct, ref string msg, ref string url)
        {
            if (asct.IsExectionSeniorManagementApprovalComplete)
            {
                workflowType = ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE;
                ProjectBidderWorkflow(project, bidder, HBProjectAction.ExecutionPackageApprovedSrMgm.Name, "", ref msg, ref url);
            }
        }

        private static void ExecutionPackageFinishedCheckForProjectComplete(Project project, Bidder bidder,ref string msg, ref string url)
        {
            var bidders = BidderUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME, BidderManager.FIND_BY_PROJECT, new object[] { project.Id })
                                       .Cast<Bidder>()
                                       .Where(b => b.Id != bidder.Id)
                                       .Select(b => new { Id = b.Id, AsstWflows = GetAssociatedWorkflows(b) })
                                       .Where(b => b.AsstWflows != null)
                                       .ToList();

            var _flag_all_bidders_awarded_or_halted = true;
            bidders.ForEach(bid => {

                //To check if bidder has contract awarded or any of the DO NOT Procced chain

                var _asst = bid.AsstWflows;
                var _completed = (_asst.PackageExecutionWorkflow?.Status == HBExecutionPackageStatusType.ContractAwarded ||
                                 _asst.PackageExecutionWorkflow?.Status == HBExecutionPackageStatusType.ExecutionPackageNoProceed ||
                                 _asst.OIGRoutingWorkflow?.Status == HBRoutingOIGStatusType.OIGNoProceed ||
                                 _asst.VPAERoutingWorkflow?.Status == HBRoutingVPAEStatusType.VPAENoProceed ||
                                 _asst.VPIEHRoutingWorkflow?.Status == HBRoutingVPIEHStatusType.VPIEHNoProceed
                                 );
                _flag_all_bidders_awarded_or_halted = _completed;

                if (!_completed) return;
            });

            //If all bidders workflows are complete, move on to Project Completed at GENERAL Workflow
            if (_flag_all_bidders_awarded_or_halted)
            {
                ProjectWorkflowExec.WorkflowType = ConstantUtility.WORKFLOW_HB_GENERAL;
                ProjectWorkflowExec.ProjectWorkflow(project, HBProjectAction.ProjectCompleted.Name, "All Bidders Awarded/Completed", ref msg, ref url);
            }
        }

        private static void RemoveAllRoutingSubWorkflows(Project project, Bidder bidder, AssociateWorkflows asct)
        {
           //Business: All Sub Routing Packages gets deleted, execept VPCM one, where it routes to Contract Specialist for an Next Bidder or Bidder may not proceed action (Await)
           //           Also, nothing happens to main Routing Package,
            asct.Workflows.Cast<ProjectBidderWorkflow>()
                            .Where(w => w.WorkflowType.In(ConstantUtility.WORKFLOW_HB_ROUTING_CQU,
                                                            ConstantUtility.WORKFLOW_HB_ROUTING_FINANCE,
                                                            ConstantUtility.WORKFLOW_HB_ROUTING_OIG))
                            .ForEach( ( w,i ) => DeleteProjectBidderWorkflow(w) );
        }


        private static void ForwardBidderFromBafoAndPreAwardVetting(Project project, Bidder bidder, AssociateWorkflows asct, ref string msg, ref string url)
        {
            if (asct.IsVettingComplete && ( asct.BafoApproved || asct.BafoNotNecessary ) )
            {
                var bafo = ProjectBAFOUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME,
                                                                     ProjectBAFOManager.FIND_BY_PROJECT,
                                                                     new object[] { project.Id })?
                                                      .Cast<ProjectBAFO>()
                                                      .FirstOrDefault(f => f.BidderId == bidder.Id);

                //set final amount for low bidder
                bidder.FinalAmt = (bidder.IsBAFO == "Y" && (bafo != null && bafo.IsFinal == "Y")) ? bafo.Amount : bidder.BidAmt;
                BidderUtility.Update(ConstantUtility.RFD_DATASOURCE_NAME, bidder); //Update with final amount

                //HB: Mentor not required....
                //workflowType = ConstantUtility.WORKFLOW_HB_BID_MENTOR;
                //ProjectBidderWorkflow(project, SCA.VAS.Workflow.ProjectAction.PendingMentorCPOReviewAction.Name, "", ref msg, ref url);

                //Generate Contract as well as Push the workflow to ROUTING PACKAGE CREATION
                CreateContractAndRoutingWorkflow(project, bidder);
            }

            if (asct.AllVettingApproved)
            { 
                WorkflowType = ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_PRIME;
                ProjectBidderWorkflow(project, bidder, HBProjectAction.VettingFinished.Name, "", ref msg, ref url);

                WorkflowType = ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_BIDBOND;
                ProjectBidderWorkflow(project, bidder, HBProjectAction.VettingFinished.Name, "", ref msg, ref url);

                WorkflowType = ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_FINANCIAL;
                ProjectBidderWorkflow(project, bidder, HBProjectAction.VettingFinished.Name, "", ref msg, ref url);
            }
            else if (asct.IsVettingRemediated)
            {
                //TODO: Remidiation follow up
            }
        }

        /// <summary>
        /// Creating Contract
        /// </summary>
        /// <param name="project"></param>
        /// <param name="bidder"></param>
        private static void CreateContractAndRoutingWorkflow(Project project, Bidder bidder)
        {
            var _contract = ContractUtility.GetByProject(ConstantUtility.RFD_DATASOURCE_NAME, project.Id, bidder.Id);
            if (_contract != null) ContractUtility.Delete(ConstantUtility.RFD_DATASOURCE_NAME, _contract.Id);
           
            //create contract
            Contract contract = ContractUtility.CreateObject();
            contract.ProjectId = project.Id;
            contract.Type = project.Type;
            contract.SolicitSeq = project.SolicitSeq;
            contract.ProjectDuration = (int)(project.KeyItems.Duration * 365.0f);  //takes only iteger part.
            contract.AltProjectDuration = project.AltProjectDuration;
            contract.Description = project.Description;
            contract.SolicitationNo = project.SolicitationNo;
            contract.SupplierId = bidder.SupplierId;
            contract.BidderId = bidder.Id;
            contract.Amount = bidder.FinalAmt;
            contract.IsBAFO = bidder.IsBAFO;
            contract.IsLowest = "Y"; //Always Lowest
            contract.ExecutionDate = DateTime.Now;
             
            if (ContractUtility.Create(ConstantUtility.RFD_DATASOURCE_NAME, contract)) //Only when Contract is really Generated.
            {
                ProjectUtility.UpdateContractNo(ConstantUtility.RFD_DATASOURCE_NAME, contract.Id);

                workflowType = ConstantUtility.WORKFLOW_HB_ROUTING_PACKAGE;
                ProjectBidderWorkflow(project, bidder, HBRoutingPackageStatusType.PendingRoutingPackageCreation.Name, "");
            }
        }


        /// <summary>
        /// Assciate Class 
        /// </summary>
        public class AssociateWorkflows
        {
            private ProjectBidderWorkflowCollection _workflows = null;

            public ProjectBidderWorkflowCollection Workflows { get { return _workflows; } set { SetChildren(value); } }

            public ProjectBidderWorkflow CurrentWorkflow { get; set; }

            public ProjectBidderWorkflow PrimeVettingWorkflow { get; set; }
            public ProjectBidderWorkflow BidBondVettingWorkflow { get; set; }
            public ProjectBidderWorkflow FinancialVettingWorkflow { get; set; }
            public ProjectBidderWorkflow Rs1Workflow { get; set; }
            public ProjectBidderWorkflow BafoWorkflow { get; set; }

            public ProjectBidderWorkflow PackageRoutingWorkflow = null;
            public ProjectBidderWorkflow CQURoutingWorkflow = null;
            public ProjectBidderWorkflow VPCMRoutingWorkflow = null;
            public ProjectBidderWorkflow VPIEHRoutingWorkflow = null;
            public ProjectBidderWorkflow VPAERoutingWorkflow = null;
            public ProjectBidderWorkflow FINRoutingWorkflow = null;
            public ProjectBidderWorkflow OIGRoutingWorkflow = null;

            public ProjectBidderWorkflow PackageExecutionWorkflow = null;
            public ProjectBidderWorkflow LegalExecutionWorkflow = null;
            public ProjectBidderWorkflow VPCPExecutionWorkflow = null;
            public ProjectBidderWorkflow EVPExecutionWorkflow = null;


            //Some Is....functionality
            internal bool IsWicks { get { return Rs1Workflow != null; }  }
            internal bool IsVettingAtAwardedOrRemediatedStage { 
                get
                {
                    return (!IsWicks || Rs1Approved) &&
                            (PrimeVettingWorkflow?.Status.In(HBPreAwardVettingPrimeStatusType.AwardVettingDisapproved.Id,
                                                            HBPreAwardVettingPrimeStatusType.AwardVettingApproved.Id)).ToBool() &&
                            (FinancialVettingWorkflow?.Status.In(HBPreAwardVettingFinancialStatusType.ManagerRecommendationFailed.Id, 
                                                          HBPreAwardVettingFinancialStatusType.ManagerRecommendationApproved.Id)).ToBool() &&
                            (BidBondVettingWorkflow?.Status.In(HBPreAwardVettingBidBondStatusType.ManagerRecommendationFailed.Id,
                                                        HBPreAwardVettingBidBondStatusType.ManagerRecommendationApproved.Id)).ToBool();
                }
            }
            internal bool IsVettingRemediated
            {
                get
                {
                    return IsVettingAtAwardedOrRemediatedStage && (PrimeVettingRemediated && BidBondVettingRemediated && FinancialVettingRemediated);
                }
            }
            internal bool IsVettingComplete
            {
                get
                {
                    return  PrimeVettingWorkflow?.Status == HBPreAwardVettingPrimeStatusType.AwardVettingFinished.Id &&
                            BidBondVettingWorkflow?.Status == HBPreAwardVettingBidBondStatusType.AwardVettingFinished.Id &&
                            FinancialVettingWorkflow?.Status == HBPreAwardVettingFinancialStatusType.AwardVettingFinished.Id;                            
                }
            }
            internal bool IsRoutingApproved
            {
                get
                {
                    return CQURoutingWorkflow?.Status == HBRoutingCQUStatusType.CQUReviewCompleted.Id &&
                            FINRoutingWorkflow?.Status == HBRoutingFinanceStatusType.FinanceReviewCompleted.Id &&
                            OIGRoutingWorkflow?.Status == HBRoutingOIGStatusType.OIGBidderReviewCompleted.Id &&
                            (
                                VPCMRoutingWorkflow?.Status == HBRoutingVPCMStatusType.VPCMReviewCompleted.Id ||
                                VPIEHRoutingWorkflow?.Status == HBRoutingVPIEHStatusType.VPIEHReviewCompleted.Id ||
                                VPAERoutingWorkflow?.Status == HBRoutingVPAEStatusType.VPAEReviewCompleted.Id
                            );
                }
            }

            internal bool IsExectionSeniorManagementApprovalComplete
            {
                get
                {
                    return LegalExecutionWorkflow?.Status == HBExecutionPackageLegalStatusType.ExecutionPackageLegalApproved.Id &&
                            VPCPExecutionWorkflow?.Status == HBExecutionPackageVPCPStatusType.ExecutionPackageVPCPApproved.Id &&
                            EVPExecutionWorkflow?.Status == HBExecutionPackageEVPStatusType.ExecutionPackageEVPApproved.Id;
                }
            }

            //Is Vetting Approved...
            internal bool AllVettingApproved { get { return BidBondVettingApproved && FinancialVettingApproved && PrimeVettingApproved;  }  }
            internal bool PrimeVettingApproved { get { return PrimeVettingWorkflow?.Status == HBPreAwardVettingPrimeStatusType.AwardVettingApproved.Id; } }
            internal bool BidBondVettingApproved { get { return BidBondVettingWorkflow?.Status == HBPreAwardVettingBidBondStatusType.AwardVettingFinished.Id; } }
            internal bool FinancialVettingApproved { get { return FinancialVettingWorkflow?.Status == HBPreAwardVettingFinancialStatusType.AwardVettingFinished.Id; } }
            internal bool Rs1Approved { get { return Rs1Workflow?.Status == ProjectRS1VettingStatusType.RS1VettingFinished.Id; } }
            internal bool BafoApproved { get { return (BafoWorkflow?.Status.In( HBBidderBafoStatusType.BAFOApproved.Id ,
                                                                                HBBidderBafoStatusType.BAFOAccepted.Id,
                                                                                HBBidderBafoStatusType.BAFONotReceivedProceedWithAward.Id,
                                                                                HBBidderBafoStatusType.BAFOProceedWithoutInfo)).ToBool(); } } 
            public bool BafoNotNecessary { get { return BafoWorkflow?.Status == HBBidderBafoStatusType.BAFONotRequested.Id; } } 

            //Is Vetting Remediated ...
            internal bool PrimeVettingRemediated { get { return PrimeVettingWorkflow?.Status == HBPreAwardVettingPrimeStatusType.AwardVettingDisapproved.Id; } }
            internal bool BidBondVettingRemediated { get { return BidBondVettingWorkflow?.Status == HBPreAwardVettingBidBondStatusType.PendingBidBondRemediation.Id; } }
            internal bool FinancialVettingRemediated { get { return FinancialVettingWorkflow?.Status == HBPreAwardVettingFinancialStatusType.PendingFinancialRemediation.Id; } }
            internal bool Rs1Remediated { get { return Rs1Workflow?.Status == ProjectRS1VettingStatusType.RS1VettingRemediate.Id; } }
            

            //Is Prew Award Vetting - Director Review a Valid menu to show in Action
            public bool IsPrimeVettingInDirectorReviewStatus { get { return PrimeVettingWorkflow?.Status == HBPreAwardVettingPrimeStatusType.PendingVettingDirectorReview.Id; } }
            public bool IsBidBondVettingInDirectorReviewStatus { get { return BidBondVettingWorkflow?.Status == HBPreAwardVettingBidBondStatusType.PendingVettingDirectorReview.Id; } }
            public bool IsFinancialVettingInDirectorReviewStatus { get { return FinancialVettingWorkflow?.Status == HBPreAwardVettingFinancialStatusType.PendingVettingDirectorReview.Id; } }

            public bool IsPrimeVettingReadyOnAction()
            {
                if (IsPrimeVettingInDirectorReviewStatus )
                {
                    return (BidBondVettingWorkflow?.Status.In(HBPreAwardVettingBidBondStatusType.AwardVettingFinished.Id,
                                                       HBPreAwardVettingBidBondStatusType.PendingVettingDirectorReview.Id)).ToBool() &&
                           (FinancialVettingWorkflow?.Status.In(HBPreAwardVettingFinancialStatusType.AwardVettingFinished.Id, 
                                                         HBPreAwardVettingFinancialStatusType.PendingVettingDirectorReview.Id)).ToBool();
                }
                return true;
            }

            public bool IsBidBondVettingReadyOnAction()
            {
                if (IsBidBondVettingInDirectorReviewStatus)
                {
                    return (PrimeVettingWorkflow?.Status.In(HBPreAwardVettingPrimeStatusType.AwardVettingFinished.Id,
                                                       HBPreAwardVettingPrimeStatusType.PendingVettingDirectorReview.Id)).ToBool() &&
                           (FinancialVettingWorkflow?.Status.In(HBPreAwardVettingFinancialStatusType.AwardVettingFinished.Id,
                                                         HBPreAwardVettingFinancialStatusType.PendingVettingDirectorReview.Id)).ToBool();
                }
                return true;
            }

            public bool IsFinancialVettingReadyOnAction()
            {
                if (IsFinancialVettingInDirectorReviewStatus)
                {
                    return (BidBondVettingWorkflow?.Status.In(HBPreAwardVettingBidBondStatusType.AwardVettingFinished.Id,
                                                       HBPreAwardVettingBidBondStatusType.PendingVettingDirectorReview.Id)).ToBool() &&
                           (PrimeVettingWorkflow?.Status.In(HBPreAwardVettingPrimeStatusType.AwardVettingFinished.Id,
                                                         HBPreAwardVettingPrimeStatusType.PendingVettingDirectorReview.Id)).ToBool();
                }
                return true;
            }

            public bool IsInPendingSelectNextBidderSelection()
            {
                return ( 
                        //(BafoWorkflow?.Status.In(HBBidderBafoStatusType.PendingNextRankedBidderSelection)).ToBool()                                 ||
                        (PrimeVettingWorkflow?.Status.In(HBPreAwardVettingPrimeStatusType.PendingNextRankedBidderSelection)).ToBool()               ||
                        (BidBondVettingWorkflow?.Status.In(HBPreAwardVettingBidBondStatusType.PendingNextRankedBidderSelection)).ToBool()           ||
                        (FinancialVettingWorkflow?.Status.In(HBPreAwardVettingFinancialStatusType.PendingNextRankedBidderSelection)).ToBool()       ||
                        
                        //For VPCM, VPIEH, VPAE, OIG, staus remains on Disapproval/Issues and From Action Menu "Pending Next Bidder" is selected.
                        (VPCMRoutingWorkflow?.Status.In(HBRoutingVPCMStatusType.VPCMDisapproval)).ToBool()                                          ||
                        (VPIEHRoutingWorkflow?.Status.In(HBRoutingVPIEHStatusType.VPIEHDisapproval)).ToBool()                                       ||
                        (VPAERoutingWorkflow?.Status.In(HBRoutingVPAEStatusType.VPAEDisapproval)).ToBool()                                          ||
                        
                        (OIGRoutingWorkflow?.Status.In(HBRoutingOIGStatusType.OIGBidderIssues)).ToBool()                       
                       );
            }

            public bool IsRoutingFinancialUnderBudgetOnHold()
            {
                return (FINRoutingWorkflow?.Status.In(HBRoutingFinanceStatusType.BudgetTeamOnHold)).ToBool();
            }

            public bool IsRoutingFinancialUnderOperationBudgetOnHold()
            {
                return (FINRoutingWorkflow?.Status.In(HBRoutingFinanceStatusType.OperatingBudgetTeamOnHold)).ToBool();
            }

            public bool IsExistsExecutionSeniorManagementWorkflows()
            {
                return this.LegalExecutionWorkflow != null; //Checking one of the workflow between Legal/VPCP/EVP is enough
            }

            private void SetChildren(ProjectBidderWorkflowCollection workflows)
            {
                _workflows = workflows;

                var _wflows = _workflows?.Cast<ProjectBidderWorkflow>();
                //Current workflow.
                CurrentWorkflow = _wflows.FirstOrDefault(w => w.WorkflowType == ProjectBidderWorkflowExec.workflowType);

                _wflows.ForEach( (wf, idx) => { 
                
                    switch(wf.WorkflowType)
                    {
                        //Vetting
                        case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_PRIME:                   PrimeVettingWorkflow = wf; break;
                        case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_BIDBOND:                 BidBondVettingWorkflow = wf; break;
                        case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_FINANCIAL:               FinancialVettingWorkflow = wf; break;
                        case ConstantUtility.WORKFLOW_HB_RS1_VETTING:                               Rs1Workflow = wf; break;
                        case ConstantUtility.WORKFLOW_HB_BAFO:                                      BafoWorkflow = wf; break;

                        //Routing
                        case ConstantUtility.WORKFLOW_HB_ROUTING_PACKAGE:                           PackageRoutingWorkflow = wf; break;
                        case ConstantUtility.WORKFLOW_HB_ROUTING_CQU:                               CQURoutingWorkflow = wf; break;
                        case ConstantUtility.WORKFLOW_HB_ROUTING_VPCM:                              VPCMRoutingWorkflow = wf; break;
                        case ConstantUtility.WORKFLOW_HB_ROUTING_VPIEH:                             VPIEHRoutingWorkflow = wf; break;
                        case ConstantUtility.WORKFLOW_HB_ROUTING_VPAE:                              VPAERoutingWorkflow = wf; break;
                        case ConstantUtility.WORKFLOW_HB_ROUTING_FINANCE:                           FINRoutingWorkflow = wf; break;
                        case ConstantUtility.WORKFLOW_HB_ROUTING_OIG:                               OIGRoutingWorkflow = wf; break;

                        //Execution
                        case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE:                         PackageExecutionWorkflow = wf; break;
                        case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_LEGAL:                   LegalExecutionWorkflow = wf; break;
                        case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_VPCP:                    VPCPExecutionWorkflow = wf; break;
                        case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_EVP:                     EVPExecutionWorkflow = wf; break;                        
                    }
                
                });                
            }
        }

        #endregion
    }
    
}
