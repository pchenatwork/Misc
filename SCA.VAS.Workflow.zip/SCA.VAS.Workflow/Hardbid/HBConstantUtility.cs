﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCA.VAS.Workflow
{
    #region ConstantUtility
    public partial class ConstantUtility
    {
        public const string WORKFLOW_HB_GENERAL = "Hardbid General Workflow";
        public const string WORKFLOW_HB_BID_DOCUMENT_REPRODUCTION = "Hardbid Bid Document Reproduction Workflow";
        public const string WORKFLOW_HB_RFI_SUBMISSION_PROCESSING = "Hardbid RFI Submission / Processing Workflow";
        public const string WORKFLOW_HB_ADDENDUM = "Hardbid Addendum Workflow";
        public const string WORKFLOW_HB_BID_RECORDING = "Hardbid Bid Recording Workflow";

        public const string WORKFLOW_HB_BAFO = "Hardbid BAFO Analysis Workflow";     /*In BA it is:- New Bid Breakdown Analysis Workflow*/
        public const string WORKFLOW_HB_PRE_AWARD_VETTING_PRIME = "Hardbid Pre-Award Vetting Prime Workflow";
        public const string WORKFLOW_HB_PRE_AWARD_VETTING_BIDBOND = "Hardbid Pre-Award Vetting Bid Bond Workflow";
        public const string WORKFLOW_HB_PRE_AWARD_VETTING_FINANCIAL = "Hardbid Pre-Award Vetting Financial Workflow";

        public const string WORKFLOW_HB_RS1_VETTING = "Hardbid RS1 Vetting";
        public const string WORKFLOW_HB_RS1_SUBCONTRACTOR = "Hardbid RS1 Subcontractor Workflow";

        public const string WORKFLOW_HB_ROUTING_PACKAGE = "Hardbid Routing Package Workflow";
        public const string WORKFLOW_HB_ROUTING_OIG = "Hardbid Routing to OIG Workflow";                
        public const string WORKFLOW_HB_ROUTING_CQU = "Hardbid Routing to Pre-qualification Workflow";
        public const string WORKFLOW_HB_ROUTING_VPCM = "Hardbid Routing to VP of CM Workflow";
        public const string WORKFLOW_HB_ROUTING_VPIEH = "Hardbid Routing to VP of IEH Workflow";
        public const string WORKFLOW_HB_ROUTING_VPAE = "Hardbid Routing to VP of A&E Workflow";
        public const string WORKFLOW_HB_ROUTING_FINANCE = "Hardbid Routing to Finance Workflow";

        //public const string WORKFLOW_HB_BID_REPRODUCTION_ORDER = "Hardbid Reproduction Order Workflow";
        //public const string WORKFLOW_HB_BID_REPRODUCTION_ORDER_SUPPLIER = "Hardbid Reproduction Order Supplier Workflow";

        public const string WORKFLOW_HB_EXECUTION_PACKAGE = "Hardbid Execution Package Workflow";
        public const string WORKFLOW_HB_EXECUTION_PACKAGE_LEGAL = "Hardbid Legal Execution Package Workflow";
        public const string WORKFLOW_HB_EXECUTION_PACKAGE_VPCP = "Hardbid VPCP Execution Package Workflow";
        public const string WORKFLOW_HB_EXECUTION_PACKAGE_EVP = "Hardbid EVP Execution Package Workflow";


        public const string JMTYPE_JOC = "JOC";
        public const string JMTYPE_ASB = "Asbestos";
        public const string JMTYPE_SWB = "Sidewalk Bridging";
        public const string JMTYPE_SRD = "Soil Boring Rock Drilling";
        /// <summary>
        /// Non Workflow Constants
        /// </summary>

        public const string HB_ROLE_DESIGN_SPECIALIST = "Design Specialist";
        public const string HB_FIND_BY_PROJECT = "FindBidder";

        //Appconfigurations
        public const string HB_UPLOADDOC_PHASINGEXHIBIT_RESTRICTED_FILETYPES = "UploadDocPhasingExhibitRestrictedFileTypes";


        //Email Templates
        public const string HB_BP_ADVAGENCIES_IFBISSUED_EMAIL_TEMPLATE = "HB_BP_ADVAGENCIES_IFBISSUED";
        public const string HB_BP_LLVENDORS_IFBISSUED_EMAIL_TEMPLATE = "HB_BP_LLVENDORS_IFBISSUED";
    }
    #endregion ConstantUtility
}
