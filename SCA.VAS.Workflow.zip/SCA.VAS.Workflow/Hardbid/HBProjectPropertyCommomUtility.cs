﻿using SCA.VAS.BusinessLogic.Hb;
using SCA.VAS.BusinessLogic.Hb.Utilities;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Hb;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI;

namespace SCA.VAS.Workflow
{
    public partial class CommonUtility
    {
        

    }
}
