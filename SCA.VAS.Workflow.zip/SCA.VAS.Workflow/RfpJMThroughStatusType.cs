using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of RfpJMSubmissionStatusType:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(RfpJMThroughStatusConverter))]
    public class RfpJMThroughStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly RfpJMThroughStatusType NewTierThrough = new RfpJMThroughStatusType(1, "NewTierThrough", "New Tier Through");
        public static readonly RfpJMThroughStatusType Tier2Created = new RfpJMThroughStatusType(2, "Tier2Created", "Tier2 Created");
        public static readonly RfpJMThroughStatusType Tier2Approved = new RfpJMThroughStatusType(3, "Tier2Approved", "Tier2 Approved");
        public static readonly RfpJMThroughStatusType Tier2Rejected = new RfpJMThroughStatusType(4, "Tier2Rejected", "Tier2 Rejected");
        public static readonly RfpJMThroughStatusType Tier2Finished = new RfpJMThroughStatusType(5, "Tier2Finished", "Tier2 Finished");

        public static readonly RfpJMThroughStatusType Tier4Created = new RfpJMThroughStatusType(6, "Tier4Created", "Tier4 Created");
        public static readonly RfpJMThroughStatusType Tier4Approved = new RfpJMThroughStatusType(7, "Tier4Approved", "Tier4 Approved");
        public static readonly RfpJMThroughStatusType Tier4Rejected = new RfpJMThroughStatusType(8, "Tier4Rejected", "Tier4 Rejected");
        public static readonly RfpJMThroughStatusType Tier4Finished = new RfpJMThroughStatusType(9, "Tier4Finished", "Tier4 Finished");

        #endregion

        #region Constructors
        public RfpJMThroughStatusType()
        {
        }

        private RfpJMThroughStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in PlanSubcontractorStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of PlanSubcontractorStatus.  
        /// </summary>
        public static RfpJMThroughStatusType Default
        {
            get
            {
                return (RfpJMThroughStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for RfpJMSubmissionStatusType class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((RfpJMThroughStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }

        public static bool IsFinal(int status)
        {
            if (status == 4 || status == 11) return true;
            else return false;
        }

        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a PlanSubcontractorStatus object.
        /// It allows a string to be assigned to a PlanSubcontractorStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator RfpJMThroughStatusType(int id)
        {
            return (RfpJMThroughStatusType)EnumerationBase.FindById(id, RfpJMThroughStatusType._list);
        }
        public static implicit operator RfpJMThroughStatusType(string name)
        {
            for (int i = 0; i < RfpJMThroughStatusType._list.Count; i++)
            {
                if (((RfpJMThroughStatusType)RfpJMThroughStatusType._list[i]).Description == name)
                    return (RfpJMThroughStatusType)RfpJMThroughStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and PlanSubcontractorStatus objects.
    /// It's very useful when binding PlanSubcontractorStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class RfpJMThroughStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, RfpJMThroughStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the PlanSubcontractorStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < RfpJMThroughStatusType._list.Count; i++)
            {
                list.Add(((RfpJMThroughStatusType)RfpJMThroughStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}