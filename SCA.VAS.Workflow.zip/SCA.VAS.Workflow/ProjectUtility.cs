﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Net.Mail;
using System.Configuration;

using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;
using System.Collections;
using SCA.VAS.Common.ValueObjects;
using System.Linq;

namespace SCA.VAS.Workflow
{
    #region ConstantUtility
    public partial class ConstantUtility
    {
        //public const string WORKFLOW_PROJECT_SOLICITATION = "Project Solicitation";
        public const string WORKFLOW_BID_AWARD_GENERAL = "Bid and Award General Workflow";
        //public const string WORKFLOW_SOLICITATION_PACKAGE = "Solicitation Package Workflow";
        //public const string WORKFLOW_BID_DOCUMENT_REVIEW_APPROVAL = "Bid Document Review/Approval Workflow";
        //public const string WORKFLOW_BID_ADVERTISEMENT = "Bid Advertisement Workflow";
        public const string WORKFLOW_BID_DOCUMENT_REPRODUCTION = "Bid Document Reproduction Workflow";
        public const string WORKFLOW_RFI_SUBMISSION_PROCESSING = "RFI Submission / Processing Workflow";
        public const string WORKFLOW_ADDENDUM = "Addendum Workflow";
        public const string WORKFLOW_BID_RECORDING = "Bid Recording Workflow";
        public const string WORKFLOW_PRE_AWARD_VETTING = "Pre-Award Vetting Workflow";
        //public const string WORKFLOW_PRE_AWARD_VETTING_BOND = "Pre-Award Vetting Bond Workflow";
        public const string WORKFLOW_PRE_AWARD_VETTING_BIDBOND_REVIEW = "Pre-Award Vetting Bid Bond Review Workflow";
        public const string WORKFLOW_PRE_AWARD_VETTING_FINANCIAL_REVIEW = "Pre-Award Vetting Financial Review Workflow";

        public const string WORKFLOW_PRE_AWARD_VETTING_MENTOR = "Pre-Award Vetting Mentor Workflow";
        public const string WORKFLOW_RS1_VETTING = "RS1 Vetting";
        public const string WORKFLOW_RS1_SUBCONTRACTOR= "RS1 Subcontractor Workflow";
        //public const string WORKFLOW_VENDOR_BID_BREAKDOWN = "Vendor Bid Breakdown Workflow";
        //public const string WORKFLOW_BID_BREAKDOWN_ANALYSIS = "Bid Breakdown Analysis Workflow";
        public const string WORKFLOW_BID_BREAKDOWN_ANALYSIS = "New Bid Breakdown Analysis Workflow";
        //public const string WORKFLOW_CONTRACT_PACKAGE_CREATION = "Contract Package Creation Workflow";
        //public const string WORKFLOW_ROUTING_PACKAGE_APPROVAL = "Routing Package Approval Workflow";
        public const string WORKFLOW_ROUTING_OIG = "Routing to OIG Workflow";
        public const string WORKFLOW_ROUTING_ADMIN = "Routing to Admin Workflow";
        public const string WORKFLOW_ROUTING_BDD = "Routing to BDD Workflow";
        public const string WORKFLOW_ROUTING_CQU = "Routing to Pre-qualification Workflow";
        public const string WORKFLOW_ROUTING_VPCM = "Routing to VP of CM Workflow";
        public const string WORKFLOW_ROUTING_FINANCE = "Routing to Finance Workflow";
        //public const string WORKFLOW_CONTRACT_EXECUTION = "Contract Execution Workflow";
        //public const string WORKFLOW_POST_EXECUTION = "Post Execution Workflow";

        public const string WORKFLOW_BID_MENTOR = "Bid and Award Mentor Workflow";
        public const string WORKFLOW_BID_MENTOR_FINANCE = "Bid and Award Mentor Finance Workflow";
        public const string WORKFLOW_BID_REPRODUCTION_ORDER = "Reproduction Order Workflow";
        public const string WORKFLOW_BID_REPRODUCTION_ORDER_SUPPLIER = "Reproduction Order Supplier Workflow";


        public const string WORKFLOW_EXECUTION_LEGAL_PKG = "Legal Execution Pkg Workflow";
        public const string WORKFLOW_EXECUTION_VPCP_PKG = "VP CP Execution Pkg Workflow";
        public const string WORKFLOW_EXECUTION_EVP_PKG = "EVP Execution Pkg Workflow";

        public const string WORKFLOW_RFP_JM_SUBMISSION = "RFP JM Submission Workflow";
        public const string WORKFLOW_RFP_JM_THROUGH = "RFP JM Through Workflow";

        public const string ROLE_DESIGN_SPECIALIST = "Design Specialist";
        public const string FIND_BY_PROJECT = "FindBidder";

        //Appconfigurations
        public const string UPLOADDOC_PHASINGEXHIBIT_RESTRICTED_FILETYPES = "UploadDocPhasingExhibitRestrictedFileTypes";
    }
    #endregion ConstantUtility

    public partial class CommonUtility
    {
        #region Pubulic Method
        public static string GetProjectStatusName(string workflowType, int statusint)
        {
            EnumerationBase status = GetProjectStatus(workflowType, statusint);
            if (status != null) return status.Description;
            return string.Empty;
        }

        public static int GetProjectStatusId(string workflowType, string statusstr)
        {
            EnumerationBase status = GetProjectStatus(workflowType, statusstr);
            if (status != null) return status.Id;
            return 0;
        }

        private static EnumerationBase GetProjectStatus(string workflowType, object status)
        {
            switch (workflowType)
            {
                case ConstantUtility.WORKFLOW_BID_AWARD_GENERAL:
                    ProjectBidAwardStatusType projectBidAwardStatus = status.ToString();
                    if (status is int) projectBidAwardStatus = (int)status;
                    return projectBidAwardStatus;
                case ConstantUtility.WORKFLOW_ADDENDUM:
                    ProjectAddendumStatusType projectAddendumStatusType = status.ToString();
                    if (status is int) projectAddendumStatusType = (int)status;
                    return projectAddendumStatusType;
                case ConstantUtility.WORKFLOW_RFI_SUBMISSION_PROCESSING:
                    ProjectRfiSubmissionStatusType projectRfiSubmissionStatusType = status.ToString();
                    if (status is int) projectRfiSubmissionStatusType = (int)status;
                    return projectRfiSubmissionStatusType;
                case ConstantUtility.WORKFLOW_BID_BREAKDOWN_ANALYSIS:
                    ProjectBidBreakdownAnalysisStatusType projectBidBreakdownAnalysisStatusType = status.ToString();
                    if (status is int) projectBidBreakdownAnalysisStatusType = (int)status;
                    return projectBidBreakdownAnalysisStatusType;
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING:
                    ProjectPreAwardVettingStatusType projectPreAwardVettingStatusType = status.ToString();
                    if (status is int) projectPreAwardVettingStatusType = (int)status;
                    return projectPreAwardVettingStatusType;
                //case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_BOND:
                //    ProjectPreAwardVettingBondStatusType projectPreAwardVettingBondStatusType = status.ToString();
                //    if (status is int) projectPreAwardVettingBondStatusType = (int)status;
                //    return projectPreAwardVettingBondStatusType;
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_BIDBOND_REVIEW:
                    ProjectPreAwardVettingBidBondReviewStatusType projectPreAwardVettingBidBondReviewStatusType = status.ToString();
                    if (status is int) projectPreAwardVettingBidBondReviewStatusType = (int)status;
                    return projectPreAwardVettingBidBondReviewStatusType;
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_FINANCIAL_REVIEW:
                    ProjectPreAwardVettingFinancialReviewStatusType projectPreAwardVettingFinancialReviewStatusType = status.ToString();
                    if (status is int) projectPreAwardVettingFinancialReviewStatusType = (int)status;
                    return projectPreAwardVettingFinancialReviewStatusType;
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_MENTOR:
                    ProjectPreAwardVettingMentorStatusType projectPreAwardVettingMentorStatusType = status.ToString();
                    if (status is int) projectPreAwardVettingMentorStatusType = (int)status;
                    return projectPreAwardVettingMentorStatusType;
                case ConstantUtility.WORKFLOW_ROUTING_OIG:
                    ProjectRoutingOIGStatusType projectRoutingOIGStatusType = status.ToString();
                    if (status is int) projectRoutingOIGStatusType = (int)status;
                    return projectRoutingOIGStatusType;
                case ConstantUtility.WORKFLOW_ROUTING_FINANCE:
                    ProjectRoutingFinanceStatusType projectRoutingFinanceStatusType = status.ToString();
                    if (status is int) projectRoutingFinanceStatusType = (int)status;
                    return projectRoutingFinanceStatusType;
                case ConstantUtility.WORKFLOW_ROUTING_CQU:
                    ProjectRoutingCQUStatusType projectRoutingCQUStatusType = status.ToString();
                    if (status is int) projectRoutingCQUStatusType = (int)status;
                    return projectRoutingCQUStatusType;
                case ConstantUtility.WORKFLOW_ROUTING_VPCM:
                    ProjectRoutingVPCMStatusType projectRoutingVPCMStatusType = status.ToString();
                    if (status is int) projectRoutingVPCMStatusType = (int)status;
                    return projectRoutingVPCMStatusType;
                case ConstantUtility.WORKFLOW_ROUTING_BDD:
                    ProjectRoutingBDDStatusType projectRoutingBDDStatusType = status.ToString();
                    if (status is int) projectRoutingBDDStatusType = (int)status;
                    return projectRoutingBDDStatusType;
                case ConstantUtility.WORKFLOW_ROUTING_ADMIN:
                    ProjectRoutingAdminStatusType projectRoutingAdminStatusType = status.ToString();
                    if (status is int) projectRoutingAdminStatusType = (int)status;
                    return projectRoutingAdminStatusType;
                case ConstantUtility.WORKFLOW_BID_DOCUMENT_REPRODUCTION:
                    ProjectBidDocumentReproductionStatusType projectBidDocumentReproductionStatusType = status.ToString();
                    if (status is int) projectBidDocumentReproductionStatusType = (int)status;
                    return projectBidDocumentReproductionStatusType;
                case ConstantUtility.WORKFLOW_BID_MENTOR:
                    ProjectBidMentorStatusType projectBidMentorStatusType = status.ToString();
                    if (status is int) projectBidMentorStatusType = (int)status;
                    return projectBidMentorStatusType;
                case ConstantUtility.WORKFLOW_BID_MENTOR_FINANCE:
                    ProjectBidMentorFinanceStatusType projectBidMentorFinanceStatusType = status.ToString();
                    if (status is int) projectBidMentorFinanceStatusType = (int)status;
                    return projectBidMentorFinanceStatusType;
                case ConstantUtility.WORKFLOW_RS1_VETTING:
                    ProjectRS1VettingStatusType projectRS1VettingStatusType = status.ToString();
                    if (status is int) projectRS1VettingStatusType = (int)status;
                    return projectRS1VettingStatusType;
            }
            return null;
        }
        #endregion Pubulic Method

        #region Email Method
        public static void ProjectSendEmail(Project project, WorkflowNode node, WorkflowHistory workflowHistory,
            string emailMessageName, string comments, string prefixDbName)
        {
            EmailMessage emailmessage = EmailMessageUtility.GetByName(ConstantUtility.COMMON_DATASOURCE_NAME, emailMessageName);
            if (emailmessage == null) return;

            Supplier supplier = SupplierUtility.Get(prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME, project.AwardSupplierId);
            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "Supplier", supplier == null ? "0" : supplier.Id.ToString());
            User user = UserUtility.Get(prefixDbName + ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

            EmailMessage newMessage = EmailReplaceRelatedUsers(emailmessage, project);

            switch (emailmessage.Objects)
            {
                case "Node Users":
                    if (node != null)
                    {
                        WorkflowNodeCollection workflownodes = new WorkflowNodeCollection();
                        workflownodes.Add(node);
                        string nodes = XmlUtility.ToXml(workflownodes);
                        UserCollection users = UserUtility.FindByCriteria(ConstantUtility.USER_DATASOURCE_NAME,UserManager.FIND_USER_BY_WORKFLOWNODES,
                                                                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                            {
                                SendEmail(emailmessage, users[i],
                                    new object[] { project, users[i], supplier, vendor },
                                    comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "Project", project.Id);
                            }
                        }
                    }
                    break;
                case "Authorized Users":
                    {
                        string nodes = XmlUtility.ToXml(workflowHistory.NextLinks);
                        UserCollection users = UserUtility.FindByCriteria(
                            ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_WORKFLOWNODES,
                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                            {
                                SendEmail(emailmessage, users[i],
                                    new object[] { project, users[i], supplier, vendor },
                                    comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "Project", project.Id);
                            }
                        }
                    }
                    break;

                case "Users":
                    {
                        SendEmail(emailmessage, user,
                            new object[] { project, user, supplier, vendor }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Project", project.Id);
                    }
                    break;

                case "Bidders":
                    {
                        BidderCollection bidders = BidderUtility.FindByCriteria(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                            BidderManager.FIND_BY_PROJECT, new object[] { project.Id });

                        if (bidders != null && bidders.Count > 0)
                        {
                            foreach (Bidder bidder in bidders)
                            {
                                supplier = SupplierUtility.Get(prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME, bidder.SupplierId);
                                vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "Supplier", supplier.Id.ToString());

                                //Email with Attachment 
                                SendEmail(emailmessage, supplier,
                                    new object[] { project, user, bidder, supplier, vendor }, comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "Project", project.Id, GetEmailAttatchments(emailmessage, project, bidder, supplier));
                            }
                        }

                    }
                    break;

                default:
                    {
                        SendEmail(emailmessage, null,
                            new object[] { project, user, supplier, vendor }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Project", project.Id);
                    }
                    break;
            }
        }

        public static object[] GetEmailAttatchments(EmailMessage emailmessage, Project project, Bidder bidder, Supplier supplier)
        {
            string downloadPath = ConfigurationManager.AppSettings["DownloadPath"];
            switch (emailmessage.Name)
            {
                case "BA_INVITATION_TO_BID_LETTER":
                    Attachment pickupTicket = new Attachment(Path.Combine(downloadPath,
                        "PickupTicket_" + project.Id + "_" + bidder.SupplierId + ".pdf"));
                    return new object[] { pickupTicket };
            }
            return null;
        }

        /// <summary>
        /// Get settings from current project "~\Data\Settings\{fileName.xml}". 
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static SettingCollection GetSettingsFromProjectData(string fileName)
        {
            //string path = HttpContext.Current.Server.MapPath(null);
            string path = HttpContext.Current.Server.MapPath("~");
            string xmlFileName = Path.Combine(Path.Combine(Path.Combine(path, "Data"), "Settings"), Path.GetFileName(fileName));
            string s = ReadFile(xmlFileName);
            return (SettingCollection)XmlUtility.Deserialize(s, typeof(SettingCollection));
        }

        public static EmailMessage EmailReplaceRelatedUsers(EmailMessage emailmessage, Bidder bidder)
        {
            if (emailmessage == null || bidder == null) return null;
            Hashtable RelatedUsers = new Hashtable();
            RelatedUsers.Add("$REJECTEDBIDDER$", bidder == null ? "" : bidder.SupplierName);
            emailmessage.FromEmail = ReplaceRelatedUsers(emailmessage.FromEmail, RelatedUsers);
            emailmessage.FromName = ReplaceRelatedUsers(emailmessage.FromName, RelatedUsers);
            emailmessage.ToEmail = ReplaceRelatedUsers(emailmessage.ToEmail, RelatedUsers);
            emailmessage.ToName = ReplaceRelatedUsers(emailmessage.ToName, RelatedUsers);
            emailmessage.CcEmail = ReplaceRelatedUsers(emailmessage.CcEmail, RelatedUsers);
            emailmessage.BccEmail = ReplaceRelatedUsers(emailmessage.BccEmail, RelatedUsers);
            emailmessage.Subject = ReplaceRelatedUsers(emailmessage.Subject, RelatedUsers);
            emailmessage.Body = ReplaceRelatedUsers(emailmessage.Body, RelatedUsers);

            return emailmessage;
        }
        public static EmailMessage EmailReplaceRelatedUsers(EmailMessage emailmessage, Project project, Bidder multiContractBidder = null)
        {
            if (emailmessage == null || project == null) return null;

            Hashtable RelatedUsers = new Hashtable();

            if (project.MultiContract)
            {
                RelatedUsers.Add("$PROJECTLISTLINK$", "<a href=\"$INTERNALSITEURL$/Hardbid/HBProject_List.aspx?Id=" + project.Id.ToString() + "\">Here</a>");
                RelatedUsers.Add("$PROJECTVETTINGLISTLINK$", "<a href=\"$INTERNALSITEURL$/Hardbid/HBBidder_List.aspx?Id=" + project.Id.ToString() + "\">Here</a>");
            }
            else
            {
                RelatedUsers.Add("$PROJECTLISTLINK$", "<a href=\"$INTERNALSITEURL$/Rfc/Project_List.aspx?Id=" + project.Id.ToString() + "\">$INTERNALSITEURL$/Rfc/Project_List.aspx?Id=" + project.Id.ToString() + "</a>");
                RelatedUsers.Add("$PROJECTVETTINGLISTLINK$", "<a href=\"$INTERNALSITEURL$/Rfc/Vetting_Request_List.aspx?Id=" + project.Id.ToString() + "\">$INTERNALSITEURL$/Rfc/Vetting_Request_List.aspx?Id=" + project.Id.ToString() + "</a>");
            }

            var _duration = (project.MultiContract ? (int)project.KeyItems.Duration * 365 : project.ProjectDuration) .ToString();

            RelatedUsers.Add("$PROJECTTYPE$", project.Type);
            RelatedUsers.Add("$SOLICITATIONNO$", project.SolicitationNo + "-" + project.SolicitSeq.ToString());
            RelatedUsers.Add("$PROJECTDESCRIPTION$", project.Description);
            RelatedUsers.Add("$PROJECTDESIGNNO$", project.DesignNo);
            RelatedUsers.Add("$PROJECTCONTRACTNO$", project.ContractNo);
            RelatedUsers.Add("$PREBIDMEETINGLOC$", project.PreBidMeetingLoc);
            RelatedUsers.Add("$PROJECTCOSTESTAMT$", project.CostEstAmt.ToString("c"));
            RelatedUsers.Add("$PROJECTREVCOSTESTAMT$", project.RevisedCostEstAmt.ToString("c"));
            RelatedUsers.Add("$PROJECTCOSTAMT$", project.CostAmt.ToString("c"));
            RelatedUsers.Add("$SOLICITPKGRCVDDATE$", project.SolicitPkgRcvdDate.ToShortDateString());
            RelatedUsers.Add("$PERFORMANCEPERIOD$", _duration);
            RelatedUsers.Add("$PROJECTRANGE$", "$" + project.AdsMinAmt.ToString() + " - " + "$" + project.AdsMaxAmt.ToString());
            RelatedUsers.Add("$CONTRACTDOCSPRICE$", "$" + project.DocsPrice.ToString());
            RelatedUsers.Add("$DOCSAVAILABLE$", project.DocsAvailableDate.ToString());
            RelatedUsers.Add("$PREBIDDATE$", project.PreBidMeetingDateTime.Date.ToShortDateString());
            RelatedUsers.Add("$PREBIDTIME$", project.PreBidMeetingDateTime.ToShortTimeString());
            RelatedUsers.Add("$WORKFLOWCOMMENTS$", project.Comments);
            RelatedUsers.Add("$JMTYPE$", project.JmType);

            string clickhereLink = string.Empty;
            if (project.MultiContract)
                clickhereLink = @"<a Disabled='disabled' href=" + "\"" + ConfigurationManager.AppSettings["InternalSiteUrl"].ToString() + "/Dashboard/REQ_Dashboard.aspx" + "\"" + ">" + " here </a>";
            else
                clickhereLink = @"<a href=" + "\"" + ConfigurationManager.AppSettings["InternalSiteUrl"].ToString() + "/Dashboard/CAU_Dashboard.aspx" + "\"" + ">" + " here </a>";
            RelatedUsers.Add("$HERE$", clickhereLink);

            string addressInfo = "";
            string boroughName = "";
            ConstantUtility.Boroughs.TryGetValue(project.Boro, out boroughName);
            addressInfo = project.AddressLine1 + ",\r\n" + project.AddressLine2 + ",\r\n" + boroughName + ",\r\n" +
                            project.City + ",\r\n" + project.State + ",\r\n" + project.ZipCode ;
            RelatedUsers.Add("$ADDRESS$", addressInfo);

            RelatedUsers.Add("$BID_ROOM$", project.Room);

            if (project.Schools != null && project.Schools.Count > 0)
                RelatedUsers.Add("$SCHOOL$", project.Schools?[0].OrgName);

            string cmFirmName = "";
            SettingCollection settings = CommonUtility.GetSettings("MentorCMFirms.xml");
            foreach (Setting setting in settings)
            {
                if (project.CMRep == setting.Value)
                {
                    cmFirmName = setting.Name;
                    break;
                }
            }
            RelatedUsers.Add("$CMFIRMNAME$", cmFirmName);

            DateTime openingDate = project.PlanedBidOpeningDateTime;

            if (project.RevisedBidOpeningDateTime != new DateTime(1900, 1, 1))
            {
                openingDate = project.RevisedBidOpeningDateTime;
            }
            if (project.ActualBidOpeningDateTime != new DateTime(1900, 1, 1))
            {
                openingDate = project.ActualBidOpeningDateTime;
            }

            RelatedUsers.Add("$BIDOPENINGDATE$", openingDate.Date.ToShortDateString());
            RelatedUsers.Add("$BIDOPENINGTIME$", openingDate.ToShortTimeString());
            RelatedUsers.Add("$IFBDATE$", project.IFBDate.ToString());

            RelatedUsers.Add("$DRAWINGCOMMENTS$", project.DrawingComments);
            RelatedUsers.Add("$S01010COMMENTS$", project.S01010Comments);
            RelatedUsers.Add("$S01500COMMENTS$", project.S01500Comments);
            RelatedUsers.Add("$S01900COMMENTS$", project.S01900Comments);
            RelatedUsers.Add("$FIDCOMMENTS$", project.FIDComments);
            RelatedUsers.Add("$OTHERCOMMENTS$", project.Comments);

            ProjectPropertyCollection projectProperties = ProjectPropertyUtility.FindByCriteria(
            ConstantUtility.RFD_DATASOURCE_NAME,
            ProjectPropertyManager.FIND_BY_PROJECT,
            new object[] { project.Id });

            User reviewer = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, GetProjectProperty("property45", projectProperties).PropertyText);
            RelatedUsers.Add("$CQUREVIEWER$", (reviewer == null) ? "" : reviewer.FullName);
            RelatedUsers.Add("$CQUREVIEWERNAME$", (reviewer == null) ? "" : reviewer.FullName);
            RelatedUsers.Add("$CQUREVIEWERPHONE$", (reviewer == null) ? "" : reviewer.Phone);
            RelatedUsers.Add("$CQUREVIEWEREMAIL$", (reviewer == null) ? "" : reviewer.Email);
            RelatedUsers.Add("$CQUREVIEWERTITLE$", (reviewer == null) ? "" : reviewer.Title);

            User contractSpecialist = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, project.ContractSpecialist);
            RelatedUsers.Add("$CONTSPECEMAIL$", contractSpecialist == null ? "" : contractSpecialist.Email);
            RelatedUsers.Add("$CONTSPECNAME$", contractSpecialist == null ? "" : contractSpecialist.Name);
            RelatedUsers.Add("$CONTSPECPHONE$", contractSpecialist == null ? "" : contractSpecialist.Phone);
            RelatedUsers.Add("$CONTSPECFAX$", contractSpecialist == null ? "" : contractSpecialist.Fax);

            Rfc rfc = RfcUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, project.RfcId);
            RelatedUsers.Add("$LIQUIDATEDDAMAGES$", rfc == null ? "" : rfc.LiquidDamagesAmt.ToString("c"));

            //inprogress
             ProjectBAFOCollection bAFOCollection = ProjectBAFOUtility.FindByCriteria
                                                    (
                                                        ConstantUtility.RFD_DATASOURCE_NAME, 
                                                        ProjectBAFOManager.FIND_BY_PROJECT,
                                                        new object[] { project.Id }
                                                    );

            ProjectBAFO ProjBafo = bAFOCollection?.Count > 0 ? bAFOCollection[0] : null;

            if (ProjBafo != null)
            {
                if (ProjBafo.IsFinal == "Y")
                {
                    RelatedUsers.Add("$BAFODECISION$", "Approved");
                }
                else
                {
                    RelatedUsers.Add("$BAFODECISION$", "Rejected");
                }
            }
            //end

            // on the bid break down analysis, the status of the decision is 
            //stored into the projet statusname field.
            RelatedUsers.Add("$BRKDOWNDECISION$", project.StatusName);

            // This is current date when the user submits that triggers
            // Two emails 1. award notice with attachment 
            // 2. contract award date for template: BA_CONTRACT_EXECUTION_SCA
            RelatedUsers.Add("$CONTRACTAWARDEDDATE$", DateTime.Today.ToShortDateString());

            // BA_PROJECT_CANCELLED  email template is used
            RelatedUsers.Add("$AWARDAMT$",  project.CostEstAmt.ToString("c"));

            string ProjectCancelReason = CommonUtility.GetProjectProperty(130, projectProperties)?.PropertyText;
           
            if (ProjectCancelReason != null)
            {
                ProjectCancelReasonCollection projectCancelReasons = ProjectCancelReasonUtility.FindByCriteria(
                ConstantUtility.RFD_DATASOURCE_NAME, ProjectCancelReasonManager.FIND, new object[] { });
                var CancelReasonDescription = projectCancelReasons?.ToList().Where(x => x.C_REASON_CODE == ProjectCancelReason)?.FirstOrDefault()?.C_REASON_DESC;
                RelatedUsers.Add("$CANCEL_REASON$", CancelReasonDescription != null ? CancelReasonDescription.ToString() : "");
            }

            string ProjectCancelComments = CommonUtility.GetProjectProperty(131, projectProperties)?.PropertyText;
            RelatedUsers.Add("$WFCOMMENTS_CANCEL$", ProjectCancelComments != null ? ProjectCancelComments.ToString() : "");

            //END

            string Breakdowncomments = CommonUtility.GetProjectProperty(13, projectProperties)?.PropertyText;
            RelatedUsers.Add("$COMMENTS$", Breakdowncomments != null ? Breakdowncomments.ToString() : "");

            //fetch design manager 
            
            var  rfcBid = RfcUtility.GetByNumber(ConstantUtility.RFD_DATASOURCE_NAME, project.TransNumber, "Bid");

            RelatedUsers.Add("$DMEMAIL$", rfcBid?.DMEmail ?? "");
            RelatedUsers.Add("$DMNAME$", rfcBid?.DMName ?? "");

            RelatedUsers.Add("$DPMEMAIL$", rfcBid?.DPMEmail ?? "");
            RelatedUsers.Add("$DPMNAME$", rfcBid?.DPMName ?? "");
            
            RelatedUsers.Add("$POEMAIL$", rfcBid?.POEmail ?? "");
            RelatedUsers.Add("$PONAME$", rfcBid?.POName ?? "");

            RelatedUsers.Add("$SPOEMAIL$", rfcBid?.SPOEmail ?? "");
            RelatedUsers.Add("$SPONAME$", rfcBid?.SPOName ?? "");

            RelatedUsers.Add("$CPOEMAIL$", rfcBid?.CPOEmail ?? "");
            RelatedUsers.Add("$CPONAME$", rfcBid?.CPOName ?? "");

            Dictionary<string, string> emailDetails = GetEmailIdNamesForRole("Contract Specialist");
            RelatedUsers.Add("$ALL_CS$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CAU Manager");
            RelatedUsers.Add("$CAU_MGR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CAU_MGR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));


            emailDetails = GetEmailIdNamesForRole("CPO");
            RelatedUsers.Add("$CPO_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CPO_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CAU Director");
            RelatedUsers.Add("$CAU_DIR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CAU_DIR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

             emailDetails = GetEmailIdNamesForRole("VP for Construction Mgmt");
            RelatedUsers.Add("$VP_CM_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$VP_CM_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CQU Director");
            RelatedUsers.Add("$CQU_DIR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CQU_DIR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CQU Manager");
            RelatedUsers.Add("$CQU_MGR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CQU_MGR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CQU Financial Manager");
            RelatedUsers.Add("$CQU_FINANCIAL_MGR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CQU_FINANCIAL_MGR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CQU Financial Analyst");
            RelatedUsers.Add("$CQU_FINANCIAL_ANALYST_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CQU_FINANCIAL_ANALYST_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CQU Reviewer");
            RelatedUsers.Add("$CQU_REVIEWER_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CQU_REVIEWER_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("CAU Intake Specialist");
            RelatedUsers.Add("$CAU_INTAKE_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CAU_INTAKE_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("VP of Capital Planning");
            RelatedUsers.Add("$VP_CP_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$VP_CP_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("EVP BA");
            RelatedUsers.Add("$EVP_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$EVP_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            // emailid should be considered only for the ResoA type rfc projects
            //email templates that are notifiable for the role Reso A Specialist - BA - 
            // BA_BO_BIDRESULTS_CM_WBRKDWN has $RESOA_EMAIL$
            // BA_BO_BIDRESULTS_CM_WOBRKDWN has $RESOA_EMAIL$
            int? ResoAcount = 0;
            if (rfcBid?.Items?.Count > 0)
            {
                // if one of the items in ResoA is Y, we should consider that project for sending emails to
                // the users having the role  'Reso A Specialist - BA'
                ResoAcount = rfcBid?.Items?.OfType<RfcItem>()?.ToList()?.Where(x => x.IsResoA == "Y")?.ToList()?.Count;
            }
            if (ResoAcount > 0 && project.Type != "Line") // for Line projects, the email shouldn't be sent.
            {
                emailDetails = GetEmailIdNamesForRole("Reso A Specialist - BA");
                RelatedUsers.Add("$RESOA_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
                RelatedUsers.Add("$RESOA_TEXT$", "(Reso A)");
            }
            else
            {
                RelatedUsers.Add("$RESOA_EMAIL$", "");
                RelatedUsers.Add("$RESOA_TEXT$", "");
            }

            emailDetails = GetEmailIdNamesForRole("Sr Director - Capital Planning");
            RelatedUsers.Add("$CP_SRDIR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$CP_SRDIR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("BA Budget Group");
            RelatedUsers.Add("$BA_BUDGET_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$BA_BUDGET_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("BA Encumbrance Group");
            RelatedUsers.Add("$BA_BUDGET_ENCUMBRANCE_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$BA_BUDGET_ENCUMBRANCE_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("President");
            RelatedUsers.Add("$PRESIDENT_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$PRESIDENT_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("OIG User BA");
            RelatedUsers.Add("$OIG_BA_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$OIG_BA_USER_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("SAF Manager");
            RelatedUsers.Add("$SAF_MGR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$SAF_MGR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("Legal");
            RelatedUsers.Add("$LEGAL_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$LEGAL_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("VP of Finance");
            RelatedUsers.Add("$VP_FINANCE_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$VP_FINANCE_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRoleCustom("Mentor CM - Limited List", project.CMRep);
            RelatedUsers.Add("$MENTOR_CM_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$MENTOR_CM_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            emailDetails = GetEmailIdNamesForRole("Director of Mentor Program BA");
            RelatedUsers.Add("$DIRECTOR_MENTOR_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
            RelatedUsers.Add("$DIRECTOR_MENTOR_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));

            //Bug/Story #2025  control the  template placeholders based on the project type and the roles to be included or deleted

             ControlPlaceHolderTemplateForRoles(emailmessage, project, RelatedUsers);

            // end

            //$BUDGETNUMBER$ - 
            RelatedUsers.Add("$BUDGETNUMBER$", project.CostAmt.ToString("c"));

            //$$ENGINEERESTIMATE$
            RelatedUsers.Add("$ENGINEERESTIMATE$", project.CostEstAmt.ToString("c"));

            //-- Getting all bidders for the Project --//
           BidderCollection bidders = BidderUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME, BidderManager.FIND_BY_PROJECT, new object[] { project.Id });
           
            if (project.MultiContract)
            {
                var hbrejectedBidderIds = BidderRejectUtility.FindByCriteria(
                                                                             ConstantUtility.RFD_DATASOURCE_NAME,
                                                                             BidderRejectManager.FIND_BY_PROJECT,
                                                                             new object[] { project.Id })?.Cast<BidderReject>()?.Select(b => new { b.BidderId, b.RejectCode});
                var hbBidders = bidders?.Cast<Bidder>()
                                        .Where(b => b.IsBidReceived == "Y")
                                        .Select(b =>
                                                new
                                                {
                                                    Name = b.SupplierName.SplitEx("|")[0],
                                                    Amt = b.BidAmt,
                                                    Rank = b.Rank,
                                                    IsRejected = (hbrejectedBidderIds?.Any(h => h.BidderId == b.Id)).ToBool()
                                                });

                var _html = "<table><tr style='text-decoration:underline'><th>Contractor Name</th><th style='text-align:right'>Lump Sum Bid Amount</th><th style='text-align:right'>Rank</th></tr>#bidders#</table>";
                var _tbls = "";
                var _strike = "<strike style='color:red'><span style='color:auto'>#INFO#</span></strike>";
                hbBidders?.ForEach((b, i) =>
                {
                    var _name = b.IsRejected ? _strike.Replace("#INFO#", b.Name) : b.Name;
                    var _amt = b.IsRejected ? _strike.Replace("#INFO#", b.Amt.ToString("C")) : b.Amt.ToString("C");
                    var _rank = b.IsRejected ? _strike.Replace("#INFO#", b.Rank.ToString()) : b.Rank.ToString();
                    
                    _tbls += $"<tr><td>{_name}</td><td style='text-align:right'>{_amt}</td><td style='text-align:right'>{_rank}</td></tr>";

                });
                
                _html = _html.Replace("#bidders#", _tbls);
                RelatedUsers.Add("$RECORDEDBIDDERLIST$", _html);
                RelatedUsers.Add("$JMMAXBIDDERSWORDS$", NumberToWords.ConvertAmount(project.MaxContractToAward));                
                RelatedUsers.Add("$JMMAXBIDDERSFIGURES$", project.MaxContractToAward);
                RelatedUsers.Add("$PROJECTDURATIONINDAYS$", _duration);
                RelatedUsers.Add("$AGGREGATENTEAMOUNT$", project.NteAmt.ToString("C"));                
                RelatedUsers.Add("$SCHOOL$", project.KeyItems?.School.ToEmpty());
                //RelatedUsers.Add("$BIDDERCONTRACTNO$", "");
                RelatedUsers.Add("$RENEWALOPTION$", project.KeyItems?.RenewalOption.ToEmpty());
                RelatedUsers.Add("$BIDDERSNO$", hbBidders?.Count());
                RelatedUsers.Add("$BIDDERSNOWORDS$", NumberToWords.ConvertAmount((hbBidders?.Count()).ToInt()));
            }

            if(multiContractBidder != null)
            {
                RelatedUsers.Add("$BIDDERCONTRACTNO$", multiContractBidder.KeyItems.ContractNo);
                RelatedUsers.Add("$NTEBIDDERAMOUNT$", multiContractBidder.KeyItems.NTEAmount.ToString("c"));
            }

            if (bidders != null)
            {
                //removing the rejected bidders
                BidderRejectCollection rejections = BidderRejectUtility.FindByCriteria(
                          ConstantUtility.RFD_DATASOURCE_NAME,
                          BidderRejectManager.FIND_BY_PROJECT,
                          new object[] { project.Id });
                BidderCollection extractActiveBidders = new BidderCollection();

                foreach (Bidder bidder in bidders)
                    extractActiveBidders.Add(bidder);

                if (extractActiveBidders != null && rejections != null)
                {
                    foreach (Bidder bidder in extractActiveBidders)
                    {
                        foreach (BidderReject rejectbidder in rejections)
                        {
                            if (bidder.Id == rejectbidder.BidderId)
                            {
                                if (bidders.Contains(bidder))
                                    bidders.Remove(bidder);
                            }
                        }
                    }

                }
                //end
            }

            if (!project.MultiContract)
            {
                int nSubmittedBiddersCount = bidders?.ToList().Where(x => x.IsBidReceived == "Y").ToList().Count ?? 0;
                RelatedUsers.Add("$BIDDERSNO$", bidders == null ? "0" : nSubmittedBiddersCount.ToString());
            }
            //creating bidder list of emails to be notified about bid results. ref email template: BA_BO_BID_RESULT_NOTIFY
                emailDetails.Clear();
                List<Bidder> listofbidders = bidders?.ToList().Where(x => x.IsBidReceived == "Y")?.ToList();
                if (listofbidders != null)
                {
                    foreach (Bidder item in listofbidders)
                    {
                        var supplierdetail = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, item.SupplierId);
                        if (supplierdetail != null && supplierdetail.Email != string.Empty &&
                                supplierdetail.Company != string.Empty && !emailDetails.ContainsKey(supplierdetail.Email))
                        {
                            emailDetails.Add(supplierdetail.Email, supplierdetail.Company);
                        }
                    }
                    RelatedUsers.Add("$VENDORS_EMAIL$", emailDetails == null ? "" : string.Join(";", emailDetails.Keys.ToList().ToArray()));
                    RelatedUsers.Add("$VENDORS_NAME$", emailDetails == null ? "" : string.Join(";", emailDetails.Values.ToList().ToArray()));
                }
            //end
            Bidder lowBidder = null;
            Bidder secondLowBidder = null;
            Bidder thirdLowBidder = null;
            Supplier supplier = null;

            double VarianceBidamount = 0.0;
            double VarianceBidamountPercentage = 0;

            if (listofbidders != null && listofbidders.Count > 0)
            {
                lowBidder = listofbidders.Count > 0 ? listofbidders[0]:null;
                secondLowBidder = listofbidders.Count > 1 ? listofbidders[1]: null;
                thirdLowBidder = listofbidders.Count > 2 ? listofbidders[2] : null;

                foreach (Bidder b in listofbidders)
                {
                    if(b.Id == project.AwardBidderId)
                    {
                        VarianceBidamount =  b.BidAmt - project.CostEstAmt;
                        VarianceBidamountPercentage = b.Variance;
                    }
                }
            }

            //bidder variance and amounts - $$VARIANCEBIDAMOUNT$	($VARIANCEBIDAMOUNTPERCENTAGE$%) $ESTIMATEBARVALUE$
            RelatedUsers.Add("$VARIANCEBIDAMOUNT$", VarianceBidamount.ToString("c"));
            RelatedUsers.Add("$VARIANCEBIDAMOUNTPERCENTAGE$",  VarianceBidamountPercentage.ToString() + "%");

            if (VarianceBidamount > 0 )// variance is above engineers estimate
            {
                RelatedUsers.Add("$ESTIMATEBARVALUE$", "above");
            }
            if (VarianceBidamount < 0)
            {
                RelatedUsers.Add("$ESTIMATEBARVALUE$", "below");
            }
            if (VarianceBidamount == 0)
            {
                RelatedUsers.Add("$ESTIMATEBARVALUE$", "same as");
            }
            //end
 
            if (lowBidder != null)
            {
                RelatedUsers.Add("$APPARENTLOWBIDVARIANCE$", lowBidder == null ? "" : lowBidder.Variance.ToString() + "%");
                RelatedUsers.Add("$APPARENTLOWBIDREVISEDVARIANCE$", lowBidder == null ? "" : lowBidder.RevisedVariance.ToString() + "%");
                RelatedUsers.Add("$APPARENTLOWBASEAMOUNT$", lowBidder == null ? "" : lowBidder.BaseAmt.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT1$", lowBidder == null ? "" : lowBidder.AlternateAmt1.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT2$", lowBidder == null ? "" : lowBidder.AlternateAmt2.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT3$", lowBidder == null ? "" : lowBidder.AlternateAmt3.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT4$", lowBidder == null ? "" : lowBidder.AlternateAmt4.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT5$", lowBidder == null ? "" : lowBidder.AlternateAmt5.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT6$", lowBidder == null ? "" : lowBidder.AlternateAmt6.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT7$", lowBidder == null ? "" : lowBidder.AlternateAmt7.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT8$", lowBidder == null ? "" : lowBidder.AlternateAmt8.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT9$", lowBidder == null ? "" : lowBidder.AlternateAmt9.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWALTERNATEAMOUNT10$",lowBidder == null ? "" : lowBidder.AlternateAmt10.ToString("c"));
                RelatedUsers.Add("$APPARENTLOWAMOUNTADJUSTMENT$", lowBidder == null ? "" : lowBidder.AmtAdjustment.ToString("c"));

                RelatedUsers.Add("$APPARENTLOWBIDAMOUNT$", lowBidder == null ? "" : lowBidder.BidAmt.ToString("c"));
                RelatedUsers.Add("$BIDRANK1_LUMPSUMAMOUNT$", lowBidder == null ? "" : lowBidder.BaseAmt.ToString("c"));
                RelatedUsers.Add("$BIDRANK1_LUMPSUMRANK$","Rank 1");

                //RelatedUsers.Add("$REJECTEDBIDDER$", lowBidder == null ? "" : lowBidder.SupplierName);
                RelatedUsers.Add("$REJECTIONREASON$", lowBidder == null ? "" : lowBidder.RejectComments);
                

                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, lowBidder.SupplierId);
                RelatedUsers.Add("$APPARENTLOWBIDDER$", supplier == null ? "" : supplier.Company.ToString());
                RelatedUsers.Add("$APPARENTLOWBIDDERTAXID$", supplier == null ? "" : supplier.FederalId.ToString());
                RelatedUsers.Add("$APPARENTLOWBIDDERNAME$", supplier == null || supplier.PrimaryContact == null ? "" : supplier.PrimaryContact.Name.ToString());
                RelatedUsers.Add("$APPARENTLOWBIDDEREMAIL$", supplier == null || supplier.PrimaryContact == null ? "" : supplier.PrimaryContact.Email.ToString());

                RelatedUsers.Add("$BIDRANK1_COMPANY$", supplier == null ? "" : supplier.Company.ToString());
            }
            else
            {
                RelatedUsers.Add("$APPARENTLOWBIDDER$", "");
                RelatedUsers.Add("$APPARENTLOWBIDAMOUNT$", "");
            }

            if (secondLowBidder != null)
            {
                RelatedUsers.Add("$SECONDLOWBIDVARIANCE$", secondLowBidder == null ? "" : secondLowBidder.ToString() + "%");
                RelatedUsers.Add("$SECONDLOWBIDREVISEDVARIANCE$", secondLowBidder == null ? "" : secondLowBidder.RevisedVariance.ToString() + "%");

                RelatedUsers.Add("$SECONDLOWBASEAMOUNT$", secondLowBidder == null ? "" : secondLowBidder.BaseAmt.ToString("c"));

                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT1$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt1.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT2$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt2.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT3$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt3.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT4$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt4.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT5$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt5.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT6$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt6.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT7$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt7.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT8$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt8.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT9$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt9.ToString("c"));
                RelatedUsers.Add("$SECONDLOWALTERNATEAMOUNT10$", secondLowBidder == null ? "" : secondLowBidder.AlternateAmt10.ToString("c"));
                RelatedUsers.Add("$SECONDLOWAMOUNTADJUSTMENT$", secondLowBidder == null ? "" : secondLowBidder.AmtAdjustment.ToString("c"));

                RelatedUsers.Add("$SECONDLOWBIDAMOUNT$", secondLowBidder == null ? "" : secondLowBidder.BidAmt.ToString("c"));
                RelatedUsers.Add("$BIDRANK2_LUMPSUMAMOUNT$", secondLowBidder == null ? "" : secondLowBidder.BaseAmt.ToString("c"));

                RelatedUsers.Add("$BIDRANK2_LUMPSUMRANK$", "Rank 2");

                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, secondLowBidder.SupplierId);
                RelatedUsers.Add("$SECONDLOWBIDDER$", supplier == null ? "" : supplier.Company.ToString());
                RelatedUsers.Add("$SECONDLOWBIDDERTAXID$", supplier == null ? "" : supplier.FederalId.ToString());
                RelatedUsers.Add("$SECONDLOWBIDDERNAME$", supplier == null || supplier.PrimaryContact == null ? "" : supplier.PrimaryContact.Name.ToString());
                RelatedUsers.Add("$SECONDLOWBIDDEREMAIL$", supplier == null || supplier.PrimaryContact == null ? "" : supplier.PrimaryContact.Email.ToString());

                RelatedUsers.Add("$BIDRANK2_COMPANY$", supplier == null ? "" : supplier.Company.ToString());
            }
            else
            {
                RelatedUsers.Add("$SECONDLOWBIDDER$", "");
                RelatedUsers.Add("$SECONDLOWBIDAMOUNT$", "");
            }

            if (thirdLowBidder != null)
            {
                RelatedUsers.Add("$THIRDLOWBIDVARIANCE$", thirdLowBidder == null ? "" : thirdLowBidder.Variance.ToString() + "%");
                RelatedUsers.Add("$THIRDLOWBIDREVISEDVARIANCE$", thirdLowBidder == null ? "" : thirdLowBidder.RevisedVariance.ToString() + "%");

                RelatedUsers.Add("$THIRDLOWBASEAMOUNT$", thirdLowBidder == null ? "" : thirdLowBidder.BaseAmt.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT1$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt1.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT2$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt2.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT3$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt3.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT4$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt4.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT5$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt5.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT6$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt6.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT7$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt7.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT8$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt8.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT9$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt9.ToString("c"));
                RelatedUsers.Add("$THIRDLOWALTERNATEAMOUNT10$", thirdLowBidder == null ? "" : thirdLowBidder.AlternateAmt10.ToString("c"));
                RelatedUsers.Add("$THIRDLOWAMOUNTADJUSTMENT$", thirdLowBidder == null ? "" : thirdLowBidder.AmtAdjustment.ToString("c"));

                RelatedUsers.Add("$THIRDLOWBIDAMOUNT$", thirdLowBidder == null ? "" : thirdLowBidder.BidAmt.ToString("c"));
                RelatedUsers.Add("$BIDRANK3_LUMPSUMAMOUNT$", thirdLowBidder == null ? "" : thirdLowBidder.BaseAmt.ToString("c"));
                RelatedUsers.Add("$BIDRANK3_LUMPSUMRANK$", "Rank 3");

                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, thirdLowBidder.SupplierId);
                RelatedUsers.Add("$THIRDLOWBIDDER$", supplier == null ? "" : supplier.Company.ToString());
                RelatedUsers.Add("$THIRDLOWBIDDERTAXID$", supplier == null ? "" : supplier.FederalId.ToString());
                RelatedUsers.Add("$THIRDLOWBIDDERNAME$", supplier == null || supplier.PrimaryContact == null ? "" : supplier.PrimaryContact.Name.ToString());
                RelatedUsers.Add("$THIRDLOWBIDDEREMAIL$", supplier == null || supplier.PrimaryContact == null ? "" : supplier.PrimaryContact.Email.ToString());

                RelatedUsers.Add("$BIDRANK3_COMPANY$", supplier == null ? "" : supplier.Company.ToString());
            }
            else
            {
                RelatedUsers.Add("$THIRDLOWBIDDER$", "");
                RelatedUsers.Add("$THIRDLOWBIDAMOUNT$", "");
            }

            Bidder awardBidder = BidderUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, project.AwardBidderId);
            RelatedUsers.Add("$FINALBIDVARIANCE$", awardBidder == null ? "" : awardBidder.Variance.ToString() + "%");
            RelatedUsers.Add("$FINALBIDREVISEDVARIANCE$", awardBidder == null ? "" : awardBidder.RevisedVariance.ToString() + "%");

            double finalBidAmount = 0;
            if (awardBidder != null)
            {
                if (awardBidder.FinalAmt > 0)
                {
                    finalBidAmount = awardBidder.FinalAmt;
                }
                else
                {
                    finalBidAmount = awardBidder.BidAmt;
                }
            }

            RelatedUsers.Add("$FINALBIDAMOUNT$", awardBidder == null ? "" : finalBidAmount.ToString("c"));
            Supplier awardSupplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, multiContractBidder != null ? multiContractBidder.SupplierId : project.AwardSupplierId);
            RelatedUsers.Add("$AWARDBIDDER$", awardSupplier == null ? "" : awardSupplier.Company.ToString());
            RelatedUsers.Add("$AWARDBIDDERTAXID$", awardSupplier == null ? "" : awardSupplier.FederalId.ToString());
            RelatedUsers.Add("$AWARDBIDDERNAME$", awardSupplier == null || awardSupplier.PrimaryContact == null ? "" : awardSupplier.PrimaryContact.Name.ToString());
            RelatedUsers.Add("$AWARDBIDDEREMAIL$", awardSupplier == null || awardSupplier.PrimaryContact == null ? "" : awardSupplier.PrimaryContact.Email.ToString());
            
            BidderWicksCollection bws = new BidderWicksCollection();
            if (awardBidder != null)
            {
                bws = BidderWicksUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME,
                    BidderWicksManager.FIND_BY_BIDDER, new object[] { awardBidder.Id });
            }

            if (bws != null && bws.Count > 0)
            {
                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, bws[0].PlumbingSupplierId);
                RelatedUsers.Add("$WICKSUBPLUMB$", supplier == null ? "" : supplier.Company);
                RelatedUsers.Add("$WICKSUBPLUMBTAXID$", supplier == null ? "" : supplier.FederalId);
                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, bws[0].ElectricalSupplierId);
                RelatedUsers.Add("$WICKSUBELEC$", supplier == null ? "" : supplier.Company);
                RelatedUsers.Add("$WICKSIBELECTAXID$", supplier == null ? "" : supplier.FederalId);
                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, bws[0].HVACSupplierId);
                RelatedUsers.Add("$WICKSUBHVAC$", supplier == null ? "" : supplier.Company);
                RelatedUsers.Add("$WICKSUBHVACTAXID$", supplier == null ? "" : supplier.FederalId);
            }
 

            emailmessage.FromEmail = ReplaceRelatedUsers(emailmessage.FromEmail, RelatedUsers);
            emailmessage.FromName = ReplaceRelatedUsers(emailmessage.FromName, RelatedUsers);
            emailmessage.ToEmail = ReplaceRelatedUsers(emailmessage.ToEmail, RelatedUsers);
            emailmessage.ToName = ReplaceRelatedUsers(emailmessage.ToName, RelatedUsers);
            emailmessage.CcEmail = ReplaceRelatedUsers(emailmessage.CcEmail, RelatedUsers);
            emailmessage.BccEmail = ReplaceRelatedUsers(emailmessage.BccEmail, RelatedUsers);
            emailmessage.Subject = ReplaceRelatedUsers(emailmessage.Subject, RelatedUsers);
            emailmessage.Body = ReplaceRelatedUsers(emailmessage.Body, RelatedUsers);

            return emailmessage;
        }

        /// <summary>
        /// This function does apply new business logic according to the userStory #2025
        /// 
        /// </summary>
        /// <param name="emailMessage"></param>
        /// <param name="project"></param>
        /// <param name="RelatedUsers"></param>
        private static void ControlPlaceHolderTemplateForRoles(EmailMessage emailMessage, Project project, Hashtable RelatedUsers)
        {
            Dictionary<string, string> emailDetails = new Dictionary<string, string>();
       
            switch (emailMessage.Name.Trim())
            {
                case "BA_BP_PODM_PREBID":
                case "BA_BO_BIDDER_REJECTED":
                case "BA_BO_BIDRESULTS_CM_WBRKDWN":
                case "BA_BO_BIDRESULTS_CM_WOBRKDWN":
                case "BA_BAFO_RESULT_NOTIFY":
                case "BA_BIDBRKDN_BYPASS_BAFO_NEXTBIDDER":
                case "BA_BIDBRKDN_PROCEED_HOLD":
                case "BA_BIDBRKDN_REBID_CANCEL":
                case "BA_CONTRACT_EXECUTION_SCA":
                case "BA_PROJECT_CANCELLED":
                case "BA_PROJECT_REBID":
                    if (project.Type.ToLower() == "mentor" || project.Type.ToLower() == "mentor grad")
                        {
                            // for mentor and grad mentor director mentor should get emails.
                        }
                        else
                        {
                        //non mentor projects, this template shouldn't have the director mentor email going.
                            if (RelatedUsers.Contains("$DIRECTOR_MENTOR_EMAIL$"))
                            {
                                 RelatedUsers["$DIRECTOR_MENTOR_EMAIL$"] = "";
                            }
                            if (RelatedUsers.Contains("$DIRECTOR_MENTOR_NAME$"))
                            {
                               RelatedUsers["$DIRECTOR_MENTOR_NAME$"] = "";
                             }
                        }
                    break;

                case "BA_RP_NOTIFY_OIG_FIN_CQU_VPCM":
                case "BA_RP_VPCM_DISAPPROVED":
                case "BA_EP_PRESIDENT_CANCEL":
                    {
                        //For all project types, the cased templates shouldn't be emailed to $DIRECTOR_MENTOR_EMAIL$
                        if (RelatedUsers.Contains("$DIRECTOR_MENTOR_EMAIL$"))
                            RelatedUsers["$DIRECTOR_MENTOR_EMAIL$"] = "";
                        if (RelatedUsers.Contains("$DIRECTOR_MENTOR_NAME$"))
                            RelatedUsers["$DIRECTOR_MENTOR_NAME$"] = "";
                    }
                    break;

                case "BA_MENTOR_FINANCE_APPROVAL":
                case "BA_MENTOR_FINANCE_BUDGET_ADJUSTMENT":
                case "BA_MENTOR_FINANCE_CANCELLATION":
                case "BA_MENTOR_CONTRACTS_TURNOVER_TO_MENTOR_CM":
                case "BA_MENTOR_MENTORCM_APPROVAL":
                case "BA_MENTOR_CONTRACT_AWARDED":

                    if (project.Type.ToLower() == "mentor" || project.Type.ToLower() == "mentor grad")
                        {
                            // for mentor and grad mentor director mentor should get emails.

                        }
                        else
                        {
                            // for non mentor and grad mentor director mentor should NOT receive these emails.
                            //hence removing them if already existing in the final collection
                            if (RelatedUsers.Contains("$DIRECTOR_MENTOR_EMAIL$"))
                                RelatedUsers["$DIRECTOR_MENTOR_EMAIL$"] = "";
                            if (RelatedUsers.Contains("$DIRECTOR_MENTOR_NAME$"))
                                RelatedUsers["$DIRECTOR_MENTOR_NAME$"] = "";
                        }

                        if (project.Type.ToLower() != "mentor")
                        {
                            //For all project types except mentor, system shouldn't email to $VP_CM_EMAIL$
                            if (RelatedUsers.Contains("$VP_CM_EMAIL$"))
                                RelatedUsers["$VP_CM_EMAIL$"] = "";
                            if (RelatedUsers.Contains("$VP_CM_NAME$"))
                                RelatedUsers["$VP_CM_NAME$"] = "";
                        }

                        break;
            case "BA_MENTOR_CPO_APPROVAL":

                    if (project.Type.ToLower() == "mentor" || project.Type.ToLower() == "mentor grad")
                    {
                        // for mentor and grad mentor director mentor should get emails.

                    }
                    else
                    {
                        // for non mentor and grad mentor director mentor should NOT receive these emails.
                        //hence removing them if already existing in the final collection
                        if (RelatedUsers.Contains("$DIRECTOR_MENTOR_EMAIL$"))
                            RelatedUsers["$DIRECTOR_MENTOR_EMAIL$"] = "";
                        if (RelatedUsers.Contains("$DIRECTOR_MENTOR_NAME$"))
                            RelatedUsers["$DIRECTOR_MENTOR_NAME$"] = "";
                    }
                        //For all project types  system shouldn't email to $VP_CM_EMAIL$
                        if (RelatedUsers.Contains("$VP_CM_EMAIL$"))
                            RelatedUsers["$VP_CM_EMAIL$"] = "";
                        if (RelatedUsers.Contains("$VP_CM_NAME$"))
                            RelatedUsers["$VP_CM_NAME$"] = "";
                    break;
             case "BA_ADDENDUM_SCA_INTERNAL":
                    if (project.Type.ToLower() != "line")
                    {
                        //For all project types, the cased templates shouldn't be emailed to $VP_CM_EMAIL$
                        if (RelatedUsers.Contains("$VP_CM_EMAIL$"))
                            RelatedUsers["$VP_CM_EMAIL$"] = "";
                        if (RelatedUsers.Contains("$VP_CM_NAME$"))
                            RelatedUsers["$VP_CM_NAME$"] = "";
                    }

                    //For all project types, the cased templates shouldn't be emailed to $DIRECTOR_MENTOR_EMAIL$
                    if (RelatedUsers.Contains("$DIRECTOR_MENTOR_EMAIL$"))
                        RelatedUsers["$DIRECTOR_MENTOR_EMAIL$"] = "";
                    if (RelatedUsers.Contains("$DIRECTOR_MENTOR_NAME$"))
                        RelatedUsers["$DIRECTOR_MENTOR_NAME$"] = "";

                    break;
             default: break;
            }
        }
        #endregion Email Method
        /// <summary>
        /// This function retrieves all the users email/name having a specific role
        /// key is the emailid and value is the name of the person
        /// </summary>
        /// <param name="roleParam"></param>
        /// <returns></returns>
        public static Dictionary<string,string> GetEmailIdNamesForRole(string roleParam)
        {
            Dictionary<string, string> UserEmailDetails = new Dictionary<string, string>();
            UserCollection UserListCollection = UserUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                UserManager.SEARCH_USER,
                new object[]
                    {
                        0,
                        0,
                        string.Empty,
                        string.Empty,
                        string.Empty,
                         1,
                        string.Empty,
                        string.Empty,
                        roleParam,
                        string.Empty,
                        string.Empty,
                    });


            if (UserListCollection != null && UserListCollection.Count > 0)
            {
                StringBuilder EmailIds = new StringBuilder();
                foreach (User usr in UserListCollection)
                {
                    if (!UserEmailDetails.ContainsKey(usr.Email))
                        UserEmailDetails.Add(usr.Email, usr.Name);
                }
            }
            return UserEmailDetails;
        }


        /// <summary>
        /// This function retrieves all the users email/name having a specific role
        /// key is the emailid and value is the name of the person
        /// </summary>
        /// <param name="roleParam"></param>
        /// <returns></returns>
        public static Dictionary<string, string> GetEmailIdNamesForRoleCustom(string roleParam, string projectCMRep)
        {
            Dictionary<string, string> UserEmailDetails = new Dictionary<string, string>();
            UserCollection UserListCollection = UserUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                UserManager.SEARCH_USER,
                new object[]
                    {
                        0,
                        0,
                        string.Empty,
                        string.Empty,
                        string.Empty,
                         1,
                        string.Empty,
                        string.Empty,
                        roleParam,
                        string.Empty,
                        string.Empty,
                    });


            if (UserListCollection != null && UserListCollection.Count > 0)
            {
                StringBuilder EmailIds = new StringBuilder();
                foreach (User usr in UserListCollection)
                {
                    if (usr.Title.ToLower().Trim().Equals(projectCMRep.ToLower().Trim())) // checking for the same mentor firms of this project
                    {
                        if (!UserEmailDetails.ContainsKey(usr.Email))
                        {
                            UserEmailDetails.Add(usr.Email, usr.Name);
                        }
                    }
            }
        }
            return UserEmailDetails;
        }
        
        public static int CreateProject(Rfc rfc, string transNumber, int userId)
        {
            int rfdId = ProjectUtility.Import(ConstantUtility.RFD_DATASOURCE_NAME,
                transNumber, 0, userId);

            if (rfdId > 0)
            {
                AddProjectUser(rfc.PO, ConstantUtility.ROLE_PROJECT_OFFICER, userId);
                AddProjectUser(rfc.SPO, ConstantUtility.ROLE_SENIOR_PROJECT_OFFICER, userId);
                AddProjectUser(rfc.CPO, ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER, userId);
                AddProjectUser(rfc.ContractSpecialist, ConstantUtility.ROLE_CONTRACT_SPECIALIST, userId);
            }

            return rfdId;
        }

        public static void AddProjectUser(string userName, string roleName, int userId)
        {
            if (userName.Trim().Length > 0)
            {
                CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, userName);
                if (cesUser != null)
                    AddUser(cesUser, roleName, "", userId);
            }
        }

        public static void GetAllLevelBreakdown(BreakdownCollection breakdowns, ref BreakdownCollection allLevelBreakdowns, ref int level)
        {
            if (breakdowns != null)
            {
                foreach (Breakdown m in breakdowns)
                {
                    string toolTip = "";
                    for (int i = 1; i < level; i++)
                        //toolTip += "  ";
                        toolTip += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    //toolTip += "<a href=\"javascript:SelectBreakdown(" + m.Id + ", '" + m.Name.Replace("'", "\\'") + "');\">" + m.Name + "</a>";

                    m.Name = toolTip + m.Name;
                    if (level != 0)
                        allLevelBreakdowns.Add(m);
                    if (m.SubBreakdowns != null)
                    {
                        level++;
                        GetAllLevelBreakdown(m.SubBreakdowns, ref allLevelBreakdowns, ref level);
                    }
                }
            }
            level--;

        }


        #region ProjectProperty functions
        public static ProjectProperty CreateProjectProperty(Control control, string value, Type type, Control parent, string changeUser)
        {
            ProjectProperty projectProperty = CreateProjectProperty(control, value, type, parent);
            projectProperty.ChangeUser = changeUser;
            return projectProperty;
        }

        public static ProjectProperty CreateProjectProperty(Control control, string value, Type type, Control parent)
        {
            ProjectProperty projectProperty = ProjectPropertyUtility.CreateObject();
            projectProperty.PropertyId = ConvertUtility.ConvertInt(control.ID.Substring(8));
            if (parent != null) projectProperty.ParentId = projectProperty.PropertyId;
            switch (type.Name)
            {
                case "Int32":
                    projectProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    projectProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    projectProperty.PropertyText = value;
                    break;
            }
            return projectProperty;
        }


        public static ProjectProperty CreateProjectProperty(Control control, string attachmentName, long attachmentId)
        {
            ProjectProperty projectProperty = ProjectPropertyUtility.CreateObject();
            projectProperty.PropertyId = ConvertUtility.ConvertInt(control.ID.Substring(8));
            projectProperty.AttachmentName = attachmentName;
            projectProperty.AttachmentId = attachmentId;

            return projectProperty;
        }

        public static ProjectProperty CreateProjectProperty(int propertyId, string value)
        {
            ProjectProperty projectProperty = CreateProjectProperty(propertyId, value, typeof(String));
            return projectProperty;
        }

        public static ProjectProperty CreateProjectProperty(int propertyId, string value, long attachmentId)
        {
            ProjectProperty projectProperty = CreateProjectProperty(propertyId, value);
            projectProperty.AttachmentId = attachmentId;

            return projectProperty;
        }


        public static ProjectProperty CreateProjectProperty(int propertyId, string value, Type type)
        {
            ProjectProperty projectProperty = ProjectPropertyUtility.CreateObject();
            projectProperty.PropertyId = propertyId;
            switch (type.Name)
            {
                case "Int32":
                    projectProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    projectProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    projectProperty.PropertyText = value;
                    break;
            }
            return projectProperty;
        }

        public static ProjectPropertyCollection AddProjectProperty(Project project, ProjectProperty projectProperty)
        {
            ProjectPropertyCollection projectProperties = new ProjectPropertyCollection();
            projectProperties.Add(projectProperty);
            return AddProjectProperty(project, projectProperties);
        }

        public static ProjectPropertyCollection AddProjectProperty(Project project, ProjectPropertyCollection projectProperties, string changeuser = null)
        {
            ProjectPropertyCollection currentProperties = ProjectPropertyUtility.FindByCriteria(
                ConstantUtility.RFD_DATASOURCE_NAME,
                ProjectPropertyManager.FIND_BY_PROJECT,
                new object[] { project.Id });
            if (currentProperties == null)
                currentProperties = new ProjectPropertyCollection();

            foreach (ProjectProperty sp in projectProperties)
            {
                if (sp.ParentId == 0)
                {
                    bool isChange = false;
                    foreach (ProjectProperty sp1 in currentProperties)
                    {
                        if (sp1.PropertyId == sp.PropertyId)
                        {
                            sp1.PropertyValue = sp.PropertyValue;
                            sp1.PropertyText = sp.PropertyText;
                            sp1.PropertyDate = sp.PropertyDate;
                            sp1.AttachmentId = sp.AttachmentId;
                            sp1.ChangeUser = changeuser;
                            isChange = true;
                        }
                    }
                    if (!isChange)
                        currentProperties.Add(sp);
                }
                else
                {
                    //Multi values
                    currentProperties.Add(sp);
                }
            }
            return currentProperties;
        }

        public static ProjectPropertyCollection GetProjectProperties(int projectId)
        {
            ProjectPropertyCollection currentProperties = ProjectPropertyUtility.FindByCriteria(
                ConstantUtility.RFD_DATASOURCE_NAME,
                ProjectPropertyManager.FIND_BY_PROJECT,
                new object[] { projectId });

            if (currentProperties == null)
                currentProperties = new ProjectPropertyCollection();

            return currentProperties;
        }


        public static ProjectProperty GetProjectProperty(Control control, ProjectPropertyCollection projectProperties)
        {
            if (projectProperties == null) return ProjectPropertyUtility.CreateObject();
            foreach (ProjectProperty sp in projectProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(control.ID.Substring(8)))
                    return sp;
            }
            return ProjectPropertyUtility.CreateObject();
        }
        public static ProjectProperty GetProjectProperty(string propertyId, ProjectPropertyCollection projectProperties)
        {
            if (projectProperties == null) return ProjectPropertyUtility.CreateObject();
            foreach (ProjectProperty sp in projectProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(propertyId.Substring(8)))
                    return sp;
            }
            return ProjectPropertyUtility.CreateObject();
        }

        public static ProjectProperty GetProjectProperty(int propertyId, ProjectPropertyCollection projectProperties)
        {
            if (projectProperties == null) return ProjectPropertyUtility.CreateObject();
            foreach (ProjectProperty sp in projectProperties)
            {
                if (sp.PropertyId == propertyId)
                    return sp;
            }
            return ProjectPropertyUtility.CreateObject();
        }

        public static ProjectProperty GetProjectProperty(int projectId, string propertyId)
        {

            var projectProperties = GetProjectProperties(projectId);

            if (projectProperties == null) return ProjectPropertyUtility.CreateObject();

            foreach (ProjectProperty sp in projectProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(propertyId.Substring(8)))
                    return sp;
            }
            return ProjectPropertyUtility.CreateObject();
        }

        public static ProjectPropertyCollection GetProjectProperties(Control control, ProjectPropertyCollection projectProperties)
        {
            ProjectPropertyCollection localProjectProperties = new ProjectPropertyCollection();
            if (projectProperties == null) return localProjectProperties;
            foreach (ProjectProperty sp in projectProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(control.ID.Substring(8)))
                    localProjectProperties.Add(sp);
            }
            return localProjectProperties;
        }
        public static ProjectPropertyCollection GetProjectProperties(string controlId, ProjectPropertyCollection projectProperties)
        {
            ProjectPropertyCollection localProjectProperties = new ProjectPropertyCollection();
            if (projectProperties == null) return localProjectProperties;
            foreach (ProjectProperty sp in projectProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(controlId.Substring(8)))
                    localProjectProperties.Add(sp);
            }
            return localProjectProperties;
        }
        #endregion ProjectProperty functions

        #region Package Functions

        public static byte[] Replace(Project project, Package package, Rfc rfc, ProjectAddendum addendum)
        {
            byte[] attachment = package.Attachment;
            var _duration = project.MultiContract ? $"{project.KeyItems.Duration} year(s) and with {project.KeyItems.RenewalOption}" : project.ProjectDuration.ToString();

            Dictionary<string, string> fields = new Dictionary<string, string>();
            fields["Date"] = DateTime.Today.ToString("MMMM dd, yyyy");

            if (project != null)
            {
                fields["ProjectType"] = project.Type;
                fields["SolicitationNo"] = project.SolicitationNo + "-" + project.SolicitSeq;
                fields["Description"] = project.Description.Trim();
                fields["DesignNo"] = project.DesignNo;
                fields["PackageNo"] = project.PackageNo;
                fields["ContractNo"] = project.ContractNo;
                fields["PerformancePeriod"] = _duration;
                fields["ContractDocsPrice"] = project.DocsPrice.ToString("c");
                fields["PreBidDate"] = project.PreBidMeetingDateTime.ToString("MMMM dd, yyyy");
                fields["PreBidTime"] = project.PreBidMeetingDateTime.ToShortTimeString();
                fields["PreBidLocation"] = project.PreBidMeetingLoc;
                fields["BOD"] = project.PlanedBidOpeningDateTime.ToString("MMMM dd, yyyy");
                fields["BOT"] = project.PlanedBidOpeningDateTime.ToShortTimeString();
                fields["DocsAvailable"] = project.DocsAvailableDate.ToString("MMMM dd, yyyy");
                fields["CostEstAmt"] = project.CostEstAmt.ToString("c");
                fields["RevisedCostEstAmt"] = project.RevisedCostEstAmt.ToString("c");
                fields["CostAmt"] = project.CostAmt.ToString("c");
                fields["SolicitPkgRcvdDate"] = project.SolicitPkgRcvdDate.ToString("MMMM dd, yyyy");
                fields["IFBDate"] = project.IFBDate.ToString("MMMM dd, yyyy");
                fields["ProjectRange"] = project.MinAmt.ToString("c") + " - " + project.MaxAmt.ToString("c");

                fields["CMFIRMNAME"] = "";
                SettingCollection settings = CommonUtility.GetSettings("MentorCMFirms.xml");
                foreach (Setting setting in settings)
                {
                    if (project.CMRep == setting.Value)
                    {
                        fields["CMFIRMNAME"] = setting.Name;
                        break;
                    }
                }

                int finalCompletionDays = 0;
                if (project.Type == "Line")
                    finalCompletionDays = project.ProjectDuration + 120;
                else if (project.ProjectDuration <= 365)
                    finalCompletionDays = project.ProjectDuration + 30;
                else if (project.ProjectDuration > 365 && project.ProjectDuration <= 730)
                    finalCompletionDays = project.ProjectDuration + 60;
                else if (project.ProjectDuration > 730)
                    finalCompletionDays = project.ProjectDuration + 90;

                fields["FinalCompletionDays"] = finalCompletionDays.ToString();

                User contractSpecialist = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, project.ContractSpecialist);
                if (contractSpecialist != null)
                {
                    fields["ContSpecName"] = contractSpecialist.FullName;
                    fields["ContSpecEmail"] = contractSpecialist.Email;
                    fields["ContSpecPhone"] = contractSpecialist.Phone;
                }
                User po = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, project.PO);
                if (po != null)
                {
                    fields["PO"] = po.FullName;
                }
                User spo = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, project.SPO);
                if (spo != null)
                {
                    fields["SPO"] = spo.FullName;
                }
                User cpo = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, project.CPO);
                if (cpo != null)
                {
                    fields["CPO"] = cpo.FullName;
                }

                Bidder lowBidder = null;
                Bidder secondLowBidder = null;
                Bidder thirdLowBidder = null;
                BidderCollection bidders = BidderUtility.FindByCriteria(
                    ConstantUtility.RFD_DATASOURCE_NAME,
                    BidderManager.FIND_BY_PROJECT,
                    new object[] { project.Id });

                if (bidders != null)
                {
                    foreach (Bidder b in bidders)
                    {
                        if (b.Rank == 1)
                            lowBidder = b;
                        else if (b.Rank == 2)
                            secondLowBidder = b;
                        else if (b.Rank == 3)
                            thirdLowBidder = b;
                    }
                    fields["BIDDERSNO"] = bidders.Count.ToString();
                }

                if (lowBidder != null)
                {
                    fields["APPARENTLOWBIDAMOUNT"] = lowBidder.BidAmt.ToString("c");
                    fields["APPARENTLOWBIDDERVARIANCE"] = lowBidder.Variance.ToString("0.00");

                    Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, lowBidder.SupplierId);
                    if (supplier != null)
                    {
                        fields["APPARENTLOWBIDDER"] = supplier.Company;
                        fields["APPARENTLOWBIDDERTAXID"] = supplier.FederalId;

                        if (supplier.PrimaryContact != null)
                        {
                            fields["APPARENTLOWBIDDERNAME"] = supplier.PrimaryContact.Name;
                            fields["APPARENTLOWBIDDEREMAIL"] = supplier.PrimaryContact.Email;
                        }
                    }
                }
                if (secondLowBidder != null)
                {
                    fields["SECONDLOWBIDAMOUNT"] = secondLowBidder.BidAmt.ToString("c");
                    fields["SECONDLOWBIDDERVARIANCE"] = secondLowBidder.Variance.ToString("0.00");

                    Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, secondLowBidder.SupplierId);
                    if (supplier != null)
                    {
                        fields["SECONDLOWBIDDER"] = supplier.Company;
                        fields["SECONDLOWBIDDERTAXID"] = supplier.FederalId;

                        if (supplier.PrimaryContact != null)
                        {
                            fields["SECONDLOWBIDDERNAME"] = supplier.PrimaryContact.Name;
                            fields["SECONDLOWBIDDEREMAIL"] = supplier.PrimaryContact.Email;
                        }
                    }
                }
                if (thirdLowBidder != null)
                {
                    fields["THIRDLOWBIDAMOUNT"] = thirdLowBidder.BidAmt.ToString("c");
                    fields["THIRDLOWBIDDERVARIANCE"] = thirdLowBidder.Variance.ToString("0.00");

                    Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, thirdLowBidder.SupplierId);
                    if (supplier != null)
                    {
                        fields["THIRDLOWBIDDER"] = supplier.Company;
                        fields["THIRDLOWBIDDERTAXID"] = supplier.FederalId;

                        if (supplier.PrimaryContact != null)
                        {
                            fields["THIRDLOWBIDDERNAME"] = supplier.PrimaryContact.Name;
                            fields["THIRDLOWBIDDEREMAIL"] = supplier.PrimaryContact.Email;
                        }
                    }
                }

                Bidder awardBidder = BidderUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, project.AwardBidderId);
                if (awardBidder != null)
                {
                    fields["FINALBIDAMOUNT"] = awardBidder.FinalAmt.ToString("c");

                    Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, project.AwardSupplierId);
                    if (supplier != null)
                    {
                        fields["AWARDBIDDER"] = supplier.Company;
                        fields["AWARDBIDDERTAXID"] = supplier.FederalId;

                        if (supplier.PrimaryContact != null)
                        {
                            fields["AWARDBIDDERNAME"] = supplier.PrimaryContact.Name;
                            fields["AWARDBIDDEREMAIL"] = supplier.PrimaryContact.Email;
                        }

                        if (supplier.PhysicalAddress != null)
                        {
                            fields["AWARDBIDDERADDRESS"] =
                                supplier.PhysicalAddress.AddressLine1.Replace("|", " ") + " " +
                                supplier.PhysicalAddress.AddressLine2.Replace("|", " ") + " " +
                                supplier.PhysicalAddress.City + ", " +
                                supplier.PhysicalAddress.State + " " +
                                supplier.PhysicalAddress.ZipCode;
                        }
                    }
                }
            }
            if (package != null)
            {
                fields["DocumentName"] = package.Name;
            }
            if (addendum != null)
            {
                fields["AddendumDescription"] = addendum.Description;
                fields["AddendumComments"] = addendum.Comments;
                fields["NumberOfPages"] = addendum.NumberOfPages.ToString();
                fields["NumberOfSheets"] = addendum.NumberOfSheets.ToString();
                fields["PickupDate"] = addendum.PickupDate.ToString("MMMM dd, yyyy");
                fields["PickupTime"] = addendum.PickupDate.ToShortTimeString();
            }

            if (project.Items != null && project.Items.Count > 0)
            {
                string schools = "";
                string schoolsAddr = "";
                string llws = "";
                foreach (ProjectItem item in project.Items)
                {
                    if (schools.IndexOf(item.School.Trim()) >= 0) continue;
                    schools += "," + item.School.Trim() + " (" + item.Boro() + ")"; ;
                    schoolsAddr += "/" + item.SchoolAddressLine1.Trim() + " " + item.SchoolAddressLine2.Trim();

                }
                foreach (ProjectItem item in project.Items)
                {
                    if (llws.IndexOf(item.LLW.Trim()) >= 0) continue;
                    llws += "," + item.LLW.Trim();
                }
                schools = schools.Substring(1);
                schoolsAddr = schoolsAddr.Substring(1);
                llws = llws.Substring(1);

                fields["School"] = schools;
                fields["SchoolAddress"] = schoolsAddr;
                fields["LLW"] = llws;
            }

            if (rfc != null)
            {
                fields["LiquidatedDamages"] = rfc.Result;

                User designManager = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, rfc.DesignManager);
                if (designManager != null)
                {
                    fields["DesignMgr"] = designManager.FullName;
                }
            }

            return OpenXmlUtility.MergeWordDoc(attachment, fields);
        }


        public static void MergePackage(Package package, int userId)
        {
            Project project = ProjectUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME,
                package.ProjectId);

            Rfc rfc = null;
            if (project.RfcId > 0)
                rfc = RfcUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, project.RfcId);
            else
                rfc = RfcUtility.GetByNumber(ConstantUtility.RFD_DATASOURCE_NAME, project.TransNumber, "Bid");

            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, userId);

            ProjectAddendum addendum = ProjectAddendumUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, package.AddendumId);

            package.Attachment = Replace(project, package, rfc, addendum);
            package.Version = GetNextMinorVersion(package.Version);
            package.ChangeUser = user.UserName;
        }

        public static string GetNextMajorVersion(string version)
        {
            int majorVersion = 0;
            string[] versions = version.Split('.');
            if (versions.Length > 0)
            {
                majorVersion = ConvertUtility.ConvertInt(versions[0]);
            }
            majorVersion += 1;
            return majorVersion.ToString() + ".0";
        }

        public static string GetNextMinorVersion(string version)
        {
            int majorVersion = 0;
            int minorVersion = 0;
            string[] versions = version.Split('.');
            if (versions.Length > 1)
            {
                majorVersion = ConvertUtility.ConvertInt(versions[0]);
                minorVersion = ConvertUtility.ConvertInt(versions[1]);
            }
            if (majorVersion == 0)
                majorVersion = 1;
            minorVersion += 1;
            return majorVersion.ToString() + "." + minorVersion.ToString();
        }

        public static Package FindPackage(int projectId, string type, string name)
        {
            Package package = null;
            PackageCollection packages = PackageUtility.FindByCriteria(
                ConstantUtility.RFD_DATASOURCE_NAME,
                PackageManager.FIND_BY_PROJECT,
                new object[]
            {
                projectId,
                0,
                type
            });
            if (packages != null)
            {
                foreach (Package pkg in packages)
                {
                    if (pkg.Name == name)
                    {
                        package = pkg;
                        break;
                    }
                }
            }
            return package;
        }
        #endregion
    }
}
