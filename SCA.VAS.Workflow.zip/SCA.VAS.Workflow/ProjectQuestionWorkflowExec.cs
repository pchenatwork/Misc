#region Copyright
/*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Configuration;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

namespace SCA.VAS.Workflow
{
    public class ProjectQuestionWorkflowExec
    {
        #region Private Member
        private static string prefixDbName = string.Empty;
        private static int userId = 0;
        private static string workflowType = string.Empty;
        public static string WorkflowType
        {
            set { workflowType = value; }
        }
        #endregion

        #region Constructor
        public ProjectQuestionWorkflowExec()
        {
        }
        static ProjectQuestionWorkflowExec()
        {
        }
        #endregion Constructor

        #region Private Method
        private static ProjectQuestion GetProjectQuestion(ProjectQuestion projectQuestion)
        {
            if (projectQuestion == null) return null;
            if (projectQuestion.TransactionId == 0)
            {
                WorkflowList workflow = WorkflowListUtility.GetByName(
                    prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                    workflowType, 0);
                if (workflow != null)
                {
                    projectQuestion.WorkflowId = workflow.Id;
                    projectQuestion.TransactionId = WorkflowExec.CreateWorkflowHistory(projectQuestion.WorkflowId);
                    ProjectQuestionUtility.Update(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME, projectQuestion);
                    ProjectQuestionUtility.UpdateTransactionId(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                        projectQuestion.Id, projectQuestion.TransactionId);
                    NodeAction(projectQuestion, "New Workflow");
                }
            }
            return projectQuestion;
        }
        #endregion

        #region Workflow Control
        public static ProjectQuestion InitialProjectQuestion(ProjectQuestion projectQuestion, string workflowName)
        {
            workflowType = workflowName;
            return GetProjectQuestion(projectQuestion);
        }

        public static User GetLastApprover(ProjectQuestion projectQuestion)
        {
            projectQuestion = GetProjectQuestion(projectQuestion);
            if (projectQuestion == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectQuestion.TransactionId);
            if (workflowHistory == null) return null;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return null;

            return UserUtility.Get(prefixDbName + ConstantUtility.USER_DATASOURCE_NAME,
                workflowHistory.ApprovalUserId);
        }

        public static int ProjectQuestionWorkflow(ProjectQuestion projectQuestion, string systemAction, string comments, ref string errmsg, ref string url)
        {
            projectQuestion = GetProjectQuestion(projectQuestion);
            if (projectQuestion == null) return 0;

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_SYSTEMNAME,
                new object[] { projectQuestion.WorkflowId, systemAction });
            if (workflowNodes == null || workflowNodes.Count == 0) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectQuestion.TransactionId);
            if (workflowHistory == null)
                return 0;

            int actionId = 0;
            for (int i = 0; i < workflowNodes.Count; i++)
            {
                if (workflowHistory.CurrentNodeId == workflowNodes[i].NodeFromId)
                {
                    actionId = workflowNodes[i].Id;
                    break;
                }
            }
            return ProjectQuestionWorkflow(projectQuestion, actionId, comments, ref errmsg, ref url);
        }

        public static int ProjectQuestionWorkflow(ProjectQuestion projectQuestion, int actionId, string comments, ref string errmsg, ref string url)
        {
            projectQuestion = GetProjectQuestion(projectQuestion);
            if (projectQuestion == null || actionId == 0) return projectQuestion.TransactionId;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectQuestion.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowNode workflowNode = WorkflowNodeUtility.Get(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
            if (workflowNode == null)
                return 0;
            if (workflowHistory.CurrentNodeId != workflowNode.NodeFromId)
                return 0;

            // condition proccessing
            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNode.Id });

            TextReader reader = XmlUtility.Serialize(projectQuestion);
            XPathDocument doc = new XPathDocument(reader);
            XPathNavigator nav = doc.CreateNavigator();

            errmsg = string.Empty;
            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count == 0)
                    {
                        errmsg += workflowCondition.ErrorMessage + "<br>";
                    }
                }
            }
            if (errmsg != string.Empty) return 0;

            //Workflow topologic
            bool approval = true;
            switch (workflowNode.Action1)
            {
                case "One":
                    break;
                case "Owner":
                    //if (projectQuestion.BuyerId != userId)
                    //    errmsg = "Only RFx owner / Creator can do this step";
                    break;
                case "All":
                case "Majority":
                case "Count":
                    WorkflowHistoryCollection workflowHistories = WorkflowHistoryUtility.FindByCriteria(
                        prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                        new object[] { projectQuestion.TransactionId });

                    WorkflowHistoryCollection currentHistories = new WorkflowHistoryCollection();
                    if (workflowHistories != null)
                    {
                        for (int i = workflowHistories.Count - 1; i >= 0; i--)
                        {
                            if (workflowHistories[i].IsActive == 1) break;
                            if (workflowHistories[i].CurrentNodeId != actionId) continue;
                            if (workflowHistories[i].ApprovalUserId == userId)
                            {
                                errmsg = "You already approved this step";
                                return 0;
                            }
                            currentHistories.Add(workflowHistories[i]);
                        }
                    }

                    // Create a history from new approval
                    WorkflowHistory approvalHistory = WorkflowHistoryUtility.CreateObject();
                    approvalHistory.TransactionHeaderId = projectQuestion.TransactionId;
                    approvalHistory.WorkflowId = projectQuestion.WorkflowId;
                    approvalHistory.CurrentNodeId = actionId;
                    approvalHistory.ApprovalUserId = WorkflowExec.GetUserId();
                    approvalHistory.ApprovalConditionId = 1;
                    approvalHistory.CreatedBy = workflowHistory.ApprovalUserId;
                    approvalHistory.CreatedType = WorkflowExec.GetUserType();
                    WorkflowHistoryUtility.Create(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, approvalHistory);

                    int approvalKnt = currentHistories.Count + 1;
                    switch (workflowNode.Action1)
                    {
                        case "All":
                            //if (approvalKnt < projectQuestionUsers.Count)
                            //    approval = false;
                            break;
                        case "Majority":
                            //if (approvalKnt < projectQuestionUsers.Count / 2)
                            //    approval = false;
                            break;
                        case "Count":
                            int knt = ConvertUtility.ConvertInt(workflowNode.Action2);
                            if (approvalKnt < knt)
                                approval = false;
                            break;
                    }
                    break;

                //case "Sequence":
                //    break;
                //case "Timer":
                //    //approve7.Checked = true;
                //    //approveKnt7.Text = workflowNode.Action2;
                //    break;
            }

            if (!approval || errmsg != string.Empty) return projectQuestion.TransactionId;

            //Action proccessing
            WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE,
                new object[] { workflowNode.Id });

            if (workflowActions != null)
            {
                foreach (WorkflowAction workflowAction in workflowActions)
                {
                    switch (workflowAction.Type)
                    {
                        //Send Email
                        case 1:
                            break;

                        //Action
                        case 2:
                            ProjectQuestionAction(projectQuestion, workflowAction.FunctionName);
                            break;

                        //Redirect page
                        case 3:
                            url = workflowAction.FunctionName;
                            break;
                    }
                }
            }

            if (workflowNode.NodeToId > 0)
            {
                WorkflowNode nextNode = WorkflowNodeUtility.Get(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode.NodeToId);
                WorkflowExec.WorkflowNextStatus(workflowNode.WorkflowId, nextNode.Name, workflowHistory.CurrentNodeId, projectQuestion.TransactionId, comments);

                NodeAction(projectQuestion, comments);
            }

            return projectQuestion.TransactionId;
        }

        public static int ProjectQuestionWorkflow(ProjectQuestion projectQuestion, string nextStatus, string comments)
        {
            projectQuestion = GetProjectQuestion(projectQuestion);
            if (projectQuestion == null) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectQuestion.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowExec.WorkflowNextSystemStatus(projectQuestion.WorkflowId, nextStatus, workflowHistory.CurrentNodeId, projectQuestion.TransactionId, comments);

            NodeAction(projectQuestion, comments);

            return projectQuestion.TransactionId;
        }

        public static WorkflowConditionCollection ProjectQuestionConditionTest(ProjectQuestion projectQuestion, int workflowNodeId)
        {
            projectQuestion = GetProjectQuestion(projectQuestion);
            if (projectQuestion == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectQuestion.TransactionId);
            if (workflowHistory == null)
                return null;

            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNodeId });

            XPathDocument doc = new XPathDocument(XmlUtility.Serialize(projectQuestion));
            XPathNavigator nav = doc.CreateNavigator();

            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count > 0)
                        workflowCondition.Status = 1;
                }
            }
            return workflowConditions;
        }
        #endregion Workflow Control

        #region Workflow Node Action
        private static void NodeAction(ProjectQuestion projectQuestion, string comments)
        {
            projectQuestion = GetProjectQuestion(projectQuestion);
            if (projectQuestion == null) return;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(
                projectQuestion.TransactionId);

            int status = CommonUtility.GetProjectStatusId(workflowType, workflowHistory.CurrentNode.Name.Trim());

            if (status == 0 || status == projectQuestion.Status) return;

            projectQuestion.Status = status;
            projectQuestion.StatusName = ((ProjectRfiSubmissionStatusType)status).Description;
            ProjectQuestionUtility.UpdateStatus(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME, projectQuestion.Id, status,
                projectQuestion.StatusName);

            // automatic step
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { projectQuestion.WorkflowId, "UserStepId", "ASC" });
            if (workflowNodes != null)
            {
                for (int i = 0; i < workflowNodes.Count; i++)
                {
                    if (workflowNodes[i].Type != 1 || workflowNodes[i].TimeToSkip != 1 ||
                        workflowHistory.CurrentNodeId != workflowNodes[i].NodeFromId)
                        continue;

                    string errmsg = string.Empty;
                    string url = string.Empty;
                    ProjectQuestionWorkflow(projectQuestion, workflowNodes[i].Id, comments, ref errmsg, ref url);
                }
            }
        }
        #endregion Workflow Node Action

        #region Batch Jobs
        #endregion Batch Jobs

        #region ProjectQuestion Action
        private static void ProjectQuestionAction(ProjectQuestion projectQuestion, string actionName)
        {
            string msg = string.Empty;
            string url = string.Empty;
            string tempType = workflowType;

            switch (actionName)
            {
                case "SampleAction":
                    //Action Here
                    break;
            }
            WorkflowType = tempType;
        }
        #endregion
    }
}
