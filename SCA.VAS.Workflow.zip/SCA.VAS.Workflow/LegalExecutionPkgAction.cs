using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of LegalExecutionPkgAction:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(LegalExecutionPkgActionConverter))]
    public class LegalExecutionPkgAction : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly LegalExecutionPkgAction NewRS1Subcontractor = new LegalExecutionPkgAction(1, "NewRS1Subcontractor", "New RS1 Subcontractor");
        public static readonly LegalExecutionPkgAction BDDReviewApprove = new LegalExecutionPkgAction(2, "BDDReviewApprove", "BDD Review Approve");
        public static readonly LegalExecutionPkgAction BDDReviewDeny = new LegalExecutionPkgAction(3, "BDDReviewDeny", "BDD Review Deny");
        public static readonly LegalExecutionPkgAction BDDManagerApprove = new LegalExecutionPkgAction(4, "BDDManagerApprove", "BDD Manager Approve");
        public static readonly LegalExecutionPkgAction BDDManagerDeny = new LegalExecutionPkgAction(5, "BDDManagerDeny", "BDD Manager Deny");

        #endregion  

        #region Constructors
        public LegalExecutionPkgAction()
        {
        }

        private LegalExecutionPkgAction(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in RS1SubcontractorAction class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of RS1SubcontractorAction.  
        /// </summary>
        public static LegalExecutionPkgAction Default
        {
            get
            {
                return (LegalExecutionPkgAction)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for LegalExecutionPkgAction class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a LegalExecutionPkgAction object.
        /// It allows a string to be assigned to a LegalExecutionPkgAction object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator LegalExecutionPkgAction(int id)
        {
            return (LegalExecutionPkgAction)EnumerationBase.FindById(id, LegalExecutionPkgAction._list);
        }
        #endregion
    }



    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and RS1SubcontractorAction objects.
    /// It's very useful when binding RS1SubcontractorAction objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class LegalExecutionPkgActionConverter : TypeConverter
    {

        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, LegalExecutionPkgAction._list);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the LegalExecutionPkgAction enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < LegalExecutionPkgAction._list.Count; i++)
            {
                list.Add(((LegalExecutionPkgAction)LegalExecutionPkgAction._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}