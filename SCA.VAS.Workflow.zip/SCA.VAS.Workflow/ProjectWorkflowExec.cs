#region Copyright
/*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Configuration;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.BusinessLogic.Supplier.Subcontractor;
using SCA.VAS.BusinessLogic.Supplier.Subcontractor.Utilities;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Template.Utilities;
using SCA.VAS.BusinessLogic.Template;
using SCA.VAS.ValueObjects.Supplier.Subcontractor;
using SCA.VAS.ValueObjects.Template;

using Project = SCA.VAS.ValueObjects.Rfd.Project;
using ProjectUtility = SCA.VAS.BusinessLogic.Rfd.Utilities.ProjectUtility;
#endregion Reference

namespace SCA.VAS.Workflow
{
    public class ProjectWorkflowExec
    {
        #region Private Member
        private static string prefixDbName = string.Empty;
        private static int userId = 0;
        private static string workflowType = string.Empty;
        public static string WorkflowType
        {
            set { workflowType = value; }
        }
        #endregion

        #region Constructor
        public ProjectWorkflowExec()
        {
        }
        static ProjectWorkflowExec()
        {
        }
        #endregion Constructor
        
        #region Private Method
        private static ProjectWorkflow GetProjectWorkflow(Project project)
        {
            bool isNewWorkflow = false;
            if (project.Workflows == null || project.Workflows.Count == 0)
            {
                project.Workflows = ProjectWorkflowUtility.FindByCriteria(
                    prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                    ProjectWorkflowManager.FIND_WORKFLOW_BY_PROJECT,
                    new object[] { project.Id });
            }

            ProjectWorkflow projectWorkflow = null;
            if (project.Workflows != null)
            {
                foreach (ProjectWorkflow sf in project.Workflows)
                {
                    if (sf.WorkflowType == workflowType)
                        projectWorkflow = sf;
                }
            }

            if (projectWorkflow == null)
            {
                projectWorkflow = ProjectWorkflowUtility.CreateObject();
                WorkflowList workflow = WorkflowListUtility.GetByName(
                    prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                    workflowType, 0);
                if (workflow != null)
                {
                    projectWorkflow.WorkflowId = workflow.Id;
                    projectWorkflow.WorkflowType = workflow.Type;
                    isNewWorkflow = true;
                }
            }

            if (projectWorkflow.TransactionId == 0)
            {
                projectWorkflow.TransactionId = WorkflowExec.CreateWorkflowHistory(projectWorkflow.WorkflowId);
                if (projectWorkflow.TransactionId == 0) return null;
                if (project.Workflows == null)
                    project.Workflows = new ProjectWorkflowCollection();
                project.Workflows.Add(projectWorkflow);
                ProjectWorkflowUtility.UpdateCollection(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                    project.Id, project.Workflows);

                if (isNewWorkflow)
                    project.Workflows = ProjectWorkflowUtility.FindByCriteria(
                        prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                        ProjectWorkflowManager.FIND_WORKFLOW_BY_PROJECT,
                        new object[] { project.Id });

                NodeAction(project, "New Workflow");
            }
            return projectWorkflow;
        }
        #endregion

        #region Workflow Control
        public static ProjectWorkflow InitialProjectWorkflow(Project project, string workflowName)
        {
            workflowType = workflowName;
            return GetProjectWorkflow(project);
        }

        public static void DeleteProjectWorkflow(ProjectWorkflow projectWorkflow)
        {
            ProjectWorkflowUtility.Delete(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                projectWorkflow.Id);
        }

        public static User GetLastApprover(Project project)
        {
            ProjectWorkflow projectWorkflow = GetProjectWorkflow(project);
            if (projectWorkflow == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectWorkflow.TransactionId);
            if (workflowHistory == null) return null;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return null;

            return UserUtility.Get(prefixDbName + ConstantUtility.USER_DATASOURCE_NAME,
                workflowHistory.ApprovalUserId);
        }

        public static int ProjectWorkflow(Project project, string systemAction, string comments, ref string errmsg, ref string url)
        {
            ProjectWorkflow projectWorkflow = GetProjectWorkflow(project);
            if (projectWorkflow == null) return 0;

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_SYSTEMNAME,
                new object[] { projectWorkflow.WorkflowId, systemAction });
            if (workflowNodes == null || workflowNodes.Count == 0) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectWorkflow.TransactionId);
            if (workflowHistory == null)
                return 0;

            int actionId = 0;
            for (int i = 0; i < workflowNodes.Count; i++)
            {
                if (workflowHistory.CurrentNodeId == workflowNodes[i].NodeFromId)
                {
                    actionId = workflowNodes[i].Id;
                    break;
                }
            }
            return ProjectWorkflow(project, actionId, comments, ref errmsg, ref url);
        }

        public static int ProjectWorkflow(Project project, int actionId, string comments, ref string errmsg, ref string url)
        {
            ProjectWorkflow projectWorkflow = GetProjectWorkflow(project);
            if (projectWorkflow == null) return 0;
            if (actionId == 0) return projectWorkflow.TransactionId;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectWorkflow.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowNode workflowNode = WorkflowNodeUtility.Get(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
            if (workflowNode == null)
                return 0;
            if (workflowHistory.CurrentNodeId != workflowNode.NodeFromId)
                return 0;

            // condition proccessing
            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNode.Id });

            TextReader reader = XmlUtility.Serialize(project);
            XPathDocument doc = new XPathDocument(reader);
            XPathNavigator nav = doc.CreateNavigator();

            errmsg = string.Empty;
            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count == 0)
                    {
                        errmsg += workflowCondition.ErrorMessage + "<br>";
                    }
                }
            }
            if (errmsg != string.Empty) return 0;

            //Workflow topologic
            bool approval = true;
            switch (workflowNode.Action1)
            {
                case "One":
                    break;
                case "Owner":
                    //if (project.BuyerId != userId)
                    //    errmsg = "Only RFx owner / Creator can do this step";
                    break;
                case "All":
                case "Majority":
                case "Count":
                    WorkflowHistoryCollection workflowHistories = WorkflowHistoryUtility.FindByCriteria(
                        prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                        new object[] { projectWorkflow.TransactionId });

                    WorkflowHistoryCollection currentHistories = new WorkflowHistoryCollection();
                    if (workflowHistories != null)
                    {
                        for (int i = workflowHistories.Count - 1; i >= 0; i--)
                        {
                            if (workflowHistories[i].IsActive == 1) break;
                            if (workflowHistories[i].CurrentNodeId != actionId) continue;
                            if (workflowHistories[i].ApprovalUserId == userId)
                            {
                                errmsg = "You already approved this step";
                                return 0;
                            }
                            currentHistories.Add(workflowHistories[i]);
                        }
                    }

                    // Create a history from new approval
                    WorkflowHistory approvalHistory = WorkflowHistoryUtility.CreateObject();
                    approvalHistory.TransactionHeaderId = projectWorkflow.TransactionId;
                    approvalHistory.WorkflowId = projectWorkflow.WorkflowId;
                    approvalHistory.CurrentNodeId = actionId;
                    approvalHistory.ApprovalUserId = WorkflowExec.GetUserId();
                    approvalHistory.ApprovalConditionId = 1;
                    approvalHistory.CreatedBy = workflowHistory.ApprovalUserId;
                    approvalHistory.CreatedType = WorkflowExec.GetUserType();
                    WorkflowHistoryUtility.Create(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, approvalHistory);

                    int approvalKnt = currentHistories.Count + 1;
                    switch (workflowNode.Action1)
                    {
                        case "All":
                            //if (approvalKnt < projectUsers.Count)
                            //    approval = false;
                            break;
                        case "Majority":
                            //if (approvalKnt < projectUsers.Count / 2)
                            //    approval = false;
                            break;
                        case "Count":
                            int knt = ConvertUtility.ConvertInt(workflowNode.Action2);
                            if (approvalKnt < knt)
                                approval = false;
                            break;
                    }
                    break;

                //case "Sequence":
                //    break;
                //case "Timer":
                //    //approve7.Checked = true;
                //    //approveKnt7.Text = workflowNode.Action2;
                //    break;
            }

            if (!approval || errmsg != string.Empty) return projectWorkflow.TransactionId;

            //Action proccessing
            WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE,
                new object[] { workflowNode.Id });

            if (workflowActions != null)
            {
                foreach (WorkflowAction workflowAction in workflowActions)
                {
                    switch (workflowAction.Type)
                    {
                        //Send Email
                        case 1:

                            var emailTask = System.Threading.Tasks.Task.Run(() =>
                            {
                                var emailMsg = workflowAction.FunctionName;
                                //if (project.MultiContract) emailMsg = emailMsg.Replace("BA_", "HB_");
                                CommonUtility.ProjectSendEmail(project, workflowNode, workflowHistory, emailMsg, comments, prefixDbName);
                            });
                            emailTask.ConfigureAwait(false);
                            break;

                        //Action
                        case 2:
                            ProjectAction(project, workflowAction.FunctionName);
                            break;

                        //Redirect page
                        case 3:
                            url = workflowAction.FunctionName;
                            break;
                    }
                }
            }

            if (workflowNode.NodeToId > 0)
            {
                WorkflowNode nextNode = WorkflowNodeUtility.Get(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode.NodeToId);
                WorkflowExec.WorkflowNextStatus(workflowNode.WorkflowId, nextNode.Name, workflowHistory.CurrentNodeId, projectWorkflow.TransactionId, comments);

                //if (comments.Trim() != string.Empty)
                //{
                //    Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.RFD_DATASOURCE_NAME,
                //        "Project", project.Id.ToString());
                //    User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

                //    VendorComment vendorComment = VendorCommentUtility.CreateObject();
                //    vendorComment.UserId = user.Id;
                //    vendorComment.VendorId = vendor.Id;
                //    vendorComment.Comments = "Workflow Comments: " + comments;
                //    vendorComment.Type = "User";
                //    vendorComment.ChangeUser = user.FullName;

                //    VendorCommentUtility.Create(ConstantUtility.RFD_DATASOURCE_NAME, vendorComment);
                //}

                NodeAction(project, comments);
            }

            return projectWorkflow.TransactionId;
        }

        public static int ProjectWorkflow(Project project, string nextStatus, string comments)
        {
            ProjectWorkflow projectWorkflow = GetProjectWorkflow(project);
            if (projectWorkflow == null) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectWorkflow.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowExec.WorkflowNextSystemStatus(projectWorkflow.WorkflowId, nextStatus, workflowHistory.CurrentNodeId, projectWorkflow.TransactionId, comments);

            //if (comments.Trim() != string.Empty)
            //{
            //    Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.RFD_DATASOURCE_NAME,
            //        "Project", project.Id.ToString());
            //    User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

            //    VendorComment vendorComment = VendorCommentUtility.CreateObject();
            //    vendorComment.VendorId = vendor.Id;
            //    vendorComment.Comments = "Workflow Comments: " + comments;
            //    if (user != null)
            //    {
            //        vendorComment.UserId = user.Id;
            //        vendorComment.Type = "User";
            //        vendorComment.ChangeUser = user.FullName;
            //    }

            //    VendorCommentUtility.Create(ConstantUtility.RFD_DATASOURCE_NAME, vendorComment);
            //}

            NodeAction(project, comments);

            return projectWorkflow.TransactionId;
        }

        public static WorkflowConditionCollection ProjectWorkflowConditionTest(Project project, int workflowNodeId)
        {
            ProjectWorkflow projectWorkflow = GetProjectWorkflow(project);
            if (projectWorkflow == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectWorkflow.TransactionId);
            if (workflowHistory == null)
                return null;

            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNodeId });

            XPathDocument doc = new XPathDocument(XmlUtility.Serialize(project));
            XPathNavigator nav = doc.CreateNavigator();

            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count > 0)
                        workflowCondition.Status = 1;
                }
            }
            return workflowConditions;
        }
        #endregion Workflow Control

        #region Workflow Node Action
        private static void NodeAction(Project project, string comments)
        {
            ProjectWorkflow projectWorkflow = GetProjectWorkflow(project);
            if (projectWorkflow == null) return;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(
                projectWorkflow.TransactionId);

            //Hardbid Fix, as Project is based on JM, ID will be greater than zero.
            int status = project.JmId <= 0 ? CommonUtility.GetProjectStatusId(workflowType, workflowHistory.CurrentNode.Name.Trim()) :
                                            CommonUtility.HBGetProjectStatusId(workflowType, workflowHistory.CurrentNode.Name.Trim()) ;
            //switch (workflowType)
            //{
            //    case ConstantUtility.WORKFLOW_BID_AWARD_GENERAL:
            //        ProjectBidAwardStatusType projectBidAwardStatusType = workflowHistory.CurrentNode.Name.Trim();
            //        if (projectBidAwardStatusType != null)
            //            status = projectBidAwardStatusType.Id;
            //        break;
            //}

            if (status == 0 || status == projectWorkflow.Status) return;
            ProjectWorkflowUtility.UpdateStatus(prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME, projectWorkflow.Id, status, workflowHistory.CurrentNode.Name.Trim());

            // automatic step
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { projectWorkflow.WorkflowId, "UserStepId", "ASC" });
            if (workflowNodes != null)
            {
                for (int i = 0; i < workflowNodes.Count; i++)
                {
                    if (workflowNodes[i].Type != 1 || workflowNodes[i].TimeToSkip != 1 ||
                        workflowHistory.CurrentNodeId != workflowNodes[i].NodeFromId)
                        continue;

                    string errmsg = string.Empty;
                    string url = string.Empty;
                    ProjectWorkflow(project, workflowNodes[i].Id, comments, ref errmsg, ref url);
                }
            }
        }

        public static void BackwardUpdateStatus(Project project, string newWorkflowStatusValue, string comments)
        {
            ProjectWorkflow projectWorkflow = GetProjectWorkflow(project);
            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(projectWorkflow.TransactionId);

            string _nodeName = workflowHistory.CurrentNode.Name.Trim();
            int status = project.JmId <= 0 ? CommonUtility.GetProjectStatusId(workflowType, _nodeName) : CommonUtility.HBGetProjectStatusId(workflowType, _nodeName);

            if (status == 0) return;
            ProjectWorkflowUtility.UpdateStatus(ConstantUtility.RFD_DATASOURCE_NAME, projectWorkflow.Id, status, workflowHistory.CurrentNode.Name.Trim());

            ProjectWorkflow(project, newWorkflowStatusValue, comments);
        }

        public static bool IsInBidderAnalysisStage(ProjectWorkflowCollection workflows)
        {
            if (workflows != null)
                return workflows[0].Status == HBGeneralStatusType.BidderSubWorkflowAnalysis;


            return false;
        }

        #endregion Workflow Node Action


        #region Project Action
        private static void ProjectAction(Project project, string actionName)
        {
            string msg = string.Empty;
            string url = string.Empty;
            string tempType = workflowType;
            Bidder lowBidder = null;

            switch (actionName)
            {
                case "SampleAction":
                    //Action Here
                    break;

                case "AwardVettingMerge":
                    project.Workflows = ProjectWorkflowUtility.FindByCriteria(
                        prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                        ProjectWorkflowManager.FIND_WORKFLOW_BY_PROJECT,
                        new object[] { project.Id });

                    ProjectWorkflow paVettingWorkflow = null;
                    ProjectWorkflow vettingBidBondWorkflow = null;
                    ProjectWorkflow vettingFinancialWorkflow = null;
                    ProjectWorkflow vettingRs1Workflow = null;

                    foreach (ProjectWorkflow sf in project.Workflows)
                    {
                        if (sf.WorkflowType == ConstantUtility.WORKFLOW_PRE_AWARD_VETTING
                            || sf.WorkflowType == ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_MENTOR)
                            paVettingWorkflow = sf;

                        if (sf.WorkflowType == ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_BIDBOND_REVIEW)
                        {
                            vettingBidBondWorkflow = sf;
                        }

                        if (sf.WorkflowType == ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_FINANCIAL_REVIEW)
                        {
                            vettingFinancialWorkflow = sf;
                        }

                        if (sf.WorkflowType == ConstantUtility.WORKFLOW_RS1_VETTING)
                        {
                            vettingRs1Workflow = sf;
                        }
                    }



                    if (paVettingWorkflow != null && vettingBidBondWorkflow != null && vettingFinancialWorkflow != null 
                        && (vettingRs1Workflow ==null || vettingRs1Workflow.Status == ProjectRS1VettingStatusType.RS1VettingFinished.Id)
                        && paVettingWorkflow.Status == ProjectPreAwardVettingStatusType.AwardVettingApproved.Id
                        && vettingBidBondWorkflow.Status == ProjectPreAwardVettingBidBondReviewStatusType.ManagerRecommendationApproved.Id
                        && vettingFinancialWorkflow.Status == ProjectPreAwardVettingFinancialReviewStatusType.ManagerRecommendationApproved.Id)
                    {
                        if (paVettingWorkflow.WorkflowType == ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_MENTOR)
                        {
                            workflowType = ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_MENTOR;
                            ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.MentorVettingFinished.Name, "", ref msg, ref url);
                        }
                        else
                        {
                            workflowType = ConstantUtility.WORKFLOW_PRE_AWARD_VETTING;
                            ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.VettingFinished.Name, "", ref msg, ref url);
                        }
                    }
                    else if (paVettingWorkflow != null && vettingBidBondWorkflow != null && vettingFinancialWorkflow != null
                             && (vettingRs1Workflow == null || vettingRs1Workflow.Status == ProjectRS1VettingStatusType.RS1VettingFinished.Id)
                             && (vettingFinancialWorkflow.Status == ProjectPreAwardVettingFinancialReviewStatusType.ManagerRecommendationFailed.Id || vettingFinancialWorkflow.Status == ProjectPreAwardVettingFinancialReviewStatusType.ManagerRecommendationApproved.Id)
                             && (vettingBidBondWorkflow.Status == ProjectPreAwardVettingBidBondReviewStatusType.ManagerRecommendationFailed.Id  || vettingBidBondWorkflow.Status == ProjectPreAwardVettingBidBondReviewStatusType.ManagerRecommendationApproved.Id)
                             && (paVettingWorkflow.Status == ProjectPreAwardVettingStatusType.AwardVettingDisapproved.Id || paVettingWorkflow.Status == ProjectPreAwardVettingStatusType.AwardVettingApproved.Id))
                    {

                        if (vettingFinancialWorkflow.Status == ProjectPreAwardVettingFinancialReviewStatusType.ManagerRecommendationFailed.Id ||
                            vettingBidBondWorkflow.Status == ProjectPreAwardVettingBidBondReviewStatusType.ManagerRecommendationFailed.Id ||
                            paVettingWorkflow.Status == ProjectPreAwardVettingStatusType.AwardVettingDisapproved.Id )
                        {
                            workflowType = ConstantUtility.WORKFLOW_BID_AWARD_GENERAL;
                            ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.VettingDirectorReview.Name, "", ref msg, ref url);
                        }
                    }




                    break;

                //case "OIG_Approve":
                //    workflowType = ConstantUtility.WORKFLOW_BID_AWARD_GENERAL;
                //    ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.OIGApprove.Name, "", ref msg, ref url);
                //    break;
                case "VettingDirectorApproved":
                    if (project.Type != "Mentor")
                    {
                        ProjectWorkflowExec.WorkflowType = ConstantUtility.WORKFLOW_PRE_AWARD_VETTING;
                        ProjectWorkflowExec.ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.VettingFinished.Name, "", ref msg, ref url);
                    }
                    else
                    {
                        ProjectWorkflowExec.WorkflowType = ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_MENTOR;
                        ProjectWorkflowExec.ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.MentorVettingFinished.Name, "", ref msg, ref url);

                    }

                    break;
                case "CheckMentorFinancing":
                    if (project.Type != "Mentor")
                    {
                        workflowType = ConstantUtility.WORKFLOW_BID_BREAKDOWN_ANALYSIS;
                        ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.FinancingVerification.Name, "No need for Financing Verification", ref msg, ref url);
                    }
                    else
                    {
                        workflowType = ConstantUtility.WORKFLOW_BID_MENTOR;
                        ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.MentorFinancialNew.Name, "", ref msg, ref url);

                        workflowType = ConstantUtility.WORKFLOW_BID_AWARD_GENERAL;
                        ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.PendingMentorFinancingAction.Name, "", ref msg, ref url);
                    }
                    break;

                case "Bypass_President":
                    if (project.Type == "Mentor")
                    {
                        workflowType = ConstantUtility.WORKFLOW_BID_BREAKDOWN_ANALYSIS;
                        ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.MentorFinancialNew.Name, "", ref msg, ref url);
                    }
                    break;

                case "CreateRS1Subcontractors":

                    lowBidder = BidderUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, project.AwardBidderId);

                    BidderWicksCollection wicks = BidderWicksUtility.FindByCriteria(
                        ConstantUtility.RFD_DATASOURCE_NAME,
                        BidderWicksManager.FIND_BY_BIDDER,
                        new object[] { lowBidder.Id });

                    Supplier prime = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, lowBidder.SupplierId);



                    if (project.Type == "Mentor")
                    {

                        if (wicks != null)
                        {
                            Supplier supplier = null;
                            if (wicks[0].ElectricalSupplierId > 0)
                            {
                                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, wicks[0].ElectricalSupplierId);
                                if (supplier != null)
                                      RS1SubcontractorUtility.CreateRS1Subcontractor(ConstantUtility.SUPPLIER_DATASOURCE_NAME,project,
                                        prime, supplier, "Electrical", wicks[0].ElectricalBidAmount); 
                            
                            }

                            if (wicks[0].PlumbingSupplierId > 0)
                            {
                                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, wicks[0].PlumbingSupplierId);
                                if (supplier != null)
                                    RS1SubcontractorUtility.CreateRS1Subcontractor(ConstantUtility.SUPPLIER_DATASOURCE_NAME,  project,
                                        prime, supplier, "Plumbing", wicks[0].PlumbingBidAmount);
                            }

                            if (wicks[0].HVACSupplierId > 0)
                            {
                                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, wicks[0].HVACSupplierId);
                                if (supplier != null)
                                    RS1SubcontractorUtility.CreateRS1Subcontractor(ConstantUtility.SUPPLIER_DATASOURCE_NAME, project,
                                        prime, supplier, "HVAC", wicks[0].HVACBidAmount);
                            }
                        }


                     

                    }
                    else
                    {
                        if (wicks != null)
                        {
                            Supplier supplier = null;
                            if (wicks[0].ElectricalSupplierId > 0)
                            {
                                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, wicks[0].ElectricalSupplierId);
                                if (supplier != null)
                                    CommonUtility.CreateSubcontractor(project, prime, supplier, "Electrical", wicks[0].ElectricalBidAmount);
                            }

                            if (wicks[0].PlumbingSupplierId > 0)
                            {
                                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, wicks[0].PlumbingSupplierId);
                                if (supplier != null)
                                    CommonUtility.CreateSubcontractor(project, prime, supplier, "Plumbing", wicks[0].PlumbingBidAmount);
                            }

                            if (wicks[0].HVACSupplierId > 0)
                            {
                                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, wicks[0].HVACSupplierId);
                                if (supplier != null)
                                    CommonUtility.CreateSubcontractor(project, prime, supplier, "HVAC", wicks[0].HVACBidAmount);
                            }
                        }
                    }
                    
                    break;

                case "Vetting_Breakdown_Finance_Merge":
                    project.Workflows = ProjectWorkflowUtility.FindByCriteria(
                        prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                        ProjectWorkflowManager.FIND_WORKFLOW_BY_PROJECT,
                        new object[] { project.Id });

                    ProjectWorkflow preAwardVettingWorkflow = null;
                    ProjectWorkflow bidBreakdownWorkflow = null;
                    ProjectWorkflow bidMentorFinnWorkflow = null;


                    foreach (ProjectWorkflow sf in project.Workflows)
                    {
                        if (sf.WorkflowType == ConstantUtility.WORKFLOW_PRE_AWARD_VETTING
                            || sf.WorkflowType == ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_MENTOR)
                            preAwardVettingWorkflow = sf;
                        if (sf.WorkflowType == ConstantUtility.WORKFLOW_BID_BREAKDOWN_ANALYSIS)
                            bidBreakdownWorkflow = sf;
                        if (sf.WorkflowType == ConstantUtility.WORKFLOW_BID_MENTOR_FINANCE)
                            bidMentorFinnWorkflow = sf;

                    }

                    if (preAwardVettingWorkflow != null && bidBreakdownWorkflow != null
                        && preAwardVettingWorkflow.Status == ProjectPreAwardVettingStatusType.AwardVettingFinished.Id
                        && bidBreakdownWorkflow.Status == ProjectBidBreakdownAnalysisStatusType.LowBidderAccepted.Id
                        && (bidMentorFinnWorkflow == null || bidMentorFinnWorkflow.Status == ProjectBidMentorFinanceStatusType.BudgetAdjustmentSubmitted.Id
                                                          || bidMentorFinnWorkflow.Status == ProjectBidMentorFinanceStatusType.FinancingInfoSubmitted.Id))
                    {
                        //set final amount for low bidder
                        lowBidder = BidderUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, project.AwardBidderId);
                        if (lowBidder.IsBAFO == "Y")
                        {
                            ProjectBAFOCollection bafos = ProjectBAFOUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME,
                                    ProjectBAFOManager.FIND_BY_PROJECT,
                                    new object[] { project.Id });
                            if (bafos != null && bafos.Count > 0)
                                foreach (ProjectBAFO bafo in bafos)
                                    if (bafo.BidderId == lowBidder.Id && bafo.IsFinal == "Y")
                                    {
                                        lowBidder.FinalAmt = bafo.Amount;
                                        break;
                                    }
                        }
                        else
                        {
                            lowBidder.FinalAmt = lowBidder.BidAmt;
                        }
                        BidderUtility.Update(ConstantUtility.RFD_DATASOURCE_NAME, lowBidder);

                        if (project.Type != "Mentor")
                        {
                            //create contract
                            Contract contract = ContractUtility.CreateObject();
                            contract.ProjectId = project.Id;
                            contract.Type = project.Type;
                            contract.SolicitSeq = project.SolicitSeq;
                            contract.ProjectDuration = project.ProjectDuration;
                            contract.AltProjectDuration = project.AltProjectDuration;
                            contract.Description = project.Description;
                            contract.SolicitationNo = project.SolicitationNo;
                            contract.SupplierId = project.AwardSupplierId;
                            contract.BidderId = project.AwardBidderId;
                            contract.Amount = lowBidder.FinalAmt;
                            contract.IsBAFO = lowBidder.IsBAFO;
                            contract.IsLowest = lowBidder.Rank == 1 ? "Y" : "N";
                            contract.ExecutionDate = DateTime.Now;

                            if (ContractUtility.Create(ConstantUtility.RFD_DATASOURCE_NAME, contract))
                            {
                                ProjectUtility.UpdateContractNo(ConstantUtility.RFD_DATASOURCE_NAME, contract.Id);

                                workflowType = ConstantUtility.WORKFLOW_BID_AWARD_GENERAL;
                                ProjectWorkflow(project, ProjectBidAwardStatusType.VettingandBidBreakdownAnalysis.Name, "");
                                ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.FinishVettingBreakdown.Name, "", ref msg, ref url);

                            }

                        }
                        else
                        {
                            workflowType = ConstantUtility.WORKFLOW_BID_MENTOR;
                            ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.PendingMentorCPOReviewAction.Name, "", ref msg, ref url);

                            workflowType = ConstantUtility.WORKFLOW_BID_AWARD_GENERAL;
                            ProjectWorkflow(project, ProjectBidAwardStatusType.VettingandBidBreakdownAnalysis.Name, "");
                            ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.PendingMentorReviewsAction.Name, "", ref msg, ref url);
                        }


                    }
                    break;
                case "Routing_Approval_Start":

                    //workflowType = ConstantUtility.WORKFLOW_ROUTING_ADMIN;
                    //ProjectWorkflow(project, ProjectRoutingAdminStatusType.PendingAdminReview.Name, "");
          
                    workflowType = ConstantUtility.WORKFLOW_ROUTING_VPCM;
                    ProjectWorkflow(project, ProjectRoutingVPCMStatusType.PendingVPCMReview.Name, "");
                    workflowType = ConstantUtility.WORKFLOW_ROUTING_FINANCE;
                    ProjectWorkflow(project, ProjectRoutingFinanceStatusType.PendingFinanceReview.Name, "");
                    workflowType = ConstantUtility.WORKFLOW_ROUTING_OIG;
                    ProjectWorkflow(project, ProjectRoutingOIGStatusType.PendingOIGBidderReview.Name, "");

                    //if (project.Type == "Line")
                    //{
                    //    workflowType = ConstantUtility.WORKFLOW_ROUTING_BDD;
                    //    ProjectWorkflow(project, ProjectRoutingBDDStatusType.PendingBDDReview.Name, "");
                    //}


                    // TO DO : Confirm this with William/Rima ; Mentioned in the meeting 
                    workflowType = ConstantUtility.WORKFLOW_ROUTING_CQU;
                    ProjectWorkflow(project, ProjectRoutingCQUStatusType.PendingCQUReview.Name, "");
                    //if (project.Type == "Mentor")
                    //{
                    //    workflowType = ConstantUtility.WORKFLOW_ROUTING_BDD;
                    //    ProjectWorkflow(project, ProjectRoutingBDDStatusType.PendingBDDReview.Name, "");
                    //}
                    //else
                    //{
                    //    workflowType = ConstantUtility.WORKFLOW_ROUTING_CQU;
                    //    ProjectWorkflow(project, ProjectRoutingCQUStatusType.PendingCQUReview.Name, "");
                    //}

                    break;
                case "Routing_Approval_Start_Admin":
                    workflowType = ConstantUtility.WORKFLOW_ROUTING_ADMIN;
                    ProjectWorkflow(project, ProjectRoutingAdminStatusType.PendingAdminReview.Name, "");
                    break;
                case "Routing_Approval_Complete":
                    project.Workflows = ProjectWorkflowUtility.FindByCriteria(
                        prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                        ProjectWorkflowManager.FIND_WORKFLOW_BY_PROJECT,
                        new object[] { project.Id });

                    //ProjectWorkflow adminWorkflow = null;
                    //ProjectWorkflow bddWorkflow = null;
                    ProjectWorkflow cquWorkflow = null;
                    ProjectWorkflow vpcmWorkflow = null;
                    ProjectWorkflow financeWorkflow = null;
                    ProjectWorkflow oigWorkflow = null;

                    foreach (ProjectWorkflow sf in project.Workflows)
                    {
                        if (sf.WorkflowType == ConstantUtility.WORKFLOW_ROUTING_OIG)
                            oigWorkflow = sf;
                        //else if (sf.WorkflowType == ConstantUtility.WORKFLOW_ROUTING_ADMIN)
                        //    adminWorkflow = sf;
                        //else if (sf.WorkflowType == ConstantUtility.WORKFLOW_ROUTING_BDD)
                        //    bddWorkflow = sf;
                        else if (sf.WorkflowType == ConstantUtility.WORKFLOW_ROUTING_CQU)
                            cquWorkflow = sf;
                        else if (sf.WorkflowType == ConstantUtility.WORKFLOW_ROUTING_VPCM)
                            vpcmWorkflow = sf;
                        else if (sf.WorkflowType == ConstantUtility.WORKFLOW_ROUTING_FINANCE)
                            financeWorkflow = sf;
                    }

                    if (
                            // adminWorkflow != null && adminWorkflow.Status == ProjectRoutingAdminStatusType.AdminReviewCompleted.Id
                            cquWorkflow != null && cquWorkflow.Status == ProjectRoutingCQUStatusType.CQUReviewCompleted.Id
                            && vpcmWorkflow != null && vpcmWorkflow.Status == ProjectRoutingVPCMStatusType.VPCMReviewCompleted.Id
                            && financeWorkflow != null && financeWorkflow.Status == ProjectRoutingFinanceStatusType.FinanceReviewCompleted.Id
                            && oigWorkflow != null && oigWorkflow.Status == ProjectRoutingOIGStatusType.OIGBidderReviewCompleted.Id
                          //  && ((project.Type != "Line") || (bddWorkflow != null && bddWorkflow.Status == ProjectRoutingBDDStatusType.BDDReviewCompleted.Id))   //only line project require BDD Review
                            )
                    {
                        workflowType = ConstantUtility.WORKFLOW_BID_AWARD_GENERAL;
                        ProjectWorkflow(project, SCA.VAS.Workflow.ProjectAction.RoutingPackageApprovalComplete.Name, "", ref msg, ref url);
                    }
                    break;
                case "RequestToRe-Vett":
                    project.Workflows = ProjectWorkflowUtility.FindByCriteria(
                        prefixDbName + ConstantUtility.RFD_DATASOURCE_NAME,
                        ProjectWorkflowManager.FIND_WORKFLOW_BY_PROJECT,
                        new object[] { project.Id });

                    ProjectWorkflow paVettingWorkflow2 = null;
                    ProjectWorkflow vettingBidBondWorkflow2 = null;
                    ProjectWorkflow vettingFinancialWorkflow2 = null;
        

                    foreach (ProjectWorkflow sf in project.Workflows)
                    {
                        switch (sf.WorkflowType)
                        {
                            case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING:
                            case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_MENTOR:
                                paVettingWorkflow2 = sf;
                                break;
                            case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_BIDBOND_REVIEW:
                                vettingBidBondWorkflow2 = sf;
                                break;
                            case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_FINANCIAL_REVIEW:
                                vettingFinancialWorkflow2 = sf;
                                break;
                        }
                    }


                    if (vettingFinancialWorkflow2 !=null 
                        && vettingFinancialWorkflow2.Status ==ProjectPreAwardVettingFinancialReviewStatusType.ManagerRecommendationFailed.Id) 
                    {
                        workflowType = ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_FINANCIAL_REVIEW;
                        ProjectWorkflow(project, ProjectPreAwardVettingFinancialReviewStatusType.PendingFinancialVetting.Name, "");
                    }

                    if (vettingBidBondWorkflow2 != null  
                        && vettingBidBondWorkflow2.Status == ProjectPreAwardVettingBidBondReviewStatusType.ManagerRecommendationFailed.Id)
                    {
                        workflowType = ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_BIDBOND_REVIEW;
                        ProjectWorkflow(project, ProjectPreAwardVettingBidBondReviewStatusType.PendingBidBondVetting.Name, "");
                    }


                    if (project.Type == "Mentor")
                    {
                        if (paVettingWorkflow2 != null
                            &&  paVettingWorkflow2.Status == ProjectPreAwardVettingMentorStatusType.AwardVettingDisapproved.Id)
                        {
                            WorkflowType = ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_MENTOR;
                            ProjectWorkflow(project, ProjectPreAwardVettingMentorStatusType.MentorAwardVettingRequested.Name, "");

                        }
                    }
                    else
                    {
                        if (paVettingWorkflow2 != null && paVettingWorkflow2.Status == ProjectPreAwardVettingStatusType.AwardVettingDisapproved.Id )
                        {
                            WorkflowType = ConstantUtility.WORKFLOW_PRE_AWARD_VETTING;
                            ProjectWorkflow(project, ProjectPreAwardVettingStatusType.AwardVettingRequested.Name, "");
                        }
                    }

                    break;

            }
            WorkflowType = tempType;
        }
        #endregion
    }
}
