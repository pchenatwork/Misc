#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ProjectBidAwardStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ProjectBidAwardStatusConverter))]
    public class ProjectBidAwardStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly ProjectBidAwardStatusType NewBidAward = new ProjectBidAwardStatusType(0, "NewBidAward", "New Bid Award");
        public static readonly ProjectBidAwardStatusType RFCPrepared = new ProjectBidAwardStatusType(1, "RFCPrepared", "Pending Project Assignment");
        public static readonly ProjectBidAwardStatusType ProjectAssigned = new ProjectBidAwardStatusType(2, "ProjectAssigned", "Pending CS Review");
        public static readonly ProjectBidAwardStatusType CSReviewed = new ProjectBidAwardStatusType(3, "CSReviewed", "Pending Solicitation Pkg creation");
        public static readonly ProjectBidAwardStatusType PendingMgrSolicitationReview = new ProjectBidAwardStatusType(4, "PendingMgrSolicitationReview", "Pending Mgr Solicitation Review");
        public static readonly ProjectBidAwardStatusType PendingCSRevision = new ProjectBidAwardStatusType(5, "PendingCSRevision", "Solicitation Pkg returned by Mgr");
        public static readonly ProjectBidAwardStatusType CSRevised = new ProjectBidAwardStatusType(6, "CSRevised", "Revised CS Review");
        public static readonly ProjectBidAwardStatusType PendingDirSolicitationReview = new ProjectBidAwardStatusType(7, "PendingDirSolicitationReview", "Pending Dir Solicitation Review");
        public static readonly ProjectBidAwardStatusType PendingCSRevision1 = new ProjectBidAwardStatusType(8, "PendingCSRevision1", "Solicitation Pkg returned by Director");
        public static readonly ProjectBidAwardStatusType CSRevised1 = new ProjectBidAwardStatusType(9, "CSRevised1", "Revised CS Review 1");
        public static readonly ProjectBidAwardStatusType PendingIFBIssuance = new ProjectBidAwardStatusType(10, "PendingIFBIssuance", "Pending IFB Issuance");
        public static readonly ProjectBidAwardStatusType PendingReproduction = new ProjectBidAwardStatusType(11, "PendingReproduction", "Pending Reproduction");
        public static readonly ProjectBidAwardStatusType DocumentsAvailable = new ProjectBidAwardStatusType(12, "DocumentsAvailable", "Pending Recording of Bidders");

        //Bid Document Review/Approval Workflow
        public static readonly ProjectBidAwardStatusType TradesSelected = new ProjectBidAwardStatusType(13, "TradesSelected", "Trades Selected");

        // Bid Pending Next low 
        public static readonly ProjectBidAwardStatusType PendingNextBidderSelection = new ProjectBidAwardStatusType(14, "PendingNextBidderSelection", "Pending Next Low Bidder Selection");

        // Bid Recording Workflow
        public static readonly ProjectBidAwardStatusType PendingBidOpening = new ProjectBidAwardStatusType(30, "PendingBidOpening", "Pending Bid Opening");
        public static readonly ProjectBidAwardStatusType BiddingClosed = new ProjectBidAwardStatusType(31, "BiddingClosed", "Pending Bid Certification");
        public static readonly ProjectBidAwardStatusType PendingBidReview = new ProjectBidAwardStatusType(32, "PendingBidReview", "Pending Bid Review");
        public static readonly ProjectBidAwardStatusType VettingandBidBreakdownAnalysis = new ProjectBidAwardStatusType(33, "VettingandBidBreakdownAnalysis", "Vetting and Bid Breakdown Analysis");
        public static readonly ProjectBidAwardStatusType BAFORejected = new ProjectBidAwardStatusType(34, "BAFORejected", "BAFO Rejected");

        // Bid recording workflow status for exceptions or not-happy paths
        public static readonly ProjectBidAwardStatusType PendingReconcileBidderCollusion = new ProjectBidAwardStatusType(35, "PendingReconcileBidderCollusion", "Pending Reconcile Bidder Collusion");

        // Contract Package Creation Workflow
        public static readonly ProjectBidAwardStatusType PendingRoutingPkgCreation = new ProjectBidAwardStatusType(41, "PendingRoutingPkgCreation", "Pending Routing Pkg Creation");
        public static readonly ProjectBidAwardStatusType PendingMgrRoutingPkgReview = new ProjectBidAwardStatusType(42, "PendingMgrRoutingPkgReview", "Pending Mgr Routing Pkg Review");
        public static readonly ProjectBidAwardStatusType RoutingPkgPendingCSRevision = new ProjectBidAwardStatusType(43, "RoutingPkgPendingCSRevision", "Routing Pkg returned by Mgr");
        public static readonly ProjectBidAwardStatusType RoutingPkgRevised = new ProjectBidAwardStatusType(44, "RoutingPkgRevised", "Revised Routing Pkg pending Manager Review");
        public static readonly ProjectBidAwardStatusType PendingDirRoutingPkgReview = new ProjectBidAwardStatusType(45, "PendingDirRoutingPkgReview", "Pending Dir Routing Pkg Review");
        public static readonly ProjectBidAwardStatusType RoutingPkgPendingCSRevision1 = new ProjectBidAwardStatusType(46, "RoutingPkgPendingCSRevision1", "Routing Pkg returned by Director");
        public static readonly ProjectBidAwardStatusType RoutingPkgRevised1 = new ProjectBidAwardStatusType(47, "RoutingPkgRevised1", "Revised Routing Pkg pending Director Review");

        // Routing Package Approval Workflow
        public static readonly ProjectBidAwardStatusType PendingRoutingPackageApproval = new ProjectBidAwardStatusType(51, "PendingRoutingPackageApproval", "Pending Routing Package Approval");

        // Contract Execution Workflow
        public static readonly ProjectBidAwardStatusType PendingExecutionPkgCreation = new ProjectBidAwardStatusType(61, "PendingExecutionPkgCreation", "Pending Execution Pkg Creation");
        public static readonly ProjectBidAwardStatusType ExecutionPackageOnHold = new ProjectBidAwardStatusType(62, "ExecutionPackageOnHold", "Execution Package On Hold");
        public static readonly ProjectBidAwardStatusType PendingLegalReview = new ProjectBidAwardStatusType(63, "PendingLegalReview", "Pending Legal Execution Pkg Review");
        public static readonly ProjectBidAwardStatusType ExecutionPkgPendingCSRevision = new ProjectBidAwardStatusType(64, "ExecutionPkgPendingCSRevision", "Execution Pkg returned by Sr. Dir Contracts");
        public static readonly ProjectBidAwardStatusType ExecutionPkgRevised = new ProjectBidAwardStatusType(65, "ExecutionPkgRevised", "Revised Execution Pkg pending Review");
        public static readonly ProjectBidAwardStatusType PendingPresidentReview = new ProjectBidAwardStatusType(66, "PendingPresidentReview", "Pending President Execution Pkg Review");
        public static readonly ProjectBidAwardStatusType PendingVPCPReview = new ProjectBidAwardStatusType(176, "PendingVPCPReview", "Pending VP CP Execution Pkg Review");
        public static readonly ProjectBidAwardStatusType PendingEVPReview = new ProjectBidAwardStatusType(177, "PendingEVPReview", "Pending EVP Execution Pkg Review");
        public static readonly ProjectBidAwardStatusType ExecutionPkgPendingCSRevision2 = new ProjectBidAwardStatusType(178, "ExecutionPkgPendingCSRevision2", "Execution Pkg returned by VP CP");
        public static readonly ProjectBidAwardStatusType ExecutionPkgPendingCSRevision3 = new ProjectBidAwardStatusType(179, "ExecutionPkgPendingCSRevision3", "Execution Pkg returned by EVP");


        public static readonly ProjectBidAwardStatusType PendingPresidentApproval = new ProjectBidAwardStatusType(67, "PendingPresidentApproval", "Pending President Approval");
        public static readonly ProjectBidAwardStatusType PendingNoticeofAward = new ProjectBidAwardStatusType(68, "PendingNoticeofAward", "Pending Notice of Award");
        public static readonly ProjectBidAwardStatusType ContractAwarded = new ProjectBidAwardStatusType(69, "ContractAwarded", "Contract Awarded");

        public static readonly ProjectBidAwardStatusType PendingSrDirectorReview = new ProjectBidAwardStatusType(163, "PendingSrDirectorReview", "Pending Sr. Dir Contracts Execution Pkg Review");
        public static readonly ProjectBidAwardStatusType ExecutionPkgPendingCSRevision1 = new ProjectBidAwardStatusType(164, "ExecutionPkgPendingCSRevision1", "Execution Pkg returned by Legal");
        public static readonly ProjectBidAwardStatusType ExecutionPkgRevised1 = new ProjectBidAwardStatusType(165, "ExecutionPkgRevised1", "Revised Execution Pkg pending Review");


        // Routing to Finance Workflow 
        public static readonly ProjectBidAwardStatusType PendingIntenttoAwardNotice = new ProjectBidAwardStatusType(70, "PendingIntenttoAwardNotice", "Pending Notice of Intent to Award");
        public static readonly ProjectBidAwardStatusType IntenttoAwardOnHold = new ProjectBidAwardStatusType(71, "IntenttoAwardOnHold", "Intent to Award On Hold");

        // Routing to OIG Workflow 
        public static readonly ProjectBidAwardStatusType RoutingToOIGBidderReview = new ProjectBidAwardStatusType(72, "RoutingToOIGBidderReview", "Routing To OIG Bidder Review");
        
        // Mentor Workflow 
        public static readonly ProjectBidAwardStatusType PendingMentorFinancing = new ProjectBidAwardStatusType(73, "PendingMentorFinancing", "Pending Mentor Financing");
        public static readonly ProjectBidAwardStatusType PendingMentorCMReview = new ProjectBidAwardStatusType(74, "PendingMentorCMReview", "Pending Mentor CM Review");
        public static readonly ProjectBidAwardStatusType PendingMentorReviews = new ProjectBidAwardStatusType(174, "PendingMentorReviews", "Pending Mentor Reviews");


        public static readonly ProjectBidAwardStatusType PendingCancel = new ProjectBidAwardStatusType(75, "PendingCancel", "Pending Cancel");        
        public static readonly ProjectBidAwardStatusType Canceled = new ProjectBidAwardStatusType(76, "Canceled", "Canceled");       
        public static readonly ProjectBidAwardStatusType OnHold = new ProjectBidAwardStatusType(77, "OnHold", "On Hold");



        public static readonly ProjectBidAwardStatusType Reproduction = new ProjectBidAwardStatusType(1000, "Reproduction", "Reproduction");

        public static readonly ProjectBidAwardStatusType CanceledProjectFromBreakDown = new ProjectBidAwardStatusType(167, "CanceledProjectFromBreakDown", "Project Canceled From Bid BreakDown Analysis");
        public static readonly ProjectBidAwardStatusType RebidProjectFromBreakDown = new ProjectBidAwardStatusType(168, "RebidProjectFromBreakDown", "Rebid From Bid BreakDown Analysis");
        public static readonly ProjectBidAwardStatusType Rebid  = new ProjectBidAwardStatusType(169, "Rebid", "Rebid");

        public static readonly ProjectBidAwardStatusType PendingVettingDirectorReview = new ProjectBidAwardStatusType(170, "PendingVettingDirectorReview", "Pending Vetting Director Review");
        public static readonly ProjectBidAwardStatusType VettingDirectorRequestToReVett = new ProjectBidAwardStatusType(171, "VettingDirectorRequestToReVett", "Vetting Director Request To Re-Vett");
        public static readonly ProjectBidAwardStatusType VettingDirectorApproved = new ProjectBidAwardStatusType(172, "VettingDirectorApproved", "Vetting Director Approved");
        public static readonly ProjectBidAwardStatusType VettingDirectorDisapproved = new ProjectBidAwardStatusType(173, "VettingDirectorDisapproved", "Vetting Director Disapproved");



        #endregion

        #region Constructors
        public ProjectBidAwardStatusType()
        {
        }

        private ProjectBidAwardStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectBidAwardStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ProjectBidAwardStatus.  
        /// </summary>
        public static ProjectBidAwardStatusType Default
        {
            get
            {
                return (ProjectBidAwardStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectBidAwardStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }

        public static List<ProjectBidAwardStatusType> GetList()
        {
            return _list.Cast<ProjectBidAwardStatusType>().OrderBy(e => e.Name).ToList();
        }

        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((ProjectBidAwardStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectBidAwardStatus object.
        /// It allows a string to be assigned to a ProjectBidAwardStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ProjectBidAwardStatusType(int id)
        {
            return (ProjectBidAwardStatusType)EnumerationBase.FindById(id, ProjectBidAwardStatusType._list);
        }
        public static implicit operator ProjectBidAwardStatusType(string name)
        {
            for (int i = 0; i < ProjectBidAwardStatusType._list.Count; i++)
            {
                if (((ProjectBidAwardStatusType)ProjectBidAwardStatusType._list[i]).Description == name)
                    return (ProjectBidAwardStatusType)ProjectBidAwardStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectBidAwardStatus objects.
    /// It's very useful when binding ProjectBidAwardStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ProjectBidAwardStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ProjectBidAwardStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectBidAwardStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ProjectBidAwardStatusType._list.Count; i++)
            {
                list.Add(((ProjectBidAwardStatusType)ProjectBidAwardStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
