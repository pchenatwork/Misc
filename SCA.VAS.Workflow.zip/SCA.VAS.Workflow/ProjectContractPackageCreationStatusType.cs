#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ProjectContractPackageCreationStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ProjectContractPackageCreationStatusConverter))]
    public class ProjectContractPackageCreationStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly ProjectContractPackageCreationStatusType NewPrequalification = new ProjectContractPackageCreationStatusType(0, "NewPrequalification", "New Qualification");
        public static readonly ProjectContractPackageCreationStatusType ApplicationSubmitted = new ProjectContractPackageCreationStatusType(1, "ApplicationSubmitted", "Application Submitted");
        public static readonly ProjectContractPackageCreationStatusType ManagerReviewed = new ProjectContractPackageCreationStatusType(2, "ManagerReviewed", "Manager Reviewed");
        public static readonly ProjectContractPackageCreationStatusType ReviewerReviewed = new ProjectContractPackageCreationStatusType(3, "ReviewerReviewed", "Reviewer Reviewed");
        public static readonly ProjectContractPackageCreationStatusType RequestMoreInfoPending = new ProjectContractPackageCreationStatusType(4, "RequestMoreInfoPending", "Request More Info Pending");
        public static readonly ProjectContractPackageCreationStatusType RequestMoreInfo = new ProjectContractPackageCreationStatusType(5, "RequestMoreInfo", "Request More Info");
        public static readonly ProjectContractPackageCreationStatusType AdditionalInfoSubmitted = new ProjectContractPackageCreationStatusType(6, "AdditionalInfoSubmitted", "Additional Info Submitted");
        public static readonly ProjectContractPackageCreationStatusType ReferenceReviewed = new ProjectContractPackageCreationStatusType(7, "ReferenceReviewed", "Reference Reviewed");
        public static readonly ProjectContractPackageCreationStatusType FinacialReviewed = new ProjectContractPackageCreationStatusType(8, "FinacialReviewed", "Financial Reviewed");
        public static readonly ProjectContractPackageCreationStatusType AllReviewed = new ProjectContractPackageCreationStatusType(9, "AllReviewed", "Reference and Financial Reviewed");
        public static readonly ProjectContractPackageCreationStatusType OIGApproved = new ProjectContractPackageCreationStatusType(10, "OIGApproved", "OIG Approved");
        public static readonly ProjectContractPackageCreationStatusType QualifiedPending = new ProjectContractPackageCreationStatusType(11, "QualifiedPending", "Qualified Pending");
        public static readonly ProjectContractPackageCreationStatusType Qualified = new ProjectContractPackageCreationStatusType(12, "Qualified", "Qualified");
        public static readonly ProjectContractPackageCreationStatusType PreDeny = new ProjectContractPackageCreationStatusType(13, "PreDeny", "PreDeny");
        public static readonly ProjectContractPackageCreationStatusType AdministrativelyClosed = new ProjectContractPackageCreationStatusType(14, "AdministrativelyClosed", "Administratively Closed");
        public static readonly ProjectContractPackageCreationStatusType DirectorClosePending = new ProjectContractPackageCreationStatusType(15, "DirectorClosePending", "Director Close Pending");
        public static readonly ProjectContractPackageCreationStatusType DirectorClosed = new ProjectContractPackageCreationStatusType(16, "DirectorClosed", "Director Closed");
        public static readonly ProjectContractPackageCreationStatusType Inactive = new ProjectContractPackageCreationStatusType(17, "Inactive", "Inactive");
        public static readonly ProjectContractPackageCreationStatusType Disqualified = new ProjectContractPackageCreationStatusType(18, "Disqualified", "Disqualified");
        public static readonly ProjectContractPackageCreationStatusType Withdrawn = new ProjectContractPackageCreationStatusType(19, "Withdrawn", "Withdrawn");
        public static readonly ProjectContractPackageCreationStatusType OIGReviewed = new ProjectContractPackageCreationStatusType(20, "OIGReviewed", "OIG Reviewed");
        public static readonly ProjectContractPackageCreationStatusType Rescinded = new ProjectContractPackageCreationStatusType(21, "Rescinded", "Rescinded");
        public static readonly ProjectContractPackageCreationStatusType Suspended = new ProjectContractPackageCreationStatusType(22, "Suspended", "Suspended");
        public static readonly ProjectContractPackageCreationStatusType RequestMoreInfo2 = new ProjectContractPackageCreationStatusType(23, "RequestMoreInfo2", "Request More Info 2");
        public static readonly ProjectContractPackageCreationStatusType AdditionalInfoSubmitted2 = new ProjectContractPackageCreationStatusType(24, "AdditionalInfoSubmitted2", "Additional Info Submitted 2");
        public static readonly ProjectContractPackageCreationStatusType Deny = new ProjectContractPackageCreationStatusType(25, "Deny", "Deny");
        public static readonly ProjectContractPackageCreationStatusType Expired = new ProjectContractPackageCreationStatusType(26, "Expired", "Expired");
        public static readonly ProjectContractPackageCreationStatusType OIGPending = new ProjectContractPackageCreationStatusType(27, "OIGPending", "OIG Pending");
        #endregion

        #region Constructors
        public ProjectContractPackageCreationStatusType()
        {
        }

        private ProjectContractPackageCreationStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectContractPackageCreationStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ProjectContractPackageCreationStatus.  
        /// </summary>
        public static ProjectContractPackageCreationStatusType Default
        {
            get
            {
                return (ProjectContractPackageCreationStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectContractPackageCreationStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }

        public static List<ProjectContractPackageCreationStatusType> GetList()
        {
            return _list.Cast<ProjectContractPackageCreationStatusType>().OrderBy(e => e.Id).ToList();
        }

        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((ProjectContractPackageCreationStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectContractPackageCreationStatus object.
        /// It allows a string to be assigned to a ProjectContractPackageCreationStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ProjectContractPackageCreationStatusType(int id)
        {
            return (ProjectContractPackageCreationStatusType)EnumerationBase.FindById(id, ProjectContractPackageCreationStatusType._list);
        }
        public static implicit operator ProjectContractPackageCreationStatusType(string name)
        {
            for (int i = 0; i < ProjectContractPackageCreationStatusType._list.Count; i++)
            {
                if (((ProjectContractPackageCreationStatusType)ProjectContractPackageCreationStatusType._list[i]).Description == name)
                    return (ProjectContractPackageCreationStatusType)ProjectContractPackageCreationStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectContractPackageCreationStatus objects.
    /// It's very useful when binding ProjectContractPackageCreationStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ProjectContractPackageCreationStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ProjectContractPackageCreationStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectContractPackageCreationStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ProjectContractPackageCreationStatusType._list.Count; i++)
            {
                list.Add(((ProjectContractPackageCreationStatusType)ProjectContractPackageCreationStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
