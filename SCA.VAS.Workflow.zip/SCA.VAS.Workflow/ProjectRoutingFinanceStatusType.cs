#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ProjectRoutingFinanceStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ProjectRoutingFinanceStatusConverter))]
    public class ProjectRoutingFinanceStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        // Routing to Finance Workflow 
        public static readonly ProjectRoutingFinanceStatusType NewRoutingtoFinance = new ProjectRoutingFinanceStatusType(0, "NewRoutingtoFinance", "New Routing to Finance");
        public static readonly ProjectRoutingFinanceStatusType PendingFinanceReview = new ProjectRoutingFinanceStatusType(1, "PendingFinanceReview", "Pending Finance Review");
        public static readonly ProjectRoutingFinanceStatusType FinanceApproval1 = new ProjectRoutingFinanceStatusType(2, "FinanceApproval1", "Budget Team Approval");
        public static readonly ProjectRoutingFinanceStatusType FinanceApproval2 = new ProjectRoutingFinanceStatusType(3, "FinanceApproval2", "Encumbrance Approval");
        public static readonly ProjectRoutingFinanceStatusType FinanceApproval3 = new ProjectRoutingFinanceStatusType(4, "FinanceApproval3", "VP Approval");
        public static readonly ProjectRoutingFinanceStatusType FinanceReviewCompleted = new ProjectRoutingFinanceStatusType(5, "FinanceReviewCompleted", "Finance Review Completed");
        public static readonly ProjectRoutingFinanceStatusType FinanceOnHold1 = new ProjectRoutingFinanceStatusType(6, "FinanceOnHold1", "Budget Team On-Hold");
        public static readonly ProjectRoutingFinanceStatusType FinanceOnHold2 = new ProjectRoutingFinanceStatusType(7, "FinanceOnHold2", "Encumbrance On-hold");
        public static readonly ProjectRoutingFinanceStatusType FinanceReturn1 = new ProjectRoutingFinanceStatusType(8, "FinanceReturn1", "Encumbrance Return");
        public static readonly ProjectRoutingFinanceStatusType FinanceReturn2 = new ProjectRoutingFinanceStatusType(9, "FinanceReturn2", "Return By VP to Encumbrance");
        public static readonly ProjectRoutingFinanceStatusType FinanceReviewDenied = new ProjectRoutingFinanceStatusType(10, "FinanceReviewDenied", "Finance Review Completed (Denied)");
        #endregion

        #region Constructors
        public ProjectRoutingFinanceStatusType()
        {
        }

        private ProjectRoutingFinanceStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectRoutingFinanceStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ProjectRoutingFinanceStatus.  
        /// </summary>
        public static ProjectRoutingFinanceStatusType Default
        {
            get
            {
                return (ProjectRoutingFinanceStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectRoutingFinanceStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }

        public static List<ProjectRoutingFinanceStatusType> GetList()
        {
            return _list.Cast<ProjectRoutingFinanceStatusType>().OrderBy(e => e.Id).ToList();
        }

        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((ProjectRoutingFinanceStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectRoutingFinanceStatus object.
        /// It allows a string to be assigned to a ProjectRoutingFinanceStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ProjectRoutingFinanceStatusType(int id)
        {
            return (ProjectRoutingFinanceStatusType)EnumerationBase.FindById(id, ProjectRoutingFinanceStatusType._list);
        }
        public static implicit operator ProjectRoutingFinanceStatusType(string name)
        {
            for (int i = 0; i < ProjectRoutingFinanceStatusType._list.Count; i++)
            {
                if (((ProjectRoutingFinanceStatusType)ProjectRoutingFinanceStatusType._list[i]).Description == name)
                    return (ProjectRoutingFinanceStatusType)ProjectRoutingFinanceStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectRoutingFinanceStatus objects.
    /// It's very useful when binding ProjectRoutingFinanceStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ProjectRoutingFinanceStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ProjectRoutingFinanceStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectRoutingFinanceStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ProjectRoutingFinanceStatusType._list.Count; i++)
            {
                list.Add(((ProjectRoutingFinanceStatusType)ProjectRoutingFinanceStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
