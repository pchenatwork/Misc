#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ScorecardStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ScorecardStatusConverter))]
    public class ScorecardStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly ScorecardStatusType NewEvaluation = new ScorecardStatusType(1, "NewEvaluation", "New Evaluation");
        public static readonly ScorecardStatusType ReleasedEvaluation = new ScorecardStatusType(2, "Released", "Evaluation Is Released");
        public static readonly ScorecardStatusType EvaluationInProgress = new ScorecardStatusType(3, "EvaluationInProgress", "Evaluation In Progress");
        public static readonly ScorecardStatusType EvaluationCompleted = new ScorecardStatusType(4, "EvaluationCompleted", "Evaluation Completed");
        public static readonly ScorecardStatusType ConstructionSpecialistReviewed = new ScorecardStatusType(5, "ConstructionSpecialistReviewed", "Design Project Manager Reviewed");
        public static readonly ScorecardStatusType DirectorReviewed = new ScorecardStatusType(6, "DirectorReviewed", "Director Reviewed");
        public static readonly ScorecardStatusType DesignManagerApproved = new ScorecardStatusType(7, "DesignManagerApproved", "Design Manager Approved");
        public static readonly ScorecardStatusType DeputyDirectorApproved = new ScorecardStatusType(8, "DeputyDirectorApproved", "Deputy Director Approved");
        public static readonly ScorecardStatusType DirectorApproved = new ScorecardStatusType(9, "DirectorApproved", "Director Approved");
        public static readonly ScorecardStatusType PendingLegalReview = new ScorecardStatusType(10, "PendingLegalReview", "Pending Legal Review");
        public static readonly ScorecardStatusType LegalApproved = new ScorecardStatusType(11, "LegalApproved", "Legal Approved");
        public static readonly ScorecardStatusType LegalRejected = new ScorecardStatusType(12, "LegalRejected", "Legal Rejected");
        public static readonly ScorecardStatusType PendingVPAEReview = new ScorecardStatusType(13, "PendingVPAEReview", "Pending VP of A&E Review");
        public static readonly ScorecardStatusType VPAEApproved = new ScorecardStatusType(14, "VPAEApproved", "VP of A&E Approved");
        public static readonly ScorecardStatusType CCFUSupervisorApproved = new ScorecardStatusType(15, "CCFUSupervisorApproved", "CCFU Supervisor Approved");
        public static readonly ScorecardStatusType PendingCCFUDirectorReview = new ScorecardStatusType(16, "PendingCCFUDirectorReview", "Pending CCFU Director Review");
        public static readonly ScorecardStatusType CCFUDirectorApproved = new ScorecardStatusType(17, "CCFUDirectorApproved", "CCFU Director Approved");
        public static readonly ScorecardStatusType Rejected = new ScorecardStatusType(18, "Rejected", "Rejected");
        public static readonly ScorecardStatusType NotNotified = new ScorecardStatusType(19, "NotNotified", "Consultant Not Notified");
        public static readonly ScorecardStatusType Complete = new ScorecardStatusType(20, "Complete", "Evaluation and Review Complete");
        public static readonly ScorecardStatusType Incomplete = new ScorecardStatusType(21, "Incomplete", "Incomplete");
        public static readonly ScorecardStatusType CPOReviewed = new ScorecardStatusType(22, "CPOReviewed", "CPO Reviewed");
        public static readonly ScorecardStatusType CPOApproved = new ScorecardStatusType(23, "CPOApproved", "CPO Approved");
        public static readonly ScorecardStatusType CPORejected = new ScorecardStatusType(24, "CPORejected", "CPO Rejected");
        public static readonly ScorecardStatusType VPCMApproved = new ScorecardStatusType(25, "VPCMApproved", "VP of CM Approved");
        public static readonly ScorecardStatusType DesignManagerReviewed = new ScorecardStatusType(26, "DesignManagerReviewed", "Design Manager Reviewed");
        public static readonly ScorecardStatusType DeputyDirectorReviewed = new ScorecardStatusType(27, "DeputyDirectorReviewed", "Deputy Director Reviewed");
        public static readonly ScorecardStatusType VPAdminApproved = new ScorecardStatusType(28, "VPAdminApproved", "VP of Admin Approved");
        public static readonly ScorecardStatusType VPAdminRejected = new ScorecardStatusType(29, "VPAdminRejected", "VP of Admin Rejected");
        public static readonly ScorecardStatusType PendingVPAdminReview = new ScorecardStatusType(30, "PendingVPAdminReview", "Pending VP of Admin Review");
        public static readonly ScorecardStatusType PendingVPCMReview = new ScorecardStatusType(31, "PendingVPCMReview", "Pending VP of CM Review");
        public static readonly ScorecardStatusType VPAERejected = new ScorecardStatusType(32, "VPAERejected", "VP of A&E Rejected");
        public static readonly ScorecardStatusType VPCMRejected = new ScorecardStatusType(33, "VPCMRejected", "VP of CM Rejected");
        public static readonly ScorecardStatusType PendingCQUReview = new ScorecardStatusType(34, "PendingCQUReview", "Pending CQU Review");
        public static readonly ScorecardStatusType CQUApproved = new ScorecardStatusType(35, "CQUApproved", "CQU Approved");
        public static readonly ScorecardStatusType CQURejected = new ScorecardStatusType(36, "CQURejected", "CQU Rejected");
        public static readonly ScorecardStatusType DesignManagerRejected = new ScorecardStatusType(37, "DesignManagerRejected", "Design Manager Rejected");
        public static readonly ScorecardStatusType DeputyDirectorRejected = new ScorecardStatusType(38, "DeputyDirectorRejected", "Deputy Director Rejected");
        public static readonly ScorecardStatusType DirectorRejected = new ScorecardStatusType(39, "DirectorRejected", "Director Rejected");
        public static readonly ScorecardStatusType VPCMReviewed = new ScorecardStatusType(40, "VPCMReviewed", "VP of CM Reviewed");
        public static readonly ScorecardStatusType VPAdminReviewed = new ScorecardStatusType(41, "VPAdminReviewed", "VP of Admin Reviewed");
        public static readonly ScorecardStatusType HygienistCApproved = new ScorecardStatusType(42, "HygienistCApproved", "Hygienist C Approved");
        public static readonly ScorecardStatusType HygienistCRejected = new ScorecardStatusType(43, "HygienistCRejected", "Hygienist C Rejected");
        public static readonly ScorecardStatusType PendingIEHReview = new ScorecardStatusType(44, "PendingIEHReview", "Pending IEH Review");
        public static readonly ScorecardStatusType IEHApproved = new ScorecardStatusType(45, "IEHApproved", "IEH Approved");
        public static readonly ScorecardStatusType IEHRejected = new ScorecardStatusType(46, "IEHRejected", "IEH Rejected");
        public static readonly ScorecardStatusType IEHReviewed = new ScorecardStatusType(47, "IEHReviewed", "IEH Reviewed");
        public static readonly ScorecardStatusType PendingVPERCReview = new ScorecardStatusType(48, "PendingVPERCReview", "Pending VP of ERC Review");
        public static readonly ScorecardStatusType VPERCApproved = new ScorecardStatusType(49, "VPERCApproved", "VP of ERC Approved");
        public static readonly ScorecardStatusType VPERCRejected = new ScorecardStatusType(50, "VPERCRejected", "VP of ERC Rejected");

        public static readonly ScorecardStatusType VPCapitalPlanningApproved = new ScorecardStatusType(51, "VPCapitalPlanningApproved", "VP of Capital Planning Approved");
        public static readonly ScorecardStatusType VPCapitalPlanningRejected = new ScorecardStatusType(52, "VPCapitalPlanningRejected", "VP of Capital Planning Rejected");
        public static readonly ScorecardStatusType VPCapitalPlanningReviewed = new ScorecardStatusType(53, "VPCapitalPlanningReviewed", "VP of Capital Planning Reviewed");
        public static readonly ScorecardStatusType PendingVPCapitalPlanningReview = new ScorecardStatusType(54, "PendingVPCapitalPlanningReview", "Pending VP of Capital Planning Review");

        public static readonly ScorecardStatusType Obsolete = new ScorecardStatusType(98, "Obsolete", "Obsolete");
        public static readonly ScorecardStatusType Inactive = new ScorecardStatusType(99, "Inactive", "Inactive");
        #endregion

        #region Constructors
        public ScorecardStatusType()
        {
        }

        private ScorecardStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ScorecardStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ScorecardStatus.  
        /// </summary>
        public static ScorecardStatusType Default
        {
            get
            {
                return (ScorecardStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ScorecardStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ScorecardStatus object.
        /// It allows a string to be assigned to a ScorecardStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ScorecardStatusType(int id)
        {
            return (ScorecardStatusType)EnumerationBase.FindById(id, ScorecardStatusType._list);
        }
        public static implicit operator ScorecardStatusType(string name)
        {
            for (int i = 0; i < ScorecardStatusType._list.Count; i++)
            {
                if (((ScorecardStatusType)ScorecardStatusType._list[i]).Name == name)
                    return (ScorecardStatusType)ScorecardStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ScorecardStatus objects.
    /// It's very useful when binding ScorecardStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ScorecardStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ScorecardStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ScorecardStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ScorecardStatusType._list.Count; i++)
            {
                list.Add(((ScorecardStatusType)ScorecardStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
