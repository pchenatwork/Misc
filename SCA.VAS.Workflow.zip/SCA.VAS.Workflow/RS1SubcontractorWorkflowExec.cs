#region Copyright
/*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Configuration;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.ValueObjects.Rfd;

 
using SCA.VAS.BusinessLogic.Supplier.Subcontractor;
using SCA.VAS.BusinessLogic.Supplier.Subcontractor.Utilities;
using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.Supplier.Subcontractor;
using SCA.VAS.ValueObjects.User;
#endregion Reference

namespace SCA.VAS.Workflow
{
    public class RS1SubcontractorWorkflowExec
    {
        #region Private Member
        private static int userId = 0;
        private static string prefixDbName = string.Empty;
        private static string workflowType = ConstantUtility.WORKFLOW_RS1_SUBCONTRACTOR;
        public static string WorkflowType
        {
            set { workflowType = value; }
        }
        #endregion

        #region Constructor
        public RS1SubcontractorWorkflowExec()
        {
        }
        static RS1SubcontractorWorkflowExec()
        {
        }
        #endregion Constructor

        #region Private Method
        private static int GetTransactionId(RS1Subcontractor rs1Subcontractor, string comments)
        {
            if (rs1Subcontractor.TransactionId == 0)
            {
                rs1Subcontractor.TransactionId = WorkflowExec.CreateWorkflowHistory(rs1Subcontractor.WorkflowId);
                RS1SubcontractorUtility.UpdateTransactionId(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                    rs1Subcontractor.Id, rs1Subcontractor.TransactionId);
            }
            return rs1Subcontractor.TransactionId;
        }
        #endregion Private Method

        #region Public Method
        public static User GetLastApprover(RS1Subcontractor rs1Subcontractor)
        {
            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(rs1Subcontractor.TransactionId);
            if (workflowHistory == null) return null;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return null;

            return UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, workflowHistory.CreatedBy);
        }

        public static DateTime GetLastApproveDate(RS1Subcontractor rs1Subcontractor)
        {
            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(rs1Subcontractor.TransactionId);
            if (workflowHistory == null) return DateTime.MinValue;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return DateTime.MinValue;

            return workflowHistory.DateCreated;
        }
        #endregion Public Method

        #region Workflow Control
        public static int RS1SubcontractorWorkflow(RS1Subcontractor rs1Subcontractor, string systemAction, string comments, ref string errmsg, ref string url)
        {
            int transactionId = GetTransactionId(rs1Subcontractor, comments);

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_SYSTEMNAME,
                new object[] { rs1Subcontractor.WorkflowId, systemAction });
            if (workflowNodes == null || workflowNodes.Count == 0) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(rs1Subcontractor.TransactionId);
            if (workflowHistory == null)
                return 0;

            int actionId = 0;
            for (int i = 0; i < workflowNodes.Count; i++)
            {
                if (workflowHistory.CurrentNodeId == workflowNodes[i].NodeFromId)
                {
                    actionId = workflowNodes[i].Id;
                    break;
                }
            }
            return RS1SubcontractorWorkflow(rs1Subcontractor, actionId, comments, ref errmsg, ref url);
        }

        public static int RS1SubcontractorWorkflow(RS1Subcontractor rs1Subcontractor, int actionId, string comments, ref string errmsg, ref string url)
        {
            int transactionId = GetTransactionId(rs1Subcontractor, comments);
            if (actionId == 0) return transactionId;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(rs1Subcontractor.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowNode workflowNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
            if (workflowHistory.CurrentNodeId != workflowNode.NodeFromId)
                return 0;

            // condition proccessing
            errmsg = string.Empty;
            WorkflowConditionCollection workflowConditions = SubcontractorConditionTest(rs1Subcontractor, workflowNode.Id);
            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    if (workflowCondition.Status == 0)
                    {
                        errmsg += workflowCondition.ErrorMessage + "<br />";
                    }
                }
            }
            if (errmsg != string.Empty) return 0;

            //Workflow topologic
            bool approval = true;
            switch (workflowNode.Action1)
            {
                case "One":
                    break;
                case "Owner":
                    break;
                case "All":
                case "Majority":
                case "Count":
                    WorkflowHistoryCollection workflowHistories = WorkflowHistoryUtility.FindByCriteria(
                        ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                        new object[] { rs1Subcontractor.TransactionId });

                    WorkflowHistoryCollection currentHistories = new WorkflowHistoryCollection();
                    if (workflowHistories != null)
                    {
                        for (int i = workflowHistories.Count - 1; i >= 0; i--)
                        {
                            if (workflowHistories[i].IsActive == 1) break;
                            if (workflowHistories[i].CurrentNodeId != actionId) continue;
                            if (workflowHistories[i].ApprovalUserId == userId)
                            {
                                errmsg = "You already approved this step!";
                                return 0;
                            }
                            currentHistories.Add(workflowHistories[i]);
                        }
                    }

                    // Create a history from new approval
                    WorkflowHistory approvalHistory = WorkflowHistoryUtility.CreateObject();
                    approvalHistory.TransactionHeaderId = rs1Subcontractor.TransactionId;
                    approvalHistory.WorkflowId = rs1Subcontractor.WorkflowId;
                    approvalHistory.CurrentNodeId = actionId;
                    approvalHistory.ApprovalUserId = WorkflowExec.GetUserId();
                    approvalHistory.ApprovalConditionId = 1;
                    approvalHistory.CreatedBy = workflowHistory.ApprovalUserId;
                    approvalHistory.CreatedType = WorkflowExec.GetUserType();
                    WorkflowHistoryUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, approvalHistory);

                    int approvalKnt = currentHistories.Count + 1;
                    switch (workflowNode.Action1)
                    {
                        case "All":
                            //if (approvalKnt < subcontractorUsers.Count)
                            //    approval = false;
                            break;
                        case "Majority":
                            //if (approvalKnt < subcontractorUsers.Count / 2)
                            //    approval = false;
                            break;
                        case "Count":
                            int knt = ConvertUtility.ConvertInt(workflowNode.Action2);
                            if (approvalKnt < knt)
                                approval = false;
                            break;
                    }
                    break;

                //case "Sequence":
                //    break;
                //case "Timer":
                //    //approve7.Checked = true;
                //    //approveKnt7.Text = workflowNode.Action2;
                //    break;
            }

            if (!approval || errmsg != string.Empty) return rs1Subcontractor.TransactionId;

            //Action proccessing
            WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE,
                new object[] { workflowNode.Id });

            if (workflowActions != null)
            {
                foreach (WorkflowAction workflowAction in workflowActions)
                {
                    switch (workflowAction.Type)
                    {
                        //Send Email
                        case 1:
                            //CommonUtility.SubcontractorSendEmail(rs1Subcontractor, workflowHistory, workflowAction.FunctionName, comments);
                            break;

                        //Action
                        case 2:
                            RS1SubcontractorAction(rs1Subcontractor, workflowAction.FunctionName);
                            break;

                        //Redirect page
                        case 3:
                            url = workflowAction.FunctionName;
                            break;
                    }
                }
            }

            if (workflowNode.NodeToId > 0)
            {
                WorkflowNode nextNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode.NodeToId);
                WorkflowExec.WorkflowNextStatus(workflowNode.WorkflowId, nextNode.Name, workflowHistory.CurrentNodeId, rs1Subcontractor.TransactionId, comments);
                NodeAction(rs1Subcontractor, comments);
            }

            return rs1Subcontractor.TransactionId;
        }

        public static int SubcontractorWorkflow(RS1Subcontractor rs1Subcontractor, string nextStatus, string comments)
        {
            int transactionId = GetTransactionId(rs1Subcontractor, comments);

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(rs1Subcontractor.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowExec.WorkflowNextSystemStatus(rs1Subcontractor.WorkflowId, nextStatus, workflowHistory.CurrentNodeId, rs1Subcontractor.TransactionId, comments);
            NodeAction(rs1Subcontractor, comments);

            return rs1Subcontractor.TransactionId;
        }

        public static WorkflowConditionCollection SubcontractorConditionTest(RS1Subcontractor rs1Subcontractor, int workflowNodeId)
        {
            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNodeId });

            XPathDocument doc = new XPathDocument(XmlUtility.Serialize(rs1Subcontractor));
            XPathNavigator nav = doc.CreateNavigator();

            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count > 0)
                        workflowCondition.Status = 1;
                }
            }
            return workflowConditions;
        }
        #endregion Workflow Control

        #region Workflow Node Action
        private static void NodeAction(RS1Subcontractor rs1Subcontractor, string comments)
        {
            int transactionId = GetTransactionId(rs1Subcontractor, comments);

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(
                rs1Subcontractor.TransactionId);

            int status = -1;
            string statusName = string.Empty;
            RS1SubcontractorStatusType subcontractorStatusType = workflowHistory.CurrentNode.Action6.Trim();
            if (subcontractorStatusType != null)
            {
                status = subcontractorStatusType.Id;
                statusName = subcontractorStatusType.Description;
            }
            if (status == -1 || status == rs1Subcontractor.Status) return;

            if (SubcontractorUtility.UpdateStatus(ConstantUtility.SUPPLIER_DATASOURCE_NAME, rs1Subcontractor.Id, status, statusName))
                rs1Subcontractor.Status = status;

            // automatic step
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { rs1Subcontractor.WorkflowId, "UserStepId", "ASC" });
            if (workflowNodes != null)
            {
                for (int i = 0; i < workflowNodes.Count; i++)
                {
                    if (workflowNodes[i].Type != 1 || workflowNodes[i].TimeToSkip != 1 ||
                        workflowHistory.CurrentNodeId != workflowNodes[i].NodeFromId)
                        continue;

                    string errmsg = string.Empty;
                    string url = string.Empty;
                    RS1SubcontractorWorkflow(rs1Subcontractor, workflowNodes[i].Id, comments, ref errmsg, ref url);
                }
            }
        }
        #endregion Workflow Node Action

        #region Batch Jobs
        #endregion Batch Jobs

        #region RS1Subcontractor Action
        private static void RS1SubcontractorAction(RS1Subcontractor rs1Subcontractor, string actionName)
        {
            string msg = string.Empty;
            string url = string.Empty;
            switch (actionName)
            {
                case "CheckRS1Finished":
                    Project project = ProjectUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, rs1Subcontractor.ProjectId);
                    RS1SubcontractorCollection rs1Subcontractors = null;
                    if (project != null)
                    {
                        rs1Subcontractors = RS1SubcontractorUtility.FindByCriteria(
                            ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                            RS1SubcontractorManager.SEARCH_RS1SUBCONTRACTOR,
                            new object[]
                            {
                                project.Id
                            });
                    
                        

                        if (rs1Subcontractors == null) break;

                        bool finished = true;
                        bool remediated = false;

                        var bidderWicks = BidderWicksUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME,
                            BidderWicksManager.FIND_BY_BIDDER, new object[] { project.AwardBidderId });

                        var currentWickSupplierIds = new List<Tuple<int, string>>{
                            Tuple.Create( bidderWicks[0].ElectricalSupplierId, "Electrical"),
                            Tuple.Create( bidderWicks[0].PlumbingSupplierId, "Plumbing") ,
                            Tuple.Create( bidderWicks[0].HVACSupplierId, "HVAC")
                        };

                        foreach (RS1Subcontractor rs1Sub  in rs1Subcontractors)
                        {
                            if (currentWickSupplierIds.Contains(Tuple.Create(rs1Sub.SupplierId, rs1Sub.WorkDescription))
                            )
                            {
                                finished &= rs1Sub.Status == RS1SubcontractorStatusType.BDDManagerApproved;
                                remediated |= rs1Sub.Status == RS1SubcontractorStatusType.BDDManagerDenied;
                            }
                        }

                        if (!finished && !remediated) break; //not all rs1's are SubInsurancePending or deny

                        if (finished)
                        {
                            ProjectWorkflowExec.WorkflowType = ConstantUtility.WORKFLOW_RS1_VETTING;
                            ProjectWorkflowExec.ProjectWorkflow(project, ProjectRS1VettingStatusType.RS1VettingFinished.Name, "");

                            break;
                        }

                        //  otherwise Remediated
                        ProjectWorkflowExec.WorkflowType = ConstantUtility.WORKFLOW_RS1_VETTING;
                        ProjectWorkflowExec.ProjectWorkflow(project, ProjectRS1VettingStatusType.RS1VettingRemediate.Name, "");
                    }

                    break;
            }
        }
        #endregion
    }
}
