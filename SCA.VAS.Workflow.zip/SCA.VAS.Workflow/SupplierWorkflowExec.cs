#region Copyright
/*=======================================================================
* Copyright (C) 2005 SCA.VAS USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Configuration;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

namespace SCA.VAS.Workflow
{
    public class SupplierWorkflowExec
    {
        #region Private Member
        private static string prefixDbName = string.Empty;
        private static int userId = 0;
        private static string workflowType = string.Empty;
        public static string WorkflowType
        {
            set { workflowType = value; }
        }
        #endregion

        #region Constructor
        public SupplierWorkflowExec()
        {
        }
        static SupplierWorkflowExec()
        {
        }
        #endregion Constructor

        #region Private Method
        private static SupplierWorkflow GetSupplierWorkflow(Supplier supplier)
        {
            if (supplier.SupplierWorkflows == null || supplier.SupplierWorkflows.Count == 0)
            {
                supplier.SupplierWorkflows = SupplierWorkflowUtility.FindByCriteria(
                    prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                    SupplierWorkflowManager.FIND_WORKFLOW_BY_SUPPLIER,
                    new object[] { supplier.Id });
            }

            SupplierWorkflow supplierWorkflow = null;
            if (supplier.SupplierWorkflows != null)
            {
                foreach (SupplierWorkflow sf in supplier.SupplierWorkflows)
                {
                    if (sf.WorkflowType == workflowType)
                        supplierWorkflow = sf;
                }
            }

            if (supplierWorkflow == null)
            {
                supplierWorkflow = SupplierWorkflowUtility.CreateObject();
                WorkflowList workflow = WorkflowListUtility.GetByName(
                    prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                    workflowType, 0);
                if (workflow != null)
                {
                    supplierWorkflow.WorkflowId = workflow.Id;
                    supplierWorkflow.WorkflowType = workflow.Type;
                }
            }

            if (supplierWorkflow.TransactionId == 0)
            {
                supplierWorkflow.TransactionId = WorkflowExec.CreateWorkflowHistory(supplierWorkflow.WorkflowId);
                if (supplierWorkflow.TransactionId == 0) return null;
                if (supplier.SupplierWorkflows == null)
                    supplier.SupplierWorkflows = new SupplierWorkflowCollection();
                supplier.SupplierWorkflows.Add(supplierWorkflow);
                SupplierWorkflowUtility.UpdateCollection(prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                    supplier.Id, supplier.SupplierWorkflows);

                NodeAction(supplier, "New Workflow");
            }
            return supplierWorkflow;
        }
        #endregion

        #region Workflow Control
        public static SupplierWorkflow InitialSupplierWorkflow(Supplier supplier, string workflowName)
        {
            workflowType = workflowName;
            return GetSupplierWorkflow(supplier);
        }

        public static User GetLastApprover(Supplier supplier)
        {
            SupplierWorkflow supplierWorkflow = GetSupplierWorkflow(supplier);
            if (supplierWorkflow == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(supplierWorkflow.TransactionId);
            if (workflowHistory == null) return null;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return null;

            return UserUtility.Get(prefixDbName + ConstantUtility.USER_DATASOURCE_NAME,
                workflowHistory.ApprovalUserId);
        }

        public static int SupplierWorkflow(Supplier supplier, string systemAction, string comments, ref string errmsg, ref string url)
        {
            SupplierWorkflow supplierWorkflow = GetSupplierWorkflow(supplier);
            if (supplierWorkflow == null) return 0;

            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_SYSTEMNAME,
                new object[] { supplierWorkflow.WorkflowId, systemAction });
            if (workflowNodes == null || workflowNodes.Count == 0) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(supplierWorkflow.TransactionId);
            if (workflowHistory == null)
                return 0;

            int actionId = 0;
            for (int i = 0; i < workflowNodes.Count; i++)
            {
                if (workflowHistory.CurrentNodeId == workflowNodes[i].NodeFromId)
                {
                    actionId = workflowNodes[i].Id;
                    break;
                }
            }
            return SupplierWorkflow(supplier, actionId, comments, ref errmsg, ref url);
        }

        public static int SupplierWorkflow(Supplier supplier, int actionId, string comments, ref string errmsg, ref string url)
        {
            SupplierWorkflow supplierWorkflow = GetSupplierWorkflow(supplier);
            if (supplierWorkflow == null || actionId == 0) return supplierWorkflow.TransactionId;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(supplierWorkflow.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowNode workflowNode = WorkflowNodeUtility.Get(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
            if (workflowNode == null)
                return 0;
            if (workflowHistory.CurrentNodeId != workflowNode.NodeFromId)
                return 0;

            // condition proccessing
            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNode.Id });

            TextReader reader = XmlUtility.Serialize(supplier);
            XPathDocument doc = new XPathDocument(reader);
            XPathNavigator nav = doc.CreateNavigator();

            errmsg = string.Empty;
            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count == 0)
                    {
                        errmsg += workflowCondition.ErrorMessage + "<br>";
                    }
                }
            }
            if (errmsg != string.Empty) return 0;

            //Workflow topologic
            bool approval = true;
            switch (workflowNode.Action1)
            {
                case "One":
                    break;
                case "Owner":
                    //if (supplier.BuyerId != userId)
                    //    errmsg = "Only RFx owner / Creator can do this step";
                    break;
                case "All":
                case "Majority":
                case "Count":
                    WorkflowHistoryCollection workflowHistories = WorkflowHistoryUtility.FindByCriteria(
                        prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                        new object[] { supplierWorkflow.TransactionId });

                    WorkflowHistoryCollection currentHistories = new WorkflowHistoryCollection();
                    if (workflowHistories != null)
                    {
                        for (int i = workflowHistories.Count - 1; i >= 0; i--)
                        {
                            if (workflowHistories[i].IsActive == 1) break;
                            if (workflowHistories[i].CurrentNodeId != actionId) continue;
                            if (workflowHistories[i].ApprovalUserId == userId)
                            {
                                errmsg = "You already approved this step";
                                return 0;
                            }
                            currentHistories.Add(workflowHistories[i]);
                        }
                    }

                    // Create a history from new approval
                    WorkflowHistory approvalHistory = WorkflowHistoryUtility.CreateObject();
                    approvalHistory.TransactionHeaderId = supplierWorkflow.TransactionId;
                    approvalHistory.WorkflowId = supplierWorkflow.WorkflowId;
                    approvalHistory.CurrentNodeId = actionId;
                    approvalHistory.ApprovalUserId = WorkflowExec.GetUserId();
                    approvalHistory.ApprovalConditionId = 1;
                    approvalHistory.CreatedBy = workflowHistory.ApprovalUserId;
                    approvalHistory.CreatedType = WorkflowExec.GetUserType();
                    WorkflowHistoryUtility.Create(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, approvalHistory);

                    int approvalKnt = currentHistories.Count + 1;
                    switch (workflowNode.Action1)
                    {
                        case "All":
                            //if (approvalKnt < supplierUsers.Count)
                            //    approval = false;
                            break;
                        case "Majority":
                            //if (approvalKnt < supplierUsers.Count / 2)
                            //    approval = false;
                            break;
                        case "Count":
                            int knt = ConvertUtility.ConvertInt(workflowNode.Action2);
                            if (approvalKnt < knt)
                                approval = false;
                            break;
                    }
                    break;

                //case "Sequence":
                //    break;
                //case "Timer":
                //    //approve7.Checked = true;
                //    //approveKnt7.Text = workflowNode.Action2;
                //    break;
            }

            if (!approval || errmsg != string.Empty) return supplierWorkflow.TransactionId;

            //Action proccessing
            WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE,
                new object[] { workflowNode.Id });

            if (workflowActions != null)
            {
                foreach (WorkflowAction workflowAction in workflowActions)
                {
                    switch (workflowAction.Type)
                    {
                        //Send Email
                        case 1:
                            // 20180502 PCHEN: Skip workflowAction IF Function is to send "XXXX_CONTACT_REMINDER" email but Supplier is NOT (A&E OR ProfService)
                            if (workflowAction.FunctionName.ToUpper().Contains("AE_CONTACT_REMINDER")
                                && !(supplier.IsAEApproved()))
                            {                               
                                break;
                            }
                            if (workflowAction.FunctionName.ToUpper().Contains("PROSVC_CONTACT_REMINDER")
                                && !(supplier.IsProfServiceApproved()))
                            {
                                break;
                            }

                            CommonUtility.SupplierSendEmail(supplier, workflowHistory, workflowAction.FunctionName, comments, prefixDbName);
                            break;
                        //Action
                        case 2:
                            //SKP: Skip WorkflowAction if function is to create Ehire Contact but Supplier is NOT Professioanl Service
                            if (workflowAction.FunctionName.ToUpper().Equals("EHIRE_COPY_PRIMARY_CONTACT_AS_ACC_REPRESENTATIVE") && !supplier.IsProfServiceApproved()) { break; }
                            SupplierAction(supplier, workflowAction.FunctionName);
                            break;

                        //Redirect page
                        case 3:
                            url = workflowAction.FunctionName;
                            break;
                    }
                }
            }

            if (workflowNode.NodeToId > 0)
            {
                WorkflowNode nextNode = WorkflowNodeUtility.Get(prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode.NodeToId);
                WorkflowExec.WorkflowNextStatus(workflowNode.WorkflowId, nextNode.Name, workflowHistory.CurrentNodeId, supplierWorkflow.TransactionId, comments);

                if (comments.Trim() != string.Empty)
                {
                    Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                        "Supplier", supplier.Id.ToString());
                    User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

                    VendorComment vendorComment = VendorCommentUtility.CreateObject();
                    vendorComment.UserId = user.Id;
                    vendorComment.VendorId = vendor.Id;
                    vendorComment.Comments = "Workflow Comments: " + comments;
                    vendorComment.Type = "User";
                    vendorComment.ChangeUser = user.FullName;

                    VendorCommentUtility.Create(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorComment);
                }

                NodeAction(supplier, comments);
            }

            return supplierWorkflow.TransactionId;
        }

        public static int SupplierWorkflow(Supplier supplier, string nextStatus, string comments)
        {
            SupplierWorkflow supplierWorkflow = GetSupplierWorkflow(supplier);
            if (supplierWorkflow == null) return 0;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(supplierWorkflow.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowExec.WorkflowNextSystemStatus(supplierWorkflow.WorkflowId, nextStatus, workflowHistory.CurrentNodeId, supplierWorkflow.TransactionId, comments);

            if (comments.Trim() != string.Empty)
            {
                Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                    "Supplier", supplier.Id.ToString());
                User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

                VendorComment vendorComment = VendorCommentUtility.CreateObject();
                vendorComment.VendorId = vendor.Id;
                vendorComment.Comments = "Workflow Comments: " + comments;
                if (user != null)
                {
                    vendorComment.UserId = user.Id;
                    vendorComment.Type = "User";
                    vendorComment.ChangeUser = user.FullName;
                }

                VendorCommentUtility.Create(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorComment);
            }

            NodeAction(supplier, comments);

            return supplierWorkflow.TransactionId;
        }

        public static WorkflowConditionCollection SupplierWorkflowConditionTest(Supplier supplier, int workflowNodeId)
        {
            SupplierWorkflow supplierWorkflow = GetSupplierWorkflow(supplier);
            if (supplierWorkflow == null) return null;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(supplierWorkflow.TransactionId);
            if (workflowHistory == null)
                return null;

            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                prefixDbName + ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNodeId });

            XPathDocument doc = new XPathDocument(XmlUtility.Serialize(supplier));
            XPathNavigator nav = doc.CreateNavigator();

            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                    XPathExpression expr = nav.Compile(workflowCondition.Condition);
                    expr.SetContext(ctx);
                    XPathNodeIterator iterator = nav.Select(expr);
                    if (iterator.Count > 0)
                        workflowCondition.Status = 1;
                }
            }
            return workflowConditions;
        }
        #endregion Workflow Control

        #region Workflow Node Action
        private static void NodeAction(Supplier supplier, string comments)
        {
            SupplierWorkflow supplierWorkflow = GetSupplierWorkflow(supplier);
            if (supplierWorkflow == null) return;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(
                supplierWorkflow.TransactionId);

            string status = string.Empty;
            switch (workflowType)
            {
                case ConstantUtility.WORKFLOW_QUALIFICATION:
                    SupplierStatusType supplierStatusType = workflowHistory.CurrentNode.Action6.Trim();
                    if (supplierStatusType != null)
                        status = supplierStatusType.Description;
                    break;
                case ConstantUtility.WORKFLOW_CERTIFICATION:
                    CertificationStatusType certificationStatusType = workflowHistory.CurrentNode.Action6.Trim();
                    if (certificationStatusType != null)
                        status = certificationStatusType.Description;
                    break;
                case ConstantUtility.WORKFLOW_OIG_QUALIFICATION:
                    OIGStatusType oIGStatusType = workflowHistory.CurrentNode.Action6.Trim();
                    if (oIGStatusType != null)
                        status = oIGStatusType.Description;
                    break;
                case ConstantUtility.WORKFLOW_AMENDED_TRADE_CODE:
                    AmendedTradeCodeStatusType amendedTradeCodeStatusType = workflowHistory.CurrentNode.Action6.Trim();
                    if (amendedTradeCodeStatusType != null)
                        status = amendedTradeCodeStatusType.Description;
                    break;
                case ConstantUtility.WORKFLOW_OVER_1MM:
                    Over1MMStatusType over1MMStatusType = workflowHistory.CurrentNode.Action6.Trim();
                    if (over1MMStatusType != null)
                        status = over1MMStatusType.Description;
                    break;
                case ConstantUtility.WORKFLOW_CHANGE_IN_APPLICATION:
                    ChangeInAppStatusType changeInAppStatusType = workflowHistory.CurrentNode.Action6.Trim();
                    if (changeInAppStatusType != null)
                        status = changeInAppStatusType.Description;
                    break;
                case ConstantUtility.WORKFLOW_MENTOR:
                    SupplierMentorType supplierMentorType = workflowHistory.CurrentNode.Action6.Trim();
                    if (supplierMentorType != null)
                        status = supplierMentorType.Description;
                    break;
            }

            SupplierStatus supplierStatus = SupplierStatusUtility.GetByType(
                prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                supplier.Id, workflowType);
            if (supplierStatus == null)
                supplierStatus = SupplierStatusUtility.CreateObject();

            if (status == string.Empty || status == supplierStatus.Status) return;

            supplierStatus.SupplierId = supplier.Id;
            supplierStatus.TypeName = workflowType;
            supplierStatus.Status = status;
            SupplierStatusUtility.Update(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierStatus);

            if (supplier.SupplierStatuses == null)
                supplier.SupplierStatuses = new SupplierStatusCollection();
            SupplierStatus newStatus = supplier.SupplierStatuses.FindByType(workflowType);
            if (newStatus == null)
                supplier.SupplierStatuses.Add(supplierStatus);
            else
                newStatus.Status = status;

            // automatic step
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { supplierWorkflow.WorkflowId, "UserStepId", "ASC" });
            if (workflowNodes != null)
            {
                for (int i = 0; i < workflowNodes.Count; i++)
                {
                    if (workflowNodes[i].Type != 1 || workflowNodes[i].TimeToSkip != 1 ||
                        workflowHistory.CurrentNodeId != workflowNodes[i].NodeFromId)
                        continue;

                    string errmsg = string.Empty;
                    string url = string.Empty;
                    SupplierWorkflow(supplier, workflowNodes[i].Id, comments, ref errmsg, ref url);
                }
            }
        }
        #endregion Workflow Node Action

        #region Batch Jobs
        #endregion Batch Jobs

        #region Supplier Action
        private static void SupplierAction(Supplier supplier, string actionName)
        {
            string msg = string.Empty;
            string url = string.Empty;
            string tempType = workflowType;
            SupplierStatus qualStatus = SupplierStatusUtility.GetByType(
                prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                supplier.Id, ConstantUtility.WORKFLOW_QUALIFICATION);

            SupplierStatus certStatus = SupplierStatusUtility.GetByType(
                prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                supplier.Id, ConstantUtility.WORKFLOW_CERTIFICATION);

            switch (actionName)
            {
                case "EHIRE_COPY_PRIMARY_CONTACT_AS_ACC_REPRESENTATIVE":
                    VendorContactExternalUtility.AutoPopulatePrimaryAsExternalContact(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplier.Id);
                    break;
                case "TransferDataCMSSubmit":
                    SupplierUtility.UpdateByType(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplier.Id, "Submit", 0, "Supplier");
                    break;
                case "TransferDataCMS":
                    User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());
                    SupplierUtility.UpdateByType(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplier.Id, "Approval", 0, user.UserName);
                    break;
                case "QualMoreInfoNoPending":
                    supplier.SupplierProperties = CommonUtility.AddSupplierProperty(supplier, CommonUtility.CreateSupplierProperty(522, "QualMoreInfoNoPending"));
                    SupplierPropertyUtility.UpdateCollection(prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                        supplier.Id, supplier.SupplierProperties);

                    if (certStatus != null && certStatus.Status == CertificationStatusType.RequestMoreCertInfoPending.Description)
                    {
                        WorkflowType = ConstantUtility.WORKFLOW_CERTIFICATION;
                        SupplierWorkflow(supplier, SCA.VAS.Workflow.SupplierAction.CheckRegMissingItem.Name,
                            "Qualification Info Ready or no need", ref msg, ref url);
                        SupplierWorkflow(supplier, SCA.VAS.Workflow.SupplierAction.Cert30DayLetter.Name,
                            "Qualification Info Ready or no need", ref msg, ref url);
                    }

                    break;
                case "CertMoreInfoNoPending":
                    supplier.SupplierProperties = CommonUtility.AddSupplierProperty(supplier, CommonUtility.CreateSupplierProperty(523, "CertMoreInfoNoPending"));
                    SupplierPropertyUtility.UpdateCollection(prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                        supplier.Id, supplier.SupplierProperties);

                    if (qualStatus != null)
                    {
                        WorkflowType = ConstantUtility.WORKFLOW_QUALIFICATION;
                        SupplierWorkflow(supplier, SCA.VAS.Workflow.SupplierAction.CheckCertMissingItem.Name,
                            "Certification Info Ready or no need", ref msg, ref url);
                    }

                    break;
                case "WaitCertMoreInfo":
                    bool certNoPending = false;
                    SupplierProperty supplierProperty523 = CommonUtility.GetSupplierProperty("property523", supplier.SupplierProperties);
                    if (supplierProperty523 != null && supplierProperty523.PropertyText == "CertMoreInfoNoPending")
                        certNoPending = true;

                    if (certNoPending || certStatus == null || (certStatus != null &&
                        certStatus.Status == CertificationStatusType.RequestMoreCertInfoPending.Description))
                    {
                        if (certStatus != null)
                        {
                            WorkflowType = ConstantUtility.WORKFLOW_CERTIFICATION;
                            SupplierWorkflow(supplier, SCA.VAS.Workflow.SupplierAction.CheckRegMissingItem.Name,
                                "Qualification Info Ready or no need", ref msg, ref url);
                        }

                        WorkflowType = ConstantUtility.WORKFLOW_QUALIFICATION;
                        SupplierWorkflow(supplier, SCA.VAS.Workflow.SupplierAction.CheckCertMissingItem.Name,
                            "Certification Info Ready or no need", ref msg, ref url);
                    }
                    break;
                case "WaitQualMoreInfo":
                    bool qualNoPending = false;
                    SupplierProperty supplierProperty522 = CommonUtility.GetSupplierProperty("property522", supplier.SupplierProperties);
                    if (supplierProperty522 != null && supplierProperty522.PropertyText == "QualMoreInfoNoPending")
                        qualNoPending = true;

                    SupplierStatus supplierStatus = SupplierStatusUtility.GetByType(
                        prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                        supplier.Id, ConstantUtility.WORKFLOW_QUALIFICATION);
                    if (qualNoPending || supplierStatus == null || (supplierStatus != null &&
                        supplierStatus.Status == SupplierStatusType.RequestMoreInfoPending.Description))
                    {
                        if (supplierStatus != null)
                        {
                            WorkflowType = ConstantUtility.WORKFLOW_QUALIFICATION;
                            SupplierWorkflow(supplier, SCA.VAS.Workflow.SupplierAction.CheckCertMissingItem.Name,
                                "Certification Info Ready or no need", ref msg, ref url);
                        }

                        WorkflowType = ConstantUtility.WORKFLOW_CERTIFICATION;
                        SupplierWorkflow(supplier, SCA.VAS.Workflow.SupplierAction.CheckRegMissingItem.Name,
                            "Qualification Info Ready or no need", ref msg, ref url);

                        // send cert 30 day letter only
                        if (supplierStatus == null || supplierStatus.Status != SupplierStatusType.RequestMoreInfoPending.Description)
                        {
                            SupplierWorkflow(supplier, SCA.VAS.Workflow.SupplierAction.Cert30DayLetter.Name,
                                "Qualification Info Ready or no need", ref msg, ref url);
                        }
                    }
                    break;

                case "ExpireOldQual":
                    if (qualStatus != null && qualStatus.Status == SupplierStatusType.Qualified.Description)
                    {
                        SupplierVersionCollection supplierVersions = SupplierVersionUtility.FindByCriteria(
                            ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                            SupplierVersionManager.FIND_BY_SUPPLIER, new object[] { supplier.Id });
                        
                        foreach (SupplierVersion sv in supplierVersions)
                        {
                            if (sv.SupplierId == supplier.Id) continue;
                            Supplier oldSupplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, sv.SupplierId);

                            SupplierStatus oldQualStatus = oldSupplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_QUALIFICATION);
                            if (oldQualStatus != null && oldQualStatus.Status == SupplierStatusType.Qualified.Description)
                            {
                                SupplierWorkflow(supplier, SupplierStatusType.Expired.Name, "Old Qualication Expired by System");
                            }
                        }
                    }
                    break;
                case "ExpireOldCert":
                    if (certStatus != null && certStatus.Status == CertificationStatusType.Certified.Description)
                    {
                        SupplierVersionCollection supplierVersions = SupplierVersionUtility.FindByCriteria(
                            ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                            SupplierVersionManager.FIND_BY_SUPPLIER, new object[] { supplier.Id });

                        foreach (SupplierVersion sv in supplierVersions)
                        {
                            if (sv.SupplierId == supplier.Id) continue;
                            Supplier oldSupplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, sv.SupplierId);

                            SupplierStatus oldCertStatus = oldSupplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);
                            if (oldCertStatus != null && oldCertStatus.Status == CertificationStatusType.Certified.Description)
                            {
                                SupplierWorkflow(supplier, CertificationStatusType.Expired.Name, "Old Certication Expired by System");
                            }
                        }
                    }
                    break;
                case "StartOIGQualification":
                    InitialSupplierWorkflow(supplier, ConstantUtility.WORKFLOW_OIG_QUALIFICATION);
                    break;
            }
            WorkflowType = tempType;
        }
        #endregion
    }
}
