#region Copyright
/*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Configuration;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

namespace SCA.VAS.Workflow
{
	public class EmailDynamicContent
	{
		#region Constructor
		public EmailDynamicContent()
		{
		}
		static EmailDynamicContent()
		{
		}
		#endregion Constructor

		#region Public Method
        public static string ReplaceDynamicContent(EmailMessage emailmessage, object emailableObj,
            object[] emailableObjs, string body)
        {
            string dynamicField = string.Empty;
            Supplier supplier = null;
            UserCollection users = new UserCollection();

            if (emailableObj is Supplier)
                supplier = (Supplier)emailableObj;
            else if (emailableObj is User)
                users.Add((User)emailableObj);

            foreach(object o in emailableObjs)
            {
                if (o is Supplier)
                    supplier = (Supplier)o;
                else if (o is User)
                    users.Add((User)o);
            }

            switch (emailmessage.Name)
            {
                case "":
                    if (supplier != null && supplier.SupplierClassifications != null)
                    {
                        foreach (SupplierClassification sc in supplier.SupplierClassifications)
                        {
                            dynamicField += sc.Classification + ", ";
                        }
                        dynamicField = dynamicField.Trim().Trim(',');
                    }
                    body = body.Replace("$DYNAMICMESSAGE$", dynamicField);


                    break;
                //case "USER_DIRECTOR_APPROVE_REQUEST":
                //case "USER_QUALIFICATION_REQUEST":
                //case "USER_DIVERSITY_APPROVE_REQUEST":
                //case "USER_VENDOR_SETUP_REQUEST":

                //    //Last Workflow Approver
                //    User user = SupplierWorkflowExec.GetLastApprover(supplier);
                //    if (user != null)
                //    {
                //        body = body.Replace("$APPROVER$", user.FullName);
                //        body = body.Replace("$APPROVEREMAIL$", user.Email);
                //    }
                //    break;
                //case "USER_DIVERSITY_SETUP":

                //    //Last Workflow Approver
                //    user = DiversityWorkflowExec.GetLastApprover(supplier);
                //    if (user != null)
                //    {
                //        body = body.Replace("$APPROVER$", user.FullName);
                //        body = body.Replace("$APPROVEREMAIL$", user.Email);
                //    }
                //    break;
            }

            return body;
        }
        
        #endregion Public Method

		#region Private Method
		#endregion Private Method
	}
}
