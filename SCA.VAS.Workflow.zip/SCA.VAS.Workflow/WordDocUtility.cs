using System;
using System.Reflection;
using System.IO;
using System.Diagnostics;
using System.Configuration;

//using Microsoft.Office.Core;
using Microsoft.Office.Interop.Word;

using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Workflow;
using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.Supplier.Subcontractor;
using SCA.VAS.BusinessLogic.Supplier.Subcontractor.Utilities;
using SCA.VAS.BusinessLogic.Supplier.Subcontractor;

using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

using oXmlPkg = DocumentFormat.OpenXml.Packaging;
using oXmlWp = DocumentFormat.OpenXml.Wordprocessing;
using xmlPT = OpenXmlPowerTools;

namespace SCA.VAS.Workflow
{
    public class WordDocUtility
    {
        private static SCA.VAS.ValueObjects.User.Menu currentStep;
        private static string workflowcomments = "";
        private static string emailname = "";

        #region Public Replace Methods


        public static void Replace(string strDoc, object[] emailableObjs, string comments)
        {
            workflowcomments = comments;
            string extension = "doc";
            if (strDoc.IndexOf('.') != -1)
            {
                extension = strDoc.Substring(strDoc.LastIndexOf(".") + 1);
            }
            if (extension.ToLower() == "docx")
            {
                ReplaceUsingOpenXML(strDoc, emailableObjs);
            }
            else
            {
                Replace(strDoc, emailableObjs);
            }
        }

        public static void Replace(string emailmessagename, string strDoc, object[] emailableObjs)
        {
            string extension = "doc";
            emailname = emailmessagename;
            if (strDoc.IndexOf('.') != -1)
            {
                extension = strDoc.Substring(strDoc.LastIndexOf(".") + 1);
            }
            if (extension.ToLower() == "docx")
            {
                ReplaceUsingOpenXML(strDoc, emailableObjs);
            }
            else
            {
                Replace(strDoc, emailableObjs);
            }
        }

        public static void Replace(string strDoc, object[] emailableObjs)
        {
            string extension = "doc";
            if (strDoc.IndexOf('.') != -1)
            {
                extension = strDoc.Substring(strDoc.LastIndexOf(".") + 1);
            }
            if (extension.ToLower() == "docx")
            {
                ReplaceUsingOpenXML(strDoc, emailableObjs);
            }
            else
            {
                ReplaceUsingInterop(strDoc, emailableObjs);
            }
        }

        #endregion

        #region Private Replace Methods (Handle in-document Token replacements)

        private static void Replace(Document doc, string oldValue, string newValue)
        {
            // Define an object to pass to the API for objMissing parameters
            object objMissing = Type.Missing;
            object objTrue = true;

            // Loop through the StoryRanges (sections of the Word doc)
            foreach (Range tmpRange in doc.StoryRanges)
            {
                object findText = oldValue;
                object replaceText = newValue;
                object replaceAll = WdReplace.wdReplaceAll;
                object wrap = WdFindWrap.wdFindContinue;

                try
                {
                    object[] Parameters;
                    Parameters = new object[15];
                    Parameters[0] = findText;
                    Parameters[1] = objTrue;
                    Parameters[2] = objMissing;
                    Parameters[3] = objMissing;
                    Parameters[4] = objMissing;
                    Parameters[5] = objMissing;
                    Parameters[6] = objMissing;
                    Parameters[7] = wrap;
                    Parameters[8] = objMissing;
                    Parameters[9] = replaceText;
                    Parameters[10] = replaceAll;
                    Parameters[11] = objMissing;
                    Parameters[12] = objMissing;
                    Parameters[13] = objMissing;
                    Parameters[14] = objMissing;

                    tmpRange.Find.GetType().InvokeMember("Execute", BindingFlags.InvokeMethod, null, tmpRange.Find, Parameters);
                }
                catch
                {
                }
            }
        }

        private static void Replace(IEnumerable<oXmlWp.Text> documentTexts, string oldText, string newText)
        {
            var tokenTexts = documentTexts.Where(t => t.Text.Contains(oldText));

            foreach (var text in tokenTexts)
            {
                if (text.Text.IndexOf(oldText) != -1)
                {
                    text.Text = text.Text.Replace(oldText, newText);
                }
            }

        }
        #endregion

        #region Full Document Token Replacement Routines

        /// <summary>
        /// This was previously the method Replace(string strDoc, object[] emailableObjs)
        /// THe only cange is in renaming the method.
        /// </summary>
        /// <param name="strDoc"></param>
        /// <param name="emailableObjs"></param>
        private static void ReplaceUsingInterop(string strDoc, object[] emailableObjs)
        {

            // Create the Word application and declare a document
            Application objApp = new Application();
            Document doc = new Document();

            // Define an object to pass to the API for objMissing parameters
            object objMissing = Type.Missing;
            object objFalse = false;

            try
            {
                // Everything that goes to the interop must be an object
                object fileName = strDoc;

                // Open the Word document.
                // Pass the "objMissing" object defined above to all optional
                // parameters.  All parameters must be of type object,
                // and passed by reference.
                doc = objApp.Documents.Open(ref fileName,
                    ref objMissing, ref objFalse, ref objMissing, ref objMissing,
                    ref objMissing, ref objMissing, ref objMissing, ref objMissing,
                    ref objMissing, ref objMissing, ref objMissing, ref objMissing,
                    ref objMissing, ref objMissing, ref objMissing);

                // Activate the document
                doc.Activate();

                Replace(doc, "$COMPANY$", ConfigurationManager.AppSettings["Company"]);
                Replace(doc, "$DATE$", DateTime.Now.ToString("MMMM dd, yyyy"));
                Replace(doc, "$WORKFLOWCOMMENTS$", workflowcomments);

                if (emailableObjs != null)
                {
                    for (int i = 0; i < emailableObjs.Length; i++)
                    {
                        if (emailableObjs[i] != null)
                        {
                            if (emailableObjs[i] is Supplier)
                            {
                                Supplier supplier = (Supplier)emailableObjs[i];
                                Replace(doc, "$FEDERALID$", supplier.FederalId);
                                Replace(doc, "$SUPPLIERCOMPANY$", supplier.Company);
                                Replace(doc, "$VENDORCOMPANY$", supplier.Company);
                                Replace(doc, "$FEDERALID$", supplier.FederalId);
                                Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "Supplier", supplier.Id.ToString());
                                VendorContact primaryContact = vendor == null ? null : CommonUtility.GetPrimaryContact(vendor.Id);
                                Replace(doc, "$VENDORPRIMARYCONTACTUSERNAME$", primaryContact == null ? "" : primaryContact.UserName);
                                Replace(doc, "$SITEURL$", ConfigurationSettings.AppSettings["SiteUrl"].ToString());
                                Replace(doc, "$SITELINK$", ConfigurationSettings.AppSettings["SiteUrl"].ToString());
                                Replace(doc, "$INTERNALSITEURL$", ConfigurationSettings.AppSettings["InternalSiteUrl"].ToString());
                                Replace(doc, "$INTERNALSITELINK$", ConfigurationSettings.AppSettings["InternalSiteUrl"].ToString());

                                string searchUrl = ConfigurationSettings.AppSettings["InternalSiteUrl"].ToString() + "/Supplier/Supplier_Search_Results.aspx?Id=" + supplier.Id.ToString();
                                Replace(doc, "$SEARCHSUPPLIERLINK$", searchUrl);

                                string commentUrl = ConfigurationSettings.AppSettings["InternalSiteUrl"].ToString() + "/Supplier/Workflow_Supplier_Comments.aspx?Id=" + supplier.Id.ToString();
                                Replace(doc, "$SUPPLIERCOMMENTLINK$", commentUrl);

                                string responseUrl = ConfigurationSettings.AppSettings["SiteUrl"].ToString() + "/Supplier/Supplier_More_Info.aspx";
                                Replace(doc, "$LETTERRESPONSELINK$", responseUrl);

                                string appType = "";
                                if (supplier.IsBoth())
                                    appType = "Qualification and Certification";
                                else if (supplier.IsCert())
                                    appType = "Certification";
                                else if (supplier.IsQual())
                                    appType = "Qualification";

                                Replace(doc, "$APPLICATIONTYPE$", appType);
                                Replace(doc, "$CQUDIVISION$", (appType.IndexOf("Qualification") < 0) ? "" : "Pre-qualification Division");
                                Replace(doc, "$BDDDIVISION$", (appType.IndexOf("Certification") < 0) ? "" : "Business Development Division");

                                string certType = "";
                                foreach (SupplierProperty sp in CommonUtility.GetSupplierProperties("property519", supplier.SupplierProperties))
                                {
                                    if (sp.PropertyText == "MBE" || sp.PropertyText == "WBE" || sp.PropertyText == "LBE")
                                        certType += sp.PropertyText + "/";
                                }
                                if (certType != "")
                                    certType = certType.Substring(0, certType.Length - 1);
                                Replace(doc, "$CERTTYPE$", certType);

                                SupplierStatus qualStatus = null;
                                SupplierStatus certStatus = null;
                                if (supplier.SupplierStatuses != null)
                                {
                                    qualStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_QUALIFICATION);
                                    certStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);
                                }
                                bool isQualified = false;
                                bool isCertified = false;
                                string qualType = "";
                                if (qualStatus != null && qualStatus.Status == SupplierStatusType.Qualified.Description)
                                    isQualified = true;
                                if (certStatus != null && certStatus.Status == CertificationStatusType.Certified.Description)
                                    isCertified = true;
                                if (isQualified && isCertified)
                                    qualType = "Qualified/Certified";
                                else
                                {
                                    if (isQualified)
                                        qualType = "Qualified";
                                    if (isCertified)
                                        qualType = "Certified";
                                }
                                Replace(doc, "$QUALIFIEDTYPE$", qualType);

                                string qualificationType = "qualification";
                                if ((supplier.Status & 1) == 1 || (supplier.Status & 2) == 2)
                                    qualificationType = "requalification";
                                Replace(doc, "$QUALIFICATIONTYPE$", qualificationType);

                                Replace(doc, "$OIGDECISION$", CommonUtility.GetSupplierProperty("property508", supplier.SupplierProperties).PropertyText);
                                Replace(doc, "$OIGCOMMENTS$", CommonUtility.GetSupplierProperty("property515", supplier.SupplierProperties).PropertyText);

                                User analyst = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, CommonUtility.GetSupplierProperty("property524", supplier.SupplierProperties).PropertyText);
                                Replace(doc, "$BDDANALYST$", (analyst == null) ? "" : analyst.FullName);
                                Replace(doc, "$BDDANALYSTNAME$", (analyst == null) ? "" : analyst.FullName);
                                Replace(doc, "$BDDANALYSTPHONE$", (analyst == null) ? "" : analyst.Phone);
                                Replace(doc, "$BDDANALYSTEMAIL$", (analyst == null) ? "" : analyst.Email);
                                Replace(doc, "$BDDANALYSTTITLE$", (analyst == null) ? "" : analyst.Title);

                                User manager = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, CommonUtility.GetSupplierProperty("property521", supplier.SupplierProperties).PropertyText);
                                Replace(doc, "$CQUMANAGER$", (manager == null) ? "" : manager.FullName);
                                Replace(doc, "$CQUMANAGERNAME$", (manager == null) ? "" : manager.FullName);
                                Replace(doc, "$CQUMANAGERPHONE$", (manager == null) ? "" : manager.Phone);
                                Replace(doc, "$CQUMANAGEREMAIL$", (manager == null) ? "" : manager.Email);
                                Replace(doc, "$CQUMANAGERTITLE$", (manager == null) ? "" : manager.Title);

                                User reviewer = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, CommonUtility.GetSupplierProperty("property10", supplier.SupplierProperties).PropertyText);
                                Replace(doc, "$CQUREVIEWER$", (reviewer == null) ? "" : reviewer.FullName);
                                Replace(doc, "$CQUREVIEWERNAME$", (reviewer == null) ? "" : reviewer.FullName);
                                Replace(doc, "$CQUREVIEWERPHONE$", (reviewer == null) ? "" : reviewer.Phone);
                                Replace(doc, "$CQUREVIEWEREMAIL$", (reviewer == null) ? "" : reviewer.Email);
                                Replace(doc, "$CQUREVIEWERTITLE$", (reviewer == null) ? "" : reviewer.Title);

                                string letterContact = "";
                                if (appType.IndexOf("Qualification") >= 0 && reviewer != null)
                                    letterContact = reviewer.FullName + " at " + reviewer.Phone + " for prequalification related questions";
                                if (appType.IndexOf("Certification") >= 0 && analyst != null)
                                    letterContact += letterContact == "" ? analyst.FullName + " at " + analyst.Phone + " for certification related questions" : " and for certification questions " + analyst.FullName + " at " + analyst.Phone;
                                Replace(doc, "$LETTERCONTACTINFO$", letterContact);

                                SupplierPersonnel majorityOwner = null;
                                SupplierPersonnelCollection keypeople = SupplierPersonnelUtility.FindByCriteria(
                                    ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                                    SupplierPersonnelManager.FIND_SUPPLIERPERSONNEL,
                                    new object[] { supplier.Id, "Y" });
                                if (keypeople != null)
                                {
                                    foreach (SupplierPersonnel sp in keypeople)
                                    {
                                        if (sp.IsOwner == "Y")
                                        {
                                            if (majorityOwner == null || sp.OwnedPercentage > majorityOwner.OwnedPercentage)
                                                majorityOwner = sp;
                                        }
                                    }
                                }
                                if (majorityOwner != null)
                                    Replace(doc, "$MAJORITYOWNER$", (majorityOwner == null) ? "" : majorityOwner.Name.Replace("|", " "));

                                string qualifiedTrades = "";
                                string millionTrades = "";
                                if (supplier.SupplierCategories != null)
                                {
                                    foreach (SupplierCategory sc in supplier.SupplierCategories)
                                    {
                                        if (sc.IsApproved == "Y")
                                        {
                                            qualifiedTrades += "(" + sc.Category.Code + ") " + sc.CategoryName + "; ";
                                            if (sc.ApprovedAverage == "under")
                                                millionTrades += "(" + sc.Category.Code + ") " + sc.CategoryName + "; ";
                                        }
                                    }
                                    if (qualifiedTrades.Trim().Length > 0)
                                        qualifiedTrades = qualifiedTrades.Substring(0, qualifiedTrades.Length - 2);
                                    if (millionTrades.Trim().Length > 0)
                                        millionTrades = millionTrades.Substring(0, millionTrades.Length - 2);
                                }
                                Replace(doc, "$QUALIFIEDTRADES$", qualifiedTrades);
                                Replace(doc, "$1MQUALIFIEDTRADES$", millionTrades);

                                int transactionId = 0;
                                int certTransactionId = 0;
                                string dateSubmitted = "";
                                string qualExpDate = "";
                                string certExpDate = "";
                                string sixtyDayDate = "";
                                string thirtyDayDate = "";
                                string qualTenDayDate = "";
                                string certTenDayDate = "";
                                string closureDate = "";
                                
                                if (emailname == "30DAY_LETTER_NOTICE")
                                {
                                    closureDate = DateTime.Now.AddDays(30).ToShortDateString();
                                    thirtyDayDate = DateTime.Now.ToShortDateString();
                                }
                                else if (emailname.IndexOf("10DAY_LETTER_NOTICE") == 0)
                                {
                                    closureDate = DateTime.Now.AddDays(10).ToShortDateString();
                                    if (emailname.ToLower().IndexOf("cert") >= 0)
                                        certTenDayDate = DateTime.Now.ToShortDateString();
                                    else
                                        qualTenDayDate = DateTime.Now.ToShortDateString();
                                }
                                if (supplier.SupplierWorkflows != null)
                                {
                                    foreach (SupplierWorkflow sw in supplier.SupplierWorkflows)
                                    {
                                        if (sw.WorkflowId == 1)
                                            transactionId = sw.TransactionId;
                                        if (sw.WorkflowId == 2)
                                            certTransactionId = sw.TransactionId;
                                    }
                                }
                                WorkflowHistoryCollection tempHistories = WorkflowHistoryUtility.FindByCriteria(
                                    ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                                    WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                                    new object[] { transactionId });
                                User qualDirector = null;
                                string qualApprovalDate = "";
                                if (tempHistories != null)
                                {
                                    foreach (WorkflowHistory wf in tempHistories)
                                    {
                                        if (wf.CurrentNodeName == SupplierStatusType.ApplicationSubmitted.Description)
                                            dateSubmitted = wf.DateCreated.ToShortDateString();
                                        if (wf.CurrentNodeName == SupplierStatusType.Qualified.Description)
                                            qualDirector = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, wf.CreatedBy);
                                    }
                                }
                                WorkflowHistoryCollection certTempHistories = WorkflowHistoryUtility.FindByCriteria(
                                    ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                                    WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                                    new object[] { certTransactionId });
                                User director = null;
                                string certApprovalDate = "";
                                if (certTempHistories != null)
                                {
                                    foreach (WorkflowHistory wf2 in certTempHistories)
                                    {
                                        if (wf2.CurrentNodeName == CertificationStatusType.DirectorApproved.Description)
                                            director = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, wf2.CreatedBy);
                                    }
                                }

                                string xml = "<ArrayOfDynamicProperty>";
                                xml += "<DynamicProperty PropertyName=\"V_SD_ADDL_SENT\" />";
                                xml += "<DynamicProperty PropertyName=\"V_SD_ADDL_SENT2\" />";
                                xml += "<DynamicProperty PropertyName=\"V_SD_PREQUAL_FROM\" />";
                                xml += "<DynamicProperty PropertyName=\"V_SD_PREQUAL_TO\" />";
                                xml += "</ArrayOfDynamicProperty>";

                                DynamicPropertyCollection properties = DynamicPropertyUtility.FindByCriteria(
                                    ConstantUtility.USER_DATASOURCE_NAME,
                                    DynamicPropertyManager.FIND_BY_PROPERTIES,
                                    new object[] { "SupplierStaticQualification", supplier.Id, xml });
                                bool is1900 = false;
                                if (properties != null)
                                {
                                    foreach (DynamicProperty prop in properties)
                                    {
                                        is1900 = prop.PropertyDate == new DateTime(1900, 1, 1);
                                        switch (prop.PropertyName)
                                        {
                                            case "V_SD_ADDL_SENT":
                                                if (thirtyDayDate == "")
                                                    thirtyDayDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                                                break;
                                            case "V_SD_ADDL_SENT2":
                                                qualTenDayDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                                                break;
                                            case "V_SD_PREQUAL_FROM":
                                                qualApprovalDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                                                break;
                                            case "V_SD_PREQUAL_TO":
                                                qualExpDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                                                
                                                break;
                                        }
                                    }
                                }

                                string xml2 = "<ArrayOfDynamicProperty>";
                                DynamicPropertyCollection types = DynamicPropertyUtility.FindByCriteria(
                                    ConstantUtility.USER_DATASOURCE_NAME,
                                    DynamicPropertyManager.FIND_BY_OBJECT,
                                    new object[] { "SupplierStaticCertification", supplier.Id });
                                if (types != null)
                                {
                                    foreach (DynamicProperty property in types)
                                    {
                                        xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_INFO_LETTER_SENT_1\" />";
                                        xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_INFO_LETTER_SENT_2\" />";
                                        xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_CERT_DATE\" />";
                                        xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_EXP_DATE\" />";
                                    }
                                }
                                xml2 += "</ArrayOfDynamicProperty>";

                                DynamicPropertyCollection properties2 = DynamicPropertyUtility.FindByCriteria(
                                    ConstantUtility.USER_DATASOURCE_NAME,
                                    DynamicPropertyManager.FIND_BY_PROPERTIES,
                                    new object[] { "SupplierStaticCertification", supplier.Id, xml2 });
                                if (properties2 != null)
                                {
                                    foreach (DynamicProperty prop2 in properties2)
                                    {
                                        if (prop2.PropertyDate != new DateTime(1900, 1, 1))
                                        {
                                            switch (prop2.PropertyName)
                                            {
                                                case "V_SD_INFO_LETTER_SENT_1":
                                                    if (thirtyDayDate == "")
                                                        thirtyDayDate = prop2.PropertyDate.ToShortDateString();
                                                    break;
                                                case "V_SD_INFO_LETTER_SENT_2":
                                                    certTenDayDate = prop2.PropertyDate.ToShortDateString();
                                                    break;
                                                case "V_SD_CERT_DATE":
                                                    certApprovalDate = prop2.PropertyDate.ToShortDateString();
                                                    break;
                                                case "V_SD_EXP_DATE":
                                                    certExpDate = prop2.PropertyDate.ToShortDateString();
                                                    break;
                                            }
                                        }
                                    }
                                }

                                string approvalDate = qualApprovalDate;
                                if (approvalDate == "")
                                    approvalDate = certApprovalDate;
                                else if (certApprovalDate != "")
                                    approvalDate += " (Qualification) & " + certApprovalDate + " (Certification)";
                                Replace(doc, "$APPROVALDATE$", approvalDate);

                                Replace(doc, "$DATERECEIVED$", dateSubmitted);

                                string expDate = qualExpDate;
                                if (expDate == "")
                                    expDate = certExpDate;
                                else if (certExpDate != "")
                                    expDate += " (Qualification) & " + certExpDate + " (Certification)";
                                Replace(doc, "$APPEXPIRATIONDATE$", expDate);
                                Replace(doc, "$QUALEXPIRATIONDATE$", qualExpDate);
                                //string certexpiredate = qualExpDate..ToString("MMMM dd, yyyy");
                               
                                Replace(doc, "$CERTEXPIRATIONDATE$", certExpDate);
                                Replace(doc, "$60DAYDATE$", sixtyDayDate);

                                string infoRequested = thirtyDayDate;
                                if (qualTenDayDate != "" || certTenDayDate != "")
                                {
                                    if (qualTenDayDate != "")
                                    {
                                        infoRequested = qualTenDayDate;
                                        if (certTenDayDate != "")
                                            infoRequested += " (Qualification) & " + certTenDayDate + " (Certification)";
                                    }
                                    else
                                        infoRequested = certTenDayDate;
                                }
                                Replace(doc, "$DATEADDITIONALINFOREQUESTED$", infoRequested);
                                Replace(doc, "$DATE30DAYSENT$", thirtyDayDate);
                                Replace(doc, "$FINALCLOSUREDATE$", closureDate);

                                string correspondenceNote = "";
                                SupplierDocument supplierDocument = SupplierDocumentUtility.GetByType(
                                    ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplier.Id, "OigApproveLetter");
                                if (supplierDocument != null && supplierDocument.Filename.Trim().Length > 0)
                                    correspondenceNote = "Correspondence has been uploaded.";
                                Replace(doc, "$CORRESPONDENCENOTE$", correspondenceNote);

                                DateTime twodays = DateTime.Now.AddDays(2);
                                while (twodays.DayOfWeek == DayOfWeek.Saturday || twodays.DayOfWeek == DayOfWeek.Sunday)
                                    twodays = twodays.AddDays(1);
                                Replace(doc, "$2BUSINESSDAYSFROMDATEASSIGNED$", twodays.ToShortDateString());

                                Replace(doc, "$BDDDIRECTOR$", (director == null) ? "" : director.FullName);
                                Replace(doc, "$BDDDIRECTORNAME$", (director == null) ? "" : director.FullName);
                                Replace(doc, "$BDDDIRECTORPHONE$", (director == null) ? "" : director.Phone);
                                Replace(doc, "$BDDDIRECTOREMAIL$", (director == null) ? "" : director.Email);
                                Replace(doc, "$BDDDIRECTORTITLE$", (director == null) ? "" : director.Title);
                                Replace(doc, "$BDDMANAGER$", (director == null) ? "" : director.FullName);
                                Replace(doc, "$BDDMANAGERNAME$", (director == null) ? "" : director.FullName);
                                Replace(doc, "$BDDMANAGERPHONE$", (director == null) ? "" : director.Phone);
                                Replace(doc, "$BDDMANAGEREMAIL$", (director == null) ? "" : director.Email);
                                Replace(doc, "$BDDMANAGERTITLE$", (director == null) ? "" : director.Title);
                                Replace(doc, "$CQUDIRECTOR$", (qualDirector == null) ? "" : qualDirector.FullName);
                                Replace(doc, "$CQUDIRECTORNAME$", (qualDirector == null) ? "" : qualDirector.FullName);
                                Replace(doc, "$CQUDIRECTORPHONE$", (qualDirector == null) ? "" : qualDirector.Phone);
                                Replace(doc, "$CQUDIRECTOREMAIL$", (qualDirector == null) ? "" : qualDirector.Email);
                                Replace(doc, "$CQUDIRECTORTITLE$", (qualDirector == null) ? "" : qualDirector.Title);

                                SupplierCommentCollection supplierComments = SupplierCommentUtility.FindByCriteria(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                                    SupplierCommentManager.FIND_SUPPLIERCOMMENT, new object[] { 0, 0, "", "", supplier.Id, "External" });
                                if (supplierComments != null)
                                {
                                    int count = 0;
                                    foreach (SupplierComment comment in supplierComments)
                                    {
                                        if (comment.Submitted != "Y")
                                        {
                                            string section = "";
                                            string filelink = comment.FileLink;
                                            string type = "";
                                            if (comment.FileLink.IndexOf("|") >= 0)
                                            {
                                                string[] filelinkArray = comment.FileLink.Split('|');
                                                if (filelinkArray.Length > 0)
                                                    filelink = filelinkArray[0];
                                                if (filelinkArray.Length > 1)
                                                    type = filelinkArray[1];
                                            }
                                            MenuCollection menus = CommonUtility.GetRegistrationMenus(supplier, type);
                                            GetCurrentMenu(menus, ConvertUtility.ConvertInt(filelink));
                                            if (currentStep != null)
                                            {
                                                if (currentStep.Text.IndexOf("Section") >= 0)
                                                {
                                                    foreach (SCA.VAS.ValueObjects.User.Menu menu in menus)
                                                        if (menu.Id == currentStep.ParentId)
                                                            section += menu.Text + ": ";
                                                }
                                                section += currentStep.Text;
                                            }
                                            if (doc.Tables.Count == 1)
                                            {
                                                Row newRow = null;
                                                if (doc.Tables[1].Rows.Count == 1 && count == 0)
                                                    newRow = doc.Tables[1].Rows[1];
                                                else
                                                    newRow = doc.Tables[1].Rows.Add(ref objMissing);
                                                newRow.Cells[1].Range.Text = section;
                                                newRow.Cells[2].Range.Text = comment.Comments;
                                                count++;
                                            }
                                        }
                                    }
                                }
                                //if (commentString.Length > 0)
                                //    commentString = commentString.Substring(0, commentString.Length - 2);
                                //Replace(doc, "$DYNAMICMISSINGINFO$", commentString);

                        

                                if (supplier.PhysicalAddress != null)
                                {
                                    supplier.PhysicalAddress.AddressLine1 = supplier.PhysicalAddress.AddressLine1.Replace("|", " ");
                                    supplier.PhysicalAddress.AddressLine2 = supplier.PhysicalAddress.AddressLine2.Trim().Length == 0 ? "" : "#" + supplier.PhysicalAddress.AddressLine2;

                                    Replace(doc, "$SUPPLIERPHYSICALADDRESS$", supplier.PhysicalAddress.AddressLine1);
                                    Replace(doc, "$SUPPLIERPHYSICALADDRESS2$", supplier.PhysicalAddress.AddressLine2);
                                    Replace(doc, "$SUPPLIERPHYSICALCITY$", supplier.PhysicalAddress.City);
                                    Replace(doc, "$SUPPLIERPHYSICALSTATE$", supplier.PhysicalAddress.State);
                                    Replace(doc, "$SUPPLIERPHYSICALZIP$", supplier.PhysicalAddress.ZipCode);
                                    Replace(doc, "$SUPPLIERPHYSICALCOUNTRY$", supplier.PhysicalAddress.Country);
                                }
                                else
                                {
                                    Replace(doc, "$SUPPLIERPHYSICALADDRESS$", "");
                                    Replace(doc, "$SUPPLIERPHYSICALADDRESS2$", "");
                                    Replace(doc, "$SUPPLIERPHYSICALCITY$", "");
                                    Replace(doc, "$SUPPLIERPHYSICALSTATE$", "");
                                    Replace(doc, "$SUPPLIERPHYSICALZIP$", "");
                                    Replace(doc, "$SUPPLIERPHYSICALCOUNTRY$", "");
                                }
                            }
                            else if (emailableObjs[i] is VendorContact)
                            {
                                VendorContact contact = (VendorContact)emailableObjs[i];
                                Replace(doc, "$SUPPLIERCONTACTNAME$", contact.Name);
                                Replace(doc, "$SUPPLIERCONTACTTITLE$", contact.Title);
                                Replace(doc, "$SUPPLIERCONTACTEMAIL$", contact.Email);
                                Replace(doc, "$SUPPLIERCONTACTPHONE$", contact.Phone);
                                Replace(doc, "$SUPPLIERCONTACTFAX$", contact.Fax);
                                Replace(doc, "$VENDORPRIMARYCONTACTUSERNAME$", contact.UserName);
                            }
                            else if (emailableObjs[i] is SupplierAddress)
                            {
                                SupplierAddress address = (SupplierAddress)emailableObjs[i];
                                Replace(doc, "$SUPPLIERADDRESSLINE1$", address.AddressLine1);
                                Replace(doc, "$SUPPLIERADDRESSLINE2$", address.AddressLine2);
                                Replace(doc, "$SUPPLIERADDRESSCITY$", address.City);
                                Replace(doc, "$SUPPLIERADDRESSSTATE$", address.State);
                                Replace(doc, "$SUPPLIERADDRESSZIPCODE$", address.ZipCode);
                            }
                            else if (emailableObjs[i] is Subcontractor)
                            {
                                Subcontractor subcontractor = (Subcontractor)emailableObjs[i];

                                subcontractor.SubcontractorProperties = SubcontractorPropertyUtility.FindByCriteria(
                                    ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                                    SubcontractorPropertyManager.FIND_BY_SUBCONTRACTOR,
                                    new object[] { subcontractor.Id });
                                if (subcontractor.SubcontractorProperties == null)
                                    subcontractor.SubcontractorProperties = new SubcontractorPropertyCollection();

                                string pendingReason = string.Empty;
                                pendingReason = CommonUtility.GetSubcontractorProperty("property30", subcontractor.SubcontractorProperties).PropertyText;
                                if (pendingReason == "Other:")
                                    pendingReason += " " + CommonUtility.GetSubcontractorProperty("property31", subcontractor.SubcontractorProperties).PropertyText;
                                Replace(doc, "$SAFPENDINGREASON$", pendingReason);

                                string disapproveReason = string.Empty;
                                disapproveReason = CommonUtility.GetSubcontractorProperty("property28", subcontractor.SubcontractorProperties).PropertyText;
                                if (disapproveReason == "Other:" || disapproveReason.IndexOf("not satisfactory for contract number:") >= 0)
                                    disapproveReason += " " + CommonUtility.GetSubcontractorProperty("property29", subcontractor.SubcontractorProperties).PropertyText;
                                Replace(doc, "$SAFDISAPPROVEREASON$", disapproveReason);

                                SubcontractorCommentCollection subcontractorComments = SubcontractorCommentUtility.FindByCriteria(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                                    SubcontractorCommentManager.FIND_SUBCONTRACTORCOMMENT, new object[] { 0, 0, "", "", subcontractor.Id, "External" });
                                string commentString = "";
                                if (subcontractorComments != null)
                                {
                                    int count = 0;
                                    string section = "";
                                    foreach (SubcontractorComment comment in subcontractorComments)
                                    {
                                        if (comment.Submitted != "Y")
                                        {
                                            //if (commentString == "")
                                            //    commentString = "<table border='1' cellpadding='3'>";
                                            //commentString += "<tr><td><b>";
                                            section = "";
                                            switch (comment.FileLink)
                                            {
                                                case "0":
                                                    section = "Company Information";
                                                    break;
                                                case "1":
                                                    section = "Apprenticeship Information";
                                                    break;
                                                case "2":
                                                    section = "License Information";
                                                    break;
                                                case "3":
                                                    section = "Insurance Information";
                                                    break;
                                            }
                                            //commentString += section + "</b></td><td>" + comment.Comments + "</td></tr>";
                                        }
                                        if (doc.Tables.Count == 1)
                                        {
                                            Row newRow = null;
                                            if (doc.Tables[1].Rows.Count == 1 && count == 0)
                                                newRow = doc.Tables[1].Rows[1];
                                            else
                                                newRow = doc.Tables[1].Rows.Add(ref objMissing);
                                            newRow.Cells[1].Range.Text = section;
                                            newRow.Cells[2].Range.Text = comment.Comments;
                                            count++;
                                        }
                                    }
                                }
                                //if (commentString != "")
                                //    commentString += "</table>";
                                //Replace(doc, "$SAFDYNAMICMISSINGINFO$", commentString);
                            }
                        }
                    }
                }

                // Save the changes
                doc.Save();

                // Close the doc and exit the app
                doc.Close(ref objMissing, ref objMissing, ref objMissing);

                objApp.Quit(
                    ref objMissing,     //SaveChanges
                    ref objMissing,     //OriginalFormat
                    ref objMissing      //RouteDocument
                    );
                objApp = null;
            }
            catch
            {
                try
                {
                    doc.Close(ref objMissing, ref objMissing, ref objMissing);
                    objApp.Quit(
                        ref objMissing,     //SaveChanges
                        ref objMissing,     //OriginalFormat
                        ref objMissing      //RouteDocument
                        );
                    objApp = null;
                }
                catch { }
            }

        }

        /// <summary>
        /// Perform document level TOKEN replacement of DOCX documents.
        /// </summary>
        /// <param name="strDoc">path of file that will be written</param>
        /// <param name="emailableObjs">array of objects used to replace token values</param>
        private static void ReplaceUsingOpenXML(string strDoc, object[] emailableObjs)
        {


            try
            {
                //fetch data into byte array from file, contrsucting a memory stream form the file will result 
                //in a possible issue as the size cannot change
                byte[] fileData = File.ReadAllBytes(strDoc);

                using (MemoryStream ms = new MemoryStream())
                {
                    ms.Write(fileData, 0, fileData.Length);
                    using (oXmlPkg.WordprocessingDocument wordDoc = oXmlPkg.WordprocessingDocument.Open(ms, true))
                    {
                        //fetch all the text elements from the document
                        //there is a possible issue that words can be split into multiple runs
                        //an example would be something like:
                        //$WORKFLOWCOMMENTS$ is present as a single word in the doument however when in the xml markup it is split into 3 items [$],[WORKFLOWCOMMENTS],[$]
                        //in this case the template needs to be changed by simply re-typing the token
                        IEnumerable<oXmlWp.Text> documentTexts = wordDoc.MainDocumentPart.Document.Body.Descendants<oXmlWp.Text>();

                        Replace(documentTexts, "$COMPANY$", ConfigurationManager.AppSettings["Company"]);
                        Replace(documentTexts, "$DATE$", DateTime.Now.ToString("MMMM dd, yyyy"));
                        
                        Replace(documentTexts, "$WORKFLOWCOMMENTS$", workflowcomments);
                        
                        #region Object Level Replacements
                        if (emailableObjs != null)
                        {
                            for (int i = 0; i < emailableObjs.Length; i++)
                            {
                                if (emailableObjs[i] != null)
                                {
                                    if (emailableObjs[i] is Supplier)
                                    {
                                        Supplier supplier = (Supplier)emailableObjs[i];
                                        Replace(documentTexts, "$FEDERALID$", supplier.FederalId);
                                        Replace(documentTexts, "$SUPPLIERCOMPANY$", supplier.Company);
                                        Replace(documentTexts, "$VENDORCOMPANY$", supplier.Company);
                                        Replace(documentTexts, "$FEDERALID$", supplier.FederalId);
                                        Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "Supplier", supplier.Id.ToString());
                                        VendorContact primaryContact = vendor == null ? null : CommonUtility.GetPrimaryContact(vendor.Id);
                                        Replace(documentTexts, "$VENDORPRIMARYCONTACTUSERNAME$", primaryContact == null ? "" : primaryContact.UserName);
                                        Replace(documentTexts, "$SITEURL$", ConfigurationSettings.AppSettings["SiteUrl"].ToString());
                                        Replace(documentTexts, "$SITELINK$", ConfigurationSettings.AppSettings["SiteUrl"].ToString());
                                        Replace(documentTexts, "$INTERNALSITEURL$", ConfigurationSettings.AppSettings["InternalSiteUrl"].ToString());
                                        Replace(documentTexts, "$INTERNALSITELINK$", ConfigurationSettings.AppSettings["InternalSiteUrl"].ToString());

                                        string searchUrl = ConfigurationSettings.AppSettings["InternalSiteUrl"].ToString() + "/Supplier/Supplier_Search_Results.aspx?Id=" + supplier.Id.ToString();
                                        Replace(documentTexts, "$SEARCHSUPPLIERLINK$", searchUrl);

                                        string commentUrl = ConfigurationSettings.AppSettings["InternalSiteUrl"].ToString() + "/Supplier/Workflow_Supplier_Comments.aspx?Id=" + supplier.Id.ToString();
                                        Replace(documentTexts, "$SUPPLIERCOMMENTLINK$", commentUrl);

                                        string responseUrl = ConfigurationSettings.AppSettings["SiteUrl"].ToString() + "/Supplier/Supplier_More_Info.aspx";
                                        Replace(documentTexts, "$LETTERRESPONSELINK$", responseUrl);

                                        string appType = "";
                                        if (supplier.IsBoth())
                                            appType = "Qualification and Certification";
                                        else if (supplier.IsCert())
                                            appType = "Certification";
                                        else if (supplier.IsQual())
                                            appType = "Qualification";

                                        Replace(documentTexts, "$APPLICATIONTYPE$", appType);
                                        Replace(documentTexts, "$CQUDIVISION$", (appType.IndexOf("Qualification") < 0) ? "" : "Pre-qualification Division");
                                        Replace(documentTexts, "$BDDDIVISION$", (appType.IndexOf("Certification") < 0) ? "" : "Business Development Division");

                                        string certType = "";
                                        foreach (SupplierProperty sp in CommonUtility.GetSupplierProperties("property519", supplier.SupplierProperties))
                                        {
                                            if (sp.PropertyText == "MBE" || sp.PropertyText == "WBE" || sp.PropertyText == "LBE")
                                                certType += sp.PropertyText + "/";
                                        }
                                        if (certType != "")
                                            certType = certType.Substring(0, certType.Length - 1);
                                        Replace(documentTexts, "$CERTTYPE$", certType);

                                        SupplierStatus qualStatus = null;
                                        SupplierStatus certStatus = null;
                                        if (supplier.SupplierStatuses != null)
                                        {
                                            qualStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_QUALIFICATION);
                                            certStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);
                                        }
                                        bool isQualified = false;
                                        bool isCertified = false;
                                        string qualType = "";
                                        if (qualStatus != null && qualStatus.Status == SupplierStatusType.Qualified.Description)
                                            isQualified = true;
                                        if (certStatus != null && certStatus.Status == CertificationStatusType.Certified.Description)
                                            isCertified = true;
                                        if (isQualified && isCertified)
                                            qualType = "Qualified/Certified";
                                        else
                                        {
                                            if (isQualified)
                                                qualType = "Qualified";
                                            if (isCertified)
                                                qualType = "Certified";
                                        }
                                        Replace(documentTexts, "$QUALIFIEDTYPE$", qualType);

                                        //CERT deny date
                                        foreach (SupplierWorkflow sf in supplier.SupplierWorkflows)
                                        {
                                            if (sf.WorkflowId == 2)
                                            {
                                                WorkflowHistoryCollection tempcertHistories = WorkflowHistoryUtility
                                                    .FindByCriteria(
                                                        ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                                                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                                                        new object[] {sf.TransactionId});

                                                if (tempcertHistories != null)
                                                {
                                                    foreach (WorkflowHistory wf in tempcertHistories)
                                                    {
                                                        if (wf.CurrentNodeName == "Deny")
                                                        {
                                                            string certdenydate = wf.DateCreated.ToString("MMMM dd, yyyy");
                                                            Replace(documentTexts, "$CERTDENYDATE$", certdenydate);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                       

                                        string qualificationType = "qualification";
                                        if ((supplier.Status & 1) == 1 || (supplier.Status & 2) == 2)
                                            qualificationType = "requalification";
                                        Replace(documentTexts, "$QUALIFICATIONTYPE$", qualificationType);

                                        Replace(documentTexts, "$OIGDECISION$", CommonUtility.GetSupplierProperty("property508", supplier.SupplierProperties).PropertyText);
                                        Replace(documentTexts, "$OIGCOMMENTS$", CommonUtility.GetSupplierProperty("property515", supplier.SupplierProperties).PropertyText);

                                        User analyst = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, CommonUtility.GetSupplierProperty("property524", supplier.SupplierProperties).PropertyText);
                                        Replace(documentTexts, "$BDDANALYST$", (analyst == null) ? "" : analyst.FullName);
                                        Replace(documentTexts, "$BDDANALYSTNAME$", (analyst == null) ? "" : analyst.FullName);
                                        Replace(documentTexts, "$BDDANALYSTPHONE$", (analyst == null) ? "" : analyst.Phone);
                                        Replace(documentTexts, "$BDDANALYSTEMAIL$", (analyst == null) ? "" : analyst.Email);
                                        Replace(documentTexts, "$BDDANALYSTTITLE$", (analyst == null) ? "" : analyst.Title);

                                        User manager = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, CommonUtility.GetSupplierProperty("property521", supplier.SupplierProperties).PropertyText);
                                        Replace(documentTexts, "$CQUMANAGER$", (manager == null) ? "" : manager.FullName);
                                        Replace(documentTexts, "$CQUMANAGERNAME$", (manager == null) ? "" : manager.FullName);
                                        Replace(documentTexts, "$CQUMANAGERPHONE$", (manager == null) ? "" : manager.Phone);
                                        Replace(documentTexts, "$CQUMANAGEREMAIL$", (manager == null) ? "" : manager.Email);
                                        Replace(documentTexts, "$CQUMANAGERTITLE$", (manager == null) ? "" : manager.Title);

                                        User reviewer = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, CommonUtility.GetSupplierProperty("property10", supplier.SupplierProperties).PropertyText);
                                        Replace(documentTexts, "$CQUREVIEWER$", (reviewer == null) ? "" : reviewer.FullName);
                                        Replace(documentTexts, "$CQUREVIEWERNAME$", (reviewer == null) ? "" : reviewer.FullName);
                                        Replace(documentTexts, "$CQUREVIEWERPHONE$", (reviewer == null) ? "" : reviewer.Phone);
                                        Replace(documentTexts, "$CQUREVIEWEREMAIL$", (reviewer == null) ? "" : reviewer.Email);
                                        Replace(documentTexts, "$CQUREVIEWERTITLE$", (reviewer == null) ? "" : reviewer.Title);

                                        string letterContact = "";
                                        if (appType.IndexOf("Qualification") >= 0 && reviewer != null)
                                            letterContact = reviewer.FullName + " at " + reviewer.Phone + " for prequalification related questions";
                                        if (appType.IndexOf("Certification") >= 0 && analyst != null)
                                            letterContact += letterContact == "" ? analyst.FullName + " at " + analyst.Phone + " for certification related questions" : " and for certification questions " + analyst.FullName + " at " + analyst.Phone;
                                        Replace(documentTexts, "$LETTERCONTACTINFO$", letterContact);

                                        SupplierPersonnel majorityOwner = null;
                                        SupplierPersonnelCollection keypeople = SupplierPersonnelUtility.FindByCriteria(
                                            ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                                            SupplierPersonnelManager.FIND_SUPPLIERPERSONNEL,
                                            new object[] { supplier.Id, "Y" });
                                        if (keypeople != null)
                                        {
                                            foreach (SupplierPersonnel sp in keypeople)
                                            {
                                                if (sp.IsOwner == "Y")
                                                {
                                                    if (majorityOwner == null || sp.OwnedPercentage > majorityOwner.OwnedPercentage)
                                                        majorityOwner = sp;
                                                }
                                            }
                                        }
                                        if (majorityOwner != null)
                                            Replace(documentTexts, "$MAJORITYOWNER$", (majorityOwner == null) ? "" : majorityOwner.Name.Replace("|", " "));

                                        if (supplier.TradeNames != null)
                                            Replace(documentTexts, "$DBANAME$", supplier.TradeNames);

                                        string qualifiedTrades = "";
                                        string millionTrades = "";
                                        if (supplier.SupplierCategories != null)
                                        {
                                            foreach (SupplierCategory sc in supplier.SupplierCategories)
                                            {
                                                if (sc.IsApproved == "Y")
                                                {
                                                    qualifiedTrades += "(" + sc.Category.Code + ") " + sc.CategoryName + "; ";
                                                    if (sc.ApprovedAverage == "under")
                                                        millionTrades += "(" + sc.Category.Code + ") " + sc.CategoryName + "; ";
                                                }
                                            }
                                            if (qualifiedTrades.Trim().Length > 0)
                                                qualifiedTrades = qualifiedTrades.Substring(0, qualifiedTrades.Length - 2);
                                            if (millionTrades.Trim().Length > 0)
                                                millionTrades = millionTrades.Substring(0, millionTrades.Length - 2);
                                        }
                                        Replace(documentTexts, "$QUALIFIEDTRADES$", qualifiedTrades);
                                        Replace(documentTexts, "$1MQUALIFIEDTRADES$", millionTrades);

                                        int transactionId = 0;
                                        int certTransactionId = 0;
                                        string dateSubmitted = "";
                                        string qualExpDate = "";
                                        string certExpDate = "";
                                        string sixtyDayDate = "";
                                        string thirtyDayDate = "";
                                        string qualTenDayDate = "";
                                        string certTenDayDate = "";
                                        string closureDate = "";
                                        string certexpiredate = "";
                                        if (emailname == "30DAY_LETTER_NOTICE")
                                        {
                                            closureDate = DateTime.Now.AddDays(30).ToShortDateString();
                                            thirtyDayDate = DateTime.Now.ToShortDateString();
                                        }
                                        else if (emailname.IndexOf("10DAY_LETTER_NOTICE") == 0)
                                        {
                                            closureDate = DateTime.Now.AddDays(10).ToShortDateString();
                                            if (emailname.ToLower().IndexOf("cert") >= 0)
                                                certTenDayDate = DateTime.Now.ToShortDateString();
                                            else
                                                qualTenDayDate = DateTime.Now.ToShortDateString();
                                        }
                                        if (supplier.SupplierWorkflows != null)
                                        {
                                            foreach (SupplierWorkflow sw in supplier.SupplierWorkflows)
                                            {
                                                if (sw.WorkflowId == 1)
                                                    transactionId = sw.TransactionId;
                                                if (sw.WorkflowId == 2)
                                                    certTransactionId = sw.TransactionId;
                                            }
                                        }
                                        WorkflowHistoryCollection tempHistories = WorkflowHistoryUtility.FindByCriteria(
                                            ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                                            WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                                            new object[] { transactionId });
                                        User qualDirector = null;
                                        string qualApprovalDate = "";
                                        if (tempHistories != null)
                                        {
                                            foreach (WorkflowHistory wf in tempHistories)
                                            {
                                                if (wf.CurrentNodeName == SupplierStatusType.ApplicationSubmitted.Description)
                                                    dateSubmitted = wf.DateCreated.ToShortDateString();
                                                if (wf.CurrentNodeName == SupplierStatusType.Qualified.Description)
                                                    qualDirector = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, wf.CreatedBy);
                                            }
                                        }
                                        WorkflowHistoryCollection certTempHistories = WorkflowHistoryUtility.FindByCriteria(
                                            ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                                            WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                                            new object[] { certTransactionId });
                                        User director = null;
                                        string certApprovalDate = "";
                                        if (certTempHistories != null)
                                        {
                                            foreach (WorkflowHistory wf2 in certTempHistories)
                                            {
                                                if (wf2.CurrentNodeName == CertificationStatusType.DirectorApproved.Description)
                                                    director = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, wf2.CreatedBy);
                                            }
                                        }

                                        string xml = "<ArrayOfDynamicProperty>";
                                        xml += "<DynamicProperty PropertyName=\"V_SD_ADDL_SENT\" />";
                                        xml += "<DynamicProperty PropertyName=\"V_SD_ADDL_SENT2\" />";
                                        xml += "<DynamicProperty PropertyName=\"V_SD_PREQUAL_FROM\" />";
                                        xml += "<DynamicProperty PropertyName=\"V_SD_PREQUAL_TO\" />";
                                        xml += "</ArrayOfDynamicProperty>";

                                        DynamicPropertyCollection properties = DynamicPropertyUtility.FindByCriteria(
                                            ConstantUtility.USER_DATASOURCE_NAME,
                                            DynamicPropertyManager.FIND_BY_PROPERTIES,
                                            new object[] { "SupplierStaticQualification", supplier.Id, xml });
                                        bool is1900 = false;
                                        if (properties != null)
                                        {
                                            foreach (DynamicProperty prop in properties)
                                            {
                                                is1900 = prop.PropertyDate == new DateTime(1900, 1, 1);
                                                switch (prop.PropertyName)
                                                {
                                                    case "V_SD_ADDL_SENT":
                                                        if (thirtyDayDate == "")
                                                            thirtyDayDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                                                        break;
                                                    case "V_SD_ADDL_SENT2":
                                                        qualTenDayDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                                                        break;
                                                    case "V_SD_PREQUAL_FROM":
                                                        qualApprovalDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                                                        break;
                                                    case "V_SD_PREQUAL_TO":
                                                        qualExpDate = is1900 ? "" : prop.PropertyDate.ToShortDateString();
                                                        certexpiredate = is1900 ? "" : prop.PropertyDate.ToString("MMMM dd, yyyy");
                                                        break;
                                                }
                                            }
                                        }

                                        string xml2 = "<ArrayOfDynamicProperty>";
                                        DynamicPropertyCollection types = DynamicPropertyUtility.FindByCriteria(
                                            ConstantUtility.USER_DATASOURCE_NAME,
                                            DynamicPropertyManager.FIND_BY_OBJECT,
                                            new object[] { "SupplierStaticCertification", supplier.Id });
                                        if (types != null)
                                        {
                                            foreach (DynamicProperty property in types)
                                            {
                                                xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_INFO_LETTER_SENT_1\" />";
                                                xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_INFO_LETTER_SENT_2\" />";
                                                xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_CERT_DATE\" />";
                                                xml2 += "<DynamicProperty PropertyType=\"" + property.PropertyType + "\" PropertyName=\"V_SD_EXP_DATE\" />";
                                            }
                                        }
                                        xml2 += "</ArrayOfDynamicProperty>";

                                        DynamicPropertyCollection properties2 = DynamicPropertyUtility.FindByCriteria(
                                            ConstantUtility.USER_DATASOURCE_NAME,
                                            DynamicPropertyManager.FIND_BY_PROPERTIES,
                                            new object[] { "SupplierStaticCertification", supplier.Id, xml2 });
                                        if (properties2 != null)
                                        {
                                            foreach (DynamicProperty prop2 in properties2)
                                            {
                                                if (prop2.PropertyDate != new DateTime(1900, 1, 1))
                                                {
                                                    switch (prop2.PropertyName)
                                                    {
                                                        case "V_SD_INFO_LETTER_SENT_1":
                                                            if (thirtyDayDate == "")
                                                                thirtyDayDate = prop2.PropertyDate.ToShortDateString();
                                                            break;
                                                        case "V_SD_INFO_LETTER_SENT_2":
                                                            certTenDayDate = prop2.PropertyDate.ToShortDateString();
                                                            break;
                                                        case "V_SD_CERT_DATE":
                                                            certApprovalDate = prop2.PropertyDate.ToShortDateString();
                                                            break;
                                                        case "V_SD_EXP_DATE":
                                                            certExpDate = prop2.PropertyDate.ToShortDateString();
                                                            break;
                                                    }
                                                }
                                            }
                                        }

                                        string approvalDate = qualApprovalDate;
                                        if (approvalDate == "")
                                            approvalDate = certApprovalDate;
                                        else if (certApprovalDate != "")
                                            approvalDate += " (Qualification) & " + certApprovalDate + " (Certification)";
                                        Replace(documentTexts, "$APPROVALDATE$", approvalDate);

                                        Replace(documentTexts, "$DATERECEIVED$", dateSubmitted);

                                        string expDate = qualExpDate;
                                        if (expDate == "")
                                            expDate = certExpDate;
                                        else if (certExpDate != "")
                                            expDate += " (Qualification) & " + certExpDate + " (Certification)";
                                        Replace(documentTexts, "$APPEXPIRATIONDATE$", expDate);
                                        Replace(documentTexts, "$QUALEXPIRATIONDATE$", qualExpDate);
                                        Replace(documentTexts, "$CERTEXPIREDDATE$", certexpiredate);
                                        Replace(documentTexts, "$CERTEXPIRATIONDATE$", certExpDate != "" ? certExpDate : certexpiredate);
                                        Replace(documentTexts, "$60DAYDATE$", sixtyDayDate);

                                        string infoRequested = thirtyDayDate;
                                        if (qualTenDayDate != "" || certTenDayDate != "")
                                        {
                                            if (qualTenDayDate != "")
                                            {
                                                infoRequested = qualTenDayDate;
                                                if (certTenDayDate != "")
                                                    infoRequested += " (Qualification) & " + certTenDayDate + " (Certification)";
                                            }
                                            else
                                                infoRequested = certTenDayDate;
                                        }
                                        Replace(documentTexts, "$DATEADDITIONALINFOREQUESTED$", infoRequested);
                                        Replace(documentTexts, "$DATE30DAYSENT$", thirtyDayDate);
                                        Replace(documentTexts, "$FINALCLOSUREDATE$", closureDate);

                                        string correspondenceNote = "";
                                        SupplierDocument supplierDocument = SupplierDocumentUtility.GetByType(
                                            ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplier.Id, "OigApproveLetter");
                                        if (supplierDocument != null && supplierDocument.Filename.Trim().Length > 0)
                                            correspondenceNote = "Correspondence has been uploaded.";
                                        Replace(documentTexts, "$CORRESPONDENCENOTE$", correspondenceNote);

                                        DateTime twodays = DateTime.Now.AddDays(2);
                                        while (twodays.DayOfWeek == DayOfWeek.Saturday || twodays.DayOfWeek == DayOfWeek.Sunday)
                                            twodays = twodays.AddDays(1);
                                        Replace(documentTexts, "$2BUSINESSDAYSFROMDATEASSIGNED$", twodays.ToShortDateString());

                                        Replace(documentTexts, "$BDDDIRECTOR$", (director == null) ? "" : director.FullName);
                                        Replace(documentTexts, "$BDDDIRECTORNAME$", (director == null) ? "" : director.FullName);
                                        Replace(documentTexts, "$BDDDIRECTORPHONE$", (director == null) ? "" : director.Phone);
                                        Replace(documentTexts, "$BDDDIRECTOREMAIL$", (director == null) ? "" : director.Email);
                                        Replace(documentTexts, "$BDDDIRECTORTITLE$", (director == null) ? "" : director.Title);
                                        Replace(documentTexts, "$BDDMANAGER$", (director == null) ? "" : director.FullName);
                                        Replace(documentTexts, "$BDDMANAGERNAME$", (director == null) ? "" : director.FullName);
                                        Replace(documentTexts, "$BDDMANAGERPHONE$", (director == null) ? "" : director.Phone);
                                        Replace(documentTexts, "$BDDMANAGEREMAIL$", (director == null) ? "" : director.Email);
                                        Replace(documentTexts, "$BDDMANAGERTITLE$", (director == null) ? "" : director.Title);
                                        Replace(documentTexts, "$CQUDIRECTOR$", (qualDirector == null) ? "" : qualDirector.FullName);
                                        Replace(documentTexts, "$CQUDIRECTORNAME$", (qualDirector == null) ? "" : qualDirector.FullName);
                                        Replace(documentTexts, "$CQUDIRECTORPHONE$", (qualDirector == null) ? "" : qualDirector.Phone);
                                        Replace(documentTexts, "$CQUDIRECTOREMAIL$", (qualDirector == null) ? "" : qualDirector.Email);
                                        Replace(documentTexts, "$CQUDIRECTORTITLE$", (qualDirector == null) ? "" : qualDirector.Title);

                                        SupplierCommentCollection supplierComments = SupplierCommentUtility.FindByCriteria(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                                            SupplierCommentManager.FIND_SUPPLIERCOMMENT, new object[] { 0, 0, "", "", supplier.Id, "External" });
                                        if (supplierComments != null)
                                        {
                                            int count = 0;
                                            var tables = wordDoc.MainDocumentPart.Document.Body.Descendants<oXmlWp.Table>().ToList();
                                            if (tables.Count() == 1)
                                            {
                                                var props = tables[0].Descendants<oXmlWp.TableProperties>().ToList();

                                                if (props.Count >= 0)
                                                {
                                                    if (props[0].TableLayout == null)
                                                    {
                                                        props[0].TableLayout = new oXmlWp.TableLayout();
                                                    }

                                                    props[0].TableLayout.Type = oXmlWp.TableLayoutValues.Fixed;
                                                }
                                            }

                                            foreach (SupplierComment comment in supplierComments)
                                            {
                                                if (comment.Submitted != "Y")
                                                {
                                                    string section = "";
                                                    string filelink = comment.FileLink;
                                                    string type = "";
                                                    if (comment.FileLink.IndexOf("|") >= 0)
                                                    {
                                                        string[] filelinkArray = comment.FileLink.Split('|');
                                                        if (filelinkArray.Length > 0)
                                                            filelink = filelinkArray[0];
                                                        if (filelinkArray.Length > 1)
                                                            type = filelinkArray[1];
                                                    }
                                                    MenuCollection menus = CommonUtility.GetRegistrationMenus(supplier, type);
                                                    GetCurrentMenu(menus, ConvertUtility.ConvertInt(filelink));
                                                    if (currentStep != null)
                                                    {
                                                        if (currentStep.Text.IndexOf("Section") >= 0)
                                                        {
                                                            foreach (SCA.VAS.ValueObjects.User.Menu menu in menus)
                                                                if (menu.Id == currentStep.ParentId)
                                                                    section += menu.Text + ": ";
                                                        }
                                                        section += currentStep.Text;
                                                    }

                                                    //var tables = wordDoc.MainDocumentPart.Document.Body.Descendants<oXmlWp.Table>().ToList();
                                                    if (tables.Count() == 1)
                                                    {
                                                        var rows = tables[0].Descendants<oXmlWp.TableRow>().ToList();
                                                        if (rows.Count() == 1 && count == 0)
                                                        {
                                                            var cells = rows[0].Descendants<oXmlWp.TableCell>().ToList();
                                                            cells[0].RemoveAllChildren();
                                                            cells[1].RemoveAllChildren();
                                                            cells[0].Append(new oXmlWp.Paragraph(new oXmlWp.Run(new oXmlWp.Text(section))));
                                                            cells[1].Append(new oXmlWp.Paragraph(new oXmlWp.Run(new oXmlWp.Text(comment.Comments))));
                                                        }
                                                        else
                                                        {
                                                            var newRow = new oXmlWp.TableRow();
                                                            newRow.Append(new oXmlWp.TableCell(new oXmlWp.Paragraph(new oXmlWp.Run(new oXmlWp.Text(section)))));
                                                            newRow.Append(new oXmlWp.TableCell(new oXmlWp.Paragraph(new oXmlWp.Run(new oXmlWp.Text(comment.Comments)))));
                                                            tables[0].AppendChild(newRow);
                                                        }
                                                        count++;
                                                    }


                                                    //if (doc.Tables.Count == 1)
                                                    //{
                                                    //    Row newRow = null;
                                                    //    if (doc.Tables[1].Rows.Count == 1 && count == 0)
                                                    //        newRow = doc.Tables[1].Rows[1];
                                                    //    else
                                                    //        newRow = doc.Tables[1].Rows.Add(ref objMissing);
                                                    //    newRow.Cells[1].Range.Text = section;
                                                    //    newRow.Cells[2].Range.Text = comment.Comments;
                                                    //    count++;
                                                    //}
                                                }
                                            }
                                        }
                                        //if (commentString.Length > 0)
                                        //    commentString = commentString.Substring(0, commentString.Length - 2);
                                        //Replace(doc, "$DYNAMICMISSINGINFO$", commentString);
                                        if (supplier!=null)
                                        {
                                            string certtype1 = "";
                                            SupplierStatusCollection supplierStatusCollection = supplier.SupplierStatuses;
                                     
                                            foreach (SupplierStatus supplierStatus in supplierStatusCollection)
                                            {
                                                if (supplierStatus.TypeName == "IsMBEApproveByDirector")
                                                    certtype1 += "M";
                                                else if (supplierStatus.TypeName == "IsWBEApproveByDirector")
                                                    certtype1 += "W";
                                                else if (supplierStatus.TypeName == "IsLBEApproveByDirector")
                                                    certtype1 += "L";
                                            }

                                            if (certtype1.IndexOf("MW") != -1)
                                            {
                                                if (certtype1.IndexOf("L") != -1)
                                                {
                                                    Replace(documentTexts, "$CERTTYPE1$", "Minority-Woman Owned Business Enterprise & Locally Based Enterprise");
                                                    Replace(documentTexts, "$SHORTS$", "MBE,WBE,LBE");
                                                }
                                                else
                                                {
                                                    Replace(documentTexts, "$CERTTYPE1$", "Minority-Woman Owned Business Enterprise");
                                                    Replace(documentTexts, "$SHORTS$", "MBE,WBE");
                                                }                                        
                                            }

                                            else if (certtype1.IndexOf("M") != -1)
                                            {
                                                if (certtype1.IndexOf("L") != -1)
                                                {
                                                    Replace(documentTexts, "$CERTTYPE1$", "Minority Owned Business Enterprise & Locally Based Enterprise");
                                                    Replace(documentTexts, "$SHORTS$", "MBE,LBE");
                                                }
                                                else
                                                {
                                                    Replace(documentTexts, "$CERTTYPE1$", "Minority Owned Business Enterprise");
                                                    Replace(documentTexts, "$SHORTS$", "MBE");
                                                }

                                            }

                                            else if (certtype1.IndexOf("W") != -1)
                                            {
                                                if (certtype1.IndexOf("L") != -1)
                                                {
                                                    Replace(documentTexts, "$CERTTYPE1$", "Woman Owned Business Enterprise & Locally Based Enterprise");
                                                    Replace(documentTexts, "$SHORTS$", "WBE,LBE");
                                                }
                                                else
                                                {
                                                    Replace(documentTexts, "$CERTTYPE1$", "Woman Owned Business Enterprise");
                                                    Replace(documentTexts, "$SHORTS$", "WBE");
                                                }

                                            }

                                            else if (certtype1.IndexOf("L") != -1)
                                            {
                                                Replace(documentTexts, "$CERTTYPE1$", "Locally Based Enterprise");
                                                Replace(documentTexts, "$SHORTS$", "LBE");
                                            }
                                            string deniedreason = CommonUtility.GetSupplierProperty("property503", supplier.SupplierProperties).PropertyText;                                          
                                            Replace(documentTexts, "$DENIEDREASON$", deniedreason);
                                            SupplierCertDenialAppeal appealrecord = SupplierCertDenialAppealUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplier.Id);
                                            if (appealrecord != null)
                                            {
                                                Replace(documentTexts, "$APPEALDENYREASON$", appealrecord.SupervisorComments);
                                                Replace(documentTexts, "$CERTAPPEALTYPE$", appealrecord.SupervisorRecommendation);
                                            }
                                                
                                        }


                                        if (supplier.PhysicalAddress != null)
                                        {
                                            supplier.PhysicalAddress.AddressLine1 = supplier.PhysicalAddress.AddressLine1.Replace("|", " ");
                                            supplier.PhysicalAddress.AddressLine2 = supplier.PhysicalAddress.AddressLine2.Trim().Length == 0 ? "" : "#" + supplier.PhysicalAddress.AddressLine2;

                                            Replace(documentTexts, "$SUPPLIERPHYSICALADDRESS$", supplier.PhysicalAddress.AddressLine1);
                                            Replace(documentTexts, "$SUPPLIERPHYSICALADDRESS2$", supplier.PhysicalAddress.AddressLine2);
                                            Replace(documentTexts, "$SUPPLIERPHYSICALCITY$", supplier.PhysicalAddress.City);
                                            Replace(documentTexts, "$SUPPLIERPHYSICALSTATE$", supplier.PhysicalAddress.State);
                                            Replace(documentTexts, "$SUPPLIERPHYSICALZIP$", supplier.PhysicalAddress.ZipCode);
                                            Replace(documentTexts, "$SUPPLIERPHYSICALCOUNTRY$", supplier.PhysicalAddress.Country);
                                           
                                            
                                        }
                                        else
                                        {
                                            Replace(documentTexts, "$SUPPLIERPHYSICALADDRESS$", "");
                                            Replace(documentTexts, "$SUPPLIERPHYSICALADDRESS2$", "");
                                            Replace(documentTexts, "$SUPPLIERPHYSICALCITY$", "");
                                            Replace(documentTexts, "$SUPPLIERPHYSICALSTATE$", "");
                                            Replace(documentTexts, "$SUPPLIERPHYSICALZIP$", "");
                                            Replace(documentTexts, "$SUPPLIERPHYSICALCOUNTRY$", "");
                                        }
                                    }
                                    else if (emailableObjs[i] is VendorContact)
                                    {
                                        VendorContact contact = (VendorContact)emailableObjs[i];
                                        Replace(documentTexts, "$SUPPLIERCONTACTNAME$", contact.Name);
                                        Replace(documentTexts, "$SUPPLIERCONTACTTITLE$", contact.Title);
                                        Replace(documentTexts, "$SUPPLIERCONTACTEMAIL$", contact.Email);
                                        Replace(documentTexts, "$SUPPLIERCONTACTPHONE$", contact.Phone);
                                        Replace(documentTexts, "$SUPPLIERCONTACTFAX$", contact.Fax);
                                        Replace(documentTexts, "$VENDORPRIMARYCONTACTUSERNAME$", contact.UserName);
                                    }
                                    else if (emailableObjs[i] is SupplierAddress)
                                    {
                                        SupplierAddress address = (SupplierAddress)emailableObjs[i];
                                        Replace(documentTexts, "$SUPPLIERADDRESSLINE1$", address.AddressLine1);
                                        Replace(documentTexts, "$SUPPLIERADDRESSLINE2$", address.AddressLine2);
                                        Replace(documentTexts, "$SUPPLIERADDRESSCITY$", address.City);
                                        Replace(documentTexts, "$SUPPLIERADDRESSSTATE$", address.State);
                                        Replace(documentTexts, "$SUPPLIERADDRESSZIPCODE$", address.ZipCode);
                                    }
                                    else if (emailableObjs[i] is Subcontractor)
                                    {
                                        Subcontractor subcontractor = (Subcontractor)emailableObjs[i];

                                        subcontractor.SubcontractorProperties = SubcontractorPropertyUtility.FindByCriteria(
                                            ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                                            SubcontractorPropertyManager.FIND_BY_SUBCONTRACTOR,
                                            new object[] { subcontractor.Id });
                                        if (subcontractor.SubcontractorProperties == null)
                                            subcontractor.SubcontractorProperties = new SubcontractorPropertyCollection();

                                        string pendingReason = string.Empty;
                                        pendingReason = CommonUtility.GetSubcontractorProperty("property30", subcontractor.SubcontractorProperties).PropertyText;
                                        if (pendingReason == "Other:")
                                            pendingReason += " " + CommonUtility.GetSubcontractorProperty("property31", subcontractor.SubcontractorProperties).PropertyText;
                                        Replace(documentTexts, "$SAFPENDINGREASON$", pendingReason);

                                        string disapproveReason = string.Empty;
                                        disapproveReason = CommonUtility.GetSubcontractorProperty("property28", subcontractor.SubcontractorProperties).PropertyText;
                                        if (disapproveReason == "Other:" || disapproveReason.IndexOf("not satisfactory for contract number:") >= 0)
                                            disapproveReason += " " + CommonUtility.GetSubcontractorProperty("property29", subcontractor.SubcontractorProperties).PropertyText;
                                        Replace(documentTexts, "$SAFDISAPPROVEREASON$", disapproveReason);

                                        SubcontractorCommentCollection subcontractorComments = SubcontractorCommentUtility.FindByCriteria(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                                            SubcontractorCommentManager.FIND_SUBCONTRACTORCOMMENT, new object[] { 0, 0, "", "", subcontractor.Id, "External" });
                                        string commentString = "";
                                        if (subcontractorComments != null)
                                        {
                                            int count = 0;
                                            string section = "";

                                            var tables = wordDoc.MainDocumentPart.Document.Body.Descendants<oXmlWp.Table>().ToList();
                                            if (tables.Count() == 1)
                                            {
                                                var props = tables[0].Descendants<oXmlWp.TableProperties>().ToList();

                                                if (props.Count >= 0)
                                                {
                                                    if (props[0].TableLayout == null)
                                                    {
                                                        props[0].TableLayout = new oXmlWp.TableLayout();
                                                    }

                                                    props[0].TableLayout.Type = oXmlWp.TableLayoutValues.Fixed;
                                                }
                                            }

                                            foreach (SubcontractorComment comment in subcontractorComments)
                                            {
                                                if (comment.Submitted != "Y")
                                                {
                                                    //if (commentString == "")
                                                    //    commentString = "<table border='1' cellpadding='3'>";
                                                    //commentString += "<tr><td><b>";
                                                    section = "";
                                                    switch (comment.FileLink)
                                                    {
                                                        case "0":
                                                            section = "Company Information";
                                                            break;
                                                        case "1":
                                                            section = "Apprenticeship Information";
                                                            break;
                                                        case "2":
                                                            section = "License Information";
                                                            break;
                                                        case "3":
                                                            section = "Insurance Information";
                                                            break;
                                                    }
                                                    //commentString += section + "</b></td><td>" + comment.Comments + "</td></tr>";
                                                }

                                                if (tables.Count() == 1)
                                                {
                                                    var rows = tables[0].Descendants<oXmlWp.TableRow>().ToList();
                                                    if (rows.Count() == 1 && count == 0)
                                                    {
                                                        var cells = rows[0].Descendants<oXmlWp.TableCell>().ToList();
                                                        cells[0].RemoveAllChildren();
                                                        cells[1].RemoveAllChildren();
                                                        cells[0].Append(new oXmlWp.Paragraph(new oXmlWp.Run(new oXmlWp.Text(section))));
                                                        cells[1].Append(new oXmlWp.Paragraph(new oXmlWp.Run(new oXmlWp.Text(comment.Comments))));
                                                    }
                                                    else
                                                    {
                                                        var newRow = new oXmlWp.TableRow();
                                                        newRow.Append(new oXmlWp.TableCell(new oXmlWp.Paragraph(new oXmlWp.Run(new oXmlWp.Text(section)))));
                                                        newRow.Append(new oXmlWp.TableCell(new oXmlWp.Paragraph(new oXmlWp.Run(new oXmlWp.Text(comment.Comments)))));
                                                        tables[0].AppendChild(newRow);
                                                    }
                                                    count++;
                                                }

                                                //if (doc.Tables.Count == 1)
                                                //{
                                                //    Row newRow = null;
                                                //    if (doc.Tables[1].Rows.Count == 1 && count == 0)
                                                //        newRow = doc.Tables[1].Rows[1];
                                                //    else
                                                //        newRow = doc.Tables[1].Rows.Add(ref objMissing);
                                                //    newRow.Cells[1].Range.Text = section;
                                                //    newRow.Cells[2].Range.Text = comment.Comments;
                                                //    count++;
                                                //}
                                            }
                                        }
                                        //if (commentString != "")
                                        //    commentString += "</table>";
                                        //Replace(doc, "$SAFDYNAMICMISSINGINFO$", commentString);
                                    }
                                }
                            }
                        }



                        #endregion

                        wordDoc.MainDocumentPart.Document.Save();
                    }
                    //write finished document to specified path
                    File.WriteAllBytes(strDoc, ms.ToArray());
                }

            }
            catch
            {

            }
        }

        #endregion

        #region Document Conversion

        public static void ConvertToXml(string strOrgDoc, string strOutDoc)
        {
            Application objApp = null;

            //boxing of default values for COM interop purposes
            object objMissing = Missing.Value;
            object objFalse = false;
            object objFormat = WdSaveFormat.wdFormatXML;

            try
            {
                objApp = new Application();
                object objOrgDoc = strOrgDoc;

                Document objDoc = objApp.Documents.Open(
                  ref objOrgDoc,    //FileName
                  ref objMissing,   //ConfirmVersions
                  ref objFalse,     //ReadOnly
                  ref objMissing,   //AddToRecentFiles
                  ref objMissing,   //Passdoc
                  ref objMissing,   //PasswordTemplate
                  ref objMissing,   //Revert
                  ref objMissing,   //WritePassdoc
                  ref objMissing,   //WritePasswordTemplate
                  ref objMissing,   //Format
                  ref objMissing,   //Enconding
                  ref objMissing,   //Visible
                  ref objMissing,   //OpenAndRepair
                  ref objMissing,   //DocumentDirection
                  ref objMissing,   //NoEncodingDialog
                  ref objMissing    //XMLTransform
                  );

                objDoc.Activate();

                object objOutDoc = strOutDoc;

                objDoc.SaveAs(
                  ref objOutDoc,      //FileName
                  ref objFormat,      //FileFormat
                  ref objMissing,     //LockComments
                  ref objMissing,     //PassWord     
                  ref objMissing,     //AddToRecentFiles
                  ref objMissing,     //WritePassword
                  ref objFalse,       //ReadOnlyRecommended
                  ref objMissing,     //EmbedTrueTypeFonts
                  ref objMissing,     //SaveNativePictureFormat
                  ref objMissing,     //SaveFormsData
                  ref objMissing,     //SaveAsAOCELetter,
                  ref objMissing,     //Encoding
                  ref objMissing,     //InsertLineBreaks
                  ref objMissing,     //AllowSubstitutions
                  ref objMissing,     //LineEnding
                  ref objMissing      //AddBiDiMarks
                  );

                objDoc.Close(
                  ref objFalse,     //SaveChanges
                  ref objMissing,   //OriginalFormat
                  ref objMissing    //RouteDocument
                  );
            }
            finally
            {
                try
                {
                    objApp.Quit(
                      ref objMissing,     //SaveChanges
                      ref objMissing,     //OriginalFormat
                      ref objMissing      //RoutDocument
                      );
                    objApp = null;
                }
                catch { }
            }
        }

        public static void ConvertToDoc(string strOrgDoc, string strOutDoc)
        {
            Application objApp = null;

            //boxing of default values for COM interop purposes
            object objMissing = Missing.Value;
            object objFalse = false;
            object objFormat = WdSaveFormat.wdFormatDocument;

            try
            {
                objApp = new Application();
                object objOrgDoc = strOrgDoc;

                Document objDoc = objApp.Documents.Open(
                  ref objOrgDoc,    //FileName
                  ref objMissing,   //ConfirmVersions
                  ref objFalse,     //ReadOnly
                  ref objMissing,   //AddToRecentFiles
                  ref objMissing,   //Passdoc
                  ref objMissing,   //PasswordTemplate
                  ref objMissing,   //Revert
                  ref objMissing,   //WritePassdoc
                  ref objMissing,   //WritePasswordTemplate
                  ref objMissing,   //Format
                  ref objMissing,   //Enconding
                  ref objMissing,   //Visible
                  ref objMissing,   //OpenAndRepair
                  ref objMissing,   //DocumentDirection
                  ref objMissing,   //NoEncodingDialog
                  ref objMissing    //XMLTransform
                  );

                objDoc.Activate();

                object objOutDoc = strOutDoc;

                objDoc.SaveAs(
                  ref objOutDoc,      //FileName
                  ref objFormat,      //FileFormat
                  ref objMissing,     //LockComments
                  ref objMissing,     //PassWord     
                  ref objMissing,     //AddToRecentFiles
                  ref objMissing,     //WritePassword
                  ref objFalse,       //ReadOnlyRecommended
                  ref objMissing,     //EmbedTrueTypeFonts
                  ref objMissing,     //SaveNativePictureFormat
                  ref objMissing,     //SaveFormsData
                  ref objMissing,     //SaveAsAOCELetter,
                  ref objMissing,     //Encoding
                  ref objMissing,     //InsertLineBreaks
                  ref objMissing,     //AllowSubstitutions
                  ref objMissing,     //LineEnding
                  ref objMissing      //AddBiDiMarks
                  );

                objDoc.Close(
                  ref objFalse,     //SaveChanges
                  ref objMissing,   //OriginalFormat
                  ref objMissing    //RouteDocument
                  );
            }
            finally
            {
                try
                {
                    objApp.Quit(
                      ref objMissing,     //SaveChanges
                      ref objMissing,     //OriginalFormat
                      ref objMissing      //RouteDocument
                      );
                    objApp = null;
                }
                catch { }
            }
        }

        public static void ConvertToMht(string strOrgDoc, string strOutDoc)
        {
            Application objApp = null;

            //boxing of default values for COM interop purposes
            object objMissing = Missing.Value;
            object objFalse = false;
            object objFormat = WdSaveFormat.wdFormatWebArchive;

            try
            {
                objApp = new Application();
                object objOrgDoc = strOrgDoc;

                Document objDoc = objApp.Documents.Open(
                  ref objOrgDoc,    //FileName
                  ref objMissing,   //ConfirmVersions
                  ref objFalse,     //ReadOnly
                  ref objMissing,   //AddToRecentFiles
                  ref objMissing,   //Passdoc
                  ref objMissing,   //PasswordTemplate
                  ref objMissing,   //Revert
                  ref objMissing,   //WritePassdoc
                  ref objMissing,   //WritePasswordTemplate
                  ref objMissing,   //Format
                  ref objMissing,   //Enconding
                  ref objMissing,   //Visible
                  ref objMissing,   //OpenAndRepair
                  ref objMissing,   //DocumentDirection
                  ref objMissing,   //NoEncodingDialog
                  ref objMissing    //XMLTransform
                  );

                objDoc.Activate();

                object objOutDoc = strOutDoc;

                objDoc.SaveAs(
                  ref objOutDoc,      //FileName
                  ref objFormat,      //FileFormat
                  ref objMissing,     //LockComments
                  ref objMissing,     //PassWord     
                  ref objMissing,     //AddToRecentFiles
                  ref objMissing,     //WritePassword
                  ref objFalse,       //ReadOnlyRecommended
                  ref objMissing,     //EmbedTrueTypeFonts
                  ref objMissing,     //SaveNativePictureFormat
                  ref objMissing,     //SaveFormsData
                  ref objMissing,     //SaveAsAOCELetter,
                  ref objMissing,     //Encoding
                  ref objMissing,     //InsertLineBreaks
                  ref objMissing,     //AllowSubstitutions
                  ref objMissing,     //LineEnding
                  ref objMissing      //AddBiDiMarks
                  );

                objDoc.Close(
                  ref objFalse,     //SaveChanges
                  ref objMissing,   //OriginalFormat
                  ref objMissing    //RouteDocument
                  );
            }
            finally
            {
                try
                {
                    objApp.Quit(
                      ref objMissing,     //SaveChanges
                      ref objMissing,     //OriginalFormat
                      ref objMissing      //RouteDocument
                      );
                    objApp = null;
                }
                catch { }
            }
        }

        #endregion

        public static void GetCurrentMenu(MenuCollection menus, int menuId)
        {
            if (menus == null || menus.Count == 0) return;
            foreach (SCA.VAS.ValueObjects.User.Menu m in menus)
            {
                if (m.Id == menuId)
                    currentStep = m;
                GetCurrentMenu(m.SubMenus, menuId);
            }
        }

        public static void Compare(string strOrgDoc, string strNewDoc, string strOutDoc,
            bool isDocFormat)
        {
            Application objApp = null;

            //boxing of default values for COM interop purposes
            object objMissing = Missing.Value;
            object objFalse = false;
            object objTarget = WdCompareTarget.wdCompareTargetNew;
            object objFormat = WdSaveFormat.wdFormatDocument;

            if (!isDocFormat)
                objFormat = WdSaveFormat.wdFormatWebArchive;
            try
            {
                objApp = new Application();
                object objNewDoc = strNewDoc;

                Document objDocLast = null;
                Document objDocBeforeLast = null;

                objDocLast = objApp.Documents.Open(
                  ref objNewDoc,    //FileName
                  ref objMissing,   //ConfirmVersions
                  ref objFalse,     //ReadOnly
                  ref objMissing,   //AddToRecentFiles
                  ref objMissing,   //Passdoc
                  ref objMissing,   //PasswordTemplate
                  ref objMissing,   //Revert
                  ref objMissing,   //WritePassdoc
                  ref objMissing,   //WritePasswordTemplate
                  ref objMissing,   //Format
                  ref objMissing,   //Enconding
                  ref objMissing,   //Visible
                  ref objMissing,   //OpenAndRepair
                  ref objMissing,   //DocumentDirection
                  ref objMissing,   //NoEncodingDialog
                  ref objMissing    //XMLTransform
                  );

                objDocLast.Compare(
                  strOrgDoc,              //FileName
                  ref objMissing,
                  ref objTarget,
                  ref objMissing,
                  ref objMissing,
                  ref objFalse,
                  ref objMissing,
                  ref objMissing
                  );

                objDocBeforeLast = objDocLast;
                objDocLast = objApp.ActiveDocument;

                if (objDocBeforeLast != null)
                {
                    objDocBeforeLast.Close(
                      ref objFalse,     //SaveChanges
                      ref objMissing,   //OriginalFormat
                      ref objMissing    //RouteDocument
                      );
                }

                object objOutDoc = strOutDoc;

                objDocLast.SaveAs(
                  ref objOutDoc,      //FileName
                  ref objFormat,      //FileFormat
                  ref objMissing,     //LockComments
                  ref objMissing,     //PassWord     
                  ref objMissing,     //AddToRecentFiles
                  ref objMissing,     //WritePassword
                  ref objFalse,       //ReadOnlyRecommended
                  ref objMissing,     //EmbedTrueTypeFonts
                  ref objMissing,     //SaveNativePictureFormat
                  ref objMissing,     //SaveFormsData
                  ref objMissing,     //SaveAsAOCELetter,
                  ref objMissing,     //Encoding
                  ref objMissing,     //InsertLineBreaks
                  ref objMissing,     //AllowSubstitutions
                  ref objMissing,     //LineEnding
                  ref objMissing      //AddBiDiMarks
                  );

                foreach (Document objDocument in objApp.Documents)
                {
                    objDocument.Close(
                      ref objFalse,     //SaveChanges
                      ref objMissing,   //OriginalFormat
                      ref objMissing    //RouteDocument
                      );
                }
            }
            finally
            {
                try
                {
                    objApp.Quit(
                      ref objMissing,     //SaveChanges
                      ref objMissing,     //OriginalFormat
                      ref objMissing      //RoutDocument
                      );
                    objApp = null;
                }
                catch { }
            }
        }

    }
}