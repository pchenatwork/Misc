#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of RfdSupplierAction:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(RfdSupplierActionConverter))]
    public class RfdSupplierAction : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly RfdSupplierAction AddToProject = new RfdSupplierAction(1, "AddToProject", "Add To Project");
        public static readonly RfdSupplierAction RemoveFromProject = new RfdSupplierAction(2, "RemoveFromProject", "Remove From Project");
        public static readonly RfdSupplierAction ReinstateToProject = new RfdSupplierAction(3, "ReinstateToProject", "Reinstate To Project");
        public static readonly RfdSupplierAction RejectFromProject = new RfdSupplierAction(4, "RejectFromProject", "Reject From Project");
        public static readonly RfdSupplierAction ReviewerReview = new RfdSupplierAction(5, "ReviewerReview", "Reviewer Review");
        public static readonly RfdSupplierAction ManagerApprove = new RfdSupplierAction(6, "ManagerApprove", "Manager Approve");
        public static readonly RfdSupplierAction ManagerQuestion = new RfdSupplierAction(7, "ManagerQuestion", "Manager Question");
        public static readonly RfdSupplierAction DirectorApprove = new RfdSupplierAction(8, "DirectorApprove", "Director Approve");
        public static readonly RfdSupplierAction DirectorQuestion = new RfdSupplierAction(9, "DirectorQuestion", "Director Question");
        public static readonly RfdSupplierAction CPOApprove = new RfdSupplierAction(10, "CPOApprove", "Chief Project Officer Approve");
        public static readonly RfdSupplierAction VPConstMgrApprove = new RfdSupplierAction(11, "VPConstMgrApprove", "VP for Construction Mgmt Approve");
        public static readonly RfdSupplierAction PresidentApprove = new RfdSupplierAction(12, "PresidentApprove", "President Approve");
        public static readonly RfdSupplierAction RescindFromProject = new RfdSupplierAction(13, "RescindFromProject", "Rescind From Project");
        public static readonly RfdSupplierAction RescindFromProject2 = new RfdSupplierAction(14, "RescindFromProject2", "Rescind From Project 2");
        public static readonly RfdSupplierAction CAURescind = new RfdSupplierAction(15, "CAURescind", "CAU Rescind");
        public static readonly RfdSupplierAction ManagerReject = new RfdSupplierAction(16, "ManagerReject", "Manager Reject");
        public static readonly RfdSupplierAction RejectInclusionRequest = new RfdSupplierAction(17, "RejectInclusionRequest", "Reject Inclusion Request");
        public static readonly RfdSupplierAction ExecutiveVPApprove = new RfdSupplierAction(18, "ExecutiveVPApprove", "Executive VP Approve");


        #endregion

        #region Constructors
        public RfdSupplierAction()
        {
        }

        private RfdSupplierAction(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in RfdSupplierAction class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of RfdSupplierAction.  
        /// </summary>
        public static RfdSupplierAction Default
        {
            get
            {
                return (RfdSupplierAction)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for RfdSupplierAction class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a RfdSupplierAction object.
        /// It allows a string to be assigned to a RfdSupplierAction object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator RfdSupplierAction(int id)
        {
            return (RfdSupplierAction)EnumerationBase.FindById(id, RfdSupplierAction._list);
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and RfdSupplierAction objects.
    /// It's very useful when binding RfdSupplierAction objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class RfdSupplierActionConverter : TypeConverter
    {

        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, RfdSupplierAction._list);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the RfdSupplierAction enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < RfdSupplierAction._list.Count; i++)
            {
                list.Add(((RfdSupplierAction)RfdSupplierAction._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
