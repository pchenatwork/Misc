﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Net.Mail;
using System.Configuration;

using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;
using System.Collections;
using SCA.VAS.Common.ValueObjects;

namespace SCA.VAS.Workflow
{
    #region ConstantUtility
    public partial class ConstantUtility
    {
        public const string WORKFLOW_SUP = "Subcontractor Utilization Plan Workflow";
    }
    #endregion ConstantUtility

    public partial class CommonUtility
    {
        #region Pubulic Method
        public static string GetPlanStatusName(string workflowType, int statusint)
        {
            EnumerationBase status = GetPlanStatus(workflowType, statusint);
            if (status != null) return status.Description;
            return string.Empty;
        }

        public static int GetPlanStatusId(string workflowType, string statusstr)
        {
            EnumerationBase status = GetPlanStatus(workflowType, statusstr);
            if (status != null) return status.Id;
            return 0;
        }

        private static EnumerationBase GetPlanStatus(string workflowType, object status)
        {
            switch (workflowType)
            {
                case ConstantUtility.WORKFLOW_SUP:
                    PlanStatusType planStatus = status.ToString();
                    if (status is int) planStatus = (int)status;
                    return planStatus;
            }
            return null;
        }
        #endregion Pubulic Method

        #region Email Method
        public static void PlanSendEmail(Plan plan, WorkflowNode node, WorkflowHistory workflowHistory,
            string emailMessageName, string comments, string prefixDbName)
        {
            EmailMessage emailmessage = EmailMessageUtility.GetByName(
                ConstantUtility.COMMON_DATASOURCE_NAME, emailMessageName);
            if (emailmessage == null) return;


            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "FederalId", plan.FederalId);
            User user = UserUtility.Get(prefixDbName + ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());

            Supplier supplier = null;
            if (vendor != null)
            {
                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendor.CurrentSupplierId);
            }

            if (supplier == null) return;

            EmailMessage newMessage = EmailReplaceRelatedUsers(emailmessage, plan);

            switch (emailmessage.Objects)
            {
                case "Authorized Users":
                    {
                       
                        string nodes = XmlUtility.ToXml(workflowHistory.NextLinks);
                        UserCollection users = UserUtility.FindByCriteria(
                            ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_WORKFLOWNODES,
                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                            {
                                SendEmail(emailmessage, users[i],
                                    new object[] { plan, users[i], supplier, vendor },
                                    comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "Plan", plan.Id);
                            }
                        }
                    }
                    break;
                //Authorized users is not returning proper users in case of SUP_ANALYST_COMMITMENT mail so used node users for finding next users.
                case "Node Users":
                    {
                        WorkflowNodeCollection workflownodes = new WorkflowNodeCollection();
                        workflownodes.Add(node);
                        string nodes = XmlUtility.ToXml(workflownodes);
                        UserCollection users = UserUtility.FindByCriteria(
                            ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_WORKFLOWNODES,
                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                            {
                                SendEmail(emailmessage, users[i],
                                    new object[] { plan, users[i], supplier, vendor },
                                    comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "Plan", plan.Id);
                            }
                        }
                    }
                    break;
                case "Users":
                    {
                        SendEmail(emailmessage, user,
                            new object[] { plan, user, supplier, vendor }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Plan", plan.Id);
                    }
                    break;

                case "Suppliers":
                    {
                        SendEmail(emailmessage, supplier,
                            new object[] { plan, user, supplier, vendor }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Plan", plan.Id);
                    }
                    break;
                case "PlanSubs":
                    {
                        PlanSubcontractorCollection ps = PlanSubcontractorUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME, PlanSubcontractorManager.FIND_BY_PLAN, new object[] { plan.Id, "All" });
                        if (ps != null)
                        {
                            foreach (PlanSubcontractor p in ps)
                            {
                                Supplier sub = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, p.SupplierId);
                                Vendor ven = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "FederalId", p.FederalId);

                                SendEmail(emailmessage, sub, new object[] { plan, user, sub, ven }, comments, (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1), "Plan", plan.Id);
                            }
                        }

                    }
                    break;
                default:
                    {
                        SendEmail(emailmessage, null,
                            new object[] { plan, user, supplier, vendor }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "Plan", plan.Id);
                    }
                    break;
            }
        }

        public static EmailMessage EmailReplaceRelatedUsers(EmailMessage emailmessage, Plan plan)
        {
            if (emailmessage == null) return null;

            Hashtable RelatedUsers = new Hashtable();

            PlanPropertyCollection planProperties = PlanPropertyUtility.FindByCriteria(
                ConstantUtility.RFD_DATASOURCE_NAME,
                PlanPropertyManager.FIND_BY_PLAN,
                new object[] { plan.Id });

            //plan info
            RelatedUsers.Add("$CONTRACTNO$", plan.ContractNo);
            RelatedUsers.Add("$SOLICITNO$", plan.SolicitNo);
            RelatedUsers.Add("$CONTRACTAMOUNT$", plan.ContractAmount.ToString("c0"));
            RelatedUsers.Add("$SUBCONTPERCENTAGE$", plan.SubcontPercentage.ToString() == "0" ? "0%" : plan.SubcontPercentage.ToString("##.##") + "%");
            RelatedUsers.Add("$WAIVERPERCENTAGE$", plan.WaiverPercentage.ToString() == "0" ? "0%" : plan.WaiverPercentage.ToString("##.##") + "%");
            RelatedUsers.Add("$REVISEDPERCENTAGE$", plan.RevisedPercentage.ToString() == "0" ? "0%" : plan.RevisedPercentage.ToString("##.##") + "%");
            RelatedUsers.Add("$MWLBEGOAL$", plan.MWLBEGoal.ToString("c0"));
            RelatedUsers.Add("$REVISEDMWLBEGOAL$", plan.RevisedMWLBEGoal.ToString("c0"));
            RelatedUsers.Add("$SUBMITTEDAMOUNT$", plan.SubmittedAmount.ToString("c0"));
            RelatedUsers.Add("$ESTIMATEAMOUNT$", plan.EstimateAmount.ToString("c0"));
            RelatedUsers.Add("$MWLBEESTIMATEAMOUNT$", plan.MWLBEEstimateAmount.ToString("c0"));
            RelatedUsers.Add("$MWLBEESTIMATEPERCENTAGE$", plan.MWLBEEstimatePercentage.ToString() == "0" ? "0%" : plan.MWLBEEstimatePercentage.ToString("##.##") + "%");
            RelatedUsers.Add("$APPROVEDAMOUNT$", plan.ApprovedAmount.ToString("c0"));
            RelatedUsers.Add("$MWLBEAPPROVEDAMOUNT$", plan.MWLBEApprovedAmount.ToString("c0"));
            RelatedUsers.Add("$MWLBEAPPROVEDPERCENTAGE$", plan.MWLBEApprovedPercentage.ToString() == "0" ? "0%" : plan.MWLBEApprovedPercentage.ToString("##.##") + "%");
            RelatedUsers.Add("$PERCENTAGECOMPLETION$", plan.PercentageCompletion.ToString() == "0" ? "0%" : plan.PercentageCompletion.ToString("##.##") + "%");
            RelatedUsers.Add("$PERFORMANCEINCLUSION$", plan.PerformanceInclusion.ToString() == "0" ? "0%" : plan.PerformanceInclusion.ToString("##.##") + "%");

            //prime info
            RelatedUsers.Add("$EEOCONTACTNAME$", plan.EEOContactName);
            RelatedUsers.Add("$EEOCONTACTPHONE$", plan.EEOContactPhone);
            RelatedUsers.Add("$EEOCONTACTEMAIL$", plan.EEOContactEmail);
            RelatedUsers.Add("$PRIMEFEDERALID$", plan.FederalId);


            //Get subcontractors that are exipiring with in 6 months
            //$PLANSUBQUALCERTSTATUS$
            PlanSubcontractorCollection ps = PlanSubcontractorUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME, PlanSubcontractorManager.FIND_BY_PLAN, new object[] { plan.Id, "All" });
            string suppliers = "<ul>";
            if (ps != null)
            {
                foreach (PlanSubcontractor p in ps)
                {
                    Vendor sub = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "FederalId", p.FederalId);
                    if (sub != null)
                    {
                        DateTime qualExpDate = sub.QualifiedExpDate;
                        DateTime certExpDate = sub.CertifiedExpDate;

                        if ((qualExpDate != DateTime.MinValue && qualExpDate.CompareTo(DateTime.Now.AddMonths(6)) <= 0) || (certExpDate != DateTime.MinValue && certExpDate.CompareTo(DateTime.Now.AddMonths(6)) <= 0))
                        {
                            suppliers = string.Format("{0}<li>{1} - Qual Exp Date:{2}, Cert Exp Date:{3}</li>", suppliers, sub.Company, sub.QualifiedExpDate, sub.CertifiedExpDate);
                        }
                    }
                }
                suppliers = string.Format("{0}</ul>", suppliers);

            }

            RelatedUsers.Add("$PLANSUBQUALCERTSTATUS$", suppliers);

            Supplier prime = SupplierUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "FederalId", plan.FederalId);

            if (prime != null)
            {
                RelatedUsers.Add("$PRIMECOMPANYNAME$", prime.Company);
                RelatedUsers.Add("$PRIMEADDRESS$", prime.PhysicalAddress.AddressLine1.Replace("|", " ") + "," + prime.PhysicalAddress.AddressLine2);
                RelatedUsers.Add("$PRIMECITY$", prime.PhysicalAddress.City);
                RelatedUsers.Add("$PRIMESTATE$", prime.PhysicalAddress.State);
                RelatedUsers.Add("$PRIMEZIPCODE$", prime.PhysicalAddress.ZipCode);
            }

            //school info
            string schoolname = string.Empty;
            schoolname = GetPlanProperty("property17", planProperties).PropertyText;
            RelatedUsers.Add("$SCHOOLNAME$", schoolname);

            string borocode = string.Empty;
            borocode = GetPlanProperty("property18", planProperties).PropertyText;
            RelatedUsers.Add("$BOROCODE$", borocode);

            string boroname = string.Empty;
            boroname = GetPlanProperty("property19", planProperties).PropertyText;
            RelatedUsers.Add("$BORONAME$", boroname);

            //reviewer info
            string reviewerUserName = string.Empty;
            reviewerUserName = GetPlanProperty("property15", planProperties).PropertyText;
            User reviewer = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, reviewerUserName);
            if (reviewer != null)
            {
                RelatedUsers.Add("$REVIEWERFIRSTNAME$", reviewer.FirstName);
                RelatedUsers.Add("$REVIEWERLASTNAME$", reviewer.LastName);
                RelatedUsers.Add("$REVIEWEREMAIL$", reviewer.Email);
                RelatedUsers.Add("$REVIEWERPHONE$", reviewer.Phone);
            }

            //plan missing info
            PlanCommentCollection planComments = PlanCommentUtility.FindByCriteria(ConstantUtility.RFD_DATASOURCE_NAME,
               PlanCommentManager.FIND_PLANCOMMENT, new object[] { 0, 0, "", "", plan.Id, "External" });
            string commentString = "";
            if (planComments != null)
            {
                foreach (PlanComment comment in planComments)
                {
                    if (comment.Submitted != "Y")
                    {
                        if (commentString == "")
                            commentString = "<table border='1' cellpadding='3'>";
                        commentString += "<tr><td><b>";
                        string section = "";
                        switch (comment.FileLink)
                        {
                            case "0":
                                section = "Plan Information";
                                break;
                        }
                        commentString += section + "</b></td><td>" + comment.Comments + "</td></tr>";
                    }
                }
            }
            if (commentString != "")
                commentString += "</table>";
            RelatedUsers.Add("$PLANDYNAMICMISSINGINFO$", commentString);

            //SUP Link
            string planInternalUrl = "$INTERNALSITEURL$/SUP/SUP_List.aspx?Id=" + plan.Id.ToString();
            RelatedUsers.Add("$SUPLISTLINK$", planInternalUrl);

            //SAT Status
            string satStatus = string.Empty;
            satStatus = GetPlanProperty("property31", planProperties).PropertyText;
            if (satStatus == "")
            {
                satStatus = GetPlanProperty("property25", planProperties).PropertyText;
            }
            RelatedUsers.Add("$SATISFACTORYSTATUS$", satStatus);

            //replace
            emailmessage.FromEmail = ReplaceRelatedUsers(emailmessage.FromEmail, RelatedUsers);
            emailmessage.ToEmail = ReplaceRelatedUsers(emailmessage.ToEmail, RelatedUsers);
            emailmessage.ToName = ReplaceRelatedUsers(emailmessage.ToName, RelatedUsers);
            emailmessage.CcEmail = ReplaceRelatedUsers(emailmessage.CcEmail, RelatedUsers);
            emailmessage.BccEmail = ReplaceRelatedUsers(emailmessage.BccEmail, RelatedUsers);
            emailmessage.Subject = ReplaceRelatedUsers(emailmessage.Subject, RelatedUsers);
            emailmessage.Body = ReplaceRelatedUsers(emailmessage.Body, RelatedUsers);

            return emailmessage;
        }

        #endregion Email Method

        public static void AddPlanUser(string userName, string roleName, int userId)
        {
            if (userName.Trim().Length > 0)
            {
                CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, userName);
                if (cesUser != null)
                    AddUser(cesUser, roleName, "", userId);
            }
        }


        #region PlanProperty functions
        public static PlanProperty CreatePlanProperty(Control control, string value, Type type, Control parent, string changeUser)
        {
            PlanProperty planProperty = CreatePlanProperty(control, value, type, parent);
            planProperty.ChangeUser = changeUser;
            return planProperty;
        }

        public static PlanProperty CreatePlanProperty(Control control, string value, Type type, Control parent)
        {
            PlanProperty planProperty = PlanPropertyUtility.CreateObject();
            planProperty.PropertyId = ConvertUtility.ConvertInt(control.ID.Substring(8));
            if (parent != null) planProperty.ParentId = planProperty.PropertyId;
            switch (type.Name)
            {
                case "Int32":
                    planProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    planProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    planProperty.PropertyText = value;
                    break;
            }
            return planProperty;
        }


        public static PlanProperty CreatePlanProperty(Control control, string attachmentName, byte[] attachment)
        {
            PlanProperty planProperty = PlanPropertyUtility.CreateObject();
            planProperty.PropertyId = ConvertUtility.ConvertInt(control.ID.Substring(8));
            planProperty.AttachmentName = attachmentName;
            planProperty.Attachment = attachment;
            return planProperty;
        }

        public static PlanProperty CreatePlanProperty(int propertyId, string value)
        {
            PlanProperty planProperty = CreatePlanProperty(propertyId, value, typeof(String));
            return planProperty;
        }

        public static PlanProperty CreatePlanProperty(int propertyId, string value, Type type)
        {
            PlanProperty planProperty = PlanPropertyUtility.CreateObject();
            planProperty.PropertyId = propertyId;
            switch (type.Name)
            {
                case "Int32":
                    planProperty.PropertyValue = ConvertUtility.ConvertInt(value);
                    break;
                case "DateTime":
                    DateTime myDate = ConvertUtility.ConvertDateTime(value);
                    planProperty.PropertyDate = myDate == DateTime.MinValue ? new DateTime(1900, 1, 1) : myDate;
                    break;
                default:
                    planProperty.PropertyText = value;
                    break;
            }
            return planProperty;
        }

        public static PlanPropertyCollection AddPlanProperty(int planId, PlanProperty planProperty)
        {
            PlanPropertyCollection planProperties = new PlanPropertyCollection();
            planProperties.Add(planProperty);
            return AddPlanProperty(planId, planProperties);
        }

        public static PlanPropertyCollection AddPlanProperty(Plan plan, PlanPropertyCollection planProperties)
        {
            return AddPlanProperty(plan.Id, planProperties);
        }
        public static PlanPropertyCollection AddPlanProperty(int planId, PlanPropertyCollection planProperties)
        {
            PlanPropertyCollection currentProperties = PlanPropertyUtility.FindByCriteria(
                ConstantUtility.RFD_DATASOURCE_NAME,
                PlanPropertyManager.FIND_BY_PLAN,
                new object[] { planId });
            if (currentProperties == null)
                currentProperties = new PlanPropertyCollection();

            foreach (PlanProperty sp in planProperties)
            {
                if (sp.ParentId == 0)
                {
                    bool isChange = false;
                    foreach (PlanProperty sp1 in currentProperties)
                    {
                        if (sp1.PropertyId == sp.PropertyId)
                        {
                            sp1.PropertyValue = sp.PropertyValue;
                            sp1.PropertyText = sp.PropertyText;
                            sp1.PropertyDate = sp.PropertyDate;
                            isChange = true;
                        }
                    }
                    if (!isChange)
                        currentProperties.Add(sp);
                }
                else
                {
                    //Multi values
                    currentProperties.Add(sp);
                }
            }
            return currentProperties;
        }

        public static PlanProperty GetPlanProperty(int propertyId, PlanPropertyCollection planProperties)
        {
            if (planProperties == null) return PlanPropertyUtility.CreateObject();
            foreach (PlanProperty sp in planProperties)
            {
                if (sp.PropertyId == propertyId)
                    return sp;
            }
            return PlanPropertyUtility.CreateObject();
        }
        public static PlanProperty GetPlanProperty(Control control, PlanPropertyCollection planProperties)
        {
            return GetPlanProperty(ConvertUtility.ConvertInt(control.ID.Substring(8)), planProperties);
        }

        public static PlanProperty GetPlanProperty(string propertyId, PlanPropertyCollection planProperties)
        {
            return GetPlanProperty(ConvertUtility.ConvertInt(propertyId.Substring(8)), planProperties);
        }

        public static PlanPropertyCollection GetPlanProperties(Control control, PlanPropertyCollection planProperties)
        {
            PlanPropertyCollection localPlanProperties = new PlanPropertyCollection();
            if (planProperties == null) return localPlanProperties;
            foreach (PlanProperty sp in planProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(control.ID.Substring(8)))
                    localPlanProperties.Add(sp);
            }
            return localPlanProperties;
        }
        public static PlanPropertyCollection GetPlanProperties(string controlId, PlanPropertyCollection planProperties)
        {
            PlanPropertyCollection localPlanProperties = new PlanPropertyCollection();
            if (planProperties == null) return localPlanProperties;
            foreach (PlanProperty sp in planProperties)
            {
                if (sp.PropertyId == ConvertUtility.ConvertInt(controlId.Substring(8)))
                    localPlanProperties.Add(sp);
            }
            return localPlanProperties;
        }


        #endregion PlanProperty functions




        #region Package Functions
        #endregion
    }
}
