#region Copyright
/*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Configuration;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.ValueObjects.Supplier.Subcontractor;
using SCA.VAS.BusinessLogic.Supplier.Subcontractor.Utilities;
#endregion Reference

namespace SCA.VAS.Workflow
{
	public class WorkflowExec
	{
		#region Private Member
        private static string prefixDbName = string.Empty;
        private static int userId = 0;
        #endregion

        #region Public Member
        public static int UserId
        {
            get { return userId; }
            set { userId = value; }
        }
        #endregion

        #region Constructor
        public WorkflowExec()
		{
		}
		static WorkflowExec()
		{
		}
		#endregion Constructor

		#region Public Method
        public static int CreateWorkflowHistory(int workflowId)
        {
            if (workflowId == 0) return 0;
            WorkflowHistory workflowHistory = WorkflowHistoryUtility.CreateObject();
            workflowHistory.WorkflowId = workflowId;
            workflowHistory.CreatedBy = GetUserId();
            workflowHistory.CreatedType = GetUserType();
            return WorkflowControl.CreateNewWorkflow(workflowHistory);
        }

        public static int CreateWorkflowHistory(int workflowId, string comments, int nodeId)
        {
            if (workflowId == 0) return 0;
            if (nodeId == 0) return CreateWorkflowHistory(workflowId);

            WorkflowHistory workflowHistory = WorkflowHistoryUtility.CreateObject();
            workflowHistory.WorkflowId = workflowId;
            workflowHistory.CreatedBy = GetUserId();
            workflowHistory.CreatedType = GetUserType();
            workflowHistory.Comments = comments;
            workflowHistory.CurrentNodeId = nodeId;
            workflowHistory.ApprovalUserId = 0;
            workflowHistory.ApprovalConditionId = 0;
            workflowHistory.IsActive = 1;

            WorkflowHistoryUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory);

            return workflowHistory.Id;
        }

        public static int GetUserId()
        {
            if (UserId != 0)
                return UserId;
            return ExtPage.GetUserId();
        }

        public static string GetUserName()
        {
            return ExtPage.GetUserName();
        }

        public static string GetUserType()
        {
            return ExtPage.GetUserType();
        }

        public static int GetWorkflowId(string type)
        {
            WorkflowListCollection workflows = WorkflowListUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowListManager.FIND_WORKFLOWLIST_BY_TYPE,
                new object[] { type });
            if (workflows != null && workflows.Count > 0)
                return workflows[0].Id;
            return 0;
        }

        public static bool WorkflowNextStatus(int workflowId, string nextNode, int currentNodeId, int transactionHeaderId, string comments)
        {
            WorkflowHistory workflowHistory = WorkflowHistoryUtility.CreateObject();
            workflowHistory.TransactionHeaderId = transactionHeaderId;
            workflowHistory.CurrentNodeId = currentNodeId;
            workflowHistory.ApprovalConditionId = 1;
            workflowHistory.ApprovalUserId = GetUserId();
            workflowHistory.Comments = comments;
            workflowHistory.CreatedBy = workflowHistory.ApprovalUserId;
            workflowHistory.CreatedType = GetUserType();

            return WorkflowControl.NextStatus(workflowHistory, workflowId, nextNode);
        }

        public static bool WorkflowNextSystemStatus(int workflowId, string nextNode, int currentNodeId, int transactionHeaderId, string comments)
        {
            WorkflowHistory workflowHistory = WorkflowHistoryUtility.CreateObject();
            workflowHistory.TransactionHeaderId = transactionHeaderId;
            workflowHistory.CurrentNodeId = currentNodeId;
            workflowHistory.ApprovalConditionId = 1;
            workflowHistory.ApprovalUserId = GetUserId();
            workflowHistory.Comments = comments;
            workflowHistory.CreatedBy = workflowHistory.ApprovalUserId;
            workflowHistory.CreatedType = GetUserType();

            return WorkflowControl.NextSystemStatus(workflowHistory, workflowId, nextNode);
        }

        public static User GetLastApprover(int transactionId)
        {
            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(transactionId);
            if (workflowHistory == null) return null;

            workflowHistory = WorkflowHistoryUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowHistory.PrevHistoryId);
            if (workflowHistory == null) return null;

            if (workflowHistory.CreatedType != "User")
                return null;

            return UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, workflowHistory.CreatedBy);
        }
        #endregion Public Method

		#region Private Method
        /*
		private static bool WorkflowNextStep(int ConditionId, int transactionHeaderId)
		{
			WorkflowHistory workflowHistory = WorkflowHistoryUtility.CreateObject();
			workflowHistory.ApprovalConditionId = ConditionId;
			workflowHistory.ApprovalUserId = GetUserId();

			return WorkflowControl.NextStep(workflowHistory, transactionHeaderId);
		}

		private static int GetTransactionIdByType(int supplierId, string workflowType)
		{
			int transactionId = 0;
			Supplier supplier = SupplierUtility.Get( prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierId );

            if (supplier.SupplierWorkflows != null)
            {
                foreach (SupplierWorkflow w in supplier.SupplierWorkflows)
                {
                    if (w.WorkflowType == workflowType)
                    {
                        transactionId = w.TransactionId;
                        break;
                    }
                }
            }
			return transactionId;
		}

		private static int GetTransactionIdByType(SupplierWorkflowCollection supplierWorkflows, string workflowType)
		{
			int transactionId = 0;
            if (supplierWorkflows != null)
            {
                foreach (SupplierWorkflow w in supplierWorkflows)
                {
                    if (w.WorkflowType == workflowType)
                    {
                        transactionId = w.TransactionId;
                        break;
                    }
                }
            }
			return transactionId;
		}*/
		#endregion Private Method

        #region Batch Jobs
        public static void FaxInDocument(SupplierDocument supplierDocument)
        {
            if (supplierDocument.Id == 0)
            {
                if (SupplierDocumentUtility.Create(prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierDocument))
                {
                    //Execute Workflow Here
                }
            }
            else
                if(SupplierDocumentUtility.Update(prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierDocument)){
                    //Execute Workflow Here
                }
        }
        public static void FaxInDocument(SubcontractorDocument subcontractorDocument)
        {
            if (subcontractorDocument.Id == 0)
            {
                if (SubcontractorDocumentUtility.Create(prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME, subcontractorDocument))
                {
                    //Execute Workflow Here
                }
            }
            else
                if (SubcontractorDocumentUtility.Update(prefixDbName + ConstantUtility.SUPPLIER_DATASOURCE_NAME, subcontractorDocument))
                {
                    //Execute Workflow Here
                }
        }
        #endregion Batch Jobs
	}
}
