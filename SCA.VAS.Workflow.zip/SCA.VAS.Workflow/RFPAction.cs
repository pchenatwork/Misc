using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of RFPAction:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(RFPActionConverter))]
    public class RFPAction : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly RFPAction NewJMCreate = new RFPAction(1, "NewJMCreate", "New JM Create");
        public static readonly RFPAction JMSumbit = new RFPAction(2, "JMSumbit", "JM Sumbit");
        public static readonly RFPAction JMApprove = new RFPAction(3, "JMApprove", "JM Approve");
        public static readonly RFPAction JMReject = new RFPAction(4, "JMReject", "JM Reject");
        public static readonly RFPAction JMReview = new RFPAction(5, "JMReview", "JM Review");
        
        public static readonly RFPAction JMCCUNegotiatorApprove = new RFPAction(6, "JMCCUNegotiatorApprove", "JM CCU Negotiator Approve");
        public static readonly RFPAction JMCCUNegotiatorReject = new RFPAction(7, "JMCCUNegotiatorReject", "JM CCU Negotiator Reject");
        public static readonly RFPAction JMCCUManagerApprove = new RFPAction(26, "JMCCUManagerApprove", "JM CCU Manager Approve");
        public static readonly RFPAction JMCCUManagerReject = new RFPAction(27, "JMCCUManagerReject", "JM CCU Manager Reject");
        public static readonly RFPAction JMCCUDirectorApprove = new RFPAction(28, "JMCCUDirectorApprove", "JM CCU Director Approve");
        public static readonly RFPAction JMCCUDirectorReject = new RFPAction(29, "JMCCUDirectorReject", "JM CCU Director Reject");
        public static readonly RFPAction JMCCUDirectorApprove2 = new RFPAction(30, "JMCCUDirectorApprove2", "JM CCU Director Approve2");
        public static readonly RFPAction JMCCUDirectorReject2 = new RFPAction(31, "JMCCUDirectorReject2", "JM CCU Director Reject2");


        public static readonly RFPAction JMVPDeptApprove = new RFPAction(32, "JMVPDeptApprove", "JM Dept. VP Approve");
        public static readonly RFPAction JMVPDeptReject = new RFPAction(33, "JMVPDeptReject", "JM Dept. VP Reject");


        public static readonly RFPAction JMRevise = new RFPAction(8, "JMRevise", "JM Revise");
        public static readonly RFPAction Tier2Create = new RFPAction(9, "Tier2Create", "Tier2 Create");
        public static readonly RFPAction Tier2Approve = new RFPAction(10, "Tier2Approve", "JM Tier2 Approve");
        public static readonly RFPAction Tier2Reject = new RFPAction(11, "Tier2Reject", "JM Tier2 Reject");
        public static readonly RFPAction Tier2Complete = new RFPAction(12, "Tier2Complete", "JM Tier2 Complete");
        public static readonly RFPAction Tier2Revision = new RFPAction(13, "Tier2Revision", "JM Tier2 Revision");
        public static readonly RFPAction Tier4Create = new RFPAction(14, "Tier4Create", "Tier4 Create");
        public static readonly RFPAction Tier4Approve = new RFPAction(15, "Tier4Approve", "JM Tier4 Approve");
        public static readonly RFPAction Tier4Reject = new RFPAction(16, "Tier4Reject", "JM Tier4 Reject");
        public static readonly RFPAction Tier4Complete = new RFPAction(17, "Tier4Complete", "JM Tier4 Complete");
        public static readonly RFPAction Tier4Revision = new RFPAction(18, "Tier4Revision", "JM Tier4 Revision");
        public static readonly RFPAction FinancialReview = new RFPAction(19, "FinancialReview", "JM Financial Review");
        public static readonly RFPAction FinancialReject = new RFPAction(20, "FinancialReject", "JM Financial Reject");
        public static readonly RFPAction PresidentApprove = new RFPAction(21, "PresidentApprove", "President Approve");
        public static readonly RFPAction PresidentReject = new RFPAction(22, "PresidentReject", "President Reject");
        
        public static readonly RFPAction FinancialVPApprove = new RFPAction(23, "FinancialVPApprove", "JM Financial VP Approve");
        public static readonly RFPAction FinancialVPReject = new RFPAction(24, "FinancialVPReject", "JM Financial VP Reject");

        public static readonly RFPAction Tier2CompleteWithoutThrough = new RFPAction(34, "Tier2CompleteWithoutThrough", "JM Tier2 Complete Without Through");
        public static readonly RFPAction Tier2Initiate = new RFPAction(35, "Tier2Initiate", "Tier2 Process Initiate");


        #endregion

        #region Constructors
        public RFPAction()
        {
        }

        private RFPAction(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in RFPAction class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of RFPAction.  
        /// </summary>
        public static RFPAction Default
        {
            get
            {
                return (RFPAction)_list[0];
            }
        }
        #endregion/

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for RFPAction class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectAction object.
        /// It allows a string to be assigned to a ProjectAction object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator RFPAction(int id)
        {
            return (RFPAction)EnumerationBase.FindById(id, RFPAction._list);
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectAction objects.
    /// It's very useful when binding RFPAction objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class RFPActionConverter : TypeConverter
    {

        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, RFPAction._list);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the RFPAction enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < RFPAction._list.Count; i++)
            {
                list.Add(((RFPAction)RFPAction._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}