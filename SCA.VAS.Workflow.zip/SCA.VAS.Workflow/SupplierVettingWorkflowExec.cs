#region Copyright
/*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region Reference
using System;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Text;
using System.Configuration;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting;
using SCA.VAS.ValueObjects.Template.Vetting;

using SCA.VAS.BusinessLogic.Supplier.Vetting.Utilities;
using SCA.VAS.BusinessLogic.Supplier.Vetting;
using SCA.VAS.ValueObjects.Supplier.Vetting;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

namespace SCA.VAS.Workflow
{
    public class SupplierVettingWorkflowExec : ExtPage
    {
        #region Constructor
        public SupplierVettingWorkflowExec()
        {
        }
        static SupplierVettingWorkflowExec()
        {
        }
        #endregion Constructor

        #region Private Method
        private static int GetTransactionId(SupplierVetting supplierVetting, string comments)
        {
            if (supplierVetting.WorkflowId == 0)
                return 0;

            if (supplierVetting.TransactionId == 0)
            {

                VettingFormStatusType statusType = (VettingFormStatusType)supplierVetting.Status;
                if (statusType == null) return 0;

                WorkflowNode workflowNode = WorkflowNodeUtility.GetBySystemName(
                    ConstantUtility.WORKFLOW_DATASOURCE_NAME, supplierVetting.WorkflowId, statusType.Name);
                if (workflowNode == null) return 0;

                supplierVetting.TransactionId = WorkflowExec.CreateWorkflowHistory(supplierVetting.WorkflowId, comments, workflowNode.Id);
                if (supplierVetting.TransactionId > 0)
                {
                    SupplierVettingUtility.UpdateTransactionId(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                        supplierVetting.Id, supplierVetting.TransactionId);
                }
            }
            return supplierVetting.TransactionId;
        }
        #endregion Private Method

        #region Workflow Control
        public static int SupplierVettingWorkflow(SupplierVetting supplierVetting,
            string systemAction, string comments, ref string errmsg, ref string url)
        {
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_SYSTEMNAME,
                new object[] { supplierVetting.WorkflowId, systemAction });
            if (workflowNodes == null || workflowNodes.Count == 0) return 0;

            int transactionId = GetTransactionId(supplierVetting, comments);

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(supplierVetting.TransactionId);
            if (workflowHistory == null)
                return 0;

            int actionId = 0;
            for (int i = 0; i < workflowNodes.Count; i++)
            {
                if (workflowHistory.CurrentNodeId == workflowNodes[i].NodeFromId)
                {
                    actionId = workflowNodes[i].Id;
                    break;
                }
            }
            return SupplierVettingWorkflow(supplierVetting, actionId, comments, ref errmsg, ref url);
        }

        public static int SupplierVettingWorkflow(SupplierVetting supplierVetting,
            int actionId, string comments, ref string errmsg, ref string url)
        {
            int transactionId = GetTransactionId(supplierVetting, comments);

            if (actionId == 0) return transactionId;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(supplierVetting.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowNode workflowNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
            if (workflowHistory.CurrentNodeId != workflowNode.NodeFromId)
                return 0;

            // condition proccessing
            errmsg = string.Empty;
            WorkflowConditionCollection workflowConditions = SupplierVettingWorkflowConditionTest(supplierVetting, workflowNode.Id);
            if (workflowConditions != null)
            {
                foreach (WorkflowCondition workflowCondition in workflowConditions)
                {
                    if (workflowCondition.Status == 0)
                    {
                        errmsg += workflowCondition.ErrorMessage + "<br />";
                    }
                }
            }
            if (errmsg != string.Empty) return 0;

            //Workflow topologic
            bool approval = true;
            int userId = GetUserId();
            switch (workflowNode.Action1)
            {
                case "One":
                    break;
                case "Owner":
                    if (supplierVetting.UserId != userId)
                        errmsg = "Only process owner can perform this step!";
                    break;
                case "All":
                case "Majority":
                case "Count":
                    WorkflowHistoryCollection workflowHistories = WorkflowHistoryUtility.FindByCriteria(
                        ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
                        new object[] { supplierVetting.TransactionId });

                    WorkflowHistoryCollection currentHistories = new WorkflowHistoryCollection();
                    for (int i = 0; i < workflowHistories.Count; i++)
                    {
                        if (workflowHistories[i].CurrentNodeId == actionId)
                            currentHistories.Add(workflowHistories[i]);
                        else
                            break;
                    }

                    for (int i = currentHistories.Count - 1; i >= 0; i--)
                    {
                        if (currentHistories[i].IsActive == 1) break;
                        if (currentHistories[i].ApprovalUserId == userId)
                        {
                            errmsg = "You've already approved this step!";
                            return 0;
                        }
                    }

                    // Create a history from new approval
                    WorkflowHistory approvalHistory = WorkflowHistoryUtility.CreateObject();
                    approvalHistory.TransactionHeaderId = supplierVetting.TransactionId;
                    approvalHistory.WorkflowId = supplierVetting.WorkflowId;
                    approvalHistory.CurrentNodeId = actionId;
                    approvalHistory.ApprovalUserId = userId;
                    approvalHistory.ApprovalConditionId = 1;
                    approvalHistory.CreatedBy = userId;
                    approvalHistory.CreatedType = GetUserType();
                    approvalHistory.Comments = comments;
                    WorkflowHistoryUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, approvalHistory);

                    int approvalKnt = currentHistories.Count + 1;
                    switch (workflowNode.Action1)
                    {
                        case "All":
                            //if (approvalKnt < userCount)
                            //    approval = false;
                            break;
                        case "Majority":
                            //if (approvalKnt < userCount / 2)
                            //    approval = false;
                            break;
                        case "Count":
                            int knt = ConvertUtility.ConvertInt(workflowNode.Action2);
                            if (approvalKnt < knt)
                                approval = false;
                            break;
                    }
                    break;

                //case "Sequence":
                //    break;
                //case "Timer":
                //    break;
            }

            if (!approval || errmsg != string.Empty) return supplierVetting.TransactionId;

            //Action proccessing
            WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE,
                new object[] { workflowNode.Id });

            foreach (WorkflowAction workflowAction in workflowActions)
            {
                switch (workflowAction.Type)
                {
                    //Send Email
                    case 1:
                        SupplierVettingSendEmail(supplierVetting, workflowHistory, workflowAction.FunctionName, comments);
                        break;

                    //Action
                    case 2:
                        SupplierVettingAction(supplierVetting, workflowAction.FunctionName);
                        break;

                    //Redirect page
                    case 3:
                        url = workflowAction.FunctionName;
                        break;
                }
            }

            if (workflowNode.NodeToId > 0)
            {
                WorkflowNode nextNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode.NodeToId);
                WorkflowExec.WorkflowNextStatus(workflowNode.WorkflowId, nextNode.Name, workflowHistory.CurrentNodeId, supplierVetting.TransactionId, comments);
                NodeAction(supplierVetting, comments);
            }

            return supplierVetting.TransactionId;
        }

        public static int SupplierVettingWorkflow(SupplierVetting supplierVetting, string nextStatus, string comments)
        {
            int transactionId = GetTransactionId(supplierVetting, comments);

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(supplierVetting.TransactionId);
            if (workflowHistory == null)
                return 0;

            WorkflowExec.WorkflowNextSystemStatus(supplierVetting.WorkflowId, nextStatus, workflowHistory.CurrentNodeId, supplierVetting.TransactionId, comments);

            NodeAction(supplierVetting, comments);

            return supplierVetting.TransactionId;
        }

        public static WorkflowConditionCollection SupplierVettingWorkflowConditionTest(SupplierVetting supplierVetting, int workflowNodeId)
        {
            WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE,
                new object[] { workflowNodeId });

            XPathDocument doc = new XPathDocument(XmlUtility.Serialize(supplierVetting));
            XPathNavigator nav = doc.CreateNavigator();

            foreach (WorkflowCondition workflowCondition in workflowConditions)
            {
                DateDiffFunctionContext ctx = new DateDiffFunctionContext(new NameTable());
                XPathExpression expr = nav.Compile(workflowCondition.Condition);
                expr.SetContext(ctx);
                XPathNodeIterator iterator = nav.Select(expr);
                if (iterator.Count > 0)
                    workflowCondition.Status = 1;
            }
            return workflowConditions;
        }
        #endregion Workflow Control

        #region Workflow Node Action
        private static void NodeAction(SupplierVetting supplierVetting, string comments)
        {
            int status = 0;
            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNode(
                supplierVetting.TransactionId);

            VettingList vettingList = VettingListUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
                supplierVetting.VettingId);

            foreach (VettingFormStatusType vettingFormStatusType in VettingFormStatusType.GetEnumList())
            {
                if (vettingFormStatusType.Name == workflowHistory.CurrentNode.Action6)
                {
                    status = vettingFormStatusType.Id;
                    break;
                }
            }

            if (status == 0) return;

            if (SupplierVettingUtility.UpdateStatus(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                supplierVetting.Id, status))
                supplierVetting.Status = status;

            // automatic step
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { supplierVetting.WorkflowId, "UserStepId", "ASC" });
            for (int i = 0; i < workflowNodes.Count; i++)
            {
                if (workflowNodes[i].Type != 1 || workflowNodes[i].TimeToSkip != 1 ||
                    workflowHistory.CurrentNodeId != workflowNodes[i].NodeFromId)
                    continue;

                string errmsg = string.Empty;
                string url = string.Empty;
                SupplierVettingWorkflow(supplierVetting, workflowNodes[i].Id, comments, ref errmsg, ref url);
            }
        }
        #endregion Workflow Node Action

        #region Email Action
        private static void SupplierVettingSendEmail(SupplierVetting supplierVetting, WorkflowHistory workflowHistory,
            string emailMessageName, string comments)
        {
            EmailMessage emailmessage = EmailMessageUtility.GetByName(
                ConstantUtility.COMMON_DATASOURCE_NAME, emailMessageName);
            if (emailmessage == null) return;

            Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                supplierVetting.SupplierId);

            Vendor vendor = VendorUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                "FederalId", supplier.FederalId);

            User vettingUser = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, supplierVetting.UserId);

            User user = null;
            string userType = GetUserType();
            if (userType == "User")
                user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, GetUserId());
            if (user == null)
                user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, supplierVetting.UserId);

            // Can not send email w/o inviter
            if (user == null) return;

            User approver = WorkflowExec.GetLastApprover(supplierVetting.TransactionId);

            VettingList vetting = VettingListUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
                supplierVetting.VettingId);

            switch (emailmessage.Objects)
            {
                case "Authorized Users":
                    {
                        string nodes = XmlUtility.ToXml(workflowHistory.NextLinks);
                        UserCollection users = UserUtility.FindByCriteria(
                            ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_WORKFLOWNODES,
                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null && users.Count > 0)
                        {
                            VendorContact vendorContact = null;
                            if (vendor != null)
                                vendorContact = vendor.PrimaryContact;

                            EmailHistory emailHistory = CommonUtility.CreateEmailHistory(emailmessage,
                                "Vetting", supplierVetting.VettingId, "User", user.Id,
                                new object[] { supplierVetting, user, vetting, supplier, vendor });
                            for (int i = 0; i < users.Count; i++)
                            {
                                CommonUtility.VettingSendEmail(emailmessage, new object[] { supplierVetting, users[i], user, supplier, vendor,vendorContact, vetting },
                                    emailHistory, "User", users[i].Id, comments, ConstantUtility.VETTING_REF_MSG, supplierVetting.VettingId);
                            }
                        }
                    }
                    break;

                case "Users":
                    {
                        UserCollection users = UserUtility.FindByCriteria(
                            ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_POST,
                            new object[] { 0, 0, "LastName", "ASC", supplierVetting.VettingId, "Vetting" });
                        if (users == null)
                        {
                            users = new UserCollection();
                            users.Add(vettingUser);
                        }
                        else
                        {
                            bool exist = false;
                            foreach (User user1 in users)
                            {
                                if (user1.Id == supplierVetting.UserId)
                                {
                                    exist = true;
                                    break;
                                }
                            }
                            if (!exist)
                                users.Add(vettingUser);
                        }

                        if (users != null && users.Count > 0)
                        {
                            VendorContact vendorContact = null;
                            if (vendor != null)
                                vendorContact = vendor.PrimaryContact;

                            EmailHistory emailHistory = CommonUtility.CreateEmailHistory(emailmessage,
                                "Vetting", supplierVetting.VettingId, "User", user.Id,
                                new object[] { supplierVetting, user, vetting, supplier, vendor ,vendorContact });
                            for (int i = 0; i < users.Count; i++)
                            {
                                CommonUtility.VettingSendEmail(emailmessage, new object[] { supplierVetting, user, users[i], supplier, vendor, vendorContact, vetting },
                                    emailHistory, "User", users[i].Id, comments, ConstantUtility.VETTING_REF_MSG, supplierVetting.VettingId);
                            }
                        }
                    }
                    break;

                case "Owner":
                    {
                        EmailHistory emailHistory = CommonUtility.CreateEmailHistory(emailmessage,
                            "Vetting", supplierVetting.VettingId, "User", user.Id,
                            new object[] { supplierVetting, vettingUser, user, vetting, supplier, vendor });
                        CommonUtility.VettingSendEmail(emailmessage, new object[] { supplierVetting, vettingUser, user, supplier, vendor, vetting },
                            emailHistory, "User", user.Id, comments, ConstantUtility.VETTING_REF_MSG, supplierVetting.VettingId);
                    }
                    break;

                case "Approver":
                    {
                        EmailHistory emailHistory = CommonUtility.CreateEmailHistory(emailmessage,
                            "Vetting", supplierVetting.VettingId, "User", user.Id,
                            new object[] { supplierVetting, user, approver, vetting, supplier, vendor });
                        CommonUtility.VettingSendEmail(emailmessage, new object[] { supplierVetting, user, approver, supplier, vendor, vetting },
                            emailHistory, "User", user.Id, comments, ConstantUtility.VETTING_REF_MSG, supplierVetting.VettingId);
                    }
                    break;

                case "Suppliers":
                    {
                        VendorContact vendorContact = null;
                        if (vendor != null)
                            vendorContact = vendor.PrimaryContact;

                        EmailHistory emailHistory = CommonUtility.CreateEmailHistory(emailmessage,
                            "Vetting", supplierVetting.VettingId, "User", user.Id,
                            new object[] { supplierVetting, user, vetting, supplier, vendor, vendorContact });
                        CommonUtility.VettingSendEmail(emailmessage, new object[] { supplierVetting, user, supplier, vendor, vetting, vendorContact },
                            emailHistory, "Contact", vendorContact.Id, comments, ConstantUtility.VETTING_REF_MSG, supplierVetting.VettingId);
                    }
                    break;

                case "NotSubmit Bidders":
                    {
                        SupplierContactCollection contacts = SupplierContactUtility.FindByCriteria(
                            ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                            SupplierContactManager.FIND_CONTACT_BY_POST,
                            new object[] { 0, 0, "Company", "ASC", supplierVetting.VettingId, "NoSubmitVetting" });

                        if (contacts != null && contacts.Count > 0)
                        {
                            //EmailHistory emailHistory = CommonUtility.CreateVettingEmailHistory(emailmessage, 
                            //        supplierVetting, user, new object[] { supplierVetting, user, vetting, supplier, supplierContact });
                            //for (int i = 0; i < contacts.Count; i++)
                            //{
                            //    EmailHistoryCollection emailHistories = EmailHistoryUtility.FindByCriteria(
                            //        ConstantUtility.USER_DATASOURCE_NAME,
                            //        EmailHistoryManager.FIND_EMAILHISTORY_BY_DATERANGE,
                            //        new object[] 
                            //    {  
                            //        0,
                            //        0,
                            //        "CreateDate",
                            //        "DESC",
                            //        DateTime.UtcNow.Date, 
                            //        DateTime.UtcNow.Date,
                            //        "",
                            //        "",
                            //        "",
                            //        "",
                            //        vetting.Id,
                            //        "Supplier",
                            //        contacts[i].Id,
                            //        emailmessage.Name,
                            //        "" 
                            //    });

                            //    if (emailHistories == null || emailHistories.Count == 0)
                            //    {
                            //        CommonUtility.VettingSendEmail(emailmessage, 
                            //            new object[] { supplierVetting, user, supplier, supplierContact },
                            //            emailHistory, "Supplier", contacts[i].Id, comments, 
                            //            ConstantUtility.VETTING_REF_MSG, supplierVetting.VettingId);
                            //    }
                            //}
                        }
                    }
                    break;

                default:
                    {
                        EmailHistory emailHistory = CommonUtility.CreateEmailHistory(emailmessage,
                            "Vetting", supplierVetting.VettingId, "User", user.Id,
                            new object[] { supplierVetting, user, vetting, supplier, vendor });
                        CommonUtility.VettingSendEmail(emailmessage, new object[] { supplierVetting, user, supplier, vendor, vetting },
                            emailHistory, "User", user.Id, comments, ConstantUtility.VETTING_REF_MSG, supplierVetting.VettingId);
                    }
                    break;
            }
        }
        #endregion

        #region Supplier Action
        private static void SupplierVettingAction(SupplierVetting supplierVetting, string actionName)
        {
        }
        #endregion
    }
}
