#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ProjectSolicitationPackageStatuss:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ProjectSolicitationPackageStatussConverter))]
    public class ProjectSolicitationPackageStatussType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly ProjectSolicitationPackageStatussType NewPrequalification = new ProjectSolicitationPackageStatussType(0, "NewPrequalification", "New Qualification");
        public static readonly ProjectSolicitationPackageStatussType ApplicationSubmitted = new ProjectSolicitationPackageStatussType(1, "ApplicationSubmitted", "Application Submitted");
        public static readonly ProjectSolicitationPackageStatussType ManagerReviewed = new ProjectSolicitationPackageStatussType(2, "ManagerReviewed", "Manager Reviewed");
        public static readonly ProjectSolicitationPackageStatussType ReviewerReviewed = new ProjectSolicitationPackageStatussType(3, "ReviewerReviewed", "Reviewer Reviewed");
        public static readonly ProjectSolicitationPackageStatussType RequestMoreInfoPending = new ProjectSolicitationPackageStatussType(4, "RequestMoreInfoPending", "Request More Info Pending");
        public static readonly ProjectSolicitationPackageStatussType RequestMoreInfo = new ProjectSolicitationPackageStatussType(5, "RequestMoreInfo", "Request More Info");
        public static readonly ProjectSolicitationPackageStatussType AdditionalInfoSubmitted = new ProjectSolicitationPackageStatussType(6, "AdditionalInfoSubmitted", "Additional Info Submitted");
        public static readonly ProjectSolicitationPackageStatussType ReferenceReviewed = new ProjectSolicitationPackageStatussType(7, "ReferenceReviewed", "Reference Reviewed");
        public static readonly ProjectSolicitationPackageStatussType FinacialReviewed = new ProjectSolicitationPackageStatussType(8, "FinacialReviewed", "Financial Reviewed");
        public static readonly ProjectSolicitationPackageStatussType AllReviewed = new ProjectSolicitationPackageStatussType(9, "AllReviewed", "Reference and Financial Reviewed");
        public static readonly ProjectSolicitationPackageStatussType OIGApproved = new ProjectSolicitationPackageStatussType(10, "OIGApproved", "OIG Approved");
        public static readonly ProjectSolicitationPackageStatussType QualifiedPending = new ProjectSolicitationPackageStatussType(11, "QualifiedPending", "Qualified Pending");
        public static readonly ProjectSolicitationPackageStatussType Qualified = new ProjectSolicitationPackageStatussType(12, "Qualified", "Qualified");
        public static readonly ProjectSolicitationPackageStatussType PreDeny = new ProjectSolicitationPackageStatussType(13, "PreDeny", "PreDeny");
        public static readonly ProjectSolicitationPackageStatussType AdministrativelyClosed = new ProjectSolicitationPackageStatussType(14, "AdministrativelyClosed", "Administratively Closed");
        public static readonly ProjectSolicitationPackageStatussType DirectorClosePending = new ProjectSolicitationPackageStatussType(15, "DirectorClosePending", "Director Close Pending");
        public static readonly ProjectSolicitationPackageStatussType DirectorClosed = new ProjectSolicitationPackageStatussType(16, "DirectorClosed", "Director Closed");
        public static readonly ProjectSolicitationPackageStatussType Inactive = new ProjectSolicitationPackageStatussType(17, "Inactive", "Inactive");
        public static readonly ProjectSolicitationPackageStatussType Disqualified = new ProjectSolicitationPackageStatussType(18, "Disqualified", "Disqualified");
        public static readonly ProjectSolicitationPackageStatussType Withdrawn = new ProjectSolicitationPackageStatussType(19, "Withdrawn", "Withdrawn");
        public static readonly ProjectSolicitationPackageStatussType OIGReviewed = new ProjectSolicitationPackageStatussType(20, "OIGReviewed", "OIG Reviewed");
        public static readonly ProjectSolicitationPackageStatussType Rescinded = new ProjectSolicitationPackageStatussType(21, "Rescinded", "Rescinded");
        public static readonly ProjectSolicitationPackageStatussType Suspended = new ProjectSolicitationPackageStatussType(22, "Suspended", "Suspended");
        public static readonly ProjectSolicitationPackageStatussType RequestMoreInfo2 = new ProjectSolicitationPackageStatussType(23, "RequestMoreInfo2", "Request More Info 2");
        public static readonly ProjectSolicitationPackageStatussType AdditionalInfoSubmitted2 = new ProjectSolicitationPackageStatussType(24, "AdditionalInfoSubmitted2", "Additional Info Submitted 2");
        public static readonly ProjectSolicitationPackageStatussType Deny = new ProjectSolicitationPackageStatussType(25, "Deny", "Deny");
        public static readonly ProjectSolicitationPackageStatussType Expired = new ProjectSolicitationPackageStatussType(26, "Expired", "Expired");
        public static readonly ProjectSolicitationPackageStatussType OIGPending = new ProjectSolicitationPackageStatussType(27, "OIGPending", "OIG Pending");
        #endregion

        #region Constructors
        public ProjectSolicitationPackageStatussType()
        {
        }

        private ProjectSolicitationPackageStatussType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectSolicitationPackageStatuss class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ProjectSolicitationPackageStatuss.  
        /// </summary>
        public static ProjectSolicitationPackageStatussType Default
        {
            get
            {
                return (ProjectSolicitationPackageStatussType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectSolicitationPackageStatuss class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((ProjectSolicitationPackageStatussType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectSolicitationPackageStatuss object.
        /// It allows a string to be assigned to a ProjectSolicitationPackageStatuss object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ProjectSolicitationPackageStatussType(int id)
        {
            return (ProjectSolicitationPackageStatussType)EnumerationBase.FindById(id, ProjectSolicitationPackageStatussType._list);
        }
        public static implicit operator ProjectSolicitationPackageStatussType(string name)
        {
            for (int i = 0; i < ProjectSolicitationPackageStatussType._list.Count; i++)
            {
                if (((ProjectSolicitationPackageStatussType)ProjectSolicitationPackageStatussType._list[i]).Name == name)
                    return (ProjectSolicitationPackageStatussType)ProjectSolicitationPackageStatussType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectSolicitationPackageStatuss objects.
    /// It's very useful when binding ProjectSolicitationPackageStatuss objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ProjectSolicitationPackageStatussConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ProjectSolicitationPackageStatussType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectSolicitationPackageStatuss enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ProjectSolicitationPackageStatussType._list.Count; i++)
            {
                list.Add(((ProjectSolicitationPackageStatussType)ProjectSolicitationPackageStatussType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
