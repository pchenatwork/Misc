#region Copyright (C) 2006 - 2007 AECsoft USA, Inc.
///==========================================================================
/// Copyright (C) 2006 AECsoft USA, Inc.
///
/// All	rights reserved. No	portion	of this	software or	its	content	may	be
/// reproduced in any form or by any means,	without	the	express	written
/// permission of the copyright owner.
///==========================================================================
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.Workflow
{
    /// <summary>
    /// This Class defines the various enumerated values of ProjectBidAdvertisementStatus:
    /// </summary>
    [Serializable]
    [TypeConverter(typeof(ProjectBidAdvertisementStatusConverter))]
    public class ProjectBidAdvertisementStatusType : EnumerationBase
    {
        #region public Variables
        internal static readonly ArrayList _list = new ArrayList();
        #endregion

        #region Enumeration Elements
        public static readonly ProjectBidAdvertisementStatusType NewPrequalification = new ProjectBidAdvertisementStatusType(0, "NewPrequalification", "New Qualification");
        public static readonly ProjectBidAdvertisementStatusType ApplicationSubmitted = new ProjectBidAdvertisementStatusType(1, "ApplicationSubmitted", "Application Submitted");
        public static readonly ProjectBidAdvertisementStatusType ManagerReviewed = new ProjectBidAdvertisementStatusType(2, "ManagerReviewed", "Manager Reviewed");
        public static readonly ProjectBidAdvertisementStatusType ReviewerReviewed = new ProjectBidAdvertisementStatusType(3, "ReviewerReviewed", "Reviewer Reviewed");
        public static readonly ProjectBidAdvertisementStatusType RequestMoreInfoPending = new ProjectBidAdvertisementStatusType(4, "RequestMoreInfoPending", "Request More Info Pending");
        public static readonly ProjectBidAdvertisementStatusType RequestMoreInfo = new ProjectBidAdvertisementStatusType(5, "RequestMoreInfo", "Request More Info");
        public static readonly ProjectBidAdvertisementStatusType AdditionalInfoSubmitted = new ProjectBidAdvertisementStatusType(6, "AdditionalInfoSubmitted", "Additional Info Submitted");
        public static readonly ProjectBidAdvertisementStatusType ReferenceReviewed = new ProjectBidAdvertisementStatusType(7, "ReferenceReviewed", "Reference Reviewed");
        public static readonly ProjectBidAdvertisementStatusType FinacialReviewed = new ProjectBidAdvertisementStatusType(8, "FinacialReviewed", "Financial Reviewed");
        public static readonly ProjectBidAdvertisementStatusType AllReviewed = new ProjectBidAdvertisementStatusType(9, "AllReviewed", "Reference and Financial Reviewed");
        public static readonly ProjectBidAdvertisementStatusType OIGApproved = new ProjectBidAdvertisementStatusType(10, "OIGApproved", "OIG Approved");
        public static readonly ProjectBidAdvertisementStatusType QualifiedPending = new ProjectBidAdvertisementStatusType(11, "QualifiedPending", "Qualified Pending");
        public static readonly ProjectBidAdvertisementStatusType Qualified = new ProjectBidAdvertisementStatusType(12, "Qualified", "Qualified");
        public static readonly ProjectBidAdvertisementStatusType PreDeny = new ProjectBidAdvertisementStatusType(13, "PreDeny", "PreDeny");
        public static readonly ProjectBidAdvertisementStatusType AdministrativelyClosed = new ProjectBidAdvertisementStatusType(14, "AdministrativelyClosed", "Administratively Closed");
        public static readonly ProjectBidAdvertisementStatusType DirectorClosePending = new ProjectBidAdvertisementStatusType(15, "DirectorClosePending", "Director Close Pending");
        public static readonly ProjectBidAdvertisementStatusType DirectorClosed = new ProjectBidAdvertisementStatusType(16, "DirectorClosed", "Director Closed");
        public static readonly ProjectBidAdvertisementStatusType Inactive = new ProjectBidAdvertisementStatusType(17, "Inactive", "Inactive");
        public static readonly ProjectBidAdvertisementStatusType Disqualified = new ProjectBidAdvertisementStatusType(18, "Disqualified", "Disqualified");
        public static readonly ProjectBidAdvertisementStatusType Withdrawn = new ProjectBidAdvertisementStatusType(19, "Withdrawn", "Withdrawn");
        public static readonly ProjectBidAdvertisementStatusType OIGReviewed = new ProjectBidAdvertisementStatusType(20, "OIGReviewed", "OIG Reviewed");
        public static readonly ProjectBidAdvertisementStatusType Rescinded = new ProjectBidAdvertisementStatusType(21, "Rescinded", "Rescinded");
        public static readonly ProjectBidAdvertisementStatusType Suspended = new ProjectBidAdvertisementStatusType(22, "Suspended", "Suspended");
        public static readonly ProjectBidAdvertisementStatusType RequestMoreInfo2 = new ProjectBidAdvertisementStatusType(23, "RequestMoreInfo2", "Request More Info 2");
        public static readonly ProjectBidAdvertisementStatusType AdditionalInfoSubmitted2 = new ProjectBidAdvertisementStatusType(24, "AdditionalInfoSubmitted2", "Additional Info Submitted 2");
        public static readonly ProjectBidAdvertisementStatusType Deny = new ProjectBidAdvertisementStatusType(25, "Deny", "Deny");
        public static readonly ProjectBidAdvertisementStatusType Expired = new ProjectBidAdvertisementStatusType(26, "Expired", "Expired");
        public static readonly ProjectBidAdvertisementStatusType OIGPending = new ProjectBidAdvertisementStatusType(27, "OIGPending", "OIG Pending");
        #endregion

        #region Constructors
        public ProjectBidAdvertisementStatusType()
        {
        }

        private ProjectBidAdvertisementStatusType(
            int id,
            string name,
            string description)
            : base(id, name, description)
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Singleton property allows the base class access the static values list defined
        /// in ProjectBidAdvertisementStatus class.
        /// </summary>
        protected override ArrayList List
        {
            get
            {
                return _list;
            }
        }

        /// <summary>
        /// Define the default value of ProjectBidAdvertisementStatus.  
        /// </summary>
        public static ProjectBidAdvertisementStatusType Default
        {
            get
            {
                return (ProjectBidAdvertisementStatusType)_list[0];
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Static method to return all Enum values for ProjectBidAdvertisementStatus class.
        /// </summary>
        public static ArrayList GetEnumList()
        {
            return _list;
        }
        public static string[] GetSortedArray()
        {
            string[] descriptions = new string[_list.Count];
            for (int i = 0; i < _list.Count; i++)
                descriptions[i] = ((ProjectBidAdvertisementStatusType)_list[i]).Description;
            Array.Sort(descriptions);
            return descriptions;
        }
        #endregion

        #region Conversion Operators
        /// <summary>
        /// Implicit operator to convert a string to a ProjectBidAdvertisementStatus object.
        /// It allows a string to be assigned to a ProjectBidAdvertisementStatus object without
        /// doing a explicit type conversion.
        /// </summary>
        public static implicit operator ProjectBidAdvertisementStatusType(int id)
        {
            return (ProjectBidAdvertisementStatusType)EnumerationBase.FindById(id, ProjectBidAdvertisementStatusType._list);
        }
        public static implicit operator ProjectBidAdvertisementStatusType(string name)
        {
            for (int i = 0; i < ProjectBidAdvertisementStatusType._list.Count; i++)
            {
                if (((ProjectBidAdvertisementStatusType)ProjectBidAdvertisementStatusType._list[i]).Description == name)
                    return (ProjectBidAdvertisementStatusType)ProjectBidAdvertisementStatusType._list[i];
            }
            return null;
        }
        #endregion
    }

    /// <summary>
    /// Implements a TypeConverter to automatically convert between string 
    /// and ProjectBidAdvertisementStatus objects.
    /// It's very useful when binding ProjectBidAdvertisementStatus objects to controls 
    /// such as DropDownList or RadioButtonList.
    /// </summary>
    public class ProjectBidAdvertisementStatusConverter : TypeConverter
    {
        #region Public Methods
        /// <summary>
        /// This override states that the type can be converted
        /// from a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="sourceType"></param>
        /// <returns></returns>
        public override bool CanConvertFrom(
            ITypeDescriptorContext context,
            Type sourceType)
        {
            if (sourceType == typeof(int))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);
        }

        /// <summary>
        /// This override states that the type can be converted
        /// to a string expression.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(
            ITypeDescriptorContext context,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// This override provides the conversion logic from
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            int id = Convert.ToInt32(value);
            return EnumerationBase.FindById(id, ProjectBidAdvertisementStatusType._list);
            //return base.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// This override provides the conversion logic to
        /// a string expression (based on the Id attribute)
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            if (destinationType == typeof(int))
            {
                EnumerationBase enumeration = value as EnumerationBase;
                if (enumeration != null)
                {
                    return enumeration.Id;
                }
            }
            return base.ConvertTo(context, culture, value, destinationType);
        }

        /// <summary>
        /// This override provides the display names for the ProjectBidAdvertisementStatus enumeration
        /// as the standard set of selectable values.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < ProjectBidAdvertisementStatusType._list.Count; i++)
            {
                list.Add(((ProjectBidAdvertisementStatusType)ProjectBidAdvertisementStatusType._list[i]).Id);
            }
            return new StandardValuesCollection(list);
        }

        /// <summary>
        /// This override tells the framework that the standard values is available
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        #endregion
    }
}
