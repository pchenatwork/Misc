﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.ValueObjects.Workflow;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Hb;

namespace SCA.VAS.Workflow
{
    public partial class ConstantUtility
    {
        public const string WORKFLOW_PREQUAL_LIMITEDLIST = "Prequal Limited List";
        public const string WORKFLOW_MENTOR_LIMITEDLIST = "Mentor Limited List";
        public const string WORKFLOW_MENTORGRADUATE_LIMITEDLIST = "Graduate Mentor Limited List";
        public const string WORKFLOW_SUPPLIER_LIMITEDLIST = "Supplier Limited List";
        //public const string WORKFLOW_INCLUSION_LIMITEDLIST = "Inclusion Limited List";
        //public const string WORKFLOW_RESCISSION_LIMITEDLIST = "Rescission Limited List";

        public const int MIN_APPROVED_FIRM = 5;
        public const int MAX_MENTOR_FIRM = 15;
        //PS 1/24/2013. Now the Max approved number is 11 instead of 8
        public const int MAX_APPROVED_MENTOR_FIRM = 11;//8; 

        public const string ROLE_PROJECT_OFFICER = "Project Officer";
    }

    public partial class CommonUtility
    {
        public static void RfdProjectSendEmail(RfdProject rfdProject, WorkflowNode node, WorkflowHistory workflowHistory,
            string emailMessageName, string comments)
        {
            RfdProjectSendEmail(rfdProject, node, workflowHistory, emailMessageName, comments, null);
        }

        public static void RfdProjectSendEmail(RfdProject rfdProject, WorkflowNode node, WorkflowHistory workflowHistory,
            string emailMessageName, string comments, RfdSupplier rfdSupplier)
        {
            EmailMessage emailmessage = EmailMessageUtility.GetByName(
                ConstantUtility.COMMON_DATASOURCE_NAME, emailMessageName);
            if (emailmessage == null) return;

            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, WorkflowExec.GetUserId());
            Supplier supplier = null;
            if (rfdSupplier != null)
                supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, rfdSupplier.SupplierId);

            EmailMessage newMessage = EmailReplaceRelatedUsers(emailmessage, rfdProject, rfdSupplier, supplier);

            switch (emailmessage.Objects)
            {
                case "Node Users":
                    if (node != null)
                    {
                        WorkflowNodeCollection workflownodes = new WorkflowNodeCollection();
                        workflownodes.Add(node);
                        string nodes = XmlUtility.ToXml(workflownodes);
                        UserCollection users = UserUtility.FindByCriteria(
                            ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_WORKFLOWNODES,
                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                            {
                                SendEmail(newMessage, users[i],
                                    new object[] { rfdProject, user, users[i], rfdSupplier, supplier },
                                    comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "RfdProject", rfdProject.Id);
                            }
                        }
                    }
                    break;

                case "Authorized Users":
                    {
                        string nodes = XmlUtility.ToXml(workflowHistory.NextLinks);
                        UserCollection users = UserUtility.FindByCriteria(
                            ConstantUtility.USER_DATASOURCE_NAME,
                            UserManager.FIND_USER_BY_WORKFLOWNODES,
                            new object[] { 0, 0, "LastName", "ASC", nodes, "", 0 });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                            {
                                SendEmail(newMessage, users[i],
                                    new object[] { rfdProject, user, users[i], rfdSupplier, supplier },
                                    comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "RfdProject", rfdProject.Id);
                            }
                        }
                    }
                    break;

                case "Approver":
                    {
                        User approver = RfdProjectWorkflowExec.GetLastApprover(rfdProject);

                        SendEmail(newMessage, user,
                            new object[] { rfdProject, user, approver, rfdSupplier, supplier }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "RfdProject", rfdProject.Id);
                    }
                    break;
                case "FinalUser":
                    {
                        User approver = RfdProjectWorkflowExec.GetLastReviewer(rfdProject);

                        SendEmail(newMessage, user,
                            new object[] { rfdProject, approver, user, rfdSupplier, supplier }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "RfdProject", rfdProject.Id);
                    }
                    break;
                case "Supplier Related Users":
                    {
                        SendEmail(newMessage, user,
                            new object[] { rfdProject, user, rfdSupplier, supplier }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "RfdProject", rfdProject.Id);
                    }
                    break;
                case "Workflow Users": // RFD Rejection email
                    {
                        UserCollection users = UserUtility.FindByCriteria(
                           ConstantUtility.USER_DATASOURCE_NAME,
                           UserManager.FIND_USER_BY_WORKFLOWTRANSACTION,
                           new object[] { rfdSupplier.TransactionId });

                        if (users != null)
                        {
                            for (int i = 0; i < users.Count; i++)
                            {
                                SendEmail(newMessage, users[i],
                                    new object[] { rfdProject, user, users[i], rfdSupplier, supplier },
                                    comments,
                                    (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                                    "RfdProject", rfdProject.Id);
                            }
                        }
                    }
                    break;
                default:
                    {
                        SendEmail(newMessage, null,
                            new object[] { rfdProject, user, rfdSupplier, supplier }, comments,
                            (emailMessageName.ToUpper().IndexOf("PASSWORD") == -1),
                            "RfdProject", rfdProject.Id);
                    }
                    break;
            }
        }

        public static EmailMessage EmailReplaceRelatedUsers(EmailMessage emailmessage, RfdProject rfdProject, RfdSupplier rfdSupplier, Supplier supplier)
        {
            if (emailmessage == null) return null;

            Hashtable RelatedUsers = new Hashtable();

            RelatedUsers.Add("$RFCPACKAGENUMBER$", (rfdProject == null) ? "" : rfdProject.Package);
            RelatedUsers.Add("$RFCSUPPLIER$", (rfdSupplier == null) ? "" : rfdSupplier.SupplierName);

            User projOfficer = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, rfdProject.Requester);

            RelatedUsers.Add("$PROJECTOFFICERNAME$", (projOfficer == null) ? "" : projOfficer.FullName);
            RelatedUsers.Add("$PROJECTOFFICERPHONE$", (projOfficer == null) ? "" : projOfficer.Phone);
            RelatedUsers.Add("$PROJECTOFFICEREMAIL$", (projOfficer == null) ? "" : projOfficer.Email);
            RelatedUsers.Add("$PROJECTOFFICERTITLE$", (projOfficer == null) ? "" : projOfficer.Title);

            User srProjOfficer = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, rfdProject.Supervisor);
            RelatedUsers.Add("$SRPROJECTOFFICERNAME$", (srProjOfficer == null) ? "" : srProjOfficer.FullName);
            RelatedUsers.Add("$SRPROJECTOFFICERPHONE$", (srProjOfficer == null) ? "" : srProjOfficer.Phone);
            RelatedUsers.Add("$SRPROJECTOFFICEREMAIL$", (srProjOfficer == null) ? "" : srProjOfficer.Email);
            RelatedUsers.Add("$SRPROJECTOFFICERTITLE$", (srProjOfficer == null) ? "" : srProjOfficer.Title);


            RelatedUsers.Add("$PROJECTDESCRIPTION$", rfdProject.Description);
            RelatedUsers.Add("$PROJECTLLW$", rfdProject.Items[0].LLW.ToString());
            RelatedUsers.Add("$SOLICITATIONNO$", rfdProject.SolicitationNo + "-" + rfdProject.SolicitSeq.ToString());
            RelatedUsers.Add("$PROJECTAMOUNT$", rfdProject.Amount.ToString());
            RelatedUsers.Add("$PROJECTSCHOOL$", rfdProject.Items[0].School);
            //RelatedUsers.Add("$PROJECTADDEDBY$", user.FullName);
            //RelatedUsers.Add("$PROJECTCOMMENT$", comment);

            
            User chiefProjOfficer = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, rfdProject.ChiefProjectOfficer);
            if (chiefProjOfficer != null)
            {
                RelatedUsers.Add("$CHIEFPROJECTOFFICERNAME$", (chiefProjOfficer == null) ? "" : chiefProjOfficer.FullName);
                RelatedUsers.Add("$CHIEFPROJECTOFFICERPHONE$", (chiefProjOfficer == null) ? "" : chiefProjOfficer.Phone);
                RelatedUsers.Add("$CHIEFPROJECTOFFICEREMAIL$", (chiefProjOfficer == null) ? "" : chiefProjOfficer.Email);
                RelatedUsers.Add("$CHIEFPROJECTOFFICERTITLE$", (chiefProjOfficer == null) ? "" : chiefProjOfficer.Title);

                UserCollection users = UserUtility.FindByCriteria(ConstantUtility.USER_DATASOURCE_NAME,
                    UserManager.FIND_USER_BY_POST,
                    new object[] { 0, 0, "ASC", "FullName", chiefProjOfficer.Id, "Supervisor" });
                if (users != null && users.Count > 0)
                {
                    RelatedUsers.Add("$CPOASSISTANTNAME$", users[0].FullName);
                    RelatedUsers.Add("$CPOASSISTANTPHONE$", users[0].Phone);
                    RelatedUsers.Add("$CPOASSISTANTEMAIL$", users[0].Email);
                    RelatedUsers.Add("$CPOASSISTANTTITLE$", users[0].Title);
                }
                else
                {
                    RelatedUsers.Add("$CPOASSISTANTNAME$", "");
                    RelatedUsers.Add("$CPOASSISTANTPHONE$", "");
                    RelatedUsers.Add("$CPOASSISTANTEMAIL$", "");
                    RelatedUsers.Add("$CPOASSISTANTTITLE$", "");
                }
            }
            //Ticket 157464 
            if (emailmessage.BccEmail.Contains("$CQUDIRECTORS$") || emailmessage.CcEmail.Contains("$CQUDIRECTORS$"))
            {
                string cqudirectorlist = "";

                UserCollection CQUdirectorlist = UserUtility.FindByCriteria(
                    ConstantUtility.USER_DATASOURCE_NAME,
                    UserManager.SEARCH_USER,
                    new object[]
                        {
                        0,
                        0,
                        string.Empty,
                        string.Empty,
                        string.Empty,
                        1,
                        string.Empty,
                        string.Empty,
                        "CQU Director",
                        string.Empty,
                        string.Empty,
                        });
                if (CQUdirectorlist != null)
                {
                    foreach (User cquUser in CQUdirectorlist)
                        cqudirectorlist = cqudirectorlist + cquUser.Email + ";";
                }
                RelatedUsers.Add("$CQUDIRECTORS$", (cqudirectorlist == null) ? "" : cqudirectorlist);
            }

            User contractSpecialist = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, rfdProject.ContractSpecialist);
            RelatedUsers.Add("$CONTRACTSPECIALISTNAME$", (contractSpecialist == null) ? "" : contractSpecialist.FullName);
            RelatedUsers.Add("$CONTRACTSPECIALISTPHONE$", (contractSpecialist == null) ? "" : contractSpecialist.Phone);
            RelatedUsers.Add("$CONTRACTSPECIALISTEMAIL$", (contractSpecialist == null) ? "" : contractSpecialist.Email);
            RelatedUsers.Add("$CONTRACTSPECIALISTTITLE$", (contractSpecialist == null) ? "" : contractSpecialist.Title);

            SettingCollection settings = SettingUtility.FindByCriteria(
                ConstantUtility.COMMON_DATASOURCE_NAME,
                SettingManager.FIND_SETTING_BY_TYPE,
                new object[] { "ConstructionManager" });
            Setting setting = settings.Find(rfdProject.ConstructionManagement);
            if (setting != null)
            {
                RelatedUsers.Add("$CMFIRMNAME$", setting.Name);
                RelatedUsers.Add("$CMFIRMEMAILS$", setting.Description);
            }
            else
            {
                RelatedUsers.Add("$CMFIRMNAME$", "");
                RelatedUsers.Add("$CMFIRMEMAILS$", "");
            }

            string school = string.Empty;
            if (rfdProject != null && rfdProject.Items != null && rfdProject.Items.Count > 0)
            {
                foreach (RfdItem item in rfdProject.Items)
                {
                    if (school.IndexOf(item.School) < 0)
                        school = school + item.School + ", ";
                }
            }
            if (school.Length >= 1)
            {
                RelatedUsers.Add("$LLWSCHOOL$", school.Substring(0, (school.Length - 1)));
            }

            emailmessage.FromEmail = ReplaceRelatedUsers(emailmessage.FromEmail, RelatedUsers);
            emailmessage.ToEmail = ReplaceRelatedUsers(emailmessage.ToEmail, RelatedUsers);
            emailmessage.ToName = ReplaceRelatedUsers(emailmessage.ToName, RelatedUsers);
            emailmessage.CcEmail = ReplaceRelatedUsers(emailmessage.CcEmail, RelatedUsers);
            emailmessage.BccEmail = ReplaceRelatedUsers(emailmessage.BccEmail, RelatedUsers);
            emailmessage.Subject = ReplaceRelatedUsers(emailmessage.Subject, RelatedUsers);
            emailmessage.Body = ReplaceRelatedUsers(emailmessage.Body, RelatedUsers);

            return emailmessage;
        }

        public static string GetCriteria(string criteria)
        {
            string supplierCriteria = "";

            List<Extra> extraItems = (List<Extra>)XmlUtility.Deserialize(criteria, typeof(List<Extra>));

            string tradeCodes = GetValue(extraItems, "Categories");
            string experience = GetValue(extraItems, "whMinAmount");
            string financialCapacity = GetValue(extraItems, "FinancialCapacity");

            // Trade Codes
            if (tradeCodes.Trim().Length > 0)
            {
                string[] categories = tradeCodes.Split('^');
                if (categories.Length > 0)
                {
                    supplierCriteria += "Trade Codes: ";
                    Category category = CategoryUtility.Get(ConstantUtility.COMMON_DATASOURCE_NAME,
                        ConvertUtility.ConvertInt(categories[0].Trim()));
                    if (category != null)
                        supplierCriteria += category.Name + " (" + category.Code + ")" + "<br />";
                    for (int i = 1; i < categories.Length; i++)
                    {
                        category = CategoryUtility.Get(ConstantUtility.COMMON_DATASOURCE_NAME,
                            ConvertUtility.ConvertInt(categories[i].Trim()));
                        if (category != null)
                            supplierCriteria += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + category.Name + " (" + category.Code + ")" + "<br />";
                    }
                }
            }

            // Experience
            if (experience.Trim().Length > 0)
            {
                supplierCriteria += "Minimum Experience: " + experience.Trim() + "<br />";
            }
            // Financial Capacity
            if (financialCapacity.Trim().Length > 0)
            {
                supplierCriteria += "Minimum Financial Capacity: " + financialCapacity.Trim() + "<br />";
            }

            return supplierCriteria;
        }

        public static bool DisplayButton(RfdProject project, string actionName)
        {
            bool bShow = true;
            WorkflowNode workflowNode = WorkflowNodeUtility.GetBySystemName(ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                project.WorkflowId, actionName);

            if (workflowNode != null)
            {
                WorkflowConditionCollection conditions = RfdProjectWorkflowExec.RfdProjectConditionTest(project, workflowNode.Id);
                if (conditions != null)
                {
                    foreach (WorkflowCondition condition in conditions)
                    {
                        if (condition.Status == 0)
                        {
                            bShow = false;
                            break;
                        }
                    }
                }
            }
            return bShow;
        }

        public static int CreateRfdProject(Rfc rfc, string transNumber, int userId)
        {
           int rfdId = RfdProjectUtility.Import(ConstantUtility.RFD_DATASOURCE_NAME,transNumber, 0, userId);

            if (rfdId > 0)
            {
                AddLimitedListUser(rfc.PO, ConstantUtility.ROLE_PROJECT_OFFICER, userId);
                AddLimitedListUser(rfc.SPO, ConstantUtility.ROLE_SENIOR_PROJECT_OFFICER, userId);
                AddLimitedListUser(rfc.CPO, ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER, userId);
                AddLimitedListUser(rfc.ContractSpecialist, ConstantUtility.ROLE_CONTRACT_SPECIALIST, userId);
            }

            return rfdId;
        }

        public static int CreateHardbidProject(HBJustificationMemo jm, int userId)
        {
           int rfdId = RfdProjectUtility.ImportJustificationMemo(ConstantUtility.RFD_DATASOURCE_NAME, jm.Id, 0, userId);

            if (rfdId > 0)
            {
                AddLimitedListUser(jm.Po, ConstantUtility.ROLE_PROJECT_OFFICER, userId);
                AddLimitedListUser(jm.Spo, ConstantUtility.ROLE_SENIOR_PROJECT_OFFICER, userId);
                AddLimitedListUser(jm.Cpo, ConstantUtility.ROLE_CHIEF_PROJECT_OFFICER, userId);
                //There is no Contract Specialist//
            }

            return rfdId;
        }

        public static void AddLimitedListUser(string userName, string roleName, int userId)
        {
            if (userName.Trim().Length > 0)
            {
                CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME, userName);
                if (cesUser != null)
                    AddUser(cesUser, roleName, "", userId);
            }
        }

        public static bool SetWorkflowPermission(RfdProject project, object[] actions)
        {
            if (project == null || actions == null || actions.Length == 0) return false;

            WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNodeByUser(project.TransactionId, -1);
            if (workflowHistory == null) return false;

            WorkflowNodeCollection workflowNodes = workflowHistory.NextLinks;
            if (workflowNodes == null || workflowNodes.Count == 0) return false;

            foreach (object action in actions)
            {
                foreach (WorkflowNode workflowNode in workflowNodes)
                {
                    if (workflowNode.NodeToId > 0 && ((RfdProjectAction)action).Name == workflowNode.Action6)
                        return true;
                }
            }
            return false;
        }

    }
}
