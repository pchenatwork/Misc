using System;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.Collections;

public class DateDiffFunction : IXsltContextFunction
{
    private XPathResultType[] _argTypes;

    public DateDiffFunction(XPathResultType[] argTypes)
    {
        _argTypes = argTypes;
        //foreach (XPathResultType t in argTypes)
        //    if (t != XPathResultType.Number)
        //        throw new Exception("incorrect argument type: must supply number values");
    }

    public int Minargs
    {
        get { return 3; }
    }

    public int Maxargs
    {
        get { return 3; }
    }

    public XPathResultType ReturnType
    {

        get { return XPathResultType.Number; }
    }

    public XPathResultType[] ArgTypes
    {
        get { return _argTypes; }
    }

    public object Invoke(XsltContext xsltContext, object[] args, XPathNavigator docContext)
    {
        return datediff((string)args[0], (string)args[1], (string)args[2], (double)args[3]);
    }

    private double datediff(string type, string startDate, string endDate, double days)
    {
        DateTime startdate;
        DateTime enddate;
        if(startDate.ToLower() == "now")
            startdate = DateTime.Now;
        else
            startdate = Convert.ToDateTime(startDate);
        if (endDate.ToLower() == "now")
            enddate = DateTime.Now;
        else
            enddate = Convert.ToDateTime(endDate);

        enddate = enddate.AddDays(days);

        TimeSpan diff = (enddate - startdate);

        switch (type.ToLower())
        {
            case "day":
                return diff.TotalDays;
            case "hour":
                return diff.TotalHours;
            case "minute":
                return diff.TotalMinutes;
            case "second":
                return diff.TotalSeconds;
            case "millisecond":
                return diff.TotalMilliseconds;
        }
        return 0;
    }
}

class DateDiffFunctionContext : XsltContext
{
    private bool _whitespace;
    private bool _preserveWhitespace;

    public DateDiffFunctionContext(NameTable nt)
        : base(nt)
    {
        _whitespace = false;
        _preserveWhitespace = false;
    }
    public override IXsltContextVariable ResolveVariable(string prefix, string name)
    {
        return new XsltVariable();
    }
    public override IXsltContextFunction ResolveFunction(string prefix, string name, XPathResultType[] ArgTypes)
    {
        if (name.ToLower() == "datediff")
            return new DateDiffFunction(ArgTypes);
        else
            return null;
    }
    public override bool Whitespace
    {
        get { return _whitespace; }
    }
    public override bool PreserveWhitespace(XPathNavigator node)
    {
        return _preserveWhitespace;
    }
    public override int CompareDocument(string doc1, string doc2)
    {
        return 0;
    }
}

class XsltVariable : IXsltContextVariable
{
    public bool IsLocal
    {
        get { return false; }
    }
    public bool IsParam
    {
        get { return false; }
    }
    public XPathResultType VariableType
    {
        get { return XPathResultType.Any; }
    }
    public object Evaluate(XsltContext xsltContext)
    {
        return null;
    }
}
