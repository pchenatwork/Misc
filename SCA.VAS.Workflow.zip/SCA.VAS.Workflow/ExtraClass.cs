﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace SCA.VAS.Workflow
{
    [Serializable]
    public class Extra
    {
        #region Private Member
        private string _name;
        private string _value;
        private string _longValue;
        private string _isDate;
        private string _isNum;
        private string _isFlag;
        private string _likeOpr;
        private string _column;
        private string _Identifier;
        private string _filterName;
        #endregion Private Membe
        #region Public Property
        [XmlAttribute]
        public string Name
        {
            get { return this._name; }
            set { this._name = value; }
        }
        [XmlAttribute]
        public string Value
        {
            get { return this._value; }
            set { this._value = value; }
        }

        [XmlIgnore]
        public string LongValue
        {
            get { return this._longValue; }
            set { this._longValue = value; }
        }

        [XmlIgnore]
        public string FilterName
        {
            get { return this._filterName; }
            set { this._filterName = value; }
        }
        //Either 1 or 0
        [XmlAttribute]
        public string IsNum
        {
            get { return this._isNum; }
            set { this._isNum = value; }
        }

        //Either 1 or 0
        [XmlAttribute]
        public string IsFlag
        {
            get { return this._isFlag; }
            set { this._isFlag = value; }
        }

        //Either 1 or 0
        [XmlAttribute]
        public string IsDate
        {
            get { return this._isDate; }
            set { this._isDate = value; }
        }

        //Either 1 or 0
        [XmlAttribute]
        public string LikeOpr 
        {
            get { return this._likeOpr; }
            set { this._likeOpr = value; }
        }
        [XmlAttribute]
        public string Column
        {
            get { return this._column; }
            set { this._column = value; }
        }
        [XmlAttribute]
        public string Identifier
        {
            get { return this._Identifier; }
            set { this._Identifier = value; }
        }
        #endregion Public Property
    }
}
