﻿namespace EVO.TimeSheetTracker.Job.Config
{
    public class ServiceOption
    {
        public string ServiceUrl { get; set; }

        public string MailFrom { get; set; }

        public string ApplicationName { get; set; }

        public string UserServiceUrl { get; set; }

        public string UserManagerServiceUrl { get; set; }

        /// <summary>
        /// MailTo will be defined in config. 
        /// It will override all MailTo email address if presented (for testing purpose)
        /// </summary>
        public string MailTo { get; set; }

    }
}
