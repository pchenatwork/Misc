﻿using EVO.TimeSheetTracker.Job.Jobs;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using SilkierQuartz;

namespace EVO.TimeSheetTracker.Job
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddRazorPages();
            services.AddSilkierQuartz((cfg) =>
            {
                cfg["quartz.plugin.recentHistory.type"] = "Quartz.Plugins.RecentHistory.ExecutionHistoryPlugin, Quartz.Plugins.RecentHistory";
                cfg["quartz.plugin.recentHistory.storeType"] = "Quartz.Plugins.RecentHistory.Impl.InProcExecutionHistoryStore, Quartz.Plugins.RecentHistory";
            }
                );
            services.AddOptions();
            services.AddQuartzJob<ProjectManagerRemindJob>("ProjectManagerRemindJob");
            //services.AddQuartzJob<ProjectApprovedRemindJob>("ProjectApprovedRemindJob");
            //services.AddQuartzJob<ProjectRejectedRemindJob>("ProjectRejectedRemindJob");
            services.AddQuartzJob<TimesheetResourceRemindJob>("TimesheetResourceRemindJob");
            services.AddQuartzJob<TimesheetManagerRemindJob>("TimesheetManagerRemindJob");
            //services.AddQuartzJob<SendMailJob>("SendMailJob");
            services.AddQuartzJob<TimesheetPeriodJob>("TimesheetPeriodJob");
            services.AddSingleton(Log.Logger);
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseStaticFiles();
            app.UseRouting();
            app.UseSilkierQuartz(new SilkierQuartzOptions()
            {
                VirtualPathRoot = "/Quartz",
                UseLocalTime = true,
                DefaultDateFormat = "yyyy-MM-dd",
                DefaultTimeFormat = "HH:mm:ss"
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();
            });

            if (env.IsDevelopment())
            {
                app.SchedulerDevJobs();
            }
            else
            {
                app.SchedulerJobs();
            }
        }
    }
}