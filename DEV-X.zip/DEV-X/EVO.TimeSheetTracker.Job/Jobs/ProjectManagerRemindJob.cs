﻿using EVO.TimeSheetTracker.Job.Config;
using EVOUserManagement;
using Microsoft.Extensions.Options;
using Quartz;
using Serilog;
using System.Linq;
using System.Threading.Tasks;
using TimeSheetTrackerService;

namespace EVO.TimeSheetTracker.Job.Jobs
{
    [DisallowConcurrentExecution, PersistJobDataAfterExecution]
    /// <summary>
    ///  4.3.2 The Timesheet Portal will send a reminder email to managers (level 2) to update the project list on the 14th day of each month. The updated project list will be due by EOD (11:59:59 pm EST) on the 20th day of each month
    /// </summary>
    public class ProjectManagerRemindJob : EmailJobBase
    {
        protected EVOUserManagementClient _evoUserManagerClient;
        protected override string EmailTemplateName { get; set; } = "ProjectSubmission";
        public ProjectManagerRemindJob( EVOUserManagementClient evoUserManagerClient, ITimeSheetTracker timeSheetClient, IOptionsSnapshot<ServiceOption> serviceOption, ILogger logger)
            : base(timeSheetClient, serviceOption, logger.ForContext<ProjectManagerRemindJob>())
        {
            _evoUserManagerClient = evoUserManagerClient;
        }

        protected override async Task<JobResult> Run(IJobExecutionContext context)
        {
            var entitys = await _timeSheetClient.GetTeamsAsync(new TeamEntity() { IsAdmin = true });

            if (entitys.Length < 1)
            {
                return JobResult.Success;
            }
            var applicationList = await _evoUserManagerClient.GetApplicationsAsync();
            if (applicationList == null || applicationList.GetApplicationsResult.Length < 1)
            {
                return JobResult.Success;
            }
            var applicationData = applicationList.GetApplicationsResult.First(a => a.ApplicationName == _serviceOption.ApplicationName);
            if (applicationData == null)
            {
                return JobResult.Success;
            }
            var permissionUser = await _evoUserManagerClient.GetUserByPermissionAsync(applicationData.ApplicationID, "Project_submit");
            if (permissionUser == null || permissionUser.GetUserByPermissionResult.Length < 1)
            {
                return JobResult.Success;
            }
            var userList = permissionUser.GetUserByPermissionResult.Where(u => u.Roles.RoleName != "ITExecutive");
            //var teamEntities = entitys.Where(o => o.Manager2 != null && o.Manager2.EmailAlert.HasValue && o.Manager2.EmailAlert.Value);

            var mangagerEamils = userList.Select(o => o.Email).Distinct();

            if (mangagerEamils != null && mangagerEamils.Count() > 0)
            {
                var subject = EmailTemplate != null ? EmailTemplate.EmailSubject : "Project Sumbit reminder";
                var body = EmailTemplate != null ? EmailTemplate.EmailContent : "The updated project list will be due, please updated!";
                var mailEntity = new MailEntity()
                {
                    From = _serviceOption.MailFrom,
                    To = string.Join(";", mangagerEamils),
                    Subject = subject,
                    Body = body
                };
                var result = SendEmail(mailEntity);
            }
            return JobResult.Success;
        }
    }
}