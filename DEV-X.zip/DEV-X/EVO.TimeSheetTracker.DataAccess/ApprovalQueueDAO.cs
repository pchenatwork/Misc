﻿using EVO.Common.UtilityCore;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace EVO.TimeSheetTracker.DataAccess
{
    public class ApprovalQueueDAO : TimeSheetTrackerDAO
    {
        public ApprovalQueueEntity GetApprovalQueueByID(int requestID)
        {
            try
            {
                var listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@RequestID", requestID)
                };

                var xml = new ApprovalQueueDAO().RunProcedureXmlString("SPU_Get_ApprovalByID", listSqlParameter);
                var res = SerializeObject<List<ApprovalQueueEntity>>.FromXml(xml);
                return res.FirstOrDefault();
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<ApprovalQueueEntity> GetApprovals(int referenceID,int requstTypeID)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>() {
                     new SqlParameter("@ReferenceID", referenceID),
                     new SqlParameter("@RequstTypeID", requstTypeID)
                };

                var xml = new ApprovalQueueDAO().RunProcedureXmlString("SPU_Get_Approval", listSqlParameter);
                var res = SerializeObject<List<ApprovalQueueEntity>>.FromXml(xml);
                return res;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }
    }
}