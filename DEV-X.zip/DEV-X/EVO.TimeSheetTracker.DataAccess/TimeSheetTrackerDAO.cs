﻿using EVO.Components2;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Configuration;

namespace EVO.TimeSheetTracker.DataAccess
{
    public abstract class TimeSheetTrackerDAO : DAO
    {
        internal override string DataBaseConnectionString()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["TimeSheetTracker"].ToString();
            return EncDec.EVODecrypt(connectionString);
        }

        internal void LogError(Exception ex)
        {
            new ApplicationLog().LogError(new ApplicationLogEntity
            {
                StackTrace = ex.StackTrace,
                UserName = "ServerException",
                Message = ex.Message,
                Date = DateTime.Now,
                Browser = "",
                MachineName = Environment.MachineName,
                OperatingSystem = Environment.OSVersion.ToString()
            });
        }
    }
}