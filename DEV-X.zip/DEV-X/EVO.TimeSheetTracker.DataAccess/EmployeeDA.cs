﻿using EVO.Common.UtilityCore;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace EVO.TimeSheetTracker.DataAccess
{
    public class EmployeeDA : TimeSheetTrackerDAO
    {
        public List<EmployeeEntity> GetEmployees(EmployeeEntity entity)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@UserID",entity.UserID),
                    new SqlParameter("@ID",entity.EmployeeID),
                    new SqlParameter("@RoleName",entity.RoleName),
                    new SqlParameter("@EmployeeName",entity.EmployeeName),
                    new SqlParameter("@OwnerID",entity.TeamOwnerID)
                };
                var xml = new EmployeeDA().RunProcedureXmlString("SPU_Get_Employees", listSqlParameter);
                var res = SerializeObject<List<EmployeeEntity>>.FromXml(xml);
                return res;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }


        public List<EmployeeEntity> GetEmployeesByRoleNames(IList<string> roleNameList)
        {
            try
            {
                var roleNames = roleNameList == null ? string.Empty : string.Join("|", roleNameList);
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@RoleNames",roleNames)                  
                };
                var xml = new EmployeeDA().RunProcedureXmlString("SPU_Get_EmployeesByRoleNames", listSqlParameter);
                var res = SerializeObject<List<EmployeeEntity>>.FromXml(xml);
                return res;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public SaveResult Insert(List<EmployeeEntity> entitys)
        {
            var result = new SaveResult();
            try
            {

                // check employee whether already exists.
                var employeeEntity = GetEmployees(entitys[0]);
                if(employeeEntity != null  && employeeEntity.Count > 0)
                {
                    entitys[0].EmployeeID = employeeEntity[0].EmployeeID;
                    result = Update(entitys);
                }
                else
                {
                    List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@UserID",entitys[0].UserID),
                    new SqlParameter("@EmployeeName",entitys[0].EmployeeName),
                    new SqlParameter("@Title",entitys[0].Title),
                    new SqlParameter("@TeamID",entitys[0].TeamID),
                    new SqlParameter("@JobGrade",entitys[0].JobGrade),
                    new SqlParameter("@EmailAlert",entitys[0].EmailAlert),
                    new SqlParameter("@CountryID",entitys[0].CountryID),
                    new SqlParameter("@DepartmentID",entitys[0].DepartmentID),
                    new SqlParameter("@ManagerID",entitys[0].ManagerID),
                    new SqlParameter("@Email",entitys[0].Email),
                    new SqlParameter("@RoleName",entitys[0].RoleName),
                    new SqlParameter("@IsActive",entitys[0].IsActive),
                    new SqlParameter("@UpdateDate",entitys[0].UpdateDate),
                    new SqlParameter("@UpdateBy",entitys[0].UpdateBy)
                };
                    string retval = new EmployeeDA().RunProcedureXmlString("SPU_Insert_Employees", listSqlParameter);

                    if (int.TryParse(retval, out int count))
                    {
                        result.AssociatedObject = count;
                        result.Success = true;
                    }
                    else
                    {
                        result.Success = false;
                        result.ErrorDescription = retval;
                    }
                }
               
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }

            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Insert the Employees.";
            }
            return result;
        }

        public SaveResult Update(List<EmployeeEntity> entitys)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID",entitys[0].EmployeeID),
                    new SqlParameter("@UserID",entitys[0].UserID),
                    new SqlParameter("@EmployeeName",entitys[0].EmployeeName),
                    new SqlParameter("@Title",entitys[0].Title),
                    new SqlParameter("@TeamID",entitys[0].TeamID),
                    new SqlParameter("@JobGrade",entitys[0].JobGrade),
                    new SqlParameter("@EmailAlert",entitys[0].EmailAlert),
                    new SqlParameter("@CountryID",entitys[0].CountryID),
                    new SqlParameter("@DepartmentID",entitys[0].DepartmentID),
                    new SqlParameter("@ManagerID",entitys[0].ManagerID),
                    new SqlParameter("@Email",entitys[0].Email),
                    new SqlParameter("@RoleName",entitys[0].RoleName),
                    new SqlParameter("@IsActive",entitys[0].IsActive),
                    new SqlParameter("@UpdateDate",entitys[0].UpdateDate),
                    new SqlParameter("@UpdateBy",entitys[0].UpdateBy)
                };
                string retval = new EmployeeDA().SqlExecuteNonQuery("SPU_Update_Employees", 180, listSqlParameter);

                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }

            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Update the Employees.";
            }
            return result;
        }

        public bool DeactiveTeamCheck(int ID)
        {
            List<SqlParameter> listSqlParameter = new List<SqlParameter>
            {
                new SqlParameter("@ID", ID)
            };
            var retval = new EmployeeDA().RunProcedureXmlString("SPU_Team_DeactiveCheck", listSqlParameter);
            return retval.Length > 0;
        }

        public SaveResult SyncEmployee(EmployeeEntity entity)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID",entity.EmployeeID),
                    new SqlParameter("@UserID",entity.UserID),
                    new SqlParameter("@EmployeeName",entity.EmployeeName),                 
                    new SqlParameter("@RoleName",entity.RoleName)
                };
                string retval = new EmployeeDA().SqlExecuteNonQuery("SPU_Sync_Employee", 180, listSqlParameter);

                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }

            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to sync the Employee.";
            }
            return result;
        }

        public SaveResult Delete(EmployeeEntity entity)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID",entity.EmployeeID),
                };
                string retval = new TeamDA().SqlExecuteNonQuery("SPU_Delete_Employee", 180, listSqlParameter);

                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }

            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Delete the Employee.";
            }
            return result;
        }
    }
}