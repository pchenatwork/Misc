﻿using EVO.Common.UtilityCore;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace EVO.TimeSheetTracker.DataAccess
{
    public class ApplicationLog : TimeSheetTrackerDAO
    {
        public SaveResult LogError(ApplicationLogEntity log)
        {
            var result = new SaveResult();

            try
            {
                var parameters = new List<SqlParameter>
                {
                    new SqlParameter("@Message", log.Message),
                    new SqlParameter("@StackTrace", log.StackTrace),
                    new SqlParameter("@UserName", log.UserName),
                    new SqlParameter("@OperatingSystem", log.OperatingSystem),
                    new SqlParameter("@Browser", log.Browser),
                    new SqlParameter("@MachineName", log.MachineName),
                    new SqlParameter("@Date", log.Date)
                };

                var retval = new ApplicationLog().SqlExecuteNonQuery("SPU_Update_ApplicationLog", 0, parameters);

                int count;

                if (int.TryParse(retval, out count))
                {
                    result.Success = true;

                    result.ErrorDescription = $"{0} Application Log updated successfully!";
                }
                else
                {
                    result.Success = false;

                    result.ErrorDescription = "Application Log update failed!";
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;

                result.ErrorDescription = ex.Message;
            }

            return result;
        }

        public List<ApplicationLogEntity> GetApplicationLogs(ApplicationLogEntity entity)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>();
                var xml = new ApplicationLog().RunProcedureXmlString("SPU_Get_ApplicationLog", listSqlParameter);
                var res = SerializeObject<List<ApplicationLogEntity>>.FromXml(xml);
                return res;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }
    }
}