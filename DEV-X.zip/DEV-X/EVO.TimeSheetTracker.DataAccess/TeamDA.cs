﻿using EVO.Common.UtilityCore;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace EVO.TimeSheetTracker.DataAccess
{
    public class TeamDA : TimeSheetTrackerDAO
    {
        public bool CheckTeamName(string name)
        {
            List<SqlParameter> listSqlParameter = new List<SqlParameter>
            {
                new SqlParameter("@teamName", name)
            };
            var retval = new TeamDA().RunProcedureXmlString("SPU_Team_CheckName", listSqlParameter);
            return retval.Length > 0;
        }

        public List<TeamEntity> GetTeamProjectReminderData(TimeSheetQueryEntity entity)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@StartDate",entity.StartDate),
                    new SqlParameter("@EndDate",entity.EndDate),
                    new SqlParameter("@IsAdmin",entity.IsAdmin),
                    new SqlParameter("@StatusIDs",entity.StatusID.CopyToDataTable())
                };
                var xml = new TeamDA().RunProcedureXmlString("SPU_Get_TeamProjectReminderData", listSqlParameter);
                return SerializeObject<List<TeamEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<TeamEntity> GetTeams(TeamEntity entity)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>();

                if (entity.Owner != null)
                {
                    listSqlParameter.Add(new SqlParameter("@OwnerID", entity.Owner.EmployeeID));
                    listSqlParameter.Add(new SqlParameter("@IsAdmin", entity.IsAdmin));
                    listSqlParameter.Add(new SqlParameter("@ID", entity.TeamID));
                }

                var xml = new TeamDA().RunProcedureXmlString("SPU_Get_Team", listSqlParameter);
                var res = SerializeObject<List<TeamEntity>>.FromXml(xml);
                return res;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public SaveResult Insert(List<TeamEntity> entitys)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@Name",entitys[0].Name),
                    new SqlParameter("@Manager1",entitys[0].Manager1.EmployeeID),
                    new SqlParameter("@Manager2",entitys[0].Manager2.EmployeeID),
                    new SqlParameter("@Owner",entitys[0].Owner.EmployeeID),
                    new SqlParameter("@IsActive",entitys[0].IsActive),
                    new SqlParameter("@UpdateDate",entitys[0].UpdateDate),
                    new SqlParameter("@UpdateBy",entitys[0].UpdateBy)
                };
                string retval = new TeamDA().RunProcedureXmlString("SPU_Insert_Team", listSqlParameter);

                if (int.TryParse(retval, out int count))
                {
                    result.AssociatedObject = count;
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Insert the team.";
            }
            return result;
        }

        public SaveResult Update(TeamEntity entity)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID",entity.TeamID),
                    new SqlParameter("@Name",entity.Name),
                   new SqlParameter("@Manager1",entity.Manager1.EmployeeID),
                    new SqlParameter("@Manager2",entity.Manager2.EmployeeID),
                    new SqlParameter("@Owner",entity.Owner.EmployeeID),
                    new SqlParameter("@IsActive",entity.IsActive),
                    new SqlParameter("@UpdateDate",entity.UpdateDate),
                    new SqlParameter("@UpdateBy",entity.UpdateBy)
                };
                string retval = new TeamDA().SqlExecuteNonQuery("SPU_Update_Team", 180, listSqlParameter, false);

                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }

            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to update the Team.";
            }

            return result;
        }

        public SaveResult Delete(TeamEntity entity)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID",entity.TeamID),
                };
                string retval = new TeamDA().SqlExecuteNonQuery("SPU_Delete_Team", 180, listSqlParameter);

                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Delete the Team.";
            }
            return result;
        }
    }
}