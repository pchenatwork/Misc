﻿using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace EVO.TimeSheetTracker.DataAccess
{
    public class CacheDA : TimeSheetTrackerDAO
    {
        public byte[] GetCache(string key)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID",key),
                    new SqlParameter("@UtcNow", DateTimeOffset.UtcNow)
                };
                var data = new CacheDA().RunProcedureScaler("SPU_Get_Cache", listSqlParameter);
                return (byte[])data;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public void RefreshCache(string key)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID",key),
                    new SqlParameter("@UtcNow", DateTimeOffset.UtcNow),
                    new SqlParameter("@IsReturnValue", false)
                };
                new CacheDA().SqlExecuteNonQuery("SPU_Get_Cache", 0, listSqlParameter);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public SaveResult SetCache(string key, byte[] data, long expirationInSeconds, DateTimeOffset? absoluteExpiration)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID",key),
                    new SqlParameter("@Data", data),
                    new SqlParameter("@UtcNow", DateTimeOffset.UtcNow),
                    new SqlParameter("@SlidingExpirationInSeconds", expirationInSeconds)
                };
                if (absoluteExpiration.HasValue)
                {
                    listSqlParameter.Add(new SqlParameter("@AbsoluteExpiration", absoluteExpiration.Value));
                }
                var retval = new CacheDA().SqlExecuteNonQuery("SPU_Update_Cache", 0, listSqlParameter);

                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            return result;
        }

        public SaveResult RemoveCache(string key)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID",key)
                };
                var retval = new CacheDA().SqlExecuteNonQuery("SPU_Delete_Cache", 0, listSqlParameter);

                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            return result;
        }

        public SaveResult RemoveExpiredCache(DateTimeOffset? utcNow)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>();
                var utcParam = utcNow.HasValue ? utcNow.Value : DateTimeOffset.UtcNow;
                listSqlParameter.Add(new SqlParameter("@UtcNow", utcParam));

                var retval = new CacheDA().SqlExecuteNonQuery("SPU_Delete_ExpiredCache", 0, listSqlParameter);

                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            return result;
        }
    }
}