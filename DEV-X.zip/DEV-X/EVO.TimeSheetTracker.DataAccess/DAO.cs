﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Xml;


namespace EVO.TimeSheetTracker.DataAccess
{
    public abstract class DAO
    {

        /*
            * NOTE: All methods that will reference this connection string muste be INSTANCES not static
            * as the underlying object will override with the appropriate connection string
            */
        //public static readonly string DAOConnectionString = "";

        internal abstract string DataBaseConnectionString();
       
        /// <summary>
        /// serializes using binary formatter... 
        /// </summary>
        /// <returns></returns>
        public byte[] Serialize()
        {
            using (MemoryStream ms = new MemoryStream())
            {
                new BinaryFormatter().Serialize(ms, this);
                return ms.ToArray();
            }
        }

        /// <summary>
        /// deserializes using binaryformatter (not xml!)
        /// </summary>
        /// <param name="daoContents"></param>
        /// <returns></returns>
        public static DAO DeSerialize(byte[] daoContents)
        {
            using (MemoryStream ms = new MemoryStream(daoContents))
            {
                return (DAO)new BinaryFormatter().Deserialize(ms);
            }
        }

        /// <summary>
        /// ADOs the sucks conversion. (this came out of ghost doc and I am leaving it)
        /// </summary>
        /// <param name="o">The o.</param>
        /// <returns></returns>
        protected object ADOSucksConversion(object o)
        {
            if (o == null) return DBNull.Value;
            else return o;
        }
        /// <summary>
        /// Determines the is db null or value.
        ///         
        ///The following reccomended by Ruslan, as this method differs the prior method in that there is no implicit conversion from whatever type to object type. (to be confirmed)
        ///I am not using this as i have already used the prior method but keeping it for future reference...
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="command">The command.</param>
        /// <param name="val">The val.</param>
        /// <param name="name">The name.</param>
        protected void DetermineIsDbNullOrValue<T>(ref SqlCommand command, T val, string name)
        {
            if (val == null) command.Parameters.AddWithValue(name, DBNull.Value);
            else command.Parameters.AddWithValue(name, val);
        }


        /// <summary>
        ///Executes the stored procedure and returns a dataset
        /// </summary>
        /// <param name="Procedure">The procedure.</param>
        /// <returns></returns>
        protected DataSet RunProcedureDataSet(string Procedure)
        {
            return RunProcedureDataSet(Procedure, null);
        }
        /// <summary>
        /// Executes the stored procedure and returns a dataset
        /// </summary>
        /// <param name="Procedure">The procedure.</param>
        /// <param name="Parameters">The parameters.</param>
        /// <returns></returns>
        protected DataSet RunProcedureDataSet(string Procedure, List<SqlParameter> Parameters)
        {
            return RunProcedureDataSet(Procedure, DataBaseConnectionString(), Parameters);
        }

        protected DataSet RunProcedureDataSet(string Procedure, List<SqlParameter> Parameters, int CommandTimeOut)
        {
            return RunProcedureDataSet(Procedure, DataBaseConnectionString(), Parameters, CommandTimeOut);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Security", "CA2100:Review SQL queries for security vulnerabilities", Justification = "<Pending>")]
        protected DataSet RunProcedureDataSet(string Procedure, string connectionString, List<SqlParameter> Parameters, int CommandTimeOut = 300)
        {

            SqlConnection MyConnection = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand();

            cmd.Connection = MyConnection;
            cmd.CommandText = Procedure;
            cmd.CommandType = CommandType.StoredProcedure;
            if (Parameters != null) cmd.Parameters.AddRange(Parameters.ToArray());

            SqlDataAdapter da = new SqlDataAdapter();
            DataSet ds = new DataSet();

            da.SelectCommand = cmd;
            cmd.CommandTimeout = CommandTimeOut;
            try
            {
                MyConnection.Open();
                //    cmd.Transaction = MyConnection.BeginTransaction(IsolationLevel.ReadUncommitted);
                da.Fill(ds);
                //     cmd.Transaction.Commit();
            }
            catch (Exception e)
            {
                //     cmd.Transaction.Commit();
                //EvoEventLog eel=new EvoEventLog();
                //eel.LogError(e.ToString());
                throw e;
            }
            finally
            {
                MyConnection.Close();
            }
            return ds;
        }

        protected DataSet RunStatementDataSet(string statement)
        {
            return RunStatementDataSet(statement, null);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Security", "CA2100:Review SQL queries for security vulnerabilities", Justification = "<Pending>")]
        protected DataSet RunStatementDataSet(string statement, List<SqlParameter> Parameters)
        {
            SqlConnection MyConnection = new SqlConnection(DataBaseConnectionString());
            // SqlTransaction tx = MyConnection.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = MyConnection;
            //cmd.Transaction = tx;
            cmd.CommandText = statement;

            if (Parameters != null) cmd.Parameters.AddRange(Parameters.ToArray());

            SqlDataAdapter da = new SqlDataAdapter();
            DataSet ds = new DataSet();

            da.SelectCommand = cmd;
            cmd.CommandTimeout = 60;
            try
            {
                MyConnection.Open();
                da.Fill(ds);
                //  tx.Commit();
            }
            catch (Exception e)
            {
                //EvoEventLog eel=new EvoEventLog();
                //eel.LogError(e.ToString());
                throw e;
            }
            finally
            {
                MyConnection.Close();
            }
            return ds;
        }


        /// <summary>
        /// Executes the stored procedure and returns an XML Element
        /// </summary>
        /// <param name="Procedure">The procedure.</param>
        /// <returns></returns>
        protected XmlElement RunProcedureXmlElement(string Procedure)
        {
            return RunProcedureXmlElement(Procedure, null);
        }
        /// <summary>
        /// Executes the stored procedure and returns an XML Element
        /// </summary>
        /// <param name="Procedure">The procedure.</param>
        /// <param name="Parameters">The parameters.</param>
        /// <returns></returns>
        protected XmlElement RunProcedureXmlElement(string Procedure, List<SqlParameter> Parameters)
        {
            DataSet ds = RunProcedureDataSet(Procedure, Parameters);
            XmlDocument xmlDoc = new XmlDocument();
            StringBuilder strXML = new StringBuilder();
            foreach (DataTable dt in ds.Tables)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    strXML.Append(dr[0]); // Do I still need .ToString()???
                }
            }
            if (strXML.Length == 0) return null; //strXML.Append("<root total=\"0\"></root>"); Changed by anubhav Shah since we have agreed to return null when no values found in db... 
            try
            {

                MemoryStream stream = new MemoryStream(Encoding.Default.GetBytes(strXML.ToString()));
                XmlReaderSettings settings = new XmlReaderSettings();
                settings.DtdProcessing = DtdProcessing.Prohibit;

                XmlReader reader = XmlReader.Create(stream, settings);
                xmlDoc.Load(reader);

                //xmlDoc.LoadXml(strXML.ToString());
            }
            catch (XmlException e)
            {
                throw e;
            }

            return xmlDoc.DocumentElement;
        }
        /// <summary>
        /// Executes the stored procedure and returns an XML string
        /// </summary>
        /// <param name="Procedure">The procedure.</param>
        /// <returns></returns>
        protected string RunProcedureXmlString(string Procedure)
        {
            return RunProcedureXmlString(Procedure, null);
        }

        /// <summary>
        /// Executes the stored procedure and returns an XML String
        /// </summary>
        /// <param name="Procedure">The procedure.</param>
        /// <param name="Parameters">The parameters.</param>
        /// <returns></returns>
        protected string RunProcedureXmlString(string Procedure, List<SqlParameter> Parameters)
        {
            DataSet ds = RunProcedureDataSet(Procedure, Parameters);
            StringBuilder strXML = new StringBuilder();
            foreach (DataTable dt in ds.Tables)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    strXML.Append(dr[0]);
                }
            }
            return strXML.ToString();
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Security", "CA2100:Review SQL queries for security vulnerabilities", Justification = "<Pending>")]
        protected object RunProcedureScaler(string Procedure, List<SqlParameter> Parameters)
        {
            //DataSet ds = RunProcedureDataSet(Procedure, Parameters);
            SqlConnection MyConnection = new SqlConnection(DataBaseConnectionString());
            MyConnection.Open();
            SqlCommand cmd = new SqlCommand(Procedure, MyConnection);
            cmd.CommandTimeout = 99999999;
            cmd.CommandType = CommandType.StoredProcedure;
            object ret = null;

            if (Parameters != null) cmd.Parameters.AddRange(Parameters.ToArray());

            try
            {
                // TODO: might need to execute reader and append byte array?
                ret = cmd.ExecuteScalar();
            }
            catch (SqlException e)
            {
                throw e;

            }
            finally
            {
                MyConnection.Close();
            }
            return ret;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Security", "CA2100:Review SQL queries for security vulnerabilities", Justification = "<Pending>")]
        protected string RunProcedureXmlString_Frank(string Procedure, List<SqlParameter> Parameters)
        {
            //DataSet ds = RunProcedureDataSet(Procedure, Parameters);
            SqlConnection MyConnection = new SqlConnection(DataBaseConnectionString());
            //SqlTransaction tx = MyConnection.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted);
            MyConnection.Open();
            SqlCommand cmd = new SqlCommand(Procedure, MyConnection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 99999999;

            if (Parameters != null) cmd.Parameters.AddRange(Parameters.ToArray());
            SqlDataReader dr = null;
            StringBuilder strXML = new StringBuilder();

            // TODO: put in try catch!
            try
            {
                DateTime dt = DateTime.Now;
                dr = cmd.ExecuteReader();
                DateTime dt2 = DateTime.Now;
                TimeSpan ts = dt2 - dt;
                while (dr.Read())
                {
                    strXML.Append(dr[0].ToString());
                }
                DateTime dt3 = DateTime.Now;
                TimeSpan ts2 = dt3 - dt2;
            }
            catch (SqlException e)
            {
                throw e;

            }
            finally
            {
                dr.Close();
                MyConnection.Close();
            }
            return strXML.ToString();
        }

        /// <summary>
        /// Executes the stored procedure and returns a datatable
        /// </summary> 
        /// <param name="Procedure">The procedure.</param>
        /// <param name="Parameters">The parameters.</param>
        /// <returns></returns>
        protected DataTable RunProcedureDataTable(string Procedure, List<SqlParameter> Parameters)
        {
            DataSet ds = RunProcedureDataSet(Procedure, Parameters);
            DataTable dt = (ds.Tables.Count > 0) ? ds.Tables[0] : null;
            return dt; //Returns MessageID...

        }


        #region Sql Execute Non Query return the string value
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Security", "CA2100:Review SQL queries for security vulnerabilities", Justification = "<Pending>")]
        public string SqlExecuteNonQuery(string spName, int iCommandTimeOut, IList<SqlParameter> sqlSPParamsList)
        {
            string retVal = "";

            using (SqlConnection sqlConnection = new SqlConnection(DataBaseConnectionString()))
            {
                // Open connection if not yet
                if (sqlConnection.State != ConnectionState.Open)
                {
                    sqlConnection.Open();
                }
                SqlCommand sqlCommand = new SqlCommand(spName, sqlConnection);
                {
                    try
                    {
                        // sqlCommand.Parameters.AddWithValue("@xx", xx);
                        // Set SQL input parameter(s)
                        for (int ix = 0; ix < sqlSPParamsList.Count; ix++)
                        {
                            sqlCommand.Parameters.Add(sqlSPParamsList[ix]);
                        }
                        #region set command type only (text or  StoredProcedure)
                        sqlCommand.CommandType = string.IsNullOrEmpty(spName) ? CommandType.Text : CommandType.StoredProcedure;
                        #endregion
                        #region set Command Time out (note if pass in time out is less than 60 default it to 60 (standard time out)
                        sqlCommand.CommandTimeout = (iCommandTimeOut < 60) ? 60 : iCommandTimeOut;
                        #endregion
                        Object objRetVal = sqlCommand.ExecuteNonQuery();
                        retVal = (objRetVal == null) ? "0" : Convert.ToString(objRetVal);
                    }
                    catch (System.Exception ex)
                    {
                        retVal = string.Format("Unable to process in 'SqlExecuteNonQuery' using spName: {0} and error message was {1}\n.", spName, ex.Message);
                    }
                }
            }
            return retVal;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Security", "CA2100:Review SQL queries for security vulnerabilities", Justification = "<Pending>")]
        public string SqlExecuteNonQuery(string spName, int iCommandTimeOut, IList<SqlParameter> sqlSPParamsList, bool customMessage)
        {
            string retVal = "";

            using (SqlConnection sqlConnection = new SqlConnection(DataBaseConnectionString()))
            {
                // Open connection if not yet
                if (sqlConnection.State != ConnectionState.Open)
                {
                    sqlConnection.Open();
                }
                SqlCommand sqlCommand = new SqlCommand(spName, sqlConnection);
                {
                    try
                    {
                        // sqlCommand.Parameters.AddWithValue("@xx", xx);
                        // Set SQL input parameter(s)
                        for (int ix = 0; ix < sqlSPParamsList.Count; ix++)
                        {
                            sqlCommand.Parameters.Add(sqlSPParamsList[ix]);
                        }
                        #region set command type only (text or  StoredProcedure)
                        sqlCommand.CommandType = string.IsNullOrEmpty(spName) ? CommandType.Text : CommandType.StoredProcedure;
                        #endregion
                        #region set Command Time out (note if pass in time out is less than 60 default it to 60 (standard time out)
                        sqlCommand.CommandTimeout = (iCommandTimeOut < 60) ? 60 : iCommandTimeOut;
                        #endregion
                        Object objRetVal = sqlCommand.ExecuteNonQuery();
                        retVal = (objRetVal == null) ? "0" : Convert.ToString(objRetVal);
                    }
                    catch (System.Exception ex)
                    {
                        if (customMessage)
                            retVal = string.Format("Unable to process in 'SqlExecuteNonQuery' using spName: {0} and error message was {1}\n.", spName, ex.Message);
                        else
                        {
                            retVal = ex.Message.ToString();
                        }
                    }
                }
            }
            return retVal;
        }
        #endregion


    }
}
