﻿using System;
using System.Xml;
using System.Collections.Generic;
using System.Text;
using FrameworkBase.Interface;
using FrameworkBase.DataAccess;
using EVO.TimeSheetTracker.Entity;
using Microsoft.Data.SqlClient;

namespace EVO.TimeSheetTracker.DataAccess
{
    public class ProjectE_DAO : AbstractDAO<Entity.ProjectE_>
    {
        #region constants
        private const string CLASSNAME = nameof(ProjectE_DAO);
        public const string FIND_BY_TOKENS= "GetProjects";
        #endregion
        /** PCHEN XXXXX Marked **/

        #region	Constructors
        private ProjectE_DAO()
        {
        }
        #endregion constructors
        public override IEnumerable<ProjectE_> FindByCriteria(IDbSession dbSession, string finderType, params object[] criteria)
        {
            try
            {
                switch (finderType)
                {
                    case FIND_BY_TOKENS:
                        {
                            DateTime startDate = new DateTime(1900,1,1); // (DateTime)criteria[0];
                            DateTime endDate = new DateTime(2222,1,1); // (DateTime)criteria[1];

                            List<SqlParameter> listSqlParameter = new List<SqlParameter>
                            {
                                new SqlParameter("@StartDate",startDate),
                                new SqlParameter("@EndDate",endDate),
                                new SqlParameter("@Teams", null),
                                new SqlParameter("@IsAdmin", false),
                                new SqlParameter("@IsActive", true),
                                new SqlParameter("@CreateBy", string.Empty)
                            };
                            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Get_Project_X_PCHEN", listSqlParameter);
                            return DeserializeCollection(reader);
                        }
                    default:
                        return null;

                }
            }
            catch (Exception ex)
            {
                //LogError(ex);
                throw new Exception("Server side error");
            }
        }
    }
}
