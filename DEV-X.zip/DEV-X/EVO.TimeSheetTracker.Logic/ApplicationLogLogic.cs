﻿using EVO.TimeSheetTracker.DataAccess;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Logic
{
   public class ApplicationLogLogic
    {
        public SaveResult LogError(ApplicationLogEntity log)
        {
            return new ApplicationLog().LogError(log);
        }

        public List<ApplicationLogEntity> GetApplicationLogs(ApplicationLogEntity entity)
        {
            return new ApplicationLog().GetApplicationLogs(entity);
        }




    }
}
