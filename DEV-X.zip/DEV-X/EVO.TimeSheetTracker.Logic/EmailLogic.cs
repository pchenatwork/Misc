﻿using EVO.TimeSheetTracker.DataAccess;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Logic
{
   public   class EmailLogic
    {

        public List<EmailEntity> GetPendingEmailList(DateTime sendDate)
        {
            return new EmailDA().GetPendingEmailList(sendDate);
        }

        public SaveResult InsertEmailList(List<EmailRequestEntity> mailList)
        {
            return new EmailDA().InsertEmailList(mailList);
        }

        public SaveResult UpdateEmailList(List<int> emailIDs)
        {
            return new EmailDA().UpdateEmailList(emailIDs);
        }
    }
}
