﻿using DocumentFormat.OpenXml.Math;
using EVO.TimeSheetTracker.DataAccess;
using EVO.TimeSheetTracker.Entity;
using System.Collections.Generic;

namespace EVO.TimeSheetTracker.Logic
{
    public class TimeSheetLogic
    {
        public List<TimeSheetEntity> GetTimeSheet(TimeSheetQueryEntity entity)
        {
            return new TimeSheetDA().GetTimeSheet(entity);
        }

        public List<TimeSheetEntity> GetTimeSheetSummary(TimeSheetQueryEntity entity)
        {
            return new TimeSheetDA().GetTimeSheetSummary(entity);
        }

        public SaveResult DeleteImportTimeSheet(string userName)
        {
            return new TimeSheetDA().DeleteImportTimeSheet(userName);
        }
        public SaveResult InsertTimeSheetBatch(List<TimeSheetEntity> entitys, string userName)
        {
            return new TimeSheetDA().InsertTimeSheetBatch(entitys,userName);
        }
        public SaveResult Insert(TimeSheetEntity entity)
        {
            return new TimeSheetDA().Insert(entity);
        }

        public SaveResult Update(TimeSheetEntity entity)
        {
            return new TimeSheetDA().Update(entity);
        }

        public SaveResult Delete(int ID)
        {
            return new TimeSheetDA().Delete(ID);
        }

        public SaveResult SubmitTimeSheets(List<int> projectIDs, string userID)
        {
            return new TimeSheetDA().SubmitTimeSheets(projectIDs, userID);
        }
        public List<TimeSheetApprovalQueueEntity> GetTimesheetApprovalList(TimeSheetQueryEntity entity)
        {
            return new TimeSheetDA().GetTimesheetApprovalList(entity);
        }

        public SaveResult RejectTimesheets(List<int> requestIDs, string userID)
        {
            return new TimeSheetDA().RejectTimesheets(requestIDs, userID);
        }

        public SaveResult ApprovalTimesheets(List<int> requestIDs, string userID)
        {
            return new TimeSheetDA().ApprovalTimesheets(requestIDs, userID);
        }

        public SaveResult UpdateTimesheetComment(TimeSheetApprovalQueueEntity entity)
        {
            return new TimeSheetDA().UpdateTimesheetComment(entity);
        }

        public List<EmployeeEntity> GetTeamOwnersOfSubmittedTimesheetUser(int period)
        {
            return new TimeSheetDA().GetTeamOwnersOfSubmittedTimesheetUser(period);
        }
    }
}
