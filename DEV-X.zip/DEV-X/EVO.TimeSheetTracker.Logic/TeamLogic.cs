﻿
using EVO.TimeSheetTracker.DataAccess;
using EVO.TimeSheetTracker.Entity;
using System.Collections.Generic;

namespace EVO.TimeSheetTracker.Logic
{
    public class TeamLogic
    {
        public bool CheckTeamName(string name)
        {
            return new TeamDA().CheckTeamName(name);
        }

        public List<TeamEntity> GetTeamProjectReminderData(TimeSheetQueryEntity entity)
        {
            return new TeamDA().GetTeamProjectReminderData(entity);
        }
        public List<TeamEntity> GetTeams(TeamEntity entity)
        {
            return new TeamDA().GetTeams(entity);
        }

        public SaveResult Insert(List<TeamEntity> entity)
        {
            return new TeamDA().Insert(entity);
        }

        public SaveResult Update(TeamEntity entity)
        {
            return new TeamDA().Update(entity);
        }

        public SaveResult Delete(TeamEntity entity)
        {
            return new TeamDA().Delete(entity);
        }
    }
}
