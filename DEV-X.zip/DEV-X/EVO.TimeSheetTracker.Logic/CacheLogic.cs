﻿using EVO.TimeSheetTracker.DataAccess;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Logic
{
  public  class CacheLogic
    {

        public byte[] GetCache(string key)
        {
            return new CacheDA().GetCache(key);
        }

        public void RefreshCache(string key)
        {
             new CacheDA().RefreshCache(key);
        }

        public SaveResult SetCache(string key, byte[] data, long expirationInSeconds, DateTimeOffset? absoluteExpiration)
        {
            return new CacheDA().SetCache(key, data, expirationInSeconds, absoluteExpiration);
        }




        public SaveResult RemoveCache(string key)
        {
            return new CacheDA().RemoveCache(key);
        }


        public SaveResult RemoveExpiredCache(DateTimeOffset? utcNow)
        {
            return new CacheDA().RemoveExpiredCache(utcNow);
        }
    }
}
