﻿#region Header Info

using FrameworkBase.Interface;
using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Xml;

/* ============================================================================
 * PCHEN 202110 Introduced
 * ============================================================================ */

#endregion

namespace FrameworkBase.DataAccess
{
    /// <summary>
    /// Abstract DAO that all xxxDAO class should be based on
    /// </summary>
    /// <typeparam name="T">IValueObject</typeparam>
    public abstract class AbstractDAO<T> : IDataAccessObject<T> where T : IValueObject 
    {
        #region constructor
        protected AbstractDAO()
        {
        }
        static AbstractDAO()
        {

        }
        #endregion constructor

        public virtual int Create(IDbSession dbSession, T newObject)
        {
            throw new NotImplementedException();
        }
        public virtual bool Update(IDbSession dbSession, T obj)
        {
            throw new NotImplementedException();
        }
        public virtual bool Delete(IDbSession dbSession, dynamic Id)
        {
            throw new NotImplementedException();
        }
        public virtual IEnumerable<T> FindByCriteria(IDbSession dbSession, string finderType, params object[] criteria)
        {
            throw new NotImplementedException();
        }
        public virtual T Get(IDbSession dbSession, dynamic id)
        {
            throw new NotImplementedException();
        }
        public virtual IEnumerable<T> GetAll(IDbSession dbSession)
        {
            throw new NotImplementedException();
        }
        public virtual object InvokeByMethodName(IDbSession dbSession, string methodName, params object[] parameters)
        {
            Type type = this.GetType();
            return type.InvokeMember(methodName, BindingFlags.DeclaredOnly |
                BindingFlags.Public | BindingFlags.Instance | BindingFlags.InvokeMethod,
                null, this, parameters);
        }
        /// <summary>
        /// Wrapper for executing  SqlCommand.ExecuteXmlReader() method, See MSDN for more details
        /// </summary>
        /// <param name="dbSession"></param>
        /// <param name="commandText"></param>
        /// <param name="parameters">parameters[0] = new SqlParameter("@ReturnValue", SqlDbType.Int);</param>
        /// <returns></returns>
        protected static XmlReader ExecuteXmlReader(IDbSession dbSession, string commandText, IEnumerable<SqlParameter> parameters)
        {
            XmlReader reader;
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = (SqlConnection)dbSession.DbConnection;
                if (dbSession.Transaction != null) cmd.Transaction = (SqlTransaction)dbSession.Transaction;

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = commandText;

                foreach (SqlParameter p in parameters)
                {
                    cmd.Parameters.Add(p);
                }

                if (cmd.Connection.State != ConnectionState.Open) cmd.Connection.Open();

                reader = cmd.ExecuteXmlReader();
            }
            return reader;
        }

        /// <summary>
        /// Wrapper for executing SqlCommand.ExecuteNonQuery() Command, See MSDN for more details
        /// </summary>
        /// <param name="dbSession"></param>
        /// <param name="commandText"></param>
        /// <param name="parameters"></param>
        /// <returns>row count</returns>
        protected static int ExecuteNonQuery(IDbSession dbSession, string commandText, IEnumerable<SqlParameter> parameters, out object retval)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                ;

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = commandText;

                foreach (SqlParameter p in parameters)
                {
                    cmd.Parameters.Add(p);
                }

                if (dbSession.Transaction != null)
                {
                    cmd.Transaction = (SqlTransaction)dbSession.Transaction;
                    cmd.Connection = cmd.Transaction.Connection;
                }
                else
                    cmd.Connection = (SqlConnection)dbSession.DbConnection;

                if (cmd.Connection.State != ConnectionState.Open) cmd.Connection.Open();

                int rowcount = cmd.ExecuteNonQuery();
                retval = cmd.Parameters["@ReturnValue"].Value;
                return rowcount;
            }
        }

        protected static T Deserialize(XmlReader reader)
        {
            return Util.XMLSerializer.Deserialize<T>(reader);
        }
        protected static IEnumerable<T> DeserializeCollection(XmlReader reader)
        {
            return Util.XMLSerializer.Deserialize<T[]>(reader);
        }
    }
}