﻿using FrameworkBase.ValueObject;
using System;

namespace TimesheetPortal.ValueObject
{
    /// <summary>
    /// PCHEN 20211007 : XXXX
    /// </summary>
    [Serializable]
    public class Employee : ValueObjectBase
    {
        /** PCHEN XXXXX Marked **/
        public string UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DisplayName { get; set; }
        public string Email { get; set; }
        public string Title { get; set; }
        public int JobGradeId { get; set; }
        public string DeptCode { get; set; }
        public string CountryCode { get; set; }
        public Employee Manager { get; set; }
    }
}
