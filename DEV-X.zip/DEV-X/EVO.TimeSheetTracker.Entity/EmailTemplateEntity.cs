﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
    public class EmailTemplateEntity
    {
        public int EmailTemplateID { get; set; }
        public string TemplateName { get; set; }
        public string EmailSubject { get; set; }
        public string EmailContent { get; set; }
    }
}
