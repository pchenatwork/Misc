﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
    public class RoleStatusEntity
    {
        public int RoleStatusID { get; set; }
        public string RoleName { get; set; }
        public int StatusID { get; set; }
        public int StatusTypeID { get; set; }
        public string Status { get; set; }
    }
}
