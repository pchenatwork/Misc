﻿using System;
using System.Collections.Generic;

namespace EVO.TimeSheetTracker.Entity
{
    public class TimeSheetQueryEntity
    {
        public int TimesheetID { get; set; }
        public string SubmittedBy { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int PeriodMonthID { get; set; }
        public List<int> StatusID { get; set; }
        public bool IsAdmin { get; set; }
        public List<TeamEntity> Teams { get; set; }
    }
}