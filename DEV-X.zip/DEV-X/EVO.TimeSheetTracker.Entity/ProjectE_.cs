﻿using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Text;


namespace EVO.TimeSheetTracker.Entity
{
    /// <summary>
    /// PCHEN 20211007 : "ProjectE_" is a replica of "ProjectEntity" for DEMO purpose
    /// </summary>
    [Serializable]    
    public class ProjectE_ : ValueObjectBase
    {
        /** PCHEN XXXXX Marked **/
        public int ProjectID { get; set; }
        public string ProjectName { get; set; }
        public List<SystemAssetEntity> SystemName { get; set; }
        public string Number { get; set; }
        public string Description { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? ProductionDate { get; set; }
        public decimal? TotalEstimatedHours { get; set; }
        public int StatusID { get; set; }
        public List<SettingsEntity> Phases { get; set; }
        public List<SettingsEntity> TimesheetProjectPhases { get; set; }
        public int? TypeID { get; set; }
        public bool NewProjectOfMonth { get; set; }
        public bool Impairment { get; set; }
        public string SystemRef { get; set; }
        public bool IsActive { get; set; }
        public List<TeamEntity> Teams { get; set; }
        public SettingsEntity ApprovalStatus { get; set; }
        public SettingsEntity ProjectStatus { get; set; }
        public SettingsEntity Type { get; set; }
        public EmployeeEntity Employee { get; set; }
        public bool IsAdmin { get; set; }
        public int TimezoneOffset { get; set; }
        public string Comment { get; set; }
    }
}
