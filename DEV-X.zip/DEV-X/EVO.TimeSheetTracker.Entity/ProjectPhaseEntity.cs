﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
    public class ProjectPhaseEntity
    {
        public int ProjectID { get; set; }
        public int OwnerID { get; set; }
        public string TeamOwner { get; set; }
        public int PhaseID { get; set; }
        public string PhaseDesc { get; set; }
        public bool IsChecked { get; set; }
        public int RequestType { get; set; }
    }
}
