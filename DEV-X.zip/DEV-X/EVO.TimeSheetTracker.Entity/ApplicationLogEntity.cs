﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
    public class ApplicationLogEntity
    {
        public int ApplicationLogID { get; set; }
        public string Message { get; set; }

        public string StackTrace { get; set; }

        public string UserName { get; set; }

        public DateTime Date { get; set; }

        public string OperatingSystem { get; set; }

        public string Browser { get; set; }

        public string MachineName { get; set; }
    }
}
