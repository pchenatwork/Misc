﻿using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
    public class ProjectTypeEnum : EnumBase<ProjectTypeEnum>
    {
        #region Enumeration Elements
        /* ==========================================================================
         * Name: 
         * Description:  
         * ==========================================================================*/
        public static readonly ProjectTypeEnum NewDev = new ProjectTypeEnum(1, "New Development", "");
        public static readonly ProjectTypeEnum NewEnhanSignificant = new ProjectTypeEnum(2, "New Enhancement - Significant", "");
        public static readonly ProjectTypeEnum NewEnhanNotSignificant = new ProjectTypeEnum(3, "New Enhancement - Not Significant", "");
        public static readonly ProjectTypeEnum BugFix = new ProjectTypeEnum(4, "Bug Fix", "");
        public static readonly ProjectTypeEnum Maint = new ProjectTypeEnum(5, "Maintenance", "");
        public static readonly ProjectTypeEnum Other = new ProjectTypeEnum(6, "Other", "");

        #endregion

        #region Constructors
        private ProjectTypeEnum(int id, string name, string extra) : base(id, name, extra)
        {
        }
        #endregion

    }

    public class ProjectStatusEnum : EnumBase<ProjectStatusEnum>
    {
        #region Enumeration Elements
        /* ==========================================================================
         * Name: 
         * Description:  
         * ==========================================================================*/
        public static readonly ProjectStatusEnum PendAppv = new ProjectStatusEnum(1, "Pending Approval", "");
        public static readonly ProjectStatusEnum Appv = new ProjectStatusEnum(2, "Approved", "");
        public static readonly ProjectStatusEnum Rejected = new ProjectStatusEnum(3, "Rejected", "");
        public static readonly ProjectStatusEnum Closed = new ProjectStatusEnum(4, "Closed", "");
        public static readonly ProjectStatusEnum Impaired = new ProjectStatusEnum(5, "Impaired", "");
        public static readonly ProjectStatusEnum Deleted = new ProjectStatusEnum(-1, "Deleted", "");

        #endregion

        #region Constructors
        private ProjectStatusEnum(int id, string name, string extra) : base(id, name, extra)
        {
        }
        #endregion

    }
}
