﻿using System;

namespace EVO.TimeSheetTracker.Entity
{
    public class ApprovalQueueEntity
    {
        public int RequestID { get; set; }
        public int RequstTypeID { get; set; }
        public int StatusID { get; set; }
        public string RequestedBy { get; set; }
        public DateTime RequestedDate { get; set; }
        public string DecidedBy { get; set; }
        public DateTime DecideDate { get; set; }
        public int ReferenceID { get; set; }
        public string Comment { get; set; }
        public int TimezoneOffset { get; set; }
    }
}