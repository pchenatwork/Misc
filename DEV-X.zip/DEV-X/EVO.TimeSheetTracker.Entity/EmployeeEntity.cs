﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
	public class EmployeeEntity
	{
		public int EmployeeID { get; set; }
		public string UserID { get; set; }
		public string EmployeeName { get; set; }
		public string Title { get; set; }
		public int TeamID { get; set; }

		public string TeamName { get; set; }

		public int TeamOwnerID { get; set; }

		public string TeamOwnerName { get; set; }

		public string DepartmentDesc { get; set; }

		public int DepartmentID { get; set; }

		public string RoleName { get; set; }

		public int ManagerID { get; set; }
		public string ManagerName { get; set; }
		public string JobGrade { get; set; }
		public bool? EmailAlert { get; set; }
		public string CountryDesc { get; set; }

		public int CountryID { get; set; }
		public string Email { get; set; }
		public bool IsActive { get; set; }
		public DateTime? UpdateDate { get; set; }
		public string UpdateBy { get; set; }

		public bool IsAdmin { get; set; }
	}
}
