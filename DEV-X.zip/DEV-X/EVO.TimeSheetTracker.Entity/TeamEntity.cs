﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
	public class TeamEntity
	{
		public int TeamID { get; set; }
		public string Name { get; set; }
		public EmployeeEntity Manager1 { get; set; }
		public EmployeeEntity Manager2 { get; set; }
		public EmployeeEntity Owner { get; set; }
		public string Country { get; set; }
		public bool? IsActive { get; set; }
		public DateTime? UpdateDate { get; set; }
		public string UpdateBy { get; set; }

		public bool IsAdmin { get; set; }
		public List<ProjectApprovalQueueEntity> Projects { get; set; }
	}
}
