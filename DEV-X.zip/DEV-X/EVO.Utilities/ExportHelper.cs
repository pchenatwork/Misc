﻿/***
***
***/ 
using System;
using System.IO;
using ClosedXML.Report;


namespace EVO.Common.UtilityCore
{
    public class ExportHelper
    {
        public static byte[] Generate(string rootPath, string fileName, object templateData)
        {
            var filePath = Path.Combine(rootPath, fileName);
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException(string.Format("Can't find file from {0}", filePath));
            }
            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var template = new XLTemplate(stream))
            {
                // ARRANGE
                template.AddVariable(templateData);
                using (var file = new MemoryStream())
                {
                    template.Generate();
                    template.SaveAs(file);
                    file.Position = 0;
                    return file.ToArray();
                }
            }
        }
    }
}