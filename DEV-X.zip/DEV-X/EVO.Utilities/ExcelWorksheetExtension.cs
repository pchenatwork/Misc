﻿using OfficeOpenXml;
using System.Data;
using System.IO;
using System.Linq;

namespace EVO.Common.UtilityCore
{
   public static class ExcelWorksheetHelper
    {
        public static DataTable ToDataTable(this ExcelWorksheet ws, bool hasHeaderRow = true)
        {
            var tbl = new DataTable(ws.Name);
            if(ws.Cells.Count() == 0)
            {
                return tbl;
            }
            foreach (var firstRowCell in ws.Cells[1, 1, 1, ws.Dimension.End.Column])
                tbl.Columns.Add(hasHeaderRow ?
                    firstRowCell.Text : string.Format("Column {0}", firstRowCell.Start.Column));
            var startRow = hasHeaderRow ? 2 : 1;
            for (var rowNum = startRow; rowNum <= ws.Dimension.End.Row; rowNum++)
            {
                var wsRow = ws.Cells[rowNum, 1, rowNum, ws.Dimension.End.Column];
                var row = tbl.NewRow();
                foreach (var cell in wsRow) row[cell.Start.Column - 1] = cell.Text;
                tbl.Rows.Add(row);
            }
            return tbl;
        }

        public static DataTable Read(Stream stream)
        {
            using(ExcelPackage pck = new ExcelPackage(stream))
            {
                ExcelWorksheet ws = pck.Workbook.Worksheets.FirstOrDefault();
                if(ws != null)
                {
                    return ws.ToDataTable(true);
                }
                return null;
            }
        }
    }
}
