﻿using System.Collections.Generic;
using System.IO;
using System.IO.Compression;



namespace EVO.Common.UtilityCore
{
    public static class ZipHelper
    {
        public static byte[] CreateEncryptedZipFile(
    List<StatementFile> sourceList)
        {
            char[] directorySeparatorChar = new char[] { Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar };
            using (MemoryStream archiveStream = new MemoryStream())
            {
                using (ZipArchive archive = new ZipArchive(
                    archiveStream,
                    ZipArchiveMode.Create,
                    true,
                    null
                   ))
                {
                    foreach (var item in sourceList)
                    {
                        using (MemoryStream pdfStream = new MemoryStream(item.FileContent))
                        {
                            string entryName = item.FileName;
                            entryName = entryName.TrimStart(directorySeparatorChar);
                            ZipArchiveEntry entry = archive.CreateEntry(entryName);


                        using (Stream entryStream = entry.Open())
                            {
                                pdfStream.CopyTo(entryStream);
                            }

                        }
                    }
                }
                return archiveStream.ToArray();
            }

        }
    }


    public class StatementFile
    {
        public byte[] FileContent { get; set; }
        public string FileType { get; set; }

        public string FileName { get; set; }
    }
}
