﻿using ClosedXML.Report.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Reflection;

namespace EVO.Common.UtilityCore
{
    public class DataTableUtil
    {
        /// <summary>
        //convert datarow to entity
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dr"></param>
        /// <returns></returns>
        public static T ConvertToEntity<T>(DataRow dr) where T : new()
        {
            T entity = new T();
            Type info = typeof(T);
            var properties = info.GetProperties();
            string columnName = string.Empty;
            object propName = DBNull.Value;
            foreach (var prop in properties)
            {
                
                if (!prop.CanWrite)
                {
                    continue;
                }
                
                var attributes = prop.GetCustomAttribute<ColumnAttribute>();

                if (attributes is null)
                {
                    columnName = prop.Name;
                }
                else
                {
                    columnName = attributes.Name ?? prop.Name;
                }
                if (!dr.Table.Columns.Contains(columnName))
                {
                    continue;
                }
                propName = dr[columnName];

                var propertyType = prop.PropertyType;
               

                if (propertyType.IsGenericType && propertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                {
                    // Check for null or empty string value.
                    if (propName == null || string.IsNullOrWhiteSpace(propName.ToString()))
                    {
                        prop.SetValue(entity, null);
                        continue;
                    }
                    else
                    {
                        propertyType = propertyType.GetGenericArguments()[0];
                    }
                }

                if(propName != DBNull.Value)
                {
                    var propertyValue = Convert.ChangeType(propName, propertyType);
                    prop.SetValue(entity, propertyValue, null);
                }
              
            }
            return entity;
        }

        /// <summary>
        /// convert DataTable to List<T>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static List<T> ToEntityList<T>(DataTable dt) where T : new()
        {
            List<T> list = new List<T>(dt.Rows.Count);
            foreach (DataRow dr in dt.Rows)
            {
                list.Add(ConvertToEntity<T>(dr));
            }
            return list;
        }
    }
}
