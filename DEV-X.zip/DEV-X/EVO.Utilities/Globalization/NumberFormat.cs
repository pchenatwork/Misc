﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace EVO.Common.UtilityCore.Globalization
{
    public static class NumberFormat
    {
        /// <summary>
        /// Convert a decimal into a string representation based on the users culture info
        /// </summary>
        /// <param name="value">The value to convert</param>
        /// <param name="negativePattern">
        ///     Default:             -1,234.00
        ///     Pattern 0:           (1,234.00)
        ///     Pattern 1:           -1,234.00
        ///     Pattern 2:           - 1,234.00
        ///     Pattern 3:           1,234.00-
        ///     Pattern 4:           1,234.00 -
        /// </param>
        /// <param name="decimalDigits">The number of decimal digits to include</param>
        /// <param name="currencySymbol">The currency symbol to include in the string</param>
        /// <returns></returns>
        public static string GetDisplayTextCurrency(decimal value, int negativePattern, int decimalDigits, string currencySymbol)
        {
            string result = "";
            result = GetDisplayTextNumber(value, negativePattern, decimalDigits);
            result = currencySymbol + result;
            return result;
        }

        /// <summary>
        /// Convert a decimal into a string representation based on the users culture info
        /// </summary>
        /// <param name="value">The value to convert</param>
        /// <param name="negativePattern">
        ///     Default:             -1,234.00
        ///     Pattern 0:           (1,234.00)
        ///     Pattern 1:           -1,234.00
        ///     Pattern 2:           - 1,234.00
        ///     Pattern 3:           1,234.00-
        ///     Pattern 4:           1,234.00 -
        /// </param>
        /// <param name="decimalDigits">The number of decimal digits to include</param>
        /// <returns></returns>
        public static string GetDisplayTextNumber(decimal value, int negativePattern, int decimalDigits)
        {
            NumberFormatInfo nfi = CultureInfo.CurrentUICulture.NumberFormat.Clone() as NumberFormatInfo;
            nfi.NumberNegativePattern = negativePattern;
            nfi.NumberDecimalDigits = decimalDigits;
            return value.ToString("N", nfi);
        }

        /// <summary>
        /// Convert a decimal into a string representation based on the users culture info
        /// </summary>
        /// <param name="value">The value to convert</param>
        /// <param name="decimalDigits">The number of decimal digits to include</param>
        /// <returns></returns>
        public static string GetDisplayTextPercent(decimal value, int decimalDigits)
        {
            NumberFormatInfo nfi = CultureInfo.CurrentUICulture.NumberFormat.Clone() as NumberFormatInfo;
            nfi.PercentDecimalDigits = decimalDigits;
            return value.ToString("P", nfi);
        }

        /// <summary>
        /// Try to convert the input string into a decimal type based on the users culture
        /// Example: 1.000,01 in italian culture will be converted to a decimal value 1000.01 
        /// </summary>
        /// <param name="input">A string representation of a number with culture specific formatting</param>
        /// <returns></returns>
        public static decimal TryParse(string input)
        {
            NumberFormatInfo nfi = CultureInfo.CurrentUICulture.NumberFormat.Clone() as NumberFormatInfo;
            decimal result = 0;
            Decimal.TryParse(input, NumberStyles.Any, nfi, out result);

            return result;
        }
    }
}
