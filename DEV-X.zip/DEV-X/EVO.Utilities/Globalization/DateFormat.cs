﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace EVO.Common.UtilityCore.Globalization
{
    public class DateFormat
    {
        public static DateTime TryParse(string input)
        {
            DateTimeFormatInfo dtfi = CultureInfo.CurrentUICulture.DateTimeFormat.Clone() as DateTimeFormatInfo;
            DateTime result = DateTime.MinValue;
            DateTime.TryParse(input, dtfi, DateTimeStyles.None, out result);

            return result;
        }
    }
}
