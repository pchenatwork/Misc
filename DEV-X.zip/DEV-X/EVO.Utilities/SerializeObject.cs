﻿using System;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace EVO.Common.UtilityCore
{
    public class SerializeObject<T>
    {
        public static T FromXml(string Xml)
        {
            if (Xml == null || Xml.Trim() == String.Empty) return default(T);
            XmlSerializer ser;
            ser = new XmlSerializer(typeof(T));
            StringReader stringReader;
            stringReader = new StringReader(Xml);
            XmlTextReader xmlReader;
            xmlReader = new XmlTextReader(stringReader);
            xmlReader.DtdProcessing = DtdProcessing.Prohibit;
            T obj = (T)ser.Deserialize(xmlReader);
            xmlReader.Close();
            stringReader.Close();
            return obj;
        }

        public static string OutputXML_Statements(T obj)
        {
            StringWriter sw = new StringWriter();
            XmlTextWriter writer = new XmlTextWriter(sw);
            writer.Formatting = Formatting.Indented;
            try
            {
                XmlSerializer s = new XmlSerializer(typeof(T));
                s.Serialize(writer, obj);
            }
            catch (Exception ex)
            {
                //do what here?
                throw ex;
            }
            finally
            {
                writer.Flush();
                writer.Close();
            }
            return sw.ToString();
        }

        public static string Serialize(T obj)
        {
            MemoryStream ms = new MemoryStream();

            XmlSerializer s = new XmlSerializer(typeof(T));
            StreamWriter sw = new StreamWriter(ms);
            s.Serialize(sw, obj);

            StreamReader sr = new StreamReader(ms);
            ms.Position = 0;
            string ret = sr.ReadToEnd();
            ms.Close();
            sw.Close();
            sr.Close();
            return ret;
        }
    }
}
