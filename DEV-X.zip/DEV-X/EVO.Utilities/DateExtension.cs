﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EVO.Common.UtilityCore
{
    public static class DateExtension
    {
        public static TimeSpan FromNow(this DateTime date)
        {
            return DateTime.Now.Subtract(date);
        }
        public static TimeSpan FromNow(this DateTime? date)
        {
            if (!date.HasValue)
                return TimeSpan.MaxValue;
            return date.Value.FromNow();
        }
    }
}
