using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace EVO.Common.UtilityCore.ProgressIndicator
{
    public class ProgressIndicator
    {        
        #region Properties

        private Guid _Id;
        ///<summary>description</summary>
        public Guid Id
        {
            get 
            {
                if (_Id == null) _Id = Guid.NewGuid();
                return _Id; 
            }
            set { _Id = value; }
        }

        private string m_Name;
        public string Name
        {
            get { return m_Name; }
            set { m_Name = value; }
        }

        private string m_Description;
        public string Description
        {
            get { return m_Description; }
            set { m_Description = value; }
        }

        private string m_CurrentMessage;
        public string CurrentMessage
        {
            get { return m_CurrentMessage; }
            set { m_CurrentMessage = value; }
        }

        private ProgressStatus m_Status;
        public ProgressStatus Status
        {
            get { return m_Status; }
            set { m_Status = value; }
        }

        private int m_PercentComplete;
        public int PercentComplete
        {
            get { return m_PercentComplete; }
            set 
            {
                m_PercentComplete = Convert.ToInt32(Interval.Start + (Interval.End - Interval.Start) * value / 100);
            }
        }

        private DateTime m_StartTime;
        public DateTime StartTime
        {
            get { return m_StartTime; }
            set { m_StartTime = value; }
        }

        private string m_LastChecked;
        public string LastChecked
        {
            get { return m_LastChecked; }
            set { m_LastChecked = value; }
        }

        private TaskInterval m_Interval;
        public  TaskInterval Interval
        {
            get { return m_Interval; }
            protected set { m_Interval = value; }
        }

        public bool IsCancelled
        {
            get
            {
                return ProgressCancellation.HasCancellation(this.Id);
            }
        }

        public ProgressIndicator()
        {
            this.Status = ProgressStatus.InProgress;
            this.Id = Guid.NewGuid();
        }

        /// <summary>
        /// i have currently decided to stick to ASP.NET web caching instead of other types, as we primarily use this dll in web projects.. 
        /// </summary>
        protected static List<ProgressIndicator> All
        {
            get
            {
                List<ProgressIndicator> indicators = new List<ProgressIndicator>();
                try
                {
                    object result = null;
                        //HttpContext.Current.Cache["ProgressIndicators"];
                    if (result != null) indicators = (List<ProgressIndicator>)result;
                }
                catch (Exception ex)
                {
                    //??
                    //possible options here may be persisted records in db instead of cached againt application... 
                    throw new Exception("Progress indicators caching retrieval failure. Please review logic in DAC.");
                }
                return indicators;
            }
            set
            {
                //HttpContext.Current.Cache["ProgressIndicators"] = value;
            }
        }
        #endregion

        #region Constructors

        public ProgressIndicator(string Name, string Description, string InitialMessage) : this()
        {
            m_Name = Name;
            m_Description = Description;
            m_CurrentMessage = InitialMessage;
        }

        #endregion

        protected void CheckForCancellation()
        {
            if (ProgressCancellation.HasCancellation(this.Id))
            {
                this.CurrentMessage = "User has stopped the process.";
                this.Status = ProgressStatus.Failed;
                Save(this);
                throw new ProgressIndicatorStoppedException("User has stopped the process.");
            }
        }

        public void Update(string CurrentMessage)
        {
            CheckForCancellation();
            this.CurrentMessage = CurrentMessage;
            ProgressIndicator.Save(this);
        }

        public void Update(double PercentComplete, string CurrentMessage)
        {
            if (PercentComplete > 99) PercentComplete = 99;
            Update((int)PercentComplete, CurrentMessage);
        }

        public void Update(int Percentcomplete, string CurrentMessage)
        {
            CheckForCancellation();
            if (PercentComplete > 99) PercentComplete = 99;
            this.PercentComplete = Percentcomplete;
            this.CurrentMessage = CurrentMessage;
            ProgressIndicator.Save(this);
        }

        public void Update(int Percentcomplete, string CurrentMessage,ProgressStatus Status  )
        {
            if (Status == ProgressStatus.InProgress) CheckForCancellation();
            if (PercentComplete > 100) PercentComplete = 100;
            this.PercentComplete = Percentcomplete;
            this.CurrentMessage = CurrentMessage;
            this.Status = Status;
            ProgressIndicator.Save(this);
        }

        public void Update(int Percentcomplete, string Description, string CurrentMessage, ProgressStatus Status)
        {
            if (Status == ProgressStatus.InProgress) CheckForCancellation();
            this.PercentComplete = Percentcomplete;
            this.Description = Description;
            this.CurrentMessage = CurrentMessage;
            this.Status = Status;
            ProgressIndicator.Save(this);
        }

        public void UpdateDescription(string Description)
        {
            CheckForCancellation();
            this.Description = Description;
            ProgressIndicator.Save(this);
        }

        public void ClearInterval()
        {
            Interval = new TaskInterval();
        }

        public void Update(TaskInterval Interval)
        {
            CheckForCancellation();
            m_Interval = Interval;
            ProgressIndicator.Save(this);
        }

        public override bool Equals(object obj)
        {
            if (obj.GetType() == typeof(ProgressIndicator))
            {
                ProgressIndicator InQuestion = (ProgressIndicator)obj;
                if (this.Id == InQuestion.Id) return true;
            }
            return false;
        }

        #region Persistence

        //public static void Save(ProgressIndicator Target, ISession session)
        //{
        //    try
        //    {
        //        session.SaveOrUpdate(Target);
        //        session.Flush();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Unable to save ProgressIndicator  object", ex);
        //    }

        //}

        public static void Save(ProgressIndicator Target)
        {
            List<ProgressIndicator> existingIndicators = ProgressIndicator.All;
            //following may not be necessary... 
            //ProgressIndicator existingIndicator = existingIndicators.Find(delegate(ProgressIndicator o) { return o.Id == Target.Id; });
            //if (existingIndicator != null)
            //{
            //    existingIndicators.Remove(existingIndicator);
            //}
            //existingIndicators.Add(Target);
            //ProgressIndicator.All = existingIndicators;

            if (existingIndicators.Contains(Target)) existingIndicators.Remove(Target);
            existingIndicators.Add(Target);


            //ISession session = NHibernator.GetSession("Progress");
            //ITransaction transaction = session.BeginTransaction();

            //try
            //{
            //    ProgressIndicator.Save(Target, session);
            //    transaction.Commit();
            //}
            //catch (Exception ex)
            //{
            //    transaction.Rollback();
            //    throw new Exception("Unable to save ProgressIndicator  object", ex);
            //}

        }

        public static ProgressIndicator Load(Guid TargetId)
        {
            return All.Find(delegate(ProgressIndicator o) { return o.Id == TargetId; });
            //ISession session = NHibernator.GetSession("Progress");
            //try
            //{
            //    return (ProgressIndicator)session.Load(typeof(ProgressIndicator), TargetId);
            //}
            //catch (Exception ex)
            //{
            //    throw new Exception("Unable to find ProgressIndicator  with id of: " + TargetId.ToString(), ex);
            //}
        }

        //public static void Delete(ProgressIndicator Target, ISession session)
        //{
        //    try
        //    {
        //        session.Delete(Target);
        //        session.Flush();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Unable To Delete ProgressIndicator ", ex);
        //    }
        //}

        public static void Delete(ProgressIndicator Target)
        {
            List<ProgressIndicator> existingIndicators = All;
            existingIndicators.Remove(Target);
            All = existingIndicators;
            //ISession mySession = NHibernator.GetSession("Progress");
            //ITransaction transaction = mySession.BeginTransaction();

            //try
            //{
            //    Delete(Target, mySession);
            //    transaction.Commit();
            //}
            //catch (Exception ex)
            //{
            //    transaction.Rollback();
            //    throw new Exception("Unable To Delete ProgressIndicator ", ex);
            //}
        }

        #endregion 
    }

    public enum ProgressStatus
    {
        InProgress = 1,
        Success = 2,
        Failed = 3
    }
}
