using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace EVO.Common.UtilityCore.ProgressIndicator
{
    public class ProgressCancellation
    {
        #region properties

        private Guid _Id;
        public Guid Id
        {
            get
            {
                if (_Id == null) _Id = Guid.NewGuid();
                return _Id;
            }
            set { _Id = value; }
        }

        private ProgressIndicator m_Indicator;
        public ProgressIndicator Indicator
        {
            get { return m_Indicator; }
            set { m_Indicator = value; }
        }

        /// <summary>
        /// i have currently decided to stick to ASP.NET web caching instead of other types, as we primarily use this dll in web projects.. 
        /// </summary>
        protected static List<ProgressCancellation> All
        {
            get
            {
                List<ProgressCancellation> cancellations = new List<ProgressCancellation>();
                try
                {
                    object result = null;
                        //HttpContext.Current.Cache["ProgressCancellations"];
                    if (result != null) cancellations = (List<ProgressCancellation>)result;
                }
                catch
                {
                    //??
                    //possible options here may be persisted records in db instead of cached againt application... 
                    throw new Exception("Progress cancellations caching retrieval failure. Please review logic in DAC.");
                }
                return cancellations;
            }
            set
            {
               // HttpContext.Current.Cache["ProgressIndicators"] = value;
            }
        }
        #endregion

        #region Persistence

        //public static void Save(ProgressCancellation Target, ISession session)
        //{
        //    try
        //    {
        //        session.SaveOrUpdate(Target);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Unable to save ProgressCancellation  object", ex);
        //    }

        //}

        public static void Save(ProgressCancellation Target)
        {
            throw new NotImplementedException();
            //ISession session = NHibernator.GetSession("Progress");
            //ITransaction transaction = session.BeginTransaction();

            //try
            //{
            //    ProgressCancellation.Save(Target, session);
            //    transaction.Commit();
            //}
            //catch (Exception ex)
            //{
            //    transaction.Rollback();
            //    throw new Exception("Unable to save ProgressCancellation  object", ex);
            //}

        }

        public static ProgressCancellation Load(int TargetId)
        {
            throw new NotImplementedException();
            //ISession session = NHibernator.GetSession("Progress");
            //try
            //{
            //    return (ProgressCancellation)session.Load(typeof(ProgressCancellation), TargetId);
            //}
            //catch (Exception ex)
            //{
            //    throw new Exception("Unable to find ProgressCancellation  with id of: " + TargetId.ToString(), ex);
            //}
        }

        //public static void Delete(ProgressCancellation Target, ISession session)
        //{
        //    try
        //    {
        //        session.Delete(Target);
        //        session.Flush();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Unable To Delete ProgressCancellation ", ex);
        //    }
        //}

        public static void Delete(ProgressCancellation Target)
        {
            throw new NotImplementedException();
            //ISession mySession = NHibernator.GetSession("Progress");
            //ITransaction transaction = mySession.BeginTransaction();

            //try
            //{
            //    Delete(Target, mySession);
            //    transaction.Commit();
            //}
            //catch (Exception ex)
            //{
            //    transaction.Rollback();
            //    throw new Exception("Unable To Delete ProgressCancellation ", ex);
            //}
        }

        #endregion

        protected ProgressCancellation()
        {

        }

        public ProgressCancellation(ProgressIndicator ind)
        {
            this.Indicator = ind;
        }

        public static void AddCancellation(ProgressIndicator ind)
        {
            if (!HasCancellation(ind.Id)) ProgressCancellation.Save(new ProgressCancellation(ind));
        }

        public static bool HasCancellation(Guid IndicatorId)
        {
            throw new NotImplementedException("To Do..");
            //            ISession session = NHibernator.GetSession("Progress");
//            IQuery q = session.CreateQuery(@"
//                        from ProgressCancellation pc
//                        where pc.Indicator.Id = :ind");
//            q.SetInt32("ind", IndicatorId);
//            return q.List().Count > 0;
        }
    }
}
