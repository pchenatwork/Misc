using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.Common.UtilityCore.ProgressIndicator
{
    public class TaskInterval
    {
        #region Properties
        private int m_Start;
        public int Start
        {
            get { return m_Start; }
            set { m_Start = value; }
        }

        private int m_End;
        public int End
        {
            get { return m_End; }
            set { m_End = value; }
        }

        public int Duration
        {
            get { return End - Start; }
        }
        #endregion

        public TaskInterval()
        {
            m_Start = 0;
            m_End = 100;
        }

        public TaskInterval(int Start, int End)
        {
            m_Start = Start;
            m_End = End;
        }

        public TaskInterval(double Start, double End)
        {
            m_Start = (int)Start;
            m_End = (int)End;
        }

        public void Increment(int Amount)
        {
            Start += Amount;
            End += Amount;
        }
    }
}
