using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.Common.UtilityCore.ProgressIndicator
{
    class TaskEntry
    {
    }
}
