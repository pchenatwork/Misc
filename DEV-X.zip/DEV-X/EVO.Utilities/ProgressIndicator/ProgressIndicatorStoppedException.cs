using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.Common.UtilityCore.ProgressIndicator
{
    public class ProgressIndicatorStoppedException : Exception
    {
        public ProgressIndicatorStoppedException(string Message)
            : base(Message)
        {
        }

        public ProgressIndicatorStoppedException(string Message, Exception InnerException)
            : base(Message, InnerException)
        {
        }
    }
}
