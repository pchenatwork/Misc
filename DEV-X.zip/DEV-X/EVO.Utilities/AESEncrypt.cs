﻿using IdentityModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;


namespace EVO.Common.UtilityCore
{
    public class AESEncrypt
    {
        private byte[] Key;

        private byte[] Vector;

        private ICryptoTransform EncryptorTransform;

        private ICryptoTransform DecryptorTransform;

        private UTF8Encoding UTFEncoder;

        public AESEncrypt(byte[] Key, byte[] Vector)
        {
            this.Key = Key;
            this.Vector = Vector;
            RijndaelManaged rijndaelManaged = new RijndaelManaged();
            EncryptorTransform = rijndaelManaged.CreateEncryptor(this.Key, this.Vector);
            DecryptorTransform = rijndaelManaged.CreateDecryptor(this.Key, this.Vector);
            UTFEncoder = new UTF8Encoding();
            rijndaelManaged.Dispose();
        }

        public static byte[] GenerateEncryptionKey()
        {
            RijndaelManaged rijndaelManaged = new RijndaelManaged();
            rijndaelManaged.KeySize = 256;
            rijndaelManaged.GenerateKey();
            return rijndaelManaged.Key;
        }

        public static byte[] GenerateEncryptionVector()
        {
            RijndaelManaged rijndaelManaged = new RijndaelManaged();
            rijndaelManaged.KeySize = 192;
            rijndaelManaged.GenerateIV();
            return rijndaelManaged.IV;
        }

        public byte[] Encrypt(string TextValue)
        {
            byte[] bytes = UTFEncoder.GetBytes(TextValue);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, EncryptorTransform, CryptoStreamMode.Write);
            cryptoStream.Write(bytes, 0, bytes.Length);
            cryptoStream.FlushFinalBlock();
            memoryStream.Position = 0L;
            byte[] array = new byte[memoryStream.Length];
            memoryStream.Read(array, 0, array.Length);
            cryptoStream.Close();
            memoryStream.Close();
            return array;
        }

        public string Decrypt(byte[] EncryptedValue)
        {
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, DecryptorTransform, CryptoStreamMode.Write);
            cryptoStream.Write(EncryptedValue, 0, EncryptedValue.Length);
            cryptoStream.FlushFinalBlock();
            memoryStream.Position = 0L;
            byte[] array = new byte[memoryStream.Length];
            memoryStream.Read(array, 0, array.Length);
            memoryStream.Close();
            return UTFEncoder.GetString(array);
        }

        private static string RandomString(int size, bool lowerCase)
        {
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < size; i++)
            {
                char value = Convert.ToChar(Convert.ToInt32(Math.Floor(26.0 * new CryptoRandom().NextDouble() + 65.0)));
                stringBuilder.Append(value);
            }
            if (lowerCase)
            {
                return stringBuilder.ToString().ToLower();
            }
            return stringBuilder.ToString();
        }

        private static int RandomNumber(int min, int max)
        {
            return new CryptoRandom().Next(min, max);
        }

        public static string GenerateToken()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append(RandomString(5, lowerCase: true));
            stringBuilder.Append("-");
            stringBuilder.Append(RandomString(5, lowerCase: true));
            stringBuilder.Append("-");
            stringBuilder.Append(RandomString(5, lowerCase: true));
            return EncodeToken(stringBuilder.ToString());
        }

        public static string EncodeToken(string toEncode)
        {
            return Convert.ToBase64String(Encoding.ASCII.GetBytes(toEncode));
        }

        public static string DecodeToken(string encodedData)
        {
            byte[] bytes = Convert.FromBase64String(encodedData);
            return Encoding.ASCII.GetString(bytes);
        }
    }
}
