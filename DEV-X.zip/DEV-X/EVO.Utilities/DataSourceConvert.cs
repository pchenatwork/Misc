﻿namespace EVO.Common.UtilityCore
{
    /// <summary>
    /// All to function convert data source to generic type
    /// </summary>
    public static class DataSourceConvert
    {
        public static T To<T>(this object obj)
        {
            if (obj == null)
            {
                return default(T);
            }
            return (T)obj;
        }
    }
}

