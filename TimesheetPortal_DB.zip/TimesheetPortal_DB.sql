USE [TimesheetPortal]
GO
EXEC sys.sp_dropextendedproperty @name=N'MS_Description' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'TimesheetPeriod', @level2type=N'COLUMN',@level2name=N'AccountingEntityId'
GO
/****** Object:  StoredProcedure [dbo].[SPU_Workflow_Update]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Workflow_Update]
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetPeriod_Find]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_TimesheetPeriod_Find]
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetPeriod_ClosePeriod]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_TimesheetPeriod_ClosePeriod]
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_UpSert]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_TimesheetActivity_UpSert]
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_Import]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_TimesheetActivity_Import]
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_GetByCriteria]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_TimesheetActivity_GetByCriteria]
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_Get]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_TimesheetActivity_Get]
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_FindByAccount]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_TimesheetActivity_FindByAccount]
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimeSheetActivity_Find_Daily]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_TimeSheetActivity_Find_Daily]
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_Find]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_TimesheetActivity_Find]
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_Delete_Import]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_TimesheetActivity_Delete_Import]
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_Delete]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_TimesheetActivity_Delete]
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetAccounting_FindByCriteria]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_TimesheetAccounting_FindByCriteria]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_Teams]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_Outlook_Teams]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_TeamResource]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_Outlook_TeamResource]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_TeamProject]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_Outlook_TeamProject]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_Team_Export]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_Outlook_Team_Export]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_Project]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_Outlook_Project]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_ExecResourceView]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_Outlook_ExecResourceView]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_ExecProjectView]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_Outlook_ExecProjectView]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_ExecApprovalView]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_Outlook_ExecApprovalView]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_EmployeeTrendReport]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_Outlook_EmployeeTrendReport]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_EmployeeSummary]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_Outlook_EmployeeSummary]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_EmployeeProject]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_Outlook_EmployeeProject]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_Employee]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_Outlook_Employee]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_ByEntity]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_Outlook_ByEntity]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_ManagerApproval_Undo]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_ManagerApproval_Undo]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_ManagerApproval]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_ManagerApproval]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_ExecutiveApproval_Undo]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_ExecutiveApproval_Undo]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_ExecutiveApproval]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Timesheet_ExecutiveApproval]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Teamsheet_Find]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Teamsheet_Find]
GO
/****** Object:  StoredProcedure [dbo].[SPU_TeamEmployee_UpSert]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_TeamEmployee_UpSert]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Team_UpSert]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Team_UpSert]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Team_Get]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Team_Get]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Team_FindByCriteria]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Team_FindByCriteria]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Team_Find]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Team_Find]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Setting_UpSert]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Setting_UpSert]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Setting_Get]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Setting_Get]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Setting_FindByCriteria]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Setting_FindByCriteria]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Setting_Find]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Setting_Find]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Setting_Delete]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Setting_Delete]
GO
/****** Object:  StoredProcedure [dbo].[SPU_ProjectTeam_UpSert]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_ProjectTeam_UpSert]
GO
/****** Object:  StoredProcedure [dbo].[SPU_ProjectActivity_UpSert]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_ProjectActivity_UpSert]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Project_UpSert]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Project_UpSert]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Project_UpdateProjectNo]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Project_UpdateProjectNo]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Project_Get]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Project_Get]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Project_FindByCriteria]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Project_FindByCriteria]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Project_Find]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Project_Find]
GO
/****** Object:  StoredProcedure [dbo].[SPU_EmployeeRole_UpSert]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_EmployeeRole_UpSert]
GO
/****** Object:  StoredProcedure [dbo].[SPU_EmployeeActivityMap_Insert]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_EmployeeActivityMap_Insert]
GO
/****** Object:  StoredProcedure [dbo].[SPU_EmployeeActivityMap_Delete]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_EmployeeActivityMap_Delete]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Employee_UpSert]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Employee_UpSert]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Employee_Get]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Employee_Get]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Employee_FindByCriteria]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Employee_FindByCriteria]
GO
/****** Object:  StoredProcedure [dbo].[SPU_Employee_Find]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_Employee_Find]
GO
/****** Object:  StoredProcedure [dbo].[SPU_EmailTemplate_FindByCriteria]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_EmailTemplate_FindByCriteria]
GO
/****** Object:  StoredProcedure [dbo].[SPU_ApplicationLog_Update]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_ApplicationLog_Update]
GO
/****** Object:  StoredProcedure [dbo].[SPU_ApplicationLog_Insert]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_ApplicationLog_Insert]
GO
/****** Object:  StoredProcedure [dbo].[SPU_ApplicationLog_Get]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_ApplicationLog_Get]
GO
/****** Object:  StoredProcedure [dbo].[SPU_ApplicationLog_Find]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_ApplicationLog_Find]
GO
/****** Object:  StoredProcedure [dbo].[SPU_AccountingEntity_GetAll]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_AccountingEntity_GetAll]
GO
/****** Object:  StoredProcedure [dbo].[SPU_AccountingEntity_FindByCriteria]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP PROCEDURE [dbo].[SPU_AccountingEntity_FindByCriteria]
GO
ALTER TABLE [dbo].[Team] DROP CONSTRAINT [DF__Team__UpdateDate]
GO
ALTER TABLE [dbo].[Team] DROP CONSTRAINT [DF__Team__CreateDate]
GO
ALTER TABLE [dbo].[Team] DROP CONSTRAINT [DF__Team__IsActive]
GO
ALTER TABLE [dbo].[Team] DROP CONSTRAINT [DF__Team__ParentId]
GO
ALTER TABLE [dbo].[Team] DROP CONSTRAINT [DF__Team__OwnerId]
GO
ALTER TABLE [dbo].[Team] DROP CONSTRAINT [DF__Team__ManagerId]
GO
/****** Object:  Index [UK_ProjectActivity]    Script Date: 1/27/2022 5:22:40 PM ******/
ALTER TABLE [dbo].[ProjectActivity] DROP CONSTRAINT [UK_ProjectActivity]
GO
/****** Object:  Table [dbo].[WorkflowHistory]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[WorkflowHistory]') AND type in (N'U'))
DROP TABLE [dbo].[WorkflowHistory]
GO
/****** Object:  Table [dbo].[TimesheetSubmission]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TimesheetSubmission]') AND type in (N'U'))
DROP TABLE [dbo].[TimesheetSubmission]
GO
/****** Object:  Table [dbo].[TimesheetPeriod]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TimesheetPeriod]') AND type in (N'U'))
DROP TABLE [dbo].[TimesheetPeriod]
GO
/****** Object:  Table [dbo].[TimesheetActivity]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TimesheetActivity]') AND type in (N'U'))
DROP TABLE [dbo].[TimesheetActivity]
GO
/****** Object:  Table [dbo].[TeamEmployee]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TeamEmployee]') AND type in (N'U'))
DROP TABLE [dbo].[TeamEmployee]
GO
/****** Object:  Table [dbo].[Team]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Team]') AND type in (N'U'))
DROP TABLE [dbo].[Team]
GO
/****** Object:  Table [dbo].[ProjectTeam]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProjectTeam]') AND type in (N'U'))
DROP TABLE [dbo].[ProjectTeam]
GO
/****** Object:  Table [dbo].[ProjectActivity]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProjectActivity]') AND type in (N'U'))
DROP TABLE [dbo].[ProjectActivity]
GO
/****** Object:  Table [dbo].[Project]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Project]') AND type in (N'U'))
DROP TABLE [dbo].[Project]
GO
/****** Object:  Table [dbo].[Enum]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Enum]') AND type in (N'U'))
DROP TABLE [dbo].[Enum]
GO
/****** Object:  Table [dbo].[EmployeeRole]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EmployeeRole]') AND type in (N'U'))
DROP TABLE [dbo].[EmployeeRole]
GO
/****** Object:  Table [dbo].[EmployeeActivityMap]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EmployeeActivityMap]') AND type in (N'U'))
DROP TABLE [dbo].[EmployeeActivityMap]
GO
/****** Object:  Table [dbo].[Employee]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Employee]') AND type in (N'U'))
DROP TABLE [dbo].[Employee]
GO
/****** Object:  Table [dbo].[EmailTemplate]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EmailTemplate]') AND type in (N'U'))
DROP TABLE [dbo].[EmailTemplate]
GO
/****** Object:  Table [dbo].[ApplicationLog]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ApplicationLog]') AND type in (N'U'))
DROP TABLE [dbo].[ApplicationLog]
GO
/****** Object:  Table [dbo].[AccountingEntity]    Script Date: 1/27/2022 5:22:40 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AccountingEntity]') AND type in (N'U'))
DROP TABLE [dbo].[AccountingEntity]
GO
/****** Object:  UserDefinedFunction [dbo].[fn_Project_GetNextNo]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP FUNCTION [dbo].[fn_Project_GetNextNo]
GO
/****** Object:  UserDefinedFunction [dbo].[fn_NumericOnly]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP FUNCTION [dbo].[fn_NumericOnly]
GO
/****** Object:  UserDefinedFunction [dbo].[fn_DelimitedStringToTable]    Script Date: 1/27/2022 5:22:40 PM ******/
DROP FUNCTION [dbo].[fn_DelimitedStringToTable]
GO
/****** Object:  UserDefinedFunction [dbo].[fn_DelimitedStringToTable]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*********************************************************
* PROCEDURE:    [fn_DelimitedStringToTable]
DESCRIPTION:  Split delimited string into table
* CREATED: 12/2021 PCHEN
MODIFICATION HISTORY
 1/21/2022 PCHEN: Use build-in STRING_SPLIT() (SQL 2016+) to do this
***********************************************************/
CREATE FUNCTION [dbo].[fn_DelimitedStringToTable]
(	
    @str VARCHAR(MAX),
    @delimiter CHAR(1)
)
RETURNS @list TABLE(token NVARCHAR(MAX))
AS
BEGIN
        --WHILE LEN(@str) > 0
        --BEGIN
        --    INSERT INTO @list(token)
        --    SELECT left(@str, charindex(@delimiter, @str+',') -1) as token
    
        --    SET @str = stuff(@str, 1, charindex(@delimiter, @str + @delimiter), '')
        --end
	INSERT INTO @list(token)
	SELECT value FROM STRING_SPLIT( @str, @delimiter)
    RETURN 
END
GO
/****** Object:  UserDefinedFunction [dbo].[fn_NumericOnly]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [fn_NumericOnly]
DESCRIPTION:  Strip a string leaving numeric chars only [0-9] and '.'
* CREATED: 10/2021 PCHEN
MODIFICATION HISTORY
***********************************************************/
CREATE Function [dbo].[fn_NumericOnly](@s VARCHAR(max))
RETURNS VARCHAR(max)
AS BEGIN
	DECLARE @rgx VARCHAR(50) = '%[^0-9\.]%'
    WHILE PATINDEX(@rgx, @s) > 0
    BEGIN
        SET @s = STUFF(@s, PATINDEX(@rgx, @s), 1, '')
    END
    RETURN @s
END

/* test *
select [dbo].[fn_NumericOnly]('  asdfa123asdfa.2345.789 mb asdf')
*/
GO
/****** Object:  UserDefinedFunction [dbo].[fn_Project_GetNextNo]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*********************************************************
* PROCEDURE:    [fn_Project_GetNextNo]
* DESCRIPTION:  Get next (ProjectNo) based on RegionCode
* CREATED: 10/21/2021 PCHEN
MODIFICATION HISTORY
1/10/2022 As per ML, US project would have no pre-fix	(1-50 reserved for predefined project)
1/21/2022 Project Prefix defined in [AccountEntity]
***********************************************************/
CREATE FUNCTION [dbo].[fn_Project_GetNextNo] (@AccountingEntityId INT)
RETURNS VARCHAR(10)
AS BEGIN
	DECLARE @MinVal INT = 1, @prefix CHAR(1) = '?'
	SELECT @MinVal = ProjMinNum, @prefix = ProjPrefix FROM AccountingEntity WHERE Id = @AccountingEntityId

	DECLARE @Current VARCHAR(20)
	SELECT @Current = MAX(ProjectNo)
	FROM Project WHERE AccountingEntityId = @AccountingEntityId
	AND ProjectNo LIKE @prefix + '____%' 

	DECLARE @Next INT = CONVERT(INT,  ISNULL([dbo].[fn_NumericOnly](@Current),'0')) + 1
	IF (@MinVal>@Next) SELECT @Next = @MinVal

	RETURN @prefix + RIGHT('0000' + CONVERT(VARCHAR(10), @Next), 5)
END

/** test 
SELECT dbo.fn_Project_GetNextNo(1) AS 'USA (101)'
	, dbo.fn_Project_GetNextNo(2) AS 'Nodus(China)'
	, dbo.fn_Project_GetNextNo(3) AS 'Delego(CAN)'
	, dbo.fn_Project_GetNextNo(4) AS 'IPG (334)'
	, dbo.fn_Project_GetNextNo(5) AS 'Poland (312)'
	, dbo.fn_Project_GetNextNo(6) AS 'Mexico (207)'
	, dbo.fn_Project_GetNextNo(7) AS 'Chile (210)'
select * from Project ORDER BY ProjectNo
*/
GO
/****** Object:  Table [dbo].[AccountingEntity]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AccountingEntity](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[PeriodFirstDay] [int] NOT NULL,
	[ProjPrefix] [varchar](5) NULL,
	[ProjMinNum] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ApplicationLog]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ApplicationLog](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[UserName] [varchar](100) NOT NULL,
	[Message] [varchar](500) NOT NULL,
	[StackTrace] [varchar](max) NOT NULL,
	[OperatingSystem] [varchar](100) NULL,
	[Browser] [varchar](100) NULL,
	[MachineName] [varchar](100) NULL,
	[Date] [datetime] NOT NULL,
 CONSTRAINT [PK_ApplicationLog] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EmailTemplate]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmailTemplate](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[TemplateName] [varchar](250) NOT NULL,
	[EmailSubject] [varchar](250) NOT NULL,
	[EmailContent] [varchar](5000) NOT NULL,
 CONSTRAINT [PK_EmailTemplate] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Employee]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Employee](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [varchar](50) NOT NULL,
	[FirstName] [nvarchar](50) NULL,
	[LastName] [nvarchar](50) NULL,
	[DisplayName] [nvarchar](100) NULL,
	[Email] [varchar](100) NULL,
	[Title] [varchar](100) NULL,
	[JobGradeId] [int] NULL,
	[DeptCode] [varchar](10) NULL,
	[CountryCode] [char](3) NULL,
	[ManagerID] [int] NULL,
	[EmailAlert] [bit] NULL,
	[IsActive] [bit] NOT NULL,
	[CreateDate] [datetime] NULL,
	[CreateBy] [varchar](50) NULL,
	[UpdateDate] [datetime] NULL,
	[UpdateBy] [varchar](50) NULL,
 CONSTRAINT [PK_Employee] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EmployeeActivityMap]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmployeeActivityMap](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeId] [int] NOT NULL,
	[ProjectId] [int] NOT NULL,
	[ActivityId] [int] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreateDate] [datetime] NULL,
	[CreateBy] [varchar](50) NULL,
	[UpdateDate] [datetime] NULL,
	[UpdateBy] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EmployeeRole]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmployeeRole](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeId] [int] NOT NULL,
	[RoleID] [int] NULL,
	[RoleName] [varchar](50) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreateDate] [datetime] NULL,
	[CreateBy] [varchar](50) NULL,
	[UpdateDate] [datetime] NULL,
	[UpdateBy] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Enum]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Enum](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](100) NOT NULL,
	[KeyVal] [varchar](15) NOT NULL,
	[TextVal] [nvarchar](100) NULL,
	[Description] [nvarchar](500) NULL,
	[ParentId] [int] NULL,
	[OrderSeq] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Project]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Project](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](500) NULL,
	[TypeId] [int] NOT NULL,
	[StartDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
	[ProdDate] [datetime] NULL,
	[EstHrs] [int] NULL,
	[ProjectNo] [varchar](20) NULL,
	[PIRNum] [varchar](20) NULL,
	[CountryCode] [char](3) NULL,
	[RequestBy] [varchar](500) NULL,
	[StatusId] [int] NULL,
	[StatusDate] [datetime] NULL,
	[IsPredefined] [bit] NULL,
	[CreateDate] [datetime] NULL,
	[CreateBy] [varchar](50) NULL,
	[UpdateDate] [datetime] NULL,
	[UpdateBy] [varchar](50) NULL,
	[AccountingEntityId] [int] NULL,
	[ParentId] [int] NULL,
 CONSTRAINT [PK_Project] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ProjectActivity]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProjectActivity](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProjectId] [int] NOT NULL,
	[ActivityId] [int] NOT NULL,
	[IsActive] [bit] NULL,
	[CreateDate] [datetime] NULL,
	[CreateBy] [varchar](50) NULL,
	[UpdateDate] [datetime] NULL,
	[UpdateBy] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ProjectTeam]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProjectTeam](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProjectId] [int] NOT NULL,
	[TeamId] [int] NOT NULL,
	[CreateDate] [datetime] NULL,
	[CreateBy] [varchar](50) NULL,
	[UpdateDate] [datetime] NULL,
	[UpdateBy] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Team]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Team](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](200) NOT NULL,
	[ShortName] [nvarchar](50) NOT NULL,
	[DeptCode] [varchar](10) NULL,
	[AccountingEntityId] [int] NULL,
	[ManagerId] [int] NOT NULL,
	[OwnerId] [int] NOT NULL,
	[ParentId] [int] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[CreateBy] [varchar](50) NULL,
	[UpdateDate] [datetime] NOT NULL,
	[UpdateBy] [varchar](50) NULL,
 CONSTRAINT [PK_Team] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TeamEmployee]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TeamEmployee](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[TeamId] [int] NOT NULL,
	[EmployeeId] [int] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreateDate] [datetime] NULL,
	[CreateBy] [varchar](50) NULL,
	[UpdateDate] [datetime] NULL,
	[UpdateBy] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TimesheetActivity]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TimesheetActivity](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeId] [int] NOT NULL,
	[ProjectId] [int] NOT NULL,
	[ActivityId] [int] NOT NULL,
	[ActivityDate] [date] NOT NULL,
	[Hours] [decimal](18, 2) NOT NULL,
	[Description] [nvarchar](4000) NULL,
	[SourceId] [int] NULL,
	[SubmissionId] [int] NULL,
	[CreateDate] [datetime] NULL,
	[CreateBy] [varchar](50) NULL,
	[UpdateDate] [datetime] NULL,
	[UpdateBy] [varchar](50) NULL,
 CONSTRAINT [PK_TimesheetActivity] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TimesheetPeriod]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TimesheetPeriod](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PeriodCode] [varchar](10) NOT NULL,
	[AccountingEntityId] [int] NULL,
	[StartDate] [datetime] NOT NULL,
	[EndDate] [datetime] NOT NULL,
	[StatusId] [int] NULL,
	[CreateDate] [datetime] NULL,
	[CreateBy] [varchar](50) NULL,
	[UpdateDate] [datetime] NULL,
	[UpdateBy] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TimesheetSubmission]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TimesheetSubmission](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeId] [int] NOT NULL,
	[PeriodCode] [varchar](10) NOT NULL,
	[StatusId] [int] NOT NULL,
	[StatusDate] [datetime] NULL,
	[CreateDate] [datetime] NULL,
	[CreateBy] [varchar](50) NULL,
	[UpdateDate] [datetime] NULL,
	[UpdateBy] [varchar](50) NULL,
 CONSTRAINT [PK_TimeSheetSubmission] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[WorkflowHistory]    Script Date: 1/27/2022 5:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[WorkflowHistory](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[WorkflowId] [int] NOT NULL,
	[EntityId] [int] NOT NULL,
	[StatusId] [int] NOT NULL,
	[StatusBy] [varchar](50) NOT NULL,
	[StatusDate] [datetime] NOT NULL,
	[Comment] [nvarchar](500) NULL,
	[PrevHistoryId] [int] NOT NULL,
	[IsCurrent] [bit] NULL,
 CONSTRAINT [PK_WorkflowHistory] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[AccountingEntity] ON 
GO
INSERT [dbo].[AccountingEntity] ([Id], [Name], [PeriodFirstDay], [ProjPrefix], [ProjMinNum]) VALUES (1, N'EVO US (101)', -26, N'U', 1)
GO
INSERT [dbo].[AccountingEntity] ([Id], [Name], [PeriodFirstDay], [ProjPrefix], [ProjMinNum]) VALUES (2, N'Nodus China (118)', -26, N'N', 10000)
GO
INSERT [dbo].[AccountingEntity] ([Id], [Name], [PeriodFirstDay], [ProjPrefix], [ProjMinNum]) VALUES (3, N'Delego (123)', -26, N'C', 11000)
GO
INSERT [dbo].[AccountingEntity] ([Id], [Name], [PeriodFirstDay], [ProjPrefix], [ProjMinNum]) VALUES (4, N'IPG (334)', -26, N'g', 33400)
GO
INSERT [dbo].[AccountingEntity] ([Id], [Name], [PeriodFirstDay], [ProjPrefix], [ProjMinNum]) VALUES (5, N'Poland (312)', -26, N'p', 31200)
GO
INSERT [dbo].[AccountingEntity] ([Id], [Name], [PeriodFirstDay], [ProjPrefix], [ProjMinNum]) VALUES (6, N'Mexico (207)', -26, N'm', 20700)
GO
INSERT [dbo].[AccountingEntity] ([Id], [Name], [PeriodFirstDay], [ProjPrefix], [ProjMinNum]) VALUES (7, N'Chile (210)', -26, N'i', 21000)
GO
SET IDENTITY_INSERT [dbo].[AccountingEntity] OFF
GO
SET IDENTITY_INSERT [dbo].[ApplicationLog] ON 
GO
INSERT [dbo].[ApplicationLog] ([Id], [UserName], [Message], [StackTrace], [OperatingSystem], [Browser], [MachineName], [Date]) VALUES (1, N'paul.rao', N'test', N'', N'Unknown', N'Chrome', N'US002-XN-0023', CAST(N'2022-01-06T15:35:24.893' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[ApplicationLog] OFF
GO
SET IDENTITY_INSERT [dbo].[Employee] ON 
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1, N'ts_superuser', N'Super', N'User', N'Super User', N'paul.chen@evopayments.com', N'Admin', 0, N'', N'   ', 0, 1, 1, CAST(N'2021-12-09T18:14:30.490' AS DateTime), N'system', CAST(N'2021-12-15T15:09:08.540' AS DateTime), N'ts_superuser')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (2, N'michaelre', N'Michael', N'Reidenbach', N'Michael Reidenbach', N'Dino.Liu@evopayments.com', N'IT Executive', 12, N'0', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:14:58.520' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:14:58.520' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (3, N'Andrew.Diamond', N'Andrew', N'Diamond', N'Andrew Jay Diamond', N'Dino.Liu@evopayments.com', N'Team Owner', 12, N'257', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (4, N'Andy.Funk', N'Andrew', N'Funk', N'Andrew Claiborne Funk', N'Dino.Liu1@evopayments.com', N'Team Owner', 10, N'706', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (5, N'stevep', N'Steven', N'Pracilio', N'Steven P Pracilio', N'Dino.Liu2@evopayments.com', N'Team Owner', 12, N'706', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (6, N'li.zhang', N'Richard', N'Zhang', N'Richard Zhang', N'richard.zhang@evopayments.com', N'TeamOwner', 9, N'707', N'CHN', 2, 1, 1, CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport', CAST(N'2021-12-16T06:36:11.517' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (7, N'SteveM', N'Steven', N'Magara', N'Steven F Magara', N'Dino.Liu@evopayments.com', N'Team Owner', 10, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (8, N'scottl', N'Scott', N'Labrash', N'Scott A Labrash', N'Dino.Liu@evopayments.com', N'Team Owner', 12, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (9, N'Jingjing.hu', N'Jing Jing', N'Hu', N'Jing Jing Hu', N'Dino.Liu@evopayments.com', N'Team Owner', 8, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (10, N'scott.baker', N'Scott', N'Baker', N'Scott R Baker', N'Dino.Liu@evopayments.com', N'Team Owner', 10, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (11, N'Maiseyl', N'Maisey', N'Liu', N'Maisey Liu', N'maisey.liu@evopayments.com', N'Admin', 0, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport', CAST(N'2021-12-15T16:19:57.893' AS DateTime), N'Maiseyl')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (12, N'Craig.Lehtovaara', N'Craig', N'Lehtovaara', N'Craig Thomas Lehtovaara', N'Dino.Liu@evopayments.com', N'Team Owner', 11, N'723', N'CAN', 0, 1, 1, CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.590' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (13, N'Hua.Deng', N'Edward', N'Deng', N'Edward Deng', N'Dino.Liu@evopayments.com', N'Manager', 6, N'257', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (14, N'haisong.jia', N'Haisong', N'Jia', N'Haisong Jia', N'haisong.jia@evopayments.com', N'Employee', 0, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-17T01:10:41.540' AS DateTime), N'haisong.jia')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (15, N'liang.zhao', N'Jason', N'Zhao', N'Jason Zhao', N'jason.zhao@evopayments.com', N'Manager', 0, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-17T01:08:01.180' AS DateTime), N'liang.zhao')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (16, N'rui.wang', N'Ray', N'Wang', N'Ray Wang', N'ray.wang@evopayments.com', N'Manager', 0, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-17T01:13:35.447' AS DateTime), N'rui.wang')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (17, N'Michelle', N'Michelle', N'Mazza-Branyan', N'Michelle A Mazza-Branyan', N'Dino.Liu@evopayments.com', N'Manager', 8, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (18, N'RobertS', N'Robert', N'Spracklin', N'Robert W Spracklin', N'Dino.Liu@evopayments.com', N'Manager', 9, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (19, N'Donald.Poletti', N'Don', N'Poletti', N'Don Poletti', N'Dino.Liu@evopayments.com', N'Manager', 8, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (20, N'bonniec', N'Bonnie', N'Chokr', N'Bonnie L Chokr', N'Dino.Liu@evopayments.com', N'Manager', 10, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (21, N'darrena', N'DARREN', N'ADELGREN', N'DARREN W ADELGREN', N'Dino.Liu@evopayments.com', N'Manager', 13, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (22, N'Harlan.Mott', N'Harlan', N'Mott', N'Harlan Mott', N'Dino.Liu@evopayments.com', N'Manager', 10, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (23, N'yaping.wu', N'Rena', N'Wu', N'Rena Wu', N'Dino.Liu@evopayments.com', N'Manager', 6, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (24, N'Jeffrey.Hanson', N'Jeffrey', N'Hanson', N'Jeffrey G Hanson', N'Dino.Liu@evopayments.com', N'Manager', 8, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (25, N'Lawrence.Moore', N'Lawrence', N'Moore', N'Lawrence Moore', N'Dino.Liu@evopayments.com', N'Manager', 8, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (26, N'Abdulk', N'Abdul', N'Khan', N'Abdul Khan', N'Dino.Liu@evopayments.com', N'Manager', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (27, N'Kiran.Nagpaul', N'Kiran', N'Nagpaul', N'Kiran Nagpaul', N'Dino.Liu@evopayments.com', N'Manager', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (28, N'Sivagamia', N'Sivagami', N'Annamalai', N'Sivagami Annamalai', N'Dino.Liu@evopayments.com', N'Manager', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (29, N'Mansoor.Khan', N'Mansoor', N'Khan', N'Mansoor Khan', N'Dino.Liu@evopayments.com', N'Manager', 6, N'723', N'CAN', 0, 1, 1, CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.960' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (30, N'Kai.Chen', N'Kallen', N'Chen', N'Kallen Chen', N'Dino.Liu@evopayments.com', N'Resource', 5, N'257', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (31, N'Shuangyu.Zhu', N'Josh', N'Zhu', N'Josh Zhu', N'Dino.Liu@evopayments.com', N'Resource', 5, N'257', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (32, N'Daphne.Walker', N'Daphne', N'Walker', N'Daphne Walker', N'Dino.Liu@evopayments.com', N'Resource', 5, N'706', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (33, N'daveg', N'David', N'Greene', N'David A Greene', N'Dino.Liu@evopayments.com', N'Resource', 10, N'706', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (34, N'David.Gerlach', N'David', N'Gerlach', N'David Gerlach', N'Dino.Liu@evopayments.com', N'Resource', 5, N'706', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (35, N'jasonb', N'Jason', N'Beck', N'Jason L Beck', N'Dino.Liu@evopayments.com', N'Resource', 5, N'706', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (36, N'Lance.Newalu', N'Lance', N'Newalu', N'Lance Newalu', N'Dino.Liu@evopayments.com', N'Resource', 5, N'706', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (37, N'michaelt', N'Michael', N'Tingle', N'Michael R Tingle', N'Dino.Liu@evopayments.com', N'Resource', 9, N'706', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (38, N'Raymond.Haller', N'Raymond', N'Haller', N'Raymond Alexander Haller', N'Dino.Liu@evopayments.com', N'Resource', 4, N'706', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (39, N'Rondall.James', N'Rondall', N'James', N'Rondall James', N'Dino.Liu@evopayments.com', N'Resource', 6, N'706', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (40, N'Simona.Tashkovska', N'Simona', N'Tashkovska', N'Simona Jovanovska Tashkovska', N'Dino.Liu@evopayments.com', N'Resource', 5, N'706', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (41, N'Kyana.Hall', N'Kyanna', N'Hall', N'Kyanna Hall', N'Dino.Liu@evopayments.com', N'Resource', 0, N'706', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (42, N'Serhiv.Pavlov', N'Serhiv ', N'Pavlov', N'Serhiv  Pavlov', N'Dino.Liu@evopayments.com', N'Resource', 0, N'706', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (43, N'andrew.zhang', N'Andrew', N'Zhang', N'Andrew Zhang', N'paul.chen@evopayments.com', N'Employee', 6, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-16T01:39:34.743' AS DateTime), N'li.zhang')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (44, N'biao.shang', N'Peter', N'Shang', N'Peter Shang', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (45, N'bob.shen', N'Bob', N'Shen', N'Bob Shen', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (46, N'congxi.liu', N'Kevin', N'Liu', N'Kevin Liu', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (47, N'Dexter.Zhao', N'Xiaoxiang', N'Zhao', N'Xiaoxiang Zhao', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (48, N'dongdong.zhang', N'Jack', N'Zhang', N'Jack Zhang', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (49, N'dongming.hu', N'Dongming', N'Hu', N'Dongming Hu', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (50, N'edison.chen', N'Edison', N'Chen', N'Edison Chen', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (51, N'feng.zhang', N'Feng', N'Zhang', N'Feng Zhang', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (52, N'fuen.wu', N'Fuen', N'Wu', N'Fuen Wu', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (53, N'gerry.deng', N'Gerry', N'Deng', N'Gerry Deng', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (54, N'Guangze.Chen', N'Guangze', N'Chen', N'Guangze Chen', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (55, N'guanjun.zhu', N'Guanjun', N'Zhu', N'Guanjun Zhu', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (56, N'jia.yang', N'Jia', N'Yang', N'Jia Yang', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (57, N'jin.xie', N'Xie', N'Jin', N'Xie Jin', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (58, N'jinye.han', N'Kit', N'Han', N'Kit Han', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (59, N'Jun.Pan', N'James', N'Pan', N'James Pan', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (60, N'kuo.wang', N'Kuo', N'Wang', N'Kuo Wang', N'kuo.wang@evopayments.com', N'Employee', 5, N'707', N'CHN', 15, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2022-01-07T02:02:12.860' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (61, N'martin.ma', N'Martin', N'Ma', N'Martin Ma', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (62, N'meng.chang', N'Connor', N'Chang', N'Connor Chang', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (63, N'minghao.tan', N'Reggie', N'Tan', N'Reggie Tan', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (64, N'Qinglong.Qian', N'Tony', N'Qian', N'Tony Qian', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (65, N'seven.qian', N'Seven', N'Qian', N'Seven Qian', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (66, N'shiying.song', N'Shiying', N'Song ', N'Shiying Song ', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (67, N'Shuai.Li', N'Owen', N'Li', N'Owen Li', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (68, N'Taojie.Ji', N'Taojie', N'Ji', N'Taojie Ji', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (69, N'wenxiang.jiang', N'Ben', N'Jiang', N'Ben Jiang', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (70, N'Xiaofeng.Wang', N'Jim', N'Wang', N'Jim Wang', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (71, N'xiaoqi.fang', N'Gigi', N'Fang', N'Gigi Fang', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (72, N'xuefei.liu', N'Phil', N'Liu', N'Phil Liu', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (73, N'xuhui.cao', N'Benjamin', N'Cao', N'Benjamin Cao', N'Dino.Liu@evopayments.com', N'Resource', 4, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (74, N'yanjun.he', N'Leo', N'He', N'Leo He', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (75, N'zhilong.zhang', N'Nick', N'Zhang', N'Nick Zhang', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (76, N'marisao', N'Marisa', N'Pracilio', N'Marisa Pracilio', N'Dino.Liu@evopayments.com', N'Resource', 7, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (77, N'VaseyS', N'Vasey', N'Salagbi', N'Vasey Salagbi', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (78, N'AndyG', N'Andy', N'Gurzynski', N'Andy Gurzynski', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (79, N'shofiurR', N'Shofiur', N'Rahman', N'Shofiur Rahman', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (80, N'LakshmiN', N'Lakshmi', N'Narayanan', N'Lakshmi Narayanan', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (81, N'LavanyaK', N'Lavanya', N'Kudumula', N'Lavanya Kudumula', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (82, N'ConnieB', N'Connie', N'Hougardy-Brown', N'Connie Hougardy-Brown', N'Dino.Liu@evopayments.com', N'Resource', 2, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (83, N'MeeraB', N'Meera', N'Badri', N'Meera Badri', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (84, N'KabithaC', N'Kabitha', N'Chirasani', N'Kabitha Chirasani', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (85, N'archanar', N'Archana', N'Rastogi', N'Archana Rastogi', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (86, N'Michael.Granovski', N'Michael', N'Granovski', N'Michael Granovski', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (87, N'Kenneth.Klein', N'Kenneth', N'Klein', N'Kenneth P Klein', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (88, N'May.Ho', N'May', N'Ho', N'May Fong Ho', N'Dino.Liu@evopayments.com', N'Resource', 4, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (89, N'Marilyn.Tambe', N'Marilyn', N'Tambe', N'Marilyn E Tambe', N'Dino.Liu@evopayments.com', N'Resource', 2, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (90, N'mgrover', N'Marc', N'Grover', N'Marc A Grover', N'Dino.Liu@evopayments.com', N'Resource', 7, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (91, N'NickR', N'Nicholas', N'Redzinak', N'Nicholas P Redzinak', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (92, N'SureshK', N'Suresh', N'Karanam Laxmi', N'Suresh Karanam Laxmi', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (93, N'Sanjay.Patil', N'Sanjay', N'Patil', N'Sanjay J Patil', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (94, N'Hung.Tran', N'Hung', N'Tran', N'Hung Phuoc Tran', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (95, N'bac.bui', N'Bac', N'Bui', N'Bac Bui', N'Dino.Liu@evopayments.com', N'Resource', 6, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (96, N'Kirthi.Karan', N'Kirthi', N'Karan', N'Kirthi Karan', N'Dino.Liu@evopayments.com', N'Resource', 5, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (97, N'Michael.Daigh', N'Michael', N'Daigh', N'Michael Daigh', N'Dino.Liu@evopayments.com', N'Resource', 4, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (98, N'Shaun.Sharples', N'Shaun', N'Sharples', N'Shaun Sharples', N'Dino.Liu@evopayments.com', N'Resource', 7, N'707', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (99, N'Anthony.Chiesi', N'Anthony', N'Chiesi', N'Anthony D Chiesi', N'Dino.Liu@evopayments.com', N'Resource', 7, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (100, N'Charles.Walkowiak', N'Charles', N'Walkowiak', N'Charles Walkowiak', N'Dino.Liu@evopayments.com', N'Resource', 9, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (101, N'christaf', N'Christa', N'Ferguson', N'Christa M Ferguson', N'Dino.Liu@evopayments.com', N'Resource', 6, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (102, N'Corey.Westcott', N'Corey', N'Westcott', N'Corey Westcott', N'Dino.Liu@evopayments.com', N'Resource', 6, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (103, N'Debra.Kruse', N'Debra', N'Kruse', N'Debra Kruse', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (104, N'jaimeb', N'Jaime', N'Brown', N'Jaime L Brown', N'Dino.Liu@evopayments.com', N'Resource', 4, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (105, N'Jason.Lawrence', N'Jason', N'Lawrence', N'Jason Lawrence', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (106, N'jeannineg', N'Jeannine', N'Lee', N'Jeannine Lee', N'Dino.Liu@evopayments.com', N'Resource', 7, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (107, N'Justin.Gogas', N'Justin', N'Gogas', N'Justin Gogas', N'Dino.Liu@evopayments.com', N'Resource', 5, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (108, N'Kevin.Winn', N'Kevin', N'Winn', N'Kevin M Winn', N'Dino.Liu@evopayments.com', N'Resource', 4, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (109, N'Marcos.Guevara', N'Marcos', N'Guevara', N'Marcos Guevara', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (110, N'markma', N'Mark', N'Malinowski', N'Mark Malinowski', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (111, N'Mattch', N'Matthew', N'Christy', N'Matthew Christy', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (112, N'Alex.Pigford', N'Michel', N'Pigford', N'Michel A Pigford', N'Dino.Liu@evopayments.com', N'Resource', 4, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (113, N'Nicole.Hall', N'Nicole', N'Hall', N'Nicole Hall', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (114, N'Noemi.Salazar', N'Noemi', N'Salazar Caballero', N'Noemi Salazar Caballero', N'Dino.Liu@evopayments.com', N'Resource', 8, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (115, N'Victor.Brown', N'Victor', N'Brown', N'Victor Brown', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (116, N'Yazeed.Haris', N'Yazeed', N'Haris', N'Yazeed K Haris', N'Dino.Liu@evopayments.com', N'Resource', 4, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (117, N'Zoey.Green', N'Zoey', N'Green', N'Zoey Green', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (118, N'Elena.Romanova', N'Elena', N'Romanova', N'Elena Romanova', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (119, N'Alex.Wang', N'Alex', N'Wang', N'Alex Wang', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (120, N'Ricol.Wang', N'Ricol', N'Wang', N'Ricol Wang', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (121, N'David.Cooney', N'David', N'Cooney', N'David Cooney', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'IRL', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (122, N'Eoin.OLeary', N'Eoin', N'O''Leary', N'Eoin O''Leary', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (123, N'Glenn.Preston', N'Glenn', N'Preston', N'Glenn Preston', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'IRL', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (124, N'Linda.Vickerman', N'Linda', N'Vickerman', N'Linda Vickerman', N'Dino.Liu@evopayments.com', N'Resource', -1, N'708', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (125, N'Chun.Wang', N'Truman', N'Wang', N'Truman Wang', N'Dino.Liu@evopayments.com', N'Resource', 3, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (126, N'Chunyan.Lu', N'Chunyan', N'Lu', N'Chunyan Lu', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (127, N'Fen.Wang', N'Arya', N'Wang', N'Arya Wang', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (128, N'Haiyan.Zhang', N'Haiyan', N'Zhang', N'Haiyan Zhang', N'Dino.Liu@evopayments.com', N'Resource', 5, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (129, N'Hanming.Mao', N'Kelly', N'Mao', N'Kelly Mao', N'Dino.Liu@evopayments.com', N'Resource', 3, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (130, N'Hannah.Wang', N'Hannah', N'Wang', N'Hannah Wang', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (131, N'jianhua.yi', N'Grace', N'Yi', N'Grace Yi', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (132, N'Jonathan.Duong', N'Jonathan', N'Duong', N'Jonathan Duong', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (133, N'Ling.Xu', N'Ling', N'Xu', N'Ling Xu', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (134, N'Lucy.Peng', N'Lucy', N'Peng', N'Lucy Peng', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (135, N'meijuan.shi', N'Sophia', N'Shi', N'Sophia Shi', N'Dino.Liu@evopayments.com', N'Resource', 5, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (136, N'Mengying.Zhang', N'Nancy', N'Zhang', N'Nancy Zhang', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (137, N'Qinhua.Rui', N'Ana', N'Rui', N'Ana Rui', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (138, N'Qiumeng.Dai', N'Riven', N'Dai', N'Riven Dai', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (139, N'Shiying.Dai', N'Elaine', N'Dai', N'Elaine Dai', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (140, N'Summer.Chen', N'Summer', N'Chen', N'Summer Chen', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (141, N'xiaoxuan.ji', N'Jessica', N'Ji', N'Jessica Ji', N'Dino.Liu@evopayments.com', N'Resource', 5, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (142, N'Xiaoya.Qian', N'Hammer', N'Qian', N'Hammer Qian', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (143, N'Xiaoyan.Liu', N'Xiaoyan', N'Liu', N'Xiaoyan Liu', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (144, N'ying.xu', N'Vicky', N'Xu', N'Vicky Xu', N'Dino.Liu@evopayments.com', N'Resource', 5, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (145, N'yuan.chen', N'Candice', N'Chen', N'Candice Chen', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (146, N'Yuan.Qiu', N'Elva', N'Qiu', N'Elva Qiu', N'Dino.Liu@evopayments.com', N'Resource', 4, N'714', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (147, N'Alexandre.Seite', N'Alexandre', N'Seite', N'Alexandre Seite', N'Dino.Liu@evopayments.com', N'Resource', 5, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (148, N'Cheryl.Cook', N'Cheryl', N'Cook', N'Cheryl L Cook', N'Dino.Liu@evopayments.com', N'Resource', 4, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (149, N'Debra.Karavas', N'Debra', N'Karavas', N'Debra Lynn Karavas', N'Dino.Liu@evopayments.com', N'Resource', 4, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (150, N'Eugene.Holman', N'Eugene', N'Holman', N'Eugene A Holman', N'Dino.Liu@evopayments.com', N'Resource', 5, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (151, N'GSchuerman', N'Greg', N'Schuerman', N'Greg Schuerman', N'Dino.Liu@evopayments.com', N'Resource', 5, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (152, N'hclukey', N'Harleigh', N'Clukey', N'Harleigh Clukey', N'Dino.Liu@evopayments.com', N'Resource', 6, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (153, N'Jeremy.Wead', N'Jeremy', N'Wead', N'Jeremy P Wead', N'Dino.Liu@evopayments.com', N'Resource', 4, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (154, N'John.Frost', N'John', N'Frost', N'John Frost', N'Dino.Liu@evopayments.com', N'Resource', 6, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (155, N'Laura.Cardenas', N'Laura', N'Cardenas', N'Laura Cardenas', N'Dino.Liu@evopayments.com', N'Resource', 4, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (156, N'Mary.OMalley', N'Mary', N'O''Malley', N'Mary R O''Malley', N'Dino.Liu@evopayments.com', N'Resource', 5, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (157, N'Michael.Hansen', N'Michael', N'Hansen', N'Michael P Hansen', N'Dino.Liu@evopayments.com', N'Resource', 5, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (158, N'Sree.Chalasani', N'Sreelakshmi', N'Chalasani', N'Sreelakshmi Chalasani', N'Dino.Liu@evopayments.com', N'Resource', 7, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (159, N'Tejaswini.Pulivarthi', N'Tejaswini', N'Pulivarthi', N'Tejaswini Pulivarthi', N'Dino.Liu@evopayments.com', N'Resource', 5, N'718', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (160, N'Robert.Hermann', N'Robert', N'Hermann', N'Robert Hermann', N'Dino.Liu@evopayments.com', N'Resource', 0, N'719', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (161, N'Atikur.Rahman', N'Atikur', N'Rahman', N'Atikur Rahman', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (162, N'Cynthiaw', N'Cynthia', N'Wolfe', N'Cynthia Wolfe', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (163, N'Mohammedm', N'Mohammed', N'Mehraz', N'Mohammed Mehraz', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (164, N'takiam', N'Takia', N'Munni', N'Takia Munni', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (165, N'Zakaria.maliashvili', N'Zakaria', N'Maliashvili ', N'Zakaria Maliashvili ', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (166, N'dino.liu', N'Dino', N'Liu', N'Dino1 Liu1', N'Dino.Liu@evopayments.com', N'Admin', 0, N'724', N'CHN', 0, 0, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2022-01-25T02:03:22.157' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (167, N'Eugeneg', N'Eugene', N'Gruzin', N'Eugene Gruzin', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (168, N'Jayeshj', N'Jayesh', N'Jayadevan', N'Jayesh Jayadevan', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (169, N'Joy.han', N'Joy', N'Han', N'Joy Han', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (170, N'joy.jing', N'Joy', N'Jing', N'Joy Jing', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'CHN', 0, 1, 0, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2022-01-10T01:01:51.787' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (171, N'lakshay.puniani', N'Lakshay', N'Puniani', N'Lakshay Puniani', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (172, N'paul.chen', N'Paul', N'Chen', N'Paul Chen', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (173, N'paul.rao', N'Paul', N'Rao', N'Paul Rao', N'paul.rao@evopayments.com', N'Admin', 0, N'724', N'CHN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-16T00:52:25.777' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (174, N'Pooja.Sabharwal', N'Pooja', N'Sabharwal', N'Pooja Sabharwal', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (175, N'Ruslanm', N'Ruslan', N'Manedyarov', N'Ruslan Manedyarov', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (176, N'venkatac', N'Venkata', N'Chittabathini', N'Venkata Chittabathini', N'Dino.Liu@evopayments.com', N'Resource', 6, N'724', N'USA', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (177, N'Colin.Stranc', N'Colin', N'Stranc', N'Colin MacKenzie Stranc', N'Dino.Liu@evopayments.com', N'Resource', 4, N'723', N'CAN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (178, N'Derek.Lo', N'Wing Hong Derek', N'Lo', N'Wing Hong Derek Lo', N'Dino.Liu@evopayments.com', N'Resource', 4, N'723', N'CAN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (179, N'Gilad.Israeli', N'Gilad', N'Israeli', N'Gilad Israeli', N'Dino.Liu@evopayments.com', N'Resource', 5, N'723', N'CAN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (180, N'Hani.Hassanain', N'Hani', N'Hassanain', N'Hani Mohammed Moein Hassanain', N'Dino.Liu@evopayments.com', N'Resource', 4, N'723', N'CAN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (181, N'Nevin.Huynh', N'Nevin', N'Huynh', N'Nevin Huynh', N'Dino.Liu@evopayments.com', N'Resource', -1, N'723', N'CAN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (182, N'Ramesh.Sud', N'Ramesh', N'Sud', N'Ramesh Alexander Singh Sud', N'Dino.Liu@evopayments.com', N'Resource', 4, N'723', N'CAN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (183, N'Vinay.Sidhu', N'Vinay', N'Sidhu', N'Vinay Sidhu', N'Dino.Liu@evopayments.com', N'Resource', 4, N'723', N'CAN', 0, 1, 1, CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.577' AS DateTime), N'batchimport')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (184, N'ba.u1', N'BA-ResourceOne', N'DummyBAU1', N'BA-ResourceOne DummyBAU1', N'Kiran.Nagpaul@evopayments.com', N'Employee', 7, NULL, N'USA', 27, 1, 0, CAST(N'2021-12-13T20:52:46.300' AS DateTime), N'ts_superuser', CAST(N'2022-01-12T15:32:41.537' AS DateTime), N'maiseyl')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (185, N'ba.m1', N'BA-ManagerOne', N'DummyBAM1', N'BA-ManagerOne DummyBAM1', N'Kiran.Nagpaul@evopayments.com', N'Manager', 8, NULL, N'CHN', 186, 1, 1, CAST(N'2021-12-14T21:02:42.670' AS DateTime), N'ba.m1', CAST(N'2022-01-12T15:34:36.160' AS DateTime), N'maiseyl')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (186, N'SA_TS_ML', N'Maisey', N'Liu', N'Maisey Liu', N'Eugene.Gruzin@evopayments.com', N'TeamOwner', 0, NULL, NULL, NULL, 1, 1, CAST(N'2021-12-14T21:03:07.983' AS DateTime), N'SA_TS_ML', CAST(N'2021-12-15T17:44:48.033' AS DateTime), N'SA_TS_ML')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (187, N'AR_TS_Timesheet_Admin', N'Atik_TS', N'Timesheet_Admin', N'Atik_TS Timesheet_Admin', N'atikur.rahman@evopayments.com', N'TimesheetAdmin', 0, NULL, NULL, NULL, 1, 1, CAST(N'2021-12-15T16:54:50.450' AS DateTime), N'AR_TS_Timesheet_Admin', CAST(N'2021-12-15T16:54:50.450' AS DateTime), N'AR_TS_Timesheet_Admin')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (188, N'SA_TS_Project_admin', N'Sivagami', N'Project Admin', N'Sivagami Project Admin', N'atikur.rahman@evopayments.com', N'ProjectAdmin', 0, NULL, NULL, NULL, 1, 1, CAST(N'2021-12-15T17:04:01.537' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-15T17:04:01.537' AS DateTime), N'SA_TS_Project_admin')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (189, N'akhan', N'Abdul', N'Khan', N'Abdul Khan', N'abdul.khan@evopayments.com', N'ITExecutive', 0, NULL, NULL, NULL, 1, 1, CAST(N'2021-12-15T17:08:50.060' AS DateTime), N'akhan', CAST(N'2021-12-15T17:08:50.060' AS DateTime), N'akhan')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (190, N'TA.M1', N'Mgr1', N'TeamA', N'Mgr1 TeamA', N'paul.chen@evopayments.com', N'Manager', 0, NULL, NULL, NULL, 1, 1, CAST(N'2021-12-17T01:03:42.710' AS DateTime), N'TA.M1', CAST(N'2021-12-17T01:03:42.710' AS DateTime), N'TA.M1')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (191, N'Xiaochun.Li', N'XiaoChun', N'LI', N'XiaoChun LI', N'Xiaochun.Li@evopayments.com', N'44', 6, NULL, N'CHN', 119, 0, 0, CAST(N'2021-12-29T02:38:53.250' AS DateTime), N'dino.liu', CAST(N'2021-12-29T02:39:09.640' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (192, N'ba.u2', N'BA-ResourceTwo', N'DummyBAU2', N'BA-ResourceTwo DummyBAU2', N'Kiran.Nagpaul@evopayments.com', N'Employee', 5, NULL, N'MEX', 27, 0, 1, CAST(N'2022-01-12T15:26:47.677' AS DateTime), N'ba.u2', CAST(N'2022-01-12T15:34:50.520' AS DateTime), N'maiseyl')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (193, N'AR_TS_Temp', N'Temp', N'_User', N'Temp _User', N'atikur.rahman@evopayments.com', N'333', 1, NULL, N'CAN', 189, 0, 1, CAST(N'2022-01-13T01:59:56.333' AS DateTime), N'dino.liu', CAST(N'2022-01-13T01:59:56.333' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[Employee] ([Id], [UserID], [FirstName], [LastName], [DisplayName], [Email], [Title], [JobGradeId], [DeptCode], [CountryCode], [ManagerID], [EmailAlert], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (194, N'AR_TS_IT_exes', N'Atik_TS', N'IT_exes', N'Atik_TS IT_exes', N'atikur.rahman@evopayments.com', N'ITExecutive', 0, NULL, NULL, NULL, 0, 1, CAST(N'2022-01-26T14:34:34.097' AS DateTime), N'AR_TS_IT_exes', CAST(N'2022-01-26T14:34:34.097' AS DateTime), N'AR_TS_IT_exes')
GO
SET IDENTITY_INSERT [dbo].[Employee] OFF
GO
SET IDENTITY_INSERT [dbo].[EmployeeActivityMap] ON 
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (10, 0, 3, 8, 1, CAST(N'2021-12-15T01:34:16.537' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (50, 3, 1, 8, 1, CAST(N'2021-12-23T22:10:52.990' AS DateTime), N'paul.rao', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (46, 3, 2, 8, 1, CAST(N'2021-12-17T02:05:38.383' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (51, 3, 4, 8, 1, CAST(N'2021-12-23T22:11:51.880' AS DateTime), N'paul.rao', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (17, 4, 1, 8, 0, CAST(N'2021-12-15T02:35:59.990' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (35, 4, 2, 8, 1, CAST(N'2021-12-16T22:13:12.310' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (29, 6, 1, 8, 1, CAST(N'2021-12-16T01:01:35.177' AS DateTime), N'li.zhang', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (30, 6, 2, 8, 0, CAST(N'2021-12-16T22:02:14.413' AS DateTime), N'li.zhang', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (40, 6, 4, 8, 1, CAST(N'2021-12-17T00:54:53.630' AS DateTime), N'li.zhang', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (74, 12, 16, 8, 1, CAST(N'2022-01-10T01:29:29.070' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (61, 15, 9, 1, 1, CAST(N'2022-01-06T00:08:51.137' AS DateTime), N'liang.zhao', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (82, 15, 65, 2, 1, CAST(N'2022-01-14T01:15:56.573' AS DateTime), N'liang.zhao', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (49, 16, 2, 8, 1, CAST(N'2021-12-19T20:41:36.767' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (67, 20, 17, 8, 1, CAST(N'2022-01-10T01:27:51.210' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (77, 21, 4, 8, 1, CAST(N'2022-01-10T01:36:31.087' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (42, 26, 1, 8, 0, CAST(N'2021-12-17T01:22:16.150' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (39, 26, 2, 8, 0, CAST(N'2021-12-17T00:53:44.257' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (43, 26, 3, 8, 0, CAST(N'2021-12-17T01:51:19.800' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (44, 26, 4, 8, 0, CAST(N'2021-12-17T01:52:09.880' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (41, 26, 6, 7, 1, CAST(N'2021-12-17T01:03:13.787' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (76, 32, 4, 8, 1, CAST(N'2022-01-10T01:36:18.760' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (78, 33, 3, 8, 1, CAST(N'2022-01-10T01:36:41.117' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (80, 34, 3, 8, 1, CAST(N'2022-01-10T01:37:07.257' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (27, 43, 1, 8, 0, CAST(N'2021-12-15T15:12:23.710' AS DateTime), N'andrew.zhang', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (31, 43, 2, 8, 0, CAST(N'2021-12-16T22:04:01.150' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (47, 43, 4, 8, 1, CAST(N'2021-12-17T02:48:29.587' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (48, 45, 1, 8, 1, CAST(N'2021-12-19T20:39:12.797' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (18, 60, 1, 8, 0, CAST(N'2021-12-15T02:38:20.523' AS DateTime), N'kuo.wang', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (20, 60, 2, 8, 0, CAST(N'2021-12-15T03:02:11.137' AS DateTime), N'kuo.wang', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (19, 60, 3, 8, 0, CAST(N'2021-12-15T02:40:44.623' AS DateTime), N'kuo.wang', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (22, 60, 4, 8, 0, CAST(N'2021-12-15T03:10:40.300' AS DateTime), N'kuo.wang', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (23, 60, 5, 8, 0, CAST(N'2021-12-15T03:16:59.447' AS DateTime), N'kuo.wang', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (83, 60, 76, 4, 1, CAST(N'2022-01-14T01:16:43.573' AS DateTime), N'kuo.wang', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (72, 62, 17, 8, 1, CAST(N'2022-01-10T01:29:07.180' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (65, 69, 1, 8, 1, CAST(N'2022-01-10T01:27:06.710' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (66, 73, 17, 8, 1, CAST(N'2022-01-10T01:27:21.617' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (62, 78, 2, 8, 1, CAST(N'2022-01-10T01:22:32.707' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (71, 82, 17, 8, 1, CAST(N'2022-01-10T01:28:55.880' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (32, 85, 1, 8, 1, CAST(N'2021-12-16T22:09:33.480' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (64, 95, 18, 8, 1, CAST(N'2022-01-10T01:26:55.897' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (63, 99, 5, 8, 1, CAST(N'2022-01-10T01:22:57.317' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (13, 100, 2, 8, 1, CAST(N'2021-12-15T01:54:47.793' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (45, 101, 3, 8, 1, CAST(N'2021-12-17T02:00:12.427' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (73, 102, 17, 8, 1, CAST(N'2022-01-10T01:29:17.290' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (52, 103, 1, 8, 1, CAST(N'2021-12-24T00:52:29.747' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (53, 103, 2, 8, 1, CAST(N'2021-12-24T00:52:45.747' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (54, 103, 3, 8, 1, CAST(N'2021-12-24T00:56:30.623' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (38, 119, 1, 8, 0, CAST(N'2021-12-16T22:20:01.427' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (28, 119, 2, 8, 0, CAST(N'2021-12-16T00:31:05.930' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (36, 119, 3, 8, 1, CAST(N'2021-12-16T22:14:43.970' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (33, 119, 4, 8, 0, CAST(N'2021-12-16T22:12:08.687' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (37, 119, 5, 8, 0, CAST(N'2021-12-16T22:16:35.003' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (79, 121, 17, 8, 1, CAST(N'2022-01-10T01:36:55.290' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (69, 126, 16, 8, 1, CAST(N'2022-01-10T01:28:31.430' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (14, 127, 1, 8, 1, CAST(N'2021-12-15T02:25:30.037' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (60, 137, 1, 8, 1, CAST(N'2021-12-24T03:15:41.650' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (11, 137, 2, 8, 0, CAST(N'2021-12-15T01:35:57.877' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (21, 137, 3, 8, 1, CAST(N'2021-12-15T03:03:30.327' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (59, 137, 4, 8, 1, CAST(N'2021-12-24T03:15:18.070' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (57, 137, 5, 8, 1, CAST(N'2021-12-24T03:14:58.087' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (12, 145, 2, 8, 1, CAST(N'2021-12-15T01:53:03.473' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (16, 147, 1, 8, 0, CAST(N'2021-12-15T02:31:10.470' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (56, 147, 2, 8, 1, CAST(N'2021-12-24T03:14:38.070' AS DateTime), N'paul.rao', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (58, 147, 3, 8, 0, CAST(N'2021-12-24T03:15:02.507' AS DateTime), N'paul.rao', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (34, 147, 5, 8, 0, CAST(N'2021-12-16T22:12:43.263' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (68, 148, 18, 8, 1, CAST(N'2022-01-10T01:28:15.430' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (81, 149, 3, 8, 1, CAST(N'2022-01-10T01:37:30.697' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (55, 161, 1, 8, 1, CAST(N'2021-12-24T02:48:21.037' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (75, 162, 1, 8, 1, CAST(N'2022-01-10T01:29:42.460' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (7, 166, 1, 8, 0, CAST(N'2021-12-14T08:52:36.807' AS DateTime), N'Dino  Liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (8, 166, 2, 8, 1, CAST(N'2021-12-14T03:55:02.713' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (9, 166, 3, 8, 1, CAST(N'2021-12-14T03:56:14.747' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (6, 166, 6, 7, 1, CAST(N'2021-12-14T08:49:12.410' AS DateTime), N'Dino  Liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (15, 169, 6, 7, 1, CAST(N'2021-12-15T02:26:07.850' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (2, 173, 1, 8, 1, CAST(N'2021-12-14T02:03:06.887' AS DateTime), N'Paul  Rao', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (3, 173, 2, 8, 1, CAST(N'2021-12-14T03:35:00.920' AS DateTime), N'Paul  Rao', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (5, 173, 3, 8, 1, CAST(N'2021-12-14T06:24:49.553' AS DateTime), N'Paul  Rao', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (4, 173, 5, 8, 0, CAST(N'2021-12-14T05:26:47.847' AS DateTime), N'Paul  Rao', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (70, 177, 16, 8, 1, CAST(N'2022-01-10T01:28:45.240' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1, 184, 1, 8, 1, CAST(N'2021-12-13T20:55:06.160' AS DateTime), N'BA-ResourceOne  DummyBAU1', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (24, 184, 6, 7, 0, CAST(N'2021-12-15T11:11:47.740' AS DateTime), N'ba.u1', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (26, 184, 8, 2, 1, CAST(N'2021-12-15T12:14:46.220' AS DateTime), N'AR_TS_Timesheet_Admin', NULL, NULL)
GO
INSERT [dbo].[EmployeeActivityMap] ([Id], [EmployeeId], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (25, 185, 1, 8, 1, CAST(N'2021-12-15T12:02:32.893' AS DateTime), N'ba.m1', NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[EmployeeActivityMap] OFF
GO
SET IDENTITY_INSERT [dbo].[EmployeeRole] ON 
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (199, 0, NULL, N'Admin', 1, CAST(N'2022-01-11T00:51:45.800' AS DateTime), N'dino.liu', CAST(N'2022-01-11T00:51:45.800' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1, 1, NULL, N'Admin', 1, CAST(N'2021-12-09T18:14:30.537' AS DateTime), N'system', CAST(N'2021-12-15T15:09:08.523' AS DateTime), N'ts_superuser')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (2, 2, NULL, N'ITExecutive', 1, CAST(N'2021-12-09T18:14:58.567' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:14:58.567' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (3, 3, NULL, N'TeamOwner', 1, CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (4, 4, NULL, N'TeamOwner', 1, CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (5, 5, NULL, N'TeamOwner', 1, CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (6, 6, NULL, N'TeamOwner', 1, CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport', CAST(N'2021-12-16T06:36:11.487' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (7, 7, NULL, N'TeamOwner', 1, CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (8, 8, NULL, N'TeamOwner', 1, CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (9, 9, NULL, N'TeamOwner', 1, CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (10, 10, NULL, N'TeamOwner', 1, CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (191, 11, NULL, N'Admin', 1, CAST(N'2021-12-15T16:19:57.863' AS DateTime), N'Maiseyl', CAST(N'2021-12-15T16:19:57.863' AS DateTime), N'Maiseyl')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (11, 11, NULL, N'TeamOwner', 0, CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport', CAST(N'2021-12-15T16:19:57.863' AS DateTime), N'Maiseyl')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (12, 12, NULL, N'TeamOwner', 1, CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:21:24.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (13, 13, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (198, 14, NULL, N'Employee', 1, CAST(N'2021-12-17T01:10:41.493' AS DateTime), N'haisong.jia', CAST(N'2021-12-17T01:10:41.493' AS DateTime), N'haisong.jia')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (14, 14, NULL, N'Manager', 0, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-17T01:10:41.493' AS DateTime), N'haisong.jia')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (15, 15, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-17T01:08:01.133' AS DateTime), N'liang.zhao')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (197, 16, NULL, N'Employee', 1, CAST(N'2021-12-17T01:09:48.430' AS DateTime), N'rui.wang', CAST(N'2021-12-17T01:09:48.430' AS DateTime), N'rui.wang')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (16, 16, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-17T01:13:35.400' AS DateTime), N'rui.wang')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (17, 17, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (18, 18, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (19, 19, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (20, 20, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (21, 21, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (22, 22, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (23, 23, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (24, 24, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (25, 25, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (26, 26, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (27, 27, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (28, 28, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (29, 29, NULL, N'Manager', 1, CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:12.990' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (99, 30, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (156, 31, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (51, 32, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (52, 33, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (54, 34, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (84, 35, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (107, 36, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (129, 37, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (143, 38, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (146, 39, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (157, 40, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (104, 41, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (149, 42, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (33, 43, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-16T01:39:34.730' AS DateTime), N'li.zhang')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (39, 44, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (40, 45, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (47, 46, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (58, 47, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (60, 48, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (61, 49, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (62, 50, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (68, 51, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (69, 52, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (70, 53, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (74, 54, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (75, 55, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (88, 56, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (90, 57, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (91, 58, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (96, 59, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (103, 60, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2022-01-07T02:02:12.813' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (117, 61, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (123, 62, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (130, 63, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (139, 64, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (150, 65, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (153, 66, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (155, 67, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (162, 68, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (168, 69, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (169, 70, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (170, 71, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (174, 72, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (175, 73, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (176, 74, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (182, 75, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (115, 76, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (164, 77, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (34, 78, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (154, 79, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (106, 80, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (109, 81, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (48, 82, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (121, 83, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (98, 84, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (36, 85, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (127, 86, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (100, 87, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (120, 88, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (114, 89, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (125, 90, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (133, 91, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (160, 92, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (148, 93, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (81, 94, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (38, 95, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (102, 96, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (126, 97, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (151, 98, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (35, 99, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (41, 100, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (43, 101, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (49, 102, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (56, 103, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (82, 104, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (83, 105, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (86, 106, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (97, 107, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (101, 108, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (113, 109, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (116, 110, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (119, 111, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (30, 112, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (134, 113, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (135, 114, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (166, 115, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (177, 116, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (183, 117, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (63, 118, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (31, 119, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (144, 120, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (53, 121, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (64, 122, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (72, 123, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (110, 124, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (44, 125, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (45, 126, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (67, 127, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (76, 128, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (78, 129, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (79, 130, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (89, 131, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (93, 132, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (111, 133, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (112, 134, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (122, 135, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (124, 136, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (140, 137, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (141, 138, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (152, 139, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (159, 140, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (171, 141, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (172, 142, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (173, 143, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (178, 144, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (179, 145, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (180, 146, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (32, 147, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (42, 148, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (55, 149, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (65, 150, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (73, 151, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (80, 152, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (87, 153, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (92, 154, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (108, 155, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (118, 156, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (128, 157, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (158, 158, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (163, 159, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (145, 160, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (37, 161, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (50, 162, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (131, 163, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (161, 164, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (181, 165, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (185, 166, NULL, N'Admin', 1, CAST(N'2021-12-14T02:00:44.273' AS DateTime), N'dino.liu', CAST(N'2022-01-25T02:03:22.097' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (59, 166, NULL, N'Employee', 0, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-16T01:28:18.190' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (187, 166, NULL, N'ProjectAdmin', 0, CAST(N'2021-12-14T05:57:16.317' AS DateTime), N'dino.liu', CAST(N'2021-12-16T01:28:18.190' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (195, 166, NULL, N'TeamOwner', 1, CAST(N'2021-12-16T01:28:18.190' AS DateTime), N'dino.liu', CAST(N'2021-12-16T01:28:18.190' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (188, 166, NULL, N'TimesheetAdmin', 1, CAST(N'2021-12-14T07:43:32.973' AS DateTime), N'dino.liu', CAST(N'2021-12-22T06:41:28.370' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (66, 167, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (85, 168, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (94, 169, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (95, 170, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (105, 171, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (136, 172, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (186, 173, NULL, N'Admin', 1, CAST(N'2021-12-14T02:02:13.930' AS DateTime), N'paul.rao', CAST(N'2021-12-16T00:52:25.760' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (137, 173, NULL, N'Employee', 0, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-14T02:02:13.930' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (138, 174, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (147, 175, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (165, 176, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (46, 177, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (57, 178, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (71, 179, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (77, 180, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (132, 181, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (142, 182, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (167, 183, NULL, N'Employee', 1, CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.623' AS DateTime), N'batchimport')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (184, 184, NULL, N'Employee', 1, CAST(N'2021-12-13T20:52:46.330' AS DateTime), N'ts_superuser', CAST(N'2022-01-12T15:32:41.520' AS DateTime), N'maiseyl')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (189, 185, NULL, N'Manager', 1, CAST(N'2021-12-14T21:02:42.687' AS DateTime), N'ba.m1', CAST(N'2022-01-12T15:34:36.143' AS DateTime), N'maiseyl')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (190, 186, NULL, N'TeamOwner', 1, CAST(N'2021-12-14T21:03:08.000' AS DateTime), N'SA_TS_ML', CAST(N'2021-12-15T17:44:48.020' AS DateTime), N'SA_TS_ML')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (192, 187, NULL, N'TimesheetAdmin', 1, CAST(N'2021-12-15T16:54:50.467' AS DateTime), N'AR_TS_Timesheet_Admin', CAST(N'2021-12-15T16:54:50.467' AS DateTime), N'AR_TS_Timesheet_Admin')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (193, 188, NULL, N'ProjectAdmin', 1, CAST(N'2021-12-15T17:04:01.550' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-15T17:04:01.550' AS DateTime), N'SA_TS_Project_admin')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (194, 189, NULL, N'ITExecutive', 1, CAST(N'2021-12-15T17:08:50.060' AS DateTime), N'akhan', CAST(N'2021-12-15T17:08:50.060' AS DateTime), N'akhan')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (196, 190, NULL, N'Accounting', 1, CAST(N'2021-12-17T01:03:42.740' AS DateTime), N'TA.M1', CAST(N'2021-12-17T01:03:42.740' AS DateTime), N'TA.M1')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (200, 192, NULL, N'Employee', 1, CAST(N'2022-01-12T15:26:47.677' AS DateTime), N'ba.u2', CAST(N'2022-01-12T15:34:50.503' AS DateTime), N'maiseyl')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (201, 193, NULL, N'Employee', 1, CAST(N'2022-01-13T01:59:56.380' AS DateTime), N'dino.liu', CAST(N'2022-01-13T01:59:56.380' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[EmployeeRole] ([Id], [EmployeeId], [RoleID], [RoleName], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (202, 194, NULL, N'ITExecutive', 1, CAST(N'2022-01-26T14:34:34.110' AS DateTime), N'AR_TS_IT_exes', CAST(N'2022-01-26T14:34:34.110' AS DateTime), N'AR_TS_IT_exes')
GO
SET IDENTITY_INSERT [dbo].[EmployeeRole] OFF
GO
SET IDENTITY_INSERT [dbo].[Enum] ON 
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (44, N'CountryCode', N'CAN', N'Canada', NULL, 0, 20)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (47, N'CountryCode', N'CHL', N'Chile', NULL, 0, 50)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (45, N'CountryCode', N'CHN', N'China', NULL, 0, 30)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (59, N'CountryCode', N'DEU', N'Germany', NULL, 0, 90)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (60, N'CountryCode', N'ESP', N'Spain', NULL, 0, 100)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (50, N'CountryCode', N'EUR', N'Europe Country', NULL, 0, 80)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (61, N'CountryCode', N'GBR', N'UK', N'1', 0, 110)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (49, N'CountryCode', N'IRL', N'Ireland', NULL, 0, 70)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (46, N'CountryCode', N'MEX', N'Mexico', NULL, 0, 40)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (48, N'CountryCode', N'POL', N'Poland', NULL, 0, 60)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (43, N'CountryCode', N'USA', N'United States', NULL, 0, 10)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (51, N'DeptCode', N'257', N'Corporate IT Audit', NULL, 0, 80)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (52, N'DeptCode', N'706', N'Front-End Processing Operations', NULL, 0, 10)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (53, N'DeptCode', N'707', N'IT Development - Operations Back Office', NULL, 0, 20)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (54, N'DeptCode', N'708', N'EVO Snap', NULL, 0, 30)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (55, N'DeptCode', N'714', N'Quality Assurance', NULL, 0, 40)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (56, N'DeptCode', N'718', N'Back-End Software Development', NULL, 0, 50)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (57, N'DeptCode', N'723', N'Delego IT', NULL, 0, 60)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (58, N'DeptCode', N'724', N'IT Development - Financial & Risk Back Office', NULL, 0, 70)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (1, N'ExpenditureTypeId', N'1', N'Expense', N'Accounting Expense Type of Expenditure', 0, 10)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (2, N'ExpenditureTypeId', N'2', N'Capital', N'Accounting Capital Type of Expenditure', 0, 20)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (16, N'JobGrade', N'1', N'level1', NULL, 0, 10)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (25, N'JobGrade', N'10', N'level10', NULL, 0, 100)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (26, N'JobGrade', N'11', N'level11', NULL, 0, 110)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (27, N'JobGrade', N'12', N'level12', NULL, 0, 120)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (28, N'JobGrade', N'13', N'level13', NULL, 0, 130)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (17, N'JobGrade', N'2', N'level2', NULL, 0, 20)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (18, N'JobGrade', N'3', N'level3', NULL, 0, 30)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (19, N'JobGrade', N'4', N'level4', NULL, 0, 40)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (20, N'JobGrade', N'5', N'level5', NULL, 0, 50)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (21, N'JobGrade', N'6', N'level6', NULL, 0, 60)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (22, N'JobGrade', N'7', N'level7', NULL, 0, 70)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (23, N'JobGrade', N'8', N'level8', NULL, 0, 80)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (24, N'JobGrade', N'9', N'level9', NULL, 0, 90)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (29, N'ProjectActivityId', N'1', N'Feasibility', NULL, 1, 10)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (30, N'ProjectActivityId', N'2', N'Requirements', NULL, 1, 20)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (31, N'ProjectActivityId', N'3', N'Design', NULL, 2, 30)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (32, N'ProjectActivityId', N'4', N'Development', NULL, 2, 40)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (33, N'ProjectActivityId', N'5', N'Testing', NULL, 2, 50)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (34, N'ProjectActivityId', N'6', N'Implementation', NULL, 2, 60)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (35, N'ProjectActivityId', N'7', N'Post Implementation', NULL, 1, 70)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (36, N'ProjectActivityId', N'8', N'N/A', N'N/A', 0, 80)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (9, N'ProjectStatusId', N'-1', N'Deleted', NULL, 0, 60)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (3, N'ProjectStatusId', N'0', N'Draft', NULL, 0, 1)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (4, N'ProjectStatusId', N'1', N'Pending', NULL, 0, 10)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (5, N'ProjectStatusId', N'2', N'Approved', NULL, 0, 20)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (6, N'ProjectStatusId', N'3', N'Rejected', NULL, 0, 30)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (7, N'ProjectStatusId', N'4', N'Closed', NULL, 0, 40)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (8, N'ProjectStatusId', N'5', N'Impaired', NULL, 0, 50)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (37, N'ProjectTypeId', N'1', N'New Development', NULL, 2, 10)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (38, N'ProjectTypeId', N'2', N'New Enhancement - Significant', NULL, 2, 20)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (39, N'ProjectTypeId', N'3', N'New Enhancement - Not Significant', NULL, 1, 30)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (40, N'ProjectTypeId', N'4', N'Bug Fix', NULL, 1, 40)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (41, N'ProjectTypeId', N'5', N'Maintenance', NULL, 1, 50)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (42, N'ProjectTypeId', N'6', N'Other', NULL, 1, 60)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (10, N'TimesheetPeriodStatusId', N'0', N'Not Current', N'Future Accounting Period', 0, 10)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (11, N'TimesheetPeriodStatusId', N'1', N'Current', N'Current Accounting Period', 0, 20)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (12, N'TimesheetPeriodStatusId', N'2', N'Closed', N'Accounting Period Closed', 0, 30)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (13, N'TimesheetStatusId', N'0', N'Draft', NULL, 0, 10)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (14, N'TimesheetStatusId', N'1', N'Manager Approved', NULL, 0, 20)
GO
INSERT [dbo].[Enum] ([Id], [Name], [KeyVal], [TextVal], [Description], [ParentId], [OrderSeq]) VALUES (15, N'TimesheetStatusId', N'2', N'Executive Approved', NULL, 0, 30)
GO
SET IDENTITY_INSERT [dbo].[Enum] OFF
GO
SET IDENTITY_INSERT [dbo].[Project] ON 
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (1, N'PTO/Holiday', N'Day Off', 6, NULL, NULL, NULL, 0, N'000001', NULL, N'USA', NULL, 2, CAST(N'2021-12-03T22:51:53.313' AS DateTime), 1, CAST(N'2021-12-03T22:51:53.313' AS DateTime), N'system', CAST(N'2021-12-03T22:51:53.313' AS DateTime), N'system', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (2, N'Administration', N'Administration Task', 6, NULL, NULL, NULL, 0, N'000002', NULL, N'USA', NULL, 2, CAST(N'2021-12-03T22:51:53.313' AS DateTime), 1, CAST(N'2021-12-03T22:51:53.313' AS DateTime), N'system', CAST(N'2021-12-03T22:51:53.313' AS DateTime), N'system', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (3, N'Training', N'Annual Training', 6, NULL, NULL, NULL, 0, N'000003', NULL, N'USA', NULL, 2, CAST(N'2021-12-03T22:51:53.313' AS DateTime), 1, CAST(N'2021-12-03T22:51:53.313' AS DateTime), N'system', CAST(N'2021-12-03T22:51:53.313' AS DateTime), N'system', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (4, N'Production Support', N'Support for Production Issues', 6, NULL, NULL, NULL, 0, N'000004', NULL, N'USA', NULL, 2, CAST(N'2021-12-03T22:51:53.313' AS DateTime), 1, CAST(N'2021-12-03T22:51:53.313' AS DateTime), N'system', CAST(N'2021-12-03T22:51:53.313' AS DateTime), N'system', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (5, N'Meetings', N'Meeting', 6, NULL, NULL, NULL, 0, N'000005', NULL, N'USA', NULL, 2, CAST(N'2021-12-03T22:51:53.313' AS DateTime), 1, CAST(N'2021-12-03T22:51:53.313' AS DateTime), N'system', CAST(N'2021-12-03T22:51:53.313' AS DateTime), N'system', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (6, N'Test Project', N'Test', 6, NULL, NULL, NULL, 10, N'E00001', N'22222', N'EUR', N'Abdul Khan', 2, CAST(N'2021-12-14T07:57:41.800' AS DateTime), 0, CAST(N'2021-12-14T05:42:00.817' AS DateTime), N'dino.liu', CAST(N'2021-12-14T07:57:41.860' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (7, N'Test email Project Test email Project Test email Project', N'222  < ff >  Test email Project Test email Project Test email Project', 1, NULL, NULL, NULL, 22, NULL, N'222', N'USA', N'System', 1, CAST(N'2021-12-20T08:05:48.353' AS DateTime), 0, CAST(N'2021-12-14T08:13:49.900' AS DateTime), N'dino.liu', CAST(N'2021-12-20T08:05:48.353' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (8, N'Proj 1 for NY BA', N'Project 1 for NY BA team', 2, NULL, NULL, NULL, 100, N'U00001', NULL, N'USA', N'Pauul Cheen', 2, CAST(N'2021-12-15T17:09:05.263' AS DateTime), 0, CAST(N'2021-12-15T17:06:28.587' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-15T17:09:05.280' AS DateTime), N'akhan', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (9, N'Project X for CHN & NY- <b>blar blar blar blar blar blar ... </b>', N'Description for Project X CHN -  blar blar blar blar blar blar ... blar blar ', 1, NULL, NULL, NULL, 100, N'N10001', NULL, N'CHN', N'Richard Zhang', 2, CAST(N'2021-12-29T02:22:24.677' AS DateTime), 0, CAST(N'2021-12-15T20:36:11.843' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-29T02:22:24.707' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (10, N'Test Project message', N'Test Project message< > &&&&', 1, NULL, NULL, NULL, 33, NULL, N'344', N'CHN', N'Andrew Zhang', 3, CAST(N'2021-12-29T00:53:12.853' AS DateTime), 0, CAST(N'2021-12-16T00:49:48.633' AS DateTime), N'li.zhang', CAST(N'2021-12-29T02:22:09.050' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (11, N'2222222', N'22', 1, NULL, NULL, NULL, 22, NULL, NULL, N'USA', N'aa', 3, CAST(N'2021-12-29T02:22:22.473' AS DateTime), 0, CAST(N'2021-12-16T20:00:58.090' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-29T02:22:22.473' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (12, N'blar blar', N'blar blar', 1, NULL, NULL, NULL, 100, NULL, NULL, N'USA', N'PaulC', 1, CAST(N'2021-12-24T05:40:42.317' AS DateTime), 0, CAST(N'2021-12-16T20:08:45.047' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-24T05:40:42.317' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (13, N'asdfasdfasdfasdfasdfsd_sdfasdfasdfasdf_fasdfasdfasdfasdfasdf', N'asfasdfasfd', 1, NULL, NULL, NULL, 33, N'U00002', N'3', N'USA', N'Alex Wang', 2, CAST(N'2021-12-29T00:54:01.340' AS DateTime), 0, CAST(N'2021-12-22T07:21:02.970' AS DateTime), N'dino.liu', CAST(N'2021-12-29T00:54:01.370' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (14, N'pkstrppoczryxoa', N'zzinyisnrwhgare', 6, NULL, NULL, NULL, 75, NULL, N'quokyyevbamtvkt', N'CHN', N'Dino Liu', 1, CAST(N'2021-12-31T02:11:01.233' AS DateTime), 0, CAST(N'2021-12-31T02:11:01.233' AS DateTime), N'dino.liu', CAST(N'2021-12-31T02:11:01.233' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (15, N'nxbgjqhccsydqjm', N'lrultcvxwbahuwb', 6, NULL, NULL, NULL, 57, NULL, N'mlopakzkqkzrfpf', N'CHN', N'Dino Liu', 1, CAST(N'2021-12-31T02:13:30.830' AS DateTime), 0, CAST(N'2021-12-31T02:13:30.830' AS DateTime), N'dino.liu', CAST(N'2021-12-31T02:13:30.830' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (16, N'Maintenance', N'Maintenance', 6, NULL, NULL, NULL, 0, N'000006', NULL, N'USA', NULL, 2, CAST(N'2022-01-03T18:52:16.317' AS DateTime), 1, CAST(N'2022-01-03T18:52:16.317' AS DateTime), N'system', CAST(N'2022-01-03T18:52:16.317' AS DateTime), N'system', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (17, N'Audit Support', N'Audit Support', 6, NULL, NULL, NULL, 0, N'000007', NULL, N'USA', NULL, 2, CAST(N'2022-01-03T18:52:16.333' AS DateTime), 1, CAST(N'2022-01-03T18:52:16.333' AS DateTime), N'system', CAST(N'2022-01-03T18:52:16.333' AS DateTime), N'system', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (18, N'Compliance', N'Compliance', 6, NULL, NULL, NULL, 0, N'000008', NULL, N'USA', NULL, 2, CAST(N'2022-01-03T18:52:16.350' AS DateTime), 1, CAST(N'2022-01-03T18:52:16.350' AS DateTime), N'system', CAST(N'2022-01-03T18:52:16.350' AS DateTime), N'system', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (19, N'spbrcgcwqxmekoe', N'egrnwuietvxpvyr', 6, NULL, NULL, NULL, 69, NULL, N'vqtfwsnycsbitzh', N'CHN', N'Dino Liu', 1, CAST(N'2022-01-07T02:58:04.053' AS DateTime), 0, CAST(N'2022-01-07T02:58:04.053' AS DateTime), N'dino.liu', CAST(N'2022-01-07T02:58:04.053' AS DateTime), N'dino.liu', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (20, N'Testing For accounting Entity', N'Testing For accounting Entity', 1, NULL, NULL, NULL, 20, N'U00003', NULL, N'USA', N'Alex Wang', 2, CAST(N'2022-01-11T03:02:22.480' AS DateTime), 0, CAST(N'2022-01-11T03:00:48.947' AS DateTime), N'dino.liu', CAST(N'2022-01-11T03:02:22.523' AS DateTime), N'dino.liu', 3, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (21, N'Test Parent', N't424234', 1, NULL, NULL, NULL, 22, N'U00004', N'3', N'USA', N'Andrew Jay Diamond', 2, CAST(N'2022-01-13T06:06:47.277' AS DateTime), 0, CAST(N'2022-01-13T06:06:37.573' AS DateTime), N'dino.liu', CAST(N'2022-01-13T06:24:39.410' AS DateTime), N'dino.liu', 7, 11)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (22, N'44r4rr4r4', N'4r4', 3, NULL, NULL, NULL, 0, N'N10002', NULL, N'CHN', N'Atikur Rahman', 2, CAST(N'2022-01-13T06:27:38.710' AS DateTime), 0, CAST(N'2022-01-13T06:27:27.273' AS DateTime), N'dino.liu', CAST(N'2022-01-13T06:27:38.727' AS DateTime), N'dino.liu', 2, 0)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (154, N'eCommission Automation', N'eCommission Automation -  Update made on Automation Script', 2, CAST(N'2019-01-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'100450', N'', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (155, N'eSafe Automation - US', N'ESAFE US:  Automation Script', 2, CAST(N'2019-01-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'100451', N'', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (156, N'eBalance - Europe 6', N'Implementate eBalance for EVO EU for settlment balance reconcilation. ', 2, CAST(N'2019-07-19T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'100834', N'', N'USA', N'', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (157, N'Spoon Retirement', N'Spoon decommission', 1, NULL, NULL, NULL, NULL, N'300080', N'', N'USA', N'', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (158, N'E360 - Mexico', N'A360 implementatin in Europe', 2, CAST(N'2019-10-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300161', N'', N'MEX', N'Scott Baker', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (159, N'SNAP - Support for Diners Card/Discover - EU', N'Add support for Diners/Discover card brand for EU', 2, CAST(N'2019-12-02T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300195', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (160, N'OnBoard - Bulk Pricing Enhancement', N'Implement future dated fees for bulk pricing updates.   ', 2, CAST(N'2020-01-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300196', N'', N'USA', N'Steve Magara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (161, N'Risk Shield 6', N'Integrate to RiskShield to support Transaction Risk Analysis ', 1, CAST(N'2020-03-11T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300245', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (162, N'Chipper 2X BT/205699', N'New Chipper 2X BT support for CommerceDriver', 2, CAST(N'2020-06-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300364', N'', N'USA', N'', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (163, N'Timesheet Portal', N'A web portal will be built for the EVO employees to enter their time in timesheet', 2, CAST(N'2021-06-04T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300374', N'', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (164, N'Spoon residual calculations to eCommission', N'Migrate residual calculation from Spoon to eCommission', 2, CAST(N'2020-07-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300398', N'', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (165, N'EVO EMRS ACH Solution ', N'EVO ACH Solution'' for eCommerce merchants', 2, CAST(N'2020-07-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300399', N'', N'USA', N'', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (166, N'ACH Boarding', N'Support Boarding to the Pay Fabric ACH platform', 1, CAST(N'2020-08-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300402', N'', N'USA', N'Nikki Nguyen ', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (167, N'SNAP - 3DSecure v2.0 for Mexico', N'eCommerce 3DS Secure 2.0 for Mexico', 2, NULL, NULL, NULL, NULL, N'300429', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (168, N'PIR-EMRS Reserve Note to CRMs', N'Reserve notes into 6 CRM: send all reserve and Qstatus related notes to 6 CRMs for easier and more convenient customer service experience', 2, NULL, NULL, NULL, NULL, N'300432', N'', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (169, N'System Simplification', N'Product/Admin Tool in wireframe 3 stage', 2, NULL, NULL, NULL, NULL, N'300491', N'', N'USA', N'Matthew McClain', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (170, N'3DS 2.0 Diners, Discover/192269', N'Additional functionality to EU 3D Secure to allow for Diners and Discover card brands', 2, CAST(N'2020-09-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300493', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (171, N'Tetra - Pay At Table', N'QA 5 for Product', 3, NULL, NULL, NULL, NULL, N'300537', N'', N'USA', N'Steve Pracilio', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (172, N'Global Tokenization Service - Integration', N'Work needed to integrate Snap* to the GTS Enhancements', 2, CAST(N'2021-02-08T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300586', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (173, N'PayTrace Migration', N'Migrate PayTrace merchants (3,000) to EVO''s frontend NGTrans', 2, CAST(N'2021-12-02T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300604', N'', N'USA', N'Steve Magara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (174, N'Conversion to New HSMs', N'Meeting to discuss unification of EVO''s HSM globally', 6, CAST(N'2021-02-16T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300609', N'', N'USA', N'Steve Pracilio', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (175, N'GPN Portico 6', N'New Global Payments Adapter connection for CA', 2, CAST(N'2021-03-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300612', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (176, N'Germany COF/MIT/RT Transactions/228785', N'Germany Merchant Initiated Transactions', 2, CAST(N'2021-05-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300633', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (177, N'eSafe EU Enhancement', N'Implementing new rules and key features', 2, NULL, NULL, NULL, NULL, N'300634', N'', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (178, N'US Gateway - Boarding Enhancement', N'Support the PayFabric US gateway Boarding through Boarding systems.  EVONow, Mercury, Flex, OnBoard', 2, CAST(N'2021-05-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300636', N'', N'USA', N'Steve Magara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (179, N'Simple Tab - QR 6', N'For the Minimal Viable Product (MVP), BirdPay will be purchased and rebranded as SimpleTab QR. This solution will enable payments from the consumers mobile phone rather than through traditional terminals. An ISV can integrate to the SimpleTab QR service by simply uploading check details to the cloud... then the ISV can text, email or print a custom URL or QR code on the bill or check. The consumer can then pay on their mobile phone using Google Pay or Apple Pay.', 2, CAST(N'2021-05-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300645', N'', N'USA', N'Andrew Diamond', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (180, N'E360 US Upgrade ', N'E360 US Upgrade to Java 1.8 (OpenJDK)', 2, CAST(N'2021-05-10T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300648', N'', N'USA', N'Scott Baker', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (181, N'NGTrans - SQL Upgrade', N'NGTRANS stress Test ', 1, NULL, NULL, NULL, NULL, N'300656', N'', N'USA', N'Steve Magara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (182, N'eBalance - Mexico 6', N'Implementate  eBalance application for EVO Mexico', 2, NULL, NULL, NULL, NULL, N'100387', N'', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (183, N'EMRS - Mexico Implementaiton', N'Implementate  EMRS application for EVO Mexico', 2, NULL, NULL, NULL, NULL, N'100397', N'PR2018. 087', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (184, N'NGTrans Key Block Encryption', N'Rework all internal encryption to key-block format', 1, NULL, NULL, NULL, NULL, N'300657', N'', N'USA', N'', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (185, N'3DS MIT/230413', N'EU 3D Secureupdates for Merchant Initiated Transactions', 2, CAST(N'2021-06-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300661', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (186, N'UPI 3DS 2.2 Certification/230633', N'Effort needed to track UPI 3DS 2.2 Certifications', 2, CAST(N'2021-06-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300662', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (187, N'3DS 2.2 for Amex/230634', N'EU 3DS 2.2 4 for AMEX', 2, CAST(N'2021-06-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300664', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (188, N'ZSFK/German CIS Stage Codes ', N'E360 enhancement for E360 to ZSFK settlement file', 2, CAST(N'2021-07-15T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300671', N'', N'USA', N'Scott Baker', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (189, N'eSafe - AML 6 (EU)', N'Billed AML module in eSafe', 2, CAST(N'2021-10-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300674', N'', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (190, N'Ingenico - Tokens and Surcharge | Snap | New', N'Tokens and Surcharge 5 for Ingenico Terminals', 1, NULL, NULL, NULL, NULL, N'300679', N'', N'USA', N'Steve Pracilio', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (191, N'Mobile Integration - EVO HQ/221038 ', N'Integrate mobile devices to EVO HQ', 2, CAST(N'2021-07-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300682', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (192, N'ACH 1099 view in MyEVO', N'Provide multiple 1099 PDF reports at end of year tax season, one for Card and one for ACH transactions', 2, CAST(N'2021-10-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300688', N'', N'USA', N'Steve Magara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (193, N'EVO In Control - US 6', N'Replace an aging MyEVO website with the EIC application from MX, with language support.  Spec out any gaps in functionality.', 2, CAST(N'2021-11-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300689', N'', N'USA', N'Steve Magara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (194, N'A360 Release 22-01', N'Various Europe Requests', 4, CAST(N'2021-09-20T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300691', N'', N'USA', N'Scott Baker', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (195, N'Developer Portal', N'Global EVO Integrator Portal containing partner integration documentation for all integration options', 2, CAST(N'2021-10-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300692', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (196, N'UCAT VPP/MPP Small Ticket Program', N'Settlement project to support Small Ticket card transaction processing', 2, CAST(N'2021-11-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300696', N'', N'USA', N'Steve Magara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (197, N'NGTIPS HTTPS Interface rework', N'Research of IO completion port usage for HTTP interface in NGTIPS', 6, NULL, NULL, NULL, NULL, N'300700', N'', N'USA', N'Steve Pracilio', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (198, N'Statement Portal Enhancements', N'Migrate all statement related items to the new Statement Portal', 2, NULL, NULL, NULL, NULL, N'300703', N'', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (199, N'Simple Tab - ISV JSON Integration 6', N'4, Integration and Deployment Support for SimpleTabCloud', 2, CAST(N'2021-10-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300704', N'', N'USA', N'Andrew Diamond', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (200, N'SNAP - NGTrans CAT 6', N'CARDHOLDER Activated Terminal Support for NGTrans', 3, CAST(N'2021-10-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300705', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (201, N'EVO Mobile - UI Workflow Enhancements', N'Product has requested new workflows for the EVO Mobile Applcation', 2, CAST(N'2021-10-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300706', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (202, N'eSafe - AML 6 (US)', N'Billed AML module in eSafe', 2, CAST(N'2021-11-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300712', N'', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (203, N'eSafe - AML 6 (MX)', N'Billed AML module in eSafe', 2, NULL, NULL, NULL, NULL, N'300713', N'', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (204, N'eCommissions - Encore Residuals Conversion', N'Migrate Encore residual to eCommission', 2, NULL, NULL, NULL, NULL, N'300714', N'', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (205, N'EVO Canada Discover IMAP to MAP conversion', N'Create Discover MAP SE# in batch and update EDS', 2, NULL, NULL, NULL, NULL, N'300716', N'', N'USA', N'Maisey Liu', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (206, N'SNAP - COF Updates for eService', N'Market COF mandates for EU, separate form Germany COF Manadates', 2, CAST(N'2021-10-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300720', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (207, N'E360.Europe.2022.March.22.Release', N'CIS Germany stage codes', 2, CAST(N'2021-12-05T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300722', N'', N'USA', N'Scott Baker', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (208, N'GSAP TID Randomization', N'Randomize the Global GSAP foreign frontend terminal IDs, currently created from the merchant''s MID and a sequence number.  For improved security.', 2, CAST(N'2022-01-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300723', N'', N'USA', N'Steve Magara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (209, N'NGTrans TPSCrypto Retirement', N'NGTrans will stop populating the TPSCrypto encrypted PCI fields in the Transaction Detail table(s) in early 2022.  Remediate all extracts and reports as appropriate to reference the DataProtect PCI table columns instead', 2, CAST(N'2022-01-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300724', N'', N'USA', N'Steve Magara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (210, N'ENH Addendum Re3', N'Re3 the ENH merchant application Addendum fill-and-sign process, that was originated in the EVONow to Spoon project', 2, CAST(N'2021-12-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300725', N'', N'USA', N'Steve Magara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (211, N'EMV Certification for Dejavoo (Android) via SNAP', N'EMV Certification for Dejavoo (Android) via SNAP', 6, NULL, NULL, NULL, NULL, N'300732', N'', N'USA', N'Steve Pracilio', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (212, N'EMV Certification - Peripherals (BluePad 55) ', N'EMV Certification ', 1, NULL, NULL, NULL, NULL, N'300733', N'', N'USA', N'Steve Pracilio', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (213, N'NGTRANS MC Decline Reason Code Service for Select Card-Not-Present', N'MC update to receive DE 48.84 for response codes 79 and 82', 1, NULL, NULL, NULL, NULL, N'300734', N'', N'USA', N'Steve Pracilio', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (214, N'Remove PTLS from Transaction Flow/241133', N'As part of our platform stability project, removing PTLS will shave time off each transaction removing uncessecarry transformations as it flows through the platform.', 6, CAST(N'2021-11-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'300731', N'', N'USA', N'Scott Labrash', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (215, N'PayCenter needs to support L2/3 transactions', N'PayCenter needs to support L2/3 transactions', 3, CAST(N'2019-10-16T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'C10010', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (216, N'FDMS RapidConnect: Support Authorized Refunds', N'FDMS RapidConnect: Support Authorized Refunds', 3, CAST(N'2019-03-22T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'C10014', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (217, N'Add 3DS2 support to FDMS Compass', N'Add 3DS2 support to FDMS Compass', 3, CAST(N'2020-07-22T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'C10027', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (218, N'PayCenter Reference Document and Multiple Invoices', N'Multi-select Invoice download. Configurable help link. Ref text.', 3, NULL, NULL, NULL, NULL, N'C10037', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (219, N'Chase Early Warning System Fraud Reduction Cheques', N'Reduce ACH Fraud for Hilti', 3, CAST(N'2021-10-18T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'C10038', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (220, N'Compass SCA Exemptions', N'Add support for Secure Consumer Authentication Exemptions to Compass', 3, CAST(N'2021-04-19T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'C10040', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (221, N'Vantiv Express Clearinghouse', N'Develop an integration to the Vantiv Express API', 3, NULL, NULL, NULL, NULL, N'C10041', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (222, N'PayFabric multi-capture support', N'Add support for multi-capture to the Delego PayFabric integration', 3, NULL, NULL, NULL, NULL, N'C10042', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (223, N'Alternative to Cognito and Lambda in DelegoPC', N'Create an alternative user management system to replace Cognito', 3, CAST(N'2021-11-11T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'C10043', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (224, N'FDMS North Void', N'Add the ability to Void authorizations through the FDMS North integration ', 3, NULL, NULL, NULL, NULL, N'C10044', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (225, N'Chase Orbital Recurring Mandate', N'Visa and MC recurring payment mandate - new response codes. Hilti', 3, CAST(N'2021-10-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'C10045', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (226, N'Proxy authentication - Mulesoft', N'P66 authentication change request - switch to Mulesoft ', 3, CAST(N'2021-09-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'C10046', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (227, N'DelegoPC BCC receipts', N'Curbell and Philips roadmap request; not willing to pay for 4. Receipt enhancements.', 3, NULL, NULL, NULL, NULL, N'C10047', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (228, N'Delego Token Deletion', N'New Delego ABAP (SAP) Program to provide Merchants with a GDPR compliance token deletion application', 3, CAST(N'2021-11-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'C10048', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (229, N'DelegoPC Card On File', N'Add support to DelegoPayCenter for SAP Customer Master / BP card on file support', 3, NULL, NULL, NULL, NULL, N'C10049', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (230, N'DelegoPC SAML support', N'Add support to DelegoPayCenter for SSO via SAML', 3, NULL, NULL, NULL, NULL, N'C10050', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (231, N'Delego Multi-Tenant 6', N'Add the ability to deploy Delego as Multi-Tenant', 2, NULL, NULL, NULL, NULL, N'C10051', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (232, N'IPG Plugin for PrestaShop (SCA)- 1.1.0', N'SCA enhancement', 2, CAST(N'2020-08-24T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'N00095', N'', N'ESP', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (233, N'IPG Plugin for OsCommerce (SCA) - 1.1.0 ', N'SCA enhancement', 2, CAST(N'2020-08-24T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'N00096', N'', N'ESP', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (234, N'IPG Plugin for Magento2 (SCA)- 1.1.0', N'SCA enhancement', 2, CAST(N'2020-08-24T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'N00097', N'', N'ESP', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (235, N'IPG Plugin for OpenCart (SCA)- 1.1.0', N'SCA enhancement', 2, CAST(N'2020-08-24T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'N00098', N'', N'ESP', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (236, N'IPG Plugin for VirtueMart (SCA)- 1.1.0', N'SCA enhancement', 2, CAST(N'2020-08-24T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'N00099', N'', N'ESP', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (237, N'IPG Plugin for WooCommerce (SCA)- 1.1.0', N'SCA enhancement', 2, CAST(N'2020-08-24T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'N00100', N'', N'ESP', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (238, N'Credit Card Advantage 41 SP5', N'Surcharge support. Support Transaction Schedule parameter', 2, NULL, NULL, NULL, NULL, N'N00149', N'', N'USA', N'David Geli', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (239, N'IPG Plugin for ECWID -  1.0.0', N'Payment plugin for ECWID ', 2, CAST(N'2021-03-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'N00186', N'', N'DEU', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (240, N'IPG Plugin for Magento2 (Recurring Payment)- 2.0.0', N'Implement the recurring payment function', 2, CAST(N'2021-03-01T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'N00187', N'', N'MEX', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (241, N'IPG Fuse Upgrade', N'Analyse FUSE Upgrade from 6.3 to 7.8', 2, CAST(N'2021-04-08T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'N00216', N'', N'POL', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (242, N'IPG Plugin for Zencart (SCA)- 1.1.0', N'Automation 6', 6, NULL, NULL, NULL, NULL, N'N00223', N'', N'POL', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (243, N'PayFabric Receivables Release 2.2', N'Tax Calculation. Payments on Incomplete Invoices. Recurring Billing. PayPal Support / Payment Page Updates.', 2, NULL, NULL, NULL, NULL, N'N00228', N'', N'USA', N'David Geli', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (244, N'US Gateway - 6', N'Implement AutoBoard, Partner Portal, Transaction set', 2, CAST(N'2021-05-16T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'N00257', N'', N'USA', N'Jim Allison ', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (245, N'Oracle Commerce Cloud 3.0 - 6', N'Support Oracle New UI and 6 features', 1, NULL, NULL, NULL, NULL, N'N00258', N'', N'USA', N'Nikki Nguyen', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (246, N'Shopping cart plugin - Magento 2.3', N'Shopping card plugin for Magento 2.3', 2, NULL, NULL, NULL, NULL, N'N00259', N'', N'USA', N'Jim Allison', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (247, N'SAP Digital Payments Add-on 1.1', N'Level 2 / Level 3 support. Advice support. JWT Validity. enhancement', 2, NULL, NULL, NULL, NULL, N'N00305', N'', N'USA', N'David Geli', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (248, N'eCommerce Shopping cart plugin - Magento 2.4', N'Shopping card plugin for Magento 2.4', 2, NULL, NULL, NULL, NULL, N'N00319', N'', N'USA', N'Jim Allison ', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (249, N'PayFabric Release 18', N'SNAP* Endpoints Failover, 6 B2B features', 2, NULL, NULL, NULL, NULL, N'N00323', N'', N'USA', N'Nikki Nguyen', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (250, N'PayFabric for Business Central 19.1', N'PayFabric Receivables Filters & Mapping Enhanced Automation. Retrieve Invoices & Customers from PayFabric Receivables.', 2, NULL, NULL, NULL, NULL, N'N00324', N'', N'USA', N'David Geli', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (251, N'CRM Charge Release 3.7', N'2021 Release Wave 2 Support. Field Service Work Order Support. Quote with PayLink Support', 2, NULL, NULL, NULL, NULL, N'N00329', N'', N'USA', N'Nikki Nguyen', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (252, N'Acumatica Intergration ', N'Integrate PayFabric Receivables', 2, NULL, NULL, NULL, NULL, N'N00330', N'', N'USA', N'Jim Allison', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (253, N'Irish Lottery 6', N'Migrate the PLI ecommerce business to the BOIPA Gateway', 2, NULL, NULL, NULL, NULL, N'N00337', N'', N'IRL', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (254, N'Sage Intacct Integration', N'Sage Intacct Integration with PFR', 1, NULL, NULL, NULL, NULL, N'N00338', N'', N'USA', N'David Geli', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (255, N'Transactional Risk Analysis (TRA) release 2', N'TRA release 2', 2, NULL, NULL, NULL, NULL, N'N00340', N'', N'IRL', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (256, N'IPG EV2107', N'SCA for AIBMS', 2, NULL, NULL, NULL, NULL, N'N00265', N'', N'POL', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (257, N'SNAP* Full Flow SCA', N'Implement SNAP* Full Flow to support SCA', 2, NULL, NULL, NULL, NULL, N'N00249', N'', N'POL', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (258, N'Android - POS 4, Anderson  Zaks', N'POS enhancement for Anderson Zaks', 2, NULL, NULL, NULL, NULL, N'N00328', N'', N'GBR', N'Robert Nemcsics', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (259, N'Philips PayCenter 4 for SRC and Health', N'Ability to filter “Account History” to limit customer to a maximum of 6 months from current date. (ii) Additional column for “Customer name” (A) Value to be mapped to “PayerID” (B) Include option to filter column (C) Column included on both Invoice and Account History page (iii) Option to hide Customer Name, Number and Company Code.', 2, CAST(N'2022-01-24T00:00:00.000' AS DateTime), NULL, NULL, NULL, N'C10052', N'', N'CAN', N'Craig Lehtovaara', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
INSERT [dbo].[Project] ([Id], [Name], [Description], [TypeId], [StartDate], [EndDate], [ProdDate], [EstHrs], [ProjectNo], [PIRNum], [CountryCode], [RequestBy], [StatusId], [StatusDate], [IsPredefined], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy], [AccountingEntityId], [ParentId]) VALUES (260, N'eSafe US Automated Contractual Info Update and new Rules', N'eSafe US Automated Contractual Info Calculation and New Rules', 2, NULL, NULL, NULL, NULL, N'300735', N'', N'USA', N'Gerald Lannan ', 2, NULL, 0, CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.593' AS DateTime), N'ImportedByDino', NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[Project] OFF
GO
SET IDENTITY_INSERT [dbo].[ProjectActivity] ON 
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1, 1, 8, 1, CAST(N'2021-12-06T00:15:56.637' AS DateTime), N'SystemImport', CAST(N'2021-12-06T00:15:56.637' AS DateTime), N'SystemImport')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (2, 2, 8, 1, CAST(N'2021-12-06T00:15:56.637' AS DateTime), N'SystemImport', CAST(N'2021-12-06T00:15:56.637' AS DateTime), N'SystemImport')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (3, 3, 8, 1, CAST(N'2021-12-06T00:15:56.637' AS DateTime), N'SystemImport', CAST(N'2021-12-06T00:15:56.637' AS DateTime), N'SystemImport')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (4, 4, 8, 1, CAST(N'2021-12-06T00:15:56.637' AS DateTime), N'SystemImport', CAST(N'2021-12-06T00:15:56.637' AS DateTime), N'SystemImport')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (5, 5, 8, 1, CAST(N'2021-12-06T00:15:56.637' AS DateTime), N'SystemImport', CAST(N'2021-12-06T00:15:56.637' AS DateTime), N'SystemImport')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (6, 6, 7, 1, CAST(N'2021-12-14T05:42:00.943' AS DateTime), N'dino.liu', CAST(N'2021-12-14T06:26:55.683' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (7, 7, 1, 1, CAST(N'2021-12-14T08:13:49.997' AS DateTime), N'dino.liu', CAST(N'2021-12-15T01:55:16.603' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (8, 8, 1, 1, CAST(N'2021-12-15T17:06:28.620' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-15T17:06:28.620' AS DateTime), N'SA_TS_Project_admin')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (9, 8, 2, 1, CAST(N'2021-12-15T17:06:28.620' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-15T17:06:28.620' AS DateTime), N'SA_TS_Project_admin')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (10, 9, 1, 1, CAST(N'2021-12-15T20:36:11.873' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-15T20:36:11.873' AS DateTime), N'SA_TS_Project_admin')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (11, 9, 2, 1, CAST(N'2021-12-15T20:36:11.873' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-15T20:36:11.873' AS DateTime), N'SA_TS_Project_admin')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (12, 10, 1, 1, CAST(N'2021-12-16T00:49:48.680' AS DateTime), N'li.zhang', CAST(N'2021-12-29T02:22:09.020' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (16, 11, 4, 1, CAST(N'2021-12-29T01:35:03.237' AS DateTime), N'dino.liu', CAST(N'2021-12-29T01:38:52.737' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (18, 15, 5, 1, CAST(N'2021-12-31T02:13:30.877' AS DateTime), N'dino.liu', CAST(N'2021-12-31T02:13:30.877' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (25, 22, 2, 1, CAST(N'2022-01-13T06:27:27.337' AS DateTime), N'dino.liu', CAST(N'2022-01-13T06:27:27.337' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (591, 174, 1, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (592, 215, 1, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (593, 217, 1, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (594, 221, 1, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (595, 222, 1, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (596, 223, 1, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (597, 224, 1, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (598, 227, 1, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (599, 229, 1, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (600, 230, 1, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (601, 231, 1, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (602, 154, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (603, 155, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (604, 156, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (605, 157, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (606, 158, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (607, 159, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (608, 160, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (609, 161, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (610, 162, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (611, 163, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (612, 164, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (613, 165, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (614, 166, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (615, 167, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (616, 168, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (617, 169, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (618, 170, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (619, 171, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (620, 172, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (621, 173, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (622, 175, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (623, 176, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (624, 177, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (625, 178, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (626, 179, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (627, 180, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (628, 181, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (629, 182, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (630, 183, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (631, 184, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (632, 185, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (633, 186, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (634, 187, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (635, 188, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (636, 189, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (637, 190, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (638, 191, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (639, 192, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (640, 193, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (641, 194, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (642, 195, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (643, 196, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (644, 197, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (645, 198, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (646, 199, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (647, 200, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (648, 201, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (649, 202, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (650, 203, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (651, 204, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (652, 205, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (653, 206, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (654, 207, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (655, 208, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (656, 209, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (657, 210, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (658, 211, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (659, 212, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (660, 213, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (661, 214, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (662, 216, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (663, 218, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (664, 219, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (665, 220, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (666, 225, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (667, 226, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (668, 228, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (669, 232, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (13, 11, 2, 0, CAST(N'2021-12-16T20:00:58.123' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-29T01:38:52.737' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (14, 12, 1, 1, CAST(N'2021-12-16T20:08:45.077' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-16T20:08:45.077' AS DateTime), N'SA_TS_Project_admin')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (15, 13, 2, 1, CAST(N'2021-12-22T07:21:03.063' AS DateTime), N'dino.liu', CAST(N'2021-12-22T07:21:03.063' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (17, 14, 5, 1, CAST(N'2021-12-31T02:11:01.297' AS DateTime), N'dino.liu', CAST(N'2021-12-31T02:11:01.297' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (19, 19, 5, 1, CAST(N'2022-01-07T02:58:04.130' AS DateTime), N'dino.liu', CAST(N'2022-01-07T02:58:04.130' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (20, 16, 8, 1, CAST(N'2022-01-10T01:26:15.647' AS DateTime), N'sys', CAST(N'2022-01-10T01:26:15.647' AS DateTime), N'sys')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (21, 17, 8, 1, CAST(N'2022-01-10T01:26:15.647' AS DateTime), N'sys', CAST(N'2022-01-10T01:26:15.647' AS DateTime), N'sys')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (22, 18, 8, 1, CAST(N'2022-01-10T01:26:15.647' AS DateTime), N'sys', CAST(N'2022-01-10T01:26:15.647' AS DateTime), N'sys')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (23, 20, 1, 1, CAST(N'2022-01-11T03:00:49.023' AS DateTime), N'dino.liu', CAST(N'2022-01-11T03:00:49.023' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (24, 21, 2, 1, CAST(N'2022-01-13T06:06:37.637' AS DateTime), N'dino.liu', CAST(N'2022-01-13T06:24:39.380' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (670, 233, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (671, 234, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (672, 235, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (673, 236, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (674, 237, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (675, 238, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (676, 239, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (677, 240, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (678, 241, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (679, 242, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (680, 243, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (681, 244, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (682, 245, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (683, 247, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (684, 248, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (685, 249, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (686, 250, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (687, 251, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (688, 252, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (689, 253, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (690, 255, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (691, 256, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (692, 257, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (693, 258, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (694, 259, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (695, 260, 2, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (696, 154, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (697, 155, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (698, 156, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (699, 157, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (700, 158, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (701, 159, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (702, 160, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (703, 161, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (704, 162, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (705, 163, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (706, 164, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (707, 165, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (708, 166, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (709, 167, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (710, 168, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (711, 169, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (712, 170, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (713, 171, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (714, 172, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (715, 173, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (716, 175, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (717, 176, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (718, 177, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (719, 178, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (720, 179, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (721, 180, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (722, 181, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (723, 182, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (724, 183, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (725, 184, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (726, 185, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (727, 186, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (728, 187, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (729, 188, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (730, 189, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (731, 190, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (732, 191, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (733, 192, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (734, 193, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (735, 194, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (736, 195, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (737, 196, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (738, 197, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (739, 198, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (740, 199, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (741, 200, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (742, 201, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (743, 202, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (744, 203, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (745, 204, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (746, 205, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (747, 206, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (748, 207, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (749, 208, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (750, 209, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (751, 210, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (752, 211, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (753, 212, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (754, 213, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (755, 214, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (756, 216, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (757, 218, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (758, 219, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (759, 220, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (760, 225, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (761, 226, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (762, 228, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (763, 232, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (764, 233, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (765, 234, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (766, 235, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (767, 236, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (768, 237, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (769, 238, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (770, 239, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (771, 240, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (772, 241, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (773, 242, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (774, 243, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (775, 244, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (776, 245, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (777, 247, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (778, 248, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (779, 249, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (780, 250, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (781, 251, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (782, 252, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (783, 253, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (784, 255, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (785, 256, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (786, 257, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (787, 258, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (788, 259, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (789, 260, 3, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (790, 154, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (791, 155, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (792, 156, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (793, 157, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (794, 158, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (795, 159, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (796, 160, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (797, 161, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (798, 162, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (799, 163, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (800, 164, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (801, 165, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (802, 166, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (803, 167, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (804, 168, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (805, 169, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (806, 170, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (807, 171, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (808, 172, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (809, 173, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (810, 175, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (811, 176, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (812, 177, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (813, 178, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (814, 179, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (815, 180, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (816, 181, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (817, 182, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (818, 183, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (819, 184, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (820, 185, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (821, 186, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (822, 187, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (823, 188, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (824, 189, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (825, 190, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (826, 191, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (827, 192, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (828, 193, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (829, 194, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (830, 195, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (831, 196, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (832, 197, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (833, 198, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (834, 199, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (835, 200, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (836, 201, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (837, 202, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (838, 203, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (839, 204, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (840, 205, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (841, 206, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (842, 207, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (843, 208, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (844, 209, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (845, 210, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (846, 211, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (847, 212, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (848, 213, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (849, 214, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (850, 216, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (851, 218, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (852, 219, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (853, 220, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (854, 225, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (855, 226, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (856, 228, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (857, 232, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (858, 233, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (859, 234, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (860, 235, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (861, 236, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (862, 237, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (863, 238, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (864, 239, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (865, 240, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (866, 241, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (867, 242, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (868, 243, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (869, 244, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (870, 245, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (871, 247, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (872, 248, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (873, 249, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (874, 250, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (875, 251, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (876, 252, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (877, 253, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (878, 255, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (879, 256, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (880, 257, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (881, 258, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (882, 259, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (883, 260, 4, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (884, 154, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (885, 155, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (886, 156, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (887, 157, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (888, 158, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (889, 159, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (890, 160, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (891, 161, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (892, 162, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (893, 163, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (894, 164, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (895, 165, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (896, 166, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (897, 167, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (898, 168, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (899, 169, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (900, 170, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (901, 171, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (902, 172, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (903, 173, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (904, 175, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (905, 176, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (906, 177, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (907, 178, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (908, 179, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (909, 180, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (910, 181, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (911, 182, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (912, 183, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (913, 184, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (914, 185, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (915, 186, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (916, 187, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (917, 188, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (918, 189, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (919, 190, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (920, 191, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (921, 192, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (922, 193, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (923, 194, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (924, 195, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (925, 196, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (926, 197, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (927, 198, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (928, 199, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (929, 200, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (930, 201, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (931, 202, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (932, 203, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (933, 204, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (934, 205, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (935, 206, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (936, 207, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (937, 208, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (938, 209, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (939, 210, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (940, 211, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (941, 212, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (942, 213, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (943, 214, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (944, 216, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (945, 218, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (946, 219, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (947, 220, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (948, 225, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (949, 226, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (950, 228, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (951, 232, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (952, 233, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (953, 234, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (954, 235, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (955, 236, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (956, 237, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (957, 238, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (958, 239, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (959, 240, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (960, 241, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (961, 242, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (962, 243, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (963, 244, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (964, 245, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (965, 247, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (966, 248, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (967, 249, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (968, 250, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (969, 251, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (970, 252, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (971, 253, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (972, 255, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (973, 256, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (974, 257, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (975, 258, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (976, 259, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (977, 260, 5, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (978, 154, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (979, 155, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (980, 156, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (981, 157, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (982, 158, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (983, 159, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (984, 160, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (985, 161, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (986, 162, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (987, 163, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (988, 164, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (989, 165, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (990, 166, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (991, 167, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (992, 168, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (993, 169, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (994, 170, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (995, 171, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (996, 172, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (997, 173, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (998, 175, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (999, 176, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1000, 177, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1001, 178, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1002, 179, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1003, 180, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1004, 181, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1005, 182, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1006, 183, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1007, 184, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1008, 185, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1009, 186, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1010, 187, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1011, 188, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1012, 189, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1013, 190, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1014, 191, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1015, 192, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1016, 193, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1017, 194, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1018, 195, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1019, 196, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1020, 197, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1021, 198, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1022, 199, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1023, 200, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1024, 201, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1025, 202, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1026, 203, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1027, 204, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1028, 205, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1029, 206, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1030, 207, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1031, 208, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1032, 209, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1033, 210, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1034, 211, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1035, 212, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1036, 213, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1037, 214, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1038, 216, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1039, 218, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1040, 219, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1041, 220, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1042, 225, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1043, 226, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1044, 228, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1045, 232, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1046, 233, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1047, 234, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1048, 235, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1049, 236, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1050, 237, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1051, 238, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1052, 239, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1053, 240, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1054, 241, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1055, 242, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1056, 243, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1057, 244, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1058, 245, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1059, 247, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1060, 248, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1061, 249, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1062, 250, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1063, 251, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1064, 252, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1065, 253, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1066, 255, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1067, 256, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1068, 257, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1069, 258, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1070, 259, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1071, 260, 6, 1, CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.610' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1072, 154, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1073, 155, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1074, 156, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1075, 157, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1076, 158, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1077, 159, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1078, 160, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1079, 161, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1080, 162, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1081, 163, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1082, 164, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1083, 165, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1084, 166, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1085, 167, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1086, 168, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1087, 169, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1088, 170, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1089, 171, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1090, 172, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1091, 173, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1092, 175, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1093, 176, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1094, 177, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1095, 178, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1096, 179, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1097, 180, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1098, 181, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1099, 182, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1100, 183, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1101, 184, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1102, 185, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1103, 186, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1104, 187, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1105, 188, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1106, 189, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1107, 190, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1108, 191, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1109, 192, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1110, 193, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1111, 194, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1112, 195, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1113, 196, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1114, 197, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1115, 198, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1116, 199, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1117, 200, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1118, 201, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1119, 202, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1120, 203, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1121, 204, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1122, 205, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1123, 206, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1124, 207, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1125, 208, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1126, 209, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1127, 210, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1128, 211, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1129, 212, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1130, 213, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1131, 214, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1132, 216, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1133, 218, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1134, 219, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1135, 220, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1136, 225, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1137, 226, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1138, 228, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1139, 232, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1140, 233, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1141, 234, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1142, 235, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1143, 236, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1144, 237, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1145, 238, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1146, 239, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1147, 240, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1148, 241, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1149, 242, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1150, 243, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1151, 244, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1152, 245, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1153, 247, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1154, 248, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1155, 249, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1156, 250, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1157, 251, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1158, 252, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1159, 253, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1160, 255, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1161, 256, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1162, 257, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1163, 258, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1164, 259, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectActivity] ([Id], [ProjectId], [ActivityId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1165, 260, 7, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
SET IDENTITY_INSERT [dbo].[ProjectActivity] OFF
GO
SET IDENTITY_INSERT [dbo].[ProjectTeam] ON 
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1, 6, 9, CAST(N'2021-12-14T05:42:00.863' AS DateTime), N'dino.liu', CAST(N'2021-12-14T06:26:55.650' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (2, 7, 9, CAST(N'2021-12-14T08:13:49.950' AS DateTime), N'dino.liu', CAST(N'2021-12-15T01:55:16.570' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (3, 8, 9, CAST(N'2021-12-15T17:06:28.603' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-15T17:06:28.603' AS DateTime), N'SA_TS_Project_admin')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (4, 9, 4, CAST(N'2021-12-15T20:36:11.860' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-15T20:36:11.860' AS DateTime), N'SA_TS_Project_admin')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (5, 9, 9, CAST(N'2021-12-15T20:36:11.860' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-15T20:36:11.860' AS DateTime), N'SA_TS_Project_admin')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (6, 10, 4, CAST(N'2021-12-16T00:49:48.650' AS DateTime), N'li.zhang', CAST(N'2021-12-29T02:22:08.990' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (10, 11, 2, CAST(N'2021-12-29T01:35:03.173' AS DateTime), N'dino.liu', CAST(N'2021-12-29T01:38:52.703' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (8, 12, 1, CAST(N'2021-12-16T20:08:45.060' AS DateTime), N'SA_TS_Project_admin', CAST(N'2021-12-16T20:08:45.060' AS DateTime), N'SA_TS_Project_admin')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (9, 13, 9, CAST(N'2021-12-22T07:21:03.017' AS DateTime), N'dino.liu', CAST(N'2021-12-22T07:21:03.017' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (11, 14, 1, CAST(N'2021-12-31T02:11:01.267' AS DateTime), N'dino.liu', CAST(N'2021-12-31T02:11:01.280' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (12, 15, 1, CAST(N'2021-12-31T02:13:30.847' AS DateTime), N'dino.liu', CAST(N'2021-12-31T02:13:30.847' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (13, 19, 1, CAST(N'2022-01-07T02:58:04.083' AS DateTime), N'dino.liu', CAST(N'2022-01-07T02:58:04.100' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (14, 20, 4, CAST(N'2022-01-11T03:00:48.977' AS DateTime), N'dino.liu', CAST(N'2022-01-11T03:00:48.993' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (15, 21, 1, CAST(N'2022-01-13T06:06:37.603' AS DateTime), N'dino.liu', CAST(N'2022-01-13T06:24:39.363' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (16, 22, 3, CAST(N'2022-01-13T06:27:27.303' AS DateTime), N'dino.liu', CAST(N'2022-01-13T06:27:27.303' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (303, 154, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (304, 155, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (305, 156, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (308, 157, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (306, 157, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (307, 157, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (309, 158, 7, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (310, 158, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (159, 159, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (160, 160, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (161, 161, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (162, 161, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (163, 162, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (164, 163, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (166, 164, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (165, 164, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (167, 165, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (169, 166, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (168, 166, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (170, 167, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (171, 168, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (174, 169, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (172, 169, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (176, 169, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (175, 169, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (173, 169, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (177, 170, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (178, 171, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (179, 172, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (181, 173, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (180, 173, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (182, 174, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (183, 174, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (184, 175, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (185, 176, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (186, 177, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (187, 178, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (189, 178, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (188, 178, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (190, 179, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (192, 179, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (193, 179, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (191, 179, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (194, 179, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (195, 180, 7, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (196, 181, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (197, 181, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (301, 182, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (302, 183, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (198, 184, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (199, 185, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (200, 186, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (201, 187, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (202, 188, 7, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (203, 189, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (204, 190, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (205, 191, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (206, 192, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (207, 193, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (208, 194, 7, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (209, 195, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (210, 196, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (211, 197, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (212, 197, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (213, 198, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (214, 199, 1, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (216, 199, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (215, 199, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (217, 199, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (218, 200, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (219, 201, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (220, 202, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (221, 203, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (223, 204, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (222, 204, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (224, 205, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (225, 206, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (226, 207, 7, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (227, 208, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (228, 209, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (229, 210, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (231, 211, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (232, 212, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (233, 213, 2, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (230, 214, 5, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (234, 215, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (235, 216, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (236, 217, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (237, 218, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (238, 219, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (239, 220, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (240, 221, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (241, 222, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (242, 223, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (243, 224, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (244, 225, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (245, 226, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (246, 227, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (247, 228, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (248, 229, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (249, 230, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (250, 231, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (251, 232, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (252, 232, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (253, 233, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (254, 233, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (255, 234, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (256, 234, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (257, 235, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (258, 235, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (259, 236, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (260, 236, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (261, 237, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (262, 237, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (263, 238, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (264, 238, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (265, 239, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (266, 239, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (267, 240, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (268, 240, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (269, 241, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (270, 241, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (271, 242, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (272, 242, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (273, 243, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (274, 243, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (277, 244, 3, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (275, 244, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (276, 244, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (278, 245, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (279, 245, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (280, 246, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (281, 246, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (282, 247, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (283, 247, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (284, 247, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (285, 248, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (286, 248, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (287, 249, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (288, 249, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (289, 250, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (290, 250, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (291, 251, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (292, 251, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (293, 252, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (294, 252, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (295, 253, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (296, 253, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (297, 254, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (298, 254, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (299, 255, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (300, 255, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (311, 256, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (312, 256, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (313, 257, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (314, 257, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (315, 258, 4, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (316, 258, 6, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (317, 259, 8, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
INSERT [dbo].[ProjectTeam] ([Id], [ProjectId], [TeamId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (318, 260, 9, CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino', CAST(N'2022-01-25T00:27:37.623' AS DateTime), N'ImportedByDino')
GO
SET IDENTITY_INSERT [dbo].[ProjectTeam] OFF
GO
SET IDENTITY_INSERT [dbo].[Team] ON 
GO
INSERT [dbo].[Team] ([Id], [Name], [ShortName], [DeptCode], [AccountingEntityId], [ManagerId], [OwnerId], [ParentId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1, N'257 Corporate IT Audit', N'Audit', N'257', 1, 3, 3, 0, 1, CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system', CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system')
GO
INSERT [dbo].[Team] ([Id], [Name], [ShortName], [DeptCode], [AccountingEntityId], [ManagerId], [OwnerId], [ParentId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (2, N'706 Front-End Processing Operations', N'Front-End', N'706', 1, 4, 5, 0, 1, CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system', CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system')
GO
INSERT [dbo].[Team] ([Id], [Name], [ShortName], [DeptCode], [AccountingEntityId], [ManagerId], [OwnerId], [ParentId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (3, N'707 IT Development - Operations Back Office', N'Back Office', N'707', 1, 7, 7, 0, 1, CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system', CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system')
GO
INSERT [dbo].[Team] ([Id], [Name], [ShortName], [DeptCode], [AccountingEntityId], [ManagerId], [OwnerId], [ParentId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (4, N'707 IT Development - Operations Back Office-CHINA', N'China', N'707', 2, 15, 6, 0, 1, CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system', CAST(N'2022-01-07T02:03:33.533' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[Team] ([Id], [Name], [ShortName], [DeptCode], [AccountingEntityId], [ManagerId], [OwnerId], [ParentId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (5, N'708 EVO Snap', N'Snap', N'708', 1, 8, 8, 0, 1, CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system', CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system')
GO
INSERT [dbo].[Team] ([Id], [Name], [ShortName], [DeptCode], [AccountingEntityId], [ManagerId], [OwnerId], [ParentId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (6, N'714 Quality Assurance', N'QA', N'714', 2, 9, 9, 0, 1, CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system', CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system')
GO
INSERT [dbo].[Team] ([Id], [Name], [ShortName], [DeptCode], [AccountingEntityId], [ManagerId], [OwnerId], [ParentId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (7, N'718 Back-End Software Development', N'Back-End', N'718', 1, 10, 10, 0, 1, CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system', CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system')
GO
INSERT [dbo].[Team] ([Id], [Name], [ShortName], [DeptCode], [AccountingEntityId], [ManagerId], [OwnerId], [ParentId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (8, N'723 Delego IT', N'Delego', N'723', 3, 12, 12, 0, 1, CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system', CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system')
GO
INSERT [dbo].[Team] ([Id], [Name], [ShortName], [DeptCode], [AccountingEntityId], [ManagerId], [OwnerId], [ParentId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (9, N'724 IT Development - Financial & Risk Back Office', N'F&R', N'724', 1, 11, 11, 0, 1, CAST(N'2021-12-03T22:51:53.330' AS DateTime), N'system', CAST(N'2021-12-29T02:39:20.967' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[Team] ([Id], [Name], [ShortName], [DeptCode], [AccountingEntityId], [ManagerId], [OwnerId], [ParentId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (10, N'707 payfabric', N'pf', N'707', 1, 7, 7, 4, 1, CAST(N'2021-12-22T00:00:00.000' AS DateTime), N'system', CAST(N'2021-12-22T00:00:00.000' AS DateTime), N'system')
GO
INSERT [dbo].[Team] ([Id], [Name], [ShortName], [DeptCode], [AccountingEntityId], [ManagerId], [OwnerId], [ParentId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (11, N'724 NY BA', N'NYBA', N'724', 1, 185, 11, 9, 1, CAST(N'2022-01-12T00:00:00.000' AS DateTime), N'system', CAST(N'2022-01-12T00:00:00.000' AS DateTime), N'system')
GO
SET IDENTITY_INSERT [dbo].[Team] OFF
GO
SET IDENTITY_INSERT [dbo].[TeamEmployee] ON 
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1, 1, 13, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (64, 1, 30, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (65, 1, 31, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (180, 1, 193, 1, CAST(N'2022-01-13T01:59:56.350' AS DateTime), N'dino.liu', CAST(N'2022-01-13T01:59:56.350' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (131, 2, 32, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (84, 2, 33, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (128, 2, 34, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (83, 2, 35, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (130, 2, 36, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (82, 2, 37, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (132, 2, 38, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (129, 2, 39, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (133, 2, 40, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (163, 2, 41, 1, CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (164, 2, 42, 1, CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (2, 3, 17, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (3, 3, 18, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (4, 3, 19, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (85, 3, 76, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (86, 3, 77, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (87, 3, 78, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (88, 3, 79, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (89, 3, 80, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (90, 3, 81, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (91, 3, 82, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (92, 3, 83, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (93, 3, 84, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (94, 3, 85, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (95, 3, 86, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (96, 3, 87, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (97, 3, 88, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (98, 3, 89, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (99, 3, 90, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (111, 3, 91, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (113, 3, 92, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (114, 3, 93, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (115, 3, 94, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (135, 3, 95, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (136, 3, 96, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (137, 3, 97, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (138, 3, 98, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (177, 4, 6, 1, CAST(N'2021-12-16T06:36:11.470' AS DateTime), N'dino.liu', CAST(N'2021-12-16T06:36:11.470' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (6, 4, 13, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (5, 4, 14, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (7, 4, 15, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (8, 4, 16, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (42, 4, 30, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (51, 4, 31, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (26, 4, 43, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-16T01:39:34.730' AS DateTime), N'li.zhang')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (27, 4, 44, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (28, 4, 45, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (29, 4, 46, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (165, 4, 47, 1, CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (30, 4, 48, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (31, 4, 49, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (32, 4, 50, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (33, 4, 51, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (34, 4, 52, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (35, 4, 53, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (36, 4, 54, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (37, 4, 55, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (38, 4, 56, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (39, 4, 57, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (40, 4, 58, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (41, 4, 59, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (43, 4, 60, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2022-01-07T02:02:12.783' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (44, 4, 61, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (45, 4, 62, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (46, 4, 63, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (47, 4, 64, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (48, 4, 65, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (49, 4, 66, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (50, 4, 67, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (166, 4, 68, 1, CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (52, 4, 69, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (53, 4, 70, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (54, 4, 71, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (55, 4, 72, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (56, 4, 73, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (57, 4, 74, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (58, 4, 75, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (178, 4, 191, 1, CAST(N'2021-12-29T02:38:53.280' AS DateTime), N'dino.liu', CAST(N'2021-12-29T02:39:04.810' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (10, 5, 20, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (9, 5, 21, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (11, 5, 22, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (103, 5, 99, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (107, 5, 100, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (100, 5, 101, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (105, 5, 102, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (142, 5, 103, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (102, 5, 104, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (146, 5, 105, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (101, 5, 106, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (106, 5, 107, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (104, 5, 108, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (144, 5, 109, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (139, 5, 110, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (140, 5, 111, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (110, 5, 112, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (143, 5, 113, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (108, 5, 114, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (145, 5, 115, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (109, 5, 116, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (141, 5, 117, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (167, 5, 118, 1, CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (168, 5, 119, 1, CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (169, 5, 120, 1, CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (170, 5, 121, 1, CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (171, 5, 122, 1, CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (172, 5, 123, 1, CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (173, 5, 124, 1, CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport', CAST(N'2021-12-09T19:37:54.607' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (12, 6, 23, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (59, 6, 125, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (69, 6, 126, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (66, 6, 127, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (74, 6, 128, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (60, 6, 129, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (61, 6, 130, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (72, 6, 131, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (134, 6, 132, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (76, 6, 133, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (62, 6, 134, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (79, 6, 135, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (77, 6, 136, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (67, 6, 137, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (78, 6, 138, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (70, 6, 139, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (63, 6, 140, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (75, 6, 141, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (73, 6, 142, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (81, 6, 143, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (80, 6, 144, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (68, 6, 145, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (71, 6, 146, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (14, 7, 24, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (13, 7, 25, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (125, 7, 147, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (124, 7, 148, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (126, 7, 149, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (118, 7, 150, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (117, 7, 151, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (112, 7, 152, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (127, 7, 153, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (121, 7, 154, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (116, 7, 155, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (123, 7, 156, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (119, 7, 157, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (120, 7, 158, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (122, 7, 159, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (174, 7, 160, 1, CAST(N'2021-12-09T19:41:06.500' AS DateTime), N'batchimport', CAST(N'2021-12-09T19:41:06.500' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (15, 8, 29, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (22, 8, 177, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (23, 8, 178, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (20, 8, 179, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (19, 8, 180, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (25, 8, 181, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (21, 8, 182, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (24, 8, 183, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (16, 9, 26, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (17, 9, 27, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (18, 9, 28, 1, CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:29:13.007' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (147, 9, 161, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (148, 9, 162, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (149, 9, 163, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (150, 9, 164, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (151, 9, 165, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (152, 9, 166, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-24T07:43:24.563' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (153, 9, 167, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (154, 9, 168, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (155, 9, 169, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (156, 9, 170, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (157, 9, 171, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (158, 9, 172, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (159, 9, 173, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (160, 9, 174, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (161, 9, 175, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (162, 9, 176, 1, CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport', CAST(N'2021-12-09T18:34:19.670' AS DateTime), N'batchimport')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (176, 9, 185, 1, CAST(N'2021-12-15T17:12:15.703' AS DateTime), N'maiseyl', CAST(N'2022-01-12T15:34:36.130' AS DateTime), N'maiseyl')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (175, 11, 184, 1, CAST(N'2021-12-13T20:52:46.317' AS DateTime), N'ts_superuser', CAST(N'2022-01-12T15:32:41.503' AS DateTime), N'maiseyl')
GO
INSERT [dbo].[TeamEmployee] ([Id], [TeamId], [EmployeeId], [IsActive], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (179, 11, 192, 1, CAST(N'2022-01-12T15:33:46.490' AS DateTime), N'maiseyl', CAST(N'2022-01-12T15:34:50.490' AS DateTime), N'maiseyl')
GO
SET IDENTITY_INSERT [dbo].[TeamEmployee] OFF
GO
SET IDENTITY_INSERT [dbo].[TimesheetActivity] ON 
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (2, 173, 1, 8, CAST(N'2021-12-14' AS Date), CAST(9.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2021-12-14T02:03:06.887' AS DateTime), N'Paul  Rao', CAST(N'2021-12-14T02:03:13.387' AS DateTime), N'Paul  Rao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (3, 173, 2, 8, CAST(N'2021-12-14' AS Date), CAST(0.01 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2021-12-14T03:35:00.920' AS DateTime), N'Paul  Rao', CAST(N'2021-12-14T08:41:03.433' AS DateTime), N'Paul  Rao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (9, 166, 6, 7, CAST(N'2021-12-14' AS Date), CAST(99.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2021-12-14T08:50:05.257' AS DateTime), N'Dino  Liu', CAST(N'2021-12-14T08:50:44.757' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (11, 173, 3, 8, CAST(N'2021-12-14' AS Date), CAST(66.00 AS Decimal(18, 2)), N'666', 1, NULL, CAST(N'2021-12-14T08:51:55.790' AS DateTime), N'Paul  Rao', CAST(N'2021-12-15T08:03:16.717' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (13, 166, 2, 8, CAST(N'2021-12-14' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2021-12-14T08:55:46.480' AS DateTime), N'Dino  Liu', CAST(N'2021-12-14T08:55:46.480' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (14, 166, 2, 8, CAST(N'2021-12-16' AS Date), CAST(7.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2021-12-15T06:45:21.997' AS DateTime), N'Dino  Liu', CAST(N'2021-12-15T06:45:21.997' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (15, 166, 2, 8, CAST(N'2021-12-17' AS Date), CAST(7.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2021-12-15T06:48:12.623' AS DateTime), N'Dino  Liu', CAST(N'2021-12-15T06:48:12.623' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (16, 166, 2, 8, CAST(N'2021-12-15' AS Date), CAST(6.00 AS Decimal(18, 2)), N'candice', 1, NULL, CAST(N'2021-12-15T06:53:16.597' AS DateTime), N'Dino  Liu', CAST(N'2021-12-15T06:53:16.597' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (17, 127, 1, 8, CAST(N'2021-12-15' AS Date), CAST(44.00 AS Decimal(18, 2)), N'arya 12.15', 1, 6, CAST(N'2021-12-15T07:25:44.583' AS DateTime), N'Dino  Liu', CAST(N'2021-12-15T07:25:44.583' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (18, 169, 6, 7, CAST(N'2021-12-15' AS Date), CAST(55.00 AS Decimal(18, 2)), N'44444', 1, NULL, CAST(N'2021-12-15T07:26:22.930' AS DateTime), N'Dino  Liu', CAST(N'2021-12-15T07:52:34.360' AS DateTime), N'Kuo  Wang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (19, 147, 1, 8, CAST(N'2021-12-15' AS Date), CAST(4.00 AS Decimal(18, 2)), N'alex 12-15', 1, 11, CAST(N'2021-12-15T07:31:25.420' AS DateTime), N'Dino  Liu', CAST(N'2021-12-15T07:33:48.300' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (20, 4, 1, 8, CAST(N'2021-12-15' AS Date), CAST(6.00 AS Decimal(18, 2)), N'66', 1, 0, CAST(N'2021-12-15T07:36:20.460' AS DateTime), N'Dino  Liu', CAST(N'2021-12-15T07:36:20.460' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (22, 60, 3, 8, CAST(N'2021-12-16' AS Date), CAST(44.00 AS Decimal(18, 2)), N'4444', 1, 5, CAST(N'2021-12-15T07:41:51.667' AS DateTime), N'Kuo  Wang', CAST(N'2021-12-15T07:41:51.667' AS DateTime), N'Kuo  Wang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (23, 60, 1, 8, CAST(N'2021-12-16' AS Date), CAST(44.00 AS Decimal(18, 2)), N'4444', 1, 5, CAST(N'2021-12-15T07:44:37.830' AS DateTime), N'Kuo  Wang', CAST(N'2021-12-15T07:44:37.830' AS DateTime), N'Kuo  Wang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (24, 60, 1, 8, CAST(N'2021-12-15' AS Date), CAST(55.00 AS Decimal(18, 2)), N'4446', 1, 5, CAST(N'2021-12-15T07:47:54.000' AS DateTime), N'Kuo  Wang', CAST(N'2021-12-15T08:01:54.560' AS DateTime), N'Kuo  Wang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (25, 60, 2, 8, CAST(N'2021-12-15' AS Date), CAST(33.00 AS Decimal(18, 2)), N'6555', 1, 5, CAST(N'2021-12-15T08:02:20.513' AS DateTime), N'Kuo  Wang', CAST(N'2021-12-15T08:02:20.513' AS DateTime), N'Kuo  Wang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (26, 137, 2, 8, CAST(N'2021-12-15' AS Date), CAST(66.00 AS Decimal(18, 2)), N'666', 1, 12, CAST(N'2021-12-15T08:03:09.843' AS DateTime), N'Dino  Liu', CAST(N'2021-12-15T08:05:25.843' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (28, 137, 3, 8, CAST(N'2021-12-15' AS Date), CAST(55.00 AS Decimal(18, 2)), N'55', 1, 12, CAST(N'2021-12-15T08:06:25.703' AS DateTime), N'Dino  Liu', CAST(N'2021-12-16T05:28:29.643' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (29, 60, 4, 8, CAST(N'2021-12-17' AS Date), CAST(555.00 AS Decimal(18, 2)), N'444', 1, 5, CAST(N'2021-12-15T08:10:45.990' AS DateTime), N'Kuo  Wang', CAST(N'2021-12-15T08:10:45.990' AS DateTime), N'Kuo  Wang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (30, 60, 5, 8, CAST(N'2021-12-15' AS Date), CAST(44.00 AS Decimal(18, 2)), N'444', 1, 5, CAST(N'2021-12-15T08:17:04.103' AS DateTime), N'Kuo  Wang', CAST(N'2021-12-15T08:17:04.103' AS DateTime), N'Kuo  Wang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (31, 166, 6, 7, CAST(N'2021-12-15' AS Date), CAST(55.00 AS Decimal(18, 2)), N'444', 1, NULL, CAST(N'2021-12-15T08:18:25.900' AS DateTime), N'Dino  Liu', CAST(N'2021-12-15T08:18:25.900' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (32, 184, 6, 7, CAST(N'2021-12-08' AS Date), CAST(12.80 AS Decimal(18, 2)), NULL, 1, 20, CAST(N'2021-12-15T16:13:12.540' AS DateTime), N'BA-ResourceOne  DummyBAU1', CAST(N'2021-12-15T16:13:12.540' AS DateTime), N'BA-ResourceOne  DummyBAU1')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (33, 184, 8, 2, CAST(N'2021-12-01' AS Date), CAST(0.10 AS Decimal(18, 2)), N'Enter by TS Admin', 1, 20, CAST(N'2021-12-15T17:15:49.193' AS DateTime), N'Atik_TS  Timesheet_Admin', CAST(N'2021-12-15T17:15:49.193' AS DateTime), N'Atik_TS  Timesheet_Admin')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (34, 43, 1, 8, CAST(N'2021-11-01' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, 1, CAST(N'2021-12-15T20:12:42.630' AS DateTime), N'Andrew PC Zhang', CAST(N'2021-12-15T20:12:42.630' AS DateTime), N'Andrew PC Zhang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (35, 119, 2, 8, CAST(N'2021-12-09' AS Date), CAST(333.00 AS Decimal(18, 2)), NULL, 1, 10, CAST(N'2021-12-16T05:31:08.663' AS DateTime), N'Dino  Liu', CAST(N'2021-12-24T05:50:47.400' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (36, 119, 2, 8, CAST(N'2021-12-08' AS Date), CAST(33.00 AS Decimal(18, 2)), NULL, 1, 10, CAST(N'2021-12-16T05:31:33.070' AS DateTime), N'Dino  Liu', CAST(N'2021-12-16T05:31:33.070' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (37, 6, 1, 8, CAST(N'2021-12-16' AS Date), CAST(10.00 AS Decimal(18, 2)), NULL, 1, 8, CAST(N'2021-12-16T06:01:43.567' AS DateTime), N'Richard  Zhang', CAST(N'2021-12-16T06:01:43.567' AS DateTime), N'Richard  Zhang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (39, 6, 1, 8, CAST(N'2021-12-17' AS Date), CAST(88.00 AS Decimal(18, 2)), N'88', 1, 8, CAST(N'2021-12-17T03:02:57.180' AS DateTime), N'Richard  Zhang', CAST(N'2021-12-17T06:51:58.317' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (41, 43, 2, 8, CAST(N'2022-01-05' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2021-12-17T03:04:06.557' AS DateTime), N'Dino  Liu', CAST(N'2021-12-17T03:08:11.400' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (42, 85, 1, 8, CAST(N'2021-12-17' AS Date), CAST(77.00 AS Decimal(18, 2)), N'77', 1, 16, CAST(N'2021-12-17T03:09:39.540' AS DateTime), N'Dino  Liu', CAST(N'2021-12-17T03:09:39.540' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (43, 119, 1, 8, CAST(N'2021-12-17' AS Date), CAST(9.00 AS Decimal(18, 2)), N'779', 1, 10, CAST(N'2021-12-17T03:21:36.367' AS DateTime), N'Dino  Liu', CAST(N'2021-12-17T06:42:19.660' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (44, 26, 6, 7, CAST(N'2021-12-17' AS Date), CAST(77.00 AS Decimal(18, 2)), N'55784', 1, 9, CAST(N'2021-12-17T06:03:18.943' AS DateTime), N'Dino  Liu', CAST(N'2021-12-17T06:51:00.753' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (46, 26, 2, 8, CAST(N'2021-12-17' AS Date), CAST(0.00 AS Decimal(18, 2)), N'88', 1, NULL, CAST(N'2021-12-17T06:51:51.100' AS DateTime), N'Dino  Liu', CAST(N'2021-12-17T06:51:51.100' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (47, 6, 1, 8, CAST(N'2021-11-09' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, 8, CAST(N'2021-12-17T07:06:34.823' AS DateTime), N'Richard  Zhang', CAST(N'2021-12-17T07:06:34.823' AS DateTime), N'Richard  Zhang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (48, 6, 4, 8, CAST(N'2021-11-09' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, 8, CAST(N'2021-12-17T07:06:35.650' AS DateTime), N'Richard  Zhang', CAST(N'2021-12-17T07:06:35.650' AS DateTime), N'Richard  Zhang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (49, 43, 4, 8, CAST(N'2021-12-17' AS Date), CAST(7.00 AS Decimal(18, 2)), NULL, 1, 3, CAST(N'2021-12-17T07:48:34.103' AS DateTime), N'Dino  Liu', CAST(N'2021-12-17T07:48:34.103' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (50, 60, 1, 8, CAST(N'2021-12-17' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, 5, CAST(N'2021-12-17T08:00:20.830' AS DateTime), N'Kuo  Wang', CAST(N'2021-12-17T08:00:20.830' AS DateTime), N'Kuo  Wang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (51, 60, 5, 8, CAST(N'2021-12-17' AS Date), CAST(7.00 AS Decimal(18, 2)), NULL, 1, 5, CAST(N'2021-12-17T08:00:22.533' AS DateTime), N'Kuo  Wang', CAST(N'2021-12-17T08:00:22.533' AS DateTime), N'Kuo  Wang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (52, 45, 1, 8, CAST(N'2021-11-10' AS Date), CAST(3.00 AS Decimal(18, 2)), N'3', 1, 4, CAST(N'2021-12-20T01:39:16.983' AS DateTime), N'Dino  Liu', CAST(N'2021-12-20T01:39:16.983' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (55, 6, 2, 8, CAST(N'2021-12-21' AS Date), CAST(4.00 AS Decimal(18, 2)), NULL, 2, 8, CAST(N'2021-12-20T07:09:16.257' AS DateTime), N'liang.zhao', CAST(N'2021-12-20T07:09:16.257' AS DateTime), N'liang.zhao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (56, 119, 1, 8, CAST(N'2021-12-21' AS Date), CAST(0.60 AS Decimal(18, 2)), NULL, 1, 10, CAST(N'2021-12-21T08:58:51.537' AS DateTime), N'Paul  Rao', CAST(N'2021-12-21T08:58:51.537' AS DateTime), N'Paul  Rao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (57, 119, 1, 8, CAST(N'2021-12-26' AS Date), CAST(6.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2021-12-22T07:44:46.640' AS DateTime), N'Dino  Liu', CAST(N'2021-12-22T07:44:46.640' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (58, 3, 1, 8, CAST(N'2021-12-16' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, 13, CAST(N'2021-12-24T03:11:01.520' AS DateTime), N'Paul  Rao', CAST(N'2021-12-24T03:11:01.520' AS DateTime), N'Paul  Rao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (59, 3, 2, 8, CAST(N'2021-12-16' AS Date), CAST(9.00 AS Decimal(18, 2)), NULL, 1, 13, CAST(N'2021-12-24T03:11:16.210' AS DateTime), N'Paul  Rao', CAST(N'2021-12-24T03:11:16.210' AS DateTime), N'Paul  Rao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (62, 4, 2, 8, CAST(N'2021-12-24' AS Date), CAST(7.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2021-12-24T05:48:22.010' AS DateTime), N'Dino  Liu', CAST(N'2021-12-24T05:48:22.010' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (64, 103, 2, 8, CAST(N'2021-12-24' AS Date), CAST(6.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2021-12-24T05:55:28.640' AS DateTime), N'Dino  Liu', CAST(N'2021-12-24T05:55:28.640' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (65, 103, 1, 8, CAST(N'2021-12-24' AS Date), CAST(74.00 AS Decimal(18, 2)), N'44', 1, NULL, CAST(N'2021-12-24T05:56:11.250' AS DateTime), N'Dino  Liu', CAST(N'2021-12-24T07:46:36.930' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (84, 103, 3, 8, CAST(N'2021-12-24' AS Date), CAST(4.00 AS Decimal(18, 2)), N'4', 1, NULL, CAST(N'2021-12-24T07:29:42.980' AS DateTime), N'Dino  Liu', CAST(N'2021-12-24T07:29:42.980' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (85, 119, 1, 8, CAST(N'2021-12-24' AS Date), CAST(10.00 AS Decimal(18, 2)), NULL, 1, 10, CAST(N'2021-12-24T07:42:54.830' AS DateTime), N'Paul  Rao', CAST(N'2021-12-24T07:42:54.830' AS DateTime), N'Paul  Rao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (86, 127, 1, 8, CAST(N'2021-12-24' AS Date), CAST(4.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2021-12-24T07:48:09.240' AS DateTime), N'Dino  Liu', CAST(N'2021-12-24T07:48:09.240' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (87, 161, 1, 8, CAST(N'2021-12-24' AS Date), CAST(3.00 AS Decimal(18, 2)), N'3', 1, 17, CAST(N'2021-12-24T07:48:25.053' AS DateTime), N'Dino  Liu', CAST(N'2021-12-24T07:48:25.053' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (88, 137, 3, 8, CAST(N'2021-12-24' AS Date), CAST(57.00 AS Decimal(18, 2)), N'44', 1, 12, CAST(N'2021-12-24T08:15:00.523' AS DateTime), N'Dino  Liu', CAST(N'2021-12-24T08:15:34.227' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (89, 137, 5, 8, CAST(N'2021-12-24' AS Date), CAST(59.00 AS Decimal(18, 2)), N'855', 1, 12, CAST(N'2021-12-24T08:15:03.540' AS DateTime), N'Dino  Liu', CAST(N'2021-12-24T08:15:31.960' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (90, 137, 4, 8, CAST(N'2021-12-24' AS Date), CAST(75.00 AS Decimal(18, 2)), N'55', 1, 12, CAST(N'2021-12-24T08:15:22.570' AS DateTime), N'Dino  Liu', CAST(N'2021-12-24T08:15:29.553' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (91, 147, 2, 8, CAST(N'2021-12-24' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, 11, CAST(N'2021-12-24T08:20:12.103' AS DateTime), N'Paul  Rao', CAST(N'2021-12-24T08:20:12.103' AS DateTime), N'Paul  Rao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (92, 119, 3, 8, CAST(N'2021-12-29' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2021-12-29T02:22:39.707' AS DateTime), N'Dino  Liu', CAST(N'2021-12-29T02:22:39.707' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (93, 119, 2, 8, CAST(N'2021-12-29' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2021-12-29T02:22:43.537' AS DateTime), N'Dino  Liu', CAST(N'2021-12-29T02:22:43.537' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (94, 0, 3, 8, CAST(N'2022-01-06' AS Date), CAST(0.00 AS Decimal(18, 2)), N'111122', 1, NULL, CAST(N'2022-01-06T00:47:05.737' AS DateTime), N'  ', CAST(N'2022-01-06T00:47:18.940' AS DateTime), N'  ')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (96, 15, 9, 1, CAST(N'2022-01-06' AS Date), CAST(0.00 AS Decimal(18, 2)), N'2222', 1, NULL, CAST(N'2022-01-06T05:09:14.980' AS DateTime), N'Jason  Zhao', CAST(N'2022-01-06T05:09:14.980' AS DateTime), N'Jason  Zhao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (97, 6, 4, 8, CAST(N'2022-01-08' AS Date), CAST(3.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-06T05:25:30.170' AS DateTime), N'Dino  Liu', CAST(N'2022-01-06T05:25:30.170' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (98, 6, 1, 8, CAST(N'2022-01-08' AS Date), CAST(3.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-06T05:25:30.980' AS DateTime), N'Dino  Liu', CAST(N'2022-01-06T05:25:30.980' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (99, 6, 4, 8, CAST(N'2022-01-14' AS Date), CAST(7.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-06T05:26:11.107' AS DateTime), N'Dino  Liu', CAST(N'2022-01-06T05:26:11.107' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (100, 6, 1, 8, CAST(N'2022-01-14' AS Date), CAST(7.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-06T05:26:11.747' AS DateTime), N'Dino  Liu', CAST(N'2022-01-06T05:26:11.747' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (101, 15, 9, 1, CAST(N'2022-01-07' AS Date), CAST(0.00 AS Decimal(18, 2)), N'3333', 1, NULL, CAST(N'2022-01-07T00:27:00.927' AS DateTime), N'Jason  Zhao', CAST(N'2022-01-07T00:27:04.333' AS DateTime), N'Jason  Zhao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (102, 4, 2, 8, CAST(N'2022-01-07' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-07T00:36:30.573' AS DateTime), N'Dino  Liu', CAST(N'2022-01-07T00:36:30.573' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (103, 26, 6, 7, CAST(N'2022-01-07' AS Date), CAST(0.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-07T00:36:44.200' AS DateTime), N'Dino  Liu', CAST(N'2022-01-07T00:37:37.763' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (104, 0, 3, 8, CAST(N'2022-01-07' AS Date), CAST(0.00 AS Decimal(18, 2)), N'66666', 1, NULL, CAST(N'2022-01-07T00:37:42.357' AS DateTime), N'Dino  Liu', CAST(N'2022-01-07T00:37:42.357' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (106, 60, 5, 8, CAST(N'2022-01-15' AS Date), CAST(33.00 AS Decimal(18, 2)), NULL, 2, NULL, CAST(N'2022-01-07T02:22:55.240' AS DateTime), N'liang.zhao', CAST(N'2022-01-07T02:22:55.240' AS DateTime), N'liang.zhao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (107, 147, 2, 8, CAST(N'2021-12-22' AS Date), CAST(9.00 AS Decimal(18, 2)), NULL, 1, 11, CAST(N'2022-01-10T06:21:36.537' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:21:36.537' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (108, 137, 1, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, 12, CAST(N'2022-01-10T06:21:46.067' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:21:46.067' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (109, 137, 3, 8, CAST(N'2021-12-22' AS Date), CAST(6.00 AS Decimal(18, 2)), NULL, 1, 12, CAST(N'2022-01-10T06:21:50.440' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:21:50.440' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (110, 137, 4, 8, CAST(N'2021-12-22' AS Date), CAST(6.00 AS Decimal(18, 2)), NULL, 1, 12, CAST(N'2022-01-10T06:21:53.723' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:21:53.723' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (111, 137, 5, 8, CAST(N'2021-12-22' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, 12, CAST(N'2022-01-10T06:21:56.893' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:21:56.893' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (112, 4, 2, 8, CAST(N'2021-12-22' AS Date), CAST(7.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:22:03.473' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:22:03.473' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (113, 3, 1, 8, CAST(N'2021-12-22' AS Date), CAST(7.00 AS Decimal(18, 2)), NULL, 1, 13, CAST(N'2022-01-10T06:22:11.567' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:22:11.567' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (114, 3, 2, 8, CAST(N'2021-12-22' AS Date), CAST(6.00 AS Decimal(18, 2)), NULL, 1, 13, CAST(N'2022-01-10T06:22:14.520' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:22:14.520' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (115, 3, 4, 8, CAST(N'2021-12-22' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, 13, CAST(N'2022-01-10T06:22:17.347' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:22:17.347' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (116, 43, 4, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:22:22.033' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:22:22.033' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (117, 78, 2, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, 14, CAST(N'2022-01-10T06:22:37.880' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:22:37.880' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (118, 99, 5, 8, CAST(N'2021-12-22' AS Date), CAST(7.00 AS Decimal(18, 2)), NULL, 1, 15, CAST(N'2022-01-10T06:23:00.503' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:23:00.503' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (119, 85, 1, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, 16, CAST(N'2022-01-10T06:26:20.850' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:26:20.850' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (120, 127, 1, 8, CAST(N'2021-12-22' AS Date), CAST(7.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:26:26.083' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:26:26.083' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (121, 161, 1, 8, CAST(N'2021-12-22' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, 17, CAST(N'2022-01-10T06:26:34.677' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:26:34.677' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (122, 185, 1, 8, CAST(N'2021-12-22' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, 19, CAST(N'2022-01-10T06:26:38.930' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:26:38.930' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (123, 184, 1, 8, CAST(N'2021-12-22' AS Date), CAST(6.00 AS Decimal(18, 2)), NULL, 1, 20, CAST(N'2022-01-10T06:26:43.007' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:26:43.007' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (124, 184, 8, 2, CAST(N'2021-12-22' AS Date), CAST(6.00 AS Decimal(18, 2)), NULL, 1, 20, CAST(N'2022-01-10T06:26:46.520' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:26:46.520' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (125, 95, 18, 8, CAST(N'2021-12-22' AS Date), CAST(6.00 AS Decimal(18, 2)), NULL, 1, 18, CAST(N'2022-01-10T06:26:58.257' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:26:58.257' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (126, 69, 1, 8, CAST(N'2021-12-22' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, 21, CAST(N'2022-01-10T06:27:10.553' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:27:10.553' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (127, 73, 17, 8, CAST(N'2021-12-22' AS Date), CAST(6.00 AS Decimal(18, 2)), NULL, 1, 22, CAST(N'2022-01-10T06:27:24.130' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:27:24.130' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (128, 45, 1, 8, CAST(N'2021-12-22' AS Date), CAST(6.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:27:39.630' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:27:39.630' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (129, 20, 17, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, 23, CAST(N'2022-01-10T06:27:55.647' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:27:55.647' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (130, 145, 2, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, 24, CAST(N'2022-01-10T06:28:01.070' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:28:01.070' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (131, 100, 2, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, 25, CAST(N'2022-01-10T06:28:04.990' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:28:04.990' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (132, 148, 18, 8, CAST(N'2021-12-22' AS Date), CAST(9.00 AS Decimal(18, 2)), NULL, 1, 26, CAST(N'2022-01-10T06:28:18.490' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:28:18.490' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (133, 101, 3, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, 27, CAST(N'2022-01-10T06:28:23.757' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:28:23.757' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (134, 126, 16, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:28:36.130' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:28:36.130' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (135, 177, 16, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:28:47.913' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:28:47.913' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (136, 82, 17, 8, CAST(N'2021-12-22' AS Date), CAST(9.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:28:58.790' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:28:58.790' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (137, 62, 17, 8, CAST(N'2021-12-22' AS Date), CAST(9.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:29:10.680' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:29:10.680' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (138, 102, 17, 8, CAST(N'2021-12-22' AS Date), CAST(9.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:29:19.930' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:29:19.930' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (139, 12, 16, 8, CAST(N'2021-12-22' AS Date), CAST(9.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:29:32.303' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:29:32.303' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (140, 162, 1, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:29:45.227' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:29:45.227' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (141, 32, 4, 8, CAST(N'2021-12-22' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:36:22.493' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:36:22.493' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (142, 21, 4, 8, CAST(N'2021-12-22' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:36:33.210' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:36:33.210' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (143, 33, 3, 8, CAST(N'2021-12-22' AS Date), CAST(9.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:36:43.960' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:36:43.960' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (144, 121, 17, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:36:57.413' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:36:57.413' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (145, 34, 3, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:37:09.447' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:37:09.447' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (146, 103, 1, 8, CAST(N'2021-12-22' AS Date), CAST(7.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:37:19.633' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:37:19.633' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (147, 103, 3, 8, CAST(N'2021-12-22' AS Date), CAST(9.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:37:20.477' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:37:20.477' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (148, 103, 2, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:37:21.663' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:37:21.663' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (149, 149, 3, 8, CAST(N'2021-12-22' AS Date), CAST(8.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-10T06:37:35.663' AS DateTime), N'Dino  Liu', CAST(N'2022-01-10T06:37:35.663' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (150, 185, 1, 8, CAST(N'2022-01-11' AS Date), CAST(0.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-11T17:22:30.510' AS DateTime), N'BA-ManagerOne  DummyBAM1', CAST(N'2022-01-11T17:22:39.230' AS DateTime), N'BA-ManagerOne  DummyBAM1')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (151, 4, 2, 8, CAST(N'2022-01-12' AS Date), CAST(5.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-12T07:24:53.397' AS DateTime), N'Dino  Liu', CAST(N'2022-01-12T07:24:53.397' AS DateTime), N'Dino  Liu')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (152, 26, 6, 7, CAST(N'2022-01-13' AS Date), CAST(20.00 AS Decimal(18, 2)), N'test fro import', 1, NULL, CAST(N'2022-01-13T02:01:50.647' AS DateTime), N'Paul  Rao', CAST(N'2022-01-13T02:01:50.647' AS DateTime), N'Paul  Rao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (156, 26, 6, 7, CAST(N'2022-01-28' AS Date), CAST(17.00 AS Decimal(18, 2)), NULL, 2, NULL, CAST(N'2022-01-13T05:09:49.230' AS DateTime), N'paul.rao', CAST(N'2022-01-13T05:09:49.230' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (157, 15, 65, 2, CAST(N'2022-01-14' AS Date), CAST(33.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-14T06:16:06.370' AS DateTime), N'Jason  Zhao', CAST(N'2022-01-14T06:16:06.370' AS DateTime), N'Jason  Zhao')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (158, 60, 76, 4, CAST(N'2022-01-14' AS Date), CAST(3.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-14T06:16:46.650' AS DateTime), N'Kuo  Wang', CAST(N'2022-01-14T06:16:46.650' AS DateTime), N'Kuo  Wang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (159, 60, 76, 4, CAST(N'2022-01-16' AS Date), CAST(3.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-14T06:16:57.840' AS DateTime), N'Kuo  Wang', CAST(N'2022-01-14T06:16:57.840' AS DateTime), N'Kuo  Wang')
GO
INSERT [dbo].[TimesheetActivity] ([Id], [EmployeeId], [ProjectId], [ActivityId], [ActivityDate], [Hours], [Description], [SourceId], [SubmissionId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (160, 173, 2, 8, CAST(N'2022-01-26' AS Date), CAST(1.00 AS Decimal(18, 2)), NULL, 1, NULL, CAST(N'2022-01-26T05:29:41.040' AS DateTime), N'Paul  Rao', CAST(N'2022-01-26T05:32:11.607' AS DateTime), N'Paul  Rao')
GO
SET IDENTITY_INSERT [dbo].[TimesheetActivity] OFF
GO
SET IDENTITY_INSERT [dbo].[TimesheetPeriod] ON 
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1, N'202111', 1, CAST(N'2021-10-26T00:00:00.000' AS DateTime), CAST(N'2021-11-25T00:00:00.000' AS DateTime), 2, CAST(N'2021-12-15T00:00:00.000' AS DateTime), N'system', CAST(N'2021-12-23T05:29:38.920' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (4, N'202111', 2, CAST(N'2021-10-26T00:00:00.000' AS DateTime), CAST(N'2021-11-25T00:00:00.000' AS DateTime), 2, CAST(N'2021-12-15T00:00:00.000' AS DateTime), N'system', CAST(N'2021-12-23T05:29:38.920' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (7, N'202111', 3, CAST(N'2021-10-26T00:00:00.000' AS DateTime), CAST(N'2021-11-25T00:00:00.000' AS DateTime), 2, CAST(N'2021-12-15T00:00:00.000' AS DateTime), N'system', CAST(N'2021-12-23T05:29:38.920' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (2, N'202112', 1, CAST(N'2021-11-26T00:00:00.000' AS DateTime), CAST(N'2021-12-25T00:00:00.000' AS DateTime), 1, CAST(N'2021-12-03T22:51:53.250' AS DateTime), N'system', CAST(N'2022-01-26T02:31:27.067' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (5, N'202112', 2, CAST(N'2021-11-26T00:00:00.000' AS DateTime), CAST(N'2021-12-25T00:00:00.000' AS DateTime), 2, CAST(N'2021-12-03T22:51:53.250' AS DateTime), N'system', CAST(N'2022-01-11T08:45:01.200' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (8, N'202112', 3, CAST(N'2021-11-26T00:00:00.000' AS DateTime), CAST(N'2021-12-25T00:00:00.000' AS DateTime), 1, CAST(N'2021-12-03T22:51:53.250' AS DateTime), N'system', CAST(N'2021-12-29T06:43:59.723' AS DateTime), N'1')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (3, N'202201', 1, CAST(N'2021-12-26T00:00:00.000' AS DateTime), CAST(N'2022-01-25T00:00:00.000' AS DateTime), 0, CAST(N'2021-12-03T22:51:53.250' AS DateTime), N'system', CAST(N'2022-01-26T02:31:27.067' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (6, N'202201', 2, CAST(N'2021-12-26T00:00:00.000' AS DateTime), CAST(N'2022-01-25T00:00:00.000' AS DateTime), 1, CAST(N'2021-12-03T22:51:53.250' AS DateTime), N'system', CAST(N'2022-01-11T08:45:01.200' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (9, N'202201', 3, CAST(N'2021-12-26T00:00:00.000' AS DateTime), CAST(N'2022-01-25T00:00:00.000' AS DateTime), 0, CAST(N'2021-12-03T22:51:53.250' AS DateTime), N'system', CAST(N'2021-12-29T06:43:59.723' AS DateTime), N'1')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (10, N'202202', NULL, CAST(N'2022-01-26T00:00:00.000' AS DateTime), CAST(N'2022-02-25T00:00:00.000' AS DateTime), 0, CAST(N'2021-12-23T05:29:38.920' AS DateTime), N'paul.rao', CAST(N'2021-12-23T05:29:38.920' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (16, N'202202', 1, CAST(N'2022-01-26T00:00:00.000' AS DateTime), CAST(N'2022-02-25T00:00:00.000' AS DateTime), 0, CAST(N'2022-01-26T02:31:27.067' AS DateTime), N'paul.rao', CAST(N'2022-01-26T02:31:27.067' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (13, N'202202', 2, CAST(N'2022-01-26T00:00:00.000' AS DateTime), CAST(N'2022-02-25T00:00:00.000' AS DateTime), 0, CAST(N'2022-01-11T08:45:01.200' AS DateTime), N'paul.rao', CAST(N'2022-01-11T08:45:01.200' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (11, N'202203', NULL, CAST(N'2022-02-26T00:00:00.000' AS DateTime), CAST(N'2022-03-25T00:00:00.000' AS DateTime), 0, CAST(N'2021-12-23T05:29:38.920' AS DateTime), N'paul.rao', CAST(N'2021-12-23T05:29:38.920' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (17, N'202203', 1, CAST(N'2022-02-26T00:00:00.000' AS DateTime), CAST(N'2022-03-25T00:00:00.000' AS DateTime), 0, CAST(N'2022-01-26T02:31:27.067' AS DateTime), N'paul.rao', CAST(N'2022-01-26T02:31:27.067' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (14, N'202203', 2, CAST(N'2022-02-26T00:00:00.000' AS DateTime), CAST(N'2022-03-25T00:00:00.000' AS DateTime), 0, CAST(N'2022-01-11T08:45:01.200' AS DateTime), N'paul.rao', CAST(N'2022-01-11T08:45:01.200' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (12, N'202204', NULL, CAST(N'2022-03-26T00:00:00.000' AS DateTime), CAST(N'2022-04-25T00:00:00.000' AS DateTime), 0, CAST(N'2021-12-29T05:31:06.643' AS DateTime), N'dino.liu', CAST(N'2021-12-29T05:31:06.643' AS DateTime), N'dino.liu')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (18, N'202204', 1, CAST(N'2022-03-26T00:00:00.000' AS DateTime), CAST(N'2022-04-25T00:00:00.000' AS DateTime), 0, CAST(N'2022-01-26T02:31:27.067' AS DateTime), N'paul.rao', CAST(N'2022-01-26T02:31:27.067' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetPeriod] ([Id], [PeriodCode], [AccountingEntityId], [StartDate], [EndDate], [StatusId], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (15, N'202204', 2, CAST(N'2022-03-26T00:00:00.000' AS DateTime), CAST(N'2022-04-25T00:00:00.000' AS DateTime), 0, CAST(N'2022-01-11T08:45:01.200' AS DateTime), N'paul.rao', CAST(N'2022-01-11T08:45:01.200' AS DateTime), N'paul.rao')
GO
SET IDENTITY_INSERT [dbo].[TimesheetPeriod] OFF
GO
SET IDENTITY_INSERT [dbo].[TimesheetSubmission] ON 
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (1, 43, N'202111', 2, CAST(N'2021-12-23T05:29:38.903' AS DateTime), CAST(N'2021-12-17T02:16:12.347' AS DateTime), N'Richard  Zhang', CAST(N'2021-12-23T05:29:38.903' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (2, 6, N'202111', 2, CAST(N'2021-12-23T05:29:38.903' AS DateTime), CAST(N'2021-12-17T07:06:45.823' AS DateTime), N'Richard  Zhang', CAST(N'2021-12-23T05:29:38.903' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (3, 43, N'202112', 2, CAST(N'2022-01-11T08:45:01.183' AS DateTime), CAST(N'2021-12-24T02:09:46.580' AS DateTime), N'Richard  Zhang', CAST(N'2022-01-11T08:45:01.183' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (4, 45, N'202112', 2, CAST(N'2022-01-11T08:45:01.183' AS DateTime), CAST(N'2021-12-24T02:09:58.317' AS DateTime), N'Richard  Zhang', CAST(N'2022-01-11T08:45:01.183' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (5, 60, N'202112', 2, CAST(N'2022-01-11T08:45:01.183' AS DateTime), CAST(N'2021-12-24T02:10:11.597' AS DateTime), N'Richard  Zhang', CAST(N'2022-01-11T08:45:01.183' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (6, 127, N'202112', 2, CAST(N'2022-01-11T08:45:01.183' AS DateTime), CAST(N'2021-12-24T03:31:08.980' AS DateTime), N'Dino  Liu', CAST(N'2022-01-11T08:45:01.183' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (7, 4, N'202112', 1, CAST(N'2021-12-29T06:43:59.723' AS DateTime), CAST(N'2021-12-29T02:37:28.153' AS DateTime), N'Dino  Liu', CAST(N'2021-12-29T06:43:59.723' AS DateTime), N'1')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (8, 6, N'202112', 2, CAST(N'2022-01-11T08:45:01.183' AS DateTime), CAST(N'2022-01-06T05:25:54.730' AS DateTime), N'Jason  Zhao', CAST(N'2022-01-11T08:45:01.183' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (9, 26, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:05:55.287' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (10, 119, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:06:00.880' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (11, 147, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:06:14.973' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (12, 137, N'202112', 2, CAST(N'2022-01-11T08:45:01.183' AS DateTime), CAST(N'2022-01-10T07:06:19.113' AS DateTime), N'Dino  Liu', CAST(N'2022-01-11T08:45:01.183' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (13, 3, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:06:24.973' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (14, 78, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:06:32.897' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (15, 99, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:06:36.663' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (16, 85, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:06:40.537' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (17, 161, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:06:46.270' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (18, 95, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:07:03.693' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (19, 185, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:07:08.037' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (20, 184, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:07:13.177' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (21, 69, N'202112', 2, CAST(N'2022-01-11T08:45:01.183' AS DateTime), CAST(N'2022-01-10T07:07:17.913' AS DateTime), N'Dino  Liu', CAST(N'2022-01-11T08:45:01.183' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (22, 73, N'202112', 2, CAST(N'2022-01-11T08:45:01.183' AS DateTime), CAST(N'2022-01-10T07:07:21.693' AS DateTime), N'Dino  Liu', CAST(N'2022-01-11T08:45:01.183' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (23, 20, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:07:28.333' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (24, 145, N'202112', 2, CAST(N'2022-01-11T08:45:01.183' AS DateTime), CAST(N'2022-01-10T07:07:32.583' AS DateTime), N'Dino  Liu', CAST(N'2022-01-11T08:45:01.183' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (25, 100, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:07:36.320' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (26, 148, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:07:40.443' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
INSERT [dbo].[TimesheetSubmission] ([Id], [EmployeeId], [PeriodCode], [StatusId], [StatusDate], [CreateDate], [CreateBy], [UpdateDate], [UpdateBy]) VALUES (27, 101, N'202112', 2, CAST(N'2022-01-26T02:31:27.050' AS DateTime), CAST(N'2022-01-10T07:07:43.897' AS DateTime), N'Dino  Liu', CAST(N'2022-01-26T02:31:27.050' AS DateTime), N'paul.rao')
GO
SET IDENTITY_INSERT [dbo].[TimesheetSubmission] OFF
GO
SET IDENTITY_INSERT [dbo].[WorkflowHistory] ON 
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (1, 1, 6, 3, N'dino.liu', CAST(N'2021-12-14T05:42:47.410' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (2, 1, 6, 1, N'dino.liu', CAST(N'2021-12-14T05:45:41.743' AS DateTime), NULL, 1, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (3, 1, 6, 3, N'dino.liu', CAST(N'2021-12-14T05:45:51.930' AS DateTime), N'777', 2, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (4, 1, 6, 1, N'dino.liu', CAST(N'2021-12-14T05:57:49.287' AS DateTime), NULL, 3, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (5, 1, 6, 3, N'dino.liu', CAST(N'2021-12-14T06:13:11.977' AS DateTime), N'', 4, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (6, 1, 6, 1, N'dino.liu', CAST(N'2021-12-14T07:57:29.190' AS DateTime), NULL, 5, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (7, 1, 6, 2, N'dino.liu', CAST(N'2021-12-14T07:57:41.800' AS DateTime), NULL, 6, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (8, 1, 7, 3, N'dino.liu', CAST(N'2021-12-15T01:05:18.270' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (9, 1, 7, 1, N'dino.liu', CAST(N'2021-12-15T01:58:09.040' AS DateTime), NULL, 8, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (10, 1, 7, 3, N'dino.liu', CAST(N'2021-12-15T02:42:53.313' AS DateTime), N'', 9, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (11, 1, 7, 1, N'dino.liu', CAST(N'2021-12-15T02:43:21.953' AS DateTime), NULL, 10, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (12, 1, 7, 3, N'dino.liu', CAST(N'2021-12-15T02:43:29.283' AS DateTime), N'', 11, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (13, 1, 7, 1, N'dino.liu', CAST(N'2021-12-15T02:43:50.533' AS DateTime), NULL, 12, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (14, 1, 7, 3, N'dino.liu', CAST(N'2021-12-15T02:44:01.017' AS DateTime), N'', 13, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (15, 1, 7, 1, N'dino.liu', CAST(N'2021-12-15T03:26:54.593' AS DateTime), NULL, 14, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (16, 1, 7, 3, N'dino.liu', CAST(N'2021-12-15T03:33:03.040' AS DateTime), N'', 15, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (17, 1, 7, 1, N'dino.liu', CAST(N'2021-12-15T03:37:40.793' AS DateTime), NULL, 16, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (18, 1, 7, 3, N'dino.liu', CAST(N'2021-12-15T05:12:26.250' AS DateTime), N'', 17, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (19, 1, 7, 1, N'dino.liu', CAST(N'2021-12-15T05:12:32.347' AS DateTime), NULL, 18, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (20, 1, 7, 3, N'dino.liu', CAST(N'2021-12-15T05:12:53.393' AS DateTime), N'', 19, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (21, 1, 7, 1, N'dino.liu', CAST(N'2021-12-15T05:13:23.080' AS DateTime), NULL, 20, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (22, 1, 7, 3, N'dino.liu', CAST(N'2021-12-15T05:17:44.643' AS DateTime), N'', 21, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (23, 1, 7, 1, N'dino.liu', CAST(N'2021-12-15T05:17:56.473' AS DateTime), NULL, 22, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (24, 1, 7, 3, N'dino.liu', CAST(N'2021-12-15T05:20:52.583' AS DateTime), N'', 23, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (25, 1, 7, 1, N'dino.liu', CAST(N'2021-12-15T05:20:59.270' AS DateTime), NULL, 24, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (26, 1, 7, 3, N'dino.liu', CAST(N'2021-12-15T05:22:31.960' AS DateTime), N'', 25, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (27, 1, 7, 1, N'dino.liu', CAST(N'2021-12-15T05:22:39.990' AS DateTime), NULL, 26, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (28, 1, 8, 2, N'akhan', CAST(N'2021-12-15T17:09:05.263' AS DateTime), NULL, 0, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (29, 2, 1, 0, N'Richard  Zhang', CAST(N'2021-12-17T02:16:12.360' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (30, 2, 1, 1, N'Richard  Zhang', CAST(N'2021-12-17T02:16:12.360' AS DateTime), N'', 29, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (31, 2, 1, 0, N'li.zhang', CAST(N'2021-12-17T02:16:37.907' AS DateTime), NULL, 30, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (32, 2, 1, 1, N'Richard  Zhang', CAST(N'2021-12-17T02:16:43.690' AS DateTime), N'', 31, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (33, 2, 2, 0, N'Richard  Zhang', CAST(N'2021-12-17T07:06:45.823' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (34, 2, 2, 1, N'Richard  Zhang', CAST(N'2021-12-17T07:06:45.823' AS DateTime), N'', 33, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (35, 2, 2, 0, N'li.zhang', CAST(N'2021-12-17T07:06:51.400' AS DateTime), NULL, 34, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (36, 1, 7, 3, N'dino.liu', CAST(N'2021-12-20T07:48:12.050' AS DateTime), N'', 27, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (37, 1, 9, 3, N'dino.liu', CAST(N'2021-12-20T07:48:14.720' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (38, 1, 12, 3, N'dino.liu', CAST(N'2021-12-20T07:48:17.050' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (39, 1, 11, 3, N'dino.liu', CAST(N'2021-12-20T07:48:19.520' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (40, 1, 10, 3, N'dino.liu', CAST(N'2021-12-20T07:48:21.690' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (41, 1, 10, 1, N'dino.liu', CAST(N'2021-12-20T08:05:15.820' AS DateTime), NULL, 40, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (42, 1, 12, 1, N'dino.liu', CAST(N'2021-12-20T08:05:22.120' AS DateTime), NULL, 38, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (43, 1, 11, 1, N'dino.liu', CAST(N'2021-12-20T08:05:31.400' AS DateTime), NULL, 39, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (44, 1, 9, 1, N'dino.liu', CAST(N'2021-12-20T08:05:38.713' AS DateTime), NULL, 37, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (45, 1, 7, 1, N'dino.liu', CAST(N'2021-12-20T08:05:48.353' AS DateTime), NULL, 36, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (46, 1, 12, 3, N'dino.liu', CAST(N'2021-12-22T07:16:45.233' AS DateTime), N'', 42, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (47, 1, 13, 3, N'dino.liu', CAST(N'2021-12-23T01:55:55.130' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (48, 2, 1, 2, N'paul.rao', CAST(N'2021-12-23T05:29:38.903' AS DateTime), NULL, 32, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (49, 2, 2, 2, N'paul.rao', CAST(N'2021-12-23T05:29:38.903' AS DateTime), NULL, 35, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (50, 1, 10, 3, N'dino.liu', CAST(N'2021-12-24T00:52:24.823' AS DateTime), N'', 41, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (51, 2, 3, 0, N'Richard  Zhang', CAST(N'2021-12-24T02:09:46.580' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (52, 2, 3, 1, N'Richard  Zhang', CAST(N'2021-12-24T02:09:46.580' AS DateTime), N'', 51, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (53, 2, 4, 0, N'Richard  Zhang', CAST(N'2021-12-24T02:09:58.317' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (54, 2, 4, 1, N'Richard  Zhang', CAST(N'2021-12-24T02:09:58.330' AS DateTime), N'', 53, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (55, 2, 5, 0, N'Richard  Zhang', CAST(N'2021-12-24T02:10:11.597' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (56, 2, 5, 1, N'Richard  Zhang', CAST(N'2021-12-24T02:10:11.613' AS DateTime), N'', 55, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (57, 2, 6, 0, N'Dino  Liu', CAST(N'2021-12-24T03:31:08.980' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (58, 2, 6, 1, N'Dino  Liu', CAST(N'2021-12-24T03:31:08.980' AS DateTime), N'', 57, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (59, 1, 12, 1, N'dino.liu', CAST(N'2021-12-24T05:40:42.317' AS DateTime), NULL, 46, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (60, 1, 11, 3, N'dino.liu', CAST(N'2021-12-24T05:40:53.050' AS DateTime), N'', 43, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (61, 1, 13, 1, N'dino.liu', CAST(N'2021-12-29T00:48:01.640' AS DateTime), NULL, 47, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (62, 1, 10, 1, N'dino.liu', CAST(N'2021-12-29T00:52:56.133' AS DateTime), NULL, 50, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (63, 1, 10, 3, N'dino.liu', CAST(N'2021-12-29T00:53:12.853' AS DateTime), N'', 62, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (64, 1, 13, 2, N'dino.liu', CAST(N'2021-12-29T00:54:01.340' AS DateTime), NULL, 61, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (65, 1, 11, 1, N'dino.liu', CAST(N'2021-12-29T02:20:51.987' AS DateTime), NULL, 60, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (66, 1, 11, 3, N'dino.liu', CAST(N'2021-12-29T02:22:22.473' AS DateTime), N'', 65, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (67, 1, 9, 2, N'dino.liu', CAST(N'2021-12-29T02:22:24.677' AS DateTime), NULL, 44, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (68, 2, 7, 0, N'Dino  Liu', CAST(N'2021-12-29T02:37:28.153' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (69, 2, 7, 1, N'Dino  Liu', CAST(N'2021-12-29T02:37:28.170' AS DateTime), N'', 68, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (70, 2, 7, 0, N'dino.liu', CAST(N'2021-12-29T02:37:31.467' AS DateTime), NULL, 69, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (71, 2, 3, 2, N'dino.liu', CAST(N'2021-12-29T05:31:06.627' AS DateTime), NULL, 52, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (72, 2, 4, 2, N'dino.liu', CAST(N'2021-12-29T05:31:06.627' AS DateTime), NULL, 54, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (73, 2, 5, 2, N'dino.liu', CAST(N'2021-12-29T05:31:06.627' AS DateTime), NULL, 56, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (74, 2, 6, 2, N'dino.liu', CAST(N'2021-12-29T05:31:06.627' AS DateTime), NULL, 58, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (75, 2, 7, 2, N'dino.liu', CAST(N'2021-12-29T05:31:06.627' AS DateTime), NULL, 70, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (76, 2, 3, 1, N'dino.liu', CAST(N'2021-12-29T05:34:51.987' AS DateTime), NULL, 71, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (77, 2, 4, 1, N'dino.liu', CAST(N'2021-12-29T05:34:51.987' AS DateTime), NULL, 72, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (78, 2, 5, 1, N'dino.liu', CAST(N'2021-12-29T05:34:51.987' AS DateTime), NULL, 73, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (79, 2, 6, 1, N'dino.liu', CAST(N'2021-12-29T05:34:51.987' AS DateTime), NULL, 74, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (80, 2, 7, 1, N'dino.liu', CAST(N'2021-12-29T05:34:51.987' AS DateTime), NULL, 75, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (81, 2, 3, 2, N'dino.liu', CAST(N'2021-12-29T05:35:09.283' AS DateTime), NULL, 76, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (82, 2, 4, 2, N'dino.liu', CAST(N'2021-12-29T05:35:09.283' AS DateTime), NULL, 77, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (83, 2, 5, 2, N'dino.liu', CAST(N'2021-12-29T05:35:09.283' AS DateTime), NULL, 78, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (84, 2, 6, 2, N'dino.liu', CAST(N'2021-12-29T05:35:09.283' AS DateTime), NULL, 79, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (85, 2, 7, 2, N'dino.liu', CAST(N'2021-12-29T05:35:09.283' AS DateTime), NULL, 80, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (86, 2, 3, 1, N'dino.liu', CAST(N'2021-12-29T06:10:34.177' AS DateTime), NULL, 81, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (87, 2, 4, 1, N'dino.liu', CAST(N'2021-12-29T06:10:34.177' AS DateTime), NULL, 82, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (88, 2, 5, 1, N'dino.liu', CAST(N'2021-12-29T06:10:34.177' AS DateTime), NULL, 83, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (89, 2, 6, 1, N'dino.liu', CAST(N'2021-12-29T06:10:34.177' AS DateTime), NULL, 84, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (90, 2, 7, 1, N'dino.liu', CAST(N'2021-12-29T06:10:34.177' AS DateTime), NULL, 85, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (91, 2, 3, 2, N'dino.liu', CAST(N'2021-12-29T06:34:11.700' AS DateTime), NULL, 86, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (92, 2, 4, 2, N'dino.liu', CAST(N'2021-12-29T06:34:11.700' AS DateTime), NULL, 87, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (93, 2, 5, 2, N'dino.liu', CAST(N'2021-12-29T06:34:11.700' AS DateTime), NULL, 88, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (94, 2, 6, 2, N'dino.liu', CAST(N'2021-12-29T06:34:11.700' AS DateTime), NULL, 89, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (95, 2, 7, 2, N'dino.liu', CAST(N'2021-12-29T06:34:11.700' AS DateTime), NULL, 90, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (96, 2, 3, 1, N'1', CAST(N'2021-12-29T06:35:16.887' AS DateTime), NULL, 91, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (97, 2, 4, 1, N'1', CAST(N'2021-12-29T06:35:16.887' AS DateTime), NULL, 92, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (98, 2, 5, 1, N'1', CAST(N'2021-12-29T06:35:16.887' AS DateTime), NULL, 93, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (99, 2, 6, 1, N'1', CAST(N'2021-12-29T06:35:16.887' AS DateTime), NULL, 94, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (100, 2, 7, 1, N'1', CAST(N'2021-12-29T06:35:16.887' AS DateTime), NULL, 95, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (101, 2, 3, 2, N'dino.liu', CAST(N'2021-12-29T06:36:46.090' AS DateTime), NULL, 96, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (102, 2, 4, 2, N'dino.liu', CAST(N'2021-12-29T06:36:46.090' AS DateTime), NULL, 97, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (103, 2, 5, 2, N'dino.liu', CAST(N'2021-12-29T06:36:46.090' AS DateTime), NULL, 98, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (104, 2, 6, 2, N'dino.liu', CAST(N'2021-12-29T06:36:46.090' AS DateTime), NULL, 99, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (105, 2, 7, 2, N'dino.liu', CAST(N'2021-12-29T06:36:46.090' AS DateTime), NULL, 100, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (106, 2, 3, 1, N'dino.liu', CAST(N'2021-12-29T06:37:32.060' AS DateTime), NULL, 101, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (107, 2, 4, 1, N'dino.liu', CAST(N'2021-12-29T06:37:32.060' AS DateTime), NULL, 102, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (108, 2, 5, 1, N'dino.liu', CAST(N'2021-12-29T06:37:32.060' AS DateTime), NULL, 103, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (109, 2, 6, 1, N'dino.liu', CAST(N'2021-12-29T06:37:32.060' AS DateTime), NULL, 104, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (110, 2, 7, 1, N'dino.liu', CAST(N'2021-12-29T06:37:32.060' AS DateTime), NULL, 105, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (111, 2, 3, 2, N'dino.liu', CAST(N'2021-12-29T06:38:35.827' AS DateTime), NULL, 106, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (112, 2, 4, 2, N'dino.liu', CAST(N'2021-12-29T06:38:35.827' AS DateTime), NULL, 107, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (113, 2, 5, 2, N'dino.liu', CAST(N'2021-12-29T06:38:35.827' AS DateTime), NULL, 108, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (114, 2, 6, 2, N'dino.liu', CAST(N'2021-12-29T06:38:35.827' AS DateTime), NULL, 109, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (115, 2, 7, 2, N'dino.liu', CAST(N'2021-12-29T06:38:35.827' AS DateTime), NULL, 110, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (116, 2, 3, 1, N'dino.liu', CAST(N'2021-12-29T06:38:45.657' AS DateTime), NULL, 111, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (117, 2, 4, 1, N'dino.liu', CAST(N'2021-12-29T06:38:45.657' AS DateTime), NULL, 112, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (118, 2, 5, 1, N'dino.liu', CAST(N'2021-12-29T06:38:45.657' AS DateTime), NULL, 113, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (119, 2, 6, 1, N'dino.liu', CAST(N'2021-12-29T06:38:45.657' AS DateTime), NULL, 114, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (120, 2, 7, 1, N'dino.liu', CAST(N'2021-12-29T06:38:45.657' AS DateTime), NULL, 115, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (121, 2, 3, 2, N'dino.liu', CAST(N'2021-12-29T06:43:31.880' AS DateTime), NULL, 116, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (122, 2, 4, 2, N'dino.liu', CAST(N'2021-12-29T06:43:31.880' AS DateTime), NULL, 117, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (123, 2, 5, 2, N'dino.liu', CAST(N'2021-12-29T06:43:31.880' AS DateTime), NULL, 118, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (124, 2, 6, 2, N'dino.liu', CAST(N'2021-12-29T06:43:31.880' AS DateTime), NULL, 119, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (125, 2, 7, 2, N'dino.liu', CAST(N'2021-12-29T06:43:31.880' AS DateTime), NULL, 120, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (126, 2, 3, 1, N'1', CAST(N'2021-12-29T06:43:59.723' AS DateTime), NULL, 121, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (127, 2, 4, 1, N'1', CAST(N'2021-12-29T06:43:59.723' AS DateTime), NULL, 122, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (128, 2, 5, 1, N'1', CAST(N'2021-12-29T06:43:59.723' AS DateTime), NULL, 123, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (129, 2, 6, 1, N'1', CAST(N'2021-12-29T06:43:59.723' AS DateTime), NULL, 124, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (130, 2, 7, 1, N'1', CAST(N'2021-12-29T06:43:59.723' AS DateTime), NULL, 125, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (131, 2, 8, 0, N'Jason  Zhao', CAST(N'2022-01-06T05:25:54.730' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (132, 2, 8, 1, N'Jason  Zhao', CAST(N'2022-01-06T05:25:54.747' AS DateTime), N'', 131, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (133, 2, 9, 0, N'Dino  Liu', CAST(N'2022-01-10T07:05:55.287' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (134, 2, 9, 1, N'Dino  Liu', CAST(N'2022-01-10T07:05:55.287' AS DateTime), N'', 133, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (135, 2, 10, 0, N'Dino  Liu', CAST(N'2022-01-10T07:06:00.880' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (136, 2, 10, 1, N'Dino  Liu', CAST(N'2022-01-10T07:06:00.897' AS DateTime), N'', 135, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (137, 2, 11, 0, N'Dino  Liu', CAST(N'2022-01-10T07:06:14.973' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (138, 2, 11, 1, N'Dino  Liu', CAST(N'2022-01-10T07:06:14.973' AS DateTime), N'', 137, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (139, 2, 12, 0, N'Dino  Liu', CAST(N'2022-01-10T07:06:19.113' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (140, 2, 12, 1, N'Dino  Liu', CAST(N'2022-01-10T07:06:19.113' AS DateTime), N'', 139, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (141, 2, 13, 0, N'Dino  Liu', CAST(N'2022-01-10T07:06:24.973' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (142, 2, 13, 1, N'Dino  Liu', CAST(N'2022-01-10T07:06:24.973' AS DateTime), N'', 141, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (143, 2, 14, 0, N'Dino  Liu', CAST(N'2022-01-10T07:06:32.897' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (144, 2, 14, 1, N'Dino  Liu', CAST(N'2022-01-10T07:06:32.910' AS DateTime), N'', 143, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (145, 2, 15, 0, N'Dino  Liu', CAST(N'2022-01-10T07:06:36.663' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (146, 2, 15, 1, N'Dino  Liu', CAST(N'2022-01-10T07:06:36.663' AS DateTime), N'', 145, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (147, 2, 16, 0, N'Dino  Liu', CAST(N'2022-01-10T07:06:40.537' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (148, 2, 16, 1, N'Dino  Liu', CAST(N'2022-01-10T07:06:40.537' AS DateTime), N'', 147, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (149, 2, 17, 0, N'Dino  Liu', CAST(N'2022-01-10T07:06:46.270' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (150, 2, 17, 1, N'Dino  Liu', CAST(N'2022-01-10T07:06:46.270' AS DateTime), N'', 149, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (151, 2, 18, 0, N'Dino  Liu', CAST(N'2022-01-10T07:07:03.693' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (152, 2, 18, 1, N'Dino  Liu', CAST(N'2022-01-10T07:07:03.693' AS DateTime), N'', 151, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (153, 2, 19, 0, N'Dino  Liu', CAST(N'2022-01-10T07:07:08.037' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (154, 2, 19, 1, N'Dino  Liu', CAST(N'2022-01-10T07:07:08.037' AS DateTime), N'', 153, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (155, 2, 20, 0, N'Dino  Liu', CAST(N'2022-01-10T07:07:13.177' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (156, 2, 20, 1, N'Dino  Liu', CAST(N'2022-01-10T07:07:13.177' AS DateTime), N'', 155, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (157, 2, 21, 0, N'Dino  Liu', CAST(N'2022-01-10T07:07:17.927' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (158, 2, 21, 1, N'Dino  Liu', CAST(N'2022-01-10T07:07:17.927' AS DateTime), N'', 157, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (159, 2, 22, 0, N'Dino  Liu', CAST(N'2022-01-10T07:07:21.693' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (160, 2, 22, 1, N'Dino  Liu', CAST(N'2022-01-10T07:07:21.693' AS DateTime), N'', 159, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (161, 2, 23, 0, N'Dino  Liu', CAST(N'2022-01-10T07:07:28.333' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (162, 2, 23, 1, N'Dino  Liu', CAST(N'2022-01-10T07:07:28.333' AS DateTime), N'', 161, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (163, 2, 24, 0, N'Dino  Liu', CAST(N'2022-01-10T07:07:32.583' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (164, 2, 24, 1, N'Dino  Liu', CAST(N'2022-01-10T07:07:32.583' AS DateTime), N'', 163, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (165, 2, 25, 0, N'Dino  Liu', CAST(N'2022-01-10T07:07:36.320' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (166, 2, 25, 1, N'Dino  Liu', CAST(N'2022-01-10T07:07:36.333' AS DateTime), N'', 165, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (167, 2, 26, 0, N'Dino  Liu', CAST(N'2022-01-10T07:07:40.443' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (168, 2, 26, 1, N'Dino  Liu', CAST(N'2022-01-10T07:07:40.443' AS DateTime), N'', 167, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (169, 2, 27, 0, N'Dino  Liu', CAST(N'2022-01-10T07:07:43.913' AS DateTime), N'', 0, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (170, 2, 27, 1, N'Dino  Liu', CAST(N'2022-01-10T07:07:43.913' AS DateTime), N'', 169, 0)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (171, 1, 20, 2, N'dino.liu', CAST(N'2022-01-11T03:02:22.480' AS DateTime), NULL, 0, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (172, 2, 3, 2, N'paul.rao', CAST(N'2022-01-11T08:45:01.183' AS DateTime), NULL, 126, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (173, 2, 4, 2, N'paul.rao', CAST(N'2022-01-11T08:45:01.183' AS DateTime), NULL, 127, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (174, 2, 5, 2, N'paul.rao', CAST(N'2022-01-11T08:45:01.183' AS DateTime), NULL, 128, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (175, 2, 6, 2, N'paul.rao', CAST(N'2022-01-11T08:45:01.183' AS DateTime), NULL, 129, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (176, 2, 8, 2, N'paul.rao', CAST(N'2022-01-11T08:45:01.183' AS DateTime), NULL, 132, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (177, 2, 12, 2, N'paul.rao', CAST(N'2022-01-11T08:45:01.183' AS DateTime), NULL, 140, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (178, 2, 21, 2, N'paul.rao', CAST(N'2022-01-11T08:45:01.183' AS DateTime), NULL, 158, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (179, 2, 22, 2, N'paul.rao', CAST(N'2022-01-11T08:45:01.183' AS DateTime), NULL, 160, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (180, 2, 24, 2, N'paul.rao', CAST(N'2022-01-11T08:45:01.183' AS DateTime), NULL, 164, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (181, 1, 21, 2, N'dino.liu', CAST(N'2022-01-13T06:06:47.277' AS DateTime), NULL, 0, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (182, 1, 22, 2, N'dino.liu', CAST(N'2022-01-13T06:27:38.710' AS DateTime), NULL, 0, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (183, 2, 9, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 134, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (184, 2, 10, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 136, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (185, 2, 11, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 138, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (186, 2, 13, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 142, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (187, 2, 14, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 144, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (188, 2, 15, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 146, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (189, 2, 16, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 148, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (190, 2, 17, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 150, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (191, 2, 18, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 152, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (192, 2, 19, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 154, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (193, 2, 20, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 156, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (194, 2, 23, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 162, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (195, 2, 25, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 166, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (196, 2, 26, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 168, 1)
GO
INSERT [dbo].[WorkflowHistory] ([Id], [WorkflowId], [EntityId], [StatusId], [StatusBy], [StatusDate], [Comment], [PrevHistoryId], [IsCurrent]) VALUES (197, 2, 27, 2, N'paul.rao', CAST(N'2022-01-26T02:31:27.050' AS DateTime), NULL, 170, 1)
GO
SET IDENTITY_INSERT [dbo].[WorkflowHistory] OFF
GO
/****** Object:  Index [UK_ProjectActivity]    Script Date: 1/27/2022 5:22:42 PM ******/
ALTER TABLE [dbo].[ProjectActivity] ADD  CONSTRAINT [UK_ProjectActivity] UNIQUE NONCLUSTERED 
(
	[ProjectId] ASC,
	[ActivityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Team] ADD  CONSTRAINT [DF__Team__ManagerId]  DEFAULT ((0)) FOR [ManagerId]
GO
ALTER TABLE [dbo].[Team] ADD  CONSTRAINT [DF__Team__OwnerId]  DEFAULT ((0)) FOR [OwnerId]
GO
ALTER TABLE [dbo].[Team] ADD  CONSTRAINT [DF__Team__ParentId]  DEFAULT ((0)) FOR [ParentId]
GO
ALTER TABLE [dbo].[Team] ADD  CONSTRAINT [DF__Team__IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Team] ADD  CONSTRAINT [DF__Team__CreateDate]  DEFAULT (getutcdate()) FOR [CreateDate]
GO
ALTER TABLE [dbo].[Team] ADD  CONSTRAINT [DF__Team__UpdateDate]  DEFAULT (getutcdate()) FOR [UpdateDate]
GO
/****** Object:  StoredProcedure [dbo].[SPU_AccountingEntity_FindByCriteria]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*********************************************************
* PROCEDURE:    [SPU_AccountingEntity_FindByCriteria]
* DESCRIPTION:  
	Get [AccountingEntity] XML records based on searching tokens
* CREATED: 12/21/2021  DINO
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_AccountingEntity_FindByCriteria] 
AS BEGIN
SELECT 
   E.Id				AS '@Id',
   E.Name			AS '@Name'
FROM AccountingEntity E
  FOR XML PATH('Setting'), ROOT('ArrayOfSetting')  

END
GO
/****** Object:  StoredProcedure [dbo].[SPU_AccountingEntity_GetAll]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*********************************************************
* PROCEDURE:    [SPU_AccountingEntity_GetAll]
* DESCRIPTION:  
	Get [AccountingEntity] XML records based on searching tokens
* CREATED: 12/21/2021  DINO
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_AccountingEntity_GetAll] 
AS BEGIN
SELECT 
   E.Id				AS '@Id',
   E.Name			AS '@Name',
   E.PeriodFirstDay	AS '@PeriodFirstDay',
   F.PeriodCode     AS '@PeriodCode',
   F.StartDate      As '@StartDate',
   F.EndDate	   As '@EndDate'
FROM AccountingEntity E
  left join TimesheetPeriod f on e.id = f.[AccountingEntityId] and StatusId = 1
  FOR XML PATH('AccountingEntity'), ROOT('ArrayOfAccountingEntity')  

END
GO
/****** Object:  StoredProcedure [dbo].[SPU_ApplicationLog_Find]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*********************************************************
* PROCEDURE:    [SPU_ApplicationLog_Get]
DESCRIPTION: Get application log data
* CREATED: [08/23/2020]
* BY: [Joy.Jing] 
MODIFICATION HISTORY
* 10/14/2021  PCHEN Unified Finder sp with @JsonTokens
**********************************************************/
CREATE PROCEDURE [dbo].[SPU_ApplicationLog_Find]
	@JsonTokens NVARCHAR(max) = NULL
AS
SELECT Id			AS '@Id',
	[ID]			AS '@ApplicationLogID',
	[UserName]		AS '@UserName',
	[Message]		AS '@Message',
	[StackTrace]	AS '@StackTrace',
	[OperatingSystem] AS '@OperatingSystem',
	[Browser]		AS '@Brower',
	[MachineName]	AS '@MachineName',
	[Date]			AS '@Date'
FROM [ApplicationLog]
ORDER BY [Date] DESC
FOR XML PATH('ApplicationLog'), ROOT('ArrayOfApplicationLog')
GO
/****** Object:  StoredProcedure [dbo].[SPU_ApplicationLog_Get]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*********************************************************
* PROCEDURE:    [SPU_ApplicationLog_Get]
DESCRIPTION: Get application log data
* CREATED: [08/23/2020]
* BY: [Joy.Jing] 
MODIFICATION HISTORY
*
**********************************************************/
create PROCEDURE [dbo].[SPU_ApplicationLog_Get]
AS
SELECT (
		SELECT [ID] as ApplicationLogID,
			[UserName],
			[Message],
			[StackTrace],
			[OperatingSystem],
			[Browser],
			[MachineName],
			[Date]
		FROM [ApplicationLog]
		ORDER BY [Date] DESC
		FOR XML PATH('ApplicationLogEntity'),
			TYPE
		)
FOR XML PATH('ArrayOfApplicationLogEntity'),
	TYPE
GO
/****** Object:  StoredProcedure [dbo].[SPU_ApplicationLog_Insert]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_ApplicationLog_Insert]
DESCRIPTION:  
* CREATED: [10/2021]
* BY: [Joy.Jing] 
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_ApplicationLog_Insert] 
	@Message VARCHAR(500),
	@StackTrace VARCHAR(MAX) = '',
	@UserName VARCHAR(100),
	@OperatingSystem VARCHAR(100),
	@Browser VARCHAR(100),
	@MachineName VARCHAR(100),
	@Date DATETIME
AS
INSERT INTO [ApplicationLog] (
	[UserName],
	[Message],
	[StackTrace],
	[OperatingSystem],
	[Browser],
	[MachineName],
	[Date]
	)
VALUES (
	@UserName,
	@Message,
	@StackTrace,
	@OperatingSystem,
	@Browser,
	@MachineName,
	@Date
	);
GO
/****** Object:  StoredProcedure [dbo].[SPU_ApplicationLog_Update]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Update_ApplicationLog]
DESCRIPTION:  
* CREATED: [08/23/2020]
* BY: [Joy.Jing] 
MODIFICATION HISTORY
*
***********************************************************/
create PROCEDURE [dbo].[SPU_ApplicationLog_Update] 
	@Message VARCHAR(500),
	@StackTrace VARCHAR(MAX),
	@UserName VARCHAR(100),
	@OperatingSystem VARCHAR(100),
	@Browser VARCHAR(100),
	@MachineName VARCHAR(100),
	@Date DATETIME
AS
INSERT INTO [ApplicationLog] (
	[UserName],
	[Message],
	[StackTrace],
	[OperatingSystem],
	[Browser],
	[MachineName],
	[Date]
	)
VALUES (
	@UserName,
	@Message,
	@StackTrace,
	@OperatingSystem,
	@Browser,
	@MachineName,
	@Date
	);
GO
/****** Object:  StoredProcedure [dbo].[SPU_EmailTemplate_FindByCriteria]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Setting_FindByCriteria]
* DESCRIPTION:  
	Get [Enum] XML records based on searching tokens
* CREATED: 10/26/2021  DINO
MODIFICATION HISTORY
*
***********************************************************/
create PROCEDURE [dbo].[SPU_EmailTemplate_FindByCriteria]
AS BEGIN
SELECT 
   E.Id				AS '@EmailTemplateID',
   E.TemplateName			AS '@TemplateName',
   E.EmailSubject		AS '@EmailSubject',
   E.EmailContent		AS '@EmailContent'
FROM EmailTemplate E
  FOR XML PATH('EmailTemplate'), ROOT('ArrayOfEmailTemplate')  

END
GO
/****** Object:  StoredProcedure [dbo].[SPU_Employee_Find]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:  [SPU_Employee_Find]
* DESCRIPTION:  Find Employees based on searching tokens
* CREATED: [10/2021] BY: [PCHEN] 
MODIFICATION HISTORY
* DATE 		BY		DESCRIPTION 
* 10/14/2021 PCHEN	Unify xx_Find SP to take @JsonTokens
* 11/18/2021 Dino Adding manager and owner to team
* 12/21/2021 PCHEN Add FinderType of 'IdFromManagerApproval'
* 12/28/2021 Dino: Adding timesheet admin role to filter
* 1/12/2022 PCHEN Add @PeriodCode argument to JsonToken
	includes disabled employee with valid TimesheetActivities during the @PeriodCode
*************************************************************/
CREATE PROCEDURE [dbo].[SPU_Employee_Find] 
	@JsonTokens NVARCHAR(MAX) = NULL,
	@IsDebug CHAR(1) = 'N'
AS
SET NOCOUNT ON

DECLARE @tEmployee TABLE ( EmployeeId INT, AccountingEntityId INT, Included CHAR(1))  -- Base table

BEGIN -- Define Searching criteria tokens, This needs to be adjusted according to application need
/*** List of Json Tokens
* 12/21/2021 PCHEN +  @IdFromManagerApproval : 
	Finder EmployeeID passed from ManagerApproval to get a list of Resource for Approval
* 1/12/2022  PCHEN +  @PeriodCode : 	
****/
DECLARE @IdFromManagerApproval INT = -1
END 

-- Convert JsonTokens into memeory table and retrieve searching variables
IF (ISJSON(@JsonTokens)>0)
BEGIN	
	DECLARE @tokens TABLE (
		Name nvarchar(4000),  Value nvarchar(max),  Type tinyint)

	INSERT INTO @tokens (Name, Value, Type)
		SELECT * FROM OPENJSON(@JsonTokens)

	SELECT @IdFromManagerApproval = value FROM @tokens WHERE name = 'IdFromManagerApproval'
	IF (@IdFromManagerApproval>0) BEGIN -- 
		-- Step 1: Pull ALL candidate employee (include InActive)
		IF EXISTS(SELECT 1 FROM EmployeeRole WHERE RoleName IN ('TimesheetAdmin', 'Admin') AND EmployeeId = @IdFromManagerApproval AND IsActive = 1)
		BEGIN -- If "Admin" select ALL
			INSERT INTO @tEmployee (EmployeeId, AccountingEntityId)
			SELECT E.Id, T.AccountingEntityId FROM Employee E 
			JOIN TeamEmployee TE ON e.Id = TE.EmployeeId 
			JOIN Team T ON TE.TeamId = T.Id
			WHERE EXISTS (			
				SELECT 1 FROM EmployeeRole R 
				WHERE R.EmployeeId = E.Id AND RoleName IN ('Employee','Manager','TeamOwner') 
			)
		END
		ELSE BEGIN -- for TeamOwner or TeamManager
			INSERT INTO @tEmployee(EmployeeId, T.AccountingEntityId)
			SELECT E.Id, T.AccountingEntityId FROM TeamEmployee TE JOIN Employee E ON TE.EmployeeId = E.Id
			JOIN Team T ON TE.TeamId = T.Id
			WHERE T.ManagerId = @IdFromManagerApproval 
				OR T.OwnerId = @IdFromManagerApproval
			UNION
			SELECT T.ManagerId, T.AccountingEntityId
			FROM Team T WHERE T.ManagerId = @IdFromManagerApproval OR T.OwnerId = @IdFromManagerApproval
			UNION
			SELECT T.OwnerId, T.AccountingEntityId
			FROM Team T WHERE T.ManagerId = @IdFromManagerApproval OR T.OwnerId = @IdFromManagerApproval
		END
		-- @tEmployee Now has ALL resources, next need to filter out (1) Disabled employeee, and (2) with no TimesheetActivity during the period
		DECLARE @PeriodCode VARCHAR(6)
		SELECT @PeriodCode = value FROM @tokens WHERE name = 'PeriodCode'
		IF LEN(RTRIM(ISNULL(@PeriodCode, ''))) <> 6 -- invalid PeriodCode, give a dummy period
			SELECT @PeriodCode = '222212'

		IF @IsDebug = 'Y' BEGIN -- Debug check point
		SELECT '' as 'A@tEmployee', @PeriodCode as '@PeriodCode', A.* , E.IsActive AS 'Employee.IsActive',
		   ISNULL(TP.StartDate,CONVERT(date, CONCAT(@PeriodCode, '01'))) as 'TP.StartDate', 
		   ISNULL(TP.EndDate, DATEADD(DAY, -1, DATEADD(MONTH, 1, CONVERT(date, CONCAT(@PeriodCode, '01'))))) as 'TP.EndDate'
		FROM @tEmployee A JOIN Employee E ON A.EmployeeId = E.Id
		LEFT JOIN TimesheetPeriod TP ON A.AccountingEntityId = TP.AccountingEntityId AND TP.PeriodCode = @PeriodCode
		WHERE e.IsActive = 1
		OR EXISTS ( 
			SELECT 1 FROM TimesheetActivity TA WHERE TA.EmployeeId = E.Id AND TA.Hours > 0
			AND TA.ActivityDate > ISNULL(TP.StartDate,CONVERT(date, CONCAT(@PeriodCode, '01')))
			AND TA.ActivityDate < DATEADD(DAY, 1, ISNULL(tp.EndDate, DATEADD(DAY, -1, DATEADD(MONTH, 1, CONVERT(date, CONCAT(@PeriodCode, '01'))))))
		)
		END -- End of debug check point

		-- Step 2: select employees with either (1) active, or (2) has timesheet activities
		UPDATE A SET Included = 'Y'
		FROM @tEmployee A JOIN Employee E ON A.EmployeeId = E.Id
		LEFT JOIN TimesheetPeriod TP ON A.AccountingEntityId = TP.AccountingEntityId AND TP.PeriodCode = @PeriodCode
		WHERE e.IsActive = 1
		OR EXISTS ( 
			SELECT 1 FROM TimesheetActivity TA WHERE TA.EmployeeId = E.Id AND TA.Hours > 0
			AND TA.ActivityDate > ISNULL(TP.StartDate,CONVERT(date, CONCAT(@PeriodCode, '01')))
			AND TA.ActivityDate < DATEADD(DAY, 1, ISNULL(tp.EndDate, DATEADD(DAY, -1, DATEADD(MONTH, 1, CONVERT(date, CONCAT(@PeriodCode, '01'))))))
		)
	END
	-- End of getting Extra searching parameters
END

SELECT 
   E.Id				AS '@Id',
   E.UserID			AS '@UserId',
   E.FirstName		AS '@FirstName',
   E.LastName		AS '@LastName',
   E.DisplayName	AS '@DisplayName',
   E.Email			AS '@Email',
   E.Title			AS '@Title',
   E.JobGradeId		AS '@JobGradeId',
   E.DeptCode		AS '@DeptCode',
   E.CountryCode	AS '@CountryCode',
   E.EmailAlert		AS '@EmailAlert',
   E.IsActive		AS '@IsActive',
   E.CreateBy		AS '@CreateBy',
   E.CreateDate		AS '@CreateDate',
   E.UpdateBy		AS '@UpdateBy',
   E.UpdateDate		AS '@UpdateDate',
	(
	  SELECT TOP 1  -- For now Employee can have only one team 1/6/2022 PC
	     T.Id        AS '@Id',
		 T.Name      as '@Name',
		 T.DeptCode  as '@DeptCode',
		 T.ManagerId AS '@ManagerId',
		 T.OwnerId	 AS '@OwnerId'
		 FROM Team T
		 INNER JOIN TeamEmployee TE ON T.id= Te.TeamId
		 WHERE TE.EmployeeId = e.Id
		 AND T.IsActive = 1
		 AND TE.IsActive = 1
      FOR XML PATH('Team'),TYPE
	)
FROM Employee E JOIN @tEmployee X ON E.Id = X.EmployeeId
WHERE X.Included = 'Y'
FOR XML PATH('Employee'), ROOT('ArrayOfEmployee')    

/** xxxx TEST xxxx **
EXEC SPU_Employee_Find  '{"IdFromManagerApproval":"9", "PeriodCode": "202112"}', 'Y'   -- TO
EXEC SPU_Employee_Find  '{"IdFromManagerApproval":"11", "PeriodCode": ""}', 'Y'  --- Admin
EXEC SPU_Employee_Find  '{"IdFromManagerApproval":"11"}', 'Y'  --- Admin
EXEC SPU_Employee_Find  '{"IdFromManagerApproval":"185", "PeriodCode": "202110"}', 'Y'  --- BA.m1
EXEC SPU_Employee_Find  '{"IdFromManagerApproval":"185", "PeriodCode": "202111"}', 'Y'  --- BA.m1
EXEC SPU_Employee_Find  '{"IdFromManagerApproval":"185", "PeriodCode": "202112"}', 'Y'  --- BA.m1

EXEC SPU_Employee_Find  '{"IdFromManagerApproval":"303"}'
** xxxxxx **/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Employee_FindByCriteria]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:  [SPU_Employee_FindByCreteria]
* DESCRIPTION:  Find Employees based on searching tokens
* CREATED: [10/2021] BY: [PCHEN] 
MODIFICATION HISTORY
* DATE 		BY		DESCRIPTION 
* 10/14/2021 PCHEN	Unify xx_Find SP to take @JsonTokens
*************************************************************/
CREATE PROCEDURE [dbo].[SPU_Employee_FindByCriteria] 
	@UserId NVARCHAR(250) = NULL,
	@TeamId int =null,
	@Id int =null,
	@OwnerId int = null

AS
SET NOCOUNT ON



-- End of getting Extra searching parameters
SELECT 
   E.Id				AS '@Id',
   E.UserID			AS '@UserId',
   E.FirstName		AS '@FirstName',
   E.LastName		AS '@LastName',
   E.DisplayName	AS '@DisplayName',
   E.Email			AS '@Email',
   E.Title			AS '@Title',
   E.JobGradeId		AS '@JobGradeId',
   E.DeptCode		AS '@DeptCode',
   E.CountryCode	AS '@CountryCode',
   E.EmailAlert		AS '@EmailAlert',
   E.IsActive		AS '@IsActive',
   E.CreateBy		AS '@CreateBy',
   E.CreateDate		AS '@CreateDate',
   E.UpdateBy		AS '@UpdateBy',
   E.UpdateDate		AS '@UpdateDate',  
   ( SELECT 
	   M.Id				AS '@Id',
	   M.UserID			AS '@UserId',
	   M.FirstName		AS '@FirstName',
	   M.LastName		AS '@LastName',
	   M.DisplayName	AS '@DisplayName',
	   M.Email			AS '@Email',
	   M.Title			AS '@Title',
	   M.JobGradeId		AS '@JobGradeId',
	   M.DeptCode		AS '@DeptCode',
	   M.CountryCode	AS '@CountryCode',
	   M.ManagerID		AS '@ManagerId'
      FROM Employee M  
      WHERE M.Id = E.ManagerID  
      FOR XML PATH('Manager'), TYPE  
    ),
	(
	  SELECT 
	     T.Id        AS '@Id',
		 T.Name      as '@Name',
		 T.DeptCode  as  '@DeptCode'
		 from Team T
		 inner join TeamEmployee TE
		 on T.id= Te.TeamId
		 where TE.EmployeeId = e.Id
      FOR XML PATH('Team'),TYPE
	),
	(
	  SELECT   
		R.RoleName as 'RoleName'
		FROM EmployeeRole R
		WHERE R.EmployeeId = E.Id
		AND IsActive = 1
      FOR XML PATH(''), ROOT('ArrayOfRoleName'), TYPE
	)
FROM Employee E
WHERE 1 = 1
and (@Id is null or @id = e.Id)
and (@UserId is null or @UserId = e.UserID)
and (@TeamId is null or  e.id In ( select te.EmployeeId from TeamEmployee te where te.TeamId = @TeamId and te.IsActive  = 1))
and (@OwnerId is null 
  or e.id in (select te.EmployeeId from TeamEmployee te inner join team  t on te.TeamId  = t.Id where t.OwnerId = @OwnerId and t.IsActive = 1 AND te.IsActive = 1
  
   union    select er.EmployeeId from  EmployeeRole er  where er.EmployeeId = e.Id and er.RoleName ='employee'  and er.IsActive  = 1
  and  not exists (select 1 from TeamEmployee te where te.employeeId = er.EmployeeId and te.IsActive = 1))
   
)
AND E.IsActive = 1
order by UpdateDate desc
FOR XML PATH('Employee'), ROOT('ArrayOfEmployee')
GO
/****** Object:  StoredProcedure [dbo].[SPU_Employee_Get]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Employee_Get]
* DESCRIPTION:  
	Get [Employee] XML record based on Id or UserID(Window User Name)
* CREATED: 10/2021  PCHEN
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Employee_Get] 
	@Id INT = NULL,
	@UserID VARCHAR(50) = NULL
AS BEGIN
IF (ISNULL(@Id, -1) < 1)
	SELECT @Id = Id FROM Employee WHERE UserID = @UserID

SELECT 
   E.Id				AS '@Id',
   E.UserID			AS '@UserId',
   E.FirstName		AS '@FirstName',
   E.LastName		AS '@LastName',
   E.DisplayName	AS '@DisplayName',
   E.Email			AS '@Email',
   E.Title			AS '@Title',
   E.JobGradeId		AS '@JobGradeId',
   E.DeptCode		AS '@DeptCode',
   E.CountryCode	AS '@CountryCode',
   E.EmailAlert		AS '@EmailAlert',
   E.IsActive		AS '@IsActive',
   E.CreateBy		AS '@CreateBy',
   E.CreateDate		AS '@CreateDate',
   E.UpdateBy		AS '@UpdateBy',
   E.UpdateDate		AS '@UpdateDate',  
   ( SELECT 
	   M.Id				AS '@Id',
	   M.UserID			AS '@UserId',
	   M.FirstName		AS '@FirstName',
	   M.LastName		AS '@LastName',
	   M.DisplayName	AS '@DisplayName',
	   M.Email			AS '@Email',
	   M.Title			AS '@Title',
	   M.JobGradeId		AS '@JobGradeId',
	   M.DeptCode		AS '@DeptCode',
	   M.CountryCode	AS '@CountryCode',
	   M.ManagerID		AS '@ManagerId'
      FROM Employee M  
      WHERE M.Id = E.ManagerID  
      FOR XML PATH('Manager'), TYPE  
    ),
	( SELECT   
		T.Id			AS '@Id',
		T.Name			AS '@Name',
		T.DeptCode		AS '@DeptCode'
		FROM Team T JOIN TeamEmployee TM ON TM.TeamId = T.Id
		WHERE TM.EmployeeId = E.Id
      FOR XML PATH('Team'), TYPE
	),
	( /* -- PCHEN Note: Good example to demo getting an array of string
	1. Make sure PATH('') set to Empty
	2. Where deserialized, decorated with  	
        [XmlArray("ArrayOfRoleName")]
        [XmlArrayItem("RoleName")]
        public Collection<string> RoleNames {get; set; }
	*/
	  SELECT   
		R.RoleName as 'RoleName'
		FROM EmployeeRole R
		WHERE R.EmployeeId = E.Id
		AND IsActive = 1
      FOR XML PATH(''), ROOT('ArrayOfRoleName'), TYPE
	)
FROM Employee E
WHERE E.Id = @Id
FOR XML PATH('Employee')  

END
/* Testing *
exec spu_employee_get null, 'paul.chen'
exec SPU_Employee_Get @Id=171

exec spu_employee_get 32, 'paul.chen'
exec spu_employee_get 32, null



select * from employee where lastname = 'chen'

*/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Employee_UpSert]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Employee_UpSert]
* DESCRIPTION:  To Insert or Update [Employee] record
*	Need to make sure 
		(1) UserID is not updatable
		(2) can not insert duplicated UserID
* CREATED: [10/2021] BY: [PCHEN] 
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Employee_UpSert] 
	@Id INT = NULL,
	@UserID VARCHAR(50) = NULL,
	@FirstName NVARCHAR(50) = NULL,
	@LastName NVARCHAR(50) = NULL,
	@DisplayName NVARCHAR(200) = NULL,
	@Email VARCHAR(100) = NULL,
	@Title VARCHAR(100) = NULL,
	@JobGradeId INT = NULL,
	@DeptCode VARCHAR(10) = NULL,
	@CountryCode CHAR(3) = NULL,
	@ManagerID INT = NULL,
	@EmailAlert BIT = NULL,
	@IsActive BIT = NULL,
	@By VARCHAR(50)
AS BEGIN
	IF EXISTS(SELECT 1 FROM Employee WHERE Id = ISNULL(@Id, -1) or UserID = @UserID) BEGIN
		-- (1)Make sure UserID is not updated
		UPDATE Employee
		SET FirstName	= ISNULL(@FirstName, FirstName),
		    LastName	= ISNULL(@LastName, LastName),
		    DisplayName = ISNULL(@DisplayName, DisplayName),
		    Email		= ISNULL(@Email, Email),
		    Title		= ISNULL(@Title, Title),
		    JobGradeId	= ISNULL(@JobGradeId, JobGradeId),
		    DeptCode	= ISNULL(@DeptCode, DeptCode),
		    CountryCode = ISNULL(@CountryCode, CountryCode),
		    ManagerID	= ISNULL(@ManagerID, ManagerID),
		    EmailAlert	= ISNULL(@EmailAlert, EmailAlert),
		    IsActive	= ISNULL(@IsActive, IsActive),
			UpdateBy	= @by,
			UpdateDate	= GETUTCDATE()
		WHERE Id = @Id or  UserID = @UserID
		IF (@@ROWCOUNT<>1) SELECT @Id = -1  -- Update none-exist record
	END
	ELSE BEGIN
		IF NOT EXISTS (SELECT 1 FROM Employee WHERE UserID = @UserID and IsActive = 1) BEGIN
			INSERT INTO [dbo].[Employee]
					   ([UserID]
					   ,[FirstName]
					   ,[LastName]
					   ,[DisplayName]
					   ,[Email]
					   ,[Title]
					   ,[JobGradeId]
					   ,[DeptCode]
					   ,[CountryCode]
					   ,[ManagerID]
					   ,[EmailAlert]
					   ,[IsActive]
					   ,[CreateDate]
					   ,[CreateBy]
					   ,[UpdateDate]
					   ,[UpdateBy])
				 VALUES 
					   (@UserID
					   ,@FirstName
					   ,@LastName
					   ,@DisplayName
					   ,@Email
					   ,@Title
					   ,@JobGradeId
					   ,@DeptCode
					   ,@CountryCode
					   ,@ManagerID
					   ,@EmailAlert
					   ,@IsActive
					   ,GETUTCDATE()
					   ,@By
					   ,GETUTCDATE()
					   ,@By)
			SELECT @Id = SCOPE_IDENTITY()
		END 
		ELSE
			SELECT @Id = -2  -- Insert duplicated UserID
	END

	RETURN @Id

END
GO
/****** Object:  StoredProcedure [dbo].[SPU_EmployeeActivityMap_Delete]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_EmployeeActivityMap_Delete]
* DESCRIPTION:  
	Delete [EmployeeActivityMa] by Id or by employeeid and projectid and activityid
* CREATED: 10/2021  JoyJing
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_EmployeeActivityMap_Delete] 
	@Id INT=NULL,
	@EmployeeId INT=NULL,
	@ProjectId INT=NULL,
	@ActivityId INT=NULL
AS BEGIN
	UPDATE EmployeeActivityMap
	SET IsActive=0
	WHERE (@Id IS NOT NULL AND Id=@Id) OR (EmployeeId=@EmployeeId AND ProjectId=@ProjectId AND ActivityId=@ActivityId)
END
GO
/****** Object:  StoredProcedure [dbo].[SPU_EmployeeActivityMap_Insert]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_EmployeeActivityMap_Inser]
DESCRIPTION:  
* CREATED: [10/2021]
* BY: [Joy.Jing] 
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_EmployeeActivityMap_Insert] 
	@EmployeeId INT,
	@ProjectId INT,
    @ActivityId INT,
    @By VARCHAR(50)
AS
IF NOT EXISTS(SELECT 1 FROM [dbo].[EmployeeActivityMap] WHERE EmployeeId=@EmployeeId AND ProjectId=@ProjectId AND ActivityId=@ActivityId)
BEGIN
INSERT INTO [dbo].[EmployeeActivityMap]
           ([EmployeeId]
           ,[ProjectId]
           ,[ActivityId]
           ,[IsActive]
           ,[CreateDate]
           ,[CreateBy])
     VALUES(@EmployeeId,
            @ProjectId,
            @ActivityId, 
            1,
            GETDATE(),
            @By)
END
ELSE
BEGIN
   UPDATE EmployeeActivityMap
	SET IsActive=1
	WHERE (EmployeeId=@EmployeeId AND ProjectId=@ProjectId AND ActivityId=@ActivityId)
END
GO
/****** Object:  StoredProcedure [dbo].[SPU_EmployeeRole_UpSert]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_EmployeeRole_UpSert]
* DESCRIPTION:  To Insert or Update [EmployeeRole] record
*	
* CREATED: [10/2021] BY: [Paul] 
MODIFICATION HISTORY
*
***********************************************************/
CREATE   PROCEDURE [dbo].[SPU_EmployeeRole_UpSert] 
	
	@EmployeeId int = 0,
	@RoleName varchar(250)=null,
	@IsActive BIT = NULL,
	@By VARCHAR(50)
AS BEGIN
   
   DECLARE @returnValue int = 0;
  

IF NOT  EXISTS(SELECT 1 FROM  [dbo].[EmployeeRole] WHERE EmployeeId=@EmployeeId and RoleName = @RoleName ) 
	BEGIN

	Update dbo.EmployeeRole set IsActive = 0,UpdateDate=GETUTCDATE(),UpdateBy = @By where EmployeeId = @EmployeeId;  --- currently one employee only have one role

	INSERT INTO [dbo].[EmployeeRole]
			   ([EmployeeId]
			   ,[RoleName]
			   ,[IsActive]
			   ,[CreateDate]
			   ,[CreateBy]
			   ,[UpdateDate]
			   ,[UpdateBy])
		 VALUES
			   (@EmployeeId,
				@RoleName
				  ,1
				,GETUTCDATE()
				,@By
				,GETUTCDATE()
				,@By)

		SELECT @returnValue= SCOPE_IDENTITY()
		
	END
ELSE
	BEGIN

	UPDATE [EmployeeRole]
		SET 
		    --RoleName = @RoleName,
		    IsActive	= ISNULL(@IsActive, IsActive),
			UpdateBy	= @by,
			UpdateDate	= GETUTCDATE()
		WHERE EmployeeId=@EmployeeId and RoleName =@RoleName
		IF (@@ROWCOUNT<>1) SELECT  @returnValue = -1  -- Update none-exist record
		
	END

	RETURN @returnValue

END
GO
/****** Object:  StoredProcedure [dbo].[SPU_Project_Find]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:  [SPU_Project_Find]
* DESCRIPTION:  Find Projects based on searching tokens
* CREATED: [10/2021] PCHEN
MODIFICATION HISTORY
* DATE 		BY		DESCRIPTION 
note: 01/11/2022 Dino Updated for adding Accounting Entity
*************************************************************/
CREATE PROCEDURE [dbo].[SPU_Project_Find] 
	@JsonTokens NVARCHAR(MAX) = NULL,
	@IsDebug CHAR(1) = 'N'
AS
SET NOCOUNT ON
-- Convert Json Extra parameters into memeory table
/*
Note 20211018 At this day I would imagine the following finder
(1) Project Admin => list All
(2) TeamOwner  => Project to his/her deport, by deptcode all status
(3) IT Exec: List by StatusIDs
(4) Accounting : List by StatusIds (Approved and Impaired)

So Json is defined as following
DECLARE @JsonExtras NVARCHAR(MAX)
	='{"deptcode": 723, "teamid": 1,  "statusids":[1,2,3]}';

*/
DECLARE @extra TABLE (
	Name nvarchar(4000), 
	Value nvarchar(max), 
	Type tinyint)

DECLARE @deptcode VARCHAR(10) = null;
DECLARE @teamid INT = -1;

DECLARE @statusids_T TABLE (
	statusid INT)
DECLARE @statusids_cnt INT = 0;

IF (ISJSON(@JsonTokens)>0)
BEGIN
	INSERT INTO @extra (Name, Value, Type)
		SELECT * FROM OPENJSON(@JsonTokens)

	SELECT @deptcode = value from @extra WHERE Name = 'deptcode'
	SELECT @teamid = value from @extra WHERE Name = 'teamid'
	INSERT INTO @statusids_T
		SELECT value FROM OPENJSON(@JsonTokens, '$.statusids')
	SET @statusids_cnt = @@ROWCOUNT

	if (@IsDebug = 'Y') BEGIN
		SELECT @deptcode as '@deptcode', @teamid as '@teamid'
		SELECT '@statusids_T' as tbl , * from @statusids_T
		END
END
-- End of getting Extra searching parameters
SELECT p.[Id] AS '@Id',
	p.[Name] AS '@Name',
	p.[Description] AS '@Description',
	p.[TypeId] AS '@TypeId',
	(SELECT TextVal From Enum em WHERE em.Name = 'ProjectTypeId' AND em.KeyVal = P.TypeId) AS '@Type',
	p.[StartDate] AS '@StartDate',
	p.[EndDate] AS '@EndDate',
	p.[ProdDate] AS '@ProdDate',
	p.[EstHrs] AS '@EstHrs',
	P.ProjectNo AS '@ProjectNo',
	p.[PIRNum] AS '@PIRNum',
	p.[CountryCode] AS '@CountryCode',
	p.[RequestBy] AS '@RequestBy',
	p.[StatusId] AS '@StatusId',
	p.[StatusDate] AS '@StatusDate',
	p.[IsPredefined] AS '@IsPredefined',
	p.[UpdateDate] AS '@UpdateDate',
	p.[UpdateBy] AS '@UpdateBy',
	p.[CreateBy] AS '@CreateBy',
	p.[CreateDate] AS '@CreateDate',
	p.[ParentId] as '@ParentId',
	(Select [Name] FROM Project WHERE Id = ParentId) AS '@ParentProjectName',
	p.[AccountingEntityId] AS '@AccountingEntityId',
	(
		SELECT 
		Id AS '@Id',
		Name AS '@Name',
		PeriodFirstDay AS '@PeriodFirstDay'
		FROM AccountingEntity WHERE Id = p.AccountingEntityID
		FOR XML PATH('AccountingEntity'), Type),
	(
		SELECT t.Id as '@Id',
			t.[Name] '@Name',
			t.[DeptCode] '@DeptCode',
			pt.CreateBy AS '@CreateBy',
			pt.CreateDate AS '@CreateDate',
			pt.UpdateBy AS'@UpdateBy',
			pt.UpdateDate AS '@UpdateDate'
		FROM ProjectTeam pt
		INNER JOIN Team t ON pt.TeamId = t.Id
		WHERE pt.ProjectId = p.Id
		FOR XML PATH('Team') , ROOT('ArrayOfTeam'), Type),
	(
		SELECT 
			em.KeyVal AS '@KeyVal', 
			em.TextVal AS '@TextVal',
			em.Description AS '@Description',
			pa.CreateBy  AS '@CreateBy',
			pa.CreateDate	AS '@CreateDate',
			pa.UpdateBy	AS '@UpdateBy',
			pa.UpdateDate	AS '@UpdateDate'
		FROM ProjectActivity pa
		JOIN Enum em on pa.ActivityId = em.KeyVal AND em.Name = 'ProjectActivityId'
		WHERE pa.ProjectId = p.Id AND pa.IsActive=1
		FOR XML PATH('Setting'), ROOT ('ArrayOfActivity')  ,Type
	),
	(
		SELECT
			H.Id		AS '@Id',
			1		AS '@WorkflowId', -- 1 for Project workflow; 2 for TimesheetSubmission Workflow
			H.StatusId	AS '@StatusId',
			H.StatusBy	AS '@StatusBy',
			H.StatusDate	AS '@StatusDate',
			H.Comment	AS '@Comment',
			H.PrevHistoryId	AS '@PrevHistoryId',
			H.IsCurrent	AS '@IsCurrent'
		FROM WorkflowHistory H WHERE H.EntityId = P.Id
		ORDER BY StatusDate DESC
		FOR XML PATH('WorkflowHistory'), ROOT ('ArrayOfWorkflowHistory')  ,Type
	)
FROM Project P
WHERE 1=1
AND (@deptcode IS NULL OR EXISTS(
		SELECT 1 FROM ProjectTeam PT 
		JOIN Team T ON PT.TeamId = T.Id
		WHERE T.DeptCode = @deptcode ) )
AND (@teamid = -1 OR EXISTS(
		SELECT 1 FROM ProjectTeam PT 
		WHERE PT.TeamId = @teamid) )
AND (@statusids_cnt = 0 OR EXISTS (
	SELECT 1 FROM @statusids_T T WHERE P.StatusId = T.statusid ))
FOR XML PATH('Project'), ROOT ('ArrayOfProject'),  TYPE

/*
exec SPU_Project_Find 
@JsonTokens='{"deptcode": 723, "teamid": 1,  "statusids":[1,2,3]}'
, @isdebug = 'Y'

exec SPU_Project_Find 
@JsonTokens='{"statusids":[1,2,3]}'
, @isdebug = 'Y'



SELECT * FROM OPENJSON(@JsonExtras, '$.statusids')
	
SELECT 'deptcode', * FROM OPENJSON(@JsonExtras) WHERE [Key

	
SELECT JSON_VALUE([value],'$.deptcodes') FROM OPENJSON(@JsonExtras);

SELECT 'extra', * FROM OPENJSON(@JsonExtras)
SELECT 'deptcodes', * FROM OPENJSON(@JsonExtras, '$.deptcodes')
*/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Project_FindByCriteria]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:  [SPU_Project_FindByCriteria]
* DESCRIPTION:  Find Projects based on searching tokens
* CREATED: [10/2021]
* BY: [PCHEN] 
MODIFICATION HISTORY
* DATE 		BY		DESCRIPTION 
note: 10/21/2021 Dino adding IsAdmin indicator
note: 12/14/2021 Dino updated for requested by
note: 01/11/2022 Dino Updated for adding Accounting Entity
*************************************************************/
CREATE PROCEDURE [dbo].[SPU_Project_FindByCriteria] 
	@Name NVARCHAR(100) = NULL,
	@PIRNum VARCHAR(20) = NULL,
	@ProjectTypeID INT = -1,
	@StartDate DATE = NULL,
	@EndDate DATE = NULL,
	@ProdDate DATE = NULL,
	@CountryCode CHAR(3) = NULL,
	@JsonExtras NVARCHAR(MAX) = NULL,
	@IsAdmin BIT = 0
AS
/*** Need further tuning ***/
SET NOCOUNT ON
-- Convert Json Extra parameters into memeory table
/*
DECLARE @JsonExtras NVARCHAR(MAX)
	='{"deptcodes": [723], "statusids":[11,21,31]}';
SELECT 'extra', * FROM OPENJSON(@JsonExtras)
SELECT 'deptcodes', * FROM OPENJSON(@JsonExtras, '$.deptcodes')
SELECT 'statusids', * FROM OPENJSON(@JsonExtras, '$.statusids')

*/
DECLARE @extra TABLE (
	Name nvarchar(4000), 
	Value nvarchar(max), 
	Type tinyint)
DECLARE @deptcodes TABLE (
	deptcode VARCHAR(20));
DECLARE @team TABLE (
	teamId int);
DECLARE @deptcodes_cnt INT;
DECLARE @statusids TABLE (
	statusid INT)
DECLARE @statusids_cnt INT;

IF (ISJSON(@JsonExtras)>0)
BEGIN
	INSERT INTO @extra (Name, Value, Type)
		SELECT * FROM OPENJSON(@JsonExtras)
	INSERT INTO @deptcodes
		SELECT value FROM OPENJSON(@JsonExtras, '$.deptcodes')
	SET @deptcodes_cnt = @@ROWCOUNT

	INSERT INTO @statusids
		SELECT value FROM OPENJSON(@JsonExtras, '$.statusids')
	SET @statusids_cnt = @@ROWCOUNT
	INSERT INTO @team
	SELECT value FROM OPENJSON(@JsonExtras, '$.team')
END
-- End of getting Extra searching parameters
SELECT p.[Id] AS '@Id',
	p.[Name] AS '@Name',
	p.[Description] AS '@Description',
	p.[TypeId] AS '@TypeId',
	(SELECT TextVal From Enum em WHERE em.Name = 'ProjectTypeId' AND em.KeyVal = P.TypeId) AS '@Type',
	ISNULL(p.[StartDate],'1900/1/1') AS '@StartDate',
	ISNULL(p.[EndDate],'1900/1/1') AS '@EndDate',
	ISNULL(p.[ProdDate],'1900/1/1') AS '@ProdDate',
	p.[EstHrs] AS '@EstHrs',
	p.[ProjectNo] AS '@ProjectNo',
	p.[PIRNum] AS '@PIRNum',
	p.[CountryCode] AS '@CountryCode',
	p.RequestBy AS '@RequestBy',
	p.[StatusId] AS '@StatusId',
	ISNULL(p.[StatusDate],'1900/1/1') AS '@StatusDate',
	p.[IsPredefined] AS '@IsPredefined',
	p.[UpdateDate] AS '@UpdateDate',
	p.[UpdateBy] AS '@UpdateBy',
	p.[CreateBy] AS '@CreateBy',
	p.[CreateDate] AS '@CreateDate',
	p.[ParentId] AS '@ParentId',
	(Select [Name] FROM Project WHERE Id = p.ParentId) AS '@ParentProjectName',
	p.[AccountingEntityId] AS '@AccountingEntityId',
	(
		SELECT 
		Id '@Id',
		Name '@Name',
		PeriodFirstDay '@PeriodFirstDay'
		FROM AccountingEntity WHERE Id = p.AccountingEntityID
		FOR XML PATH('AccountingEntity'), Type),
	(
		SELECT t.Id as '@Id',
			t.[Name] '@Name',
			t.[DeptCode] '@DeptCode',
			pt.CreateBy AS '@CreateBy',
			pt.CreateDate AS '@CreateDate',
			pt.UpdateBy AS'@UpdateBy',
			pt.UpdateDate AS '@UpdateDate'
		FROM ProjectTeam pt
		INNER JOIN Team t ON pt.TeamId = t.Id
		WHERE pt.ProjectId = p.Id
		FOR XML PATH('Team') , ROOT('ArrayOfTeam'), Type),
	(
		SELECT 
			em.KeyVal AS '@KeyVal', 
			em.TextVal AS '@TextVal',
			em.Description AS '@Description',
			pa.CreateBy  AS '@CreateBy',
			pa.CreateDate	AS '@CreateDate',
			pa.UpdateBy	AS '@UpdateBy',
			pa.UpdateDate	AS '@UpdateDate'
		FROM ProjectActivity pa
		JOIN Enum em on pa.ActivityId = em.KeyVal AND em.Name = 'ProjectActivityId'
		WHERE pa.ProjectId = p.Id AND pa.IsActive=1
		FOR XML PATH('Setting'), ROOT ('ArrayOfActivity')  ,Type
	),
	(
		SELECT
			H.Id		AS '@Id',
			1		AS '@WorkflowId', -- 1 for Project workflow; 2 for TimesheetSubmission Workflow
			H.StatusId	AS '@StatusId',
			H.StatusBy	AS '@StatusBy',
			H.StatusDate	AS '@StatusDate',
			H.Comment	AS '@Comment',
			H.PrevHistoryId	AS '@PrevHistoryId',
			H.IsCurrent	AS '@IsCurrent'
		FROM WorkflowHistory H WHERE H.EntityId = P.Id
		ORDER BY StatusDate DESC
		FOR XML PATH('WorkflowHistory'), ROOT ('ArrayOfWorkflowHistory')  ,Type
	)
FROM Project P
WHERE (@Name IS NULL OR (LEN(@name) > 2 AND (CHARINDEX(@Name, P.Name)>0 OR CHARINDEX(@Name, P.Description) > 0)))
AND (@PIRNum IS NULL OR @PIRNum = P.PIRNum)
AND (@ProjectTypeID = -1 OR @ProjectTypeID = P.TypeID)
AND (@CountryCode IS NULL OR @CountryCode = P.CountryCode)
AND ((@IsAdmin = 1 AND (SELECT count(1) FROM @statusids) = 0 ) OR P.IsPredefined=1 OR EXISTS (
	SELECT 1 FROM @statusids A WHERE A.statusid = P.StatusId
))
AND (@IsAdmin = 1 OR P.IsPredefined=1 OR EXISTS (
	SELECT 1 FROM ProjectTeam PT JOIN Team T ON PT.TeamID = T.Id
	WHERE PT.ProjectID = P.Id AND PT.TeamId in (SELECT TeamId FROM @team)
	)
)

FOR XML PATH('Project'), ROOT ('ArrayOfProject'),  TYPE

/*
exec SPU_Project_Find
select * from project
*/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Project_Get]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*********************************************************
* PROCEDURE: [SPU_Project_Get]
DESCRIPTION: Get project data by project ID
* CREATED: [10/14/2021]
* BY: [Dino.liu] 
MODIFICATION HISTORY
* PCHEN 10/15/2021 Revised 
note: 01/11/2022 Dino Updated for adding Accounting Entity
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Project_Get] 
	@ID INT
AS
 
SELECT p.[Id] AS '@Id',
	p.[Name] AS '@Name',
	p.[Description] AS '@Description',
	p.[TypeId] AS '@TypeId',
	(SELECT TextVal From Enum em WHERE em.Name = 'ProjectTypeId' AND em.KeyVal = P.TypeId) AS '@Type',
	p.[StartDate] AS '@StartDate',
	p.[EndDate] AS '@EndDate',
	p.[ProdDate] AS '@ProdDate',
	p.[EstHrs] AS '@EstHrs',
	p.[ProjectNo] AS '@ProjectNo',
	p.[PIRNum] AS '@PIRNum',
	p.[CountryCode] AS '@CountryCode',
	p.[RequestBy] AS '@RequestBy',
	p.[StatusId] AS '@StatusId',
	p.[StatusDate] AS '@StatusDate',
	p.[IsPredefined] AS '@IsPredefined',
	p.[UpdateDate] AS '@UpdateDate',
	p.[UpdateBy] AS '@UpdateBy',
	p.[CreateBy] AS '@CreateBy',
	p.[CreateDate] AS '@CreateDate',
	p.[ParentId] AS '@ParentId',
	p.[AccountingEntityId] AS '@AccountingEntityId',
	(
		SELECT 
		Id AS '@Id',
		Name AS '@Name',
		PeriodFirstDay AS '@PeriodFirstDay'
		FROM AccountingEntity WHERE Id = p.AccountingEntityID
		FOR XML PATH('AccountingEntity'), Type),
	(
		SELECT t.Id as '@Id',
			t.[Name] '@Name',
			t.[DeptCode] '@DeptCode',
			pt.CreateBy AS '@CreateBy',
			pt.CreateDate AS '@CreateDate',
			pt.UpdateBy AS'@UpdateBy',
			pt.UpdateDate AS '@UpdateDate'
		FROM ProjectTeam pt
		INNER JOIN Team t ON pt.TeamId = t.Id
		WHERE pt.ProjectId = p.Id
		FOR XML PATH('Team') , ROOT('ArrayOfTeam'), Type),
	(
		SELECT 
			em.KeyVal AS '@KeyVal', 
			em.TextVal AS '@TextVal',
			em.Description AS '@Description',
			pa.CreateBy  AS '@CreateBy',
			pa.CreateDate	AS '@CreateDate',
			pa.UpdateBy	AS '@UpdateBy',
			pa.UpdateDate	AS '@UpdateDate'
		FROM ProjectActivity pa
		JOIN Enum em on pa.ActivityId = em.KeyVal AND em.Name = 'ProjectActivityId'
		WHERE pa.ProjectId = p.Id AND pa.IsActive=1
		FOR XML PATH('Setting'), ROOT ('ArrayOfActivity')  ,Type
	),
	(
		SELECT
			H.Id		AS '@Id',
			1		AS '@WorkflowId', -- 1 for Project workflow; 2 for TimesheetSubmission Workflow
			H.StatusId	AS '@StatusId',
			H.StatusBy	AS '@StatusBy',
			H.StatusDate	AS '@StatusDate',
			H.Comment	AS '@Comment',
			H.PrevHistoryId	AS '@PrevHistoryId',
			H.IsCurrent	AS '@IsCurrent'
		FROM WorkflowHistory H WHERE H.EntityId = P.Id
		ORDER BY StatusDate DESC
		FOR XML PATH('WorkflowHistory'), ROOT ('ArrayOfWorkflowHistory')  ,Type
	)
FROM Project p
WHERE p.Id =@ID
ORDER BY p.UpdateDate DESC
FOR XML PATH('Project'), TYPE

/** For testing --
	select * from Enum

EXEC SPU_Project_Get 1 
	**/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Project_UpdateProjectNo]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Project_UpdateProjectNo]
* DESCRIPTION:  To update ProjectNo upon project approval
* CREATED: [10/2021] BY: PCHEN
MODIFICATION HISTORY
* 1/21/2022 PCHEN Project# based on AccountingEntity
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Project_UpdateProjectNo] 
	@ProjectId INT, @By VARCHAR(20) = NULL
AS BEGIN
DECLARE @CountryCode VARCHAR(10)
	, @ProjectNo VARCHAR(10)
	, @AccountingEntityId INT
SELECT @CountryCode = CountryCode
	, @ProjectNo=ProjectNo
	, @AccountingEntityId = AccountingEntityId
FROM Project WHERE Id = @ProjectId

IF (LEN(ISNULL(@ProjectNo,''))<=2) BEGIN  -- Invalid ProjectNo
	SELECT @ProjectNo = dbo.fn_Project_GetNextNo(@AccountingEntityId)
	UPDATE Project SET ProjectNo = @ProjectNo,
		UpdateBy = ISNULL(@By, UpdateBy),
		UpdateDate = GETUTCDATE()
	WHERE Id = @ProjectId
	IF (@@ROWCOUNT<>1) SELECT @ProjectId = -1
END

RETURN @ProjectId	

END

GO
/****** Object:  StoredProcedure [dbo].[SPU_Project_UpSert]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Project_UpSert]
* DESCRIPTION:  To Insert or Update [Project] record
*	 
* CREATED: [10/2021] BY: [JoyJing] 
MODIFICATION HISTORY
* 10/15/2021 PCHEN Revised
* 12/14/2021 Dino changed for PIRNUM
* 01/11/2022 Dino changed for Accounting Entity
* 01/13/2022 Dino changed for ParentID 
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Project_UpSert] 
	@Id INT = NULL,
	@Name NVARCHAR(100) = NULL,
	@Description NVARCHAR(500) = NULL,
	@TypeId INT = NULL,
	@StartDate DATETIME = NULL,
	@EndDate DATETIME = NULL,
	@ProdDate DATETIME = NULL,
	@EstHrs INT = 0,
	@PIRNum VARCHAR(20) = NULL,
	@CountryCode CHAR(3) = NULL,
	@RequestBy VARCHAR(500) = NULL,
	@IsPredefined BIT = 0,
	@By VARCHAR(50),
	@AccountingEntityId INT = NULL,
	@ParentID INT = NULL
AS BEGIN

	IF EXISTS(SELECT 1 FROM Project WHERE Id = @Id) BEGIN
		UPDATE Project
		SET Name	= ISNULL(@Name, Name),
		    Description = ISNULL(@Description, Description),
			TypeId	= ISNULL(@TypeId, TypeId),
		    StartDate	= ISNULL(@StartDate, StartDate),
		    EndDate		= ISNULL(@EndDate, EndDate),
		    ProdDate = ISNULL(@ProdDate, ProdDate),
		    EstHrs		= ISNULL(@EstHrs, EstHrs),
		    PIRNum	= @PIRNum,
		    CountryCode	= ISNULL(@CountryCode, CountryCode),
		    RequestBy	= ISNULL(@RequestBy, RequestBy),
			-- StatusId/StatusDate to to be updated by Workflow
			AccountingEntityId	= ISNULL(@AccountingEntityId, AccountingEntityId),
			ParentId = @ParentID,
			UpdateBy	= @By,
			UpdateDate	= GETUTCDATE()
		WHERE Id = @Id
		IF (@@ROWCOUNT<>1) SELECT @Id = -1
	END
	ELSE BEGIN
		INSERT INTO [dbo].[Project]
			([Name]
           ,[Description]
           ,[TypeId]
           ,[StartDate]
           ,[EndDate]
           ,[ProdDate]
           ,[EstHrs]
           ,[PIRNum]
           ,[CountryCode]
           ,[RequestBy]
           ,[StatusId]
           ,[StatusDate]
           ,[IsPredefined]
           ,[CreateDate]
           ,[CreateBy]
           ,[UpdateDate]
           ,[UpdateBy]
		   ,[AccountingEntityId]
		   ,[ParentID])
			 VALUES 
			(@Name
           ,@Description
           ,@TypeId
           ,@StartDate
           ,@EndDate
           ,@ProdDate
           ,@EstHrs
           ,@PIRNum
           ,@CountryCode
           ,@RequestBy
           ,1 -- @StatusId
           ,GETUTCDATE() -- @StatusDate
           , @IsPredefined
           ,GETUTCDATE()
           ,@By
           ,GETUTCDATE()
           ,@By
		   ,@AccountingEntityId
		   ,@ParentID)
		SELECT @Id = SCOPE_IDENTITY()
	END
	

END

--IF (SELECT COUNT(1) FROM @Team) > 0
--BEGIN
--DELETE FROM ProjectTeam WHERE ProjectId = @Id;
--INSERT INTO ProjectTeam (ProjectId, TeamId,CreateDate,CreateBy,UpdateDate,UpdateBy) SELECT @Id, ID,GETUTCDATE(),@by,GETUTCDATE(),@by FROM @Team
--END
--IF (SELECT COUNT(1) FROM @Activity) > 0
--BEGIN
--DELETE FROM ProjectActivity WHERE ProjectId = @Id;
--INSERT INTO ProjectActivity (ProjectId, ActivityId,IsActive,CreateDate,CreateBy,UpdateDate,UpdateBy) SELECT @Id, ID,1,GETUTCDATE(),@by,GETUTCDATE(),@by FROM @Activity
--END

RETURN @Id

/** Testing **
DECLARE @JsonExtra NVARCHAR(MAX)
	='[{"Name":"707 IT Development - Operations Back Office-CHINA","DeptCode":"707","Manager":null,"Owner":null,"Employees":[],"Id":4,"CreateBy":"pchen","CreateDate":"2021-10-15T00:00:00","UpdateBy":"pchen","UpdateDate":"2021-10-15T00:00:00","Extra":null},{"Name":"724 IT Development - Financial \\u0026 Risk Back Office","DeptCode":"724","Manager":null,"Owner":null,"Employees":[],"Id":9,"CreateBy":"pchen","CreateDate":"2021-10-15T00:00:00","UpdateBy":"pchen","UpdateDate":"2021-10-15T00:00:00","Extra":null}]';
SELECT 'extra', * FROM OPENJSON(@JsonExtra)

select * from openjson('{"Name":"707 IT Development - Operations Back Office-CHINA","DeptCode":"707","Manager":null,"Owner":null,"Employees":[],"Id":4,"CreateBy":"pchen","CreateDate":"2021-10-15T00:00:00","UpdateBy":"pchen","UpdateDate":"2021-10-15T00:00:00","Extra":null}')

SELECT 'deptcodes', * FROM OPENJSON(@JsonExtra, '$.deptcodes')
SELECT 'countrycodes', * FROM OPENJSON(@JsonExtra, '$.countrycodes')

----------------------------


	IF (@Id > 0) BEGIN -- with a valid ProjectId, now process Teams(@TeamJson) and ProjectActivities(@ActivityJson) association	
		DECLARE @tRunning TABLE (xId INT)
		IF (ISJSON(@TeamJson)>0) BEGIN -- Process Teams data		
			INSERT INTO @tRunning(xId)
			SELECT JSON_VALUE([value],'$.Id') FROM OPENJSON(@TeamJson);
			IF (@@ROWCOUNT > 0) BEGIN
				-- Insert new record
				INSERT INTO ProjectTeam (ProjectId, TeamId, CreateDate, CreateBy, UpdateDate, UpdateBy)
				SELECT @Id, xId, GETUTCDATE(), @By, GETUTCDATE(), @By
				FROM @tRunning A
				WHERE NOT EXISTS (SELECT 1 FROM ProjectTeam pt WHERE pt.ProjectId = @Id AND pt.TeamId=A.xId)
				-- Delete non-exist records
				DELETE FROM ProjectTeam
				WHERE ProjectId = @Id
				AND TeamId NOT IN  (SELECT xId FROM @tRunning)
			END
		END
		IF (ISJSON(@ActivityJson)>0) BEGIN -- Process ProjectActivity data		
			DELETE FROM @tRunning -- Clean the running table
			INSERT INTO @tRunning(xId)
			SELECT JSON_VALUE([value],'$.KeyVal') FROM OPENJSON(@ActivityJson);
			IF (@@ROWCOUNT > 0) BEGIN
				-- Insert new record
				INSERT INTO ProjectActivity(ProjectId, ActivityId, IsActive, CreateDate, CreateBy, UpdateDate, UpdateBy)
				SELECT @Id, xId, 1, GETUTCDATE(), @By, GETUTCDATE(), @By
				FROM @tRunning A
				WHERE NOT EXISTS (SELECT 1 FROM ProjectActivity pt WHERE pt.ProjectId = @Id AND pt.ActivityId=A.xId)
				-- Delete non-exist records
				DELETE FROM ProjectActivity
				WHERE ProjectId = @Id
				AND ActivityId NOT IN  (SELECT xId FROM @tRunning)
			END
		END
	END


**/
GO
/****** Object:  StoredProcedure [dbo].[SPU_ProjectActivity_UpSert]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_ProjectActivity_UpSert]
* DESCRIPTION:  To Insert or Update [ProjectActivity] record
*	 based on @ActivityIdJson eg [{"Id":4}, {"Id":3}]
* CREATED: [10/2021] BY: PCHEN
MODIFICATION HISTORY
* 
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_ProjectActivity_UpSert] 
	@ProjectId INT,
	@ActivityIdJson NVARCHAR(MAX) = NULL,
	@By VARCHAR(50)
AS BEGIN
IF EXISTS(SELECT 1 FROM Project WHERE Id = @ProjectId) BEGIN -- Make sure @ProjectID exists
	IF (ISJSON(@ActivityIdJson)>0) BEGIN -- Process Activitys data		
		DECLARE @tRunning TABLE (xId INT)
		INSERT INTO @tRunning(xId)
		SELECT JSON_VALUE([value],'$.Id') FROM OPENJSON(@ActivityIdJson);
		IF (@@ROWCOUNT > 0) BEGIN
			-- Inactive(soft delete) non-exist records
			UPDATE ProjectActivity SET
				IsActive = 0,
				UpdateBy = @By,
				UpdateDate = GETUTCDATE()
			WHERE ProjectId = @ProjectId
			AND ActivityId NOT IN  (SELECT xId FROM @tRunning)
			-- Update exiting records
			UPDATE ProjectActivity SET
				IsActive = 1,
				UpdateBy = @By,
				UpdateDate = GETUTCDATE()
			WHERE ProjectId = @ProjectId
			AND ActivityId IN  (SELECT xId FROM @tRunning)
			-- Insert new record
			INSERT INTO ProjectActivity (ProjectId, ActivityId, IsActive, CreateDate, CreateBy, UpdateDate, UpdateBy)
			SELECT @ProjectId, xId, 1, GETUTCDATE(), @By, GETUTCDATE(), @By
			FROM @tRunning A
			WHERE NOT EXISTS (SELECT 1 FROM ProjectActivity pt WHERE pt.ProjectId = @ProjectId AND pt.ActivityId=A.xId)
		END
	END
END
RETURN 0
END

/** Testing **
DECLARE @ActivityIdJson NVARCHAR(MAX)
	='[{"Id":4}, {"Id":3}]';
SELECT JSON_VALUE([value],'$.Id') FROM OPENJSON(@ActivityIdJson);	

EXEC SPU_ProjectActivity_UpSert 1, @ActivityIdJson, 'joy'


select * from project order by id
select * from ProjectActivity order by projectid
select * from ProjectTeam order by projectid
**/
GO
/****** Object:  StoredProcedure [dbo].[SPU_ProjectTeam_UpSert]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_ProjectTeam_UpSert]
* DESCRIPTION:  To Insert or Update [ProjectTeam] record
*	 based on @TeamIdJson eg [{"Id":4}, {"Id":3}]
* CREATED: [10/2021] BY: PCHEN
MODIFICATION HISTORY
* 
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_ProjectTeam_UpSert] 
	@ProjectId INT,
	@TeamIdJson NVARCHAR(MAX) = NULL,
	@By VARCHAR(50)
AS BEGIN
DECLARE @OK BIT = 0;
IF EXISTS(SELECT 1 FROM Project WHERE Id = @ProjectId) BEGIN -- Make sure a valid ProjectID
	IF (ISJSON(@TeamIdJson)>0) BEGIN -- Process Teams data		
		DECLARE @tRunning TABLE (xId INT)
		INSERT INTO @tRunning(xId)
		SELECT JSON_VALUE([value],'$.Id') FROM OPENJSON(@TeamIdJson);
		IF (@@ROWCOUNT > 0) BEGIN
			-- Insert new record
			INSERT INTO ProjectTeam (ProjectId, TeamId, CreateDate, CreateBy, UpdateDate, UpdateBy)
			SELECT @ProjectId, xId, GETUTCDATE(), @By, GETUTCDATE(), @By
			FROM @tRunning A
			WHERE NOT EXISTS (SELECT 1 FROM ProjectTeam pt WHERE pt.ProjectId = @ProjectId AND pt.TeamId=A.xId)
			-- Delete non-exist records
			DELETE FROM ProjectTeam
			WHERE ProjectId = @ProjectId
			AND TeamId NOT IN  (SELECT xId FROM @tRunning)
			-- Update exiting records
			UPDATE ProjectTeam SET
				UpdateBy = @By,
				UpdateDate = GETUTCDATE()
			WHERE ProjectId = @ProjectId
			AND TeamId IN  (SELECT xId FROM @tRunning)
		END
	END
END
RETURN 0
END

/** Testing **
DECLARE @TeamIdJson NVARCHAR(MAX)
	='[{"Id":4}, {"Id":2}]';
SELECT JSON_VALUE([value],'$.Id') FROM OPENJSON(@TeamIdJson);	

EXEC SPU_ProjectTeam_UpSert 2, @TeamIdJson, 'joy'


select * from projectteam

**/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Setting_Delete]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*********************************************************
* PROCEDURE:    [SPU_Setting_Delete]
* DESCRIPTION:  
	Delete record by Id
* CREATED: 10/18/2021  DINO
MODIFICATION HISTORY
*
***********************************************************/
Create PROCEDURE [dbo].[SPU_Setting_Delete] 
	@Id INT 
AS BEGIN
	DELETE FROM Enum WHERE Id = @Id
END
GO
/****** Object:  StoredProcedure [dbo].[SPU_Setting_Find]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*********************************************************
* PROCEDURE:    [SPU_Setting_Find]
* DESCRIPTION:  
	Get [Enum] XML records based on searching tokens
* CREATED: 10/13/2021  DINO
MODIFICATION HISTORY
* 10/19/2021 PCHEN	Unify xx_Find SP to take @JsonTokens
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Setting_Find] 
	@JsonTokens NVARCHAR(max)
AS BEGIN
/*** pchen:  We might not need this ***/
SELECT 
   E.Id				AS '@Id',
   E.Name			AS '@Name',
   E.KeyVal		AS '@KeyVal',
   E.TextVal		AS '@TextVal',
   E.Description	AS '@Description',
   E.ParentId			AS '@ParentId',
   E.OrderSeq			AS '@OrderSeq'
FROM Enum E
WHERE 1=2
--(@Name IS NULL OR @Name = E.Name)
--AND (@KeyVal IS NULL OR @KeyVal = E.KeyVal)
--AND (@TextVal IS NULL OR @TextVal = E.TextVal)
--AND (@Description IS NULL OR @Description = E.Description)
  FOR XML PATH('Setting'), ROOT('ArrayOfSetting')  

END
/** Testing
exec SPU_Setting_Find 'ProjectActivityId'
**/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Setting_FindByCriteria]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Setting_FindByCriteria]
* DESCRIPTION:  
	Get [Enum] XML records based on searching tokens
* CREATED: 10/13/2021  DINO
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Setting_FindByCriteria] 
	@Name VARCHAR(100) = NULL,
	@KeyVal VARCHAR(15) = NULL,
	@TextVal NVARCHAR(100) = NULL,
	@Description NVARCHAR(500) = NULL
AS BEGIN
SELECT 
   E.Id				AS '@Id',
   E.Name			AS '@Name',
   E.KeyVal		AS '@KeyVal',
   E.TextVal		AS '@TextVal',
   E.Description	AS '@Description',
   E.ParentId			AS '@ParentId',
   E.OrderSeq			AS '@OrderSeq'
FROM Enum E
WHERE (@Name IS NULL OR @Name = E.Name)
AND (@KeyVal IS NULL OR @KeyVal = E.KeyVal)
AND (@TextVal IS NULL OR @TextVal = E.TextVal)
AND (@Description IS NULL OR @Description = E.Description)
Order by OrderSeq desc
  FOR XML PATH('Setting'), ROOT('ArrayOfSetting')  

END
/** Testing
exec SPU_Setting_Find 'ProjectActivityId'
**/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Setting_Get]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Setting_Get]
* DESCRIPTION:  
	Get setting XML record from [Enum] based on Id
* CREATED: 10/13/2021  DINO
MODIFICATION HISTORY
*
***********************************************************/
Create PROCEDURE [dbo].[SPU_Setting_Get] 
	@Id INT
AS BEGIN

SELECT 
   E.Id				AS '@Id',
   E.Name			AS '@Name',
   E.KeyVal		AS '@KeyVal',
   E.TextVal		AS '@TextVal',
   E.Description		AS '@Description',
   E.ParentId		AS '@ParentId',
   E.OrderSeq		AS '@OrderSeq'  
   
FROM Enum E
WHERE E.Id = @Id
FOR XML PATH('Setting')  

END
GO
/****** Object:  StoredProcedure [dbo].[SPU_Setting_UpSert]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*********************************************************
* PROCEDURE:    [SPU_Setting_UpSert]
* DESCRIPTION:  To Insert or Update record
* CREATED: [10/18/2021] BY: [DINO] 
MODIFICATION HISTORY
*Dino 01/25/2022 Fixed bug for insert data.
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Setting_UpSert] 
	@Id INT = NULL,
	@Name NVARCHAR(100) = NULL,
	@KeyVal VARCHAR(15) = NULL,
	@TextVal VARCHAR(100) = NULL,
	@Description NVARCHAR(500) = NULL,
	@ParentId INT = NULL,
	@OrderSeq INT = NULL
AS BEGIN
	IF EXISTS(SELECT 1 FROM Enum WHERE Id = ISNULL(@Id, -1)) BEGIN
		UPDATE Enum
		SET Name	= ISNULL(@Name, Name),
		    KeyVal	= ISNULL(@KeyVal, KeyVal),
		    TextVal = ISNULL(@TextVal, TextVal),
		    Description		= ISNULL(@Description, Description),
			ParentId		= ISNULL(@ParentId, ParentId),
		    OrderSeq		= ISNULL(@OrderSeq, OrderSeq)
		WHERE Id = @Id
		IF (@@ROWCOUNT<>1) SELECT @Id = -1  -- Update none-exist record
	END
	ELSE BEGIN
		IF NOT EXISTS (SELECT 1 FROM Enum WHERE (Id = @Id) OR (Name = @Name and KeyVal = @KeyVal)) BEGIN
			INSERT INTO [dbo].[Enum]
					   ([Name]
					   ,[KeyVal]
					   ,[TextVal]
					   ,[Description]
					   ,[ParentId]
					   ,[OrderSeq]
					   )
				 VALUES 
					   (
					   @Name
					   ,@KeyVal
					   ,@TextVal
					   ,@Description
					   ,@ParentId
					   ,@OrderSeq)
			SELECT @Id = SCOPE_IDENTITY()
		END 
		ELSE
			SELECT @Id = -2  -- Insert duplicated
	END

	RETURN @Id

END
GO
/****** Object:  StoredProcedure [dbo].[SPU_Team_Find]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*********************************************************
* PROCEDURE:    [SPU_Team_Find]
* DESCRIPTION:  
	Find Team based on searching tokens
* CREATED: 10/13/2021  DINO
MODIFICATION HISTORY
* 10/19/2021 PCHEN	Unify xx_Find SP to take @JsonTokens
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Team_Find] 
	@JsonTokens NVARCHAR(MAX) = NULL
AS BEGIN
	/*** Unfinished ***/
SELECT 
   T.Id				AS '@Id',
   T.Name			AS '@Name',
   T.DeptCode		AS '@DeptCode',
   T.CreateBy		AS '@CreateBy',
   T.CreateDate		AS '@CreateDate',
   T.UpdateBy		AS '@UpdateBy',
   T.UpdateDate		AS '@UpdateDate',  
   ( SELECT 
	   M.Id				AS '@Id',
	   M.UserID			AS '@UserId',
	   M.FirstName		AS '@FirstName',
	   M.LastName		AS '@LastName',
	   M.DisplayName	AS '@DisplayName',
	   M.Email			AS '@Email',
	   M.Title			AS '@Title',
	   M.JobGradeId		AS '@JobGradeId',
	   M.DeptCode		AS '@DeptCode',
	   M.CountryCode	AS '@CountryCode',
	   M.ManagerID		AS '@ManagerId'
      FROM Employee M  
      WHERE M.Id = T.ManagerID  
      FOR XML PATH('Manager'), TYPE  
    ),
	( SELECT 
	   M.Id				AS '@Id',
	   M.UserID			AS '@UserId',
	   M.FirstName		AS '@FirstName',
	   M.LastName		AS '@LastName',
	   M.DisplayName	AS '@DisplayName',
	   M.Email			AS '@Email',
	   M.Title			AS '@Title',
	   M.JobGradeId		AS '@JobGradeId',
	   M.DeptCode		AS '@DeptCode',
	   M.CountryCode	AS '@CountryCode',
	   M.ManagerID		AS '@ManagerId'
      FROM Employee M  
      WHERE M.Id = T.OwnerId  
      FOR XML PATH('Owner'), TYPE  
    )
FROM Team T
WHERE 1=2

FOR XML PATH('Team'), ROOT('ArrayOfTeam')

END
GO
/****** Object:  StoredProcedure [dbo].[SPU_Team_FindByCriteria]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*********************************************************
* PROCEDURE:    [SPU_Team_FindByCriteria]
* DESCRIPTION:  
	Find Team based on searching tokens
* CREATED: 10/13/2021  DINO
MODIFICATION HISTORY
*  addd partentId search  12/2/2021 by paul.rao
*  12/8/2021 PCHEN fixed only return parent teams
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Team_FindByCriteria] 
	@Id INT = NULL,
	@Name NVARCHAR(100) = NULL,
	@DeptCode VARCHAR(10) = NULL,
	@ManagerId INT = NULL,
	@OwnerId INT = NULL,
	@ParentId INT = null,
	@IsAdmin bit
AS BEGIN
	
SELECT 
   T.Id				AS '@Id',
   T.Name			AS '@Name',
   T.DeptCode		AS '@DeptCode',
   T.CreateBy		AS '@CreateBy',
   T.CreateDate		AS '@CreateDate',
   T.UpdateBy		AS '@UpdateBy',
   T.UpdateDate		AS '@UpdateDate',  
   T.ParentId       As '@ParentId',
   T.ShortName		As '@ShortName',
   ( SELECT 
	   M.Id				AS '@Id',
	   M.UserID			AS '@UserId',
	   M.FirstName		AS '@FirstName',
	   M.LastName		AS '@LastName',
	   M.DisplayName	AS '@DisplayName',
	   M.Email			AS '@Email',
	   M.Title			AS '@Title',
	   M.JobGradeId		AS '@JobGradeId',
	   M.DeptCode		AS '@DeptCode',
	   M.CountryCode	AS '@CountryCode',
	   M.ManagerID		AS '@ManagerId'
      FROM Employee M  
      WHERE M.Id = T.ManagerID  
      FOR XML PATH('Manager'), TYPE  
    ),
	( SELECT 
	   M.Id				AS '@Id',
	   M.UserID			AS '@UserId',
	   M.FirstName		AS '@FirstName',
	   M.LastName		AS '@LastName',
	   M.DisplayName	AS '@DisplayName',
	   M.Email			AS '@Email',
	   M.Title			AS '@Title',
	   M.JobGradeId		AS '@JobGradeId',
	   M.DeptCode		AS '@DeptCode',
	   M.CountryCode	AS '@CountryCode',
	   M.ManagerID		AS '@ManagerId'
      FROM Employee M  
      WHERE M.Id = T.OwnerId  
      FOR XML PATH('Owner'), TYPE  
    ) 
FROM Team T
WHERE @IsAdmin = 1  or (
(@Name IS NULL OR T.Name =@Name)
AND (ISNULL(@ParentId, 0) = 0 or (t.ParentId = @ParentId and t.IsActive =1 ))
AND (@DeptCode IS NULL OR @DeptCode = t.DeptCode)
AND (ISNULL(@ManagerId,0) =0 OR @ManagerId = t.ManagerId)
AND (ISNULL(@OwnerId,0) = 0 or  @OwnerId = t.OwnerId)
AND (ISNULL(@Id, 0) = 0 or @Id = t.Id)
)
ORDER BY T.DeptCode
FOR XML PATH('Team'), ROOT('ArrayOfTeam')

END

GO
/****** Object:  StoredProcedure [dbo].[SPU_Team_Get]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*********************************************************
* PROCEDURE:    [SPU_Team_Get]
* DESCRIPTION:  
	Get [Team] XML record based on Id
* CREATED: 10/13/2021  DINO
MODIFICATION HISTORY
* PCHEN 10/12/2021 Add Employee collection
* PCHEN 10/19/2021 Add:
	ShortName; IsActive(soft delete); OwnerId + ManagerId
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Team_Get] 
	@Id INT
AS BEGIN

SELECT 
   T.Id				AS '@Id',
   T.Name			AS '@Name',
   T.ShortName		AS '@ShortName',
   T.DeptCode		AS '@DeptCode',
   T.AccountingEntityId As '@AccountingEntityId',
   T.ManagerId		AS '@ManagerId',
   T.OwnerId		AS '@OwnerId',
   T.IsActive		AS '@IsActive',
   T.CreateBy		AS '@CreateBy',
   T.CreateDate		AS '@CreateDate',
   T.UpdateBy		AS '@UpdateBy',
   T.UpdateDate		AS '@UpdateDate',
   ( SELECT 
	   M.Id				AS '@Id',
	   M.UserID			AS '@UserId',
	   M.FirstName		AS '@FirstName',
	   M.LastName		AS '@LastName',
	   M.DisplayName	AS '@DisplayName',
	   M.Email			AS '@Email',
	   M.Title			AS '@Title',
	   M.JobGradeId		AS '@JobGradeId',
	   M.DeptCode		AS '@DeptCode',
	   M.CountryCode	AS '@CountryCode',
	   M.ManagerID		AS '@ManagerId'
      FROM Employee M  
      WHERE M.Id = T.ManagerID  
      FOR XML PATH('Manager'), TYPE  
    ),
	( SELECT 
	   M.Id				AS '@Id',
	   M.UserID			AS '@UserId',
	   M.FirstName		AS '@FirstName',
	   M.LastName		AS '@LastName',
	   M.DisplayName	AS '@DisplayName',
	   M.Email			AS '@Email',
	   M.Title			AS '@Title',
	   M.JobGradeId		AS '@JobGradeId',
	   M.DeptCode		AS '@DeptCode',
	   M.CountryCode	AS '@CountryCode',
	   M.ManagerID		AS '@ManagerId'
      FROM Employee M  
      WHERE M.Id = T.OwnerId  
      FOR XML PATH('Owner'), TYPE  
    ), 
    (  
      SELECT 
	   M.Id				AS '@Id',
	   M.UserID			AS '@UserId',
	   M.FirstName		AS '@FirstName',
	   M.LastName		AS '@LastName',
	   M.DisplayName	AS '@DisplayName',
	   M.Email			AS '@Email',
	   M.Title			AS '@Title',
	   M.JobGradeId		AS '@JobGradeId',
	   M.DeptCode		AS '@DeptCode',
	   M.CountryCode	AS '@CountryCode',
	   M.ManagerID		AS '@ManagerId'
      FROM Employee M JOIN TeamEmployee TE
		ON M.Id = TE.EmployeeId
      WHERE TE.TeamId = T.Id  
      FOR XML PATH('Employee'), ROOT('ArrayOfEmployee'), TYPE
	  )  
FROM Team T
WHERE T.Id = @Id
FOR XML PATH('Team')  

END
/** Testing Code **
EXEC SPU_Team_get 9
**/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Team_UpSert]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*********************************************************
* PROCEDURE:    [SPU_Team_UpSert]
* DESCRIPTION:  To Insert or Update [Team] record
* CREATED: [10/13/2021] BY: [DINO] 
MODIFICATION HISTORY
* 10/10/2021 PCHEN Added ShortName and IsActive
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Team_UpSert] 
	@Id INT,
	@Name NVARCHAR(200) = NULL,
	@ShortName NVARCHAR(50) = NULL,
	@DeptCode VARCHAR(10) = NULL,
	@ManagerId INT = NULL,
	@OwnerId INT = NULL,
	@IsActive BIT = NULL,
	@By VARCHAR(50)
AS BEGIN
	IF EXISTS(SELECT 1 FROM Team WHERE Id = @Id) BEGIN
		UPDATE Team
		SET Name		= ISNULL(@Name, Name),
		    ShortName	= ISNULL(@ShortName, ShortName),
		    DeptCode	= ISNULL(@DeptCode, DeptCode),
		    ManagerId	= ISNULL(@ManagerId, ManagerId),
		    OwnerId		= ISNULL(@OwnerId, OwnerId),
			IsActive	= ISNULL(@IsActive, IsActive),
			UpdateBy	= @by,
			UpdateDate	= GETUTCDATE()
		WHERE Id = @Id
		IF (@@ROWCOUNT<>1) SELECT @Id = -1  -- Update none-exist record
	END
	ELSE BEGIN
		IF NOT EXISTS (SELECT 1 FROM Team WHERE (Id = @Id) OR (Name = @Name)) BEGIN
			INSERT INTO [dbo].[Team]
					   ([Name], [ShortName]
					   ,[DeptCode]
					   ,[ManagerID]
					   ,[OwnerId], [IsActive]
					   ,[CreateDate]
					   ,[CreateBy]
					   ,[UpdateDate]
					   ,[UpdateBy])
				 VALUES 
					   (
					   @Name, @ShortName
					   ,@DeptCode
					   ,@ManagerId
					   ,@OwnerId, @IsActive
					   ,GETUTCDATE()
					   ,@By
					   ,GETUTCDATE()
					   ,@By)
			SELECT @Id = SCOPE_IDENTITY()
		END 
		ELSE
			SELECT @Id = -2  -- Insert duplicated
	END

	RETURN @Id

END
GO
/****** Object:  StoredProcedure [dbo].[SPU_TeamEmployee_UpSert]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_TeamEmployee_UpSert]
* DESCRIPTION:  To Insert or Update [TeamEmployee] record
*	
* CREATED: [10/2021] BY: [Paul] 
MODIFICATION HISTORY
*
***********************************************************/
CREATE   PROCEDURE [dbo].[SPU_TeamEmployee_UpSert] 
	
	@TeamId INT = 0,
	@EmployeeId int = 0,
	@IsActive BIT = NULL,
	@By VARCHAR(50)
AS BEGIN
   Declare @returnValue  int = 0;
   SELECT  @TeamId = Id from Team where id = @TeamId;
   IF @TeamId < 1
     begin
	   return @returnValue;
	 end


	IF EXISTS(SELECT 1 FROM  [dbo].[TeamEmployee] WHERE EmployeeId=@EmployeeId) 
	BEGIN
		-- (1)Make sure UserID is not updated
		UPDATE TeamEmployee
		SET 
		    TeamId = @TeamId,
		    IsActive	= ISNULL(@IsActive, IsActive),
			UpdateBy	= @by,
			UpdateDate	= GETUTCDATE()
		WHERE EmployeeId=@EmployeeId 
		IF (@@ROWCOUNT<>1) SELECT  @returnValue = -1  -- Update none-exist record
	END
	ELSE BEGIN

			INSERT INTO [dbo].[TeamEmployee]
					   ([TeamId]
					   ,[EmployeeId]
					   ,[IsActive]
					   ,[CreateDate]
					   ,[CreateBy]
					   ,[UpdateDate]
					   ,[UpdateBy])
				 VALUES
					   (@TeamId
					   ,@EmployeeId
					   ,@IsActive
					   ,GETUTCDATE()
					   ,@By
					   ,GETUTCDATE()
					   ,@By)
		
						SELECT @returnValue= SCOPE_IDENTITY()
	
		
	END

	RETURN @returnValue

END
GO
/****** Object:  StoredProcedure [dbo].[SPU_Teamsheet_Find]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Teamsheet_Find]
* DESCRIPTION:  
* CREATED: 10/2021  JoyJing
MODIFICATION HISTORY
* PCHEN Reimplement based on new "TimeSheet" Business Entity
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Teamsheet_Find] 
	@JsonTokens NVARCHAR(1000) = NULL,
	@debugging BIT = NULL
AS
SET NOCOUNT ON

BEGIN -- Define Searching criteria tokens, This needs to be adjusted according to application need
 DECLARE @isValid BIT = 0, -- Assume invalid search
 -- PCHEN 10/15/2021 Note: As of this date, these 4 type of search can be projected
		@employeeid Int = NULL,		-- by employee
		@teamid INT = NULL,			-- by team
		@fromdate DATETIME = NULL,
		@todate DATETIME = NULL
END

IF (ISJSON(@JsonTokens)>0)
BEGIN
	SET @isValid = 1
	DECLARE @tokens TABLE (
		Name nvarchar(4000),  Value nvarchar(max),  Type tinyint)

	INSERT INTO @tokens (Name, Value, Type)
		SELECT * FROM OPENJSON(@JsonTokens)

	SELECT @employeeId = Value from @tokens WHERE Name = 'employeeid'
	SELECT @teamid = Value from @tokens WHERE Name = 'teamid'
	SELECT @fromdate = Value from @tokens WHERE Name = 'fromdate'
	SELECT @todate = Value from @tokens WHERE Name = 'todate'
END

DECLARE @tEmp TABLE ( EmpId INT, TeamId INT)
-- Get all candidate employees into @tEmp
INSERT INTO @tEmp 
SELECT E.Id, @teamid
FROM Employee E 
WHERE @isValid = 1
AND (@employeeid IS NULL OR E.Id = @employeeid)
AND (@teamid IS NULL OR EXISTS(
	SELECT 1 FROM TeamEmployee TE JOIN Team T ON TE.TeamId = T.id
	WHERE T.Id = @teamid)
)
IF (@debugging = 1) SELECT '@tEmp' as tbl, * from @tEmp

BEGIN  -- Get XML
SELECT 
	E.Id		AS '@EmployeeId',
	@teamid		AS '@TeamId',
	@fromdate	AS '@FromDate',
	@todate		AS '@ToDate',
	-1.11			AS '@Hours',  -- Not Calculated yet
	(SELECT	   
	   S.Id				AS '@Id',
	   S.EmployeeId		AS '@EmployeeId',
	   S.ProjectId		AS '@ProjectId',
	   (SELECT Name	FROM Project P WHERE P.Id = s.ProjectId
			)			AS '@ProjectName',
	   S.ActivityId		AS '@ActivityId',
	   ( SELECT TextVal FROM Enum WHERE Name = 'ProjectActivityId'
			AND KeyVal = S.ActivityId)  AS '@ActivityName',
	   S.ActivityDate	AS '@ActivityDate',
	   S.Hours			AS '@Hours',
	   S.Description	AS '@Description',
	   S.SourceId		AS '@SourceId',
	   S.SubmissionId	AS '@SubmissionId',
	   S.CreateBy		AS '@CreateBy',
	   S.CreateDate		AS '@CreateDate',
	   S.UpdateBy		AS '@UpdateBy',
	   S.UpdateDate		AS '@UpdateDate'
	 FROM TimeSheet S 
	 WHERE S.EmployeeId = X.EmpId
	 AND ISNULL(@fromdate, '1/1/1900') < S.ActivityDate 
	 AND ISNULL(@todate, '9/9/9999') > S.ActivityDate
	 FOR XML PATH('TimeSheetActivity')  , ROOT('TimeSheetActivity'), TYPE
	 )
FROM Employee E JOIN @tEmp X ON E.Id = X.EmpId
FOR XML PATH('TimeSheet')  , ROOT('ArrayOfTimeSheet'), TYPE

END

GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_ExecutiveApproval]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_ExecutiveApproval]
* DESCRIPTION:  Timesheet Executive Approval for all teams
* CREATED: 10/26/2021  PCHEN
MODIFICATION HISTORY
12/22/2021 PCHEN Add 'AccountingEntity', Now ExecutiveApproval is per Entity
01/27/2022 PCHEN Transit from '_V2' where @AccountingEntityId is optional
	(compatable with previous version where @AccoutingEntityId is not in place)
	To: @AccountingEntityId is required for approval
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_ExecutiveApproval] 
	@PeriodCode CHAR(6),  -- 'YYYYMM'
	@AccountingEntityId INT, 
	@Comment NVARCHAR(500) = NULL,
	@By varchar(50),
	@IsDebug CHAR(1) = 'N'
AS BEGIN
SET NOCOUNT ON
-- For IT Executive to approve (close) a timesheet period
DECLARE @StatusID INT = 2, -- Executive Approved - TimesheetStatusId in [Enum]'
	@WorkflowID INT = 2   -- Timesheet Approval WorkflowID = 2

/**** Dev Note PCHEN 10/26/2021 * laying out the logic but might need some more refinement *****/

-- Step 1: Pull all timesheet submissions under the same PeriodCode for AccountingEntityId
-- Step 2: update timesheet submission status to 'IT Executive Approval'
-- Step 3: Update workflow history
-- Step 4: Close the period and make the next one current
DECLARE @t TABLE ( SubmisstionId INT, PrevHistoryId INT)
INSERT INTO @t 
SELECT s.Id, 0 
FROM TimesheetSubmission s
WHERE EmployeeId IN (
	SELECT TE.EmployeeId FROM TeamEmployee TE
	JOIN Team T ON TE.TeamId = T.Id
	WHERE T.AccountingEntityId = @AccountingEntityId
	UNION
	SELECT OwnerId
	FROM Team T 
	WHERE T.AccountingEntityId = @AccountingEntityId
)
AND PeriodCode = @PeriodCode
AND StatusId <> 2 -- Not "Executive Approved"

-- Associate with PrevHistoryId from [WorkflowHistory] table
UPDATE A SET
	PrevHistoryId = WF.Id
FROM @t A JOIN WorkflowHistory WF ON
	A.SubmisstionId = WF.EntityId AND 
	WF.WorkflowId = @WorkflowID AND 
	WF.IsCurrent = 1

DECLARE @errcnt INT = 0;
BEGIN TRAN
-- * Update TimesheetSubmission status 
UPDATE T SET 
	StatusDate = GETUTCDATE(),
	StatusId = @StatusID, 
	UpdateDate = GETUTCDATE(),
	UpdateBy = @By
FROM TimesheetSubmission T JOIN @t B ON T.Id = B.SubmisstionId
IF (@@ERROR<> 0) SELECT @errcnt = @errcnt + 1

-- * Update existing WorkflowHistory to 'Not Current'
UPDATE WF SET
	IsCurrent = 0
FROM WorkflowHistory WF JOIN @t B ON WF.Id = B.PrevHistoryId
IF (@@ERROR<> 0) SELECT @errcnt = @errcnt + 1

-- * Create the lastest WorkflowHistory record
INSERT INTO WorkflowHistory (
	WorkflowId, EntityId, 
	StatusId, StatusBy, StatusDate, 
	Comment, PrevHistoryId, IsCurrent)
SELECT 
	@WorkflowID, SubmisstionId, 
	@StatusID, @By, GETUTCDATE(),
	@Comment, PrevHistoryId, 1
FROM @t
IF (@@ERROR<> 0) SELECT @errcnt = @errcnt + 1

-- * Closing current and prepare future periods  
DECLARE @x INT
EXEC @x = SPU_TimesheetPeriod_ClosePeriod @PeriodCode, @AccountingEntityId, @By, @IsDebug
IF @x <> 0 SELECT @errcnt = @errcnt + 1	

IF (@IsDebug = 'Y') BEGIN
	SELECT '' as 'TimesheetSubmission', * FROM TimesheetSubmission WHERE ID in (select SubmisstionId from @T)
	SELECt '' AS 'WorkflowHistory', * from WorkflowHistory where WorkflowId = 2
		AND EntityId in (select SubmisstionId from @T) ORDER BY EntityId, StatusDate
    SELECT @errcnt = 100; -- To rollback transaction
END

IF (@errcnt = 0) BEGIN 	
	COMMIT;  
	RETURN 0; -- Success
	END
ELSE BEGIN
	ROLLBACK;
	RETURN -1;  -- Indicate a failure
	END

END
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_ExecutiveApproval_Undo]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_ExecutiveApproval_Undo]
* DESCRIPTION:  Undo Timesheet Executive Approval for All Employee per Period
	Will execute only against "Just Closed (Executive Approved) Period"
* CREATED: 11/30/2021  PCHEN
MODIFICATION HISTORY
01/27/2022 PCHEN Add @AccountingEntityId, can undo per Entity
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_ExecutiveApproval_Undo] 
	@PeriodCode CHAR(6),  -- 'YYYYMM'
	@AccountingEntityId INT,
	@Comment NVARCHAR(500) = NULL,
	@By varchar(50)
AS BEGIN

SET NOCOUNT ON

-- Make sure Timesheet Period is 'Closed' and next one is 'Current'
DECLARE @NextPeriod CHAR(6) = CONVERT(nvarchar(6), DATEADD(MONTH, 1, CONCAT(@PeriodCode, '01')), 112),
	@_Closed INT = 2,
	@_Current INT = 1,
	@_Future INT = 0;

IF NOT (EXISTS (SELECT 1 FROM TimesheetPeriod 
					WHERE PeriodCode = @PeriodCode AND StatusId = @_Closed 
					AND AccountingEntityId = @AccountingEntityId) -- Period is closed
	AND EXISTS (SELECT 1 FROM TimesheetPeriod 
			WHERE PeriodCode = @NextPeriod AND StatusId = @_Current
			AND AccountingEntityId = @AccountingEntityId) -- Next Period is current
			)
	RETURN -1  -- Not undo-able, return failed

-- All submissions that need to roll-back
DECLARE @tSubmission TABLE (SubmissionId INT, LastWorkflowPKId INT)
INSERT INTO @tSubmission(SubmissionId, LastWorkflowPKId)
SELECT S.Id, ISNULL(W.Id, 0) FROM TimesheetSubmission S 
LEFT JOIN WorkflowHistory W ON S.Id = W.EntityId
WHERE S.PeriodCode = @PeriodCode
AND W.WorkflowId = 2 AND W.EntityId = S.Id AND W.IsCurrent=1
AND EXISTS (
	SELECT 1 FROM Employee E 
	JOIN TeamEmployee TE ON TE.EmployeeId = E.Id
	JOIN Team T ON T.Id = TE.TeamId
	WHERE T.AccountingEntityId = @AccountingEntityId
	AND (S.EmployeeId = E.Id 
      OR S.EmployeeId = T.ManagerId 
      OR S.EmployeeId = T.OwnerId)
	)

BEGIN TRAN
BEGIN TRY
	UPDATE TimesheetPeriod SET 
		StatusId = @_Future, UpdateBy = @By, UpdateDate = GETUTCDATE()
		WHERE StatusId=@_Current AND PeriodCode = @NextPeriod
		AND AccountingEntityId = @AccountingEntityId

	UPDATE TimesheetPeriod SET 
		StatusId = @_Current, UpdateBy = @By, UpdateDate = GETUTCDATE()
		WHERE StatusId=@_Closed AND PeriodCode = @PeriodCode
		AND AccountingEntityId = @AccountingEntityId

	UPDATE S SET
		StatusId = 1, StatusDate = GETUTCDATE(), -- Manager Approved
		UpdateBy = @By,	UpdateDate = GETUTCDATE()
	FROM TimesheetSubmission S JOIN @tSubmission T ON S.Id = T.SubmissionId
	WHERE S.StatusId = 2	-- Executive Approved

	UPDATE W SET
		IsCurrent = 0
	FROM WorkflowHistory W JOIN @tSubmission S ON W.Id = S.LastWorkflowPKId

	INSERT INTO WorkflowHistory(WorkflowId, EntityId, StatusId, StatusBy, StatusDate, Comment, PrevHistoryId, IsCurrent)
	SELECT 2, S.SubmissionId, 1, @By, GETUTCDATE(), @Comment, S.LastWorkflowPKId, 1
	FROM @tSubmission S

	COMMIT TRAN
	RETURN 0
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRAN
	RETURN -2 -- Mark failure
END CATCH

RETURN -999 -- Shouldn't reach here

END

GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_ManagerApproval]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_ManagerApproval]
* DESCRIPTION:  Timesheet Manager Approval per Employee
	For Team Manager Timesheet Approval
* CREATED: 10/23/2021  PCHEN
MODIFICATION HISTORY
 10/29/2021 PCHEN added comment field in case needed in the future
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_ManagerApproval] 
	@EmployeeId INT, 
	@PeriodCode CHAR(6),  -- 'YYYYMM'
	@TimesheetActivityIdsJSON NVARCHAR(max),
	@Comment NVARCHAR(500) = NULL,
	@By varchar(50)
AS BEGIN
SET NOCOUNT ON

DECLARE @SubmissionId INT;

-- For Team Manager Timesheet Approval on each Employee

-- Step 1: Create Timesheet Submission ID on behalf of Employee
SELECT @SubmissionId = Id FROM TimesheetSubmission
WHERE EmployeeId = @EmployeeId AND PeriodCode = @PeriodCode

IF (ISNULL(@submissionid, 0) =0) BEGIN
	INSERT INTO dbo.TimesheetSubmission (EmployeeId, PeriodCode, StatusId, StatusDate, 
		CreateBy, CreateDate, UpdateBy, UpdateDate)
	VALUES(@EmployeeId, @PeriodCode, 0, GETUTCDATE(), 
		@By, GETUTCDATE(), @By, GETUTCDATE())
	SET @SubmissionId = @@IDENTITY -- TimesheetSubmission.Id

	-- step 2: Create Workflow history on 'Draft'
	EXEC SPU_Workflow_Update 2, @SubmissionId, 0, @Comment, @By  -- 0==Draft
END

-- Step 3: Attach TimesheetSubmission(Timesheet)ID to TimesheetActivities
IF (ISJSON(@TimesheetActivityIdsJSON)>0) BEGIN -- Update TimesheetActivity SubmisstionID
	DECLARE @tID TABLE (Id INT)
	INSERT INTO @tID(Id) SELECT JSON_VALUE([value],'$.Id') FROM OPENJSON(@TimesheetActivityIdsJSON);
	IF (@@ROWCOUNT > 0) BEGIN
		UPDATE A SET SubmissionId = @SubmissionId
		FROM TimesheetActivity A JOIN @tID B on A.Id = B.Id
	END
END

-- step 4: Create Workflow history for 'Manager Approval'
EXEC SPU_Workflow_Update 2, @SubmissionId, 1, @Comment, @By  -- 1==Manager Approved

RETURN 0

END
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_ManagerApproval_Undo]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_ManagerApproval_Undo]
* DESCRIPTION:  Undo Timesheet Manager Approval per Employee
	Will execute only before Executive Approval
* CREATED: 11/19/2021  PCHEN
MODIFICATION HISTORY
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_ManagerApproval_Undo] 
	@EmployeeId INT, 
	@PeriodCode CHAR(6),  -- 'YYYYMM'
	@Comment NVARCHAR(500) = NULL,
	@By varchar(50)
AS BEGIN
SET NOCOUNT ON

DECLARE @SubmissionId INT;
SELECT @SubmissionId = S.Id FROM TimesheetPeriod P
	JOIN TimesheetSubmission S ON P.PeriodCode = S.PeriodCode
	WHERE P.PeriodCode = @PeriodCode AND P.StatusId = 1 -- 1: Period Current
	AND S.EmployeeId = @EmployeeId AND S.StatusId = 1 -- 1: Timesheet status: Manager Approved

IF ISNULL(@SubmissionId, 0) = 0
	RETURN -1  -- Not undo-able, return failed

-- Step 1: Change Submission status to Draft mode
UPDATE TimesheetSubmission SET StatusId = 0 WHERE Id = @SubmissionId
-- step 2: Create Workflow history for 'Draft'
EXEC SPU_Workflow_Update 2, @SubmissionId, 0, @Comment, @By  -- 0==Draft
-- step 3: revoke SubmissionId from Activity
UPDATE TimesheetActivity SET SubmissionId = 0 WHERE SubmissionId= @SubmissionId

RETURN 0

END

/* testing *
*/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_ByEntity]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_Outlook_ByEntity]
* DESCRIPTION:  Timesheet Outlook for IT Executive Per AccountingEntity 
	(ALL Teams under the Entity, All Projects)
  Return a DataTable
* CREATED: 10/2021  PCHEN on [SPU_Timesheet_Outlook_Teams]
MODIFICATION HISTORY
- 11/08/2021 PCHEN Introduced ParentId, only report on TopMost teamID (ParentId = 0)
  eg: Parent Team 'Tx' will have two Child Teams
		Child Team 'Ta', Parent ='Tx'
		Child team 'Tb', Parent ='Tx'
  We will report on "Tx", NOT 'Ta' or 'Tb' individually
- 11/23/2021 P.RAO Added Project sorting, leave predefined on top
- 11/24/2021 PCHEN Return ALL teams
- 12/21/2021 PCHEN 
	Obsoleted "SPU_Timesheet_Outlook_Teams" and newly create this SP
	added AccountEntityId as parameter
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_Outlook_ByEntity]  
	@PeriodCode CHAR(6),  -- 'YYYYMM'
	@AccountingEntityId INT = -1,
	@IsDebug CHAR(1) = 'N'
AS BEGIN
SET NOCOUNT ON

-- @tTeam TeamId with Reporting TeamId (TopMostId)
DECLARE @tTeam TABLE (Id INT, TopMostId INT)

;WITH X as (
    SELECT Id, ParentId, 0 Lvl FROM Team WHERE AccountingEntityId = @AccountingEntityId
    UNION ALL
    SELECT T.Id, T.ParentId, Lvl+1
    FROM Team T JOIN X on T.ParentId = X.Id
	)
INSERT INTO @tTeam
SELECT Id, CASE WHEN ParentId = 0 THEN Id ELSE ParentId END AS ParentId
FROM ( SELECT *, MAX(Lvl) OVER (PARTITION BY Id) AS [MaxLevel] 
       FROM X ) A
WHERE MaxLevel = Lvl 

-- Using temp table #T for grouping
DROP TABLE IF EXISTS  #T
CREATE TABLE #T  (
	TeamID INT, Team VARCHAR(100),
	ProjectID INT, Project VARCHAR(100),
	Hours Decimal(18,2), HoursT VARCHAR(100) ,
	IsPredefined bit )	

;WITH C AS (
	SELECT T.TopMostId AS TeamId, A.ProjectId, SUM(Hours) as Hours
	FROM TimesheetActivity A
	JOIN TimesheetSubmission S ON A.SubmissionId = S.id 
	JOIN TeamEmployee TE on TE.EmployeeId = A.EmployeeId
	JOIN @tTeam T ON TE.TeamId = T.Id
	WHERE A.Hours>0   
	AND S.PeriodCode = @PeriodCode
	GROUP BY T.TopMostId, A.ProjectId)
INSERT INTO #T (TeamID, Team, ProjectID, Project, Hours,IsPredefined)
SELECT T.Id, REPLACE(REPLACE(REPLACE('S'+T.DeptCode+convert(varchar(20),t.Id),' ','space'),'&','strike'),'-','underline') ,
	C.ProjectId, P.Name, C.Hours,p.IsPredefined
FROM Team T 
LEFT JOIN C on T.Id = C.TeamId
LEFT JOIN Project P ON C.ProjectId = P.Id
WHERE EXISTS (SELECT 1 FROM @tTeam WHERE TopMostId = T.Id)
order  by T.DeptCode asc

IF (@@ROWCOUNT=0) -- Create a dummy record if no data
INSERT INTO #T (TeamID, Team, ProjectID, Project, Hours) 
VALUES(0, 'NoTeam', 0, 'No Project Data', 0)

UPDATE #T SET HoursT = CONVERT(varchar(10), Hours) + '::'
		+ CONVERT(VARCHAR(10), ProjectID) + '::'
		+ CONVERT(VARCHAR(10), TeamID) 

DECLARE @cols NVARCHAR(MAX) = 
STUFF((SELECT DISTINCT ',' + QUOTENAME(Team) 
    from #T 
FOR XML PATH(''), Type
).value('.', 'NVARCHAR(MAX)') ,1,1,'')

DECLARE @query  NVARCHAR(MAX) = 
N'SELECT Project, ' + @cols + N' FROM 
( SELECT Project,IsPredefined, isnull(HoursT,0) as HoursT, Team
    FROM #t 
) x
pivot 
(   MIN(HoursT)
    FOR Team IN (' + @cols + N')
) p WHERE LEN(ISNULL(Project,''''))>0 ORDER BY IsPredefined DESC, Project ASC'

IF (@IsDebug = 'Y') BEGIN -- Debugging check point
	SELECT '' AS 'Team@tTeam', * FROM @tTeam
	SELECT '' as '#T', * FROM #T order by  IsPredefined desc, Project ASC;
	SELECT @query AS 'EXECUTE sp_executesql @query'
END
EXECUTE sp_executesql @query

DROP TABLE IF EXISTS #T
END
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_Employee]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_Outlook_Employee]
* DESCRIPTION:  Timesheet Outlook per Employee
	For Team Manager Timesheet review (per Employee) before Approval
	Employee summary details on project
* CREATED: 10/2021  PCHEN
MODIFICATION HISTORY
 10/22/2021 PCHEN	Add PeriodStatus concept
 10/26/2021 JOYJING	Add Filter for approved data of current period
 10/27/2021 PCHEN Refine SubmissionId logic, add SubmissionStatus output
 11/19/2021 PCHEN Further refine SubmissionID + Start/EndDate logic
 1/25/2021  PCHEN Add AccountingEntityId factor to pull Start/End Date from [TimesheetPeriod]
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_Outlook_Employee] 
	@EmployeeId INT, 
	@PeriodCode CHAR(6),  -- 'YYYYMM'
	@IsDebug CHAR(1) = 'N'
AS BEGIN
SET NOCOUNT ON

-- For Team Manager Approval for each Employee

DECLARE 
    @PeriodStatusId INT = -1,  -- Assume "Unknown", 0=future; 1=Current 2=Closed
	@SubmissionId INT = 0 , @SubmissionStatusId INT = -1,
	@StartDate DATETIME = '1/1/1900', @EndDate DATETIME = '2/2/2222'

SELECT @SubmissionId = Id, @SubmissionStatusId = StatusId FROM TimesheetSubmission S 
WHERE S.EmployeeId = @EmployeeId AND S.PeriodCode = @PeriodCode
AND StatusId <> 0 -- Not in draft mode

/* Case Analysis *
 When @SubmissionId > 0 -- Manager has already submitted/approved
 WHEN @SubmissionId = 0 -- Hours to be submmited/approved
	If Period = 'Current' OR (Previous Period is "Current" and Previous Period "SubmissionId>0")
		Get All Activities with Submission = 0 up to PeriodEndDate
		=> FromDate = '1/1/1900'; ToDate = PeriodEndDate
	If Period = 'Future' or 'Unknown' Get All Activities with Submission=0 during StartDate to EndDate
		=> FromDate = PeriodStartDate; ToDate = PeriodEndDate
 */

DECLARE @IsPrevCurrentWithSubmission bit = 0, @AccountingEntityId INT = -1

SELECT TOP 1 @AccountingEntityId = T.AccountingEntityId 
FROM Team T 
WHERE T.ManagerId = @EmployeeId
OR T.OwnerId = @EmployeeId
OR EXISTS (SELECT 1 FROM TeamEmployee TE WHERE TE.TeamId = T.Id AND TE.EmployeeId = @EmployeeId)

IF EXISTS(SELECT 1 FROM TimesheetSubmission S JOIN TimesheetPeriod P ON S.PeriodCode = P.PeriodCode
			WHERE S.EmployeeId = @EmployeeId 
			AND P.PeriodCode = CONVERT(nvarchar(6), DATEADD(MONTH, -1, CONCAT(@PeriodCode, '01')), 112) 
			AND P.AccountingEntityId = @AccountingEntityId
			AND P.StatusId = 1 AND S.StatusId <> 0) --Period=Current and Submission Not in draft mode
	SELECT @IsPrevCurrentWithSubmission = 1

SELECT
	@PeriodStatusId = StatusId,
	@StartDate = CASE WHEN (StatusId=1 OR @IsPrevCurrentWithSubmission=1) AND @SubmissionId=0 THEN '1/1/1900' ELSE StartDate END,
	@EndDate = EndDate
FROM TimesheetPeriod WHERE PeriodCode = @PeriodCode AND AccountingEntityId = @AccountingEntityId

IF (@PeriodStatusId=-1) BEGIN  
	-- If Still Unknown Period, compose defult start/end date
	SELECT @StartDate  = CONVERT(date, CONCAT(@PeriodCode, '01'))
	SELECT @EndDate = DATEADD(DAY, -1, DATEADD(MONTH, 1, @StartDate))
END

DECLARE @CurrentPeriodCode varchar(10)
SELECT top 1  @CurrentPeriodCode = PeriodCode  FROM TimesheetPeriod WHERE StatusId  = 1 AND AccountingEntityId = @AccountingEntityId;

DECLARE @tActivity TABLE(
	Id INT, EmployeeId INT, ProjectId INT, 
	ActivityId INT, ActivityDate DateTime, Hours Decimal(18,2),
	Description NVARCHAR(4000), SourceId INT, SubmissionId INT)
INSERT INTO @tActivity
SELECT Id, EmployeeId, ProjectId, 
	ActivityId, ActivityDate, Hours,
	Description, SourceId, SubmissionId
FROM TimeSheetActivity A
WHERE A.EmployeeId = @EmployeeId
AND Hours>0
AND ((@SubmissionId>0 AND SubmissionId = @SubmissionId)
	OR 
	(@SubmissionId = 0 AND ISNULL(SubmissionId, 0) = 0 AND 
	ActivityDate < DATEADD(day, 1, @EndDate) AND
	ActivityDate > @StartDate))
IF (@@ROWCOUNT=0) -- Insert a dummy activity
	INSERT INTO @tActivity (EmployeeId, Hours) VALUES(-1, 0)

IF (@IsDebug = 'Y') BEGIN  -- Debugging check point
	SELECT @AccountingEntityId AS '@AccountingEntityId',
		@PeriodCode AS '@PeriodCode', @PeriodStatusId as '@PeriodStatusId', 
		@SubmissionId as '@SubmissionId', @IsPrevCurrentWithSubmission AS '@IsPrevCurrentWithSubmission',
		@StartDate AS '@StartDate', @EndDate AS '@EndDate'
	SELECT ' ' as 'tbl@tActivity', * FROM @tActivity ORDER BY ActivityDate
END

SELECT @EmployeeId		AS '@ResourceId',
	(SELECT DisplayName FROM Employee WHERE Id = @EmployeeId) AS '@ResourceName',
	'Employee'			AS '@ResourceType',
	@StartDate			AS '@FromDate',
	@EndDate			AS '@ToDate',
	@CurrentPeriodCode  as  '@CurrentPeriodCode',
	@PeriodCode			AS '@PeriodCode',
	@PeriodStatusId		AS '@PeriodStatusId',
	@SubmissionStatusId	AS '@TimesheetStatusId',
	SUM(A.Hours)		AS '@Hours',
    (  
      SELECT 
		B.EmployeeId	AS '@ResourceId',
		(SELECT DisplayName FROM Employee WHERE Id = B.EmployeeId) AS '@ResourceName',
		'Employee'		AS '@ResourceType',
		B.ProjectId		AS '@SubjectId',
		(SELECT Name FROM Project WHERE Id = B.ProjectId) AS '@SubjectName',
		'Project'		AS '@SubjectType',
		SUM(B.Hours)		AS '@Hours'
      FROM @tActivity B WHERE EmployeeId>0
	  GROUP BY B.EmployeeId, B.ProjectId
      FOR XML PATH('Timesheet'), ROOT('ArrayOfTimesheet'), TYPE
	  ) ,
    (  
      SELECT B.Id		AS '@Id',		
		B.EmployeeId	AS '@EmployeeId',
		B.ProjectId		AS '@ProjectId',
		--(SELECT Name FROM Project WHERE Id = B.ProjectId) AS '@ProjectName',
		B.ActivityId	AS '@ActivityId',
		--(SELECT TextVal FROM ENUM WHERE Name = 'ProjectActivityId' AND KeyVal = B.ActivityId)
		--				AS '@ActivityName',
		B.ActivityDate	AS '@ActivityDate',
		B.Hours			AS '@Hours',
		B.SourceId		AS '@SourceId',
		B.SubmissionId	AS '@SubmissionId'
      FROM @tActivity B WHERE EmployeeId>0
	  ORDER BY B.ActivityDate
      FOR XML PATH('TimesheetActivity'), ROOT('ArrayOfTimesheetActivity'), TYPE
	  )  
FROM @tActivity A
FOR XML PATH('Timesheet')  

END

/* testing *
select * from employee
select * from timesheetactivity
EXEC SPU_Timesheet_Outlook_Employee @EmployeeId = 183
, @PeriodCode = '202111', @IsDebug = 'Y'

EXEC SPU_Timesheet_Outlook_Employee @EmployeeId = 183
, @PeriodCode = '202111', @IsDebug = 'Y'

-- We've set the 202110 period current, this will include all submissionid==0 activities
EXEC SPU_Timesheet_Outlook_Employee @EmployeeId = 169
, @PeriodCode = '202110', @IsDebug = 'Y'

select TE.EmployeeId, T.AccountingEntityId from TeamEmployee TE JOIN Team T on TE.TeamId = T.Id


select A.EmployeeId, SubmissionId, S.PeriodCode, sum(A.Hours) as hrs
from TimesheetActivity A LEFT JOIN TimesheetSubmission S ON SubmissionId = s.Id
GROUP BY A.EmployeeId, SubmissionId, S.PeriodCode
order by A.EmployeeId
*/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_EmployeeProject]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_Outlook_EmployeeProject]
* DESCRIPTION:  Teamsheet Outlook for Employee per Project
	Project Activities summary Details on Employee (View from Manager Approval
* CREATED: 10/2021  PCHEN
MODIFICATION HISTORY
	10/22/2021 PCHEN Added PeriodStatus Concept
	10/25/2021 JoyJing Description Field
	11/19/2021 PCHEN
		Refine logic for future period ( duplicated with SPU_Timesheet_Outlook_Employee )
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_Outlook_EmployeeProject] 
	@EmployeeId INT, 
	@ProjectId INT,
	@PeriodCode CHAR(6),  -- 'YYYYMM'
	@IsDebug CHAR(1) = 'N'
AS BEGIN
SET NOCOUNT ON

DECLARE 
    @PeriodStatusId INT = -1,  -- Assume "Unknown", 0=future; 1=Current 2=Closed
	@SubmissionId INT = 0 , @SubmissionStatusId INT = -1,
	@StartDate DATETIME = '1/1/1900', @EndDate DATETIME = '2/2/2222'

SELECT @SubmissionId = Id, @SubmissionStatusId = StatusId FROM TimesheetSubmission S 
WHERE S.EmployeeId = @EmployeeId AND S.PeriodCode = @PeriodCode
AND S.StatusId <> 0 -- not in the draft mode

/* Case Analysis *
 When @SubmissionId > 0 -- Manager has already submitted/approved
 WHEN @SubmissionId = 0 -- Hours to be submmited/approved
	If Period = 'Current' OR (Previous Period is "Current" but "SubmissionId>0")
		Get All Activities with Submission = 0 up to PeriodEndDate
		=> FromDate = '1/1/1900'; ToDate = PeriodEndDate
	If Period = 'Future' or 'Unknown' Get All Activities with Submission=0 during StartDate to EndDate
		=> FromDate = PeriodStartDate; ToDate = PeriodEndDate
 */
DECLARE @IsPrevCurrentWithSubmission bit = 0
IF EXISTS(SELECT 1 FROM TimesheetSubmission S JOIN TimesheetPeriod P ON S.PeriodCode = P.PeriodCode
			WHERE S.EmployeeId = @EmployeeId 
			AND P.PeriodCode = CONVERT(nvarchar(6), DATEADD(MONTH, -1, CONCAT(@PeriodCode, '01')), 112) 
			AND P.StatusId = 1 AND S.StatusId <> 0) --Period=Current and Submission Not in draft mode
	SELECT @IsPrevCurrentWithSubmission = 1
SELECT
	@PeriodStatusId = StatusId,
	@StartDate = CASE WHEN (StatusId=1 OR @IsPrevCurrentWithSubmission=1) AND @SubmissionId=0 THEN '1/1/1900' ELSE StartDate END,
	@EndDate = EndDate
FROM TimesheetPeriod WHERE PeriodCode = @PeriodCode

IF (@PeriodStatusId=-1) BEGIN  
	-- If Still Unknown Period, compose defult start/end date
	SELECT @StartDate  = CONVERT(date, CONCAT(@PeriodCode, '01'))
	SELECT @EndDate = DATEADD(DAY, -1, DATEADD(MONTH, 1, @StartDate))
END

DECLARE @tActivity TABLE(
	Id INT, EmployeeId INT, ProjectId INT, 
	ActivityId INT, ActivityDate DateTime, Hours Decimal(18,2),
	Description NVARCHAR(4000), SourceId INT, SubmissionId INT)
INSERT INTO @tActivity
SELECT Id, EmployeeId, ProjectId, 
	ActivityId, ActivityDate, Hours,
	Description, SourceId, SubmissionId
FROM TimeSheetActivity A
WHERE A.EmployeeId = @EmployeeId
AND A.ProjectId = @ProjectId
AND Hours>0
AND ((@SubmissionId>0 AND SubmissionId = @SubmissionId)
	OR 
	(@SubmissionId = 0 AND ISNULL(SubmissionId, 0) = 0 AND 
	 ActivityDate < DATEADD(day, 1, @EndDate) AND
	 ActivityDate > @StartDate))
IF (@@ROWCOUNT=0) -- INSERT a dummy activity
INSERT INTO @tActivity(EmployeeId, Hours) VALUES(-1,0)

IF (@IsDebug = 'Y') BEGIN -- Debug check point
	SELECT @PeriodCode AS '@PeriodCode', @PeriodStatusId as '@PeriodStatusId', @SubmissionId as '@SubmissionId', @IsPrevCurrentWithSubmission AS '@IsPrevCurrentWithSubmission',
		@StartDate AS '@StartDate', @EndDate AS '@EndDate'
	SELECT '' as '@tActivity', * FROM @tActivity
END

SELECT @EmployeeId		AS '@ResourceId',
	(SELECT DisplayName FROM Employee WHERE Id = @EmployeeId) AS '@ResourceName',
	'Employee'			AS '@ResourceType',
	@ProjectId			AS '@SubjectId',
	(SELECT [Name] FROM Project WHERE Id = @ProjectId) AS '@SubjectName',
	'Project'			AS '@SubjectType',
	@EndDate			AS '@ToDate',
	@PeriodCode			AS '@PeriodCode',
	@PeriodStatusId		AS '@PeriodStatusId',
	@SubmissionStatusId	AS '@TimesheetStatusId',
	SUM(A.Hours)		AS '@Hours',
    (  
      SELECT B.Id		AS '@Id',		
		B.EmployeeId	AS '@EmployeeId',
		B.ProjectId		AS '@ProjectId',
		--(SELECT Name FROM Project WHERE Id = B.ProjectId) AS '@ProjectName',
		B.ActivityId	AS '@ActivityId',
		(SELECT TextVal FROM ENUM WHERE Name = 'ProjectActivityId' AND KeyVal = B.ActivityId)
						AS '@ActivityName',
		B.ActivityDate	AS '@ActivityDate',
		B.Hours			AS '@Hours',
		B.SourceId		AS '@SourceId',
		B.SubmissionId	AS '@SubmissionId',
		B.Description	AS '@Description'
      FROM @tActivity B WHERE B.EmployeeId > 0
	  ORDER BY B.ActivityDate
      FOR XML PATH('TimesheetActivity'), ROOT('ArrayOfTimesheetActivity'), TYPE
	  )  
FROM @tActivity A
GROUP BY EmployeeID, ProjectId
FOR XML PATH('Timesheet')  
END

/* testing *
exec SPU_Timesheet_Outlook_EmployeeProject @EmployeeId=291,@ProjectId=1,@PeriodCode=N'202112'
 ,@IsDebug = 'Y'
exec SPU_Timesheet_Outlook_EmployeeProject @EmployeeId=291,@ProjectId=1,@PeriodCode=N'202012'
 ,@IsDebug = 'Y'


EXEC SPU_Timesheet_Outlook_EmployeeProject @EmployeeId = 169, @ProjectId = 1, 
@PeriodCode = '202110' ,@IsDebug = 'Y'

select * from timesheetactivity where employeeid = 169 and projectid = 1

*/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_EmployeeSummary]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_Outlook_EmployeeSummary]
* DESCRIPTION:  Timesheet Outlook for Employee Summary
	Employee hours summary (View from Manager Approval)
* CREATED: 11/2021  PCHEN
	Based on SPU_Timesheet_Outlook_Employee_Summary (Created By JoyJ)
	enhanced and revised
MODIFICATION HISTORY
	11/23/2021 admin role can get all the employee
	11/21/2021 PCHEN, If RequesterId is TeamManager, TeamOwner's records will be pulled as well
	1/10/2022   paulR, filter with active employee record 
	1/13/2022 PCHEN Included deleted(disabled) employee if valid TimesheetActivities are presented during the period
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_Outlook_EmployeeSummary] 
	@RequesterId INT, 
	@PeriodCode CHAR(6),  -- 'YYYYMM'
	@IsDebug CHAR(1) = 'N'
AS BEGIN
SET NOCOUNT ON

-- Base table stores the universe of Employees to be working on
DECLARE @t TABLE(EmployeeId INT, SubmissionId INT, SubmissionStatusId INT, PrevSubmissionId INT, StartDate DateTime, EndDate DATETIME)

-- Pull ALL related employees (included disabled)
INSERT INTO @t (EmployeeId)
SELECT DISTINCT E.Id FROM Employee E 
JOIN TeamEmployee TE ON E.Id = TE.EmployeeId
JOIN Team T ON T.Id = TE.TeamId
WHERE EXISTS(  -- Admin will get all employees
	SELECT 1 FROM Employee em
	JOIN EmployeeRole r ON  em.Id=r.EmployeeId
	WHERE r.RoleName IN ('Admin','TimesheetAdmin') AND em.Id=@RequesterId)
OR E.Id = @RequesterId
OR T.ManagerId = @RequesterId
OR T.OwnerId = @RequesterId
UNION
SELECT ManagerId FROM Team WHERE ManagerId = @RequesterId OR OwnerId = @RequesterId
UNION
SELECT OwnerId FROM Team WHERE ManagerId = @RequesterId OR OwnerId = @RequesterId

DECLARE @PeriodStatusId INT = -1,  -- Assume "Unknown", 0=future; 1=Current 2=Closed
	@StartDate DATETIME, @EndDate DATETIME
SELECT
	@PeriodStatusId = StatusId,
	@StartDate = StartDate,
	@EndDate = EndDate
FROM TimesheetPeriod WHERE PeriodCode = @PeriodCode

IF (@PeriodStatusId = -1) BEGIN -- Unknow Period, StartDate/EndDate = First/Last day of the month
	SELECT @StartDate  = CONVERT(date, CONCAT(@PeriodCode, '01'));
	SELECT @EndDate = DATEADD(DAY, -1, DATEADD(MONTH, 1, @StartDate));
END

/* logic explain PCHEN 11/2021 *
If SubmissionID > 0, use SubmissionId to pull Activities
If SubmissionId == 0
	If PeriodCode = 'Current' OR 
	(PeriodCode = 'Future' and has Submission from "Previous Period" -- Only can happen between Manager and Executive Approval)
		StartDate=1/1/1900, EndDate = PeriodEndDate -- To included ALL historic hours
	ELSE
		StartDate=PeriodStartDate, EndDate=PeriodEndDate
When @PeriodCode is outside of [TimesheetPeriod], PeriodStartDate = {first date of YYYYMM}, PeriodEndDate = {Last date of YYYYMM}
 */

UPDATE A SET
	SubmissionId = S.Id, 
	SubmissionStatusId = S.StatusId
FROM @t A JOIN TimesheetSubmission S ON A.EmployeeId= S.EmployeeId
WHERE S.PeriodCode = @PeriodCode
AND S.StatusId<> 0

UPDATE A SET
	PrevSubmissionId = S.Id
FROM @t A JOIN TimesheetSubmission S ON A.EmployeeId= S.EmployeeId
WHERE  S.PeriodCode = CONVERT(nvarchar(6), DATEADD(MONTH, -1, CONCAT(@PeriodCode, '01')), 112) 
AND S.StatusId<> 0

UPDATE @t SET
	EndDate = @EndDate,
	StartDate = CASE 
			WHEN @PeriodStatusId = 1 THEN '1/1/1900' -- Current Period, 
			WHEN @PeriodStatusId = 0 AND PrevSubmissionId > 0 THEN '1/1/1900' -- Future but previou period has submission
			ELSE @StartDate END

DECLARE @tActivity TABLE(
	Id INT, EmployeeId INT, ProjectId INT, 
	ActivityId INT, ActivityDate DateTime, Hours Decimal(18,2),
	SourceId INT, SubmissionId INT)
INSERT INTO @tActivity
SELECT Id, A.EmployeeId, A.ProjectId, 
	A.ActivityId, A.ActivityDate, A.Hours,
	A.SourceId, A.SubmissionId
FROM TimeSheetActivity A JOIN @t B ON A.EmployeeId = B.EmployeeId
WHERE Hours>0
AND (A.SubmissionId = B.SubmissionId
	OR 
	(ISNULL(A.SubmissionId, 0) = 0 AND
     ISNULL(B.SubmissionId, 0) = 0 AND 
     ActivityDate < DATEADD(day, 1, B.EndDate) AND
     ActivityDate > B.StartDate))
IF (@@ROWCOUNT=0) -- INSERT a dummy activity
INSERT INTO @tActivity(EmployeeId, Hours) VALUES(-1, 0)

IF (@IsDebug = 'Y') BEGIN -- Debug check point
	SELECT '' AS '@t', @PeriodCode as '@PeriodCode', @PeriodStatusId AS '@PeriodStatusId',* FROM @t ORDER BY EmployeeId
	SELECT '' as '@tActivity', * FROM @tActivity ORDER BY EmployeeId, ActivityDate, ProjectId
END

; WITH S AS (
	SELECT EmployeeId, SUM(Hours) As Hours
	FROM @tActivity
	GROUP BY EmployeeId
)
SELECT -1		AS '@ResourceId',
	'Multiple Employees' AS '@ResourceName',
	'Employee'			AS '@ResourceType',
	-1			AS '@SubjectId',
	'Employee Summary'	AS '@SubjectName',
	'Outlook'			AS '@SubjectType',
	@PeriodCode			AS '@PeriodCode',
	@StartDate			AS '@FromDate',
	@EndDate			AS '@ToDate',
	@PeriodStatusId		AS '@PeriodStatusId',
	--@SubmissionStatusId	AS '@TimesheetStatusId',
	SUM(Hours)		AS '@Hours',
    ( 
      SELECT 
		E.Id					AS '@ResourceId',
		E.DisplayName			AS '@ResourceName',
		'Employee'				AS '@ResourceType',
		T.SubmissionStatusId	AS '@TimesheetStatusId',
		ISNULL(S.Hours, 0 )		AS '@Hours'
      FROM @t T JOIN Employee E ON T.EmployeeId = E.Id
	  LEFT JOIN S ON T.EmployeeId = S.EmployeeId
	  WHERE E.IsActive = 1 OR ISNULL(S.Hours, 0 ) > 0
	  ORDER BY T.SubmissionStatusId, E.DisplayName
      FOR XML PATH('Timesheet'), ROOT('ArrayOfTimesheet'), TYPE
	  )  
FROM S
FOR XML PATH('Timesheet')  
END
/** Testing **
exec SPU_Timesheet_Outlook_EmployeeSummary @RequesterId=185,@PeriodCode=N'202112'
	, @IsDebug = 'Y'
exec SPU_Timesheet_Outlook_EmployeeSummary @RequesterId=185,@PeriodCode=N'202111'
 **/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_EmployeeTrendReport]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_Outlook_EmployeeTrendReport]
* DESCRIPTION:  Teamsheet Outlook for Employee per Project
 
* CREATED: 10/2021  JoyJing
MODIFICATION HISTORY
	 
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_Outlook_EmployeeTrendReport] 
	@EmployeeId INT, 
	@PeriodCode VARCHAR(10)
AS BEGIN
SET NOCOUNT ON
  DECLARE  @EmployeeName VARCHAR(100);
  DECLARE @tPeriodCode TABLE (PeriodCode VARCHAR(10))

  DECLARE @i INT = -11;
	WHILE ( @i <= 0)
	BEGIN
		INSERT INTO @tPeriodCode
		VALUES (CONVERT(nvarchar(6), DATEADD(MONTH, @i, CONCAT(@PeriodCode, '01')), 112))
		SET @i = @i+1;
	END

SELECT @EmployeeId		AS '@ResourceId',
	@PeriodCode			AS '@PeriodCode',
	(SELECT DisplayName FROM Employee WHERE Id = @EmployeeId) AS '@ResourceName',
	'Employee'			AS '@ResourceType',
    (
		SELECT T.PeriodCode			AS '@PeriodCode', 
			ISNULL(SUM(A.Hours), 0) AS '@Hours'
		FROM @tPeriodCode T LEFT JOIN TimesheetSubmission S ON T.PeriodCode = S.PeriodCode AND S.EmployeeId = @EmployeeId
		LEFT JOIN TimesheetActivity A ON A.SubmissionId = S.Id
		GROUP BY T.PeriodCode
		FOR XML PATH('Timesheet'), ROOT('ArrayOfTimesheet'), TYPE
	  )  
FOR XML PATH('Timesheet')  
	

  --INSERT INTO @tPeriodCode(PeriodCode)  SELECT TOP 12 PeriodCode FROM TimesheetPeriod WHERE PeriodCode<=@PeriodCode ORDER BY PeriodCode ASC
  --SET @EmployeeName=(SELECT DisplayName FROM Employee WHERE Id =@EmployeeId)
  
  --SELECT  tp.PeriodCode  as '@PeriodCode' ,
  --        ISNULL(aa.Hours,0) as '@Hours' ,
		--  @EmployeeName as '@ResourceName'
  --FROM @tPeriodCode tp  
  --LEFT JOIN (SELECT sum([Hours]) AS [Hours] ,b.PeriodCode
  --           FROM [US_TimesheetPortal].[dbo].[TimesheetActivity] a
  --           JOIN [US_TimesheetPortal].[dbo].TimesheetSubmission b ON  a.SubmissionId=b.id
  --           JOIN  @tPeriodCode p ON b.PeriodCode=p.PeriodCode
  --           WHERE   a.EmployeeId=@EmployeeId
  --           GROUP BY b.PeriodCode) aa on tp.PeriodCode=aa.PeriodCode
		--	 FOR XML PATH('Timesheet'), ROOT('ArrayOfTimesheet'), TYPE
END
 
/* Test 


EXEC SPU_Timesheet_Outlook_EmployeeTrendReport 171,  '202111'

EXEC SPU_Timesheet_Outlook_EmployeeTrendReport 169,  '202111'


*/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_ExecApprovalView]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_Outlook_ExecApprovalView]
* DESCRIPTION:  For IT Executive Approval pull header data
* CREATED: 1/2022  PCHEN
MODIFICATION HISTORY
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_Outlook_ExecApprovalView] 	
	@AccountingEntityId  int,
	@PeriodCode CHAR(6) = '' -- 'YYYYMM, if 1900/01, find active period
AS BEGIN
SET NOCOUNT ON;

-- @tTeam TeamId with its Reporting TeamId (TopMostId)
DECLARE @tTeam TABLE (Id INT, TopMostId INT)
;WITH X as (
    SELECT Id, ParentId, 0 Lvl FROM Team where AccountingEntityId=@AccountingEntityId
    UNION ALL
    SELECT X.Id, T.ParentId, Lvl+1
    FROM X JOIN Team T on X.ParentId = T.Id
	WHERE ISNULL(T.ParentId, 0) > 0 )   
INSERT INTO @tTeam
SELECT Id, CASE WHEN ParentId = 0 THEN Id ELSE ParentId END AS ParentId
FROM ( SELECT *, MAX(Lvl) OVER (PARTITION BY Id) AS [MaxLevel] 
       FROM X ) A
WHERE MaxLevel = Lvl 

if (len(@PeriodCode) = 0)
	SELECT @PeriodCode = PeriodCode FROM TimesheetPeriod WHERE AccountingEntityId = @AccountingEntityId AND StatusId=1

;WITH tHrs AS (
	SELECT TM.TopMostId AS TeamId, A.EmployeeId, SUM(Hours) as Hours
	FROM TimesheetActivity A
	JOIN TeamEmployee TE on TE.EmployeeId = A.EmployeeId
	JOIN @tTeam TM ON TE.TeamId = TM.Id
	WHERE A.Hours>0
	AND EXISTS (SELECT 1 FROM TimeSheetSubmission S 
		WHERE S.PeriodCode = @PeriodCode
		AND A.SubmissionId = S.Id)
	GROUP BY TM.TopMostId, a.EmployeeId	)

SELECT 
	@AccountingEntityId AS '@ResourceId',
	'AccountingEntity'	AS '@ResourceType',
	E.Name				AS '@ResourceName',
	P.PeriodCode		AS '@PeriodCode',
	P.StatusId			AS '@PeriodStatusId',
	p.StartDate			As '@FromDate',
	p.EndDate		    AS '@ToDate',
	(SELECT SUM(Hours) FROM tHrs)
						AS '@Hours'
FROM TimesheetPeriod P JOIN AccountingEntity E ON P.AccountingEntityId = E.Id
WHERE P.PeriodCode = @PeriodCode AND P.AccountingEntityId = @AccountingEntityId
FOR XML PATH('Timesheet')  

END

/* Test *
EXEC SPU_Timesheet_Outlook_ExecApprovalView 1, '202110'
EXEC SPU_Timesheet_Outlook_ExecApprovalView 1, '202111'
EXEC SPU_Timesheet_Outlook_ExecApprovalView 1, '202112'
*/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_ExecProjectView]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_Outlook_ExecProjectView]
* DESCRIPTION:  Timesheet Outlook for IT Executive Per AccountingEntity 
	(ALL Teams under the Entity, All Projects)
  Return a DataTable for ProjectView
* CREATED: 10/2021  PCHEN on [SPU_Timesheet_Outlook_Teams]
MODIFICATION HISTORY
- 11/08/2021 PCHEN Introduced ParentId, only report on TopMost teamID (ParentId = 0)
  eg: Parent Team 'Tx' will have two Child Teams
		Child Team 'Ta', Parent ='Tx'
		Child team 'Tb', Parent ='Tx'
  We will report on "Tx", NOT 'Ta' or 'Tb' individually
- 11/23/2021 P.RAO Added Project sorting, leave predefined on top
- 11/24/2021 PCHEN Return ALL teams
- 12/21/2021 PCHEN 
	Obsoleted "SPU_Timesheet_Outlook_Teams" and newly create this SP
	added AccountEntityId as parameter
	Obsoleted "SPU_Timesheet_Outlook_ByEntity"
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_Outlook_ExecProjectView]  
	@PeriodCode CHAR(6),  -- 'YYYYMM'
	@AccountingEntityId INT = -1,
	@IsDebug CHAR(1) = 'N'
AS BEGIN
SET NOCOUNT ON

-- @tTeam TeamId with Reporting TeamId (TopMostId)
DECLARE @tTeam TABLE (Id INT, TopMostId INT)

;WITH X as (
    SELECT Id, ParentId, 0 Lvl FROM Team WHERE AccountingEntityId = @AccountingEntityId
    UNION ALL
    SELECT T.Id, T.ParentId, Lvl+1
    FROM Team T JOIN X on T.ParentId = X.Id
	)
INSERT INTO @tTeam
SELECT Id, CASE WHEN ParentId = 0 THEN Id ELSE ParentId END AS ParentId
FROM ( SELECT *, MAX(Lvl) OVER (PARTITION BY Id) AS [MaxLevel] 
       FROM X ) A
WHERE MaxLevel = Lvl 

-- Using temp table #T for grouping
DROP TABLE IF EXISTS  #T
CREATE TABLE #T  (
	TeamID INT, Team VARCHAR(100),
	ProjectID INT, Project VARCHAR(100),
	Hours Decimal(18,2), HoursT VARCHAR(100) ,
	IsPredefined bit )	
	
;WITH C AS (
	SELECT T.TopMostId AS TeamId, A.ProjectId, SUM(Hours) as Hours
	FROM TimesheetActivity A
	JOIN TimesheetSubmission S ON A.SubmissionId = S.id 
	JOIN TeamEmployee TE on TE.EmployeeId = A.EmployeeId
	JOIN @tTeam T ON TE.TeamId = T.Id
	WHERE A.Hours>0   
	AND S.PeriodCode = @PeriodCode
	GROUP BY T.TopMostId, A.ProjectId)
INSERT INTO #T (TeamID, Team, ProjectID, Project, Hours,IsPredefined)
--SELECT T.Id, REPLACE(REPLACE(REPLACE('S'+T.DeptCode+convert(varchar(20),t.Id),' ','space'),'&','strike'),'-','underline') ,
SELECT T.Id, 'T_' + Convert(varchar(10),T.Id),
	C.ProjectId, P.Name, C.Hours,p.IsPredefined
FROM Team T 
LEFT JOIN C on T.Id = C.TeamId
LEFT JOIN Project P ON C.ProjectId = P.Id
WHERE EXISTS (SELECT 1 FROM @tTeam WHERE TopMostId = T.Id)
order  by T.DeptCode asc

IF (@@ROWCOUNT=0) -- Create a dummy record if no data
INSERT INTO #T (TeamID, Team, ProjectID, Project, Hours) 
VALUES(0, 'NoTeam', 0, 'No Project Data', 0)

UPDATE #T SET HoursT = CONVERT(varchar(10), Hours) + '::'
		+ CONVERT(VARCHAR(10), ProjectID) + '::'
		+ CONVERT(VARCHAR(10), TeamID) 

DECLARE @cols NVARCHAR(MAX) = 
STUFF((SELECT DISTINCT ',' + QUOTENAME(Team) 
    from #T 
FOR XML PATH(''), Type
).value('.', 'NVARCHAR(MAX)') ,1,1,'')

DECLARE @query  NVARCHAR(MAX) = 
N'SELECT Project, ' + @cols + N' FROM 
( SELECT Project,IsPredefined, isnull(HoursT,0) as HoursT, Team
    FROM #t 
) x
pivot 
(   MIN(HoursT)
    FOR Team IN (' + @cols + N')
) p WHERE LEN(ISNULL(Project,''''))>0 ORDER BY IsPredefined DESC, Project ASC'

IF (@IsDebug = 'Y') BEGIN -- Debugging check point
	SELECT '' AS 'Team@tTeam', * FROM @tTeam
	SELECT '' as '#T', * FROM #T order by  IsPredefined desc, Project ASC;
	SELECT @query AS 'EXECUTE sp_executesql @query'
END
EXECUTE sp_executesql @query

DROP TABLE IF EXISTS #T
END
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_ExecResourceView]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_Outlook_ExecResourceView]
* DESCRIPTION:  Teamsheet Outlook per Team per Resource
	Team summary Details on Employee
* CREATED: 10/2021  PaulR
MODIFICATION HISTORY
 10/27/2021 PCHEN finish up SP with XML output
 11/09/2021 PCHEN Introduced ParentId, report on TopMost teamID (ParentId = 0) only
  eg:	Resource 'Ra' with team 'Ta', root team ='Tx'
		Resource 'Rb' with team 'Tb', root team ='Tx'
  We will now report on "Tx" with both Ra+Rb in it, NOT by Ta or Tb individually

 12/21/2021 PaoR   Add  @EntityId parameter
 1/26/2022 PCHEN obsolete "SPU_Timesheet_Outlook_TeamResource" 
	use this new name to hold more meaningful 
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_Outlook_ExecResourceView] 	
	@AccountingEntityId  int,
	@PeriodCode CHAR(6) -- 'YYYYMM
AS BEGIN
SET NOCOUNT ON;

-- @tTeam TeamId with its Reporting TeamId (TopMostId)
DECLARE @tTeam TABLE (Id INT, TopMostId INT)
;WITH X as (
    SELECT Id, ParentId, 0 Lvl FROM Team where AccountingEntityId=@AccountingEntityId
    UNION ALL
    SELECT X.Id, T.ParentId, Lvl+1
    FROM X JOIN Team T on X.ParentId = T.Id
	WHERE ISNULL(T.ParentId, 0) > 0 )   
INSERT INTO @tTeam
SELECT Id, CASE WHEN ParentId = 0 THEN Id ELSE ParentId END AS ParentId
FROM ( SELECT *, MAX(Lvl) OVER (PARTITION BY Id) AS [MaxLevel] 
       FROM X ) A
WHERE MaxLevel = Lvl 

;WITH tResHrs AS (
	SELECT TM.TopMostId AS TeamId, A.EmployeeId, SUM(Hours) as Hours
	FROM TimesheetActivity A
	JOIN TeamEmployee TE on TE.EmployeeId = A.EmployeeId
	JOIN @tTeam TM ON TE.TeamId = TM.Id
	WHERE A.Hours>0
	AND EXISTS (SELECT 1 FROM TimeSheetSubmission S 
		WHERE S.PeriodCode = @PeriodCode
		AND A.SubmissionId = S.Id)
	GROUP BY TM.TopMostId, a.EmployeeId	)
SELECT 
	@AccountingEntityId AS '@ResourceId',
	'AccountingEntity'	AS '@ResourceType',
	E.Name				AS '@ResourceName',
	P.PeriodCode		AS '@PeriodCode',
	P.StatusId			AS '@PeriodStatusId',
	p.StartDate			As '@FromDate',
	p.EndDate		    AS '@ToDate',
	(SELECT SUM(Hours) FROM tResHrs)
						AS '@Hours',
    (  
      SELECT 
		R.EmployeeId	AS '@ResourceId',
		E.DisplayName   AS '@ResourceName',
		'Employee'		AS '@ResourceType',
		R.TeamId		AS '@SubjectId',
		(SELECT Name FROM Team WHERE Id = R.TeamId) AS '@SubjectName',
		'Team'		AS '@SubjectType',
		R.Hours		AS '@Hours'
      FROM tResHrs R JOIN Employee E ON R.EmployeeId = E.Id
	  ORDER BY R.TeamId, E.FirstName
      FOR XML PATH('Timesheet'), ROOT('ArrayOfTimesheet'), TYPE
	) 
FROM TimesheetPeriod P JOIN AccountingEntity E ON P.AccountingEntityId = E.Id
WHERE P.PeriodCode = @PeriodCode AND P.AccountingEntityId = @AccountingEntityId
FOR XML PATH('Timesheet')  

END

/* Test *
EXEC SPU_Timesheet_Outlook_ExecResourceView '202110'
*/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_Project]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_Outlook_Project]
* DESCRIPTION:  Teamsheet Outlook per Team per Resource
	Team summary Details on Employee
* CREATED: 10/2021  PaulR

MODIFICATION HISTORY
add entityId filter parameter  12/22/2021/ PaulR
***********************************************************/
CREATE    PROCEDURE [dbo].[SPU_Timesheet_Outlook_Project] 
	
	@PeriodCode CHAR(6) = NULL,  -- 'YYYYMM
	@EntityId int
	
AS BEGIN
SET NOCOUNT ON;



SELECT  A.ProjectId, p.Name as ProjectName, sum(Hours) as Hours
	FROM TimesheetActivity A
	JOIN TeamEmployee TE on TE.EmployeeId = A.EmployeeId
	JOIN Team T on Te.TeamId = T.Id
	JOIN Project p on a.ProjectId = p.Id
	WHERE A.Hours>0
	and (@EntityId =0 or T.AccountingEntityId  = @EntityId)
	AND EXISTS (SELECT 1 FROM TimeSheetSubmission S 
		WHERE S.PeriodCode = @PeriodCode
		AND S.id = A.SubmissionId)   
	GROUP BY  a.ProjectId,p.Name


END
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_Team_Export]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_Outlook_Team_Export]
* DESCRIPTION:  Timesheet Outlook Export Per Team
	Entire team timesheet should be exported. The fields should be resource, project, hours
* CREATED: 11/2021  JoyJing
MODIFICATION HISTORY
-- JoyJ export emplyee get the employee whose 
	team manager==current user and the employee is not the teamowner 
	or  
	get the employee whose team owner==current user
-- 11/30/2021 PCHEN changed output to 'ArrayOfTimesheet'
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_Outlook_Team_Export] 
	@EmployeeId INT, 
	@PeriodCode CHAR(6), -- 'YYYYMM'.
	@IsDebug CHAR(1) = 'N'
AS BEGIN
SET NOCOUNT ON

-- Base table stores the universe of Employees to be working on
DECLARE @t TABLE(EmployeeId INT, SubmissionId INT, SubmissionStatusId INT, PrevSubmissionId INT, StartDate DateTime, EndDate DATETIME)

INSERT INTO @t (EmployeeId)
SELECT DISTINCT E.Id FROM Employee E 
JOIN TeamEmployee TE ON E.Id = TE.EmployeeId
JOIN Team T ON T.Id = TE.TeamId
WHERE EXISTS(  -- Admin will get all employees
	SELECT 1 FROM Employee e
	JOIN EmployeeRole r ON  e.Id=r.EmployeeId
	WHERE r.RoleName='Admin' AND e.Id=@EmployeeId)
OR E.Id = @EmployeeId
OR T.ManagerId = @EmployeeId
OR T.OwnerId = @EmployeeId

DECLARE @PeriodStatusId INT = -1,  -- Assume "Unknown", 0=future; 1=Current 2=Closed
	@StartDate DATETIME, @EndDate DATETIME
SELECT
	@PeriodStatusId = StatusId,
	@StartDate = StartDate,
	@EndDate = EndDate
FROM TimesheetPeriod WHERE PeriodCode = @PeriodCode

IF (@PeriodStatusId = -1) BEGIN -- Unknow Period, StartDate/EndDate = First/Last day of the month
	SELECT @StartDate  = CONVERT(date, CONCAT(@PeriodCode, '01'));
	SELECT @EndDate = DATEADD(DAY, -1, DATEADD(MONTH, 1, @StartDate));
END

/* logic explain PCHEN 11/2021 *
If SubmissionID > 0, use SubmissionId to pull Activities
If SubmissionId == 0
	If PeriodCode = 'Current' OR (PeriodCode = 'Future' and has Submission from "Previous Period")
		StartDate=1/1/1900, EndDate = PeriodEndDate
	ELSE
		StartDate=PeriodStartDate, EndDate=PeriodEndDate
When @PeriodCode is outside of [TimesheetPeriod], PeriodStartDate = {first date of YYYYMM}, PeriodEndDate = {Last date of YYYYMM}
 */

UPDATE T SET
	SubmissionId = S.Id, 
	SubmissionStatusId = S.StatusId
FROM @t T JOIN TimesheetSubmission S ON T.EmployeeId= S.EmployeeId
WHERE S.PeriodCode = @PeriodCode
AND S.StatusId<> 0

UPDATE T SET
	PrevSubmissionId = S.Id
FROM @t T JOIN TimesheetSubmission S ON T.EmployeeId= S.EmployeeId
WHERE  S.PeriodCode = CONVERT(nvarchar(6), DATEADD(MONTH, -1, CONCAT(@PeriodCode, '01')), 112) 
AND S.StatusId<> 0

UPDATE @t SET
	EndDate = @EndDate,
	StartDate = CASE 
			WHEN @PeriodStatusId = 1 THEN '1/1/1900' -- Current Period, 
			WHEN @PeriodStatusId = 0 AND PrevSubmissionId > 0 THEN '1/1/1900' -- Future but previou period has submission
			ELSE @StartDate END

DECLARE @tActivity TABLE(
	Id INT, EmployeeId INT, ProjectId INT, 
	ActivityId INT, ActivityDate DateTime, Hours Decimal(18,2),
	SourceId INT, SubmissionId INT)
INSERT INTO @tActivity
SELECT Id, A.EmployeeId, A.ProjectId, 
	A.ActivityId, A.ActivityDate, A.Hours,
	A.SourceId, A.SubmissionId
FROM TimeSheetActivity A JOIN @t B ON A.EmployeeId = B.EmployeeId
WHERE Hours>0
AND (A.SubmissionId = B.SubmissionId
	OR 
	(ISNULL(A.SubmissionId, 0) = 0 AND
     ISNULL(B.SubmissionId, 0) = 0 AND 
     ActivityDate < DATEADD(day, 1, B.EndDate) AND
     ActivityDate > B.StartDate))
IF (@@ROWCOUNT=0) -- INSERT a dummy activity
INSERT INTO @tActivity(EmployeeId, Hours) VALUES(-1, 0)

IF (@IsDebug = 'Y') BEGIN -- Debugging check point
	SELECT '' AS '@t', @PeriodCode as '@PeriodCode', @PeriodStatusId AS '@PeriodStatusId',* FROM @t ORDER BY EmployeeId
	SELECT '' as '@tActivity', * FROM @tActivity ORDER BY EmployeeId, ActivityDate, ProjectId
END

; WITH S AS (
	SELECT EmployeeId,ProjectId, SUM(Hours) As Hours
	FROM @tActivity
	GROUP BY EmployeeId,ProjectId
)
SELECT 
	E.Id					AS '@ResourceId',
	E.DisplayName			AS '@ResourceName',
	'Employee'				AS '@ResourceType',
	T.SubmissionStatusId	AS '@TimesheetStatusId',
	S.ProjectId		AS '@SubjectId',
	(SELECT Name FROM Project WHERE Id = S.ProjectId) AS '@SubjectName',
	'Project'		AS '@SubjectType',
	ISNULL(S.Hours, 0 )		AS '@Hours'
    FROM @t T JOIN Employee E ON T.EmployeeId = E.Id AND E.IsActive = 1
	LEFT JOIN S ON T.EmployeeId = S.EmployeeId
	ORDER BY T.SubmissionStatusId, E.DisplayName
    FOR XML PATH('Timesheet'), ROOT('ArrayOfTimesheet'), TYPE
END
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_TeamProject]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_Outlook_TeamProject]
* DESCRIPTION:  Teamsheet Outlook per Team per Project
	Team summary Details on Employee
* CREATED: 10/2021  PCHEN
MODIFICATION HISTORY
 11/09/2021 PCHEN Introduced ParentId, passed a teamID, needs to find all resources from child teams too
  eg:	Resource 'Ra' with team 'Ta', root team ='Tx'
  When 'Tx' is queried, 'Ra' will be included
12/22/2022  PaoR  add @entityid parameter
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_Outlook_TeamProject] 
	@TeamId INT, 
	@ProjectId INT,
	@PeriodCode CHAR(6),  -- 'YYYYMM'
	@EntityId int,
	@IsDebug CHAR(1) = 'N'
AS BEGIN
SET NOCOUNT ON

-- @tTeam all team IDs include child
DECLARE @tTeam TABLE (Id INT)
;WITH X as (
    SELECT Id, ParentId FROM Team WHERE Id = @TeamId and (@EntityId =0 or AccountingEntityId = @EntityId)
    UNION ALL
	SELECT T.Id, T.ParentId 
	FROM Team T JOIN X ON T.ParentId = X.Id)
INSERT INTO @tTeam SELECT ID FROM X

-- @tHrs Employee Hours
DECLARE @tHrs TABLE (EmployeeId INT,Hrs DECIMAL(18,2))
INSERT INTO @tHrs
SELECT A.EmployeeId, SUM(A.Hours)  -- SELECT TE.TeamId,  A.*
FROM TimeSheetActivity A
JOIN TeamEmployee TE ON A.EmployeeId = TE.EmployeeId
JOIN @tTeam T ON T.Id = TE.TeamId
WHERE A.Hours > 0
AND A.ProjectId = @ProjectId
AND EXISTS(
	SELECT 1 FROM TimeSheetSubmission S 
	WHERE A.SubmissionId = S.Id 
	AND PeriodCode = @PeriodCode)
GROUP BY A.EmployeeId

IF (@IsDebug = 'Y') 
BEGIN  
	SELECT '' as '@tTeam', * FROM @tTeam
	SELECT '' as 'TimeSheetActivity', TE.TeamId,  A.*
	FROM TimeSheetActivity A
	JOIN TeamEmployee TE ON A.EmployeeId = TE.EmployeeId
	JOIN @tTeam T ON T.Id = TE.TeamId
	WHERE A.ProjectId = @ProjectId
	AND EXISTS(
		SELECT 1 FROM TimeSheetSubmission S 
		WHERE A.SubmissionId = S.Id 
		AND PeriodCode = @PeriodCode
		)
	SELECT '' as '@tHrs', * FROM @tHrs	
	SELECT '' AS '@tHrs Sum()', sum(hrs) as Hrs FROM @tHrs
END

SELECT @TeamId		AS '@ResourceId',
	(SELECT Name FROM Team WHERE Id = @TeamId) AS '@ResourceName',
	'Team'			AS '@ResourceType',
	@ProjectId		AS '@SubjectId',
	(SELECT [Name] FROM Project WHERE Id = @ProjectId) AS '@SubjectName',
	'Project'		AS '@SubjectType',
	P.StartDate		AS '@FromDate',
	P.EndDate		AS '@ToDate',
	P.StatusId		AS '@PeriodStatusId',
	P.PeriodCode	AS '@PeriodCode',
	(SELECT SUM(Hrs) FROM @tHrs) AS '@Hours',
    (  
      SELECT 
		B.EmployeeId	AS '@ResourceId',
		E.DisplayName   AS '@ResourceName',
		'Employee'		AS '@ResourceType',
		B.Hrs			AS '@Hours'
      FROM @tHrs B JOIN Employee E ON B.EmployeeId = E.Id
	  ORDER BY E.FirstName
      FOR XML PATH('Timesheet'), ROOT('ArrayOfTimesheet'), TYPE
	  )  
FROM TimesheetPeriod P WHERE p.PeriodCode = @PeriodCode
FOR XML PATH('Timesheet')  
END

/* testing *
EXEC SPU_Timesheet_Outlook_TeamProject @TeamID = 9, @ProjectId = 43, @PeriodCode = '202111'
	, @IsDebug = 'Y'
EXEC SPU_Timesheet_Outlook_TeamProject @TeamID = 12, @ProjectId = 43, @PeriodCode = '202111'
	, @IsDebug = 'Y'
*/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_TeamResource]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_Outlook_TeamResource]
* DESCRIPTION:  Teamsheet Outlook per Team per Resource
	Team summary Details on Employee
* CREATED: 10/2021  PaulR
MODIFICATION HISTORY
 10/27/2021 PCHEN finish up SP with XML output
 11/09/2021 PCHEN Introduced ParentId, report on TopMost teamID (ParentId = 0) only
  eg:	Resource 'Ra' with team 'Ta', root team ='Tx'
		Resource 'Rb' with team 'Tb', root team ='Tx'
  We will now report on "Tx" with both Ra+Rb in it, NOT by Ta or Tb individually

  12/21/2021 PaoR   Add  @EntityId parameter
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_Outlook_TeamResource] 	
	@PeriodCode CHAR(6) , -- 'YYYYMM	
	@EntityId  int
AS BEGIN
SET NOCOUNT ON;

-- @tTeam TeamId with its Reporting TeamId (TopMostId)
DECLARE @tTeam TABLE (Id INT, TopMostId INT)
;WITH X as (
    SELECT Id, ParentId, 0 Lvl FROM Team where @EntityId =0 or AccountingEntityId=@EntityId
    UNION ALL
    SELECT X.Id, T.ParentId, Lvl+1
    FROM X JOIN Team T on X.ParentId = T.Id
	WHERE ISNULL(T.ParentId, 0) > 0 )   
INSERT INTO @tTeam
SELECT Id, CASE WHEN ParentId = 0 THEN Id ELSE ParentId END AS ParentId
FROM ( SELECT *, MAX(Lvl) OVER (PARTITION BY Id) AS [MaxLevel] 
       FROM X ) A
WHERE MaxLevel = Lvl 

;WITH tResHrs AS (
	SELECT TM.TopMostId AS TeamId, A.EmployeeId, SUM(Hours) as Hours
	FROM TimesheetActivity A
	JOIN TeamEmployee TE on TE.EmployeeId = A.EmployeeId
	JOIN @tTeam TM ON TE.TeamId = TM.Id
	WHERE A.Hours>0
	AND EXISTS (SELECT 1 FROM TimeSheetSubmission S 
		WHERE S.PeriodCode = @PeriodCode
		AND A.SubmissionId = S.Id)
	GROUP BY TM.TopMostId, a.EmployeeId	)
SELECT
   ( SELECT top 1  PeriodCode  FROM TimesheetPeriod WHERE StatusId  = 1) as '@CurrentPeriodCode',
	P.PeriodCode		AS '@PeriodCode',
	P.StatusId			AS '@PeriodStatusId',
	p.StartDate			As '@FromDate',
	p.EndDate		    AS '@ToDate',
	(SELECT SUM(Hours) FROM tResHrs)
						AS '@Hours',
    (  
      SELECT 
		R.EmployeeId	AS '@ResourceId',
		E.DisplayName   AS '@ResourceName',
		'Employee'		AS '@ResourceType',
		R.TeamId		AS '@SubjectId',
		(SELECT Name FROM Team WHERE Id = R.TeamId) AS '@SubjectName',
		'Team'		AS '@SubjectType',
		R.Hours		AS '@Hours'
      FROM tResHrs R JOIN Employee E ON R.EmployeeId = E.Id
	  ORDER BY R.TeamId, E.FirstName
      FOR XML PATH('Timesheet'), ROOT('ArrayOfTimesheet'), TYPE
	) 
FROM TimesheetPeriod P WHERE P.PeriodCode = @PeriodCode
FOR XML PATH('Timesheet')  

END

/* Test *
EXEC SPU_Timesheet_Outlook_TeamResource '202110'
*/
GO
/****** Object:  StoredProcedure [dbo].[SPU_Timesheet_Outlook_Teams]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Timesheet_Outlook_Teams]
* DESCRIPTION:  Teamsheet Outlook for IT Executive for ALL Teams All Projects
  Return a DataTable
* CREATED: 10/2021  PCHEN
MODIFICATION HISTORY
- 11/08/2021 PCHEN Introduced ParentId, only report on TopMost teamID (ParentId = 0)
  eg: Parent Team 'Tx' will have two Child Teams
		Child Team 'Ta', Parent ='Tx'
		Child team 'Tb', Parent ='Tx'
  We will report on "Tx", NOT 'Ta' or 'Tb' individually
- 11/23/2021 P.RAO Added Project sorting, leave predefined on top
- 11/24/2021 PCHEN Return ALL teams

-- 12/21/2021 P.Rao  Add team sordting by  deptcode asc
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Timesheet_Outlook_Teams]  
	@PeriodCode CHAR(6),  -- 'YYYYMM'
	@EntityId   int, --- '1'
	@IsDebug CHAR(1) = 'N'
AS BEGIN
SET NOCOUNT ON

-- @tTeam TeamId with Reporting TeamId (TopMostId)
DECLARE @tTeam TABLE (Id INT, TopMostId INT)
;WITH X as (
    SELECT Id, ParentId, 0 Lvl FROM Team where @EntityId = 0 or  AccountingEntityId = @EntityId 
    UNION ALL
    SELECT X.Id, T.ParentId, Lvl+1
    FROM X JOIN Team T on X.ParentId = T.Id
	WHERE ISNULL(T.ParentId, 0) > 0 )   
INSERT INTO @tTeam
SELECT Id, CASE WHEN ParentId = 0 THEN Id ELSE ParentId END AS ParentId
FROM ( SELECT *, MAX(Lvl) OVER (PARTITION BY Id) AS [MaxLevel] 
       FROM X ) A
WHERE MaxLevel = Lvl 

-- Using temp table #T for grouping
DROP TABLE IF EXISTS  #T
CREATE TABLE #T  (
	TeamID INT, Team VARCHAR(100),
	ProjectID INT, Project VARCHAR(100),
	Hours Decimal(18,2), HoursT VARCHAR(100) ,
	IsPredefined bit )	

;WITH C AS (
	SELECT T.TopMostId AS TeamId, A.ProjectId, SUM(Hours) as Hours
	FROM TimesheetActivity A
	JOIN TimesheetSubmission S ON A.SubmissionId = S.id 
	JOIN TeamEmployee TE on TE.EmployeeId = A.EmployeeId
	JOIN @tTeam T ON TE.TeamId = T.Id
	WHERE A.Hours>0   
	AND S.PeriodCode = @PeriodCode
	GROUP BY T.TopMostId, A.ProjectId)
INSERT INTO #T (TeamID, Team, ProjectID, Project, Hours,IsPredefined)
SELECT T.Id, REPLACE(REPLACE(REPLACE('S'+T.DeptCode+convert(varchar(20),t.Id),' ','space'),'&','strike'),'-','underline') ,
	C.ProjectId, P.Name, C.Hours,p.IsPredefined
FROM Team T 
LEFT JOIN C on T.Id = C.TeamId
LEFT JOIN Project P ON C.ProjectId = P.Id
WHERE EXISTS (SELECT 1 FROM @tTeam WHERE TopMostId = T.Id)
order  by T.DeptCode asc

IF (@@ROWCOUNT=0) -- Create a dummy record if no data
INSERT INTO #T (TeamID, Team, ProjectID, Project, Hours) 
VALUES(0, 'NoTeam', 0, 'No Project Data', 0)

UPDATE #T SET HoursT = CONVERT(varchar(10), Hours) + '::'
		+ CONVERT(VARCHAR(10), ProjectID) + '::'
		+ CONVERT(VARCHAR(10), TeamID) 


DECLARE @cols NVARCHAR(MAX) = 
STUFF((SELECT DISTINCT ',' + QUOTENAME(Team) 
    from #T 
FOR XML PATH(''), Type
).value('.', 'NVARCHAR(MAX)') ,1,1,'')



DECLARE @query  NVARCHAR(MAX) = 
N'SELECT Project, ' + @cols + N' FROM 
( SELECT Project,IsPredefined, isnull(HoursT,0) as HoursT, Team
    FROM #t 
) x
pivot 
(   MIN(HoursT)
    FOR Team IN (' + @cols + N')
) p WHERE LEN(ISNULL(Project,''''))>0 ORDER BY IsPredefined DESC, Project ASC'

IF (@IsDebug = 'Y') BEGIN -- Debugging check point
	SELECT '' AS 'Team@tTeam', * FROM @tTeam
	SELECT '' as '#T', * FROM #T order by  IsPredefined desc, Project ASC;
	SELECT @query AS 'EXECUTE sp_executesql @query'
END
EXECUTE sp_executesql @query

DROP TABLE IF EXISTS #T
END
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetAccounting_FindByCriteria]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_TimesheetAccounting_FindByCriteria]
* DESCRIPTION:  
* CREATED: 10/27/2021  Dino Liu
MODIFICATION HISTORY
Dino 11/19/2021 query deptCode from team rather than employee 
PCHEN 12/16/2021 'RequestBy' is now Free-Text, don't join with [Employee]
Dino 12/21/2021 Adding accounting eneity
PCHEN 1/19/2022 Add grouping per Resource per Project Per Activity
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_TimesheetAccounting_FindByCriteria] 
	@PeriodCode VARCHAR(10) = NULL,
	@EntitiesID VARCHAR(500) = ''
AS
SET NOCOUNT ON

;WITH tBASE AS (
   SELECT TA.EmployeeId, TA.ProjectId, TA.ActivityId, SUM(TA.Hours) as Hours 
   FROM TimesheetActivity TA JOIN TimesheetSubmission S ON S.Id = TA.SubmissionId
   WHERE S.PeriodCode= @PeriodCode AND S.StatusId=2
   AND TA.EmployeeId IN (
		SELECT TE.EmployeeId FROM Team T JOIN TeamEmployee TE ON T.Id = TE.TeamId
		WHERE T.AccountingEntityId in (SELECT token FROM dbo.fn_DelimitedStringToTable(@EntitiesID, ',')))
   GROUP BY TA.EmployeeId, TA.ProjectId, TA.ActivityId
)
SELECT 
	ROW_NUMBER() OVER (ORDER BY E.DisplayName) AS '@Id',
	p.Id '@ProjectID',
	P.RequestBy as '@ProjectManager',
	p.Name '@ProjectName',
	N1.TextVal AS '@Activity',
	p.ProjectNo '@Number',
	N2.TextVal AS '@ProjectType', 
	'??{{Do we need it}}??' AS '@Description',
	B.Hours		AS '@Hours',
	B.EmployeeId '@ResourceID',
	E.DisplayName '@ResourceName',
	E.UserID '@UserID',
	(SELECT DisplayName FROM Employee WHERE Id = E.ManagerID) AS '@ResourceManager',
	'??{{status.TextVal}}??' AS  '@Status',
	case when (select top 1 keyval from Enum where Id = N2.ParentId) = 2 then 1 else 0 end '@ProjectTypeCap',
	case when (select top 1 keyval from Enum where Id = N1.ParentId) = 2 then 1 else 0 end '@PhaseTypeCap',
	E.DeptCode	AS '@Department',
	E.CountryCode '@Country',
	E.JobGradeId '@PayLevel'
FROM tBase B
JOIN Project P ON B.ProjectId = P.Id
JOIN Employee E ON B.EmployeeId = E.Id
JOIN Enum N1 ON N1.Name = 'ProjectActivityId' AND B.ActivityId = N1.KeyVal   -- ProjectActivity == ProjectPhase
JOIN Enum N2 ON N2.Name = 'ProjectTypeId' AND P.TypeId = N2.KeyVal 		-- ProjectType
ORDER BY P.IsPredefined, P.Name, E.DisplayName
FOR XML PATH('TimeSheetAccounting') , ROOT('ArrayOfTimeSheetAccounting'), TYPE

GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_Delete]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_TimesheetActivity_Delete]
* DESCRIPTION:  
	Delete [TimesheetActivity] by Id
* CREATED: 10/2021  PCHEN
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_TimesheetActivity_Delete] 
	@Id INT 
AS BEGIN
    IF EXISTS(SELECT 1 FROM TimesheetActivity WHERE Id=@Id AND DATEDIFF(D,ActivityDate,GETDATE())=0)
	BEGIN
	DECLARE @ProjectId INT,@ActivityId INT,@EmployeeId INT
	SELECT @ProjectId=ProjectId,@ActivityId=ActivityId,@EmployeeId=EmployeeId  FROM TimesheetActivity WHERE Id=@Id
	UPDATE EmployeeActivityMap
	Set IsActive=0
	WHERE EmployeeId=@EmployeeId AND ProjectId=@ProjectId AND ActivityId=@ActivityId
	END
	DELETE FROM TimeSheetActivity WHERE Id = @Id
END
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_Delete_Import]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_Delete_ImportTimeSheet]
DESCRIPTION: delete timesheet import data. 
* CREATED: [11/23/2020]
* BY: [Joy.Jing] 
MODIFICATION HISTORY
 
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_TimesheetActivity_Delete_Import] 
	@UserName Varchar(50)
AS BEGIN
  DELETE
  FROM TimesheetActivity
  WHERE SubmissionId IS NULL
		AND SourceId=2
		AND CreateBy=@UserName
END
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_Find]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_TimesheetActivity_Find]
* DESCRIPTION:  
* CREATED: 10/2021  JoyJing
MODIFICATION HISTORY
* PCHEN Reimplement based on new "TimeSheetActivity" Business Entity
* add monthly data search
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_TimesheetActivity_Find] 
	@JsonTokens NVARCHAR(1000) = NULL
AS
SET NOCOUNT ON

BEGIN -- Define Searching criteria tokens, This needs to be adjusted according to application need
 DECLARE 
 -- PCHEN 10/15/2021 Note: As of this date, only 3 paramenters are expected
		@employeeid Int = NULL,		-- by employeeid
		@fromdate DATETIME = NULL,
		@todate DATETIME = NULL,
		@isMonth INT = 0
END

IF (ISJSON(@JsonTokens)>0)
BEGIN
	DECLARE @tokens TABLE (
		Name nvarchar(4000),  Value nvarchar(max),  Type tinyint)

	INSERT INTO @tokens (Name, Value, Type)
		SELECT * FROM OPENJSON(@JsonTokens)

	SELECT @employeeId = Value from @tokens WHERE Name = 'employeeid'
	SELECT @fromdate = Value from @tokens WHERE Name = 'fromdate'
	SELECT @todate = Value from @tokens WHERE Name = 'todate'
	SELECT @isMonth = Value from @tokens WHERE Name = 'isMonth'
	SELECt @todate = ISNULL(@todate, @fromdate) -- set to fromdate if todate not present
END

BEGIN  -- Get XML
IF(@isMonth=0)
BEGIN
SELECT 
	   S.Id				AS '@Id',
	   S.EmployeeId		AS '@EmployeeId',
	   S.ProjectId		AS '@ProjectId',
	   (SELECT Name	FROM Project P WHERE P.Id = s.ProjectId
			)			AS '@ProjectName',
	   S.ActivityId		AS '@ActivityId',
	   ( SELECT TextVal FROM Enum WHERE Name = 'ProjectActivityId'
			AND KeyVal = S.ActivityId)  AS '@ActivityName',
	   S.ActivityDate	AS '@ActivityDate',
	   S.Hours			AS '@Hours',
	   S.Description	AS '@Description',
	   S.SourceId		AS '@SourceId',
	   S.SubmissionId	AS '@SubmissionId',
	   S.CreateBy		AS '@CreateBy',
	   S.CreateDate		AS '@CreateDate',
	   S.UpdateBy		AS '@UpdateBy',
	   S.UpdateDate		AS '@UpdateDate'
	 FROM TimeSheetActivity S 
	 WHERE S.EmployeeId = @employeeid
	 AND (@fromdate < DATEADD(DAY, 1, S.ActivityDate))
	 AND (@todate > DATEADD(DAY, -1, S.ActivityDate))
FOR XML PATH('TimesheetActivity') , ROOT('ArrayOfTimesheetActivity'), TYPE
END
ELSE
BEGIN
SELECT 
	   S.EmployeeId  AS '@EmployeeId',	 
	   SUM(S.Hours) AS '@Hours',		 
	   CONVERT(VARCHAR(10), S.ActivityDate,20) AS '@ActivityDate'	 
	 FROM TimeSheetActivity S 
	 WHERE S.EmployeeId = @employeeid
	 AND (@fromdate < DATEADD(DAY, 1, S.ActivityDate))
	 AND (@todate > DATEADD(DAY, -1, S.ActivityDate))
	 GROUP BY CONVERT(VARCHAR(10), S.ActivityDate,20) ,EmployeeId
	 FOR XML PATH('TimesheetActivity') , ROOT('ArrayOfTimesheetActivity'), TYPE
END
END

/*** Testing ***
exec SPU_TimesheetActivity_Find  '{"employeeid":171}'
exec SPU_TimesheetActivity_Find @JsonTokens=N'{"employeeid":171,"fromdate":"2021-10-01T00:00:00"}'
exec SPU_TimesheetActivity_Find @JsonTokens=N'{"employeeid":171,"fromdate":"2021-10-01T00:00:00","todate":"2021-11-01T00:00:00"}'
select * from TimesheetActivity
***/
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimeSheetActivity_Find_Daily]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_TimeSheetActivity_Find_Daily]
* DESCRIPTION:  
	Get [Employee] XML record based on EmployeeId and ActivityDate 
* CREATED: 10/2021  JoyJing
MODIFICATION HISTORY
* 12/13/2021 PCHEN changed the logic as :
	If for the date activities exists, take them from [TimesheetActivity]
	if not exists, take it from [EmployeeActivityMap]
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_TimeSheetActivity_Find_Daily] 
	@JsonTokens NVARCHAR(1000) = NULL
AS
SET NOCOUNT ON

BEGIN -- Define Searching criteria tokens, This needs to be adjusted according to application need
 DECLARE @employeeId Int = NULL,
		 @activityDate DATETIME = NULL
		END
		IF (ISJSON(@JsonTokens)>0)
BEGIN	
 
	DECLARE @tokens TABLE (
		Name nvarchar(4000),  Value nvarchar(max),  Type tinyint)

	INSERT INTO @tokens (Name, Value, Type)
		SELECT * FROM OPENJSON(@JsonTokens)

	SELECT @employeeId = value from @tokens WHERE name = 'EmployeeId'
	SELECT @activityDate = value from @tokens WHERE name = 'ActivityDate'
END
BEGIN
--DECLARE @count int;
--SELECT @count=count(1) FROM TimeSheetActivity WHERE EmployeeId=@employeeId AND ActivityDate=@activityDate
--if(@count>0 OR DATEDIFF(D,@activityDate,GETUTCDATE())>0)  -- for pastby date,only take the timesheet data

IF EXISTS(SELECT 1 FROM TimeSheetActivity WHERE EmployeeId=@employeeId AND ActivityDate=@activityDate)
BEGIN
SELECT 
   T.Id				AS '@Id',
   T.EmployeeId		AS '@EmployeeId',
   T.ProjectId		AS '@ProjectId',
   T.ActivityId		AS '@ActivityId',
   T.ActivityDate	AS '@ActivityDate',
   T.Hours			AS '@Hours',
   T.Description	AS '@Description',
   T.SourceId		AS '@SourceId',
   T.SubmissionId	AS '@SubmissionId',
   T.CreateBy		AS '@CreateBy',
   T.CreateDate		AS '@CreateDate',
   T.UpdateBy		AS '@UpdateBy',
   T.UpdateDate		AS '@UpdateDate', 
   1 AS '@IsTimeSheet', 
  (SELECT Name	FROM Project P WHERE P.Id = T.ProjectId
			)			AS '@ProjectName',
	( SELECT TextVal FROM Enum WHERE Name = 'ProjectActivityId'
			AND KeyVal = T.ActivityId)  AS '@ActivityName'
FROM TimeSheetActivity T
WHERE T.EmployeeId = @employeeId AND ActivityDate=@activityDate
FOR XML PATH('TimesheetActivity') , ROOT('ArrayOfTimesheetActivity'), TYPE
END
ELSE
BEGIN
--for current or future day without timsheet date,get the map cached data
SELECT  T.Id		AS '@Id',
   T.EmployeeId		AS '@EmployeeId',
   T.ProjectId		AS '@ProjectId',
   T.ActivityId		AS '@ActivityId',
   @activityDate	AS '@ActivityDate',
   0			    AS '@Hours',
   ''	            AS '@Description',
   NULL		        AS '@SourceId',
   NULL	            AS '@SubmissionId',
   T.CreateBy		AS '@CreateBy',
   T.CreateDate		AS '@CreateDate',
   T.UpdateBy		AS '@UpdateBy',
   T.UpdateDate		AS '@UpdateDate',  
   0 AS '@IsTimeSheet', 
  (SELECT Name	FROM Project P WHERE P.Id = T.ProjectId
			)			AS '@ProjectName',
	( SELECT TextVal FROM Enum WHERE Name = 'ProjectActivityId'
			AND KeyVal = T.ActivityId)  AS '@ActivityName'
	FROM EmployeeActivityMap T WHERE EmployeeId=@employeeId AND IsActive=1
	FOR XML PATH('TimesheetActivity') , ROOT('ArrayOfTimesheetActivity'), TYPE
END
END
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_FindByAccount]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_TimesheetActivity_FindByAccount]
* DESCRIPTION:  Timesheet search for account user
* CREATED: 12/2021  JoyJing
MODIFICATION HISTORYrch
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_TimesheetActivity_FindByAccount] 
	@JsonTokens NVARCHAR(1000) = NULL
AS
SET NOCOUNT ON

BEGIN -- Define Searching criteria tokens, This needs to be adjusted according to application need
 DECLARE 
		@periodcode VARCHAR(10) = NULL
END

IF (ISJSON(@JsonTokens)>0)
BEGIN
	DECLARE @tokens TABLE (
		Name nvarchar(4000),  Value nvarchar(max),  Type tinyint)

	INSERT INTO @tokens (Name, Value, Type)
		SELECT * FROM OPENJSON(@JsonTokens)

	SELECT @periodcode = Value from @tokens WHERE Name = 'periodcode'
END

BEGIN  -- Get XML
SELECT 
	   S.Id				AS '@Id',
	   S.EmployeeId		AS '@EmployeeId',
	   (SELECT DisplayName FROM Employee WHERE Id = S.EmployeeId) AS '@EmployeeName',
	  	 (SELECT ME.DisplayName From Employee ME  
    JOIN Team T ON ME.Id=T.ManagerId
	 JOIN TeamEmployee TE ON T.Id=TE.TeamId where TE.EmployeeId=s.EmployeeId AND TE.IsActive=1 ) AS '@ManagerName',
	   S.ProjectId		AS '@ProjectId',
	   (SELECT TextVal FROM Enum WHERE Name = 'ProjectActivityId'
			AND KeyVal = S.ActivityId)  AS '@ActivityName',
	   S.ActivityId		AS '@ActivityId',
	   S.ActivityDate	AS '@ActivityDate',
	   S.Hours			AS '@Hours',
	   S.Description	AS '@Description',
	   S.SourceId		AS '@SourceId',
	   S.SubmissionId	AS '@SubmissionId',
	   S.CreateBy		AS '@CreateBy',
	   S.CreateDate		AS '@CreateDate',
	   S.UpdateBy		AS '@UpdateBy',
	   S.UpdateDate		AS '@UpdateDate',
	    ( SELECT p.[Id] AS '@Id',
	p.[Name] AS '@Name',
	p.[Description] AS '@Description',
	p.[TypeId] AS '@TypeId',
	(SELECT TextVal From Enum em WHERE em.Name = 'ProjectTypeId' AND em.KeyVal = P.TypeId) AS '@Type',
	p.[StartDate] AS '@StartDate',
	p.[EndDate] AS '@EndDate',
	p.[ProdDate] AS '@ProdDate',
	p.[EstHrs] AS '@EstHrs',
	P.ProjectNo AS '@ProjectNo',
	p.[PIRNum] AS '@PIRNum',
	p.[CountryCode] AS '@CountryCode',
	p.[RequestBy] AS '@RequestBy',
	p.[StatusId] AS '@StatusId',
	p.[StatusDate] AS '@StatusDate',
	p.[IsPredefined] AS '@IsPredefined',
	p.[UpdateDate] AS '@UpdateDate',
	p.[UpdateBy] AS '@UpdateBy',
	p.[CreateBy] AS '@CreateBy',
	p.[CreateDate] AS '@CreateDate',
	(
		SELECT 
			em.KeyVal AS '@KeyVal', 
			em.TextVal AS '@TextVal',
			em.Description AS '@Description',
			pa.CreateBy  AS '@CreateBy',
			pa.CreateDate	AS '@CreateDate',
			pa.UpdateBy	AS '@UpdateBy',
			pa.UpdateDate	AS '@UpdateDate'
		FROM ProjectActivity pa
		JOIN Enum em on pa.ActivityId = em.KeyVal AND em.Name = 'ProjectActivityId'
		WHERE pa.ProjectId = p.Id AND pa.IsActive=1
		FOR XML PATH('Setting'), ROOT ('ArrayOfActivity')  ,Type
	)
FROM Project P
WHERE   P.Id =S.ProjectId  
      FOR XML PATH('Project'), TYPE  
       )
	 FROM TimeSheetActivity S 
	 JOIN TimesheetSubmission TS ON S.SubmissionId=TS.Id
	 WHERE TS.PeriodCode=@periodcode AND TS.StatusId=2

FOR XML PATH('TimesheetActivity') , ROOT('ArrayOfTimesheetActivity'), TYPE
END
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_Get]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_TimesheetActivity_Get]
* DESCRIPTION:  
	Get [TimesheetActivity] single record in XML form
* CREATED: 10/2021  PCHEN
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_TimesheetActivity_Get] 
	@Id INT 
AS BEGIN

SELECT 	   
	S.Id				AS '@Id',
	S.EmployeeId		AS '@EmployeeId',
	S.ProjectId			AS '@ProjectId',
	(SELECT Name	FROM Project P WHERE P.Id = s.ProjectId
		)				AS '@ProjectName',
	S.ActivityId		AS '@ActivityId',
	( SELECT TextVal FROM Enum WHERE Name = 'ProjectActivityId'
		AND KeyVal = S.ActivityId)  AS '@ActivityName',
	S.ActivityDate		AS '@ActivityDate',
	S.Hours				AS '@Hours',
	S.Description		AS '@Description',
	S.SourceId			AS '@SourceId',
	S.SubmissionId		AS '@SubmissionId',
	S.CreateBy			AS '@CreateBy',
	S.CreateDate		AS '@CreateDate',
	S.UpdateBy			AS '@UpdateBy',
	S.UpdateDate		AS '@UpdateDate'
FROM TimeSheetActivity S 
WHERE S.Id = @Id
FOR XML PATH('TimesheetActivity')  

END
/* Testing *
exec SPU_TimesheetActivity_Get 9
select * from TimeSheetActivity

*/
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_GetByCriteria]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_TimesheetActivity_GetByCriteria]
* DESCRIPTION:  
	Get [TimesheetActivity] single record in XML form with criteria
* CREATED: 10/2021  JoyJing
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_TimesheetActivity_GetByCriteria] 
	@EmployeeId INT = NULL,
	@ProjectId INT = NULL,
	@ActivityId INT = NULL,
	@ActivityDate DATE = NULL
AS BEGIN
IF EXISTS(SELECT 1 FROM TimeSheetActivity WHERE EmployeeId = @EmployeeId AND ProjectId=@ProjectId AND ActivityId=@ActivityId AND DATEDIFF(D,ActivityDate,@ActivityDate)=0) 
BEGIN
SELECT 	   
	S.Id				AS '@Id',
	S.EmployeeId		AS '@EmployeeId',
	S.ProjectId			AS '@ProjectId',
	(SELECT Name	FROM Project P WHERE P.Id = s.ProjectId
		)				AS '@ProjectName',
	S.ActivityId		AS '@ActivityId',
	( SELECT TextVal FROM Enum WHERE Name = 'ProjectActivityId'
		AND KeyVal = S.ActivityId)  AS '@ActivityName',
	S.ActivityDate		AS '@ActivityDate',
	S.Hours				AS '@Hours',
	S.Description		AS '@Description',
	S.SourceId			AS '@SourceId',
	S.SubmissionId		AS '@SubmissionId',
	S.CreateBy			AS '@CreateBy',
	S.CreateDate		AS '@CreateDate',
	S.UpdateBy			AS '@UpdateBy',
	S.UpdateDate		AS '@UpdateDate',  
    1 AS '@IsTimeSheet'
FROM TimeSheetActivity S 
WHERE S.EmployeeId = @EmployeeId AND S.ProjectId=@ProjectId AND ActivityId=@ActivityId AND DATEDIFF(D,S.ActivityDate,@ActivityDate)=0
FOR XML PATH('TimesheetActivity')  
 END
	ELSE
	BEGIN
	SELECT  T.Id		AS '@Id',
   T.EmployeeId		AS '@EmployeeId',
   T.ProjectId		AS '@ProjectId',
   T.ActivityId		AS '@ActivityId',
   @ActivityDate	AS '@ActivityDate',
   0			    AS '@Hours',
   ''	            AS '@Description',
   NULL		        AS '@SourceId',
   NULL	            AS '@SubmissionId',
   T.CreateBy		AS '@CreateBy',
   T.CreateDate		AS '@CreateDate',
   T.UpdateBy		AS '@UpdateBy',
   T.UpdateDate		AS '@UpdateDate',  
   0 AS '@IsTimeSheet', 
  (SELECT Name	FROM Project P WHERE P.Id = T.ProjectId
			)			AS '@ProjectName',
	( SELECT TextVal FROM Enum WHERE Name = 'ProjectActivityId'
			AND KeyVal = T.ActivityId)  AS '@ActivityName'
	FROM EmployeeActivityMap T WHERE EmployeeId=@EmployeeId AND IsActive=1 AND ProjectId=@ProjectId AND ActivityId=@ActivityId 
	FOR XML PATH('TimesheetActivity') 
END
END

/* Testing *
exec SPU_TimesheetActivity_Get 9
select * from TimeSheetActivity

*/
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_Import]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*********************************************************
* PROCEDURE:    [SPU_TimesheetActivity_Import]
* DESCRIPTION:  import activity data
* CREATED: [11/04/2021] BY: JOYJING
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_TimesheetActivity_Import] 
	@Id INT = NULL,
	@EmployeeId INT = NULL,
	@ProjectId INT = NULL,
	@ActivityId INT = NULL,
	@ActivityDate DATE = NULL, 
	@Hours Decimal(18,2) = NULL,
	@Description VARCHAR(5000) = NULL,
	@By VARCHAR(50)
AS BEGIN
	IF EXISTS(SELECT 1 FROM TimeSheetActivity WHERE EmployeeId = @EmployeeId AND ProjectId=@ProjectId AND ActivityId=@ActivityId AND DATEDIFF(D,ActivityDate,@ActivityDate)=0 AND SourceId=1) 
	    BEGIN
	 -- We don't update EmployeeId
	 -- update exist timesheet data
	    SELECT @Id = -1  -- Update none-exist record
	   END
	ELSE 
	BEGIN
	 --insert timesheet data
	 INSERT INTO dbo.TimeSheetActivity
		   (EmployeeId
		   ,ProjectId
		   ,ActivityId
		   ,ActivityDate
		   ,Hours
		   ,Description
		   ,SourceId
		   -- ,SubmissionId
		   ,CreateDate
		   ,CreateBy
		   ,UpdateDate
		   ,UpdateBy)
		VALUES
		   (@EmployeeId, 
			@ProjectId,
			@ActivityId, 
			@ActivityDate, 
			@Hours, 
			@Description,
			2,  -- <SourceId> 1: User input 2: Import (reserved)
			GETUTCDATE(), 
			@By, --    ,
			GETUTCDATE(), 
			@By --   
			)
		SELECT @Id = SCOPE_IDENTITY()
	END
	RETURN @Id
	END
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetActivity_UpSert]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*********************************************************
* PROCEDURE:    [SPU_TimesheetActivity_UpSert]
* DESCRIPTION:  To Insert or Update [TimesheetActivity] table
* CREATED: [10/15/2021] BY: PCHEN
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_TimesheetActivity_UpSert] 
	@Id INT = NULL,
	@EmployeeId INT = NULL,
	@ProjectId INT = NULL,
	@ActivityId INT = NULL,
	@ActivityDate DATE = NULL, 
	@Hours Decimal(18,2) = NULL,
	@Description VARCHAR(5000) = NULL,
	@By VARCHAR(50)
AS BEGIN
	IF EXISTS(SELECT 1 FROM TimeSheetActivity WHERE EmployeeId = @EmployeeId AND ProjectId=@ProjectId AND ActivityId=@ActivityId AND DATEDIFF(D,ActivityDate,@ActivityDate)=0) 
	    BEGIN
	 -- We don't update EmployeeId
	 -- update exist timesheet data
		UPDATE TimeSheetActivity
		SET ProjectId		= ISNULL(@ProjectId, ProjectId),
		    ActivityId		= ISNULL(@ActivityId, ActivityId),
		    ActivityDate	= ISNULL(@ActivityDate, ActivityDate),
		    Hours			= ISNULL(@Hours, Hours),
			Description		= @Description,
			-- SubmissionId	= ISNULL(@SubmissionId, SubmissionId),
			UpdateBy		= @by,
			UpdateDate		= GETUTCDATE()
		WHERE Id = @Id
		IF (@@ROWCOUNT<>1) SELECT @Id = -1  -- Update none-exist record
	   END
	ELSE 
	BEGIN
	 IF(DATEDIFF(D,@ActivityDate,GETUTCDATE())=0)--insert/update activity map data when activity date equals current date
	 BEGIN
	  UPDATE EmployeeActivityMap
	  SET IsActive=1
	  WHERE (EmployeeId=@EmployeeId AND ProjectId=@ProjectId AND ActivityId=@ActivityId)
	  IF NOT EXISTS(SELECT 1 FROM [dbo].[EmployeeActivityMap] WHERE EmployeeId=@EmployeeId AND ProjectId=@ProjectId AND ActivityId=@ActivityId AND IsActive=1)
	  BEGIN
	   INSERT INTO [dbo].[EmployeeActivityMap]
           ([EmployeeId]
           ,[ProjectId]
           ,[ActivityId]
           ,[IsActive]
           ,[CreateDate]
           ,[CreateBy])
       VALUES(@EmployeeId,
            @ProjectId,
            @ActivityId, 
            1,
            GETUTCDATE(),
           @By)
	  END
	 END
	 --insert timesheet data
	 INSERT INTO dbo.TimeSheetActivity
		   (EmployeeId
		   ,ProjectId
		   ,ActivityId
		   ,ActivityDate
		   ,Hours
		   ,Description
		   ,SourceId
		   -- ,SubmissionId
		   ,CreateDate
		   ,CreateBy
		   ,UpdateDate
		   ,UpdateBy)
		VALUES
		   (@EmployeeId, 
			@ProjectId,
			@ActivityId, 
			@ActivityDate, 
			@Hours, 
			@Description,
			1,  -- <SourceId> 1: User input 2: Import (reserved)
			-- @SubmissionId, 
			GETUTCDATE(), --<CreateDate, datetime,>
			@By, --    ,<CreateBy, varchar(50),>
			GETUTCDATE(), --   ,<UpdateDate, datetime,>
			@By --   ,<UpdateBy, varchar(50),>
			)
		SELECT @Id = SCOPE_IDENTITY()
	END
	RETURN @Id
	END
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetPeriod_ClosePeriod]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_TimesheetPeriod_ClosePeriod]
* DESCRIPTION:  
  For IT Executive to approve (close) a timesheet period per AccountingEntity
	1. Close the Period (If it is current)
	2. Make the next one Current
	3. Pre-populate 3 more periods (for start and end date where 
		some future hours can be allocated to for outlook)
* CREATED: 11/27/2021  PCHEN
MODIFICATION HISTORY
	12/22/2021 PCHEN add '@AccountingEntity' factor into system
		Now Timesheet Period is 'AccountingEntity' specific
	01/27/2022 And Period Cut-off date is comming from [AccountingEntity]
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_TimesheetPeriod_ClosePeriod] 
	@PeriodCode CHAR(6),  -- 'YYYYMM'
	@AccountingEntityId INT, 
	@By varchar(50),
	@IsDebug CHAR(1) = 'N'
AS BEGIN
SET NOCOUNT ON
-- Make sure the @PeriodCode+@AccountEntity is "Current"
IF NOT EXISTS (SELECT 1 FROM TimesheetPeriod 
			WHERE PeriodCode = @PeriodCode AND StatusId = 1
			AND AccountingEntityId = @AccountingEntityId)
   RETURN -1   

DECLARE @tPeriod TABLE(AccountingEntityId SMALLINT, 
	PeriodCode CHAR(6), StartDate DATETIME, EndDate DATETIME, StatusId SMALLINT)

DECLARE @FirstDay INT=1, @MthAddFactor INT = 0,
	@NextPeriod CHAR(6), @NextStartDate DATE, @NextEndDate DATE, @i INT = 0;

SELECT @FirstDay = ABS(PeriodFirstDay), 
	@MthAddFactor = CASE WHEN PeriodFirstDay > 0 THEN 0 ELSE -1 END
FROM AccountingEntity WHERE Id = @AccountingEntityId

WHILE ( @i < 4)
BEGIN
	SELECT @NextPeriod = CONVERT(varchar(6), DATEADD(MONTH, @i, CONCAT(@PeriodCode, '01')), 112);
	SELECT @NextStartDate = DATEADD(MONTH, @MthAddFactor, CONVERT(date, CONCAT(@NextPeriod, RIGHT('0' + CONVERT(VARCHAR(2), @FirstDay), 2))));
	SELECT @NextEndDate = DATEADD(DAY, -1, DATEADD(MONTH, 1, @NextStartDate));

	INSERT INTO @tPeriod
	VALUES (@AccountingEntityId, @NextPeriod, @NextStartDate, @NextEndDate, 
		CASE @i WHEN 0 THEN 2	-- 'Close' the first
				WHEN 1 THEN 1	-- 'Current' the one after
				ELSE 0			-- 'Future' any periods after current
		END)
	SET @i = @i+1;
END

IF (@IsDebug = 'Y') BEGIN -- Debug Checkpoint
	SELECT @PeriodCode as '@PeriodCode', @FirstDay as '@FirstDay' , @MthAddFactor as '@MthAddFactor'
	SELECT '' as '@tPeriod', * FROM @tPeriod
	SELECT '' as '[TimesheetPeriod]', P.* FROM TimesheetPeriod P JOIN @tPeriod T ON P.PeriodCode = T.PeriodCode AND P.AccountingEntityId = T.AccountingEntityId	
END
ELSE BEGIN
BEGIN TRY
 select @IsDebug = @IsDebug 
	UPDATE P SET
		StatusId = T.StatusId,
		StartDate = T.StartDate,
		EndDate  = T.EndDate,
		UpdateDate = GETUTCDATE(),
		UpdateBy = @By 
	FROM TimesheetPeriod P JOIN @tPeriod T ON P.PeriodCode = T.PeriodCode AND P.AccountingEntityId = T.AccountingEntityId
	WHERE P.StatusId <> T.StatusId 
	  OR  P.StartDate <> T.StartDate 
	  OR  P.EndDate <> T.EndDate

	INSERT INTO TimesheetPeriod(PeriodCode, AccountingEntityId, 
		StartDate, EndDate, StatusId, 
		CreateDate, CreateBy, UpdateDate, UpdateBy)
	SELECT PeriodCode, AccountingEntityId, 
		StartDate, EndDate, StatusId, 
		GETUTCDATE(), @By, GETUTCDATE(), @By
	FROM @tPeriod T
	WHERE NOT EXISTS (SELECT 1 FROM TimesheetPeriod P 
				WHERE P.PeriodCode = T.PeriodCode
				AND P.AccountingEntityId = T.AccountingEntityId)

END TRY
BEGIN CATCH
	RETURN -999
END CATCH
END -- End IF

RETURN 0
END
GO
/****** Object:  StoredProcedure [dbo].[SPU_TimesheetPeriod_Find]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:    [SPU_TimesheetActivity_Get]
* DESCRIPTION:  
	Get [TimesheetPeriod] 
* CREATED: 10/2021  PaulR
MODIFICATION HISTORY
*
***********************************************************/
Create   PROCEDURE [dbo].[SPU_TimesheetPeriod_Find] 
	@Id INT =null ,
	@StatusId int =null,
	@PeriodCode varchar(10) = null
AS 
BEGIN



SELECT [Id]						AS  'Id'
      ,[PeriodCode]				As  'PeriodCode'
      ,[StartDate]				As  'FromDate'
      ,[EndDate]                As   'ToDate'
      ,[StatusId]				As    'StatusId'
      
  FROM [dbo].[TimesheetPeriod]



WHERE  (@Id is null or id = @Id)
and (@StatusId is null or StatusId = @StatusId)
and (@PeriodCode is null or PeriodCode=@PeriodCode)
 FOR XML PATH('TimesheetPeriod') , ROOT('ArrayOfTimesheetPeriod'), TYPE

END

GO
/****** Object:  StoredProcedure [dbo].[SPU_Workflow_Update]    Script Date: 1/27/2022 5:22:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*********************************************************
* PROCEDURE:  [SPU_Workflow_Update]
DESCRIPTION:  To update workflow Status
@WorkflowID: 1: Project Workflow 2: Timesheet Submission Workflow
* CREATED: 10/18/2021 PCHEN
MODIFICATION HISTORY
*
***********************************************************/
CREATE PROCEDURE [dbo].[SPU_Workflow_Update] 
	@WorkflowId INT,
	@EntityId INT,
	@StatusId INT,
	@Comment NVARCHAR(500) = NULL, 
	@By VARCHAR(50)
AS  BEGIN

DECLARE @PreviousId int = 0;
SELECT @PreviousId = Id FROM WorkflowHistory
WHERE WorkflowId = @WorkflowId
AND EntityId = @EntityId
AND IsCurrent = 1

DECLARE @errcnt INT = 0;
BEGIN TRAN
if (@PreviousId > 0)
	UPDATE WorkflowHistory SET IsCurrent=0 WHERE Id = @PreviousId

IF (@@ERROR<> 0) SELECT @errcnt = @errcnt + 1

INSERT INTO WorkflowHistory (
	WorkflowId, EntityId, 
	StatusId, StatusBy, StatusDate, 
	Comment, PrevHistoryId, IsCurrent)
values (
	@WorkflowId, @EntityId, 
	@StatusId, @By, GETUTCDATE(),
	@Comment, @PreviousId, 1)
IF (@@ERROR <> 0) SELECT @errcnt = @errcnt + 1

-- Update corresponding Workflow entity (Project or TimesheetSubmission)
If (@WorkflowId = 1) -- Project
	UPDATE Project SET 
		StatusId = @StatusId,
		StatusDate = GETUTCDATE(),
		UpdateBy = @By,
		UpdateDate = GETUTCDATE()
	WHERE Id = @EntityId
ELSE IF (@WorkflowId = 2) -- Timesheet Submission
	UPDATE TimeSheetSubmission SET
		StatusId = @StatusId,
		StatusDate = GETUTCDATE(),
		UpdateBy = @By,
		UpdateDate = GETUTCDATE()
	WHERE Id = @EntityId

IF (@@ERROR<> 0) SELECT @errcnt = @errcnt + 1

IF (@errcnt = 0) BEGIN 
	COMMIT;  
	RETURN 0; -- Success
	END
ELSE BEGIN
	ROLLBACK;
	RETURN -1;  -- Indicate a failure
	END

END
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Accounting Region' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'TimesheetPeriod', @level2type=N'COLUMN',@level2name=N'AccountingEntityId'
GO
