﻿using EVO.TimesheetPortal.Entity;
using FrameworkBase.BusinessLogic;
using FrameworkBase.DataAccess;

namespace EVO.TimesheetPortal.BusinessLogic
{
    public class TimesheetPeriodManager : ManagerBase<TimesheetPeriod>
    {
        #region	Constructors

        private TimesheetPeriodManager(IDbSession dbSession, IDataAccessObject<TimesheetPeriod> dao) : base(dbSession, dao)
        {
        }

        static TimesheetPeriodManager()
        {
            // Initialize logger here if needed
        }

        #endregion constructors

        #region Custom menthods can't handle by IManager

        #endregion
    }
}