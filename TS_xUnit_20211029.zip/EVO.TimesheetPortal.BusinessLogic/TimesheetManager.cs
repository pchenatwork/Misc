﻿/*=======================================================================
* Modification History:
* ----------------------------------------------------------------------
* 10/14/2021   DINO    Introduced
* 10/20/2021   PCHEN   Mainly used for Timesheet(group by timesheet activities) lookup
*=======================================================================*/

using EVO.TimesheetPortal.Entity;
using FrameworkBase.BusinessLogic;
using FrameworkBase.DataAccess;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.Json;
using System.Xml;

namespace EVO.TimesheetPortal.BusinessLogic
{
    public class TimesheetManager : ManagerBase<Timesheet>
    {
        #region	Constructors

        private TimesheetManager(IDbSession dbSession, IDataAccessObject<Timesheet> dao) : base(dbSession, dao)
        {
        }

        static TimesheetManager()
        {
            // Initialize logger here if needed
        }

        #endregion constructors

        #region Custom menthods can't handle by IManager

        /// <summary>
        /// IT Executive Summary Outlook
        /// </summary>
        /// <param name="PeriodCode">YYYYMM</param>
        /// <returns>DataTable with string value (Hours) in form of {{TotalHrs}}::{{ProjectId}}::{{TeamId}}</returns>
        public DataTable GetOutlookByExecutiveSummary(string PeriodCode)
        {
            return (DataTable)dao.InvokeByMethodName("GetOutlookByExecutiveSummary",
                new object[] { dbSession, PeriodCode });
        }

        /// <summary>
        /// periodCoe : 202110
        /// </summary>
        /// <param name="periodCode"></param>
        /// <returns></returns>
        public DataTable GetOutlookProjectSummary(string periodCode)
        {
            return (DataTable)dao.InvokeByMethodName("GetOutlookProjectSummary",
               new object[] { dbSession, periodCode });
        }

        /// <summary>
        /// periodCoe : 202110
        /// </summary>
        /// <param name="periodCode"></param>
        /// <returns></returns>
        public Timesheet GetOutlookByTeamResource(string periodCode)
        {
            return (Timesheet)dao.InvokeByMethodName("GetOutlookByTeamResource",
               new object[] { dbSession, periodCode });
        }
        /// <summary>
        /// Get timesheet outlook per team per project
        /// </summary>
        /// <param name="TeamId"></param>
        /// <param name="ProjectId"></param>
        /// <param name="PeriodCode">YYYYMM</param>
        /// <returns></returns>
        public Timesheet GetOutlookByTeamProject(int TeamId, int ProjectId, string PeriodCode)
        {
            return (Timesheet)dao.InvokeByMethodName("GetOutlookByTeamProject",
                new object[] { dbSession, TeamId, ProjectId, PeriodCode});
        }
        /// <summary>
        /// Get timesheet outlook for Employee per project from Manager
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="ProjectId"></param>
        /// <param name="PeriodCode">YYYYMM</param>
        /// <returns></returns>
        public Timesheet GetOutlookByEmployeeProject(int EmployeeId, int ProjectId, string PeriodCode)
        {
            return (Timesheet)dao.InvokeByMethodName("GetOutlookByEmployeeProject",
                new object[] { dbSession, EmployeeId, ProjectId, PeriodCode });
        }

        /// <summary>
        /// Get timesheet outlook per Employee from Manager
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="PeriodCode">YYYYMM</param>
        /// <returns></returns>
        public Timesheet GetOutlookByEmployee(int EmployeeId, string PeriodCode)
        {
            return (Timesheet)dao.InvokeByMethodName("GetOutlookByEmployee",
                new object[] { dbSession, EmployeeId, PeriodCode });
        }
        /// <summary>
        /// Employee Timsheet Manager Approval
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="PeriodCode">YYYYMM</param>
        /// <param name="jsonTSActivityIds">List of TimesheetActivity.Id in JSON format to be approved by this approval</param>
        /// <param name="by"></param>
        /// <returns></returns>
        public bool ManagerApproval(int EmployeeId, string PeriodCode, string by, string jsonTSActivityIds=null)
        {
            if (jsonTSActivityIds == null)
            {
                // if jsonTSActivityIds not present, Compose the JSON Ids from a DB lookup
                var ts = GetOutlookByEmployee(EmployeeId, PeriodCode);
                var x = from t in ts.Activities select new { t.Id }; // => form of [{"Id":4}, {"Id":3}]
                jsonTSActivityIds = JsonSerializer.Serialize(x);
            }
            return (bool)dao.InvokeByMethodName("ManagerApproval",
                new object[] { dbSession, EmployeeId, PeriodCode, jsonTSActivityIds, by });
        }
        /// <summary>
        /// Timesheet Executive Approval
        /// </summary>
        /// <param name="PeriodCode">YYYYMM</param>
        /// <param name="by"></param>
        /// <param name="Comment"></param>
        /// <returns></returns>
        public bool ExecutiveApproval(string PeriodCode, string by, string Comment = null)
        {
            return (bool)dao.InvokeByMethodName("ExecutiveApproval",
                new object[] { dbSession, PeriodCode, by, Comment });
        }

        public IEnumerable<Timesheet> GetTrendData(int EmployeeId, string PeriodCode)
        {
            return (IEnumerable<Timesheet>)dao.InvokeByMethodName("GetTrendData",
                  new object[] { dbSession, EmployeeId, PeriodCode });
        }
        /// <summary>
        /// Outlook for Executive on All Teams All resource(Employee)
        /// </summary>
        /// <param name="PeriodCode">YYYYMM</param>
        /// <returns></returns>
        public Timesheet GetOutlookTeamResource(string PeriodCode)
        {
            return (Timesheet)dao.InvokeByMethodName("GetOutlookTeamResource",
                new object[] { dbSession, PeriodCode });
        }
        #endregion
    }
}