﻿#region Header Info
using EVO.TimesheetPortal.Entity;
using FrameworkBase.BusinessLogic;
using FrameworkBase.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/
#endregion

namespace EVO.TimesheetPortal.BusinessLogic
{
    public class EmployeeManager : ManagerBase<Employee>
    {
        #region	Constructors
        private EmployeeManager(IDbSession dbSession, IDataAccessObject<Employee> dao): base(dbSession, dao)
        { 
        }

        static EmployeeManager()
        {
            //_logger will go here
        }
        #endregion constructors

        #region Custom menthods can't handle by IManager

        // Two sample methods to consume the new Find using JsonTokens Only
        public IEnumerable<Employee> FindByDeptCode(string deptcode)
        {
            var jsonTokens = new { deptcode = deptcode };
            return this.dao.Find(this.dbSession, JsonSerializer.Serialize(jsonTokens));

        }
        public List<Employee> FindByName(string name)
        {
            var jsonTokens = new { all=true, name = name };
            var x =  this.dao.Find(this.dbSession, JsonSerializer.Serialize(jsonTokens));

            /*** We can convert the result to List<Employee> if wished ***/
            return x.ToList();
            /***/
        }


        /// <summary>
        /// Dummy custom method for demo purpose 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="status"></param>
        /// <returns>a list of strings containing parameters</returns>
        public List<string> MyDemoInvokeMethod1(int id, string status)
        {
            /// This can be used to any delete/update/insert/searching method that is outside of standard methods
            var x =  (List<string>)dao.InvokeByMethodName("MyDaoMethod1",
                new object[] { dbSession, id, status });

            // we can do some more manipulation after getting the data from DAO
            x.Add("Added from EmployeeManager.MyInvokeMethods");
            return x; 
        }

        #endregion

    }
}
