﻿#region Header Info
using EVO.TimesheetPortal.Entity;
using FrameworkBase.BusinessLogic;
using FrameworkBase.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/
#endregion

namespace EVO.TimesheetPortal.BusinessLogic
{
    public class TimesheetActivityManager : ManagerBase<TimesheetActivity>
    { 
        #region	Constructors
        private TimesheetActivityManager(IDbSession dbSession, IDataAccessObject<TimesheetActivity> dao)
            : base(dbSession, dao)
        {
        }

        static TimesheetActivityManager()
        {
            //_logger can go here
        }
        #endregion constructors

        #region Custom menthods outside of IManager
        public IList<TimesheetActivity> FindByDate(int EmployeeId, DateTime ActivityDate)
        {
            var jsonTokens = new { EmployeeId = EmployeeId, ActivityDate = ActivityDate };
            return dao.InvokeByMethodName("FindDailyData", new object[] { this.dbSession, JsonSerializer.Serialize(jsonTokens) });
        }
        public List<TimesheetActivity> FindByDate(int EmployeeId, DateTime SDate, DateTime EDate,int IsMonth=0)
        {
            var jsonTokens = new { employeeid = EmployeeId, fromdate = SDate, todate = EDate, IsMonth=IsMonth };
            return this.dao.Find(this.dbSession, JsonSerializer.Serialize(jsonTokens))?.ToList();
        }

        public TimesheetActivity GetByCriteria(TimesheetActivity e)
        {
            return dao.InvokeByMethodName("GetByCriteria", new object[] { this.dbSession, e });
        }
        #endregion

    }
}
