﻿using EVO.TimesheetPortal.Entity;
using FrameworkBase.BusinessLogic;
using FrameworkBase.DataAccess;
using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimesheetPortal.BusinessLogic
{
    public class ApplicationLogManager : ManagerBase<ApplicationLog>
    {
        #region 'Manager' specific 'FinderType'
        /** Note PCHEN: **
         *  Make sure the finderType value matches to corresponding finderType in Dao **/
        //public const string FIND_EMPLOYEES = "SPU_Employee_Find";
        #endregion

        #region	Constructors
        private ApplicationLogManager(IDbSession dbSession, IDataAccessObject<ApplicationLog> dao) 
            : base(dbSession, dao)
        {
        }

        static ApplicationLogManager()
        {
            //_logger = LoggingUtility.GetLogger(typeof(EmployeeManager).FullName);
        }
        #endregion constructors

        #region Custom menthods outside of IManager
        #endregion

    }
}

