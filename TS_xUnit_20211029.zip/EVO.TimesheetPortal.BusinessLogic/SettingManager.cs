﻿/*=======================================================================
* Modification History:
* ----------------------------------------------------------------------
* 10/14/2021   DINO       Introduced
*=======================================================================*/

using EVO.TimesheetPortal.Entity;
using FrameworkBase.BusinessLogic;
using FrameworkBase.DataAccess;

namespace EVO.TimesheetPortal.BusinessLogic
{
    public class SettingManager : ManagerBase<Setting>
    {
        #region	Constructors

        private SettingManager(IDbSession dbSession, IDataAccessObject<Setting> dao) : base(dbSession, dao)
        {
        }

        static SettingManager()
        {
        }

        #endregion constructors

        #region Custom menthods can't handle by IManager
        #endregion
    }
}