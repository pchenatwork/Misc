﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FrameworkBase.Interface
{
    interface IValueObjectAudit
    {
        string CreateBy { get; set; }
        DateTime CreateDate { get; set; }
        string UpdateBy { get; set; }
        DateTime UpdateDate { get; set; }
        string Extra { get; set; }
    }
}
