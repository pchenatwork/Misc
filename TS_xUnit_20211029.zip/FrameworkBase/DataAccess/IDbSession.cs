﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using System;
using System.Data;

#endregion

namespace FrameworkBase.DataAccess
{
    /// <summary>
    /// Represent a database session
    /// </summary>
    public interface IDbSession : IDisposable
    {
        IDbConnection DbConnection { get; }
        IDbTransaction Transaction { get; }

        IDbTransaction BeginTrans(IsolationLevel isolation = IsolationLevel.ReadCommitted);

        void Commit();

        void Rollback();
    }
}