﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using System;
using System.Data;
using System.Linq;

#endregion Header Info

namespace FrameworkBase.DataAccess
{
    /// <summary>
    /// Represent a DbSession to SQL Server from application
    /// </summary>
    public class SqlSession : IDbSession, IDisposable
    {
        #region Private members

        private IDbConnection _dbConn;
        private IDbTransaction _dbTran;

        #endregion Private members

        #region Constructor
        /// <summary>
        /// DbSession for SQL Server
        /// </summary>
        /// <param name="connStr"></param>
        internal SqlSession(string connStr)
        {
            try
            {
                _dbConn = Microsoft.Data.SqlClient.SqlClientFactory.Instance.CreateConnection(); 
                if (_dbConn != null) _dbConn.ConnectionString = connStr;
            }
            catch (Exception ex)
            {
                // In case _dbConn is not NULL, set it to NULL
                if (_dbConn != null)
                {
                    _dbConn = null;
                }
            }
        }

        #endregion Constructor

        #region Properties

        public IDbConnection DbConnection => _dbConn;
        public IDbTransaction Transaction => _dbTran;

        #endregion Properties

        public IDbTransaction BeginTrans(IsolationLevel isolation = IsolationLevel.ReadCommitted)
        {
            if (_dbConn.State == ConnectionState.Closed) _dbConn.Open();
            return _dbTran = _dbConn.BeginTransaction(isolation);
        }

        public void Commit()
        {
            _dbTran.Commit();
            _dbTran = null;
        }

        public void Rollback()
        {
            _dbTran.Rollback();
            _dbTran = null;
        }

        public void Dispose()
        {
            if (_dbConn.State != ConnectionState.Closed)
            {
                if (_dbTran != null)
                {
                    //_dbTran.Rollback();
                    _dbTran.Dispose();
                    _dbTran = null;
                }
                _dbConn.Close();
            }
            _dbConn = null;
            GC.SuppressFinalize(this);
        }
    }
}
