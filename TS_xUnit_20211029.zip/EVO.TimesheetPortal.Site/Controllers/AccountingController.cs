﻿using EVO.Common.UtilityCore;
using EVO.TimesheetPortal.Site.App_Classes;
using EVO.TimesheetPortal.Site.Models;
using EVO.TimesheetPortal.Site.Service;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class AccountingController : BaseController
    {
        private static readonly string AccountingDataKey = "AccountingData-{0}";
        private AccountingService AccountingService;

        public AccountingController(AccountingService accountingService)
        {
            AccountingService = accountingService;
        }

        [PageEntry(ActionName = "index", ControllerName = "Accounting")]
        public ActionResult Index()
        {
            return View();
        }

        public async Task<ActionResult> Read([DataSourceRequest] DataSourceRequest request, BaseModel model)
        {
            string period = model.Extra;
            var sessionKey = string.Format(AccountingDataKey, period);
            var timeSheetList = ApplicationContext.Current.Session.GetJson<List<TimeSheetAccountingModel>>(sessionKey);
            if (timeSheetList == null || timeSheetList.Count == 0)
            {
                timeSheetList = await AccountingService.GetTimesheetAccounting(period);
            }
            return Json(timeSheetList.ToDataSourceResult(request));
        }

        public async Task<ActionResult> UploadPayRate(IEnumerable<IFormFile> importRateFiles, string DateRange)
        {
            ProblemDetails x = new ProblemDetails();
            x.Extensions.Add("DateRange", DateRange);
            try
            {
                var file = importRateFiles?.FirstOrDefault();
                if (file == null || file.Length < 1)
                {
                    x.Status = 500;
                    x.Detail = "File length error.";
                }
                List<AccountingModel> accountingList = await AccountingService.GenearteAccountModel(file);
                if (accountingList == null || accountingList.Count < 1)
                {
                    x.Status = 297;
                    x.Detail = "Payrate file can not be empty.";
                }
                int reuslt = await AccountingService.CalculatePayrate(DateRange, AccountingDataKey, accountingList);
                switch (reuslt)
                {
                    case 0:
                        x.Status = 298;
                        x.Detail = "Payrate file matches to no timesheet record."; break;
                    case 1:
                        x.Status = 200;
                        x.Detail = "Payrate file applied."; break;
                    case 2:
                        x.Status = 299;
                        x.Detail = "Payrate file partially matches to timesheet record(s)."; break;
                }
            }
            catch (Exception ex)
            {
                Serilog.Log.Error(ex, "import payrate file error.");
                x.Status = 500;
                x.Detail = ex.Message;
            }
            return new ObjectResult(x);
        }

        [HttpPost]
        public ActionResult Download([FromServices] IWebHostEnvironment webHostingEnv)
        {
            var rootPath = webHostingEnv.ContentRootPath + "\\Templates";
            var fileName = "payrate.xlsx";
            var data = ExportHelper.Generate(rootPath, fileName, new TimeSheetAccountingModel());
            return File(data, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
        }
    }
}