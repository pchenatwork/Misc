using EVO.TimesheetPortal.Entity;
using EVO.TimesheetPortal.Site.App_Classes;
using EVO.TimesheetPortal.Site.Models;
using EVO.TimesheetPortal.Site.Service;
using EVOUserWSServiceReference;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.Collections.Generic;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using TimeSheetTrackerCore.Site.Models;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class LoginController : Controller
    {
        private IEmployeeService ResourceService;
        private ITeamService TeamService;
        public IConfiguration Configuration;
        public static string DomainName;
        private readonly IHttpContextAccessor HttpContextAccessor;
        protected IEVOUserWS UserManagementClient;
        public IWebHostEnvironment Environment { get; set; }

        public LoginController(
            IEVOUserWS userManagementClient,
            IEmployeeService service,
            ITeamService teamService,
            IConfiguration configuration,
            IWebHostEnvironment environment,
            IHttpContextAccessor httpContextAccessor)
        {
            ResourceService = service;
            Configuration = configuration;
            Environment = environment;
            DomainName = Configuration.GetValue<string>("Application:DefualtDomainName");
            HttpContextAccessor = httpContextAccessor;
            UserManagementClient = userManagementClient;
            TeamService = teamService;
        }

        [HttpGet]
        public async Task<IActionResult> UserLogin(string returnUrl)
        {
            returnUrl = FormatReturn(returnUrl);
            ViewBag.ReturnUrl = returnUrl;
            ViewBag.UserName = HttpContextAccessor.HttpContext.User.Identity.Name;
            var authCookie = ApplicationContext.Current.Request.Cookies["TimeSheetTrackerCookie"];
            if (authCookie != null)
            {
                await HttpContext.SignOutAsync();
                HttpContext.Session.Clear();
            }
            return View();
        }

        [HttpPost]
        [IgnoreAntiforgeryToken]
        public async Task<IActionResult> UserLogin([Bind("UserName,Password")] LoginViewModel model, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                returnUrl = FormatReturn(returnUrl);
                if (string.IsNullOrEmpty(model.UserName))
                {
                    ModelState.AddModelError("", "The user name is empty.");
                    return View();
                }

                var userName = ResolveDomainAccount(model.UserName);
                PrincipalContext context = new PrincipalContext(ContextType.Domain, DomainName);

                try
                {
                    if (!context.ValidateCredentials(userName, model.Password))
                    {
                        ModelState.AddModelError("", "The username or password is incorrect. Please try again. Your windows account will be locked after the 3rd unsuccessful attempt.");
                        return View();
                    }
                    else
                    {
                        var userWP = await GetUserData(userName);
                        var currentUser = await GetCurrentUser(userName);
                        var team = await TeamService.GetTeamAsync(currentUser?.Team?.ID ?? -1);
                        currentUser.Team = new TeamModel
                        {
                            ID = team.Id,
                            DeptCode = team.DeptCode,
                            Name = team.Name,
                            Manager = new EmployeeModel { ID = team.Manager?.Id ?? 0 },
                            Owner = new EmployeeModel { ID = team.Owner?.Id ?? 0}
                        };
                        var UserModel = new UserModel() { User = userWP.user, Employee = currentUser };
                        UserModel.IsAdmin = UserModel.CheckIsAdmin(userWP.user);
                        return await LoginAuthenticate(returnUrl, UserModel);
                    }
                }
                catch (Exception error)
                {
                    Log.Error(error, "Login Error!");
                    ModelState.AddModelError("", "Login failed, please contact administrator to check the e user service.");
                    return View();
                }
            }
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> SuperUserLogin(string returnUrl)
        {
            returnUrl = FormatReturn(returnUrl);
            ViewBag.ReturnUrl = returnUrl;
            var authCookie = ApplicationContext.Current.Request.Cookies["TimeSheetTrackerCookie"];
            if (authCookie != null)
            {
                await HttpContext.SignOutAsync();
                HttpContext.Session.Clear();
            }
            return View();
        }

        [HttpPost]
        [IgnoreAntiforgeryToken]
        public async Task<IActionResult> SuperUserLogin([Bind("UserName,Password")] LoginViewModel model, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                returnUrl = FormatReturn(returnUrl);
                string token = Configuration.GetValue<string>("SuperUserToken");
                if (string.IsNullOrEmpty(token))
                {
                    ModelState.AddModelError("", "Super user log in is closed.");
                    return View();
                }

                var inputToken = model.Password;
                var userName = model.UserName;

                try
                {
                    if (token != inputToken)
                    {
                        ModelState.AddModelError("", "Please provide the correct token!");
                        return View();
                    }
                    else
                    {
                        var userWP = await GetUserData(userName);
                        if (userWP.user == null)
                        {
                            ModelState.AddModelError("", "Please add this user in eUser first!");
                            return View();
                        }
                        var currentUser = await GetCurrentUser(userName);
                        var team = await TeamService.GetTeamAsync(currentUser?.Team?.ID ?? -1);
                        currentUser.Team = new TeamModel
                        {
                            ID = team.Id,
                            DeptCode = team.DeptCode,
                            Name = team.Name,
                            Manager = new EmployeeModel { ID = team.Manager?.Id ?? 0 },
                            Owner = new EmployeeModel { ID = team.Owner?.Id ?? 0 }
                        };
                        var UserModel = new UserModel() { User = userWP.user, Employee = currentUser };
                        UserModel.IsAdmin = UserModel.CheckIsAdmin(userWP.user);
                        return await LoginAuthenticate(returnUrl, UserModel);
                    }
                }
                catch (Exception error)
                {
                    Log.Error(error, "Login Error!");
                    ModelState.AddModelError("", "Login failed, please contact administrator to check the e user service.");
                    return View();
                }
            }
            return View();
        }

        private async Task<IActionResult> LoginAuthenticate(string returnUrl, UserModel userModel)
        {
            var userClaims = new List<Claim>()
                            {
                                new Claim(ClaimTypes.Name, userModel.User.UserName),
                                new Claim(ClaimTypes.Email, userModel.User.Email),
                            };
            var grandmaIdentity = new ClaimsIdentity(userClaims, "Forms");
            var idleTimeOut = Configuration.GetValue<double>("Application:TimeOut");
            var authProperties = new AuthenticationProperties
            {
                AllowRefresh = true,
                ExpiresUtc = DateTimeOffset.UtcNow.AddSeconds(idleTimeOut),
                IsPersistent = false,
                IssuedUtc = DateTimeOffset.UtcNow,
                RedirectUri = null
            };
            var userPrincipal = new ClaimsPrincipal(new[] { grandmaIdentity });
            await HttpContext.SignInAsync(userPrincipal, authProperties);

            if (userModel.Employee != null && userModel.Employee.ID > 0)
            {
                var employeee = userModel.Employee;
                var userName = userModel.User.FirstName + " " + userModel.User.LastName;
                var roleName = userModel.User.Roles.RoleName;
                if (!string.IsNullOrEmpty(userName.Trim(' ')) && (!employeee.RoleNames.Any(s => s == roleName) || employeee.DisplayName != userName))
                {
                    employeee.DisplayName = userName;
                    //await LoginService.SyncEmployee(employeee.EmployeeID, employeee.UserID, userName, roleName);
                }
            }

            ApplicationSession.CurrentLanguage = GetCurrentLanuage(Request.Headers["Accept-Language"].ToString());
            ApplicationSession.SetUser(userModel);

            string tempUrl = returnUrl;
            if (string.IsNullOrEmpty(returnUrl))
            {
                tempUrl = Url.Action("index", "home");
                if (userModel.Employee != null)
                {
                    switch (userModel.User.Roles.RoleName?.ToLower())
                    {
                        case "manager":
                        case "itexecutive":
                            tempUrl = Url.Action("approval", "project");
                            break;
                        case "projectadmin":
                            tempUrl = Url.Action("Index", "Project");
                            break;
                        case "employee":
                        case "timesheetadmin":
                            tempUrl = Url.Action("Index", "TimeSheet");
                            break;
                        case "accounting":
                            tempUrl = Url.Action("Index", "Accounting");
                            break;
                        case "teamowner":
                            tempUrl = Url.Action("Index", "Employee");
                            break;
                        default:
                            tempUrl = Url.Action("Index", "TimeSheet");
                            break;
                    }
                }
            }

            if (Url.IsLocalUrl(tempUrl))
            {
                ViewBag.ReturnUrl = returnUrl;
                return Redirect(tempUrl);
            }
            else
            {
                return View("Error", model: "The return url is incorrect, please re-login the application.");
            }
        }

        private string FormatReturn(string returnUrl)
        {
            if (returnUrl?.Contains("SessionID") ?? false)
                returnUrl = returnUrl.Substring(0, returnUrl.IndexOf("SessionID") - (returnUrl.Contains("&SessionID") ? 1 : 0));
            if (CheckReturnUrlInBlackList(returnUrl))
            {
                returnUrl = string.Empty;
            }
            return returnUrl;
        }

        private bool CheckReturnUrlInBlackList(string url)
        {
            if (string.IsNullOrWhiteSpace(url))
            {
                return false;
            }
            var blackList = new List<string>() { "Excel_Export" };
            return blackList.Any(s => url.Contains(s));
        }

        private string ResolveDomainAccount(string domainName)
        {
            if (string.IsNullOrEmpty(domainName))
            {
                return string.Empty;
            }
            var domainArray = domainName.Split(new char[] { '\\' });
            var emailFormatArray = domainName.Split(new char[] { '@' });

            string userName = domainName;

            if (domainArray.Length > 1)
            {
                userName = domainArray[1];
            }
            else if (emailFormatArray.Length > 1)
            {
                userName = emailFormatArray[0];
            }

            return userName;
        }

        private async Task<UserWP> GetUserData(string userName)
        {
            string applicationName = Configuration.GetValue<string>("Application:Name");
            return await UserManagementClient.GetUserProfileAsync(applicationName, userName);
        }

        private async Task<EmployeeModel> GetCurrentUser(string loginName)
        {
            var apiResponse = await ResourceService.SearchAsync(new Employee() { UserId = loginName });
            var entity = apiResponse.Content?.FirstOrDefault(f=>f.UserId == loginName);
            var model = new EmployeeModel();
            if (entity == null)
            {
                return model;
            }
            model.UserId = entity.UserId;
            model.LastName = entity.LastName;
            model.FirstName = entity.FirstName;
            model.Email = entity.Email;
            model.CountryCode = entity.CountryCode;
            model.CreateBy = entity.CreateBy;
            model.CreateDate = entity.CreateDate;
            model.DeptCode = entity.DeptCode;
            model.DisplayName = entity.DisplayName;
            model.ID = entity.Id;
            model.JobGradeId = entity.JobGradeId;
            model.Manager = new ManagerModel
            {
                ID = entity.Manager?.Id ?? 0,
                DisplayName = entity.Manager?.DisplayName
            };
            model.Team = new TeamModel
            {
                ID = entity.Team?.Id ?? 0,
                Name = entity.Team?.Name,
                Manager = new EmployeeModel { ID = entity.Team?.Manager?.Id ?? 0, UserId = entity.Team?.Manager?.UserId },
                Owner = new EmployeeModel { ID = entity.Team?.Owner?.Id ?? 0, UserId = entity.Team?.Owner?.UserId }
            };
            model.RoleNames = entity.RoleNames.ToList();
            return model;
        }

        private string GetCurrentLanuage(string acceptLang)
        {
            string lang = "en-US";
            if (!string.IsNullOrEmpty(acceptLang))
            {
                lang = acceptLang.Split(',')?.FirstOrDefault();
            }
            return lang;
        }
    }
}