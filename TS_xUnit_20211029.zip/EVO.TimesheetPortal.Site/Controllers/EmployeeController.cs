﻿using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using EVO.TimesheetPortal.Site.App_Classes;
using EVO.TimesheetPortal.Site.Models;
using EVO.TimesheetPortal.Site.Service;
using System.Threading.Tasks;
using TimeSheetTrackerCore.Site.Models;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Numeric;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class EmployeeController : BaseController
    {
        //private IEmployeeService  Service;
        private EmployeeService Service;
            
        public EmployeeController(EmployeeService employeeService)
        {
            Service = employeeService;
        }

        [PageEntry(ActionName = "index", ControllerName = "Employee")]
        public IActionResult Index()
        {

            var PermissionNameList = ApplicationSession.GetUser()?.User.Permissions
           .Where(w => !string.IsNullOrEmpty(w.PermissionName)).Select(s => s.PermissionName).ToList();
            ViewData["PermissionNameList"] = PermissionNameList;
            return View();
        }

        public IActionResult CreateEmployee()
        {
            return PartialView("EmployeeCreate", new EmployeeModel());
        }

        public async Task<IActionResult> EditEmployee(int id)
        {
            var employee = await Service.GetEmployeeById(id);
            return PartialView("EmployeeEdit", employee);
        }


        [HttpGet]
        [Consumes("application/json")]
        public async Task<JsonResult> GetResource()
        {
            var resources = await Service.GetAllResource();
            return Json(resources);
        }

        

        public async Task<ActionResult> Read([DataSourceRequest] DataSourceRequest request)
        {
            int ownerId = ApplicationSession.GetUser().Employee?.ID ?? -1;
            if (ApplicationSession.IsTeamAdmin)
            {
                ownerId = 0;
            }
            var employeeList = await Service.GetListByEntity(new Entity.Employee() { TeamOwnerId = ownerId});
            foreach (var i in employeeList)
            {
                List<ActionOptionModel> a = new List<ActionOptionModel>();
                a.Add(new ActionOptionModel() { T = 1, N = "Edit", V = $"edit:{i.ID}", E = i.ID.ToString() });
                a.Add(new ActionOptionModel() { T = 3, N = "Delete", V = $"delete:{i.ID}", E = i.ID.ToString() });
                i.Extra = JsonSerializer.Serialize(a);
            }
            return Json(employeeList.ToDataSourceResult(request));
        }

        [HttpPost]
        public async Task<ActionResult> Save(EmployeeModel model)
        {

            if (model != null && ModelState.IsValid)
            {
                if(model.ID < 1)
                {
                    model.CreateBy = UserName;
                    model.CreateDate = DateTime.UtcNow;
                    model.IsActive = true;
                    model.DisplayName = model.FirstName + " " + model.LastName;
                }
                model.UpdateBy = UserName;
                model.UpdateDate = DateTime.UtcNow;

                var result = await Service.SaveAsync(model);
                if (!result.IsSuccessStatusCode)
                {
                    ModelState.AddModelError("", result.Error.Content);
                }
            }

            
            return Json(model);
        }

        public async Task<ActionResult> Delete(int id)
        {
            var result = await Service.DeleteAsync(id, UserName);
            
            return Json(result.Content);

        }

        public async Task<List<EmployeeModel>> GetManagers()
        {
            var result = await Service.GetList();
            return result;
        }

        public async Task<ActionResult> ReadEmployee()
        {
            var result = await Service.PopulateEmployeeSearchData();
            return Json(result);
        }


        public async  Task<ActionResult> GetTeams(string text)
        {
            int? teamOwnerId = ApplicationSession.GetUser().Employee?.ID ;
            teamOwnerId = ApplicationSession.IsTeamAdmin ? null : teamOwnerId;
            var result =  await Service.GetTeams(teamOwnerId);
            return Json(result);
        }


        public async Task<ActionResult> GetDeptments(string text)
        {
            var result = await Service.GetDepartmentCodeList();
            return Json(result);
        }


        public async Task<ActionResult> GetJobGrades(string text)
        {
            var result = await Service.GetJobGradeCodeList();
            return Json(result);
        }

        public async Task<ActionResult> GetCountryCodes(string text)
        {
            var result = await Service.GetCountryCodeList();
            return Json(result);
        }

    }
}