﻿using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;

using System;
using System.Collections.Generic;
using System.Linq;
using EVO.TimesheetPortal.Site.App_Classes;
using EVO.TimesheetPortal.Site.Models;
using EVO.TimesheetPortal.Site.Service;
using System.Threading.Tasks;
using EVO.TimesheetPortal.Entity;
using System.Reflection;


namespace EVO.TimesheetPortal.Site.Controllers
{
    public class TeamController : BaseController<ITeamService>
    {
        private readonly IEmployeeService EmployeeService;
        public TeamController(ITeamService t, IEmployeeService employeeService) : base(t)
        {
            EmployeeService = employeeService;
        }

        [PageEntry(ActionName = "Index", ControllerName = "Team")]
        public IActionResult Index()
        {
            var user = ApplicationSession.GetUser();
            

            var PermissionNameList = user?.User.Permissions
             .Where(w => !string.IsNullOrEmpty(w.PermissionName)).Select(s => s.PermissionName).ToList();

            ViewData["PermissionNameList"] = PermissionNameList;

            ViewData["IsAdmin"] = ApplicationSession.IsAdmin;
            return View();
        }

        public async Task<IActionResult> EditTeam(int id)
        {
            var team = await Client.GetTeamAsync(id);
            var teamModel = TeamModel.MapEntiyToModel(team);
            return PartialView("TeamEdit", teamModel);
        }

        public IActionResult CreateTeam()
        {
            return PartialView("TeamCreate", new TeamModel());
        }

        public async Task<ActionResult> Read([DataSourceRequest] DataSourceRequest request)
        {
            var userModel = ApplicationSession.GetUser();

            var isViewAllTeam = ApplicationSession.GetPermissionAccessByKey("Team_ViewAll") || ApplicationSession.IsTeamAdmin;
            var owner = userModel?.Employee;
            var teamViewModel = new TeamCriteria() {IsAdmin = isViewAllTeam };
            teamViewModel.OwnerId = owner?.ID ?? 0;

            var result = await Client.SearchAsync(teamViewModel);
            if(result.IsSuccessStatusCode)
            {
                var teamList = TeamModel.MapObjectToModel(result.Content);
                return Json(teamList.ToDataSourceResult(request));
            }
            else 
            {
                return Json(result.Error);
            }
           
            
        }

        [AcceptVerbs("Post")]
        public async Task<ActionResult> Create(TeamModel model)
        {
            if (model != null && ModelState.IsValid)
            {
                model.UpdateBy = UserName;
                model.UpdateDate = DateTime.Now;
                model.CreateBy = UserName;
                model.CreateDate = DateTime.Now;

                var result = await Client.InsertAsync(TeamModel.MapModelToObject(model));
                if (!result.IsSuccessStatusCode)
                {
                    ModelState.AddModelError("", result.Error.Content);
                }
                else
                {
                    model.ID = result.Content;
                }
            }

            return Json(model);
        }

        [AcceptVerbs("Post")]
        public async Task<ActionResult>  Update(TeamModel model)
        {
            if (model != null)
            { 
                model.UpdateBy = UserName;
                model.UpdateDate = DateTime.Now;

                var result = await Client.SaveAsync(TeamModel.MapModelToObject(model));
                if (!result.IsSuccessStatusCode)
                {
                    ModelState.AddModelError("", result.Error.Content);
                }
            }

            return Json(model);
        }

        [AcceptVerbs("Post")]
        public async Task<ActionResult> Destroy([DataSourceRequest] DataSourceRequest request, List<TeamModel> models)
        {
            if (models != null)
            {
                foreach (var model in models)
                {
                    var result = await Client.DeleteAsync(model.ID);
                    if (!result.IsSuccessStatusCode)
                    {
                        ModelState.AddModelError("", result.Error.Message);
                    }
                }
            }

            return Json(models.ToDataSourceResult(request, ModelState));
        }


        [HttpGet]
        public async Task<bool> CheckTeamName(string name)
        {
            var result = await Client.SearchAsync(new TeamCriteria() { Name = name });
            if(result.Error == null)
            {
                var team = result.Content;
                if(team !=null && team.Count > 0)
                {
                    return true;

                }
            }
            return false;
        }


        [AcceptVerbs("Get")]
        public async Task<bool> CheckTeamDeactive(int teamID)
        {
            var result = await EmployeeService.SearchAsync(new Employee() { Team = new Team() { Id= teamID } });
            if(result.Error == null  && result.Content != null  && result.Content.Count > 0)
            {
                return true;
            }
            return false;
        }
        [HttpGet]
        [Consumes("application/json")]
        public async Task<JsonResult> GetManager(string text)
        {
            var user = ApplicationSession.GetUser();
            var currentEmployee = user?.Employee;
            var ownerId = currentEmployee.ID;
            var employee = user.IsAdmin ? new Employee() : new Employee() { TeamOwnerId = ownerId };
            var result = await EmployeeService.SearchAsync(employee);
            var employees = result.Content;
            if(employees != null && employees.Count > 0 )
            {
                var list = employees.Select(s => new DropDownItemModel { DataID = s.Id, DataText = s.DisplayName }).ToList();
                if (!employees.Exists(o=> o.Id .Equals(currentEmployee.ID))) {
                    var item = new DropDownItemModel() { DataID = currentEmployee.ID, DataText = currentEmployee.DisplayName };
                    list.Add(item);
                }
                return Json(list);
            }

            return Json(new List<DropDownItemModel>() { new DropDownItemModel() { DataID = currentEmployee.ID, DataText = currentEmployee.DisplayName } });
            
           
        }

    }
}