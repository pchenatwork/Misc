﻿using EVO.TimesheetPortal.Site.App_Classes;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class BaseController<T> : BaseController where T : class
    {
        protected T Client;

        public BaseController()
        {
        }

        public BaseController(T t)
        {
            Client = t;
        }
    }

    [Authorize]
    [AutoValidateAntiforgeryToken]
    public class BaseController : Controller
    {
        public string UserName { get { return User.Identity.Name; } }

        public override Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            if (ApplicationSession.GetUser()?.User.MenuItems == null && HttpContext.Request.IsAjaxRequest())
            {
                HttpContext.Session.Clear();
                HttpContext.SignOutAsync(Microsoft.AspNetCore.Authentication.Cookies.CookieAuthenticationDefaults.AuthenticationScheme);
                context.Result = new StatusCodeResult(400);
                return Task.CompletedTask;
            }
            return base.OnActionExecutionAsync(context, next);
        }
    }
}