﻿using Azure.Core;
using EVO.TimesheetPortal.Entity;
using EVO.TimesheetPortal.Site.Models;
using EVO.TimesheetPortal.Site.Service;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class SettingController : BaseController<ISettingService>
    {
        private ISettingService SettingService;

        public SettingController(ISettingService settingService)
        {
            SettingService = settingService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<ActionResult> Read([DataSourceRequest] DataSourceRequest request)
        {
            var apiResponse = await SettingService.SearchAsync(new Entity.Setting());
            var list = apiResponse.Content.ToList();
            return Json(list.ToDataSourceResult(request));
        }

        [AcceptVerbs("Post")]
        public async Task<ActionResult> Create([DataSourceRequest] DataSourceRequest request, List<SettingModel> models)
        {
            if (models != null && ModelState.IsValid)
            {
                foreach (var model in models)
                {
                    var entity = new Setting
                    {
                        Id = model.Id,
                        Description = model.Description,
                        KeyVal = model.KeyVal,
                        Name = model.Name,
                        OrderSeq = model.OrderSeq,
                        ParentId = model.ParentId,
                        TextVal = model.TextVal
                    };
                    var result = await SettingService.SaveAsync(entity);
                    if (result != null)
                    {
                        model.Id = result.Content.Id;
                    }
                }
            }

            return Json(models.ToDataSourceResult(request, ModelState));
        }

        [AcceptVerbs("Post")]
        public async Task<ActionResult> Update([DataSourceRequest] DataSourceRequest request, List<SettingModel> models)
        {
            if (models != null && ModelState.IsValid)
            {
                foreach (var model in models)
                {
                    var entity = new Setting
                    {
                        Id = model.Id,
                        Description = model.Description,
                        KeyVal = model.KeyVal,
                        Name = model.Name,
                        OrderSeq = model.OrderSeq,
                        ParentId = model.ParentId,
                        TextVal = model.TextVal
                    };
                    await SettingService.SaveAsync(entity);
                }
            }

            return Json(models.ToDataSourceResult(request, ModelState));
        }

        [AcceptVerbs("Post")]
        public async Task<ActionResult> Destroy([DataSourceRequest] DataSourceRequest request, List<SettingModel> models)
        {
            if (models != null)
            {
                foreach (var model in models)
                {
                    await SettingService.DeleteAsync(model.Id);
                }
            }

            return Json(models.ToDataSourceResult(request, ModelState));
        }


        [HttpGet]
        [Consumes("application/json")]
        public async Task<JsonResult> GetCountries()
        {
            var apiResponse = await SettingService.SearchAsync(new Entity.Setting() { Name = "CountryCode" });
            var list = apiResponse.Content.ToList();
            return Json(list);
        }

        [HttpGet]
        [Consumes("application/json")]
        public async Task<JsonResult> GetActivity()
        {
            var apiResponse = await SettingService.SearchAsync(new Entity.Setting() { Name = "ProjectActivityId" });
            var list = apiResponse.Content?.Select(s => new DropDownItemStringKeyModel { DataID = s.KeyVal, DataText = s.TextVal }).ToList();
            return Json(list);
        }

        [HttpGet]
        [Consumes("application/json")]
        public async Task<JsonResult> GetProjectType()
        {
            var apiResponse = await SettingService.SearchAsync(new Entity.Setting() { Name = "ProjectTypeId" });
            var list = apiResponse.Content.ToList();
            return Json(list);
        }

        [HttpGet]
        [Consumes("application/json")]
        public async Task<JsonResult> GetProjectStatus()
        {
            var apiResponse = await SettingService.SearchAsync(new Entity.Setting() { Name = "ProjectStatusId" });
            var list = apiResponse.Content.ToList();
            return Json(list);
        }
    }
}