﻿using EVOUserWSServiceReference;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using EVO.TimesheetPortal.Site.App_Classes;
using TimeSheetTrackerCore.Site.Models;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class MenuItemController : BaseController
    {
        public IActionResult Index()
        {
            return View();
        }

        public ActionResult Menu()
        {
            var user = ApplicationSession.GetUser();

            List<MenuItem> allMenuItems = user?.User.MenuItems.ToList();
            allMenuItems.RemoveAll(x => Convert.ToBoolean(x.IsVisible) == false);
            List<MenuItemModel> menuItems = new MenuItemModel().MapObjectToModel(allMenuItems);
            return PartialView("_Menu", menuItems);
        }
    }
}