﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using EVO.TimesheetPortal.Site.Service;
using Microsoft.AspNetCore.Mvc;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public  class TimesheetExecutiveController : BaseController<ITimeSheetActivityService>
    {
        private readonly ITeamService TeamService;

        public TimesheetExecutiveController(ITeamService teamService)
        {
            TeamService = teamService;
        }

        public async Task<ActionResult> Executive()
        {
            var allTeams = await TeamService.SearchAsync(new Entity.TeamCriteria());

            var dataTable = new DataTable();
            var keys = new DataColumn[1];

            var idColumn = new DataColumn();
            idColumn.DataType = typeof(int);
            idColumn.ColumnName = "ProjectID";
            keys[0] = idColumn;
            dataTable.Columns.Add(idColumn);
            dataTable.Columns.Add("Project", typeof(string));
            foreach (var team in allTeams.Content)
            {
                dataTable.Columns.Add(team.Name, typeof(string));
            }
            dataTable.PrimaryKey = keys;

            return View(dataTable);
        }
    }
}
