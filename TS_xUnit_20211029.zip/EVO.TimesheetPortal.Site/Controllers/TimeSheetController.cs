using Azure.Core;
using EVO.TimesheetPortal.Entity;
using EVO.TimesheetPortal.Site.App_Classes;
using EVO.TimesheetPortal.Site.Models;
using EVO.TimesheetPortal.Site.Service;
using EVOUserWSServiceReference;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Identity.Client;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using EVO.Common.UtilityCore;
using DocumentFormat.OpenXml.Spreadsheet;
using System.IO;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class TimeSheetController : BaseController<ITimeSheetActivityService>
    {
        private readonly ITeamService TeamService;
        private readonly ITimeSheetActivityService ActivityService;

        private IEmployeeActivityMapService MapService;
        private IProjectService ProjectService;
        private IEmployeeService EmployeeService;
        private ITimeSheetService TimeSheetService;
        public TimeSheetController(ITimeSheetActivityService activityService,
            IProjectService projectService,
            IEmployeeActivityMapService mapService,
            IEmployeeService employeeService,
            ITimeSheetService timeSheetService, ITeamService teamService)
        {
            ActivityService = activityService;
            ProjectService = projectService;
            MapService = mapService;
            EmployeeService = employeeService;
            TimeSheetService = timeSheetService;
            TeamService = teamService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<ActionResult> Executive()
        {
            var timeSheet = await TimeSheetService.GetOutlookByTeamResource(DateTime.UtcNow.ToString("yyyyMM"));

            return View(timeSheet.Content);
        }

        [HttpPost]
        public async Task<JsonResult> ExecutiveApproval(string periodCode)
        {
            var user = ApplicationSession.GetUser();
            var saveResult = new SaveResult() { Success = true };
            var result  = await TimeSheetService.ExecutiveApproval(periodCode, user.DisplayName);
            if(result.Error != null)
            {
                saveResult.Success = false;
                saveResult.ErrorDescription = "Executive Approval Error.";
            }
            else
            {
                saveResult.Success = result.Content;
            }
            return Json(saveResult);
        }


        public async Task<JsonResult> GetResourView([DataSourceRequest] DataSourceRequest request, string periodCode)
        {
            var data = await TimeSheetService.GetOutlookByTeamResource(periodCode);
            if(data.Content != null)
            {
                return Json(data.Content.Details.ToDataSourceResult(request));
            }
            return Json(new List<Timesheet>().ToDataSourceResult(request));
        }

        public async  Task<ActionResult> GetResourceDetail(int projectId=1, int teamId=9, string periodCode="")
        {

            var data = await TimeSheetService.GetOutlookByTeamProject(teamId, projectId, periodCode);
            var result = data.Content;
            result = result ?? new Timesheet();
            return PartialView("ResourceDetail", result);
        }


        public async Task<ActionResult>  GetExecutionSummary(string periodCode)
        {

            var data = await TimeSheetService.GetOutlookByExecutiveSummary(periodCode);

            if (data.Content != null)
            {

                JsonSerializerOptions options = new JsonSerializerOptions()
                { Converters = { new DataTableJsonConverter() }, WriteIndented = true };

                var dataTable = System.Text.Json.JsonSerializer.Deserialize<DataTable>(data.Content, options);
                var projectData = await TimeSheetService.GetOutlookProjectSummary(periodCode);
               
                var projectSummaryTable = System.Text.Json.JsonSerializer.Deserialize<DataTable>(projectData.Content,options);


                var projectSummary = DataTableUtil.ToEntityList<ProjectSummaryModel>(projectSummaryTable);

                dataTable.Columns.Add("Total");
                for(var i = 0; i < dataTable.Rows.Count; i++ )
                {
                    var row = dataTable.Rows[i];
                    var projectObj = row["Project"];
                    var projectName = projectObj != null ? projectObj.ToString(): "";
                    row["Total"] = 0.00;
                    if (!string.IsNullOrWhiteSpace(projectName))                   
                    {
                        var projectItem = projectSummary.Where(o => o.ProjectName.Equals(projectName)).FirstOrDefault();
                        if(projectItem != null)
                        {
                            row["Total"] = projectItem.Hours;
                        }
                    }
                }


                return Json(dataTable);
            }
            return Json(null);
        }

        public async Task<JsonResult> GetTimesheetMonthly([DataSourceRequest] DataSourceRequest request, TimesheetSearchModel searchModel)
        {
            var user = ApplicationSession.GetUser();
            var timesheetData = (await ActivityService.GetByMonthAsync(user.Employee.ID, searchModel.StartDate.GetValueOrDefault(DateTime.Now), searchModel.EndDate.GetValueOrDefault(DateTime.Now))).Content;
            if (timesheetData == null)
            {
                timesheetData = new List<TimesheetActivity>();
            }
            List<TimesheetMonthModel> monthList = new List<TimesheetMonthModel>();
            foreach (var timeData in timesheetData)
            {
                monthList.Add(new TimesheetMonthModel()
                {
                    Start = new DateTime(timeData.ActivityDate.Ticks, DateTimeKind.Utc),
                    End = new DateTime(timeData.ActivityDate.Ticks, DateTimeKind.Utc),
                    ResourceID = timeData.EmployeeId,
                    Title = timeData.Hours.ToString(),
                    Description = timeData.Hours.ToString()
                });
            }
            // activityService.
            return Json(monthList.ToDataSourceResult(request));
        }

        public async Task<ActionResult> Readv2([DataSourceRequest] DataSourceRequest request, DateTime activityDate)
        {
            var user = ApplicationSession.GetUser();
            int employeeId = user.Employee.ID;
            var timesheetData = (await ActivityService.GetByDateAsync(employeeId, activityDate)).Content;
            if (timesheetData == null)
            {
                timesheetData = new List<TimesheetActivity>();
            }
            var list = timesheetData.Select(s => TimesheetActivityModel.MappingFromEntity(s)).ToList();
            return Json(list.ToDataSourceResult(request));
        }

        public ActionResult CreateTask()
        {
            var model = new NewTaskModel();
            return PartialView("Task", model);
        }

        [HttpGet]
        [Consumes("application/json")]
        public async Task<JsonResult> GetProjectList()
        {
            var searchEntity = new Entity.Project();
            searchEntity.Teams = new Collection<Team> { new Team { Id = ApplicationSession.GetUser().Employee?.Team?.ID ?? 0 } };
            searchEntity.IsAdmin = ApplicationSession.IsITExecutive || ApplicationSession.IsProjectAdmin;
            searchEntity.QueryStatus = new Collection<int> { ProjectStatusEnum.Approved };

            var apiResponse = await ProjectService.SearchAsync(searchEntity);

            return Json(apiResponse.Content.Select(s => new DropDownItemModel { DataID = s.Id, DataText = s.Name }));
        }

        [HttpPost]
        public async Task<JsonResult> CreateTaskForm(TimesheetCreateModel model)
        {
            var saveResult = new SaveResult() { Success = false };
            var user = ApplicationSession.GetUser();
            int employeeId = user.Employee.ID;
            var dailyData = (await ActivityService.GetByDateAsync(employeeId, model.ActivityDate)).Content;
            if (dailyData != null && dailyData.Where(s => s.ProjectId == model.ProjectId && s.ActivityId == model.ActivityId).Count() > 0)
            {
                saveResult.Success = false;
                return Json(saveResult);
            }
            TimesheetActivity entity = new TimesheetActivity()
            {
                ActivityDate = model.ActivityDate,
                EmployeeId = employeeId,
                ProjectId = model.ProjectId,
                ActivityId = model.ActivityId,
                CreateBy = user.DisplayName
            };
            saveResult.Success = (await ActivityService.InsertAsync(entity)).Content?.Id > 0;
            var newData= (await ActivityService.GetByCriteria(entity)).Content;
            saveResult.AssociatedObject = newData;
            return Json(saveResult);
        }

        [HttpPost]
        public async Task<JsonResult> UpdateTask(TimesheetUpdateModel model)
        {
            var saveResult = new SaveResult() { Success = false };
            if (ModelState.IsValid)
            {
                var user = ApplicationSession.GetUser();

                TimesheetActivity entity = new TimesheetActivity();
                if (model.IsTimeSheet == 1)
                {
                    entity = (await ActivityService.GetAsync(model.Id)).Content;
                    entity.Hours = model.Hours;
                    entity.Description = model.Description;
                    entity.UpdateBy = user.DisplayName;
                }
                else
                {
                    entity.ProjectId = model.ProjectId;
                    entity.ActivityId = model.ActivityId;
                    entity.ActivityDate = model.ActivityDate;
                    entity.Hours = model.Hours;
                    entity.Description = model.Description;
                    entity.CreateBy = user.DisplayName;
                    entity.EmployeeId = user.Employee.ID;
                }
                saveResult.Success = (await ActivityService.InsertAsync(entity)).Content?.Id>0;
                var newData = (await ActivityService.GetByCriteria(entity)).Content;
                saveResult.AssociatedObject = newData;
            }
         
            return Json(saveResult);
        }

        [HttpPost]
        public async Task<JsonResult> RemoveTask(TimesheetRemoveModel model)
        {
            var saveResult = new SaveResult() { Success = true };
            if (model.IsTimeSheet == 1)
            {
                saveResult.Success = (await ActivityService.DeleteAsync(model.Id)).Content;
            }
            else
            {
                saveResult.Success = (await MapService.DeleteAsync(model.Id)).Content;
            }
            return Json(saveResult);
        }
        #region Timesheet Approval
        public ActionResult Approval()
        {
            //var timesheetStatus = (IEnumerable<DropDownItemModel>)ViewData["timesheetStatus"];
            //ViewData["timesheetStatus"] = timesheetStatus.Where(t => t.DataText != "Draft");

            return View();
        }

        [HttpGet]
        [Consumes("application/json")]
        public async Task<ActionResult> GetResources()
        {
            //need admin permission to get all resources.
            var list = new List<DropDownItemStringKeyModel>();
            if (ApplicationSession.IsTimesheetAdmin || ApplicationSession.GetUser()?.Employee?.Team?.Owner?.ID == ApplicationSession.GetUser()?.Employee?.ID)
            {
                int teamID = ApplicationSession.GetUser()?.Employee?.Team?.ID ?? -1;
                var userList = (await EmployeeService.GetAllAsync()).Content;
                var filterUserData = ApplicationSession.IsTimesheetAdmin ? userList : userList.Where(w => w.Team?.Id == teamID);
                foreach (var p in filterUserData)
                {
                    list.Add(new DropDownItemStringKeyModel() { DataText = p.DisplayName, DataID = p.Id.ToString() });
                }
                if (!list.Any(a => a.DataID == ApplicationSession.GetUser()?.Employee?.ID.ToString()) && ApplicationSession.GetUser().Employee != null)
                {
                    list.Add(new DropDownItemStringKeyModel
                    {
                        DataID = ApplicationSession.GetUser().Employee.ID.ToString(),
                        DataText = ApplicationSession.GetUser().Employee.DisplayName
                    });
                }
                list.OrderBy(s => s.DataText);
                var employee = ApplicationSession.GetUser().Employee;
                if (employee != null)
                {
                    var firstItem = list.Single(r => r.DataID == employee.ID.ToString());
                    list.Remove(firstItem);
                    list.Insert(0, firstItem);
                }
            }
            else
            {
                var employee = ApplicationSession.GetUser().Employee;
                var firstItem = new DropDownItemStringKeyModel { DataID = employee?.ID.ToString(), DataText = employee?.DisplayName ?? string.Empty };
                list.Insert(0, firstItem);
            }

            return Json(list);
        }

        public async Task<JsonResult> Approval_Read([DataSourceRequest] DataSourceRequest request, string periodCode, int resourceId)
        {
            var timesheetData = (await TimeSheetService.GetOutlookByEmployee(resourceId, periodCode)).Content;
            if (timesheetData == null)
            {
                return Json(new List<Timesheet>().ToDataSourceResult(request));
            }
            return Json(timesheetData?.Details.ToDataSourceResult(request));
        }

        public async Task<ActionResult> GetTimesheetDetail(string periodCode, int resourceId, int projectId)
        {
            var timesheetData = (await TimeSheetService.GetOutlookByEmployeeProject(resourceId, projectId, periodCode)).Content;
            //  var activityList = timesheetData == null ? new Collection<TimesheetActivity>() : timesheetData.Activities;
            return PartialView("TimeSheetDetail", timesheetData);
        }
        /// <summary>
        /// Create by PCHEN for DEMO purpose using ViewComponent
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <param name="PeriodCode"></param>
        /// <returns></returns>
        public IActionResult ReloadManagerApproval(int EmployeeId, string PeriodCode)
        {
            return ViewComponent("ManagerApproval", new { EmployeeId = EmployeeId, PeriodCode = PeriodCode });
        }


        [HttpPost]
        public async Task<JsonResult> ManagerApproval(int EmployeeId, string PeriodCode)
        {
            var user = ApplicationSession.GetUser();
            var saveResult = new SaveResult() { Success = true };
            saveResult.Success = (await TimeSheetService.ManagerApproval(EmployeeId, PeriodCode, user.DisplayName)).Content;
            return Json(saveResult);
        }

        #endregion
        #region Summary Report
        //private List<TimesheetModel> GetTimeSheetSummary(int period)
        //{
        //    var queryModel = new TimeSheetQueryEntity();
        //    queryModel.PeriodMonthID = period;
        //    queryModel.IsAdmin = ApplicationSession.IsITExecutive;
        //    var teams = new List<TeamEntity>();
        //    ApplicationSession.GetUser().LoginUserTeam.ForEach(f => teams.Add(new TeamEntity { TeamID = f.TeamID }));

        //    queryModel.Teams = teams.ToArray();
        //    return Client.GetTimeSheetSummary(queryModel);
        //}
        #endregion
        #region Trend Report
        public async Task<ActionResult> GetTimesheetTrend(string period, int employeeid)
        {
            var trendList = (await TimeSheetService.GetTrendData(employeeid, period)).Content;
            if (trendList == null)
            {
                trendList = new List<Timesheet>();
            }
            string employeeName = trendList?.First().ResourceName;
            int i = 1;
            List<GridColumn> monthCols = new List<GridColumn>();
            List<string> monthColsArr = new List<string>();
            List<decimal> nums = new List<decimal>();
            StringWriter sw = new StringWriter();
            JsonWriter writer = new JsonTextWriter(sw);
            writer.WriteStartObject();
            if (trendList!=null && trendList.Count>0)
            {
                foreach (var data in trendList)
                {
                    string fieldName = "Month" + i.ToString();
                    monthCols.Add(new GridColumn() { field = fieldName, title = data.PeriodCode });
                    monthColsArr.Add(data.PeriodCode);
                    nums.Add(data.Hours);
                    writer.WritePropertyName(fieldName);
                    writer.WriteValue(data.Hours);
                    i++;
                }
            }
            writer.WriteEndObject();
            writer.Flush();
            string jsonText = sw.GetStringBuilder().ToString();
            // monthCols.Reverse();
            ViewData["monthCols"] = System.Text.Json.JsonSerializer.Serialize(monthCols);
            ViewData["monthColsArr"] = monthColsArr.ToArray();
            ViewData["employeeid"] = employeeid;
            ViewData["employeeName"] = employeeName;
            ViewData["trendData"] = jsonText;
            ViewData["lineData"] = nums;
            return PartialView("TimesheetTrend");
        }
        #endregion
    }


}