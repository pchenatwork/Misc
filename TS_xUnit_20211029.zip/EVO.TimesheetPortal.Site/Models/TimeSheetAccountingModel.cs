﻿using EVO.TimesheetPortal.Entity;

namespace EVO.TimesheetPortal.Site.Models
{
    public class TimeSheetAccountingModel : BaseModel
    {
        public int ProjectID { get; set; }
        public string ProjectManager { get; set; }
        public string ProjectName { get; set; }
        public string Activity { get; set; }
        public string Number { get; set; }
        public string ProjectType { get; set; }
        public string Description { get; set; }
        public decimal Hours { get; set; }
        public int ResourceID { get; set; }
        public string UserID { get; set; }
        public string ResourceName { get; set; }
        public string ResourceManager { get; set; }
        public string Status { get; set; }
        public string CapProjectType { get; set; }
        public string CapProjectPhase { get; set; }
        public string FinalCap { get; set; }
        public string Department { get; set; }
        public string Country { get; set; }
        public string PayLevel { get; set; }
        public decimal AverageRate { get; set; }
        public decimal Salary { get; set; }
        public decimal Taxes { get; set; }
        public decimal Benefits { get; set; }
        public decimal FourZeroOneK { get; set; }
        public decimal Total { get; set; }
        public bool ProjectTypeCap { get; set; }
        public bool PhaseTypeCap { get; set; }

        public static TimeSheetAccountingModel MappingFromEntity(TimeSheetAccounting entity)
        {
            if (entity == null)
            {
                return new TimeSheetAccountingModel();
            }

            return new TimeSheetAccountingModel
            {
                Activity = entity.Activity,
                CapProjectPhase = entity.PhaseTypeCap ? "Yes" : "No",
                ProjectTypeCap = entity.ProjectTypeCap,
                CapProjectType = entity.ProjectTypeCap ? "Yes" : "No",
                PhaseTypeCap = entity.PhaseTypeCap,
                Department = entity.Department,
                Country = entity.Country,
                Description = entity.Description,
                Hours = entity.Hours,
                ResourceID = entity.ResourceID,
                ResourceManager = entity.ResourceManager,
                ResourceName = entity.ResourceName,
                Number = entity.Number,
                ProjectID = entity.ProjectID,
                ID = entity.Id,
                ProjectManager = entity.ProjectManager,
                ProjectName = entity.ProjectName,
                ProjectType = entity.ProjectType,
                Status = entity.Status,
                UserID = entity.UserID,
                FinalCap = entity.ProjectTypeCap && entity.PhaseTypeCap ? "Yes" : "No",
                PayLevel = entity.PayLevel
            };
        }
    }
}