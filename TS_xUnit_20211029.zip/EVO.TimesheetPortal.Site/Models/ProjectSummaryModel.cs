﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Models
{
    public class ProjectSummaryModel
    {
        public int ProjectId { get; set; }

        public string ProjectName { get; set; }

       public  decimal  Hours { get; set; }
    }
}
