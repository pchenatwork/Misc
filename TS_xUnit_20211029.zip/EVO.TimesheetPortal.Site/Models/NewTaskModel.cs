﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Models
{
    public class NewTaskModel
    {
        public int ResourceID { get; set; }
        public int ProjectId { get; set; }
        public int ActivityId { get; set; }
        public DateTime ActivityDate { get; set; }
    }
}
