﻿using System.ComponentModel.DataAnnotations;

namespace EVO.TimesheetPortal.Site.Models
{
    public class SettingModel
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string KeyVal { get; set; }

        [Required]
        public string TextVal { get; set; }

        public string Description { get; set; }

        public int ParentId { get; set; }

        public int OrderSeq { get; set; }
    }
}