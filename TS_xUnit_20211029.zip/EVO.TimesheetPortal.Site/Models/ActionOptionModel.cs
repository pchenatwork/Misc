﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TimeSheetTrackerCore.Site.Models
{
    /// <summary>
    /// To compose and pass along the ActionOptions to HTML
    /// For JQuery to do further processing
    /// </summary>
    public class ActionOptionModel
    {
        /// <summary>
        /// Action Type Id. 1: Popup; 2: Redirect to new page; 3: Direct form post;
        /// </summary>
        public int T { get; set; }
        /// <summary>
        /// Name
        /// </summary>
        public string N { get; set; }
        /// <summary>
        /// Value
        /// </summary>
        public string V { get; set; }
        /// <summary>
        /// Might have some Extra value in addition to V (Value)
        /// </summary>
        public string E { get; set; }
    }
}
