﻿using System.ComponentModel.DataAnnotations.Schema;

namespace EVO.TimesheetPortal.Site.Models
{
    public class AccountingModel
    {
        [Column("Pay Level")]
        public string PayLevel { get; set; } = string.Empty;

        [Column("Average Rate")]
        public decimal AverageRate { get; set; }

        [Column("Tax Rate")]
        public decimal TaxRate { get; set; }

        [Column("Benefit Rate")]
        public decimal BenefitRate { get; set; }

        [Column("401K Rate")]
        public decimal FourZeroOneKRate { get; set; }

        [Column("Country Code")]
        public string CountryCode { get; set; } = string.Empty;

        [Column("Department Code")]
        public string DepartmentCode { get; set; } = string.Empty;
    }
}