﻿using EVO.TimesheetPortal.Entity;
using System;
using System.ComponentModel.DataAnnotations;

namespace EVO.TimesheetPortal.Site.Models
{
    public class TimesheetActivityModel : BaseModel
    {
        public int EmployeeId { get; set; }
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public int ActivityId { get; set; }
        public string ActivityName { get; set; }
        public DateTime ActivityDate { get; set; }

        [Required]
        [UIHint("NumericTextBox")]
        [Range(0, 999)]
        public decimal Hours { get; set; }

        [DataType(DataType.Text)]
        [StringLength(2000)]
        [UIHint("TextBox")]
        public string Description { get; set; }

        public int SourceId { get; set; }
        public int SubmissionId { get; set; }
        public int IsTimeSheet { get; set; }

        public static TimesheetActivityModel MappingFromEntity(TimesheetActivity entity)
        {
            if (entity == null)
            {
                return new TimesheetActivityModel();
            }
            var model = new TimesheetActivityModel
            {
                ActivityDate = entity.ActivityDate,
                ActivityId = entity.ActivityId,
                Description = entity.Description,
                Hours = entity.Hours,
                ActivityName = entity.ActivityName,
                CreateBy = entity.CreateBy,
                CreateDate = entity.CreateDate,
                EmployeeId = entity.EmployeeId,
                Extra = entity.Extra,
                ID = entity.Id,
                ProjectId = entity.ProjectId,
                SubmissionId = entity.SubmissionId,
                IsTimeSheet = entity.IsTimeSheet,
                ProjectName = entity.ProjectName,
                SourceId = entity.SourceId,
                UpdateBy = entity.UpdateBy,
                UpdateDate = entity.UpdateDate,
                IsReadonly=entity.SubmissionId>0
            };
            return model;
        }
    }
}