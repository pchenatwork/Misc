﻿using EVO.TimesheetPortal.Entity;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json;
using TimeSheetTrackerCore.Site.Models;

namespace EVO.TimesheetPortal.Site.Models
{
    public class ProjectModel : BaseModel
    {
        [Required]
        [StringLength(100, ErrorMessage = "The Name length cannot greater than 100")]
        public string Name { get; set; }

        [Required(ErrorMessage = "The Type field is required.")]
        public int TypeID { get; set; }

        [StringLength(300, ErrorMessage = "The Description length cannot greater than 300.")]
        public string Description { get; set; }

        public string Type { get; set; }
        [StringLength(20, ErrorMessage = "The PIR NO. length cannot greater than 20.")]
        public string PIRNo { get; set; }
        public string Phase { get; set; }
        public List<int> PhaseList { get; set; }

        [Required(ErrorMessage = "The Phase field is required.")]
        public List<DropDownItemStringKeyModel> Phases { get; set; }

        public string Team { get; set; }
        public List<int> TeamList { get; set; }

        [Required(ErrorMessage = "The Team field is required.")]
        public List<DropDownItemModel> Teams { get; set; }

        [Range(0, 100000, ErrorMessage = "The Est. Hours cannot greater than 100,000.")]
        public decimal EstimatedHours { get; set; }

        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? ProdDate { get; set; }
        public string Country { get; set; }
        public string RequestedBy { get; set; }
        public string Status { get; set; }
        public string ProjectNo { get; set; }

        public static ProjectModel MappingFromEntity(Project item)
        {
            var project = new ProjectModel();
            if (item == null)
            {
                return project;
            }
            project.Country = item.CountryCode;
            project.ID = item.Id;
            project.EstimatedHours = item.EstHrs;
            project.Description = item.Description;
            project.Name = item.Name;
            project.StartDate = item.StartDate == new DateTime(1900,1,1) ? DateTime.MinValue : item.StartDate;
            project.EndDate = item.EndDate == new DateTime(1900, 1, 1) ? DateTime.MinValue : item.EndDate;
            project.ProdDate = item.ProdDate == new DateTime(1900, 1, 1) ? DateTime.MinValue : item.ProdDate;
            project.ProjectNo = item.ProjectNo;

            project.Teams = item.Teams.Select(s => new DropDownItemModel { DataID = s.Id, DataText = s.Name }).ToList();
            project.Team = string.Join(",", item.Teams.Select(s => s.Name));
            project.Status = item.StatusName;
            project.RequestedBy = item.RequestBy;
            project.PIRNo = item.PIRNum;
            project.TypeID = item.TypeId;
            project.Type = item.Type;
            project.Phase = string.Join(",", item.Activities.Select(s => s.TextVal));
            project.Phases = item.Activities.Select(s => new DropDownItemStringKeyModel { DataID = s.KeyVal, DataText = s.TextVal }).ToList();
            List<ActionOptionModel> a = new List<ActionOptionModel>();
            switch (project.Status.ToLower())
            {
                case "approved":
                    a.Add(new ActionOptionModel() { T = 1, N = "Edit", V = $"edit:{item.Id}", E = item.Id.ToString() });
                    a.Add(new ActionOptionModel() { T = 3, N = "Impair", V = $"impair:{item.Id}", E = item.Id.ToString() });
                    a.Add(new ActionOptionModel() { T = 3, N = "Close", V = $"close:{item.Id}", E = item.Id.ToString() });
                    break;

                case "rejected":
                    a.Add(new ActionOptionModel() { T = 1, N = "Edit", V = $"edit:{item.Id}", E = item.Id.ToString() });
                    a.Add(new ActionOptionModel() { T = 3, N = "Re-Submit", V = $"resubmit:{item.Id}", E = item.Id.ToString() });
                    a.Add(new ActionOptionModel() { T = 3, N = "Delete", V = $"delete:{item.Id}", E = item.Id.ToString() });
                    break;

                case "pending approval":
                    project.IsReadonly = true;
                    break;

                default:
                    break;
            }
            project.Extra = JsonSerializer.Serialize(a);
            return project;
        }

        public static Project MappingFromModel(ProjectModel model)
        {
            var team = new Collection<Team>();
            foreach (int item in model.TeamList)
            {
                team.Add(new Team { Id = item });
            }

            var activity = new Collection<Setting>();
            foreach (int item in model.PhaseList)
            {
                activity.Add(new Setting { Id = item, KeyVal = $"{item}" });
            }
            var entity = new Project();
            entity.Id = model.ID;
            entity.Name = model.Name;
            entity.Description = model.Description;
            entity.CreateBy = model.UpdateBy;
            entity.UpdateBy = model.UpdateBy;
            entity.EstHrs = model.EstimatedHours;
            entity.Teams = team;
            entity.TypeId = model.TypeID;
            entity.Activities = activity;
            entity.StatusId = ProjectStatusEnum.PendAppv;
            entity.RequestBy = model.RequestedBy;
            entity.CountryCode = model.Country;
            entity.StartDate = model.StartDate ?? DateTime.MinValue;
            entity.EndDate = model.EndDate ?? DateTime.MinValue;
            entity.ProdDate = model.ProdDate ?? DateTime.MinValue;
            entity.PIRNum = model.PIRNo;
            return entity;
        }
    }
}