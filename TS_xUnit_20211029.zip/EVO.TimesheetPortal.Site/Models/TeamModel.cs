﻿using EVO.TimesheetPortal.Entity;
using EVO.TimesheetPortal.Site.App_Classes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Site.Models
{
    public class TeamModel: BaseModel
    {      
        [Required]
        public string Name { get; set; }
        
        public string DeptCode { get; set; }

        public string ShortName { get; set; }
       
        public EmployeeModel Manager { get; set; }
      
        public EmployeeModel Owner { get; set; }

        [Required(ErrorMessage ="The Team Owner is required.")]
        public int TeamOwner { get; set; }


        public static List<TeamModel> MapObjectToModel(List<Team> list)
        {
            var returnObj = new List<TeamModel>();
            if (list == null)
            {
                return returnObj;
            }
           // var isEditable = ApplicationSession.GetPermissionAccessByKey("Team_Edit");
            foreach (var entity in list)
            {
                TeamModel model = new TeamModel();
                model.ID = entity.Id;
                model.Name = entity.Name;
                model.ShortName = entity.ShortName;
                model.IsActive = entity.IsActive;
                model.Manager = entity.Manager == null ? new EmployeeModel() : new EmployeeModel() { ID = entity.Manager.Id, DisplayName = entity.Manager.DisplayName };
                model.Owner = entity.Owner == null ? new EmployeeModel() : new EmployeeModel() { ID = entity.Owner.Id, DisplayName = entity.Owner.DisplayName};
                model.TeamOwner = model.Owner.ID;
                model.UpdateBy = entity.UpdateBy;
                model.UpdateDate = entity.UpdateDate;
                model.DeptCode = entity.DeptCode;
                model.CreateBy = entity.CreateBy;
                model.CreateDate = entity.CreateDate;
                returnObj.Add(model);
            }
            return returnObj;
        }

        public static Team MapModelToObject(TeamModel model)
        {
            var entity = new Team();
            entity.Id = model.ID;
            entity.Name = model.Name;
            entity.ShortName = model.ShortName;
            entity.ManagerId = (model.Manager?.ID).GetValueOrDefault();
            entity.Manager = model.Manager == null ?  new Employee(): new Employee() { Id= model.Manager.ID, DisplayName =model.Manager.DisplayName};
            entity.DeptCode = model.DeptCode;
            entity.OwnerId = (model.Owner?.ID).GetValueOrDefault(); 
            entity.Owner = model.Owner == null ? new Employee() : new Employee() { Id = model.Owner.ID, DisplayName = model.Owner.DisplayName };
            entity.CreateBy = model.CreateBy;
            entity.CreateDate = model.CreateDate;
            entity.UpdateBy = model.UpdateBy;
            entity.UpdateDate = model.UpdateDate;
           
            return entity;
        }

        public static TeamModel MapEntiyToModel(Team entity)
        {
            var model = new TeamModel();
             model.ID = entity.Id;
            model.ID = entity.Id;
            model.Name = entity.Name;
            model.ShortName = entity.ShortName;
            model.IsActive = entity.IsActive;
            model.Manager = entity.Manager == null ? new EmployeeModel() : new EmployeeModel() { ID = entity.Manager.Id, DisplayName = entity.Manager.DisplayName };
            model.Owner = entity.Owner == null ? new EmployeeModel() : new EmployeeModel() { ID = entity.Owner.Id, DisplayName = entity.Owner.DisplayName };
            model.TeamOwner = model.Owner.ID;
            model.UpdateBy = entity.UpdateBy;
            model.UpdateDate = entity.UpdateDate;
            model.DeptCode = entity.DeptCode;
            model.CreateBy = entity.CreateBy;
            model.CreateDate = entity.CreateDate;
            return model;
        }
    }
}
