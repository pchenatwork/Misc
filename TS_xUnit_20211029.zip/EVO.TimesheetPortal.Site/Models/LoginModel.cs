﻿using EVOUserWSServiceReference;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TimeSheetTrackerCore.Site.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = " ")]
        [DisplayName("User Name")]
        [StringLength(50)]
        public string UserName { get; set; }

        [Required(ErrorMessage = " ")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public bool IsAuthenticated { get; set; }

        [DataType(DataType.Text)]
        [StringLength(500)]
        public static string Message { get; set; }

        [DataType(DataType.Text)]
        [StringLength(500)]
        public string GroupPermissionMessage { get; set; }

        //public UserWP User { get; set; }

        public SaveResult SaveResult { get; set; }

        public User User { get; set; }
    }
}