﻿using EVO.TimesheetPortal.Entity;
using EVO.TimesheetPortal.Site.App_Classes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Site.Models
{

    public class ManagerModel
    {
         public int ID { get; set; }
        public string DisplayName { get; set; }
    }
    public class EmployeeModel: BaseModel
    { 
       
        [Required(ErrorMessage ="The Resource field is required.")]
        public string UserId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string DisplayName { get; set; }

    
        public string Email { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The Title length cannot greater than 100")]
        public string Title { get; set; }


        [Required (ErrorMessage = "The Job Grade field is required. ")]
        public int JobGradeId { get; set; }


        //[Required(ErrorMessage = "The Dept. field is requierd.")]
        public string DeptCode { get; set; }


        [Required(ErrorMessage = "The Country field is requierd.")]
        public string CountryCode { get; set; }


        public ManagerModel Manager { get; set; }

        public bool EmailAlert { get; set; }


        [Required(ErrorMessage ="The Team field is requierd.")]
        public TeamDropDownItemModel TeamItem { get; set; }

        public TeamModel Team { get; set; }

        public List<string> RoleNames { get; set; }

        public string RoleName { get; set; }


        public static List<EmployeeModel> MapEntitysToModels(List<Employee> list)
        {
            var returnObj = new List<EmployeeModel>();
            foreach (var entity in list)
            {
                EmployeeModel model = new EmployeeModel();
                model.ID = entity.Id;
              
                model.UserId = entity.UserId;
                model.DisplayName = entity.DisplayName;
                model.FirstName = entity.FirstName;
                model.LastName = entity.LastName;
                model.JobGradeId = entity.JobGradeId;
                model.Email = entity.Email;
               
                model.Title = entity.Title;
                model.TeamItem =  entity.Team == null ? new TeamDropDownItemModel() : new TeamDropDownItemModel() { DataID = entity.Team.Id, DataText = entity?.Team.Name, ShortName = entity?.Team.ShortName }; 
                model.RoleNames = entity.RoleNames.ToList();
                model.RoleName = model.RoleNames.FirstOrDefault();
                model.CountryCode = entity.CountryCode;
                model.DeptCode = entity.DeptCode;
                model.EmailAlert = entity.EmailAlert;
               
                model.Manager = entity.Manager ==null ?  new ManagerModel() : new ManagerModel() { ID =  entity.Manager.Id, DisplayName = entity?.Manager.DisplayName};

                model.IsActive = entity.IsActive;
                model.UpdateDate = entity.UpdateDate;
                model.UpdateBy = entity.UpdateBy;
                model.CreateBy = entity.CreateBy;
                model.CreateDate = entity.CreateDate;

                returnObj.Add(model);
            }
            return returnObj;
        }

        public  static EmployeeModel EntityToModel(Employee entity)
        {
            EmployeeModel model = new EmployeeModel();
            model.ID = entity.Id;

            model.UserId = entity.UserId;
            model.DisplayName = entity.DisplayName;
            model.FirstName = entity.FirstName;
            model.LastName = entity.LastName;
            model.JobGradeId = entity.JobGradeId;
            model.Email = entity.Email;

            model.Title = entity.Title;
            model.TeamItem = entity.Team == null ? new TeamDropDownItemModel() : new TeamDropDownItemModel() { DataID = entity.Team.Id, DataText = entity?.Team.Name, ShortName = entity?.Team.ShortName };
            model.RoleNames = entity.RoleNames.ToList();
            model.RoleName = model.RoleNames.FirstOrDefault();
            model.CountryCode = entity.CountryCode;
            model.DeptCode = entity.DeptCode;
            model.EmailAlert = entity.EmailAlert;

            model.Manager =entity.Manager == null ? new ManagerModel(): new ManagerModel() { ID = entity.Manager.Id, DisplayName = entity.Manager.DisplayName };

            model.IsActive = entity.IsActive;
            model.UpdateDate = entity.UpdateDate;
            model.UpdateBy = entity.UpdateBy;
            model.CreateBy = entity.CreateBy;
            model.CreateDate = entity.CreateDate;
            return model;
        }

        public static Employee ModelToEntity(EmployeeModel entity)
        {
            Employee model = new Employee();
            model.Id = entity.ID;

            model.UserId = entity.UserId;
            model.DisplayName = entity.DisplayName;
            model.FirstName = entity.FirstName;
            model.LastName = entity.LastName;
            model.JobGradeId = entity.JobGradeId;
            model.Email = entity.Email;

            model.Title = entity.Title;
            model.Team = entity.TeamItem == null ? new Team() : new Team() { Id = entity.TeamItem.DataID, Name = entity.TeamItem.DataText, ShortName = entity?.TeamItem.ShortName };
            model.RoleNames = entity.RoleNames;

            model.CountryCode = entity.CountryCode;
            model.DeptCode = entity.DeptCode;
            model.EmailAlert = entity.EmailAlert;

            model.Manager = entity.Manager == null ? new Employee():  new Employee() { Id = entity.Manager.ID, DisplayName = entity.Manager.DisplayName };

            model.IsActive = entity.IsActive;
            model.UpdateDate = entity.UpdateDate;
            model.UpdateBy = entity.UpdateBy;
            model.CreateBy = entity.CreateBy;
            model.CreateDate = entity.CreateDate;
            return model;
        }
    }
}
