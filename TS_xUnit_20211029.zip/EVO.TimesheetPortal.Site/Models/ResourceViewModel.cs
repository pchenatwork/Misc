﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Models
{
    public class ResourceViewModel
    {
        public string ResourceName { get; set; }

        public int Hours { get; set; }
    }

    public class ResourceDetailModel
    {
        public string TeamName { get; set; }

        public string ProjectName { get; set; }

        public List<ResourceViewModel> Details { get; set; }
    }
}
