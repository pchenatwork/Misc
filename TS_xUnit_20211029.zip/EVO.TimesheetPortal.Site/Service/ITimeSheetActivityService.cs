﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Refit;
using EVO.TimesheetPortal.Entity;
using Microsoft.AspNetCore.Mvc;

namespace EVO.TimesheetPortal.Site.Service
{
    public interface ITimeSheetActivityService : IService
    {

        [Get("/api/timesheetactivity/getdaily")]
        Task<ApiResponse<IList<TimesheetActivity>>> GetByDateAsync(int employeeId, DateTime activityDate);

        [Post("/api/timesheetactivity")]
        Task<ApiResponse<TimesheetActivity>> InsertAsync([FromBody] TimesheetActivity entity);
        [Delete("/api/timesheetactivity")]
        Task<ApiResponse<bool>> DeleteAsync(int id);

        [Get("/api/timesheetactivity")]
        Task<ApiResponse<TimesheetActivity>> GetAsync(int Id);

        [Get("/api/timesheetactivity/getmonthly")]
        Task<ApiResponse<IList<TimesheetActivity>>> GetByMonthAsync(int employeeId, DateTime startDate,DateTime endDate);

        [Get("/api/timesheetactivity/getoutlookbyemployee")]
        Task<ApiResponse<IList<TimesheetActivity>>> GetOutlookByEmployee(int employeeId, string periodCode);
        [Get("/api/timesheetactivity/getbycriteria")]
        Task<ApiResponse<TimesheetActivity>> GetByCriteria([FromQuery]TimesheetActivity entity); 
    }
}
