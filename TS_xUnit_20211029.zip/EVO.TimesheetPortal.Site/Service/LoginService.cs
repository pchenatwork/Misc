﻿using EVO.TimesheetPortal.Site.Service;
using EVOUserWSServiceReference;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimeSheetTrackerCore.Site.Models;


namespace TimeSheetTrackerCore.Site.Service
{
    public class LoginService : IService
    {
        protected IEVOUserWS UserManagementClient;

        protected IConfiguration Configuration;

       

        public LoginService(IEVOUserWS userManagementClient, IConfiguration configuration)
        {
            UserManagementClient = userManagementClient;
            Configuration = configuration;
           
        }

        public async Task<UserWP> GetUserData(string userName)
        {
            string applicationName = Configuration.GetValue<string>("Application:Name");
            return await UserManagementClient.GetUserProfileAsync(applicationName, userName);
        }

        //public async Task<EmployeeModel> GetCurrentUser(string loginName)
        //{
        //    var employee = await TimesheetTrackerClient.GetEmployeesAsync(new EmployeeEntity() { UserID = loginName });
        //    return EmployeeModel.MapObjectToModel(employee.ToList()).FirstOrDefault();
        //}

        //public async Task<List<TeamViewModel>> GetCurrentUserTeam(int empolyeeID)
        //{
        //    var entity = await TimesheetTrackerClient.GetTeamsAsync(new TeamEntity() { IsActive = true });
        //    return TeamViewModel.MapObjectToModel(entity.Where(w => (w.Manager1?.EmployeeID == empolyeeID 
        //                                                                || w.Manager2?.EmployeeID == empolyeeID
        //                                                                || w.Owner?.EmployeeID == empolyeeID
        //                                                             )&& w.IsActive == true).ToList());
        //}

        //public async Task<TimeSheetTrackerServiceReference.SaveResult> SyncEmployee(int ID, string userID, string employeeName, string roleName)
        //{
        //    var entity = new EmployeeEntity()
        //    {
        //        EmployeeID = ID,
        //        UserID = userID,
        //        EmployeeName = employeeName,
        //        RoleName = roleName
        //    };
        //    return await TimesheetTrackerClient.SyncEmployeeAsync(entity);
        //}
    }
}