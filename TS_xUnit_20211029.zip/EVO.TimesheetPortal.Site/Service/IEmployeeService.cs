﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Refit;
using EVO.TimesheetPortal.Entity;



namespace EVO.TimesheetPortal.Site.Service
{
    public interface IEmployeeService: IService
    {

        [Get("/api/Employee")]
        Task<ApiResponse<Employee>> GetAsync(int Id);

        [Post("/api/Employee")]
        Task<ApiResponse<int>> CreateAsync(Employee entity);

        [Put("/api/Employee")]
        Task<ApiResponse<int>> UpdateAsync(Employee entity);

        [Delete("/api/Employee")]
        Task<ApiResponse<bool>> DeleteAsync(int Id,string updateBy);

        [Get("/api/Employee/getall")]
        Task<ApiResponse<List<Employee>>> GetAllAsync();

        [Post("/api/Employee/search")]
        Task<ApiResponse<List<Employee>>> SearchAsync(Employee entity);
    }
}
