﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Refit;
using EVO.TimesheetPortal.Entity;
using Microsoft.AspNetCore.Mvc;
using System.Data;

namespace EVO.TimesheetPortal.Site.Service
{
    public interface ITimeSheetService : IService
    {
        [Post("/api/timesheet/ExecutiveApproval")]
        Task<ApiResponse<bool>> ExecutiveApproval(string periodCode, string updateBy, string comments = null);
            
        [Get("/api/timesheet/GetOutlookByTeamResource")]
        Task<ApiResponse<Timesheet>> GetOutlookByTeamResource(string periodCode);

        [Get("/api/timesheet/GetOutlookProjectSummary")]
        Task<ApiResponse<string>> GetOutlookProjectSummary(string periodCode);

        [Get("/api/timesheet/GetOutlookByTeamProject")]
        Task<ApiResponse<Timesheet>> GetOutlookByTeamProject(int teamId, int projectId, string periodCode);

        [Get("/api/timesheet/GetExecutiveSummary")]
        Task<ApiResponse<string>> GetOutlookByExecutiveSummary(string periodCode);

        [Get("/api/timesheet/getoutlookbyemployee")]
        Task<ApiResponse<Timesheet>> GetOutlookByEmployee(int employeeId, string periodCode);

        [Get("/api/timesheet/getoutlookbyemployeeproject")]
        Task<ApiResponse<Timesheet>> GetOutlookByEmployeeProject(int employeeId, int projectId, string periodCode);

        [Get("/api/timesheet/managerapproval")]
        Task<ApiResponse<bool>> ManagerApproval(int employeeId, string periodCode, string by);

        [Get("/api/timesheet/gettrenddata")]
        Task<ApiResponse<List<Timesheet>>> GetTrendData(int employeeId, string periodCode); 
    }
}
