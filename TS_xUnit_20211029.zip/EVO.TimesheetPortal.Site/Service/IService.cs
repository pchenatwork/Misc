﻿namespace EVO.TimesheetPortal.Site.Service
{
    public interface IService
    {
    }
}