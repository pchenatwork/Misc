﻿var checkedIds = [];
$(document).ready(function () {
    var grid = $('#Timesheet').data('kendoGrid');
    grid.element.on("click", ".row-checkbox", selectRow);

    $('#header-chb').change(function (ev) {
        var checked = ev.target.checked;
        $('.row-checkbox').each(function (idx, item) {
            if (checked) {
                if (!($(item).closest('tr').is('.k-state-selected'))) {
                    $(item).click();
                }
            } else {
                checkedIds = [];
                if ($(item).closest('tr').is('.k-state-selected')) {
                    $(item).click();
                }
            }
        });
    });

    $('.k-grid-Approve').click(function (e) {
        var d = [];
        d = checkedIds;
        if (d.length > 0) {
            kConfirm("Please Confirm","Are you sure that you want to approve?").then(function () {
                var approve = function () {
                    $.ajax(
                        {
                            url: "/Timesheet/Apprvoed",
                            type: 'post',
                            dataType: "json",
                            data: JSON.stringify(d),
                            contentType: 'application/json; charset=utf-8',
                            async: false,
                            success: function (result) {
                                if (result.Success) {
                                    onReloadGridDataSource();
                                    DisplayNotification("Record approved successfully!", "success");
                                } else {
                                    DisplayNotification(result.ErrorDescription, "warning");
                                }
                            },
                            error: function (e) {
                                DisplayNotification("Server side error ocurred", "warning");
                                return true;
                            }
                        })
                };
                onPushUpdate(approve);
                 
            }, function () { });
        } else {
            DisplayNotification("Please select the timesheet record(s) to be approved.", "warning");
            e.preventDefault();
        }
    });

    $('.k-grid-Reject').click(function (e) {
        var d = [];
        d = checkedIds;
        
        if (d.length > 0) {
            kConfirm("Please Confirm","Are you sure that you want to reject?").then(function () {
                var reject = function () {
                    $.ajax(
                        {
                            url: "/Timesheet/Rejected",
                            type: 'post',
                            dataType: "json",
                            data: JSON.stringify(d),
                            contentType: 'application/json; charset=utf-8',
                            async: false,
                            success: function (result) {
                                if (result.Success) {
                                    onReloadGridDataSource();
                                    DisplayNotification("Record rejected successfully!", "success");
                                } else {
                                    DisplayNotification(result.ErrorDescription, "warning");
                                }
                            },
                            error: function (e) {
                                DisplayNotification("Server side error ocurred", "warning");
                                return true;
                            }
                        });
                };
                onPushUpdate(reject);
                
            }, function () { });
        } else {
            DisplayNotification("Please select the timesheet record(s) to be rejected.", "warning");
            e.preventDefault();
        }
    });

    $('.k-grid-SummaryReport').click(function () {
        $.when($.post("/timesheet/timesheetsummary", { period: $("#dateRange").val() })).then(function (data) {
            var employeeWindow = $("#timesheetSummary");
            employeeWindow.html('');
            employeeWindow.append(data);
            employeeWindow = employeeWindow.kendoWindow({
                modal: true,
                title: "Timesheet Summary Report",
                visible: false,
                width: "1000px",
                actions: ["Close"]
            }).data("kendoWindow");
            if (employeeWindow) {
                employeeWindow.center().open();

                setTimeout(function () {
                    var h = window.innerHeight;
                    var w = window.innerWidth;
                    var wheight = $('#timesheetSummary').parent()[0].scrollHeight / 2;
                    var wWidth = $('#timesheetSummary').parent()[0].scrollWidth / 2;
                    $('#timesheetSummary').closest(".k-window").css({
                        top: h / 2 - wheight,
                        left: w / 2 - wWidth
                    });
                }, 500)
            }
        });
    });
});
function filterPeriod() {
    return {
        Period: $("#dateRange").val()
    };
}
function OnClickNotify() {
    kendo.confirm("Are you sure that you want to Notify Accounting, Please make sure to approve all timesheet?").then(function () {
        $.ajax(
            {
                url: "/Timesheet/NotifyAccounting",
                type: 'post',
                dataType: "json",
                data: {},
                contentType: 'application/json; charset=utf-8',
                async: false,
                success: function (result) {
                    if (result.Success) {

                        DisplayNotification("Notify Accounting successfully!", "success");
                    } else {
                        DisplayNotification(result.ErrorDescription, "warning");
                    }
                },
                error: function (e) {
                    DisplayNotification("Server side error ocurred", "warning");
                    return true;
                }
            });
    }, function () { });
}

function onDataBound(e) {
    var grid = this;
    var allRows = grid.items();
    var checkHeader = true;
    var hasCheck = false;
    $.each(allRows, function (index, value) {
        $(value).find(".row-checkbox").attr('disabled', true);
        $(value).find(".k-checkbox-label").attr('style', 'display:none');
        $(value).find(".row-checkbox").attr('style', 'display:none');
        $("[data-uid='" + grid.dataItem(value).uid + "']").removeClass("k-state-selected");
        checkedIds.forEach(function (f) {
            if (f === grid.dataItem(value).RequestID) {
                $('#' + grid.dataItem(value).TimeSheetID + '').attr('checked', 'true');
                $("[data-uid='" + grid.dataItem(value).uid + "']").removeClass("k-state-selected");
                try {
                    grid.select(value);
                } catch (e) {

                }
            }
        });

        if (grid.dataItem(value).StatusDesc === defaultStatus || (isTimesheetAdmin === 'True' && !['Approved','Rejected'].includes(grid.dataItem(value).StatusDesc))) {
            $(value).find(".row-checkbox").attr('disabled', false);
            $(value).find(".k-checkbox-label").attr('style', 'display:block');
            $(value).find(".row-checkbox").attr('style', 'display:block');
        }

        if (checkHeader && $(value).find(".row-checkbox")[0] && $(value).find(".row-checkbox").attr("disabled") != 'disabled') {
            checkHeader = $(value).find(".row-checkbox")[0].checked;
            hasCheck = true;
        }
    })
    //$("#header-chb")[0].checked = hasCheck && checkHeader;
}

function selectRow() {
    if (this.id !== "header-chb") {
        var checked = this.checked,
            row = $(this).closest("tr"),
            grid = $("#Timesheet").data("kendoGrid"),
            dataItem = grid.dataItem(row);
        
        var checkHeader = true;
        if (checked) {
            const index = checkedIds.indexOf(dataItem.RequestID);
            if (index < 0) {
                checkedIds.push(dataItem.RequestID);
            }
            $("[data-uid='" + dataItem.uid + "']").addClass("k-state-selected");
            $.each(grid.items(), function (index, item) {
                if ($(item).find(".k-checkbox-label").attr('style') == 'display:block'
                    && $(item).find(".row-checkbox").attr("disabled") != 'disabled'
                    && !($(item).hasClass("k-state-selected"))) {
                    checkHeader = false;
                    return false;
                }
            });
            $("#header-chb")[0].checked = checkHeader;
        } else {
            $("[data-uid='" + dataItem.uid + "']").removeClass("k-state-selected");
            $("#header-chb")[0].checked = false;
            const index = checkedIds.indexOf(dataItem.RequestID);
            if (index > -1) {
                checkedIds.splice(index, 1);
            }
        }
    }
}

function onPushUpdate(f) {
    var grid = $("#Timesheet").data("kendoGrid");
    var hasDirtyData = false;
    var items = grid.dataSource.data();
    for (var i = 0; i < items.length; i++) {
        if (items[i].dirty) {
            hasDirtyData = true;
            break;
        }
    }
    if (hasDirtyData) {
        grid.dataSource.sync().then(f);
    } else {
        f();
    }
}

function onReloadGridDataSource() {
    var grid = $("#Timesheet").data("kendoGrid");
    this.checkedIds = [];
    grid.dataSource.read();
}

function onDataFilter() {
    var dateRangeValue = $("#dateRange").val();
    var submittedValue = $("#TeamOwner").val();
    var statusFilter = $("#StatusFilter").data("kendoMultiSelect");
    var statusFilterValue = statusFilter?statusFilter.value():"";

    var obj = {
        Period: dateRangeValue,
        Submitted: submittedValue,
        statusFilter: "".concat(statusFilterValue)
    }
    return compoundObjectWithForgeryToken(obj);
}

function AllowedEditComment(dataItem) {
    return dataItem.StatusDesc === defaultStatus || (isTimesheetAdmin === 'True' && !['Approved', 'Rejected'].includes(dataItem.StatusDesc));
}