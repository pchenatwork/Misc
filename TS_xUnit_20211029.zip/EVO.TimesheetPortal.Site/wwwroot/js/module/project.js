﻿$(document).ready(function () {
    $('.k-grid-Add').click(function () {
        $.when($.post("/project/CreateProject")).then(function (data) {
            var timesheetWindow = $("#createProject");
            timesheetWindow.html('');
            timesheetWindow.append(data);
            timesheetWindow = timesheetWindow.kendoWindow({
                modal: true,
                title: "+ Project",
                visible: false,
                width: "700px",
                actions: ["Close"],
                resizable: false
            }).data("kendoWindow");
            if (timesheetWindow) {
                timesheetWindow.center().open();
                timesheetWindow.bind("close", projectFormEditor.onWindowClose)
            }
        });
    });

    $("#project").kendoTooltip({
        filter: ".tooltips",
        width: '300px',
        content: function (e) {
            var dataItem = $(".k-grid").data("kendoGrid").dataItem(e.target.closest("tr"));
            if (formatLongStr(dataItem.Team, 20) === e.target.html()) {
                return dataItem.Team;
            } else if (formatLongStr(dataItem.Description, 20) === e.target.html()) {
                return dataItem.Description;
            } else if (formatLongStr(dataItem.Phase, 20) === e.target.html()) {
                return dataItem.Phase;
            } else if (formatLongStr(dataItem.Name, 20) === e.target.html()) {
                return dataItem.Name;
            } else if (formatLongStr(dataItem.Type, 20) === e.target.html()) {
                return dataItem.Type;
            }
            //return '';
        }
    });

    $("#projectApprove").kendoTooltip({
        filter: ".tooltips",
        width: '300px',
        content: function (e) {
            var dataItem = $(".k-grid").data("kendoGrid").dataItem(e.target.closest("tr"));
            if (formatLongStr(dataItem.Team, 40) === e.target.html()) {
                return dataItem.Team;
            } else if (formatLongStr(dataItem.Description, 60) === e.target.html()) {
                return dataItem.Description;
            } else if (formatLongStr(dataItem.Phase, 30) === e.target.html()) {
                return dataItem.Phase;
            } else if (formatLongStr(dataItem.Name, 40) === e.target.html()) {
                return dataItem.Name;
            }
            return '';
        }
    });
});

function error_handler(e) {
    if (e.errors) {
        var message = "Errors:\n";
        $.each(e.errors, function (key, value) {
            if ('errors' in value) {
                $.each(value.errors, function () {
                    message += this + "\n";
                });
            }
        });
        alert(message);
    }
}

var project = {
    onDataBound: function (e) {
        var grid = $(".k-grid").data("kendoGrid");
        var data = grid.dataSource.data();
        $.each(data, function (i, row) {
            if (row.Status == 'Pending Approval') {
                $('tr[data-uid="' + row.uid + '"] ').css("color", "gray");
            } else if (row.Status === 'Rejected') {
                $('tr[data-uid="' + row.uid + '"] ').css("color", "#b34d4d");
            } else if (row.Status === 'Approved') {
                $('tr[data-uid="' + row.uid + '"] ').css("color", "#007bff");
            }

            var des = $('tr[data-uid="' + row.uid + '"]').find("[id*='_action_for_']");
            if (des.length == 1 && row.Is1OK) {
                ActionMenuMaker.MakeMenu(des[0]);
            }
        });
    },
    onShowMore: function (e) {
        var grid = $(".k-grid").data("kendoGrid");
        var data = grid.columns;
        if ($(e).text() === 'More') {
            $(e).text('Less')
            $.each(data, function (i, row) {
                if (row.hidden && i > 1) {
                    grid.showColumn(i);
                }
            });
        } else {
            $(e).text('More')
            var hideCols = ['Type', 'Description', 'EstimatedHours', 'StartDate', 'EndDate', 'ProdDate', 'Country', 'RequestedBy'];
            $.each(data, function (i, row) {
                if (hideCols.indexOf(row.field) > 0) {
                    grid.hideColumn(i);
                }
            });
        }
    },
    onMenuAction: function (e) {
        $.ajax(
            {
                url: "/project/" + e.split(':')[0],
                type: 'post',
                dataType: "json",
                data: JSON.stringify(e.split(':')[1]),
                contentType: 'application/json; charset=utf-8',
                async: false,
                success: function (result) {
                    DisplayNotification("Operation successfully!", "success");
                    var grid = $('#project').data('kendoGrid');
                    grid.dataSource.read();
                },
                error: function (e) {
                    DisplayNotification("Server side error ocurred", "warning");
                    return true;
                }
            });
    }
};

var projectFormEditor = {
    onFormValidateField: function (e) {
        $("#validation-success").html("");
    },
    onFormSubmit: function (e) {
        projectFormEditor.submitData(false);
        e.preventDefault();
    },
    onFormCreateAndSubmit: function () {
        var validator = $("#CreateProjectForm").kendoValidator().data("kendoValidator");
        if (validator.validate()) {
            projectFormEditor.submitData(true);
        }
    },
    onFormClear: function (e) {
        $("#validation-success").html("");
    },
    submitData: function (isSubmit) {
        var data = {};
        var teams = $("#Teams").data("kendoMultiSelect");
        var phase = $("#Phases").data("kendoMultiSelect");
        data.ID = $("#ID").val();
        data.Name = $("#Name").val();
        data.TypeID = $("#TypeID").val();
        data.Description = $("#Description").val();
        data.PhaseList = phase.value();
        data.Country = $("#Country").val();
        data.EstimatedHours = $("#EstimatedHours").val();
        data.TeamList = teams.value();
        data.RequestedBy = $("#RequestedBy").val();
        data.PIRNo = $("#PIRNo").val();

        if ($("#StartDate").val()) {
            data.StartDate = $("#StartDate").val();
        }
        if ($("#EndDate").val()) {
            data.EndDate = $("#EndDate").val();
        }
        if ($("#ProdDate").val()) {
            data.ProdDate = $("#ProdDate").val();
        }
        $.when($.ajax({
            url: "/project/CreateProjectForm",
            type: "POST",
            data: data
        })).then(function (data) {
            var grid = $('#project').data('kendoGrid');
            grid.dataSource.read();
            var createProjectWindow = $('#createProject').data("kendoWindow");
            var editProjectWindow = $('#editProject').data("kendoWindow");
            if (createProjectWindow) {
                createProjectWindow.close();
            }
            if (editProjectWindow) {
                editProjectWindow.close();
            }
        });
    },
    onWindowClose: function () {
        var grid = $('#project').data('kendoGrid');
        grid.dataSource.read();
    }
};

var projectApprove = {
    approveProject: function (e) {
        var id = $(e).closest('tr').find('td').eq(0).text();
        $.ajax(
            {
                url: "/project/approve",
                type: 'post',
                dataType: "json",
                data: JSON.stringify(id),
                contentType: 'application/json; charset=utf-8',
                async: false,
                success: function (result) {
                    DisplayNotification("Operation successfully!", "success");
                    var grid = $('#projectApprove').data('kendoGrid');
                    grid.dataSource.read();
                },
                error: function (e) {
                    DisplayNotification("Server side error ocurred", "warning");
                    return true;
                }
            });
    },
    onDataFilter: function () {
        var obj = {
            Status: $("#projectStatus").val()
        }
        return compoundObjectWithForgeryToken(obj);
    },
    rejectProject: function (e) {
        var id = $(e).closest('tr').find('td').eq(0).text();
        $('#projectID').val(id);
        var editorWindow = $("#RejectWindow");
        editorWindow.kendoWindow({
            width: "400px",
            height: "230px",
            modal: true,
            actions: [
                "Close"
            ],
            close: function () {
            }
        }).data("kendoWindow")
            .title('Reject')
            .center();
        var wnd = $("#RejectWindow").data("kendoWindow");
        wnd.open();
    },
    closeComment: function (e) {
        if (e === 1) {
            var data = {};
            data.Id = $('#projectID').val();
            data.Comment = $('#Comment').val();
            if (data.Comment.length > 300) {
                $('#Comment').addClass('k-invalid')
                $('#Comment-msg').show();
                return;
            } else {
                $('#Comment-msg').hide();
                $('#Comment').removeClass('k-invalid')
                $.ajax(
                    {
                        url: "/project/reject",
                        type: 'post',
                        dataType: "json",
                        data: JSON.stringify({ 'ID': $('#projectID').val(), 'Comment': $('#Comment').val() }),
                        contentType: 'application/json; charset=utf-8',
                        async: false,
                        success: function (result) {
                            DisplayNotification("Operation successfully!", "success");
                            var grid = $('#projectApprove').data('kendoGrid');
                            grid.dataSource.read();
                        },
                        error: function (e) {
                            DisplayNotification("Server side error ocurred", "warning");
                            return true;
                        }
                    });
            }
        }
        var wnd = $("#RejectWindow").data("kendoWindow");
        $('#Comment').val('');
        wnd.close();
    },
    onSelect: function (e) {
        var grid = $(".k-grid").data("kendoGrid");
        if (e.indices[0] == 1) {
            $("#projectStatus").val(2);
            grid.dataSource.read();
        } else if (e.indices[0] == 0) {
            $("#projectStatus").val(1);
            grid.dataSource.read();
        } else {
            grid.options.excel.fileName = projectApprove.getExcelName();
            grid.saveAsExcel();
        }
    },
    showApproveBtn: function (dataItem) {
        return dataItem.Status === 'Pending' && dataItem.Is2OK;
    },
    showRejectBtn: function (dataItem) {
        return dataItem.Status === 'Pending' && dataItem.Is3OK;
    },
    getExcelName: function () {
        if ($("#projectStatus").val() === '1') {
            return 'Project Pending Listing';
        } else {
            return 'Project Listing';
        }
    },
    onCommnetBlur: function () {
        if ($('#Comment').val().length > 300) {
            $('#Comment-msg').show();
            $('#Comment').addClass('k-invalid')
        } else {
            $('#Comment-msg').hide();
            $('#Comment').removeClass('k-invalid')
        }
    }
};

(function ($, kendo) {
    $.extend(true, kendo.ui.validator, {
        validateOnBlur: true,
        rules: { // custom rules
            projectnamevalidation: function (input, params) {
                if (input.is("[name='Name']") && input.val() !== "") {
                    input.attr("data-Name-msg", "Project Name is existing");
                    $.ajax(
                        {
                            url: "/Project/CheckProjectName?name=" + input.val(),
                            type: 'get',
                            dataType: "json",
                            contentType: 'application/json; charset=utf-8',
                            async: false,
                            success: function (result) {
                                retValue = !result;
                            },
                            error: function (e) {
                                return true;
                            }
                        });
                    return retValue;
                } else {
                    return true;
                }
            }
        },
        messages: {
            projectnamevalidation: function (input) {
                return input.attr("data-Name-msg");
            }
        }
    });
})(jQuery, kendo);

var ActionMenuMaker = (function () {
    /* Use bootstrap dropdown menu to construct the ActionOption Menu */
    var _popup = function (name, value, extra) {
        // Logic for preparing element that will link a "Popup" goes here
        var item = $('<button class="btn btn-default btn-sm dropdown-item" type="button">' + name + '</button>');
        item.on('click', function () {
            if (value.split(':')[0] === 'edit') {
                $.when($.post("/project/UpdateProject?Id=" + value.split(':')[1])).then(function (data) {
                    var timesheetWindow = $("#editProject");
                    timesheetWindow.html('');
                    timesheetWindow.append(data);
                    timesheetWindow = timesheetWindow.kendoWindow({
                        modal: true,
                        title: "Edit Project",
                        visible: false,
                        width: "700px",
                        actions: ["Close"],
                        resizable: false
                    }).data("kendoWindow");
                    if (timesheetWindow) {
                        timesheetWindow.center().open();
                        timesheetWindow.bind("close", projectFormEditor.onWindowClose)
                    }
                });
            }
        });
        return item;
    };
    var _redirect = function (name, value, extra) {
        // Logic for preparing element that will "Redirect" to a new page goes here
        var item = $('<a class="dropdown-item" href="#">' + name + '</a>');
        item.on('click', function () {
            alert('redirect to : ' + value);
        });
        return item;
    };
    var _formpost = function (name, value, extra) {
        // Logic for preparing element that will result a "Form Post" goes here
        var item = $('<a class="dropdown-item" href="#">' + name + '</a>');
        item.on('click', function () {
            project.onMenuAction(value);
        });
        return item;
    };
    return {
        MakeMenu: function (ele) {
            var arr = JSON.parse($(ele).attr("data-options"));
            if (arr.length > 0) {
                var id = "ActionOption" + ele.id.substring(ele.id.lastIndexOf("_"), ele.length);
                var div = $('<div class="dropdown" />');
                div.hover(function () {
                    $('.k-i-gear', this).trigger('click');
                });
                // var btn = $('<button class="btn btn-info btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="' + id + '">Action</button>');
                var btn = $('<span class="k-icon k-i-gear dropdown-toggle.caret-off" ' +
                    'data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id = "' + id + '" /> ');
                div.append(btn);

                var menuitem = $('<div class="dropdown-menu" aria-labelledby="' + id + '" />');
                menuitem.append($('<h4 class="dropdown-header">Action</h4>'));
                menuitem.append($('<div class="dropdown-divider" />'));
                arr.forEach(function (o) {
                    switch (o.T) {
                        case 1: // popup
                            menuitem.append(_popup(o.N, o.V, o.E));
                            break;
                        case 2: // redirect
                            menuitem.append(_redirect(o.N, o.V, o.E));
                            break;
                        case 3:  // form post
                            menuitem.append(_formpost(o.N, o.V, o.E));
                            break;
                        default:
                            break
                    }
                })
                div.append(menuitem);

                $(ele).append(div);
            }
        }
    }
})();