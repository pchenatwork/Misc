﻿var checkedIds = [];

$(document).ready(function () {
    function init() {
        var grid = $('#Timesheet').data('kendoGrid');
        grid.element.on("click", ".row-checkbox", selectRow);
        //setAddTimesheetButtonStatus();

        if (permission && permission.indexOf('Import_TimeSheet') > -1) {
            $('.k-upload').show();
            $('#downloadTemplate').show();
            setInvalidDownloadButtonStatus();
        } else {
            $('.k-upload').hide();
            $('#downloadTemplate').hide();
            $('#invalidDownload').hide();
        }
    };

    init();

    $.extend(true, kendo.ui.validator, {
        rules: { // custom rules
            projectname_datatextvalidation: function (input) {
                //check if it is the ProductName field
                if (input.is("[id=ProjectName_DataText]")) {
                    input.attr("data-ProjectName_DataTextvalidation-msg", "Project Name is required.");
                    return !!input.val() && input.val() !== -1 && input.val() !== "";
                }
                return true;
            },
            hoursvalidation: function (input) {
                if (input.is("[name=Hours]")) {
                    input.attr("data-Hoursvalidation-msg", "Hours must be between 1 and 720.");
                    return !!input.val() && parseFloat(input.val()) > 0 && parseFloat(input.val()) <= 720;
                }
                return true;
            },
            projectphase_datatextvalidation: function (input) {
                //check if it is the ProductName field
                if (input.is("[id=TSProjectPhase_DataText]")) {
                    input.attr("data-ProjectPhase_DataTextvalidation-msg", "Project Phase is required.");
                    return !!input.val() && input.val() !== -1 && input.val() !== "";
                }
                return true;
            },
            descriptionvalidation: function (input) {
                if (input.is("[name=Description]")) {
                    input.attr("data-Descriptionvalidation-msg", "Description is required.");
                    return !!input.val() && input.val() !== -1 && input.val() !== "";
                }
                return true;
            }
        }
    });

    $('#header-chb').change(function (ev) {
        var checked = ev.target.checked;
        $('.row-checkbox').each(function (idx, item) {
            if (checked) {
                if (!($(item).closest('tr').is('.k-state-selected'))) {
                    $(item).click();
                }
            } else {
                checkedIds = [];
                if ($(item).closest('tr').is('.k-state-selected')) {
                    $(item).click();
                }
            }
        });
    });

    $('.k-grid-Submit').click(function (e) {
        var d = [];
        d = checkedIds;
        var isDirty = dirtyCheck();
        if (isDirty) {
            DisplayNotification("Changes have not been saved!", "warning");
            return;
        }
        if (d.length > 0) {
            kConfirm("Please Confirm", "Are you sure that you want to submit?").then(function () {
                $.ajax(
                    {
                        url: "/TimeSheet/Submit",
                        type: 'post',
                        dataType: "json",
                        data: JSON.stringify(d),
                        contentType: 'application/json; charset=utf-8',
                        async: false,
                        success: function (result) {
                            if (result.Success) {
                                //refresh
                                onReloadGridDataSource();
                                DisplayNotification("Record submitted successfully!", "success");
                            } else {
                                DisplayNotification(result.ErrorDescription, "warning");
                            }
                        },
                        error: function (e) {
                            return true;
                        }
                    });
            }, function () { });
        } else {
            e.preventDefault();
            DisplayNotification("Please select a record for [Submit]", "warning");
        }

    });

    $('#downloadTemplate').click(function () {
        kConfirm("Please Confirm", "Are you sure that you want to download?").then(function () {
            var form = $("<form></form>").attr("action", "/timesheet/Download").attr("method", "post");
            var token = $("[name='__RequestVerificationToken']").val();
            form.append($("<input></input>").attr("type", "hidden").attr("name", "__RequestVerificationToken").attr("value", token));
            form.appendTo('body').submit().remove();
        }, function () { });
    })

    $('#invalidDownload').click(function () {
        kConfirm("Please Confirm", "Are you sure that you want to download?").then(function () {
            var form = $("<form></form>").attr("action", "/timesheet/DownloadInvalidList").attr("method", "post");
            var token = $("[name='__RequestVerificationToken']").val();
            form.append($("<input></input>").attr("type", "hidden").attr("name", "__RequestVerificationToken").attr("value", token));
            form.appendTo('body').submit().remove();
        }, function () { });
    })

    $("#importTimesheetFiles").kendoUpload({
        "upload": OnAttachUpload,
        "success": OnAttachSuccess,
        "error": OnError,
        "select": onSelect,
        "validation": {
            "allowedExtensions": [".xlsx"],
            "maxFileSize": 900000
        },
        "async": { "autoUpload": true, "saveUrl": "/timesheet/Upload" },
        "multiple": false,
        "showFileList": false
    });
});

function projectNameFilter(element) {
    var resourcesID = $("#ResourceID").val() === undefined || $("#ResourceID").val() === "" ? 'NoData' : $("#ResourceID").val();
    var dateRangeValue = $("#dateRange").val();
    element.kendoDropDownList({
        dataSource: {
            transport: {
                read: "/Timesheet/GetProjectNamesFilter?userName=" + resourcesID + "&period=" + dateRangeValue
            }
        },
        optionLabel: "--Select Value--"
    });
}

function onSelect(e) {
    $('.k-upload-status').remove();
    $("#uploadIcon").removeClass("k-i-upload");
    $("#uploadIcon").addClass("k-i-loading");
    $("#uploadLbl").text("Uploading...");
    $("#importTimesheetFiles").data("kendoUpload").disable();
};

function OnAttachUpload(arg) {
    var dateRangeValue = $("#dateRange").val();
    arg.data = { DateRange: dateRangeValue };
}

function OnAttachSuccess(arg) {
    var result = arg.response;
    var message = (result || "").detail || "Import file error occurred, please try again!";
    if (arg.response.status == '207') {
        DisplayNotification(message, "error");
    } else {
        if (arg.response.Invalid) {
            $('#invalidDownload').show();
            DisplayNotification("Import failed, please download invalid list to check reason.", "warning");
        } else {
            $('#invalidDownload').hide();
            DisplayNotification("Import timesheet successfully.", "info");
        }
        var grid = $("#Timesheet").data("kendoGrid");
        grid.dataSource.read();
    }
    $('.k-upload-status').hide();
    $("#uploadIcon").removeClass("k-i-loading");
    $("#uploadIcon").addClass("k-i-upload");
    $("#uploadLbl").text("Import");
    $("#importTimesheetFiles").data("kendoUpload").enable();
}

function OnDestroy(e) {
    var grid = $("#Timesheet").data("kendoGrid");
    var row = $(e.currentTarget).closest("tr");
    var dataItem = this.dataItem($(e.currentTarget).closest("tr"));

    grid.options.messages.editable.confirmation = "Are you sure you want to delete this record?";
    grid.removeRow(row);
    e.preventDefault();

}

function OnError(arg) {
    $('.k-upload-status').hide();
    $("#uploadIcon").removeClass("k-i-loading");
    $("#uploadIcon").addClass("k-i-upload");
    $("#importTimesheetFiles").data("kendoUpload").enable();
    $("#uploadLbl").text("Import");
    if (arg.XMLHttpRequest.status == "500") {
        DisplayNotification("Import file error occurred, please try again!", "error");
    }

    if (arg.XMLHttpRequest.status === "200") {
        location.href = "/accounting/index?isParticalView=true";
        DisplayNotification("Import file success!", "success");
    }
}

function onProjectNameChange(e) {
    var projectID = e.sender._old;
    if (projectID !== '') {
        $('#hideProjectID').val(projectID);
        var resourcesID = $("#ResourceID").val() === undefined || $("#ResourceID").val() === "" ? 'NoData' : $("#ResourceID").val();
        $.ajax(
            {
                url: "/Timesheet/GetProject?Id=" + projectID + "&userName=" + resourcesID,
                type: 'get',
                contentType: 'application/json; charset=utf-8',
                async: false,
                success: function (result) {
                    if (result.TimesheetProjectPhase === '' || undefined) {
                        DisplayNotification("Please contact manager to adding timesheet project phase for this project.", "warning");
                        return;
                    }
                    if (result.TimesheetProjectPhase === '' || undefined) {

                    }
                    var grid = $("#Timesheet").data("kendoGrid");
                    var dataSource = grid.dataSource;
                    var rowIndex = $(e.sender.element).closest('tr')[0].getAttribute("data-uid");
                    for (var i = 0; i < dataSource.data().length; i++) {
                        if (dataSource.data()[i].uid === rowIndex) {
                            var data = dataSource.data()[i];
                            var senderDataSource = e.sender.dataSource._data;
                            var projectData = senderDataSource.find(function (p) {
                                return p.DataID == projectID;
                            })
                            if (data.uid === rowIndex && projectData) {
                                data.ProjectName = { DataText: projectData.DataText, DataID: projectID };
                                //data.ProjectName.DataID = projectID;
                                data.ProjectID = projectID;
                                data.SystemName = result.SystemName;
                                data.Number = result.Number;
                                data.ProjectType = result.ProjectType;
                                data.TimesheetProjectPhase = result.TimesheetProjectPhase;
                                data.ProjectPhase = result.ProjectPhase;
                                data.PeriodID = $("#dateRange").data("kendoDropDownList").value();
                                var dataID = 0;
                                statusData.forEach(function (f) {
                                    if (f.DataText === 'Draft') {
                                        dataID = f.DataID;
                                        return;
                                    }
                                });
                                data.StatusID = dataID;
                                var row = $('tr[data-uid="' + rowIndex + '"]');
                                row.find('.systemName').html(result.SystemName);
                                row.find('.Number').html(result.Number);
                                row.find('.ProjectType').html(result.ProjectType);
                                row.find('.ProjectPhase').html(result.ProjectPhase);
                            }
                        }
                    }

                },
                error: function (e) {
                    DisplayNotification("Get project failed", "warning");
                    resetDataItem(e);
                }
            });
        $.ajax(
            {
                url: "/Timesheet/GetTimesheetProjectPhases?ProjectID=" + projectID + "&resourceID=" + resourcesID,
                type: 'get',
                contentType: 'application/json; charset=utf-8',
                async: false,
                success: function (result) {
                    var grid = $("#Timesheet").data("kendoGrid");
                    var dataSource = grid.dataSource;
                    var rowIndex = $(e.sender.element).closest('tr')[0].getAttribute("data-uid");
                    for (var i = 0; i < dataSource.data().length; i++) {
                        if (dataSource.data()[i].uid === rowIndex) {
                            var data = dataSource.data()[i];
                            if (data.uid === rowIndex) {
                                var row = $('tr[data-uid="' + rowIndex + '"]');
                                row.find('.TimesheetProjectPhase');
                                var phase = $('#TSProjectPhase_DataText').data('kendoDropDownList');
                                if (phase) {
                                    phase.dataSource.data(result);
                                }
                            }
                        }
                    }

                },
                error: function (e) {
                    DisplayNotification("Get timesheet project phase failed", "warning");
                    resetDataItem(e);
                }
            });
    } else {
        resetDataItem(e);
    }
}


function resetDataItem(e) {
    var grid = $("#Timesheet").data("kendoGrid");
    var dataSource = grid.dataSource;
    e.sender.value("-1");
    var rowIndex = $(e.sender.element).closest('tr')[0].getAttribute("data-uid");
    for (var i = 0; i < dataSource.data().length; i++) {
        if (dataSource.data()[i].uid === rowIndex) {
            var data = dataSource.data()[i];
            if (data.uid === rowIndex) {
                data.ProjectName = { DataText: '', DataID: -1 };
                data.ProjectID = '';
                data.SystemName = '';
                data.Number = '';
                data.ProjectType = '';
                data.TimesheetProjectPhase = '';
                data.StatusID = '';

                var row = $('tr[data-uid="' + rowIndex + '"]');
                row.find('.systemName').html("");
                row.find('.Number').html("");
                row.find('.ProjectType').html("");
                row.find('.TimesheetProjectPhase').html("");
            }
        }
    }
}

function isNewAllowEditable(dataItem) {
    return dataItem && dataItem.isNew && dataItem.isNew();
}

function isAllowEditable(dataItem) {
    if (dataItem.isNew()) {
        return true;
    } else {
        return (dataItem.StatusID === 9 || dataItem.StatusID === 16) && ($('#IsAdmin').val() === 'True' || dataItem.ResourceID === loginUser);
    }
}

function onDataBound(e) {
    var grid = $("#Timesheet").data("kendoGrid");
    var allRows = grid.items();
    var checkHeader = true;
    var hasCheck = false;
    $.each(allRows, function (index, value) {
        var deleteStatus = false;
        $(value).find(".row-checkbox").attr('disabled', true);
        $(value).find(".k-checkbox-label").attr('style', 'display:none');
        $(value).find(".row-checkbox").attr('style', 'display:none');
        $("[data-uid='" + grid.dataItem(value).uid + "']").removeClass("k-state-selected");
        checkedIds.forEach(function (f) {
            if (!!grid.dataItem(this) && f === grid.dataItem(value).TimeSheetID) {
                $('#' + grid.dataItem(value).TimeSheetID + '').attr('checked', 'true');
                $("[data-uid='" + grid.dataItem(value).uid + "']").addClass("k-state-selected");
                try {
                    grid.select(value);
                } catch (e) {

                }
            }
        });

        statusData.forEach(function (f) {
            if (f.DataID === grid.dataItem(value).StatusID
                && (f.DataID === 9 || f.DataID === 16)
                && ($('#IsAdmin').val() === 'True'
                    || grid.dataItem(value).ResourceID === loginUser
                    || (loginUser === grid.dataItem(value).UpdatedBy && grid.dataItem(value).Type === 1))
            ) {
                deleteStatus = f.DataID === grid.dataItem(value).StatusID && (f.DataID === 9 || f.DataID == 16)
                    || loginUser === grid.dataItem(value).ResourceID
                    || $('#IsAdmin').val() === 'True'
                    || (loginUser === grid.dataItem(value).UpdatedBy && grid.dataItem(value).Type === 1);
                $(value).find(".row-checkbox").attr('disabled', false);
                $(value).find(".k-checkbox-label").attr('style', 'display:block');
                $(value).find(".row-checkbox").attr('style', 'display:block');
                return;
            }
        });

        if (checkHeader && $(value).find(".row-checkbox")[0] && $(value).find(".row-checkbox").attr("disabled") != 'disabled') {
            checkHeader = $(value).find(".row-checkbox")[0].checked;
            hasCheck = true;
        }

        $(value).find(".k-grid-Delete").attr('disabled', !deleteStatus);
    })
    $("#header-chb")[0].checked = hasCheck && checkHeader;
}

function onGridEdit(e) {
    if ($('#IsAdmin').val() === 'True' && e.model.isNew()) {
        e.model.ResourceID = $("#ResourceID").val();
        e.model.ResourceName = $("#ResourceID").data("kendoComboBox").text();
        e.model.ResourceManager = $("#ManageName").val();
        e.model.ProjectManager = $("#ProjectManagerName").val();
    }
}

function onGridBeforeEdit(e) {
    if (e.model.ProjectID >= 0) {
        $('#hideProjectID').val(e.model.ProjectID);
        $('#hideResourceID').val(e.model.ResourceID);
    }
}

function selectRow() {
    if (this.id !== "header-chb") {
        var checked = this.checked,
            row = $(this).closest("tr"),
            grid = $("#Timesheet").data("kendoGrid"),
            dataItem = grid.dataItem(row);

        var checkHeader = true;
        if (checked) {
            const index = checkedIds.indexOf(dataItem.TimeSheetID);
            if (index < 0) {
                checkedIds.push(dataItem.TimeSheetID);
            }
            $("[data-uid='" + dataItem.uid + "']").addClass("k-state-selected");
            $.each(grid.items(), function (index, item) {
                if ($(item).find(".k-checkbox-label").attr('style') == 'display:block' && $(item).find(".row-checkbox").attr("disabled") != 'disabled' && !($(item).hasClass("k-state-selected"))) {
                    checkHeader = false;
                    return false;
                }
            });
            $("#header-chb")[0].checked = checkHeader;
        } else {
            $("[data-uid='" + dataItem.uid + "']").removeClass("k-state-selected");
            $("#header-chb")[0].checked = false;
            var index = checkedIds.indexOf(dataItem.TimeSheetID);
            if (index > -1) {
                checkedIds.splice(index, 1);
            }
        }
    }
}

function onReloadGridDataSource() {
    var dateReangeText = $("#dateRange").data("kendoDropDownList").text();
    var isCurrentMonth = dateReangeText.trim() === "Current Month";
    if (!isCurrentMonth) {
        $(".k-upload").hide();
        $('#downloadTemplate').hide();
        $('#importTimesheetFiles').hide();
        $('#invalidDownload').hide();
        $('.k-grid-button').hide();
        $('.k-grid-submit').hide();
    } else {
        if (permission && permission.indexOf('Import_TimeSheet') > -1) {
            $(".k-upload").show();
            $('#importTimesheetFiles').show();
            $('#downloadTemplate').show();
            setInvalidDownloadButtonStatus();

        } else {
            $(".k-upload").hide();
            $("#importTimesheetFiles").hide();
            $('#downloadTemplate').hide();
            $('#invalidDownload').hide();
        }

        if (permission && permission.indexOf('Timesheet_Edit') > -1) {
            $('.k-grid-button').show();
        } else {
            $('.k-grid-button').hide();
        }

        if (permission && permission.indexOf('Timesheet_Submit') > -1) {
            $('.k-grid-submit').show();
        } else {
            $('.k-grid-submit').hide();
        }

    }
    var grid = $("#Timesheet").data("kendoGrid");
    this.checkedIds = [];
    grid.dataSource.read();
    if ($('#IsAdmin').val() === 'True') {
        $('.k-grid-button').show();
        $('.k-grid-submit').show();
        //setAddTimesheetButtonStatus();
        getManagerName($("#ResourceID").val());
    }
}

function setInvalidDownloadButtonStatus() {
    if (invalidData == 'True') {
        $('#invalidDownload').show();
    } else {
        $('#invalidDownload').hide();
    }
}

function setAddTimesheetButtonStatus() {
    if ($('#IsAdmin').val() === 'True') {
        $('.k-grid-Add').attr('disabled', $("#ResourceID").val() === '');
    }
}

function onDataFilter() {
    var dateRangeValue = $("#dateRange").val();
    var statusFilter = $("#StatusFilter").data("kendoMultiSelect");
    var statusFilterValue = statusFilter.value();
    var resourcesID = $("#ResourceID").val() === undefined || $("#ResourceID").val() === "" ? 'NoData' : $("#ResourceID").val();

    var obj = {
        PeriodID: dateRangeValue,
        StatusFilter: "".concat(statusFilterValue),
        ResourceID: resourcesID
    }
    return compoundObjectWithForgeryToken(obj);
}

function buildGetProjectPhaseQuery(e) {
    var resID = $('#ResourceID').val();
    if (resID === '' || resID === undefined) {
        resID = $('#hideResourceID').val();
    }
    var obj = {
        ProjectID: $('#hideProjectID').val(),
        resourceID: resID
    }
    return obj;
}

function buildGetProjectNamesQuery() {
    //var resourcesID = $("#ResourceID").val() === undefined || $("#ResourceID").val() === "" ? 'NoData' : $("#ResourceID").val();
    var resourcesID = $('#hideResourceID').val();
    var obj = {
        userName: resourcesID
    }
    return obj;
}

function renderDropDownInGridCell(e) {
    if (e && e.DataText) {
        return e.DataText;
    }
    return '';
}

function getManagerName(userID) {
    $.ajax(
        {
            url: "/Timesheet/GetManagerName?userID=" + userID,
            type: 'get',
            contentType: 'application/json; charset=utf-8',
            async: false,
            success: function (result) {
                if (result) {
                    $('#ManageName').val(result.ManagerName);
                    $('#ProjectManagerName').val(result.TeamOwnerName);
                }
            },
            error: function (e) {
                DisplayNotification("Get Resource manager failed", "warning");
            }
        });
}

$(document).ready(function () {
    $('.k-grid-Add').click(function () {
        $.when($.post("/timesheet/CreateTimesheet")).then(function (data) {
            var timesheetWindow = $("#createTimesheet");
            timesheetWindow.html('');
            timesheetWindow.append(data);
            timesheetWindow = timesheetWindow.kendoWindow({
                modal: true,
                title: "Add timesheet",
                visible: false,
                width: "700px",
                actions: ["Close"],
                resizable: false
            }).data("kendoWindow");
            if (timesheetWindow) {
                timesheetWindow.center().open();
                timesheetWindow.bind("close", timesheetFormEditor.onWindowClose)
                $("#hideResourceID").val(loginUser);
                timesheetFormEditor.reloadProject(); 
            }
        });
    });

    $('.k-grid-Export').click(function () {
        exportExcel();
    });
});

function exportExcel() {
    var grid = $('.k-grid').data('kendoGrid');
    if (grid) {
        var columns = grid.columns.map(function (o) { if (!o.hidden) { return { title: o.title, field: o.field } } }).filter(function (o) { return o != undefined && o.title != undefined });

        $.when($.post("/timesheet/read", onDataFilter())).then(function (data) {
            var items = data && data.Data || [];
            var template = kendo.template($("#excelTemplate").html());
            var heads = columns.map(function (o) { return o.title; });
            // Create some dummy data.
            var rows = generateRows(columns, items);
            var data = { heads: heads, rows: rows };
            var result = template(data); //Execute the template
            toExcel(result, 'TimeSheet');
        })


    }
}

function generateRows(columns, items) {
    var rows = []
    for (var i = 0; i < items.length; i++) {
        var row = {}
        for (var j = 0; j < columns.length; j++) {

            if (items[i]) {
                var field = columns[j].field;
                var fieldValue = "";
                if (field.indexOf('DataText') > -1) {
                    field = field.replace('.DataText', '');
                    fieldValue = items[i][field] && items[i][field].DataText;
                } else {
                    fieldValue = items[i][field];
                }
                if (field == "Description" || field == "Comment") {
                    if (fieldValue) {
                        fieldValue = fieldValue.replaceAll('<ul>', '').replaceAll('<ol>', '').replaceAll('</ul>', '').replaceAll('</ol>', '').replaceAll('<li>', '').replaceAll(
                            '</li>', '</p>');
                        fieldValue = fieldValue.replaceAll('<p>', '').replaceAll('</p>', '<br style="mso-data-placement:same-cell;" />');

                    }
                }
                row[columns[j].field] = fieldValue || "";
            }
        }
        rows.push(row);
    }
    return rows;
}

function onSaveChanges(e) {
    var valid = true;
    var grid = $(".k-grid").data("kendoGrid");
    var rows = grid.tbody.find("tr");
    grid.options.editable.mode = "inline"
    var model = grid.dataItem(rows[0]);
    if (model && model.isNew()) {
        grid.editRow(rows[0]);
        var cols = $(rows[0]).find("td");
        for (var j = 0; j < cols.length; j++) {
            if (!grid.editable.validatable.options.rules.projectType_datatextvalidation($(cols[j]).find('input'))) {
                valid = false;
                break;
            }
        }
    }
    if (!valid) {
        e.preventDefault(true);
    } else {
        $('.k-grid-add').attr('disabled', false);
    }
    grid.options.editable.mode = "incell"
}

function onCellClose(e) {
    var model = e.model
    var container = e.container;
    if (model.dirtyFields.ProjectPhase) {
        container.addClass("k-dirty-cell");
        model.dirtyFields["ProjectPhase.DataText"] = true;
    }
}

var timesheetFormEditor = {
    onResourceChange: function (e) {
        var resourceID = e.sender._old;
        $("#hideResourceID").val(resourceID);
        timesheetFormEditor.reloadProject(); 
        timesheetFormEditor.reloadTsPhase();
    },
    onProjectNameChange: function (e) {
        var projectID = e.sender._old;
        $('#hideProjectID').val(projectID);
        timesheetFormEditor.reloadTsPhase();
    },
    onFormValidateField: function (e) {
        $("#validation-success").html("");
    },
    onFormSubmit: function (e) {
        timesheetFormEditor.submitData(false);
        e.preventDefault();
    },
    onFormCreateAndSubmit: function () {
        var validator = $("#CreateTimesheetForm").kendoValidator().data("kendoValidator");
        if (validator.validate()) {
            timesheetFormEditor.submitData(true);
        }
    },
    onFormClear: function (e) {
        $("#validation-success").html("");
    },
    submitData: function (isSubmit) {
        var data = {};
        data.ProjectID = $("#ProjectID").val();
        data.ResourceID = $("#ResourceID").val();
        data.ReportDate = $("#ReportDate").val();
        data.ActivityDescription = $("#ActivityDescription").val();
        data.Hours = $("#Hours").val();
        data.TFSID = $("#TFSID").val();
        data.TimesheetProjectPhaseID = $("#TimesheetProjectPhaseID").val();
        data.SubmitData = isSubmit;

        $.when($.ajax({
            url: "/timesheet/CreateTimesheetForm",
            type: "POST",
            data: data
        })).then(function (data) {
            kConfirm("Please Confirm", "Would you like to add new timesheet?").then(function () {
                $("#ActivityDescription").val('');
                $('#Hours').data("kendoNumericTextBox").value(null);
                $("#TFSID").val('');

            }, function () {
                var grid = $('#Timesheet').data('kendoGrid');
                grid.dataSource.read();
                var timesheetWindow = $("#createTimesheet").data("kendoWindow");
                timesheetWindow.close();
            });
        });
    },
    reloadProject: function () {
        var projectID = $("#ProjectID").data("kendoDropDownList");
        projectID.dataSource.read();
        projectID.value(null);
        projectID.refresh(); 
    },
    reloadTsPhase: function () {
        var tsPhase = $("#TimesheetProjectPhaseID").data("kendoDropDownList");
        tsPhase.dataSource.read();
        tsPhase.value(null);
        tsPhase.refresh(); 
    },
    onWindowClose: function () {
        var grid = $('#Timesheet').data('kendoGrid');
        grid.dataSource.read();
    }
};
