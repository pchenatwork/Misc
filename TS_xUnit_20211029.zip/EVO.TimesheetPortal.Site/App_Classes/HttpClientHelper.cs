﻿using System;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.App_Classes
{
    public class HttpClientHelper
    {
        public string Token { get; private set; }
        public HttpClientHelper(string token)
        {
            Token = token;
        }
        public async Task<string> PostAsync(string url, string json)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    BuildHeader(client);

                    var stringContent = new StringContent(json, Encoding.UTF8, "application/json");
                    using (HttpResponseMessage response = await client.PostAsync(url, stringContent))
                    {
                        response.EnsureSuccessStatusCode();
                        string responseBody = await response.Content.ReadAsStringAsync();
                        return responseBody;
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.ToString());
            }
            return "";
        }


        public async Task<string> GetAsync(string url)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    BuildHeader(client);
                    using (HttpResponseMessage response = await client.GetAsync(url))
                    {
                        response.EnsureSuccessStatusCode();
                        string responseBody = await response.Content.ReadAsStringAsync();
                        return responseBody;
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.ToString());
            }
            return "";
        }

        private void BuildHeader(HttpClient client)
        {
            if (string.IsNullOrWhiteSpace(Token))
            {
                throw new ArgumentException("Token is invalid.");
            }
            client.DefaultRequestHeaders.Accept.Add(
                           new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic",
                Convert.ToBase64String(
                    Encoding.ASCII.GetBytes(
                        string.Format("{0}:{1}", "", Token))));
        }
    }
}
