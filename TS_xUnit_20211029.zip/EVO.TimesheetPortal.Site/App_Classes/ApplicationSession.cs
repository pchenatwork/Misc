﻿using EVOUserWSServiceReference;
using Microsoft.AspNetCore.Http;
using System.Linq;
using System.Text;
using TimeSheetTrackerCore.Site.Models;

namespace EVO.TimesheetPortal.Site.App_Classes
{
    public class ApplicationSession
    {
        private static UserModel _user;

        public static string ApplicationName { get; set; } = "Time-sheet Portal";

        public static UserModel GetUser()
        {
            byte[] sessionStr = null;
            if (ApplicationContext.Current != null)
                sessionStr = ApplicationContext.Current.Session.Get("User");

            if (sessionStr == null)
            {
                return new UserModel();
            }
            _user = Newtonsoft.Json.JsonConvert.DeserializeObject<UserModel>(Encoding.UTF8.GetString(sessionStr));
            return _user;
        }

        public static void SetUser(UserModel user)
        {
            string userJson = Newtonsoft.Json.JsonConvert.SerializeObject(user);
            ApplicationContext.Current.Session.Set("User", Encoding.UTF8.GetBytes(userJson));
        }

        public static bool GetPermissionAccessByKey(string key)
        {
            UserPermissions permission = GetPermissionByKey(key);

            if (permission != null)
            {
                return true;
            }

            return false;
        }

        public static UserPermissions GetPermissionByKey(string key)
        {
            var user = GetUser().User;
            if (user == null || user.Permissions == null) return null;
            UserPermissions permission = GetUser().User?.Permissions.ToList().Find((p) =>
            {
                return !string.IsNullOrEmpty(p.PermissionName) && (p.PermissionName.ToLower() == key.ToLower());
            });

            return permission;
        }

        public static bool IsITExecutive
        {
            get
            {
                return GetUser().User.Roles.RoleName.ToLower().Equals("itexecutive") || IsTimesheetAdmin;
            }
        }

        public static bool IsAdmin { get { return GetUser().User.Roles.RoleName.ToLower().Equals("admin"); } }

        public static bool IsAccounting { get { return GetUser().User.Roles.RoleName.ToLower().Equals("accounting"); } }

        public static bool IsProjectAdmin
        {
            get
            {
                return GetUser().User.Roles.RoleName.ToLower().Equals("projectadmin")
                      || GetUser().User.Roles.RoleName.ToLower().Equals("admin");
            }
        }

        public static bool IsTimesheetAdmin
        {
            get
            {
                return GetUser().User.Roles.RoleName.ToLower().Equals("timesheetadmin")
                      || GetUser().User.Roles.RoleName.ToLower().Equals("admin");
            }
        }

        public static bool IsTeamAdmin
        {
            get
            {
                return GetUser().User.Roles.RoleName.ToLower().Equals("admin");
            }
        }

        public static bool IsManager
        {
            get
            {
                return GetUser().User.Roles.RoleName.ToLower().Equals("manager");
            }
        }

        public static string CurrentLanguage { get; set; } = "en-US";
    }
}