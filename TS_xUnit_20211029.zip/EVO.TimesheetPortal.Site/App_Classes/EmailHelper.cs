﻿using EmailService;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.App_Classes
{
    public class EmailHelper
    {
        private EmailServiceSoapClient EmailService;
        private IConfiguration Configuration;

        public EmailHelper(EmailServiceSoapClient emailService, IConfiguration configuration)
        {
            EmailService = emailService;
            Configuration = configuration;
        }

        public async Task<SaveResult> SendEmailAsync(EmailEntity emailEntity)
        {
            if (EmailService == null || Configuration == null)
            {
                throw new ArgumentNullException("EmailService/Configuration cannot null.");
            }
            var result = new SaveResult();
            if (emailEntity.IsValid)
            {
                result.Success = false;
                result.ErrorDescription = "To/Subject/Body are required.";
                return result;
            }

            string emailFromDefualt = Configuration.GetValue<string>("Email:From") ?? "ITDEV@evopayments.com";
            if (string.IsNullOrEmpty(emailEntity.From))
            {
                emailEntity.From = emailFromDefualt;
            }

            string emailTest = Configuration.GetValue<string>("Email:EmailTest") ?? string.Empty;

            // Swap emailTo to "EmailTest" if a valid email value is presented
            emailEntity.To = !string.IsNullOrEmpty(emailTest) ? emailTest : emailEntity.To;

            var email = new Email
            {
                Sender = emailEntity.From,
                Recipients = emailEntity.To,
                Subject = emailEntity.Subject,
                Body = emailEntity.Body + "</ br>"
            };

            if (!string.IsNullOrEmpty(emailEntity.Bcc))
                email.Bcc = emailEntity.Bcc;

            if (!string.IsNullOrEmpty(emailEntity.Cc))
                email.Cc = emailEntity.Cc;

            email.IsHtml = true;

            string applicationName = Configuration.GetValue<string>("Application:Name") ?? "Time-sheet Portal";

            try
            {
                result = await EmailService.SendEmailAsync(applicationName, 1, email);
            }
            catch (Exception ex)
            {
                result.ErrorDescription = "Email failed -- " + ex.Message;
                result.Success = false;
            }
            return result;
        }
    }

    public class EmailEntity
    {
        public string From { get; set; }
        public string To { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string Bcc { get; set; }
        public string Cc { get; set; }

        public bool IsValid
        {
            get
            {
                return string.IsNullOrEmpty(To) || string.IsNullOrEmpty(Subject) || string.IsNullOrEmpty(Body);
            }
        }
    }
}