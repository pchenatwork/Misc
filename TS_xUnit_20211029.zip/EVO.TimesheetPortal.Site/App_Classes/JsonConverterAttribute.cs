using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;
using System;
using System.IO;

namespace EVO.TimesheetPortal.Site
{
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class JsonConverterAttribute : ActionFilterAttribute
    {
        public string Model { get; set; }
        public Type JsonDataType { get; set; }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            string inputContent;
            using (var sr = new StreamReader(filterContext.HttpContext.Request.Body))
            {
                inputContent = sr.ReadToEndAsync().Result;
            }
            var result = JsonDataType.IsValueType ? Activator.CreateInstance(JsonDataType) : null;
            if (inputContent.Length > 0)
            {
                try
                {
                    result = JsonConvert.DeserializeObject(inputContent, JsonDataType);
                }
                catch
                {
                }
               
            }

            filterContext.ActionArguments[Model] = result;
        }
    }
}