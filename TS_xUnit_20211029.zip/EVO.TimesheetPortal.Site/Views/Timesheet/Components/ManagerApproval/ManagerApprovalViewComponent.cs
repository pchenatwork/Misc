﻿using EVO.TimesheetPortal.Site.Service;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Views.Timesheet.Components.ManagerApproval
{
    public class ManagerApprovalViewComponent : ViewComponent
    {
        private ITimeSheetService _TimesheetService;
        public ManagerApprovalViewComponent(ITimeSheetService timeSheetService)
        { 
            _TimesheetService = timeSheetService; 
        }
        public async Task<IViewComponentResult> InvokeAsync(int EmployeeId=0, string PeriodCode="")
        {
            if (string.IsNullOrEmpty(PeriodCode))
            {
                PeriodCode = DateTime.UtcNow.ToString("yyyyMM");
            }
            var apiResponse = await _TimesheetService.GetOutlookByEmployee(EmployeeId, PeriodCode);
            return View("Default", apiResponse.Content);
        }
    }
}
