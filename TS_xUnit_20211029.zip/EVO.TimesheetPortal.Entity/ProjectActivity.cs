﻿using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Entity
{
    public class ProjectActivity : ValueObjectBase
    {
        [XmlAttribute]
        public Project Project { get; set; }

        [XmlElement]
        public Setting Activity { get; set; }

        [XmlAttribute]
        public bool IsActive { get; set; }

    }
}