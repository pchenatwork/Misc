﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/15/2021  Dino          Created
* 10/15/2021  PCHEN         Modified to Business Entity
*=======================================================================*/

using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Xml.Serialization;

#endregion

namespace EVO.TimesheetPortal.Entity
{
    /// <summary>
    /// Geniric Business Entity Represent Timesheet (A group of TimesheetActivities) 
    /// by Resource, eg Employee or Team(group of Employee) 
    /// by Type (eg Project)
    /// with a date range
    /// </summary>
    [Serializable]
    public class Timesheet : ValueObjectBase
    {
        #region	Private Members
        private DateTime _fromDate = new DateTime(1900, 1, 1);
        private DateTime _toDate = new DateTime(1900, 1, 1);
        #endregion
        /// <summary>
        ///  Generic Resource (Employee or Team)depends on actual usage
        /// </summary>
        [XmlAttribute()]
        public int ResourceId { get; set; }
        [XmlAttribute()]
        public string ResourceName { get; set; }
        [XmlAttribute()]
        public string ResourceType { get; set; }
        /// <summary>
        ///  Generic Subject ID (eg ProjectID), 
        /// </summary>
        [XmlAttribute()]
        public int SubjectId { get; set; }
        [XmlAttribute()]
        public string SubjectName { get; set; }
        [XmlAttribute()]
        public string SubjectType { get; set; }
        [XmlAttribute()]
        public DateTime FromDate
        {
            get
            {
                return this._fromDate;
            }
            set
            {
                this._fromDate = value;
            }
        }
        [XmlAttribute()]
        public DateTime ToDate
        {
            get
            {
                return this._toDate;
            }
            set
            {
                this._toDate = value;
            }
        }
        [XmlAttribute()]
        public string PeriodCode { get; set; }
        [XmlAttribute()]
        public int PeriodStatusId { get; set; }
        public string PeriodStatus
        {
            get { return TimesheetPeriodStatusEnum.GetById(PeriodStatusId).Name; }
        }
        [XmlAttribute()]
        public int TimesheetStatusId { get; set; }
        public string TimesheetStatus
        {
            get { return TimesheetStatusEnum.GetById(TimesheetStatusId).Name; }
        }
        [XmlAttribute()]
        public decimal Hours { get; set; }
        [XmlArray("ArrayOfTimesheet")]
        public Collection<Timesheet> Details { get; set; }
        [XmlArray("ArrayOfTimesheetActivity")]
        public Collection<TimesheetActivity> Activities { get; set; }
    }
}
