﻿using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Entity
{
    public class TimeSheetAccounting : ValueObjectBase
    {
        [XmlAttribute]
        public int ProjectID { get; set; }
        [XmlAttribute]
        public string ProjectManager { get; set; }
        [XmlAttribute]
        public string ProjectName { get; set; }
        [XmlAttribute]
        public string Activity { get; set; }
        [XmlAttribute]
        public string Number { get; set; }
        [XmlAttribute]
        public string ProjectType { get; set; }
        [XmlAttribute]
        public string Description { get; set; }
        [XmlAttribute]
        public decimal Hours { get; set; }
        [XmlAttribute]
        public int ResourceID { get; set; }
        [XmlAttribute]
        public string UserID { get; set; }
        [XmlAttribute]
        public string ResourceName { get; set; }
        [XmlAttribute]
        public string ResourceManager { get; set; }
        [XmlAttribute]
        public string Status { get; set; }

        [XmlAttribute]
        public string Department { get; set; }
        [XmlAttribute]
        public string Country { get; set; }
        [XmlAttribute]
        public bool ProjectTypeCap { get; set; }
        [XmlAttribute]
        public bool PhaseTypeCap { get; set; }
        [XmlAttribute]
        public string PayLevel { get; set; }
    }
}
