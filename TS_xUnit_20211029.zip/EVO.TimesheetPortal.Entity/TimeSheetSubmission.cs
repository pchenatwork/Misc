﻿using FrameworkBase.ValueObject;
using System;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Entity
{
    public class TimeSheetSubmission : ValueObjectBase
    {
        [XmlAttribute()]
        public Employee Employee { get; set; }

        [XmlAttribute()]
        public string PeriodCode { get; set; }

        [XmlAttribute()]
        public Setting Status { get; set; }

        [XmlAttribute()]
        public DateTime? StatusDate { get; set; }
    }
}