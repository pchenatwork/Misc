﻿using FrameworkBase.ValueObject;
using System;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Entity
{
    [Serializable]
    public class EmailTemplate : ValueObjectBase
    {
        [XmlAttribute()]
        public int EmailTemplateID { get; set; }

        [XmlAttribute()]
        public string TemplateName { get; set; }

        [XmlAttribute()]
        public string EmailSubject { get; set; }

        [XmlAttribute()]
        public string EmailContent { get; set; }
    }
}