﻿using FrameworkBase.ValueObject;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Entity
{
    public class EmployeeActivityMap : ValueObjectBase
    {
        [XmlElement()]
        public Employee Employee { get; set; }

        [XmlElement()]
        public Project Project { get; set; }

        [XmlElement()]
        public Setting Activity { get; set; }

        [XmlAttribute()]
        public bool IsActive { get; set; }
        [XmlAttribute()]
        public int EmployeeId { get; set; }
        public int ActivityId { get; set; }
        public int ProjectId { get; set; }
    }
}