﻿using FrameworkBase.ValueObject;

namespace EVO.TimesheetPortal.Entity
{
    public class TimesheetPeriod : ValueObjectBase
    {
    }
}