﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/


using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Xml.Serialization;

#endregion

namespace EVO.TimesheetPortal.Entity
{
    [Serializable]
    public class Employee : ValueObjectBase
    {
        [XmlAttribute()]
        public string UserId { get; set; }

        [XmlAttribute()]
        public string FirstName { get; set; }

        [XmlAttribute()]
        public string LastName { get; set; }

        [XmlAttribute()]
        public string DisplayName { get; set; }

        [XmlAttribute()]
        public string Email { get; set; }

        [XmlAttribute()]
        public string Title { get; set; }

        [XmlAttribute()]
        public int JobGradeId { get; set; }

        [XmlAttribute()]
        public string DeptCode { get; set; }

        [XmlAttribute()]
        public string CountryCode { get; set; }

        [XmlElement()]
        public Employee Manager { get; set; }

        [XmlAttribute()]
        public bool EmailAlert { get; set; }

        [XmlAttribute()]
        public bool IsActive { get; set; }

        [XmlElement()]
        public Team Team { get; set; }

        [XmlArray("ArrayOfRoleName")]
        [XmlArrayItem("RoleName")]
        public List<string> RoleNames {get; set; }

        public bool IsAdmin { get; set; }

        public int  TeamOwnerId { get; set; }
    }
}
