﻿using FrameworkBase.ValueObject;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Entity
{
    public class Setting : ValueObjectBase
    {
        [XmlAttribute()]
        public string Name { get; set; }

        [XmlAttribute()]
        public string KeyVal { get; set; }

        [XmlAttribute()]
        public string TextVal { get; set; }

        [XmlAttribute()]
        public string Description { get; set; }

        [XmlAttribute()]
        public int ParentId { get; set; }

        [XmlAttribute()]
        public int OrderSeq { get; set; }
    }
}