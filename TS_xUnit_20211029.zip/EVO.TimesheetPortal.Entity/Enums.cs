﻿#region
using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Text;
#endregion


/*=======================================================================
 * Note: A place where All Enums can be defined
 * Enums are values that usually doesn't change over time
 * "Setting" stored in [Enum] table too, but values will change
 * Both "Enum" and "Setting" are defined in [Enum] table
 * ------------------------------------------------------------
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/
namespace EVO.TimesheetPortal.Entity
{    
    public class ProjectStatusEnum : EnumBase<ProjectStatusEnum>
    {
        #region Enumeration Elements
        /* ==========================================================================
         * Name: ProjectStatusEnum
         * Description:  Enum ID here need to match to KeyVal in [Enum] Table
         * ==========================================================================*/
        public static readonly ProjectStatusEnum Draft = new ProjectStatusEnum(0, "Draft", "Not Submitted Yet");
        public static readonly ProjectStatusEnum PendAppv = new ProjectStatusEnum(1, "Pending", "Pending Manager Approval");
        public static readonly ProjectStatusEnum Approved = new ProjectStatusEnum(2, "Approved", "IT Executive Approved");
        public static readonly ProjectStatusEnum Rejected = new ProjectStatusEnum(3, "Rejected", "Rejected");
        public static readonly ProjectStatusEnum Closed = new ProjectStatusEnum(4, "Closed", "Closed");
        public static readonly ProjectStatusEnum Impaired = new ProjectStatusEnum(5, "Impaired", "Impaired");
        public static readonly ProjectStatusEnum Deleted = new ProjectStatusEnum(-1, "Deleted", "Deleted");

        #endregion

        #region Constructors
        private ProjectStatusEnum(int id, string name, string extra) : base(id, name, extra)
        {
        }
        #endregion
    }
    public class TimesheetStatusEnum : EnumBase<TimesheetStatusEnum>
    {
        #region Enumeration Elements
        /* ==========================================================================
         * Name: TimesheetStatusEnum
         * Description:  Enum ID here need to match to KeyVal in [Enum] Table
         * ==========================================================================*/
        public static readonly TimesheetStatusEnum Draft = new TimesheetStatusEnum(0, "Draft", "Not Submitted Yet");
        public static readonly TimesheetStatusEnum MgrAppv = new TimesheetStatusEnum(1, "Manager Approved", "Manager Approved");
        public static readonly TimesheetStatusEnum Approved = new TimesheetStatusEnum(2, "Executive Approved", "IT Executive Approved");

        #endregion

        #region Constructors
        private TimesheetStatusEnum(int id, string name, string extra) : base(id, name, extra)
        {
        }
        #endregion
    }
    public class TimesheetPeriodStatusEnum : EnumBase<TimesheetPeriodStatusEnum>
    {
        #region Enumeration Elements
        /* ==========================================================================
         * Name: TimesheetPeriodStatusEnum
         * Description:  Enum ID here need to match to KeyVal in [Enum] Table
         * ==========================================================================*/
        public static readonly TimesheetPeriodStatusEnum NotCurrent = new TimesheetPeriodStatusEnum(0, "Not Current", "Future Accounting Period");
        public static readonly TimesheetPeriodStatusEnum Current = new TimesheetPeriodStatusEnum(1, "Current", "Current Accounting Period");
        public static readonly TimesheetPeriodStatusEnum Closed = new TimesheetPeriodStatusEnum(2, "Closed", "Accounting Period Closed");

        #endregion

        #region Constructors
        private TimesheetPeriodStatusEnum(int id, string name, string extra) : base(id, name, extra)
        {
        }
        #endregion

    }
}
