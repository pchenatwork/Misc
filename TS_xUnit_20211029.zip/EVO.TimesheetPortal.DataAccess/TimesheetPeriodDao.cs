﻿using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;

namespace EVO.TimesheetPortal.DataAccess
{
    public class TimesheetPeriodDao : DaoBase<TimesheetPeriod>
    {
        private const string CLASSNAME = nameof(TimesheetPeriodDao);

        #region Constructor

        private TimesheetPeriodDao()
        {
        }

        static TimesheetPeriodDao()
        {
            // logger can go here if needed
        }

        #endregion Constructor

        public override int Create(IDbSession dbSession, TimesheetPeriod eneity)
        {
            return _Upsert(dbSession, eneity);
        }

        #region Custon Dao Method

        private static int _Upsert(IDbSession dbSession, TimesheetPeriod entity)
        {
            var paras = new List<SqlParameter>();
            int rowcount;
            rowcount = ExecuteNonQuery(dbSession, "SPU_TimesheetPeriod_Insert", paras, out object retval);
            return (int)retval;
        }

        #endregion Custon Dao Method
    }
}