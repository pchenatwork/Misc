﻿/*=======================================================================
* Modification History:
* ----------------------------------------------------------------------
* 10/14/2021   DINO       Introduced
*=======================================================================*/

using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using FrameworkBase.ValueObject;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Data;
using System.Xml;

namespace EVO.TimesheetPortal.DataAccess
{
    public class SettingDao : DaoBase<Setting>
    {
        private const string CLASSNAME = nameof(SettingDao);

        private SettingDao()
        {
        }

        public override IEnumerable<Setting> FindByEntity(IDbSession dbSession, IValueObject entity)
        {
            Setting criteria = (Setting)entity;
            List<SqlParameter> listSqlParameter = new List<SqlParameter>();
            if (criteria != null)
            {
                listSqlParameter = new List<SqlParameter>
                            {
                                new SqlParameter("@Name",criteria.Name),
                                new SqlParameter("@KeyVal", criteria.KeyVal),
                                new SqlParameter("@TextVal", criteria.TextVal),
                                new SqlParameter("@Description", criteria.Description)
                            };
            }

            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Setting_FindByCriteria", listSqlParameter);
            return DeserializeCollection(reader);
        }

        public override Setting Get(IDbSession dbSession, dynamic id)
        {
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@Id", id);
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Setting_Get", parameters);
            return Deserialize(reader);
        }

        public override int Create(IDbSession dbSession, Setting newObject)
        {
            return _Upsert(dbSession, newObject);
        }

        public override bool Update(IDbSession dbSession, Setting obj)
        {
            return _Upsert(dbSession, obj) > 0;
        }

        public override bool Delete(IDbSession dbSession, dynamic Id, dynamic By)
        {
            var paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("@Id", Id));
            return ExecuteNonQuery(dbSession, "SPU_Setting_Delete", paras, out object retval) > 0;
        }

        private static int _Upsert(IDbSession dbSession, Setting eneity)
        {
            var paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("@Id", eneity.Id));
            paras.Add(new SqlParameter("@Name", eneity.Name));
            paras.Add(new SqlParameter("@KeyVal", eneity.KeyVal));
            paras.Add(new SqlParameter("@TextVal", eneity.TextVal));
            paras.Add(new SqlParameter("@Description", eneity.Description));
            paras.Add(new SqlParameter("@ParentId", eneity.ParentId));
            paras.Add(new SqlParameter("@OrderSeq", eneity.OrderSeq));

            int rowcount;
            rowcount = ExecuteNonQuery(dbSession, "SPU_Setting_UpSert", paras, out object retval);
            return (int)retval;
        }
    }
}