﻿/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/14/2021   DINO       Introduced
*=======================================================================*/

using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Data;
using System.Xml;

namespace EVO.TimesheetPortal.DataAccess
{
    public class EmployeeActivityMapDao : DaoBase<EmployeeActivityMap>
    {
        private const string CLASSNAME = nameof(EmployeeActivityMapDao);

        private EmployeeActivityMapDao()
        {
        }

        //public override IEnumerable<EmployeeActivityMap> FindByCriteria(IDbSession dbSession, string finderType, EmployeeActivityMap criteria)
        //{
        //    switch (finderType)
        //    {
        //        case _FIND:
        //            {
        //                List<SqlParameter> listSqlParameter = new List<SqlParameter>();
        //                if (criteria != null)
        //                {
        //                    listSqlParameter = new List<SqlParameter>
        //                    {
        //                        new SqlParameter("@ProjectId",criteria.Project?.Id),
        //                        new SqlParameter("@ActivityId", criteria.Activity?.Id),
        //                        new SqlParameter("@EmployeeId", criteria.Employee?.Id)
        //                    };
        //                }

        //                XmlReader reader = ExecuteXmlReader(dbSession, "SPU_EmployeeActivityMap_Find", listSqlParameter);
        //                return DeserializeCollection(reader);
        //            }
        //        default:
        //            return null;
        //    }
        //}

        public override bool Delete(IDbSession dbSession, dynamic Id, dynamic By)
        {
            var paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("@Id", Id));
            return ExecuteNonQuery(dbSession, "SPU_EmployeeActivityMap_Delete", paras, out object retval) > 0;
        }

        public override EmployeeActivityMap Get(IDbSession dbSession, dynamic id)
        {
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@Id", id);
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_EmployeeActivityMap_Get", parameters);
            return Deserialize(reader);
        }

        public override int Create(IDbSession dbSession, EmployeeActivityMap newObject)
        {
            return _Upsert(dbSession, newObject);
        }

        public override bool Update(IDbSession dbSession, EmployeeActivityMap obj)
        {
            return _Upsert(dbSession, obj) > 0;
        }

        private static int _Upsert(IDbSession dbSession, EmployeeActivityMap eneity)
        {
            var paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("@Id", eneity.Id));
            paras.Add(new SqlParameter("@ProjectId", eneity.Project?.Id));
            paras.Add(new SqlParameter("@EmployeeId", eneity.Employee?.Id));
            paras.Add(new SqlParameter("@ActivityId", eneity.Activity?.Id));
            paras.Add(new SqlParameter("@IsActive", eneity.IsActive));
            paras.Add(new SqlParameter("@By", eneity.UpdateBy));

            int rowcount;
            rowcount = ExecuteNonQuery(dbSession, "SPU_EmployeeActivityMap_UpSert", paras, out object retval);
            return (int)retval;
        }
    }
}
