﻿using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimesheetPortal.DataAccess
{
    public class ApplicationLogDao : DaoBase<ApplicationLog>
    {
        #region	Constructors
        private ApplicationLogDao()
        {
        }
        #endregion constructors

        #region Override IDataAccessObject
        public override int Create(IDbSession dbSession, ApplicationLog log)
        {
            var parameters = new List<SqlParameter>
                {
                    new SqlParameter("@Message", log.Message),
                    new SqlParameter("@StackTrace", log.StackTrace),
                    new SqlParameter("@UserName", log.UserName),
                    new SqlParameter("@OperatingSystem", log.OperatingSystem),
                    new SqlParameter("@Browser", log.Browser),
                    new SqlParameter("@MachineName", log.MachineName),
                    new SqlParameter("@Date", log.Date)
                };
            int rowcount;
            rowcount = ExecuteNonQuery(dbSession, "SPU_ApplicationLog_Insert", parameters, out object retval);
            return (int)retval;
        }

        public override IEnumerable<ApplicationLog> GetAll(IDbSession dbSession)
        {

            return _Find(dbSession, "SPU_ApplicationLog_Find", "{}");

            //List<SqlParameter> listSqlParameter = new List<SqlParameter>();
            //var reader = ExecuteXmlReader(dbSession, "SPU_ApplicationLog_Find", listSqlParameter);
            //return DeserializeCollection(reader);
        }
        #endregion

    }
}
