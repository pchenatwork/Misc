﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using FrameworkBase.Common;
using FrameworkBase.DataAccess;
using FrameworkBase.ValueObject;
using System;
using System.Linq;
using System.Reflection;
#endregion

namespace EVO.TimesheetPortal.DataAccess
{
    /// <summary>
    /// Singleton Factory Method to create {{Entity}}Dao 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public sealed class DaoFactory<T> : FactoryBase<DaoFactory<T>> where T : IValueObject
    {
        /// <summary>
        /// Make sure "{{ValueObjectName}}Dao" class exists in the Assembly
        /// </summary>
        /// <param name="daoClassName"></param>
        /// <returns></returns>
        public DaoBase<T> GetDao()
        {
            try
            {
                // ClassName should be in convention of "{{ValueObjectName}}Dao"
                string sClassName = typeof(T).Name.ToLower() + "dao";
                // Search type in current assembly
                Type type = (from t in Assembly.GetExecutingAssembly().GetTypes()
                             where t.IsClass && t.Name.ToLower().Equals(sClassName)
                             select t).Single();
                // create instance by reflection
                return Activator.CreateInstance(type,
                     BindingFlags.NonPublic | BindingFlags.Instance, null,
                     null, null) as DaoBase<T>;
            }
            catch
            {
                //throw new SystemException(e.InnerException.Message, e.InnerException);
                return null;
            }
        }
    }
}

