﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using FrameworkBase.DataAccess;

using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Xml;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.Util;
using FrameworkBase.ValueObject;
using System.Linq;
#endregion

namespace EVO.TimesheetPortal.DataAccess
{
    public class EmployeeDao : DaoBase<Employee>
    {
        #region constants
        private const string CLASSNAME = nameof(EmployeeDao);
        #endregion

        #region	Constructors
        private EmployeeDao()
        {
        }
        #endregion constructors

        #region Override IDataAccessObject
        /// <summary>
        /// Dynamic ID == EmployeeId(INT) or UserId(STRING)
        /// </summary>
        /// <param name="dbSession"></param>
        /// <param name="id">Employee.Id (int) or Employee.UserId (sting) </param>
        /// <returns></returns>
        public override Employee Get(IDbSession dbSession, dynamic id)
        {
            string @paramname = (id.GetType().ToString() == "System.Int32") ? "@Id" : "@UserId";

            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter(@paramname, id);
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Employee_Get", parameters);
            return Deserialize(reader);
        }
        public override int Create(IDbSession dbSession, Employee employee)
        {
            var  employeeId = _Upsert(dbSession, employee);
            employee.Id = employeeId;
            if (employee.Team !=null && employee.Team.Id > 0)
            {                
               var isSuccess = SaveTeamEmployee(dbSession, employee);
            }

            if(employee.RoleNames !=null && !string.IsNullOrWhiteSpace(string.Join("", employee.RoleNames.ToArray())))
            {
                var isSuccess = SaveEmployeeRole(dbSession, employee);
            }
            return employeeId;
        }
        public override bool Update(IDbSession dbSession, Employee employee)
        {
            if (employee.Team != null && employee.Team.Id > 0)
            {
                var isSuccess = SaveTeamEmployee(dbSession, employee);
            }

            if (employee.RoleNames != null && !string.IsNullOrWhiteSpace(string.Join("", employee.RoleNames.ToArray())))
            {
                var isSuccess = SaveEmployeeRole(dbSession, employee);
            }
            return _Upsert(dbSession, employee) > 0;
        }
        /// <summary>
        /// Soft delete
        /// </summary>
        /// <param name="dbSession"></param>
        /// <param name="Id"></param>
        /// <param name="By"></param>
        /// <returns></returns>
        public override bool Delete(IDbSession dbSession, dynamic Id, dynamic By)
        {
            Employee e = this.Get(dbSession, Id);
            e.IsActive = false;
            e.UpdateBy = By;
            return _Upsert(dbSession, e) > 0;
        }

        public override IEnumerable<Employee> Find(IDbSession dbSession, string jsonTokens)
        {
            return _Find(dbSession, "SPU_Employee_Find", jsonTokens);
        }

        public override IEnumerable<Employee> FindByEntity(IDbSession dbSession, IValueObject entity)
        {
            Employee criteria = (Employee)entity;

            List<SqlParameter> listSqlParameter = new List<SqlParameter>();
            if (criteria != null)
            {
                if (criteria.UserId != null)
                    listSqlParameter.Add(new SqlParameter("@UserId", criteria.UserId));
                if (criteria.Team !=null)
                    listSqlParameter.Add(new SqlParameter("@TeamId", criteria.Team.Id));
                if (criteria.Id > 0)
                    listSqlParameter.Add(new SqlParameter("@Id", criteria.Id));

                if (criteria.TeamOwnerId > 0)
                    listSqlParameter.Add(new SqlParameter("@OwnerId", criteria.TeamOwnerId));
              
            }

            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Employee_FindByCriteria", listSqlParameter);
            return DeserializeCollection(reader);
            
        }

        public override IEnumerable<Employee> GetAll(IDbSession dbSession)
        {
            return _Find(dbSession, "SPU_Employee_Find", "");
        }

        public bool SaveTeamEmployee(IDbSession dbSession, Employee employee)
        {
            var sqlParameters = new List<SqlParameter>();
            sqlParameters.Add(new SqlParameter("@TeamId", employee.Team.Id));
            sqlParameters.Add(new SqlParameter("@EmployeeId", employee.Id));
            sqlParameters.Add(new SqlParameter("@IsActive", employee.Team.IsActive));
            sqlParameters.Add(new SqlParameter("@By", employee.UpdateBy));

            int rowcount = ExecuteNonQuery(dbSession, "SPU_TeamEmployee_UpSert", sqlParameters, out object retval);
            return (int)retval > 0;
        }


        public bool SaveEmployeeRole(IDbSession dbSession, Employee employee)
        {
            var sqlParameters = new List<SqlParameter>();    
            sqlParameters.Add(new SqlParameter("@EmployeeId", employee.Id));
            sqlParameters.Add(new SqlParameter("@RoleName", employee.RoleNames.FirstOrDefault()));
            sqlParameters.Add(new SqlParameter("@IsActive", employee.Team.IsActive));
            sqlParameters.Add(new SqlParameter("@By", employee.UpdateBy));

            int rowcount = ExecuteNonQuery(dbSession, "SPU_EmployeeRole_UpSert", sqlParameters, out object retval);
            return (int)retval > 0;
        }

        #endregion

        #region Custon Methods

        /// <summary>
        /// Dummy method for DEMO purpose
        /// </summary>
        /// <param name="dbSession"></param>
        /// <param name="finderType"></param>
        /// <returns></returns>
        public IEnumerable<string> MyDaoMethod1(IDbSession dbSession, params object[] criteria)
        {
            // Mimic a database lookup
            List<string> l = new List<string>();

            l.Add("Added from EmployeeDao.MyMethod1");

            int i = 0;
            foreach (var x in criteria)
            {
                l.Add("criteria["+ i + "] : " + x.ToString());
                i++;
            }

            return l;
        }

        #endregion

        #region Private Wrapper Methods
        /// <summary>
        ///     Wrapper function for sp 'SPU_Employee_UpSert'.
        /// </summary>
        private static int _Upsert(IDbSession dbSession, Employee e)
        {
            var L = new List<SqlParameter>();
            L.Add(new SqlParameter("@Id", e.Id));
            L.Add(new SqlParameter("@UserId", e.UserId));
            L.Add(new SqlParameter("@FirstName", e.FirstName));
            L.Add(new SqlParameter("@LastName", e.LastName));
            L.Add(new SqlParameter("@DisplayName", e.DisplayName));
            L.Add(new SqlParameter("@Email", e.Email));
            L.Add(new SqlParameter("@Title", e.Title));
            L.Add(new SqlParameter("@JobGradeId", e.JobGradeId));
            L.Add(new SqlParameter("@DeptCode", e.DeptCode));
            L.Add(new SqlParameter("@CountryCode", e.CountryCode));
            L.Add(new SqlParameter("@ManagerId", e.Manager.Id));
            L.Add(new SqlParameter("@EmailAlert", e.EmailAlert));
            L.Add(new SqlParameter("@IsActive", e.IsActive));
            L.Add(new SqlParameter("@By", e.UpdateBy));

            int rowcount;
            rowcount = ExecuteNonQuery(dbSession, "SPU_Employee_UpSert", L, out object retval);
            return (int)retval;
        }

        #endregion
    }
}
