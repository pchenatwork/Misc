﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using FrameworkBase.DataAccess;

using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Xml;
using EVO.TimesheetPortal.Entity;
#endregion


namespace EVO.TimesheetPortal.DataAccess
{
    public class TimesheetActivityDao : DaoBase<TimesheetActivity>
    {
        #region	Constructors
        private TimesheetActivityDao()
        {
        }
        #endregion constructors

        #region Override IDataAccessObject
        public override TimesheetActivity Get(IDbSession dbSession, dynamic id)
        {
            SqlParameter[] p = new SqlParameter[] { new SqlParameter("@Id", id) };
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_TimesheetActivity_Get", p);
            return Deserialize(reader);
        }

        public  TimesheetActivity GetByCriteria(IDbSession dbSession, TimesheetActivity e)
        {
            var L = new List<SqlParameter>();
            L.Add(new SqlParameter("@EmployeeId", e.EmployeeId));
            L.Add(new SqlParameter("@ProjectId", e.ProjectId));
            L.Add(new SqlParameter("@ActivityId", e.ActivityId));
            L.Add(new SqlParameter("@ActivityDate", e.ActivityDate));
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_TimesheetActivity_GetByCriteria", L);
            return Deserialize(reader);
        }

        
        public override int Create(IDbSession dbSession, TimesheetActivity ts)
        {
            return _Upsert(dbSession, ts, ts.CreateBy);
        }
        public override bool Update(IDbSession dbSession, TimesheetActivity ts)
        {
            return _Upsert(dbSession, ts,ts.UpdateBy) > 0;
        }
        public override bool Delete(IDbSession dbSession, dynamic Id, dynamic By = null)
        {
            SqlParameter[] p = new SqlParameter[] { new SqlParameter("@Id", Id) };

            int rowcount = ExecuteNonQuery(dbSession, "SPU_TimesheetActivity_Delete", p, out object retval);
            return rowcount >=1;
        }
        public override IEnumerable<TimesheetActivity> Find(IDbSession dbSession, string jsonTokens)
        {
            return _Find(dbSession, "SPU_TimesheetActivity_Find", jsonTokens);
        }
        #endregion
        public IEnumerable<TimesheetActivity> FindDailyData(IDbSession dbSession, string jsonTokens)
        {
            return _Find(dbSession, "SPU_TimeSheetActivity_Find_Daily", jsonTokens);
        }

        #region Private Wrapper Methods
        /// <summary>
        ///     Wrapper function for sp 'SPU_TimesheetActivity_UpSert'.
        /// </summary>
        private static int _Upsert(IDbSession dbSession, TimesheetActivity e,string updateBy)
        {
            var L = new List<SqlParameter>();
            L.Add(new SqlParameter("@Id", e.Id));  
            L.Add(new SqlParameter("@EmployeeId", e.EmployeeId));
            L.Add(new SqlParameter("@ProjectId", e.ProjectId));
            L.Add(new SqlParameter("@ActivityId", e.ActivityId));
            L.Add(new SqlParameter("@ActivityDate", e.ActivityDate));
            L.Add(new SqlParameter("@Hours", e.Hours));
            L.Add(new SqlParameter("@Description", e.Description));
            L.Add(new SqlParameter("@By", updateBy));

            int rowcount;
            rowcount = ExecuteNonQuery(dbSession, "SPU_TimesheetActivity_UpSert", L, out object retval);
            return (int)retval;
        }

        #endregion
    }
}

