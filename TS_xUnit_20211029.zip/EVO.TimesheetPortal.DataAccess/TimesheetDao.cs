﻿/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/14/2021   DINO       Introduced
* 
*=======================================================================*/

using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Xml;

namespace EVO.TimesheetPortal.DataAccess
{
    public class TimesheetDao : DaoBase<Timesheet>
    {
        private const string CLASSNAME = nameof(TimesheetDao);

        #region Constructor
        private TimesheetDao() { }
        static TimesheetDao()
        {
            // logger can go here if needed
        }
        #endregion

        #region Custon Dao Method

        public DataTable GetOutlookByExecutiveSummary(IDbSession dbSession, string PeriodCode)
        {
            SqlParameter[] p = new SqlParameter[] { new SqlParameter("@PeriodCode", PeriodCode) };
            return ExecuteReader(dbSession, "SPU_Timesheet_Outlook_Teams", p);
            /*** PCHEN Note: With _V2 value is return as {{Hours}}::{{ProjectId}}::{{TeamId}}  *****/
        }

        public DataTable GetOutlookProjectSummary(IDbSession dbSession, string periodCode)
        {
            SqlParameter[] p = new SqlParameter[] { new SqlParameter("@PeriodCode", periodCode) };
            return ExecuteReader(dbSession, "SPU_Timesheet_Outlook_Project", p);
           
        }

        public Timesheet GetOutlookByTeamResource(IDbSession dbSession, string periodCode)
        {
            
            SqlParameter[] p = new SqlParameter[] { new SqlParameter("@PeriodCode", periodCode) };
             XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Timesheet_Outlook_TeamResource", p);
            return Deserialize(reader);
        }
        private Timesheet GetOutlookByTeamProject(IDbSession dbSession, int TeamId, int ProjectId, string PeriodCode)
        {
            var parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("@TeamId", TeamId);
            parameters[1] = new SqlParameter("@ProjectId", ProjectId);
            parameters[2] = new SqlParameter("@PeriodCode", PeriodCode);
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Timesheet_Outlook_TeamProject", parameters);
            return Deserialize(reader);
        }
        private Timesheet GetOutlookByEmployee(IDbSession dbSession, int EmployeeId, string PeriodCode)
        {
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@EmployeeId", EmployeeId);
            parameters[1] = new SqlParameter("@PeriodCode", PeriodCode);
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Timesheet_Outlook_Employee", parameters);
            return Deserialize(reader);
        }
        private Timesheet GetOutlookByEmployeeProject(IDbSession dbSession, int EmployeeId, int ProjectId, string PeriodCode)
        {
            var parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("@EmployeeId", EmployeeId);
            parameters[1] = new SqlParameter("@ProjectId", ProjectId);
            parameters[2] = new SqlParameter("@PeriodCode", PeriodCode);
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Timesheet_Outlook_EmployeeProject", parameters);
            return Deserialize(reader);
        }
        private bool ManagerApproval(IDbSession dbSession, int EmployeeId, string PeriodCode, string JsonTSActivityIds, string By)
        {
            var parameters = new SqlParameter[4];
            parameters[0] = new SqlParameter("@EmployeeId", EmployeeId);
            parameters[1] = new SqlParameter("@PeriodCode", PeriodCode);
            parameters[2] = new SqlParameter("@TimesheetActivityIdsJSON", JsonTSActivityIds);
            parameters[3] = new SqlParameter("@By", By);

            int rowcount = ExecuteNonQuery(dbSession, "SPU_Timesheet_ManagerApproval", parameters, out object retval);
            return (int)retval == 0;
        }
        private bool ExecutiveApproval(IDbSession dbSession, string PeriodCode, string By, string Comment = null)
        {
            var parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("@PeriodCode", PeriodCode);
            parameters[1] = new SqlParameter("@Comment", Comment);
            parameters[2] = new SqlParameter("@By", By);

            int rowcount = ExecuteNonQuery(dbSession, "SPU_Timesheet_ExecutiveApproval", parameters, out object retval);
            return (int)retval == 0;
        }

        private IEnumerable<Timesheet> GetTrendData(IDbSession dbSession, int EmployeeId, string PeriodCode)
        {
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@EmployeeId", EmployeeId);
            parameters[1] = new SqlParameter("@PeriodCode", PeriodCode);

            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Timesheet_Outlook_TrendReport", parameters);
            return DeserializeCollection(reader);
        }

        private Timesheet GetOutlookTeamResource(IDbSession dbSession, string PeriodCode)
        {
            var parameters = new SqlParameter[] {new SqlParameter("@PeriodCode", PeriodCode) };
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Timesheet_Outlook_TeamResource", parameters);
            return Deserialize(reader);
        }
        #endregion
    }
}