﻿using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using FrameworkBase.ValueObject;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Xml;

namespace EVO.TimesheetPortal.DataAccess
{
    public class EmailTemplateDao : DaoBase<EmailTemplate>
    {
        private const string CLASSNAME = nameof(EmailTemplateDao);

        private EmailTemplateDao()
        {
        }

        static EmailTemplateDao()
        {
            // logger can go here if needed
        }

        public override IEnumerable<EmailTemplate> FindByEntity(IDbSession dbSession, IValueObject entity)
        {
            EmailTemplate criteria = (EmailTemplate)entity;
            List<SqlParameter> listSqlParameter = new List<SqlParameter>();
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_EmailTemplate_FindByCriteria", listSqlParameter);
            var result = DeserializeCollection(reader);
            return result;
        }
    }
}