﻿using EVO.TimesheetPortal.BusinessLogic;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.AspNetCore.Mvc;

namespace TimeSheetTracker.Api.Controllers
{
    /// <summary>
    ///
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class TimesheetPeriodController : ApiControllerBase<IDbSession>
    {
        private readonly TimesheetPeriodManager manager = null;

        /// <summary>
        ///
        /// </summary>
        /// <param name="dbSession"></param>
        public TimesheetPeriodController(IDbSession dbSession) : base(dbSession)
        {
            manager = (TimesheetPeriodManager)ManagerFactory<TimesheetPeriod>.Instance.GetManager(dbSession);
        }

        /// <summary>
        ///
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public int Insert()
        {
            //var result = manager.Create(new TimesheetPeriod());
            return 0;
        }
    }
}