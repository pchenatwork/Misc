﻿using DocumentFormat.OpenXml.ExtendedProperties;
using DocumentFormat.OpenXml.Office2010.Excel;
using EVO.TimesheetPortal.BusinessLogic;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using EVO.Common.UtilityCore;

using System.Text.Json;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TimeSheetTracker.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TimesheetController : ApiControllerBase<IDbSession>
    {
        private readonly TimesheetManager Manager = null;
        public TimesheetController(IDbSession dbSession) : base(dbSession)
        {
            Manager = (TimesheetManager)ManagerFactory<Timesheet>.Instance.GetManager(dbSession);
        }

        [HttpGet]
        [Route("GetExecutiveSummary")]
        public async Task<ActionResult> GetOutlookByExecutiveSummary(string periodCode)
        {
            if (string.IsNullOrWhiteSpace(periodCode))
                return null;
            var data = Manager.GetOutlookByExecutiveSummary(periodCode);
           
            JsonSerializerOptions options = new JsonSerializerOptions()
            { Converters = { new DataTableJsonConverter() }, WriteIndented = true };

            var jsonString = System.Text.Json.JsonSerializer.Serialize(data, options);
           
            return  Content(jsonString);
        }

        [HttpGet]
        [Route("GetOutlookProjectSummary")]
        public async Task<ActionResult> GetOutlookProjectSummary(string periodCode)
        {
            if (string.IsNullOrWhiteSpace(periodCode))
                return null;
            var data = Manager.GetOutlookProjectSummary(periodCode);

            JsonSerializerOptions options = new JsonSerializerOptions()
            { Converters = { new DataTableJsonConverter() }, WriteIndented = true };

            var jsonString = System.Text.Json.JsonSerializer.Serialize(data, options);

            return Content(jsonString);
        }

        [HttpGet]
        [Route("GetOutlookByTeamResource")]
        public async Task<Timesheet> GetOutlookByTeamResource(string periodCode)
        {
            if (string.IsNullOrWhiteSpace(periodCode))
                return null;
            var data = Manager.GetOutlookByTeamResource(periodCode);

            return data;
        }

        [HttpPost]
        [Route("ExecutiveApproval")]
        public bool ExecutiveApproval(string periodCode, string updateBy,string comments =null)
        {
            var list = Manager.ExecutiveApproval(periodCode, updateBy,comments);
            return list;
        }



        [HttpGet]
        [Route("GetOutlookByTeamProject")]
        public async Task<Timesheet> GetOutlookByTeamProject(int teamId, int projectId, string periodCode)
        {
            var list = Manager.GetOutlookByTeamProject(teamId, projectId, periodCode);
            return list;

        }




        [HttpGet]
        [Route("GetOutlookByEmployee")]
        public async Task<Timesheet> GetOutlookByEmployee(int employeeId, string periodCode)
        {
            var list = Manager.GetOutlookByEmployee(employeeId, periodCode);
            return list;
        }

        [HttpGet]
        [Route("GetOutlookByEmployeeProject")]
        public Timesheet GetOutlookByEmployeeProject(int employeeId, int projectId, string periodCode)
        {
            var list = Manager.GetOutlookByEmployeeProject(employeeId, projectId, periodCode);
            return list;
        }

        [HttpGet]
        [Route("ManagerApproval")]
        public bool ManagerApproval(int employeeId,  string periodCode,string by)
        {
            var list = Manager.ManagerApproval(employeeId, periodCode,by);
            return list;
        }

        [HttpGet]
        [Route("GetTrendData")]
        public async Task<IEnumerable<Timesheet>> GetTrendData(int employeeId, string periodCode)
        {
            var list = Manager.GetTrendData(employeeId, periodCode);
            return list;
        }
    }
}
