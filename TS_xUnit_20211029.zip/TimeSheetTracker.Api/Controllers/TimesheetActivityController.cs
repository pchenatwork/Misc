﻿using DocumentFormat.OpenXml.ExtendedProperties;
using DocumentFormat.OpenXml.Office2010.Excel;
using EVO.TimesheetPortal.BusinessLogic;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TimeSheetTracker.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TimesheetActivityController : ApiControllerBase<IDbSession>
    {
        private readonly TimesheetActivityManager Manager = null;
        public TimesheetActivityController(IDbSession dbSession) : base(dbSession)
        {
            Manager = (TimesheetActivityManager)ManagerFactory<TimesheetActivity>.Instance.GetManager(dbSession);
        }

        /// <summary>
        /// get daily timesheet data of an employee at certain day.
        /// </summary>
        /// <param name="employeeId"></param>
        /// <param name="activityDate"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetDaily")]
        public IList<TimesheetActivity> GetDaily(int employeeId,DateTime activityDate)
        {
            var data = Manager.FindByDate(employeeId, activityDate);
            return data;
        }

        /// <summary>
        ///
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public TimesheetActivity Get(int Id)
        {
            var entity = Manager.Get(Id);
            return entity;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="searchEntity"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("search")]
        public IEnumerable<TimesheetActivity> Search([FromQuery] TimesheetActivity searchEntity)
        {
            searchEntity = searchEntity ?? new TimesheetActivity();
            var list = Manager.FindByEntity(searchEntity);
            return list;
        }


        /// <summary>
        ///
        /// </summary>
        /// <param name="searchEntity"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetMonthly")]
        public IEnumerable<TimesheetActivity> GetMonthly(int employeeId, DateTime startDate,DateTime endDate)
        {
            var list = Manager.FindByDate(employeeId,startDate,endDate,1);
            return list;
        }
      
        /// <summary>
        ///
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpDelete]
        public bool Delete(int Id)
        {
            return Manager.Delete(Id);
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost]
        public TimesheetActivity Save([FromBody] TimesheetActivity entity)
        {
            entity = entity ?? new TimesheetActivity();
            if (entity.Id > 0)
            {
                Manager.Update(entity);
            }
            else
            {
                entity.Id = Manager.Create(entity);
            }
            return entity;
        }

        [HttpGet]
        [Route("GetByCriteria")]
        public TimesheetActivity GetByCriteria([FromQuery]TimesheetActivity e)
        {
            return Manager.GetByCriteria(e);
        }
    }
}
