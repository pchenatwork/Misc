﻿using EVO.TimesheetPortal.BusinessLogic;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace TimeSheetTracker.Api.Controllers
{
    /// <summary>
    ///
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectController : ApiControllerBase<IDbSession>
    {
        private readonly ProjectManager Manager = null;

        /// <summary>
        ///
        /// </summary>
        /// <param name="dbSession"></param>
        public ProjectController(IDbSession dbSession) : base(dbSession)
        {
            Manager = (ProjectManager)ManagerFactory<Project>.Instance.GetManager(dbSession);
        }

        /// <summary>
        ///
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("get")]
        public Project Get(int Id)
        {
            var entity = Manager.Get(Id);
            return entity;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="searchEntity"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("search")]
        public IEnumerable<Project> Search([FromBody] Project searchEntity)
        {
            searchEntity = searchEntity ?? new Project();
            var list = Manager.FindByEntity(searchEntity);
            return list;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("delete")]
        public bool Delete(int Id)
        {
            return Manager.Delete(Id);
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("save")]
        public Project Save([FromBody] Project entity)
        {
            entity = entity ?? new Project();
            if (entity.Id > 0)
            {
                Manager.Update(entity);
            }
            else
            {
                entity.Id = Manager.Create(entity);
            }
            return entity;
        }


        /// <summary>
        ///
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("updatestatus")]
        public bool UpdateStatus([FromBody] WorkflowHistory entity)
        {
            entity = entity ?? new WorkflowHistory();
            return Manager.UpdateWorkflowStatus(entity.EntityId, entity.StatusId, entity.UpdateBy, entity.Comment);
        }
    }
}