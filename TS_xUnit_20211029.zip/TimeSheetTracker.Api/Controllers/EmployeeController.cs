﻿using EVO.TimesheetPortal.BusinessLogic;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TimeSheetTracker.Api.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ApiControllerBase<IDbSession>
    {

        private readonly EmployeeManager Manager = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dbSession"></param>
        public EmployeeController(IDbSession dbSession) : base(dbSession)
        {
            Manager = (EmployeeManager)ManagerFactory<Employee>.Instance.GetManager(dbSession);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet]
        
        public Employee Get(int Id)
        {
            var entity = Manager.Get(Id);
            return entity;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="searchEntity"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("search")]
        public IEnumerable<Employee> Search([FromBody] Employee searchEntity)
        {
            searchEntity = searchEntity ?? new Employee();
            var list = Manager.FindByEntity(searchEntity);
            return list;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("getall")]
        public IEnumerable<Employee> GetAll()
        {
            var list = Manager.GetAll();
            return list;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpDelete]
        public bool Delete(int Id,string updateBy)
        {
            return Manager.Delete(Id,updateBy);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPut]
        public bool Update([FromBody] Employee entity)
        {

            var result = Manager.Update(entity);
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost]
        public int Insert([FromBody] Employee entity)
        {

            var result = Manager.Create(entity);
            return result;
        }
    }
}
