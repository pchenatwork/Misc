﻿using DocumentFormat.OpenXml.ExtendedProperties;
using EVO.TimesheetPortal.BusinessLogic;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TimeSheetTracker.Api.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class AccountingController : ApiControllerBase<IDbSession>
    {
        private readonly TimesheetAccountingManager Manager = null;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dbSession"></param>
        public AccountingController(IDbSession dbSession) : base(dbSession)
        {
            Manager = (TimesheetAccountingManager)ManagerFactory<TimeSheetAccounting>.Instance.GetManager(dbSession);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="periodCode"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("search")]
        public IEnumerable<TimeSheetAccounting> Search([FromQuery] string periodCode)
        {
            var list = Manager.FindByPeriodCode(periodCode);
            return list;
        }
    }
}
