﻿using EVO.TimesheetPortal.BusinessLogic;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace TimeSheetTracker.Api.Controllers
{
    /// <summary>
    ///
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class EmailTemplateController : ApiControllerBase<IDbSession>
    {
        private readonly EmailTemplateManager manager = null;

        /// <summary>
        ///
        /// </summary>
        /// <param name="dbSession"></param>
        public EmailTemplateController(IDbSession dbSession) : base(dbSession)
        {
            manager = (EmailTemplateManager)ManagerFactory<EmailTemplate>.Instance.GetManager(dbSession);
        }

        /// <summary>
        ///
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("search")]
        public IEnumerable<EmailTemplate> Search()
        {
            var queryEntity = new EmailTemplate();
            var list = manager.FindByEntity(queryEntity);
            return list;
        }
    }
}