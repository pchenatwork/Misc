﻿using EVO.TimesheetPortal.BusinessLogic;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace TimeSheetTracker.Api.Controllers
{
    /// <summary>
    ///
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class SettingController : ApiControllerBase<IDbSession>
    {
        private readonly SettingManager manager = null;

        /// <summary>
        ///
        /// </summary>
        /// <param name="dbSession"></param>
        public SettingController(IDbSession dbSession) : base(dbSession)
        {
            manager = (SettingManager)ManagerFactory<Setting>.Instance.GetManager(dbSession);
        }

        /// <summary>
        ///
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("get")]
        public Setting GetSetting(int Id)
        {
            var entity = manager.Get(Id);
            return entity;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="setting"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("search")]
        public IEnumerable<Setting> Search([FromQuery] Setting setting)
        {
            setting = setting ?? new Setting();
            var list = manager.FindByEntity(setting);
            return list;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("delete")]
        public bool Delete(int Id)
        {
            return manager.Delete(Id);
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="setting"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("save")]
        public Setting Save([FromBody] Setting setting)
        {
            setting = setting ?? new Setting();
            if (setting.Id > 0)
            {
                manager.Update(setting);
            }
            else
            {
                setting.Id = manager.Create(setting);
            }
            return setting;
        }
    }
}