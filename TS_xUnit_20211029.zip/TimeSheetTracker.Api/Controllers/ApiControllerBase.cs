﻿using FrameworkBase.DataAccess;
using Microsoft.AspNetCore.Mvc;

namespace TimeSheetTracker.Api.Controllers
{
    /// <summary>
    ///
    /// </summary>
    /// <typeparam name="T"></typeparam>
    [Produces("application/json")]
    [ApiController]
    public abstract class ApiControllerBase<T> : ControllerBase where T : IDbSession
    {
        /// <summary>
        ///
        /// </summary>
        protected readonly T _dbSession;

        /// <summary>
        ///
        /// </summary>
        public ApiControllerBase()
        {
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="dbSession"></param>
        public ApiControllerBase(T dbSession)
        {
            _dbSession = dbSession;
        }
    }
}