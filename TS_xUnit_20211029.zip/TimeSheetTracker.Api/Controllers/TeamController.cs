﻿using FrameworkBase.DataAccess;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EVO.TimesheetPortal.Entity;
using EVO.TimesheetPortal.BusinessLogic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TimeSheetTracker.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamController : ApiControllerBase<IDbSession>
    {
        private readonly TeamManager _manager = null;

        public TeamController(IDbSession dbSession) : base(dbSession)
        {
            _manager = (TeamManager)ManagerFactory<Team>.Instance.GetManager(dbSession);
        }
       
        [HttpGet]
        public IEnumerable<Team> Search([FromQuery] TeamCriteria teamCriteria)
        {
          
            var result = _manager.FindByEntity(teamCriteria);
            return result;    
        }

        [HttpGet]
        [Route("get")]
        public Team GetById(int id)
        {
            var result = _manager.Get(id);
            return result;
        }


        [HttpPut]
        public bool Update([FromBody] Team team)
        {
           
            var result = _manager.Update(team);
            return result;
        }


        [HttpPost]
        public int Insert([FromBody] Team team)
        {
           
            var result = _manager.Create(team);
            return result;
        }

        [HttpDelete]
        public bool Delete(int id)
        {

            var result = _manager.Delete(id);
            return result;
        }


    }
}
