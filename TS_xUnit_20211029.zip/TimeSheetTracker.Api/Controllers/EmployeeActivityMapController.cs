﻿using DocumentFormat.OpenXml.ExtendedProperties;
using DocumentFormat.OpenXml.Office2010.Excel;
using EVO.TimesheetPortal.BusinessLogic;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TimeSheetTracker.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeActivityMapController : ApiControllerBase<IDbSession>
    {
        private readonly EmployeeActivityMapManager Manager = null;
        public EmployeeActivityMapController(IDbSession dbSession) : base(dbSession)
        {
            Manager = (EmployeeActivityMapManager)ManagerFactory<EmployeeActivityMap>.Instance.GetManager(dbSession);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("get")]
        public EmployeeActivityMap Get(int Id)
        {
            var entity = Manager.Get(Id);
            return entity;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="searchEntity"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("search")]
        public IEnumerable<EmployeeActivityMap> Search([FromQuery] EmployeeActivityMap searchEntity)
        {
            searchEntity = searchEntity ?? new EmployeeActivityMap();
            var list = Manager.FindByEntity(searchEntity);
            return list;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("getall")]
        public IEnumerable<EmployeeActivityMap> GetAll()
        {
            var list = Manager.GetAll();
            return list;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpDelete]
        public bool Delete(int Id)
        {
            return Manager.Delete(Id);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPut]
        public bool Update([FromBody] EmployeeActivityMap entity)
        {

            var result = Manager.Update(entity);
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost]
        public int Insert([FromBody] EmployeeActivityMap entity)
        {

            var result = Manager.Create(entity);
            return result;
        }
    }
}
