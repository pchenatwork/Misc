using EVO.Common.UtilityCore.Configuration;
using FrameworkBase.DataAccess;
using HappyCode.NetCoreBoilerplate.Api.Infrastructure.Registrations;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Microsoft.FeatureManagement;
using Microsoft.FeatureManagement.FeatureFilters;
using Swashbuckle.AspNetCore.SwaggerUI;
using TimeSheetTracker.Api.Infrastructure.Filters;
using TimeSheetTracker.Api.Infrastructure.Settings;

namespace TimeSheetTracker.Api
{
    /// <summary>
    /// /
    /// </summary>
    public class Startup
    {
        private readonly IConfiguration _configuration;

        /// <summary>
        ///
        /// </summary>
        /// <param name="configuration"></param>
        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="services"></param>
        public virtual void ConfigureServices(IServiceCollection services)
        {
            services
                .AddHttpContextAccessor()
                .AddRouting(options => options.LowercaseUrls = true)
                .AddMvcCore(options =>
                {
                    options.Filters.Add<HttpGlobalExceptionFilter>();
                    options.Filters.Add<ValidateModelStateFilter>();
                    options.Filters.Add<ApiKeyAuthorizationFilter>();
                })
                .AddApiExplorer()
                .AddDataAnnotations()
                .SetCompatibilityVersion(CompatibilityVersion.Latest);

            services.Configure<ApiKeySettings>(_configuration.GetSection("ApiKey"));
            services.AddSwagger(_configuration);

            services.TryAddTransient<IDbSession>(provider =>
            {
                var constr = _configuration.GetValue<string>("ConnectionStrings:TimeSheetTracker");
                var dbProvider = _configuration.GetValue<string>("ConnectionStrings:Provider");

                var dbSession = DbSessionFactory.Instance.GetSqlSession(constr);
                return dbSession;
            });

            services.AddFeatureManagement()
                .AddFeatureFilter<TimeWindowFilter>();
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        public virtual void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            ConfigurationManager.Configuration = _configuration;
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "TimeSheetTracker.Api V1");
                c.DocExpansion(DocExpansion.None);
            });
        }
    }
}