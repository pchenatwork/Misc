﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TimeSheetTracker.Api.Infrastructure.Settings
{
    /// <summary>
    /// 
    /// </summary>
    public class ApiKeySettings
    {
        /// <summary>
        /// 
        /// </summary>
        public string SecretKey { get; set; }
    }
}
