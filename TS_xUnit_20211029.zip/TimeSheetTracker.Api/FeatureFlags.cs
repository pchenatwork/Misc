﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TimeSheetTracker.Api
{
    public static class FeatureFlags
    {
        public const string ApiKey = nameof(ApiKey);
        public const string Santa = nameof(Santa);
    }
}
