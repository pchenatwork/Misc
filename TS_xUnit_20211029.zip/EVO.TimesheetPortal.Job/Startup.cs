﻿using EmailService;
using EVO.TimesheetPortal.Job.Jobs;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using MoreLinq;
using Refit;
using Serilog;
using SilkierQuartz;
using System;
using System.Linq;
using System.Reflection;
using System.ServiceModel;

namespace EVO.TimesheetPortal.Job
{
    public class Startup
    {
        public IWebHostEnvironment Env { get; set; }
        public IConfiguration Configuration { get; }

        public Startup(IWebHostEnvironment env, IConfiguration configuration)
        {
            Env = env;
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddRazorPages();
            services.AddSilkierQuartz((cfg) =>
                {
                    cfg["quartz.plugin.recentHistory.type"] = "Quartz.Plugins.RecentHistory.ExecutionHistoryPlugin, Quartz.Plugins.RecentHistory";
                    cfg["quartz.plugin.recentHistory.storeType"] = "Quartz.Plugins.RecentHistory.Impl.InProcExecutionHistoryStore, Quartz.Plugins.RecentHistory";
                }
            );
            services.AddOptions();

            services.TryAddTransient<EmailServiceSoapClient>(provider =>
            {
                var emailAddress = Configuration.GetValue<string>("WCF:EmailAddress");
                var isHttps = emailAddress.ToLower().IndexOf("https") > -1;

                BasicHttpBinding binding = new BasicHttpBinding(BasicHttpSecurityMode.Transport);
                binding.MaxReceivedMessageSize = 2147483647;
                binding.MaxBufferPoolSize = 2147483647;

                var client = isHttps ? new EmailServiceSoapClient(binding, new EndpointAddress(emailAddress)) : new EmailServiceSoapClient(EmailServiceSoapClient.EndpointConfiguration.EmailServiceSoap);
                client.Endpoint.Address = new System.ServiceModel.EndpointAddress(emailAddress);

                return client;
            });

            var refitSettings = new RefitSettings(new SystemTextJsonContentSerializer());
            var rpcLibs = Assembly.GetExecutingAssembly().GetTypes().Where(type => type.Name.EndsWith("Service")
               && type.Name.StartsWith("I"));
            var userAddress = Configuration.GetValue<string>("WCF:ServiceUrl");
            rpcLibs.ForEach(type =>
            {
                var clientBuilder = services.AddRefitClient(type, refitSettings).SetHandlerLifetime(TimeSpan.FromMinutes(2));
                clientBuilder = clientBuilder.ConfigureHttpClient(client => client.BaseAddress = new Uri(userAddress));
            });

            services.AddQuartzJob<ProjectManagerRemindJob>("ProjectManagerRemindJob");
            services.AddQuartzJob<TimesheetResourceRemindJob>("TimesheetResourceRemindJob");
            services.AddQuartzJob<TimesheetManagerRemindJob>("TimesheetManagerRemindJob");
            services.AddSingleton(Log.Logger);
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseStaticFiles();
            app.UseRouting();
            app.UseSilkierQuartz(new SilkierQuartzOptions()
            {
                VirtualPathRoot = "/Quartz",
                UseLocalTime = true,
                DefaultDateFormat = "yyyy-MM-dd",
                DefaultTimeFormat = "HH:mm:ss"
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();
            });

            if (env.IsDevelopment())
            {
                app.SchedulerDevJobs();
            }
            else
            {
                app.SchedulerJobs();
            }
        }
    }
}