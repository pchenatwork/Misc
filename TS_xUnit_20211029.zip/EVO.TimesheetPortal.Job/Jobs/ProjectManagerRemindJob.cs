﻿using EmailService;
using EVO.TimesheetPortal.Job.Config;
using EVO.TimesheetPortal.Job.Service;
using EVOUserManagement;
using Microsoft.Extensions.Options;
using Quartz;
using Serilog;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Job.Jobs
{
    [DisallowConcurrentExecution, PersistJobDataAfterExecution]
    /// <summary>
    ///  4.3.2 The Timesheet Portal will send a reminder email to managers (level 2) to update the project list on the 14th day of each month. The updated project list will be due by EOD (11:59:59 pm EST) on the 20th day of each month
    /// </summary>
    public class ProjectManagerRemindJob : EmailJobBase
    {
        protected EVOUserManagementClient _evoUserManagerClient;
        protected override string EmailTemplateName { get; set; } = "ProjectSubmission";

        public ProjectManagerRemindJob(EVOUserManagementClient evoUserManagerClient,
            IEmailTemplateService emailTemplateService,
            EmailServiceSoapClient emailService,
            IOptionsSnapshot<ServiceOption> serviceOption,
            ILogger logger)
            : base(emailTemplateService, emailService, serviceOption, logger.ForContext<TimesheetResourceRemindJob>())
        {
            _evoUserManagerClient = evoUserManagerClient;
        }

        protected override async Task<JobResult> Run(IJobExecutionContext context)
        {
            var applicationList = await _evoUserManagerClient.GetApplicationsAsync();
            if (applicationList == null || applicationList.GetApplicationsResult.Length < 1)
            {
                return JobResult.Success;
            }
            var applicationData = applicationList.GetApplicationsResult.First(a => a.ApplicationName == _serviceOption.ApplicationName);
            if (applicationData == null)
            {
                return JobResult.Success;
            }
            var permissionUser = await _evoUserManagerClient.GetUserByPermissionAsync(applicationData.ApplicationID, "Project_submit");
            if (permissionUser == null || permissionUser.GetUserByPermissionResult.Length < 1)
            {
                return JobResult.Success;
            }
            var userList = permissionUser.GetUserByPermissionResult.Where(u => u.Roles.RoleName != "ITExecutive");

            var mangagerEamils = userList.Select(o => o.Email).Distinct();

            if (mangagerEamils != null && mangagerEamils.Count() > 0)
            {
                var emailTemplate = EmailTemplate.Result;
                var subject = EmailTemplate != null ? emailTemplate.EmailSubject : "Project Sumbit reminder";
                var body = EmailTemplate != null ? emailTemplate.EmailContent : "The updated project list will be due, please updated!";
                var mailEntity = new EmailEntity()
                {
                    From = _serviceOption.MailFrom,
                    To = string.Join(";", mangagerEamils),
                    Subject = subject,
                    Body = body
                };
                var result = await SendEmailAsync(mailEntity);
            }
            return JobResult.Success;
        }
    }
}