﻿using EmailService;
using EVO.TimesheetPortal.Job.Config;
using EVO.TimesheetPortal.Job.Service;
using Microsoft.Extensions.Options;
using Quartz;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Job.Jobs
{
    [DisallowConcurrentExecution, PersistJobDataAfterExecution]
    public class TimesheetResourceRemindJob : EmailJobBase
    {
        protected override string EmailTemplateName { get; set; } = "TimesheetSubmission";
        private IEmployeeService EmployeeService;
        private readonly List<string> RoleNameList = new List<string>() { "employee", "manager", "teamowner" };

        public TimesheetResourceRemindJob(
            IEmployeeService employeeService,
            IEmailTemplateService emailTemplateService,
            EmailServiceSoapClient emailService,
            IOptionsSnapshot<ServiceOption> serviceOption,
            ILogger logger)
            : base(emailTemplateService, emailService, serviceOption, logger.ForContext<TimesheetResourceRemindJob>())
        {
            EmployeeService = employeeService;
        }

        protected override async Task<JobResult> Run(IJobExecutionContext context)
        {
            var apiResponse = await EmployeeService.GetAllAsync();
            var employees = apiResponse.Content;
            var subject = " Sumbit Timesheet Reminder";
            var mailList = new List<EmailEntity>();
            var emailTemplate = EmailTemplate.Result;
            var x = employees.Where(o => o.IsActive && o.Email != null && o.EmailAlert && RoleNameList.Any(c => o.RoleNames.Any(a => a.ToLower() == c)))
                .GroupBy(m => m.Email).Select(grp => grp.First());
            foreach (var employee in x)
            {
                mailList.Add(new EmailEntity()
                {
                    From = _serviceOption.MailFrom,
                    To = employee.Email,
                    Subject = emailTemplate != null ? emailTemplate.EmailSubject : subject,
                    Body = emailTemplate != null ? emailTemplate.EmailContent : "Please be reminded that you need to submit your timesheet by EOD(11:59:59 pm EST) on the 25th of each month."
                }); ;
            }
            return SendEmailListAsync(mailList);
        }
    }
}