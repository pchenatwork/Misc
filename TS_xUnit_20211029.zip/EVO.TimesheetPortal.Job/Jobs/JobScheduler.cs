﻿using Microsoft.AspNetCore.Builder;
using Quartz;
using SilkierQuartz;
using System;
using System.Collections.Generic;
using System.IO;

namespace EVO.TimesheetPortal.Job.Jobs
{
    public static class JobScheduler
    {
        public static void SchedulerDevJobs(this IApplicationBuilder app)
        {
            IScheduler scheduler = app.GetScheduler();
            {
                var jobData = new JobDataMap();
                jobData.Put("DateFrom", DateTime.Now);
                jobData.Put("QuartzAssembly", File.ReadAllBytes(typeof(IScheduler).Assembly.Location));

#pragma warning disable CS0618 // Type or member is obsolete
                app.UseQuartzJob<ProjectManagerRemindJob>(() =>
                {
                    var result = new List<TriggerBuilder>();
                    result.Add(TriggerBuilder.Create()
                        // .StartAt(new DateTimeOffset(new DateTime(DateTime.Now.Year, DateTime.Now.Month, 3, 9, 36, 50)))
                        .ForJob("ProjectManagerRemindJob")
                        .WithCronSchedule("0 30 8 14 1/1 ? *").StartNow());
                    //.WithSimpleSchedule(x => x.WithIntervalInSeconds(10).RepeatForever()));
                    return result;
                });

                app.UseQuartzJob<TimesheetResourceRemindJob>(() =>
                {
                    var result = new List<TriggerBuilder>();
                    result.Add(TriggerBuilder.Create()
                        // .StartAt(new DateTimeOffset(new DateTime(DateTime.Now.Year, DateTime.Now.Month, 3, 9, 36, 50)))
                        .ForJob("TimesheetResourceRemindJob")
                    .WithCronSchedule("0 0/10 * 14 * ?").StartNow());
                    //.WithSimpleSchedule(x => x.WithIntervalInSeconds(30).RepeatForever()));
                    return result;
                }
               );

                app.UseQuartzJob<TimesheetManagerRemindJob>(() =>
                {
                    var result = new List<TriggerBuilder>();
                    result.Add(TriggerBuilder.Create()
                        // .StartAt(new DateTimeOffset(new DateTime(DateTime.Now.Year, DateTime.Now.Month, 3, 9, 36, 50)))
                        .ForJob("TimesheetManagerRemindJob")
                    .WithCronSchedule("0 0/10 * 14 * ?").StartNow());
                    //.WithSimpleSchedule(x => x.WithIntervalInSeconds(30).RepeatForever()));
                    return result;
                });

#pragma warning restore CS0618 // Type or member is obsolete
            }
        }

        /// <summary>
        /// for staging , production environment
        /// </summary>
        /// <param name="app"></param>
        public static void SchedulerJobs(this IApplicationBuilder app)
        {
            IScheduler scheduler = app.GetScheduler();
            {
                var jobData = new JobDataMap();
                jobData.Put("DateFrom", DateTime.Now);
                jobData.Put("QuartzAssembly", File.ReadAllBytes(typeof(IScheduler).Assembly.Location));

#pragma warning disable CS0618 // Type or member is obsolete
                app.UseQuartzJob<ProjectManagerRemindJob>(() =>
                {
                    var result = new List<TriggerBuilder>();
                    result.Add(TriggerBuilder.Create()
                        // .StartAt(new DateTimeOffset(new DateTime(DateTime.Now.Year, DateTime.Now.Month, 3, 9, 36, 50)))
                        .ForJob("ProjectManagerRemindJob")
                      .WithCronSchedule("0 30 8 14 1/1 ? *").StartNow());
                    //.WithSimpleSchedule(x => x.w(60).RepeatForever()));
                    return result;
                });

                app.UseQuartzJob<TimesheetResourceRemindJob>(() =>
                {
                    var result = new List<TriggerBuilder>();
                    result.Add(TriggerBuilder.Create()
                        // .StartAt(new DateTimeOffset(new DateTime(DateTime.Now.Year, DateTime.Now.Month, 3, 9, 36, 50)))
                        .ForJob("TimesheetResourceRemindJob")
                    .WithCronSchedule("0 0 9 25W * ? * ").StartNow());       // At 09:00 AM, on the weekday nearest day 25 of the month
                    return result;
                }
               );

                app.UseQuartzJob<TimesheetManagerRemindJob>(() =>
                {
                    var result = new List<TriggerBuilder>();
                    result.Add(TriggerBuilder.Create()
                        // .StartAt(new DateTimeOffset(new DateTime(DateTime.Now.Year, DateTime.Now.Month, 3, 9, 36, 50)))
                        .ForJob("TimesheetManagerRemindJob")
                    .WithCronSchedule("0 10 9 26 1/1 ? *").StartNow());

                    return result;
                });

#pragma warning restore CS0618 // Type or member is obsolete
            }
        }
    }
}