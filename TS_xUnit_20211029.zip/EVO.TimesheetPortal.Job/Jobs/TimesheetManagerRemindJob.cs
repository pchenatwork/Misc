﻿using EmailService;
using EVO.TimesheetPortal.Job.Config;
using EVO.TimesheetPortal.Job.Service;
using Microsoft.Extensions.Options;
using Quartz;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Job.Jobs
{
    [DisallowConcurrentExecution, PersistJobDataAfterExecution]
    public class TimesheetManagerRemindJob : EmailJobBase
    {
        protected override string EmailTemplateName { get; set; } = "TimesheetReview";
        private static string _subject = " Sumbit Timesheet Reminder for manager";
        private IEmployeeService EmployeeService;
        public TimesheetManagerRemindJob(IEmployeeService employeeService,
            IEmailTemplateService emailTemplateService,
            EmailServiceSoapClient emailService,
            IOptionsSnapshot<ServiceOption> serviceOption,
            ILogger logger)
            : base(emailTemplateService, emailService, serviceOption, logger.ForContext<TimesheetResourceRemindJob>())
        {
            EmployeeService = employeeService;
        }

        protected override async Task<JobResult> Run(IJobExecutionContext context)
        {
            var apiResponse = await EmployeeService.GetAllAsync();
            var employees = apiResponse.Content;
            var emailTemplate = EmailTemplate.Result;
            var list = employees.Where(o => o.IsActive && o.Email != null && o.EmailAlert && o.RoleNames.Any(a => a.ToLower() == "manager"))
                .GroupBy(m => m.Email).Select(grp => grp.First());
            
            var mailList = new List<EmailEntity>();
            foreach (var mail in list.Distinct())
            {
                mailList.Add(new EmailEntity()
                {
                    From = _serviceOption.MailFrom,
                    To = mail.Email,
                    Subject = EmailTemplate != null ? emailTemplate.EmailSubject : _subject,
                    Body = EmailTemplate != null ? emailTemplate.EmailContent : "Plase submit your timesheet by EOD(11:59:59 pm EST) of 26th."
                });
            }
            return SendEmailListAsync(mailList);
        }
    }
}