﻿using EVO.TimesheetPortal.Entity;
using Refit;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Job.Service
{
    public interface ITimesheetPeriodService:IService
    {
        [Post("/api/TimesheetPeriod")]
        Task<ApiResponse<int>> CreateAsync();
    }
}
