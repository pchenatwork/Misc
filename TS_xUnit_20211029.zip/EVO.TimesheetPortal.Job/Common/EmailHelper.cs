﻿using EmailService;
using System;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Job
{
    public class EmailHelper
    {
        public async static Task<SaveResult> SendEmailAsync(EmailEntity emailEntity, EmailServiceSoapClient emailService)
        {
            if (emailService == null)
            {
                throw new ArgumentNullException("EmailService/Configuration cannot null.");
            }
            var result = new SaveResult();
            if (emailEntity.IsValid)
            {
                result.Success = false;
                result.ErrorDescription = "To/Subject/Body are required.";
                return result;
            }

            var email = new Email
            {
                Sender = emailEntity.From,
                Recipients = emailEntity.To,
                Subject = emailEntity.Subject,
                Body = emailEntity.Body + "</ br>"
            };

            if (!string.IsNullOrEmpty(emailEntity.Bcc))
                email.Bcc = emailEntity.Bcc;

            if (!string.IsNullOrEmpty(emailEntity.Cc))
                email.Cc = emailEntity.Cc;

            email.IsHtml = true;

            try
            {
                result = await emailService.SendEmailAsync(emailEntity.Application, 1, email);
            }
            catch (Exception ex)
            {
                result.ErrorDescription = "Email failed -- " + ex.Message;
                result.Success = false;
            }
            return result;
        }
    }

    public class EmailEntity
    {
        public string Application { get; set; } = "Time-sheet Portal";
        public string From { get; set; }
        public string To { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string Bcc { get; set; }
        public string Cc { get; set; }

        public bool IsValid
        {
            get
            {
                return string.IsNullOrEmpty(To) || string.IsNullOrEmpty(Subject) || string.IsNullOrEmpty(Body);
            }
        }
    }
}