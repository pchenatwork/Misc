﻿



CREATE PROCEDURE [dbo].[DeleteLicenseCertificate]
@id int
AS
Begin

Update  License
set  Filename =null,
	CertificateId = null
Where Id = @id
return @@rowcount
End












