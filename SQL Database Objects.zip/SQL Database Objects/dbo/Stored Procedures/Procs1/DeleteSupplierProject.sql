﻿


/*
*********************************************************************************************************************
Procedure:	DeleteSupplierProject
Purpose:	Delete a row from SupplierProject table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/11/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteSupplierProject
	@id int
as

delete SupplierProject
where Id = @id
return @@RowCount

