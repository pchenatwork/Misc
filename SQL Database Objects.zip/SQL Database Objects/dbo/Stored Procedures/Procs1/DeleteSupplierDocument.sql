﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierDocument
Purpose:	Delete a row from SupplierDocument table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/12/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteSupplierDocument
	@id int
as

delete SupplierDocument
where Id = @id
return @@RowCount

