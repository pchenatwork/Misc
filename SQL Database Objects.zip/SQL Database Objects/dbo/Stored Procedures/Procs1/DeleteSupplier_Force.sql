/* ================================================

	SCA Force-delete of Supplier from system
	Original code from Paul, modified into proc by Jeff 01/2019

   ================================================ */

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE DeleteSupplier_Force 
	@TaxID varchar(12), 
	@UserID int,
	@Comments varchar(80), -- longer will require redefining AccessUrl field in UserLog
	@Test char(1) = 'N'    --Calling this with �Y� will do a test run without committing the transaction.
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @t1 TABLE (
		RowID INT IDENTITY,
		COLUMN_NAME VARCHAR(100),
		TABLE_NAME VARCHAR(100),
		TEXT_VALUE VARCHAR(100))

	DECLARE @t2 TABLE (
		RowID INT,
		COLUMN_NAME VARCHAR(100),
		TABLE_NAME VARCHAR(100),
		TEXT_VALUE VARCHAR(100),
		RECORDS INT)
    
	DECLARE @Suppliers TABLE (
		SupplierId INT,
		VendorID INT,
		FederalID varchar(20))
	INSERT INTO @Suppliers
	SELECT A.Id, B.Id, @TaxID
	FROM Supplier A LEFT JOIN Vendor B ON A.FederalId = B.FederalId
	WHERE A.FederalId = @TaxID

	--select * from @Suppliers

	SET NOCOUNT ON
	-- Vendor records
	INSERT INTO @t1 (COLUMN_NAME, TABLE_NAME, TEXT_VALUE)
	SELECT
		c.name  AS 'ColumnName',
		t.name AS 'TableName',
		s.VendorID
	FROM        
		sys.columns c,
		sys.tables  t,
		sys.types y ,
		(SELECT Distinct VendorID FROM @Suppliers WHERE VendorID IS NOT NULL) S
	WHERE  1=1
	and c.object_id = t.object_id
	and c.system_type_id = y.system_type_id
	and c.name = 'Vendorid'
	and y.name like '%int'
	-- Supplier records
	INSERT INTO @t1 (COLUMN_NAME, TABLE_NAME, TEXT_VALUE)
	SELECT
		c.name  AS 'ColumnName',
		t.name AS 'TableName',
		s.SupplierId
	FROM        
		sys.columns c,
		sys.tables  t,
		sys.types y ,
		(SELECT Distinct SupplierId FROM @Suppliers) S
	WHERE  1=1
	and c.object_id = t.object_id
	and c.system_type_id = y.system_type_id
	and c.name LIKE '%Supplierid'
	and y.name like '%int'


	--- IF (@Test='Y') SELECT '@t1' as t, * FROM @t1

	DECLARE @Id INT, @sql NVARCHAR(500), 
		@table VARCHAR(50), 
		@column varchar(50), 
		@text_value varchar(50)
	While EXISTS(SELECT 1 FROM @t1)
	Begin
		SELECT TOP 1 @Id= RowID, @table = TABLE_NAME, @column=COLUMN_NAME, @text_value = TEXT_VALUE from @t1;

		SELECT @SQL = 'SELECT ''' + CONVERT(VARCHAR(10), @Id) + ''', ''' + @column +''', ''' + @table + ''', ''' + @text_value  + ''', COUNT(1) FROM [' + @table + '] WHERE [' + @column + '] = ' + @text_value + ' GROUP BY ' + @column;

		--- IF (@Test='Y') PRINT 'SQL = ' + @sql;

		INSERT INTO @t2 EXEC(@sql);
		DELETE @t1 WHERE RowID = @Id
	END

	IF (@Test='Y') SELECT 'ToBeDeleted' as Tbl, * FROM @t2
	--- delete these tables the last
	DELETE FROM @t2 WHERE TABLE_NAME IN ('Supplier', 'SupplierWorkflow', 'Vendor', 'VendorContact')

	declare @cnt1 INT = 0, @cnt2 int = 0, @ErrCnt int = 0, @ThisErrCode INT = 0

	BEGIN TRAN

	-- Step1: remove Vendor records
	Print ('** Step1: Delete various Vendor/Supplier records')
	While EXISTS(SELECT 1 FROM @t2)
	Begin
		SELECT TOP 1 @Id= RowID, @table = TABLE_NAME, @column=COLUMN_NAME, @cnt1=RECORDS, @text_value=TEXT_VALUE from @t2;
		SELECT @sql = 'DELETE FROM ['+ @table + '] WHERE [' + @column + '] = ' +  @text_value;

		EXECUTE sp_executesql @Sql;
		SELECT @cnt2 = @@ROWCOUNT, @ThisErrCode=@@ERROR;
		PRINT 'SQL = ' + @sql;
		PRINT '@@ROWCOUNT = ' +CONVERT(VARCHAR(10), @cnt2);
		PRINT '@RowToDel  = ' +CONVERT(VARCHAR(10), @cnt1);

		if (@ThisErrCode<>0 OR @cnt2 <> @cnt1) 
		BEGIN
			SET @ErrCnt = @ErrCnt+1;
		END

		DELETE FROM @t2 WHERE RowID = @Id
	END

	PRINT'** Step2: Delete static [VendorContactRole]/[VendorContact]/[Vendor]/[SupplierWorkflow]/[WorkflowHistory]/[Supplier] table'
		delete from VendorContactRole WHERE VendorContactId in (
			SELECT id FROM VendorContact A JOIN @Suppliers B ON A.VendorId=b.VendorID)
		SELECT @cnt2 = @@ROWCOUNT, @ThisErrCode=@@ERROR;
		PRINT 'SQL = delete from VendorContactRole WHERE VendorContactId in ...';
		PRINT '@@ROWCOUNT = ' +CONVERT(VARCHAR(10), @cnt2);
		if (@ThisErrCode<>0) SET @ErrCnt=@ErrCnt+1;
    
		delete from VendorContact WHERE VendorId in (
			SELECT VendorId from @Suppliers B)
		SELECT @cnt2 = @@ROWCOUNT, @ThisErrCode=@@ERROR;
		PRINT 'SQL = delete from VendorContact WHERE VendorId in ...';
		PRINT '@@ROWCOUNT = ' +CONVERT(VARCHAR(10), @cnt2);
		if (@ThisErrCode<>0) SET @ErrCnt=@ErrCnt+1;

		DELETE WorkflowHistory WHERE TransactionHeaderId in
			(select TransactionId FROM SupplierWorkflow A 
			join @Suppliers B on A.SupplierId=B.SupplierId)
		SELECT @cnt2 = @@ROWCOUNT, @ThisErrCode=@@ERROR;
		PRINT 'SQL = DELETE WorkflowHistory WHERE TransactionHeaderId in ...';
		PRINT '@@ROWCOUNT = ' +CONVERT(VARCHAR(10), @cnt2);
		if (@ThisErrCode<>0) SET @ErrCnt=@ErrCnt+1;
    
		DELETE FROM SupplierWorkflow
		   WHERE SupplierId IN (select SupplierId from @Suppliers)
		SELECT @cnt2 = @@ROWCOUNT, @ThisErrCode=@@ERROR;
		PRINT 'SQL = DELETE FROM SupplierWorkflow ...';
		PRINT '@@ROWCOUNT = ' +CONVERT(VARCHAR(10), @cnt2);
		if (@ThisErrCode<>0) SET @ErrCnt=@ErrCnt+1;
    
		DELETE supplier where id in (select supplierid from @Suppliers)
		SELECT @cnt2 = @@ROWCOUNT, @ThisErrCode=@@ERROR;
		PRINT 'SQL = DELETE supplier where id in (...)';
		PRINT '@@ROWCOUNT = ' +CONVERT(VARCHAR(10), @cnt2);
		if (@ThisErrCode<>0) SET @ErrCnt=@ErrCnt+1;

		delete from Vendor WHERE Id in (
			SELECT VendorId from @Suppliers B)
		SELECT @cnt2 = @@ROWCOUNT, @ThisErrCode=@@ERROR;
		PRINT 'SQL = delete from Vendor WHERE VendorId in ...';
		PRINT '@@ROWCOUNT = ' +CONVERT(VARCHAR(10), @cnt2);
		if (@ThisErrCode<>0) SET @ErrCnt=@ErrCnt+1;

		-- Write to UserLog, Added by JW 01/2019
		if (len(@Comments) > 0)
			set @Comments = concat(' ',@Comments)

		insert into UserLog (UserId, AccessTime, AccessUrl, RefType, RefId) values (
			 @UserID
			,CURRENT_TIMESTAMP
			,concat('Deleted ',@TaxID,@Comments)
			,'Supplier'
			,0
		)

	IF (@Test = 'Y')
	BEGIN
		PRINT '-----------------------------------------------------------';
		PRINT 'Test, rollback transaction';
		rollback tran;
	END
	ELSE
	IF (@ErrCnt > 0) 
	BEGIN
		PRINT '-----------------------------------------------------------';
		PRINT '**Error**, rollback transaction';
		rollback tran;
	END
	ELSE
	BEGIN
		PRINT '-----------------------------------------------------------';
		commit tran;
		--** rollback tran;
		PRINT 'Done';
	END

	return @ErrCnt -- VAS checks this to deterimine if successful or not

END
GO
