﻿




CREATE procedure [dbo].[CopySupplierAddress]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin
	insert SupplierAddress
		(
			SupplierId,
			AddressType,
			FromSupplier,
			AddressLine1,
			AddressLine2,
			City,
			State,
			ZipCode,
			Country,
			AddressId,
			County,
			ChangeDate,
			ChangeUser
		)
	select
			@newSupplierId,
			AddressType,
			FromSupplier,
			AddressLine1,
			AddressLine2,
			City,
			State,
			ZipCode,
			Country,
			newid(),
			County,
			getdate(),
			@changeUser
	from SupplierAddress where supplierId=@supplierId

end





