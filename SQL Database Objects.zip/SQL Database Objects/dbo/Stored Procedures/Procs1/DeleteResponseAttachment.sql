﻿CREATE procedure DeleteResponseAttachment
	@id int
as
Update Response
Set AttachmentId = null,
AttachmentName = null
where Id = @id
return @@RowCount