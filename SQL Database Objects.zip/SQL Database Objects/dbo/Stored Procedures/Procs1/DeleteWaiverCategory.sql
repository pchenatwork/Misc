﻿/*
*********************************************************************************************************************
Procedure:	DeletePlanWaiverCategory
Purpose:	Delete a row from PlanWaiverCategory table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/1/2010		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
create procedure [dbo].[DeleteWaiverCategory]
	@id int
as

delete PlanWaiverCategory
where Id = @id
return @@RowCount

