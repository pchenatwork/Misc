﻿CREATE procedure [dbo].[DeleteRfdCommentAttachment] 
	@id int
AS

Update RfdComment
Set FileName = null,
	AttachmentId = null
Where Id = @id
return @@rowcount

