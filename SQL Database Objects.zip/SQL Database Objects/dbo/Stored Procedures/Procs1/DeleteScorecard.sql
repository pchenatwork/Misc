﻿
/*
*********************************************************************************************************************
Procedure:	DeleteScorecard
Purpose:	Delete a row from Scorecard table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/23/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteScorecard]
	@id int
as

declare @refId int

Select @refId = RefId From Scorecard
Where Id = @id

BEGIN Transaction

delete from ScorecardHistory
where ScorecardId = @id

delete from ScorecardDescription
where ScorecardId = @id

delete from ScorecardAttachment
where ScorecardId = @id

delete from ScorecardComment
where ScorecardId = @id

delete from ScorecardScoreHistory
where ScorecardId = @id

delete from ScorecardScore
where ScorecardId = @id

delete from ScorecardQuestionUserType
where QuestionId in (Select Id From ScorecardQuestion Where ScorecardId = @id)

delete from ScorecardQuestion
where ScorecardId = @id

delete from ScorecardCategory
where ScorecardId = @id

delete from ScorecardInvitee
where ScorecardId = @id

delete from ScorecardUser
where ScorecardId = @id

delete from Scorecard
where Id = @id

delete from ScorecardProjectUser
Where ScorecardProjectId = @refId and ScorecardProjectId not in (Select RefId From Scorecard)

delete from ScorecardProject
Where Id = @refId and Id not in (Select RefId From Scorecard)

if @@error = 0
	Commit Transaction
else
	RollBack Transaction

return @@RowCount
