﻿-- =============================================
-- Author:		Pasha	
-- Create date: <Create Date,,>
-- Description:	Procedure is to identify vendors that are eligible for Mentor Program
-- Rules:
		/*Must be certified by the SCA as a MBE or WBE or LBE
		  Must be pre-qualified with the SCA
		  No bonding capacity or Bonding capacity of one million dollars or less
		  Must be experienced in any Mentor trade
		  Gross Sales must be less that 2.1 million dollars averaged over 3 years
		  Owner should not be part of any other mentor firm
		  Should not be present in Mentor Exception
		  Shouls not be already in Mentor/Grad Mentor Program or in the process of enrollment
		*/
-- =============================================
CREATE PROCEDURE [dbo].[EEO_GetMentorEligibleVendors] 
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @c_vendor_id char(12)
    declare @max_seq numeric
    declare @sd_start smalldatetime,
            @sd_end smalldatetime,
            @cur_dt smalldatetime

	-- Create a separate process to move vendors with owners who are earier sole propritors and mentor program to Mentor Exceptions
	select @cur_dt = convert(smalldatetime,convert(char(12), getdate()))
    -- Insert statements for procedure here
	select  distinct v.*  
    from	EEO_MASTER t1, vendor v, supplierstatus c,supplierstatus p,eeo_vendor e
    where	isnull(t1.m_average_sales, 0) <= 2100000   -- Avg Sale 
      and	t1.c_vendor_id = v.FederalId
	  and	v.CertifiedSupplierId=c.supplierid
	  and	c.TypeName='Supplier Certification'
	  and	c.status='Certified'
	  and	v.QualifiedSupplierId=p.supplierid
	  and	p.TypeName='Supplier Prequalification'
	  and	p.status='Qualified'
	  and	v.id=e.VendorId
	  and	e.MentorFlag='0' -- do not included who are already in the process of getting enrolled
	  and	not exists(	select v1.federalid 
						from 
							supplierpersonnel sp , supplierpersonnel sp1, Vendor v1,EEO_MENTOR_GRAD_DETAIL e
						where	
							sp.supplierid=v.QualifiedSupplierId
							and sp.IsOwner='Y'
							and sp.status<>4 --active
							and sp.SSN=sp1.SSN
							and	sp1.IsOwner='Y'
							and sp1.status<>4
							and sp1.supplierid=v1.QualifiedSupplierId
							and v1.FederalId<>v.FederalId
							and v1.id=e.VENDORID
							and sp.SSN not in ('wwwwwwwww','%%%%%%%%%','zzzzzzzzz','')
							)
	  
	  and	exists (select * 
					from 
						suppliercategory sc, EEO_MENTOR_ILGBL_TRADES e
					where 
						sc.supplierid=v.CertifiedSupplierId 
						and sc.CategoryId=e.CategoryId
						and sc.IsApproved='Y'
					)
					
	  and not exists(select 'x' -- Prime bond not exceeding 1000000
					from SupplierSurety
					where supplierid=v.QualifiedSupplierId
					and IsPrimary='Y'
					and SingleCapacity>1000000
			)
      
	  and not exists(select 'x' -- Prime bond not exceeding 1000000
					from SupplierSurety
					where supplierid=v.QualifiedSupplierId
					and IsPrimary='N'
					and SingleCapacity>1000000
					)
	 
	 and not exists (select * from EEO_MENTOR_EXCEPTION
					where vendorid=v.id
					and @cur_dt between sd_start and isnull(sd_end,'1/1/9999')
					)

	and not exists (select * from EEO_MENTOR_GRAD_DETAIL
					where vendorid=v.id)
	
	order by v.Company
	
END
