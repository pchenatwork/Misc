﻿

 CREATE procedure [dbo].[EEO_FindSupplierCategory]
	@supplierId int
as

set nocount on

Select c.Id	,c.Name	,c.Code	
from SupplierCategory sc
Inner join Category c on sc.CategoryId = c.Id
Where sc.IsApproved = 'Y' and sc.SupplierId = @supplierId --36118
