﻿



/*
*********************************************************************************************************************
Procedure:	DeleteSupplierApprenticeshipProgram
Purpose:	Delete a row from SupplierApprenticeshipProgram table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/19/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSupplierApprenticeshipProgram]
	@id int
as


declare @supplierid int
declare @type nvarchar(50)
declare @transferredFlag  char(1)
select @supplierid = supplierid, @type = [Type], @transferredFlag=transferredFlag from SupplierApprenticeshipProgram where Id=@id

delete SupplierApprenticeshipProgram
where Id = @id

declare @rowcount int
set @rowcount = @@RowCount

--if @transferredFlag= '1' and @type = 'AddApprenticeship'
--	Insert AuditLog_Meta
--		(TableName, RecordId, VASId,  MainId, TransactionID, Action, ActionTime, UserName, ProcessedStatus)
--		values('SupplierApprenticeshipProgram', @id,@id, @supplierid, null, 'delete',null,null, null)

return @rowcount







