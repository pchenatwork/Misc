﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierPersonnelMixedInfo
Purpose:	Delete a row from SupplierPersonnelMixedInfo table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/12/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierPersonnelMixedInfo
	@id int
as

delete SupplierPersonnelMixedInfo
where Id = @id
return @@RowCount

