﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectAddendum
Purpose:	Delete a row from ProjectAddendum table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
1/14/2010		AECSOFTUSA\angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteProjectAddendum
	@id int
as

delete ProjectAddendum
where Id = @id
return @@RowCount

