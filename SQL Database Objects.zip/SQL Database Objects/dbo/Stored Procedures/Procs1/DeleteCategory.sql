﻿



/*
*********************************************************************************************************************
Procedure:	DeleteCategory
Purpose:	Delete a row from Category table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
03/09/2007		Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteCategory]
	@id int
as

declare @count int

if exists (select * from SupplierCategory where CategoryId = @id )
	return 0

delete Category
where Id = @id

Set @count = @@rowcount

exec CreateCategories

return @count







