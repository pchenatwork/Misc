﻿










CREATE procedure [dbo].[CopyPlanSubcontractor]	
	@planId int, 
	@newPlanId int,
	@changeUser nvarchar(50)
as
begin

begin transaction
begin try
	exec [CopyPlanSubcontractorTable] @planId, @newPlanId, @changeUser 
	
	--declare @item nvarchar(50)
	--set @item='Verification1, Verification2, Verification3, Verification4, VerificationTotal'
	--insert [PlanStatistics]
	--	(
	--		PlanId, 
	--		Type, 
	--		MBEAmount, 
	--		WBEAmount, 
	--		LBEAmount, 
	--		NonMinorityAmount, 
	--		TotalAmount,  
	--		PertOfPlanAmount, 
	--		ChangeUser, 
	--		ChangeDate
	--	)
	-- select 
	--		@planId,
	--		item,
	--		0,
	--		0,
	--		0,
	--		0,
	--		0,
	--		0,
	--		@changeUser,
	--		GETDATE()
	--from
	--	dbo.split(@item, ',')

	declare @planSubContractorId int	
	declare @newPlanSubContractorId int
	declare @mycursor cursor
	set @mycursor = cursor for (select id from PlanSubcontractor where planId = @newPlanId and type='Verification')
	open @mycursor
	fetch next from @mycursor into @newPlanSubContractorId
	while @@fetch_status = 0
		begin 
			set @planSubContractorId = (select copyId from PlanSubcontractor where ID=@newPlanSubContractorId)
			exec [CopyPlanSubcontractorCategory] @planSubContractorId, @newPlanSubContractorId, @changeUser
			exec [CopyPlanSubcontractorCertification] @planSubContractorId, @newPlanSubContractorId, @changeUser
			exec [CopyPlanSubcontractorDocument] @planSubContractorId, @newPlanSubContractorId, @changeUser
			exec [CopyPlanSubcontractorProperty] @planSubContractorId, @newPlanSubContractorId, @changeUser
												
			fetch next from @mycursor into @newPlanSubContractorId
		end
	
		commit transaction	
		return 1 
		
	end try
	begin catch
		rollback transaction
		return 0
	end catch
end



 


































