﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierAddress
Purpose:	Delete a row from SupplierAddress table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/31/2004		AECSOFT\lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierAddress
	@id int
as
delete SupplierAddress
where Id = @id
return @@RowCount


