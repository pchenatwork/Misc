﻿


CREATE PROCEDURE [dbo].[DeleteCertificate]
	@id int
AS
Begin

Update  Certification
set  Filename = null,
	CertificateId = null
Where Id = @id
return @@rowcount
End











