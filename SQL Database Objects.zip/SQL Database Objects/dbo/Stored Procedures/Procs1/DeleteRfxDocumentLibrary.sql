﻿/*
*********************************************************************************************************************
Procedure:	DeleteRfxDocumentLibrary
Purpose:	Delete a row from RfxDocumentLibrary table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
2/15/2006		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteRfxDocumentLibrary]
	@id int
as
delete RfxDocumentLibrary
where Id = @id
return @@RowCount

