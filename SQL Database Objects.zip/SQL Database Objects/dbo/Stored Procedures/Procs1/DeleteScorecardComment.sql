﻿
/*
*********************************************************************************************************************
Procedure:	DeleteScorecardComment
Purpose:	Delete a row from ScorecardComment table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/2/2006		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
Create procedure [dbo].[DeleteScorecardComment]
	@id int
as
delete ScorecardComment
where Id = @id
return @@RowCount

