﻿/*
*********************************************************************************************************************
Procedure:	DeleteScheduleHistory
Purpose:	Delete a row from ScheduleHistory table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
2/25/2005		AECSOFT\lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteScheduleHistory
	@id int
as
delete ScheduleHistory
where Id = @id
return @@RowCount


