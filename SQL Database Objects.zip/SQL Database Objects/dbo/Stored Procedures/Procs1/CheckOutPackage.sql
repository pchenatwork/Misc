﻿/*
*********************************************************************************************************************
Procedure:	CheckOutPackage
Purpose:	Update CheckOut Info in Package table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
08/16/2007		Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CheckOutPackage]
	@id int,
	@checkOutId int,
	@checkOutType nvarchar(10)
as
Update Package
set
	CheckOutId = @checkOutId,
	CheckOutType = @checkOutType,
	CheckOutDate = getdate()
where Id = @id
return  @@RowCount



