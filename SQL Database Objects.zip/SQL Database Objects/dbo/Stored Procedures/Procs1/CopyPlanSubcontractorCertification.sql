﻿










CREATE procedure [dbo].[CopyPlanSubcontractorCertification]	
	@planSubcontractorId int, 
	@newPlanSubcontractorId int,
	@changeUser nvarchar(50)
as
begin
	insert [PlanSubcontractorCertification]
		( 
			PlanSubcontractorId, 
			Classification, 
			Amount,
			IsCertifiedByNY, 
			CertifiedAgent, 
			CertificationType, 
			CertificationNo, 
			EffectiveDate, 
			ExpirationDate, 
			CertificateId, 
			FaxIn, 
			Filename, 
			CertificationId, 
			ChangeUser, 
			ChangeDate
		)
	select   
			@newPlanSubcontractorId, 
			Classification, 
			Amount,
			IsCertifiedByNY, 
			CertifiedAgent, 
			CertificationType, 
			CertificationNo, 
			EffectiveDate, 
			ExpirationDate, 
			CertificateId, 
			FaxIn, 
			Filename, 
			CertificationId, 
			@changeUser, 
			GETDATE()
	from
		[PlanSubcontractorCertification]
	where
		PlanSubcontractorId=@planSubcontractorId
	
end



 


































