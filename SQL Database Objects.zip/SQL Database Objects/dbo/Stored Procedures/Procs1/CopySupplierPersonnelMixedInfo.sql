﻿








CREATE procedure [dbo].[CopySupplierPersonnelMixedInfo]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin

------------Generate DocumentIds
declare @tempDocument table
(
	Id int,
	documentId nvarchar(4000)
)

declare @tempDocument2 table
(
	Id int,
	documentIds nvarchar(4000)
)


insert into @tempDocument
(	
	id,
	documentId
)
select t.id, convert(nvarchar(4000), sp.id) from 
	(SELECT s.id, substring('|' + s.documentIds + '|', t.N + 1, charindex('|', '|' + s.documentIds + '|', t.N + 1) - t.N - 1) as documentId
		FROM Tally t,  SupplierPersonnelMixedInfo s
		WHERE substring('|' + s.documentIds + '|', t.N, 1) = '|'
		AND t.N < len('|' + s.documentIds + '|')
		and s.supplierid=@supplierId) t, 
	SupplierDocument sp
	where t.documentId = sp.copyid
	and sp.supplierId=@newSupplierId


;WITH CTE ( Id, documentIds, documentId, length ) 
      AS ( SELECT Id, CAST( '' AS NVARCHAR(4000) ), CAST( '' AS NVARCHAR(4000) ), 0
             FROM @tempDocument
            GROUP BY Id
            UNION ALL
           SELECT t.Id, CAST( c.documentIds + 
                  CASE WHEN length = 0 THEN '' ELSE '|' END + t.documentId AS NVARCHAR(4000) ), 
                  CAST( t.documentId AS NVARCHAR(4000)), length + 1
             FROM CTE c
            INNER JOIN @tempDocument t
               ON c.Id = t.Id
            WHERE t.documentId > c.documentId )

insert into @tempDocument2
(	
	Id,
	documentIds
)
SELECT Id, documentIds 
			FROM ( SELECT Id, documentIds, 
						RANK() OVER ( PARTITION BY Id ORDER BY length DESC )
				   FROM CTE ) D ( Id, documentIds, rank )
			WHERE rank = 1 



 
--------Copy rows	
	
	insert SupplierPersonnelMixedInfo
		(
			SupplierId,
			Type,
			ExpertiseField,
			TotalYears,
			YearsInSupplier,
			Amount,
			ContributionType,
			StartDate,
			EndDate,
			IsOwner,
			HeldPosition,
			EmployeeName,
			Relationship,
			FirmId,
			QuestionIds,
			PersonnelId,
			DocumentIds,
			ChangeDate,
			ChangeUser
		)
	select
			@newSupplierId,
			s.Type,
			s.ExpertiseField,
			s.TotalYears,
			s.YearsInSupplier,
			s.Amount,
			s.ContributionType,
			s.StartDate,
			s.EndDate,
			s.IsOwner,
			s.HeldPosition,
			s.EmployeeName,
			s.Relationship,
			srf.id,
			s.QuestionIds,
			sp.id,
			td.DocumentIds,
			getdate(),
			@changeUser
	from SupplierPersonnelMixedInfo s
	left join @tempDocument2 td
	on s.Id = td.Id
	left join Supplierpersonnel sp
	on s.personnelId = sp.copyId
	left join SupplierRelatedFirm srf
	on s.firmId = srf.copyId
	where s.supplierId=@supplierId
	and DateDiff(day, EndDate, DateAdd(year, -5, getdate())) < 0
	and Type in ('AddOwnOtherFirm')


	
		insert SupplierPersonnelMixedInfo
		(
			SupplierId,
			Type,
			ExpertiseField,
			TotalYears,
			YearsInSupplier,
			Amount,
			ContributionType,
			StartDate,
			EndDate,
			IsOwner,
			HeldPosition,
			EmployeeName,
			Relationship,
			FirmId,
			QuestionIds,
			PersonnelId,
			DocumentIds
		)
	select
			@newSupplierId,
			s.Type,
			s.ExpertiseField,
			s.TotalYears,
			s.YearsInSupplier,
			s.Amount,
			s.ContributionType,
			s.StartDate,
			s.EndDate,
			s.IsOwner,
			s.HeldPosition,
			s.EmployeeName,
			s.Relationship,
			srf.id,
			s.QuestionIds,
			sp.id,
			td.DocumentIds
	from SupplierPersonnelMixedInfo s
	left join @tempDocument2 td
	on s.Id = td.Id
	left join Supplierpersonnel sp
	on s.personnelId = sp.copyId
	left join SupplierRelatedFirm srf
	on s.firmId = srf.copyId
	where s.supplierId=@supplierId
	and Type not in ('AddOwnOtherFirm')

	
end













