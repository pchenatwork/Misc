﻿/*
*********************************************************************************************************************
Procedure:	DeletePlanSubcontractorCertification
Purpose:	Delete a row from PlanSubcontractorCertification table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/1/2010		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeletePlanSubcontractorCertification
	@id int
as

delete PlanSubcontractorCertification
where Id = @id
return @@RowCount

