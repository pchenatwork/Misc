﻿






CREATE procedure [dbo].[CopySupplierAccount]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin

-----Generate PersonnelIds
declare @tempPersonnel table
(
	Id int,
	personnelId nvarchar(4000)
)

declare @tempPersonnel2 table
(
	Id int,
	personnelIds nvarchar(4000)
)

insert into @tempPersonnel
(	
	id,
	personnelId
)
select t.id, convert(nvarchar(4000), sp.id) from 
	(SELECT s.id, substring('|' + s.personnelids + '|', t.N + 1, charindex('|', '|' + s.personnelids + '|', t.N + 1) - t.N - 1) as personnelid
		FROM Tally t,  supplieraccount s
		WHERE substring('|' + s.personnelids + '|', t.N, 1) = '|'
		AND t.N < len('|' + s.personnelids + '|')
		and s.supplierid=@supplierId) t, 
	supplierpersonnel sp
	where t.personnelid = sp.copyid
	and sp.supplierid=@newSupplierId


;WITH CTE ( Id, personnelIds, personnelId, length ) 
      AS ( SELECT Id, CAST( '' AS NVARCHAR(4000) ), CAST( '' AS NVARCHAR(4000) ), 0
             FROM @tempPersonnel
            GROUP BY Id
            UNION ALL
           SELECT t.Id, CAST( c.personnelIds + 
                  CASE WHEN length = 0 THEN '' ELSE '|' END + t.personnelId AS NVARCHAR(4000) ), 
                  CAST( t.personnelId AS NVARCHAR(4000)), length + 1
             FROM CTE c
            INNER JOIN @tempPersonnel t
               ON c.Id = t.Id
            WHERE t.personnelId > c.personnelId )

insert into @tempPersonnel2
(	
	Id,
	personnelIds
)
SELECT Id, personnelIds 
			FROM ( SELECT Id, personnelIds, 
						RANK() OVER ( PARTITION BY Id ORDER BY length DESC )
				   FROM CTE ) D ( Id, personnelIds, rank )
			WHERE rank = 1 

------------Generate DocumentIds
declare @tempDocument table
(
	Id int,
	documentId nvarchar(4000)
)

declare @tempDocument2 table
(
	Id int,
	documentIds nvarchar(4000)
)


insert into @tempDocument
(	
	id,
	documentId
)
select t.id, convert(nvarchar(4000), sp.id) from 
	(SELECT s.id, substring('|' + s.documentIds + '|', t.N + 1, charindex('|', '|' + s.documentIds + '|', t.N + 1) - t.N - 1) as documentId
		FROM Tally t,  supplieraccount s
		WHERE substring('|' + s.documentIds + '|', t.N, 1) = '|'
		AND t.N < len('|' + s.documentIds + '|')
		and s.supplierid=@supplierId) t, 
	SupplierDocument sp
	where t.documentId = sp.copyid
	and sp.supplierId=@newSupplierId


;WITH CTE ( Id, documentIds, documentId, length ) 
      AS ( SELECT Id, CAST( '' AS NVARCHAR(4000) ), CAST( '' AS NVARCHAR(4000) ), 0
             FROM @tempDocument
            GROUP BY Id
            UNION ALL
           SELECT t.Id, CAST( c.documentIds + 
                  CASE WHEN length = 0 THEN '' ELSE '|' END + t.documentId AS NVARCHAR(4000) ), 
                  CAST( t.documentId AS NVARCHAR(4000)), length + 1
             FROM CTE c
            INNER JOIN @tempDocument t
               ON c.Id = t.Id
            WHERE t.documentId > c.documentId )

insert into @tempDocument2
(	
	Id,
	documentIds
)
SELECT Id, documentIds 
			FROM ( SELECT Id, documentIds, 
						RANK() OVER ( PARTITION BY Id ORDER BY length DESC )
				   FROM CTE ) D ( Id, documentIds, rank )
			WHERE rank = 1 


--------Copy rows
	insert SupplierAccount
		(
			SupplierId,
			DataGridType,
			Title,
			Type,
			BankName,
			Phone,
			Fax,
			Url,
			AddressLine1,
			AddressLine2,
			City,
			State,
			Country,
			ZipCode,
			QuestionIds,
			PersonnelIds,
			DocumentIds,
			ChangeDate,
			ChangeUser
		)
	select
			@newSupplierId,
			DataGridType,
			Title,
			Type,
			BankName,
			Phone,
			Fax,
			Url,
			AddressLine1,
			AddressLine2,
			City,
			State,
			Country,
			ZipCode,
			QuestionIds,
			tp.personnelIds,
			td.DocumentIds,
			getdate(),
			@changeUser
	from SupplierAccount sa
	left join @tempPersonnel2 tp
	on sa.Id = tp.Id
	left join @tempDocument2 td
	on sa.Id = td.Id
	where supplierId=@supplierId

end










