﻿

Create procedure DeleteWorkflowAction
	@id int
as

delete WorkflowAction
where Id = @id
return @@RowCount




