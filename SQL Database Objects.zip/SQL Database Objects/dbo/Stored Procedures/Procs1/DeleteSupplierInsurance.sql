﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierInsurance
Purpose:	Delete a row from SupplierInsurance table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/12/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteSupplierInsurance
	@id int
as

delete SupplierInsurance
where Id = @id
return @@RowCount

