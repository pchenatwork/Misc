﻿
/*
*********************************************************************************************************************
Procedure:	DeleteSupplierFinancial
Purpose:	Delete a row from SupplierFinancial table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
06/28/2011		Bill Cooper			Created
*********************************************************************************************************************
*/
Create procedure [dbo].[DeleteSupplierFinancial]
	@id int
as

delete SupplierFinancial
where Id = @id
return @@RowCount


