﻿
/*
*********************************************************************************************************************
Procedure:	DeleteSupplierDocument
Purpose:	Delete a row from SupplierDocument table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/12/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
create procedure [dbo].[DeleteSupplierReport]
	@id int
as

delete SupplierReport
where Id = @id
return @@RowCount


