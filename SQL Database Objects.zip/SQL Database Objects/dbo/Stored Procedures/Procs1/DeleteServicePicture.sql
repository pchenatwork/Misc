﻿
CREATE procedure DeleteServicePicture
	@id int
as

Update service
set filename ='',
PictureId=null
where Id = @id

return @@RowCount

