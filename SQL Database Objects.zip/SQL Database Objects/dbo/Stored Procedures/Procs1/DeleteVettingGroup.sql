﻿/*
*********************************************************************************************************************
Procedure:	DeleteVettingGroup
Purpose:	Delete a row from VettingGroup table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/27/2007		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteVettingGroup]
	@id int
as

Begin Transaction

Delete VettingGroupStatus Where VettingGroupId = @id

Delete VettingInGroup Where VettingGroupId = @id

delete VettingGroup
where Id = @id

if @@error = 0
	Commit Transaction
else
	RollBack Transaction

return @@RowCount

