﻿CREATE PROCEDURE [dbo].[EEO_GetClassSchAttendees_tmp](
    @CLASSESSCHEID INT
) 
AS 

BEGIN
Declare @CLASS_TYPE as varchar(20)
Declare @CLASS_ID as varchar(20)
Declare @ModuleId as int 
Declare @SD_CLASS_DATE as datetime
Declare @CLASS_COUNT as int = 0

select  @CLASS_ID =C.C_CLASS_ID ,  @CLASS_TYPE = C.C_CLASS_TYPE, @SD_CLASS_DATE = SD_CLASS_DATE, @ModuleId = C.ModuleId from EEO_CLASSES_SCHE CS , EEO_CLASSES C  
where  C.C_CLASS_ID = CS.C_CLASS_ID AND CS.ID = @CLASSESSCHEID

--Advanced class type
If @CLASS_TYPE=4   
	begin 
		select @CLASS_COUNT=count(C_CLASS_ID)   from EEO_CLASSES where ModuleId =@ModuleId
	end 
Else
	 begin
		select @CLASS_COUNT=count(C_CLASS_ID)   from EEO_CLASSES where C_CLASS_TYPE =@CLASS_TYPE
	 end 

	 

select ID,  VENDORID, FEDERALID, COMPANY, C_RSVPD , C_REASON_EXCUSED , C_ATTENDED,TEST_SCORE,	REVIEWED , 
	 ReviewedBy, ReviewedDate,  UpdatedBy, UpdatedDate, @CLASS_COUNT as  ClassCount,
		dbo.EEO_GetMissedCount( VENDORID ,@CLASS_TYPE,@ModuleId )as MissedCount
 from 
(
			select  isnull(VX.ID,0) as ID,vx.C_CLASS_ID,VX.SD_SCHED, EV.VENDORID, V.FEDERALID, V.COMPANY, VX.C_RSVPD , VX.C_REASON_EXCUSED ,
					VX.C_ATTENDED,VX.TEST_SCORE,VX.REVIEWED , R.FirstName  + ' '+ R.LastName as ReviewedBy, VX.SD_REVIEW as ReviewedDate,
					U.FirstName  + ' '+ U.LastName as UpdatedBy, VX.SD_UPDATE as UpdatedDate 
			
			 from 
			(
				SELECT vc.ID, vc.C_CLASS_ID, vc.SD_SCHED, vc.VENDORID, VC.C_RSVPD , vc.C_REASON_EXCUSED , vc.C_ATTENDED,vc.I_UPDATEDBY , vc.SD_UPDATE,vc.I_REVIEWDBY , vc.SD_REVIEW, vc.TEST_SCORE, vc.REVIEWED
					FROM EEO_VENDOR_CLASSES VC 
				 where vc.C_CLASS_ID = @CLASS_ID  and vc.SD_SCHED= CONVERT(VARCHAR(10),@SD_CLASS_DATE ,110)   
	 
			 ) VX 
				RIGHT JOIN EEO_VENDOR  EV ON EV.VendorId = VX.VendorId
				INNER JOIN VENDOR V  ON V.Id= EV.VENDORID 
				LEFT OUTER JOIN [User] U on VX.I_UPDATEDBY = U.Id
				LEFT OUTER JOIN [User] R on VX.I_REVIEWDBY = R.Id
			 WHERE     (@CLASS_TYPE =  1 AND EV.Status IN ( 'Preliminary_Class_Details_Emailed','Preliminary_Class_RSVPD'))
						OR
						(@CLASS_TYPE = 2 AND EV.Status  = 'Orientation__Class_Details_Emailed')
						OR
						(@CLASS_TYPE = 3 AND EV.Status  = 'Tier1_Program')
						OR
						--((@CLASS_TYPE= 4  OR @CLASS_TYPE = 6) AND EV.Status  IN ( 'Tier2_Program' ,'AdvancedClassesUpdated','AdvancedClassesAbsent'))
						--PS Change
						((@CLASS_TYPE= 4  OR @CLASS_TYPE = 6) AND EV.Status  IN ( 'Tier2_Program' ))
						OR
						(@CLASS_TYPE = 5 AND   EV.MentorFlag=7)
) c

where not exists (SELECT * FROM EEO_VENDOR_CLASSES WHERE  VENDORID=C.VENDORID AND rtrim(C_CLASS_ID)=rtrim(@CLASS_ID) AND C_ATTENDED = 'Y' AND REVIEWED=1 )

union 

select ID,  VENDORID, FEDERALID, COMPANY, C_RSVPD , C_REASON_EXCUSED , C_ATTENDED,TEST_SCORE,	
			REVIEWED , ReviewedBy, ReviewedDate,  UpdatedBy, UpdatedDate, @CLASS_COUNT as  ClassCount,
	 dbo.EEO_GetMissedCount( VENDORID ,@CLASS_TYPE,@ModuleId )as MissedCount
 from 
(
				select  isnull(VX.ID,0) as ID,vx.C_CLASS_ID,VX.SD_SCHED, V.ID as VENDORID, V.FEDERALID, V.COMPANY, VX.C_RSVPD , VX.C_REASON_EXCUSED ,
					VX.C_ATTENDED,VX.TEST_SCORE,VX.REVIEWED , R.FirstName  + ' '+ R.LastName as ReviewedBy, VX.SD_REVIEW as ReviewedDate,
					U.FirstName  + ' '+ U.LastName as UpdatedBy, VX.SD_UPDATE as UpdatedDate
					from  EEO_VENDOR_CLASSES VX INNER JOIN VENDOR V  ON V.Id= VX.VENDORID 
							LEFT OUTER JOIN [User] U on VX.I_UPDATEDBY = U.Id
							LEFT OUTER JOIN [User] R on VX.I_REVIEWDBY = R.Id
			    where rtrim(C_CLASS_ID)=rtrim(@CLASS_ID) and CONVERT(VARCHAR(10),SD_SCHED,110) = CONVERT(VARCHAR(10),@SD_CLASS_DATE,110) 

) d

order by COMPANY


END
