﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectDocument
Purpose:	Delete a row from ProjectDocument table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/30/2009		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteProjectDocument
	@id int
as

delete ProjectDocument
where Id = @id
return @@RowCount

