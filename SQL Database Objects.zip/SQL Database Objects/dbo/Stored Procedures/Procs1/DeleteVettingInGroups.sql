﻿/*
*********************************************************************************************************************
Procedure:	DeleteVettingInGroups
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
11/28/2007	Lily Xiong		Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteVettingInGroups]
	@vettingGroupId int,
	@vettingInGroupsXml ntext
AS
Declare @hdoc int

-- Convert VettingInGroup data from XML to in memory table. 
EXEC sp_xml_preparedocument @hDoc OUTPUT, @vettingInGroupsXml

Delete From VettingInGroup
where VettingGroupId = @vettingGroupId
and VettingId in (Select VettingId 
	FROM OPENXML(@hDoc, '/ArrayOfVettingInGroup/VettingInGroup', 1)
	with
	(
		VettingId int
	)
)
--Release the internal representation of the XML document.
EXEC sp_xml_removedocument @hDoc
RETURN 1



