﻿


/*
*********************************************************************************************************************
Procedure:	DeleteSubcontractorProperty
Purpose:	Delete a row from SubcontractorProperty table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/10/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSubcontractorProperty]
	@id int
as

delete SubcontractorProperty
where Id = @id

return @@rowcount



