﻿






CREATE procedure [dbo].[CopySupplierDocument]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin
	insert SupplierDocument
		(
			SupplierId,
			Type,
			Filename,
			AttachmentId,
			Status,
			DocumentId,
			TransactionId,
			DocumentNo,
			ExpirationDate,
			Description,
			CopyId,
			ChangeDate,
			ChangeUser
		)
	select
			@newSupplierId,
			Type,
			Filename,
			AttachmentId,
			Status,
			newid(),
			TransactionId,
			DocumentNo,
			ExpirationDate,
			Description,
			Id,
			getdate(),
			@changeUser
	from SupplierDocument 
	where supplierId=@supplierId
	and isnull(type, '') not like '%Checklist%'
	and isnull(type, '') not like '%FinancialStatement%'

end





