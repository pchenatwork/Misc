﻿


CREATE PROCEDURE [dbo].[DeleteSupplierInsuranceAttachment]
	@id int
AS
Begin

	Update SupplierInsurance 
	Set AttachmentId=null,
	    Filename = null
	where Id = @id
return @@rowcount
End










