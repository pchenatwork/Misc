﻿





/*
*********************************************************************************************************************
Procedure:	DeleteSubcontractor
Purpose:	Delete a row from Subcontractor table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/3/2008		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSubcontractor]
	@id int,
	@userName nvarchar(50)=null
as
BEGIN Transaction

begin try
	--auditlog--
	declare @actionTime datetime
	set @actionTime = getdate()
	declare @transactionId int
	insert into [Transaction](Type, ActionTime) values ('CMS', @actionTime)
	select @transactionId = max(id) from [Transaction]	

	declare @transferredflag char(1)
	select @transferredflag=transferredflag from subcontractor where id=@id

	declare @recordId int

	declare @temp table
	(
		tablename nvarchar(50),
		id int,
		vasid int,
		subcontractorId int,
		[action] nvarchar(50)
	)

	insert into @temp
	(
		tablename,
		id,
		vasid,
		subcontractorId,
		[action]
	)
	select 'Subcontractor', id, id, @id, 'delete' 
	from Subcontractor 
	where Id=@id 
		and transferredFlag='1'


	Insert 
		AuditLog
		(TableName, RecordId, VASId,  MainId, transactionid, action, actiontime, username, processedstatus)	
	select  
		tablename, id, vasid, SubcontractorId, @transactionId, [action], @actionTime, @userName, 'U' 
	from @temp
	----Auditlog



	delete from SubcontractorApprenticeshipProgram
	where subcontractorId=@id

	delete from subcontractorcategory
	where subcontractorId=@id

	delete from SubcontractorComment
	where SubcontractorId = @id

	delete from SubcontractorContact
	where SubcontractorId = @id

	delete from subcontractordocument
	where subcontractorid=@id

	delete from SubcontractorInsurance
	where SubcontractorId = @id

	delete from SubcontractorLicense
	where SubcontractorId = @id

	delete from SubcontractorProperty
	where SubcontractorId = @id

	delete from subcontractorvendex
	where subcontractorid = @id

	delete from SubcontractorWorkerComp
	where SubcontractorId = @id

	delete from SubcontractorWorkerCompDetail
	where SubcontractorId = @id

	delete from subcontractorItem
	where subcontractorid = @id
	
	delete Subcontractor
	where Id = @id

		Commit Transaction
		return @@RowCount
	end try
	
	begin catch
		RollBack Transaction
		return 0
	end catch 






