﻿
CREATE procedure DeleteService
	@id int
as

delete Service
where Id = @id
return @@RowCount

