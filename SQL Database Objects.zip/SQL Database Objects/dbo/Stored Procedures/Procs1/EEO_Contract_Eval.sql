﻿CREATE proc dbo.EEO_Contract_Eval @vendor_id varchar(20)

AS
BEGIN     

  CREATE TABLE #Cont_Eval
     ( c_contract varchar(10) NULL,
     OverAll_Perform VarChar(10) NULL,
     Eval_type varchar(10) NULL,
     Eval_stage varchar(10) NULL,
     quality_work varchar(10) NULL,
     scheduling varchar(10) NULL,
     management varchar(10) NULL,
     eeo varchar(10) NULL,
     budget varchar(10) NULL,
     safety varchar(10) NULL,
     Prime_or_Sub varchar(5) NULL,
     c_vendor_id varchar(11) NOT NULL,
     n_SubCont_seq varchar(20) NULL,
     c_performance varchar(1) NULL,
     c_type varchar(1) NULL,
     si_Eval_stage Varchar(20) NULL,
     c_quality_work varchar(1) NULL,
    c_scheduling varchar(1) NULL,
     c_management varchar(1) NULL,
     c_eeo varchar(1) NULL,
     c_budget varchar(1) NULL,
     c_safety varchar(1) NULL )

     --CREATE CLUSTERED INDEX ContEval ON #Cont_Eval(c_contract,c_vendor_id)

  INSERT INTO #Cont_Eval
      SELECT Contract.C_CONTRACT,   
          '',
          '',
          '',
          '',
          '',
          '',
          '',
          '',
          '',
          '',
          Contract.c_vendor_id,
          Contract_Eval.N_SubCont_seq,
          Contract_Eval.c_performance,
          Contract_Eval.c_type,
          Contract_Eval.si_Eval_stage,
          Contract_Eval.c_quality_work,
         Contract_Eval.c_scheduling,
          Contract_Eval.c_management,
          Contract_Eval.c_eeo,
          Contract_Eval.c_budget,
          Contract_Eval.c_safety
      FROM CMS_CONTRACT CONTRACT   
             inner join cms_Contract_Eval  CONTRACT_EVAL on CONTRACT.C_CONTRACT = CONTRACT_EVAL.C_CONTRACT   
             left outer join  CMS_SUBCONT  SUBCONT on CONTRACT_EVAL.N_SUBCONT_SEQ = SUBCONT.N_SUBCONT_SEQ 
      WHERE (( CONTRACT.c_vendor_id = @vendor_id )  --AND
           --( CONTRACT.C_CONTRACT = CONTRACT_EVAL.C_CONTRACT ) AND
           --( CONTRACT_EVAL.N_SUBCONT_SEQ = SUBCONT.N_SUBCONT_SEQ ) 
		   AND
			(CONTRACT_EVAL.SD_EVAL_END between DATEADD(Month,-12,GetDate()) and Getdate() )
		   )

     
     UPDATE #Cont_eval
       SET  Eval_type = 'Constr.' WHERE c_type = 'C'

     UPDATE #Cont_eval
       SET  Eval_type = 'Design' WHERE c_type = 'D'

     UPDATE #Cont_eval
       SET  Eval_type = 'Req''mt' WHERE c_type = 'R'

     UPDATE #Cont_eval
       SET  Eval_type = 'SubContr.' WHERE c_type = 'S'

     UPDATE #Cont_eval
       SET  Eval_stage = 'Interim' WHERE si_Eval_stage = 1

     UPDATE #Cont_eval
       SET  Eval_stage = 'Interim II' WHERE si_Eval_stage = 2

     UPDATE #Cont_eval
       SET  Eval_stage = 'Subst Com.' WHERE si_Eval_stage = 3

     UPDATE #Cont_eval
       SET  Eval_stage = 'Post Occu.' WHERE si_Eval_stage = 4

     UPDATE #Cont_eval
       SET  Eval_stage = 'Phase I' WHERE si_Eval_stage = 5

     UPDATE #Cont_eval
       SET  Eval_stage = 'Phase II' WHERE si_Eval_stage = 6

     UPDATE #Cont_eval
       SET  Eval_stage = 'Phase III' WHERE si_Eval_stage = 7

     UPDATE #Cont_eval
       SET  Eval_stage = 'Other' WHERE si_Eval_stage = 8

     UPDATE #Cont_eval
       SET Prime_or_Sub = 'Sub' WHERE N_SubCont_seq is NOT Null

     UPDATE #Cont_eval
       SET Prime_or_Sub = 'Prime' WHERE N_SubCont_seq is Null

     UPDATE #Cont_eval
       SET OverAll_Perform = 'OutStand.' WHERE c_performance = 'O'

     UPDATE #Cont_eval
       SET OverAll_Perform = 'Very Good' WHERE c_performance = 'V'

     UPDATE #Cont_eval
       SET OverAll_Perform = 'Satisfact.' WHERE c_performance = 'S'

     UPDATE #Cont_eval
       SET OverAll_Perform = 'Marginal' WHERE c_performance = 'M'

     UPDATE #Cont_eval
       SET OverAll_Perform = 'UnSatisfa.' WHERE c_performance = 'U'

     UPDATE #Cont_eval
       SET OverAll_Perform = 'N/A' WHERE c_performance = 'N'

     UPDATE #Cont_eval
       SET quality_work = 'OutStand.' WHERE c_quality_work = 'O'

     UPDATE #Cont_eval
       SET quality_work = 'Very Good' WHERE c_quality_work = 'V'

     UPDATE #Cont_eval
       SET quality_work = 'Satisfact.' WHERE c_quality_work = 'S'

     UPDATE #Cont_eval
       SET quality_work = 'Marginal' WHERE c_quality_work = 'M'

     UPDATE #Cont_eval
       SET quality_work = 'UnSatisfa.' WHERE c_quality_work = 'U'

     UPDATE #Cont_eval
       SET quality_work = 'N/A' WHERE c_quality_work = 'N'

     UPDATE #Cont_eval
       SET scheduling = 'OutStand.' WHERE c_scheduling = 'O'

     UPDATE #Cont_eval
       SET scheduling = 'Very Good' WHERE c_scheduling = 'V'

     UPDATE #Cont_eval
       SET scheduling = 'Satisfact.' WHERE c_scheduling = 'S'

     UPDATE #Cont_eval
       SET scheduling = 'Marginal' WHERE c_scheduling = 'M'

     UPDATE #Cont_eval
       SET scheduling = 'UnSatisfa.' WHERE c_scheduling = 'U'

     UPDATE #Cont_eval
       SET scheduling = 'N/A' WHERE c_scheduling = 'N'

     UPDATE #Cont_eval
       SET management = 'OutStand.' WHERE c_management = 'O'

     UPDATE #Cont_eval
       SET management = 'Very Good' WHERE c_management = 'V'

     UPDATE #Cont_eval
       SET management = 'Satisfact.' WHERE c_management = 'S'

     UPDATE #Cont_eval
       SET management = 'Marginal' WHERE c_management = 'M'

     UPDATE #Cont_eval
       SET management = 'UnSatisfa.' WHERE c_management = 'U'

     UPDATE #Cont_eval
       SET management = 'N/A' WHERE c_management = 'N'

     UPDATE #Cont_eval
       SET eeo = 'OutStand.' WHERE c_eeo = 'O'

     UPDATE #Cont_eval
       SET eeo = 'Very Good' WHERE c_eeo = 'V'

     UPDATE #Cont_eval
       SET eeo = 'Satisfact.' WHERE c_eeo = 'S'

     UPDATE #Cont_eval
       SET eeo = 'Marginal' WHERE c_eeo = 'M'

     UPDATE #Cont_eval
       SET eeo = 'UnSatisfa.' WHERE c_eeo = 'U'

     UPDATE #Cont_eval
       SET eeo = 'N/A' WHERE c_eeo = 'N'

     UPDATE #Cont_eval
       SET budget = 'OutStand.' WHERE c_budget = 'O'

     UPDATE #Cont_eval
       SET budget = 'Very Good' WHERE c_budget = 'V'

     UPDATE #Cont_eval
       SET budget = 'Satisfact.' WHERE c_budget = 'S'

     UPDATE #Cont_eval
       SET budget = 'Marginal' WHERE c_budget = 'M'

     UPDATE #Cont_eval
       SET budget = 'UnSatisfa.' WHERE c_budget = 'U'

     UPDATE #Cont_eval
       SET budget = 'N/A' WHERE c_budget = 'N'


     UPDATE #Cont_eval
       SET safety = 'OutStand.' WHERE c_safety = 'O'

     UPDATE #Cont_eval
       SET safety = 'Very Good' WHERE c_safety = 'V'

     UPDATE #Cont_eval
       SET safety = 'Satisfact.' WHERE c_safety = 'S'

     UPDATE #Cont_eval
       SET safety = 'Marginal' WHERE c_safety = 'M'

     UPDATE #Cont_eval
       SET safety = 'UnSatisfa.' WHERE c_safety = 'U'

     UPDATE #Cont_eval
       SET safety = 'N/A' WHERE c_safety = 'N'

     SELECT #cont_eval.c_contract, #cont_eval.OverAll_Perform, #cont_eval.Eval_type, #cont_eval.Eval_stage, #cont_eval.quality_work, #cont_eval.scheduling, 
	 #cont_eval.management, #cont_eval.eeo, #cont_eval.budget, #cont_eval.safety, #cont_eval.Prime_or_Sub, #cont_eval.c_vendor_id, #cont_eval.n_SubCont_seq, 
	 #cont_eval.c_performance, #cont_eval.c_type, #cont_eval.si_Eval_stage, #cont_eval.c_quality_work, #cont_eval.c_scheduling, #cont_eval.c_management, 
	 #cont_eval.c_eeo, #cont_eval.c_budget, #cont_eval.c_safety FROM #cont_eval

     DROP TABLE #cont_eval
END
