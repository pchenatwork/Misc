﻿CREATE procedure [dbo].[DeletePlanCommunicationCommentAttachment] 
	@id int
AS

Update PlanCommunicationComment
Set FileName = null,
	AttachmentId = null
Where Id = @id
return @@rowcount
