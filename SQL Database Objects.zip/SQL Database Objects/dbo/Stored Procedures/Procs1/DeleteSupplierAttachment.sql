﻿CREATE procedure [dbo].[DeleteSupplierAttachment] 
	@supplierId int
AS

Update Supplier
Set FileName = null,
	AttachmentId = null
Where Id = @supplierId
return @@rowcount
