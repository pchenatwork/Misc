﻿
/*
*********************************************************************************************************************
Procedure:	DeleteScorecardTemplateCategory
Purpose:	Delete a row from ScorecardTemplateCategory table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/3/2006		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteScorecardTemplateCategory]
	@id int
as

delete ScorecardTemplateUserType
Where CategoryId = @id

delete ScorecardTemplateCategory
where Id = @id
return @@RowCount


