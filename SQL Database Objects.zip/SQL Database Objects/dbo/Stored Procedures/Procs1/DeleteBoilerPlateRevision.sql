﻿/*
*********************************************************************************************************************
Procedure:	DeleteBoilerPlateRevision
Purpose:	Delete a row from BoilerPlateRevision table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
1/20/2011		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteBoilerPlateRevision
	@id int
as

delete BoilerPlateRevision
where Id = @id
return @@RowCount

