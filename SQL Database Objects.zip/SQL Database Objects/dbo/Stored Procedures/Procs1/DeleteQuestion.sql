﻿




/*
*********************************************************************************************************************
Procedure:	DeleteQuestion
Purpose:	Delete a row from Question table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/27/2004		AECSOFT\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteQuestion]
	@id int
as

delete Answer
Where QuestionId = @id

delete Answer
Where QuestionId in (Select Id From Question Where ParentId = @id)

delete QuestionCategory
Where QuestionId = @id

delete Question
where ParentId = @id

delete Question
where Id = @id

return @@RowCount





