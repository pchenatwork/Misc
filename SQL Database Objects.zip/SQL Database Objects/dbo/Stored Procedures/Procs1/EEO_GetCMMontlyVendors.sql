﻿IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[EEO_GetCMMontlyVendors]'))
   EXEC('CREATE PROCEDURE [dbo].[EEO_GetCMMontlyVendors] AS BEGIN SET NOCOUNT ON; END')
GO
/*
*******************************************************************************
Procedure:	 
Purpose:	 
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
09/11/2015		Syed			    Created
9/30/2015		Pasha				isnull(m.D_CONSTR_END,getdate()) added
                                    Made change to filter for Mentor firms only. Added
                                    Used eeo_latest_ppm_rating instead of using eeo_mentor_ppm_rating 
                                    Modified the end logic of getting counter
08/02/2017		PCHEN				Combine URS(11-1445800) and AECom(13-5511947), into one
10/24/2017		PCHEN				code refactor + performance tuning
---------------------------
Note 11/03/2017 Code is not deployed due to no requirement yet.
*******************************************************************************
*/
ALTER PROCEDURE [dbo].[EEO_GetCMMontlyVendors]
        @userId int =0
AS

Begin

Declare
    @vendorid as int, 
    @TaxId as VARCHAR(20),
    @startDate as Date ,
    @endDate as Date ,
    @currentDate date=getdate(),
    @DayOfMonth Int , 
    @Month Int,
    @Year Int,
    @EndYear Int,
    @Days4MonthlyAssessment int

Select @Days4MonthlyAssessment = ISNULL([value],0) from dbo.EEO_CONFIG
    where [key] = 'Days4MonthlyAssessment'
  
---** 20170802 PCH AECOM took over USR, so bind these two EIN together
---** 20171024 further fine tune
DECLARE @t_CMTaxIDs TABLE (
    TaxID NVARCHAR(100)
) 

DECLARE @cm_cnt INT

INSERT INTO @t_CMTaxIDs 
SELECT LTRIM(RTRIM(ISNULL(Title, ''))) FROM [user] 
WHERE Id = @userId
SELECT @cm_cnt = @@ROWCOUNT

---** get cm_count,
--  @cm_cnt = 0 ==> All 
--  @cm_cnt < 0 ==> None
--  @cm_cnt > 0 ==> Get Mentor related to the specific CM taxID

IF (@cm_cnt = 0) 
    SELECT @cm_cnt = -1 -- User don't exist

IF EXISTS(SELECT 1 FROM @t_CMTaxIDs WHERE LEN(TaxID)=0) OR @userId = 0
    SELECT @cm_cnt = 0  -- Empty TaxID -> All

IF EXISTS (SELECT 1 FROM @t_CMTaxIDs WHERE TaxID in ('11-1445800', '13-5511947'))
BEGIN
    DELETE FROM @t_CMTaxIDs
	---** Combine URS(11-1445800) and AECom ('13-5511947')
    INSERT INTO @t_CMTaxIDs VALUES ('11-1445800'), ('13-5511947')
END

---** List of CM Contracts
DECLARE @t_CMContracts TABLE (
    C_CONTRACT VARCHAR(50)
)
INSERT INTO @t_CMContracts
    SELECT DISTINCT C_CONTRACT 
    FROM MV_SOLICIT_CONTRACT A
    JOIN @t_CMTaxIDs B ON A.C_VENDOR_ID = B.TaxID


Declare @tempVendorPeriod Table
(
    Id int identity (1,1) Primary Key,
    PeriodId decimal(5,0),
    Vendorid int,
    TaxId VARCHAR(20),
    Period_StartDate Datetime,
    Period_EndDate Datetime
)
DECLARE eeo_vendor_cursor CURSOR FOR 
    SELECT distinct V.ID, V.FederalId,
        DATEFROMPARTS(YEAR(GD.SD_START_DATE),MONTH(GD.SD_START_DATE),1)  AS STARTDATE,   -- start of the month
        EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS ENDDATE  --  USE SD_EXT_GRAD_DATE FIRST OTHERWISE SD_GRAD_DATE AND EXCLUDE FINAL YEAR
    FROM (
        SELECT * FROM  DBO.EEO_MENTOR_GRAD_DETAIL  A
        WHERE ID = (
            SELECT MAX(ID) FROM DBO.EEO_MENTOR_GRAD_DETAIL B
            WHERE C_MENTOR_TYPE='MENTOR' 
            AND B.VENDORID = A.VENDORID
        )
    ) GD , EEO_VENDOR EV, VENDOR V  
    WHERE  GD.VENDORID=EV.VENDORID
    AND EV.VENDORID =V.ID
    AND EV.MENTORFLAG IN (4,6,0)
    AND (@cm_cnt=0 
        OR (@cm_cnt>0 AND EXISTS (
            SELECT 1 FROM MV_SOLICIT_CONTRACT SC 
            WHERE SC.ME_VENDOR_ID = V.FederalId
            AND SC.ME_CONTRACT IN (
                SELECT DISTINCT C_CONTRACT 
                FROM @t_CMContracts )
           ))
        )
 
OPEN eeo_vendor_cursor
    FETCH NEXT FROM eeo_vendor_cursor 
        INTO @vendorid, @TaxId, @startDate,@endDate

    WHILE @@FETCH_STATUS = 0
    BEGIN
        Insert Into @tempVendorPeriod
        (   PeriodId ,
            Vendorid,
            TaxId,
            Period_StartDate, 
            Period_EndDate  
            )
        SELECT number+1,
            @vendorid,
            @TaxId,
            DATEADD(year,number,@startDate) PeriodStart,
            DATEADD(DAY,-1,	DATEADD(year,number+1,@startDate)) PeriodEnd 
        from master..spt_values sv
                where sv.type = 'P' AND DATEADD(year,number,@startDate) <= DATEADD(day, @Days4MonthlyAssessment,@endDate)                                 

            -- Get the next vendor.
    FETCH NEXT FROM eeo_vendor_cursor 
        INTO @vendorid, @TaxId, @startDate,@endDate
    END 

CLOSE eeo_vendor_cursor;
DEALLOCATE eeo_vendor_cursor;

---* Final select 
Select distinct pm.vendorid
    from 
        (
            SELECT Vendorid,TaxId, PeriodId ,Period_StartDate,Period_EndDate, DATEADD(month,number,Period_StartDate) PeriodMonth
            from 
                @tempVendorPeriod t, master..spt_values sv
            where sv.type = 'P' and DATEADD(month,number,t.Period_StartDate) <t.Period_EndDate
        ) pm 
        --left outer join  V_EEO_PROJECT_ORCMS_ACTIVITY PAC on  ISNULL(PAC.C_VENDOR_ID,PAC.ME_VENDOR_ID)= pm.TaxId 
        left outer join  V_EEO_PROJECT_ORCMS_ACTIVITY PAC on PAC.ME_VENDOR_ID= pm.TaxId
    where 
        PeriodMonth  >= DATEADD(dd, 1, EOMONTH(PAC.CONST_BEGIN , -1)) 
        and EOMONTH(pm.PeriodMonth) <= EOMONTH(isnull(PAC.CO_DATE,@currentDate)) 
        and PeriodMonth  <= @currentDate --  check only period months less then or equal to today date
        and @currentDate BETWEEN PeriodMonth  AND EOMONTH(PeriodMonth) --  
        and  not exists (
                    select * 
                    from eeo_latest_ppm_rating  
                    where vendorid=pm.vendorid
                        and PROJ_CODE=PAC.C_PROJ_CODE
                        and EOMONTH(MONTH_RATED)=	EOMONTH(PeriodMonth)	 -- very important				
                        and isnull(IS_SUBMITTED,0)=1
            )
        and (@cm_cnt=0  -- ALL
             OR ( @cm_cnt > 0 AND PAC.ME_CONTRACT in (select c_contract from @t_CMContracts ))
            )	
END
GO
/*
exec EEO_GetCMMontlyVendors
        @userId = 945

exec EEO_GetCMMontlyVendors
        @userId = 945
        */