﻿CREATE procedure [dbo].[DeleteSupplierCommentAttachment] 
	@id int
AS

Update SupplierComment
Set FileName = null,
	AttachmentId = null
Where Id = @id
return @@rowcount
