﻿/*
*********************************************************************************************************************
Procedure:	DeleteVendorContact
Purpose:	Delete a row from VendorContact table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/9/2004		AECSOFT\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteVendorContact]
	@id int
as


delete from VendorContactRole where vendorcontactId = @id
delete from VendorContact where Id = @id
return @@RowCount




