﻿

Create procedure DeletePermissionDetail
	@id int
as

delete PermissionDetail
where Id = @id
return @@RowCount




