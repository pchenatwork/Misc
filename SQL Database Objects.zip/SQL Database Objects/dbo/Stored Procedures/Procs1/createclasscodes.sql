﻿


/*
*********************************************************************************************************************
Procedure:	UpdateSubcontractorDocument
Purpose:	Update a row in SubcontractorDocument table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/12/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[createclasscodes]
	@classcodesXml ntext
as

Declare @hdoc int
EXEC sp_xml_preparedocument @hDoc OUTPUT, @classcodesXml

-- Insert to the database table.

Select * into classcodes
FROM OPENXML(@hDoc, '/ArrayOfSetting/Setting', 1)
WITH
(
	Name nvarchar(200),
	value nvarchar(100)
)


 --Release the internal representation of the XML document.
EXEC sp_xml_removedocument @hDoc