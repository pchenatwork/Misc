﻿



CREATE PROCEDURE [dbo].[DeleteSupplierDisadvantagedEmployeeResume]
(
@id int
)AS
Begin

Update  SupplierDisadvantagedEmployee
set  ResumeFilename ='',
	ResumeId = null
Where Id = @id
return @@rowcount
End










