﻿
CREATE  PROCEDURE [dbo].[aspnet_Users_CreateUser]
    @ApplicationId    uniqueidentifier,
    @UserName         nvarchar(256),
    @IsUserAnonymous  bit,
    @LastActivityDate DATETIME,
    @UserId           uniqueidentifier OUTPUT
AS
BEGIN
    IF( @UserId IS NULL )
        SELECT @UserId = NEWID()
    ELSE
    BEGIN
        IF( EXISTS( SELECT UserId FROM dbo.aspnet_Users
                    WHERE @UserId = UserId ) )
            RETURN -1
    END
    INSERT dbo.aspnet_Users (ApplicationId, UserId, UserName, LoweredUserName, IsAnonymous, LastActivityDate)
    VALUES (@ApplicationId, @UserId, @UserName, LOWER(@UserName), @IsUserAnonymous, @LastActivityDate)

	IF exists ( Select * from aspnet_Applications where ApplicationId = @ApplicationId
				and ApplicationName = '/USPS' )
		Update Supplier set SupplierId = @UserId, Password = '3' where Supplier.UserName = @UserName
	ELSE
		INSERT dbo.[User] (UserId)  VALUES ( @UserId )

    RETURN 0
END









