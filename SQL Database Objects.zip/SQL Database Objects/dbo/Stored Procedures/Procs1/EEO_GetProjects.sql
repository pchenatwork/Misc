﻿  
--=============================================================================================  
  
-----------------------------------------------------------  
------ Alter EEO_GETPROJECTS to use V_EEO_PROJECT_ORCMS_ACTIVITY  
-----------------------------------------------------------  
  
  
 /*  
*********************************************************************************************************************  
Procedure:    
Purpose:    
---------------------------------------------------------------------------------------------------------------------  
Date   Developer   Notes  
==========  =================== ===============================  
09/11/2015  Syed       Created 
9/30/2015       Pasha    Made change to add isnull(D_CONSTR_END,Getdate()). If the project end date is null then consider today's date  
7/25/2017		Rulong	 Made change to filter those projects without Constr_begin date
2/23/2021       Rekha    Made changes to include  LSP Projects
*********************************************************************************************************************  
*/  
ALTER PROCEDURE [dbo].[EEO_GetProjects]  
 -- Add the parameters for the stored procedure here  
 @vendorId int,  
    @targetMonth int,  
    @targetYear int  
AS  
  
Begin  
  
Declare @federalId as nvarchar(20)   
Declare @DayOfMonth TinyInt Set @DayOfMonth = 1  
Declare @Month TinyInt Set @Month =@targetMonth  
Declare @Year Integer Set @Year = @targetYear  
  
  
  
selecT  @federalId = v.FederalId from   Vendor v  
  where v.Id=@vendorId  
  
 SELECT DISTINCT PAC.C_PROJ_CODE as C_PACKAGE_CODE,PAC.CONST_BEGIN as D_CONSTR_BEGIN,
       isnull(PAC.CO_DATE,Getdate()) as D_CONSTR_END  FROM  V_EEO_PROJECT_ORCMS_ACTIVITY PAC    
   WHERE ISNULL(C_VENDOR_ID,ME_VENDOR_ID)=@federalId  
    AND DATEADD(DAY, @DAYOFMONTH - 1,             
         DATEADD(MONTH, @MONTH - 1,   
               DATEADD(YEAR, @YEAR-1900, 0)))   
                 
 BETWEEN DATEADD(m, DATEDIFF(m, 0, D_CONSTR_BEGIN), 0) AND isnull(PAC.CO_DATE,Getdate())  
 AND PAC.CONST_BEGIN IS NOT NULL
  
  UNION

 SELECT DISTINCT LSP.ProjectCode as C_PACKAGE_CODE,LSP.StartDate as D_CONSTR_BEGIN,
       isnull(LSP.EndDate,Getdate()) as D_CONSTR_END  FROM  VW_LSPProjects LSP    
   WHERE LSP.VendorTaxId=@federalId  
    AND DATEADD(DAY, @DAYOFMONTH - 1,             
         DATEADD(MONTH, @MONTH - 1,   
               DATEADD(YEAR, @YEAR-1900, 0)))   
                 
 BETWEEN DATEADD(m, DATEDIFF(m, 0, LSP.StartDate), 0) AND isnull(LSP.EndDate,Getdate())  
 AND LSP.StartDate IS NOT NULL
 
end  




