﻿
CREATE PROCEDURE [dbo].[CheckSupplierExist] 
	@email nvarchar( 50 ),
	@federalId nvarchar( 50 ),
	@ssn nvarchar( 50 ),
	@company nvarchar( 50 )
AS
Begin
	Select Count( * ) from Supplier 
	where Id != convert(int, @ssn)
		and dbo.fnStripNonnumericChars(FederalId) = dbo.fnStripNonnumericChars(@federalId)
		and @federalId != '' 
End


