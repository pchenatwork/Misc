﻿




/*
*********************************************************************************************************************
Procedure:	CopyPackageFromTemplate
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
08/27/2007	Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CopyProjectDocumentFromTemplate]
	@projectId int,
	@addendumId int,
	@type nvarchar(20),
	@templateId int,
	@userName nvarchar(50)
AS
Begin
Set NoCount On

if @type='Addendum'
	-- Insert Package
	Insert Into ProjectDocument
	( 
		ProjectId,
		RefId,
		Type,
		FileName,
		AttachmentId,
		ChangeUser,
		ChangeDate
	) 
	Select  
		@projectId,
		@addendumId,
		@type,
		FileName,
		AttachmentId,
		@userName,
		getdate()
	From RfxDocument
	Where LibraryId = @templateId


return 1
End





