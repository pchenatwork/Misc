﻿Create procedure DeleteAction
	@id int
as
delete Action
where Id = @id
return @@RowCount


