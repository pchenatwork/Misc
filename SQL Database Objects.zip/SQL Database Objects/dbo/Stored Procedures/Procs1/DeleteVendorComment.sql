﻿/*
*********************************************************************************************************************
Procedure:	DeleteVendorComment
Purpose:	Delete a row from VendorComment table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
12/15/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteVendorComment
	@id int
as

delete VendorComment
where Id = @id
return @@RowCount

