﻿



CREATE PROCEDURE [dbo].[DeleteSupplierPersonnelCertification]
(
@id int
)AS
Begin

Update  SupplierPersonnel
set  CertificationFilename ='',
	CertificationId = null
Where Id = @id
return @@rowcount
End










