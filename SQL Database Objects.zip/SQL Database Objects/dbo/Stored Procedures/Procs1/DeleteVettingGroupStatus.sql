﻿/*
*********************************************************************************************************************
Procedure:	DeleteVettingGroupStatus
Purpose:	Delete a row from VettingGroupStatus table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/28/2007		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteVettingGroupStatus
	@id int
as

delete VettingGroupStatus
where Id = @id
return @@RowCount

