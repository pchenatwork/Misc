﻿/*
*********************************************************************************************************************
Procedure:	DeleteSubContractorLicense
Purpose:	Delete a row from SubContractorLicense table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/3/2008		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteSubContractorLicense
	@id int
as

delete SubContractorLicense
where Id = @id
return @@RowCount

