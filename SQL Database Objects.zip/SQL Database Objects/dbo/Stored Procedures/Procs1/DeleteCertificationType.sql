﻿

/*
*********************************************************************************************************************
Procedure:	DeleteCertificationType
Purpose:	Delete a row from CertificationType table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
12/8/2004		AECSOFT\lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteCertificationType
	@id int
as
delete CertificationType
where Id = @id
return @@RowCount





