﻿/*
*********************************************************************************************************************
Procedure:	DeletePackage
Purpose:	Delete a row from Package table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/29/2007		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeletePackage]
	@id int
as

BEGIN Transaction

delete PackageHistory
Where PackageId = @id

delete Package
where Id = @id

if @@error = 0
begin
	Commit Transaction
	return 1
end
else
begin
	RollBack Transaction
	return 0
end



