﻿/*
*********************************************************************************************************************
Procedure:	DeleteRfxDocument
Purpose:	Delete a row from RfxDocument table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
2/15/2006		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteRfxDocument]
	@id int
as

BEGIN Transaction

delete RfxDocumentHistory
Where DocumentId = @id

delete RfxDocument
where Id = @id

if @@error = 0
	Commit Transaction
else
	RollBack Transaction

return @@RowCount

