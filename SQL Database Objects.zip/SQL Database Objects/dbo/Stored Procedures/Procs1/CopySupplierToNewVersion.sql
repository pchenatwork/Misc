﻿




CREATE procedure  [dbo].[CopySupplierToNewVersion]
	@oldSupplierId int = null,
	@newSupplierId int = null,
	@type nvarchar(50) = null
AS
BEGIN
SET NOCOUNT ON

	--Keep Cert
	if @type = 'Cert'
	begin
		begin tran
		begin try
			--1. not copied in copysupplier sp.		
			update SupplierStaticCertification set supplierId=@newSupplierId where supplierId=@oldSupplierId
			update SupplierWorkflow set supplierId=@newSupplierId where supplierId=@oldSupplierId and workflowtype='Supplier Certification'
			update SupplierStatus set supplierId= @newSupplierId where supplierId=@oldSupplierId and typename='Supplier Certification'
			update SupplierComment set supplierId = @newSupplierId where supplierId=@oldSupplierId 
			update SupplierFinancial set supplierId = @newSupplierId where supplierId=@oldSupplierId
			
			--2. partially copied in copysupplier sp.
			update SupplierProperty set supplierId = @newSupplierId where supplierId=@oldSupplierId and propertyId in (501, 502, 503, 504, 509, 516, 517, 518, 519, 520, 523, 524, 533, 534, 535, 536, 537, 1400, 1800)			
			insert into supplierproperty(SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName)
			select @newSupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName
			from supplierproperty where supplierid=@oldSupplierId 
				and 
				(
					(--internal
					propertyId not in (10, 50, 51, 54)
					--osha.ascx 
					and propertyId not in (62, 63, 64, 65)
					--
					and (propertyId <447 or (propertyId >495 and propertyId <501) or propertyId in (2001,2003,2004))
					and convert(nvarchar(1000), isnull(propertytext, '')) ='N'
					)
					
					or
					
					(--internal
					propertyId in (10, 50, 51, 54)
					--osha.ascx 
					or propertyId in (62, 63, 64, 65)
					--
					or(propertyId >=447 and propertyId <=495)
					)
				)
			/*
			insert SupplierDocument
			(
				SupplierId,
				Type,
				Filename,
				Attachment,
				Status,
				DocumentId,
				TransactionId,
				DocumentNo,
				ExpirationDate,
				Description,
				CopyId,
				ChangeDate,
				ChangeUser
			)
			select
				@newSupplierId,
				Type,
				Filename,
				Attachment,
				Status,
				newid(),
				TransactionId,
				DocumentNo,
				ExpirationDate,
				Description,
				Id,
				ChangeDate,
				ChangeUser
			from SupplierDocument 
			where supplierId=@oldSupplierId
			and (isnull(type, '') like '%FinancialStatement%' --Financial Statement Documents
				or isnull(type, '') like '%Checklist%')

			*/
			--3. Copied in CopySupplier sp	
			
			--SupplierPersonnel 
			update sp1
			set
				sp1.status = 0,
				sp1.isverified = 'N'
			from 
				(select * from SupplierPersonnel where supplierId = @newSupplierId) sp1
			inner join
				(select * from SupplierPersonnel where supplierId = @oldSupplierId) sp2
			on
				sp1.copyId = sp2.Id
						
			update Supplier set certsubmitteddate = (select certsubmittedDate from supplier where Id=@oldSupplierid) where Id=@newSupplierId
			update Supplier set certsubmitteddate = null where Id=@oldSupplierId
			update Supplier set certifieddate = (select certifieddate from supplier where Id=@oldSupplierid) where Id=@newSupplierId
			update Supplier set certifieddate = null where Id=@oldSupplierId
			
			update vendor set certifiedsupplierId = @newSupplierId where certifiedsupplierId = @oldSupplierId

			/****end****/
	
			commit tran
			return 1
		end try
		begin catch
			rollback tran
			return 0
		end catch
	end

	--Keep Qual
	if @type = 'Qual'
	begin
		begin tran
		begin try

			
			--1. not copied in copysupplier sp.		
			update SupplierStaticQualification set supplierId=@newSupplierId where supplierId=@oldSupplierId			
			update SupplierDisqualification set supplierId= @newSupplierId where supplierId=@oldSupplierId 
			update SupplierWorkflow set supplierId=@newSupplierId where supplierId=@oldSupplierId and workflowtype='Supplier Prequalification'
			update SupplierStatus set supplierId= @newSupplierId where supplierId=@oldSupplierId and typename='Supplier Prequalification'
			update SupplierComment set supplierId = @newSupplierId where supplierId=@oldSupplierId
			update SupplierFinancial set supplierId = @newSupplierId where supplierId=@oldSupplierId
			
			
			--2. partially copied in copysupplier sp.
			update SupplierProperty set supplierId = @newSupplierId where supplierId=@oldSupplierId and propertyId in (505, 506, 507, 508, 511, 512, 513, 514, 515, 521, 522, 532, 539, 540, 541, 542, 1200, 1600)			
			insert into supplierproperty(SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName)
			select @newSupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName
			from supplierproperty where supplierid=@oldSupplierId 
				and 
				(
					(--internal
					propertyId not in (10, 50, 51, 54)
					--osha.ascx 
					and propertyId not in (62, 63, 64, 65)
					--
					and (propertyId <447 or (propertyId >495 and propertyId <501) or propertyId in (2001,2003,2004))
					and convert(nvarchar(1000), isnull(propertytext, '')) ='N'
					)
					
					or
					
					(--internal
					propertyId in (10, 50, 51, 54)
					--osha.ascx 
					or propertyId in (62, 63, 64, 65)
					--
					or(propertyId >=447 and propertyId <=495)
					)
				)
				/*		
			insert SupplierDocument
			(
				SupplierId,
				Type,
				Filename,
				Attachment,
				Status,
				DocumentId,
				TransactionId,
				DocumentNo,
				ExpirationDate,
				Description,
				CopyId,
				ChangeDate,
				ChangeUser
			)
			select
				@newSupplierId,
				Type,
				Filename,
				Attachment,
				Status,
				newid(),
				TransactionId,
				DocumentNo,
				ExpirationDate,
				Description,
				Id,
				ChangeDate,
				ChangeUser
			from SupplierDocument 
			where supplierId=@oldSupplierId
			and (isnull(type, '') like '%FinancialStatement%' --Financial Statement Documents
				or isnull(type, '') like '%Checklist%')
				*/
			--3. Copied in CopySupplier sp
			
			--SupplierApprenticeshipprogram is only related to qual app, not cert app, so need to be deleted and then updated
			delete from SupplierApprenticeshipprogram where supplierId=@newSupplierId
			update SupplierApprenticeshipprogram set supplierId = @newSupplierId where supplierId=@oldSupplierId
			
			--SupplierPersonnel 
			update sp1
			set
				sp1.status =0,
				sp1.isverified = 'N'
			from 
				(select * from SupplierPersonnel where supplierId = @newSupplierId) sp1
			inner join
				(select * from SupplierPersonnel where supplierId = @oldSupplierId) sp2
			on
				sp1.copyId = sp2.Id
				
			
			
			update Supplier set qualsubmitteddate = (select qualsubmitteddate from supplier where Id=@oldSupplierid) where Id=@newSupplierId
			update Supplier set qualsubmitteddate = null where Id=@oldSupplierId
			update Supplier set qualifieddate = (select qualifieddate from supplier where Id=@oldSupplierid) where Id=@newSupplierId
			update Supplier set qualifieddate = null where Id=@oldSupplierId
			
			update vendor set qualifiedsupplierId = @newSupplierId where qualifiedsupplierId = @oldSupplierId
			
			update sc2
			set 
				sc2.IsApproved =sc1.IsApproved,
				sc2.ApprovedAverage = sc1.ApprovedAverage
			from
				(select * from suppliercategory where supplierid=@oldSupplierId) sc1
			inner join
				(select * from suppliercategory where supplierid=@newSupplierId) sc2
			on
				sc1.categoryId = sc2.categoryId
					
			/****end****/

			commit tran
			return 1
		end try
		begin catch
			rollback tran
			return 0
		end catch
	end

END





