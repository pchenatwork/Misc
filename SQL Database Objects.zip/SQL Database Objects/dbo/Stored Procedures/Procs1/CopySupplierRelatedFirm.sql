﻿





CREATE procedure [dbo].[CopySupplierRelatedFirm]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin
	insert SupplierRelatedFirm
		(
			SupplierId,
			CompanyName,
			CompanyTaxId,
			CompanyDescription,
			Phone,
			Fax,
			Url,
			AddressLine1,
			AddressLine2,
			City,
			State,
			Country,
			ZipCode,
			Relationship,
			Percentage,
			RepresentativeName,
			RepresentativeTitle,
			CopyId,
			ChangeDate,
			ChangeUser
		)
	select
			@newSupplierId,
			CompanyName,
			CompanyTaxId,
			CompanyDescription,
			Phone,
			Fax,
			Url,
			AddressLine1,
			AddressLine2,
			City,
			State,
			Country,
			ZipCode,
			Relationship,
			Percentage,
			RepresentativeName,
			RepresentativeTitle,
			Id,
			getdate(),
			@changeUser
	from SupplierRelatedFirm where supplierId=@supplierId

end




