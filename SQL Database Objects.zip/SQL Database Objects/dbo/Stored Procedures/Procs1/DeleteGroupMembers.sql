﻿/*
*********************************************************************************************************************
Procedure:	DeleteGroupMembers
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
12/05/2004	Lily Xiong		Created
*********************************************************************************************************************
*/
CREATE PROCEDURE DeleteGroupMembers
	@groupId int,
	@groupMembersXml ntext
AS
Declare @hdoc int
-- Convert GroupMember data from XML to in memory table. 
EXEC sp_xml_preparedocument @hDoc OUTPUT, @groupMembersXml
Delete From GroupMember
where GroupId = @groupId
and SupplierId in (Select SupplierId FROM OPENXML(@hDoc, '/ArrayOfGroupMember/GroupMember', 1)
	with
	(
		SupplierId int
	)
)
--Release the internal representation of the XML document.
EXEC sp_xml_removedocument @hDoc
RETURN 1




