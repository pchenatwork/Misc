﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplier
Purpose:	Delete a row from Supplier table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
05/17/2013		David Kwok		Created
*********************************************************************************************************************


ALTER TABLE delFromVasAuditlog
DROP CONSTRAINT PK_delFromVasAuditlog
GO
ALTER TABLE DELFROMVASAUDITLOG 
DROP COLUMN ID 
GO
ALTER TABLE delFromVasAuditlog
ADD ID INT IDENTITY(1, 1)constraint PK_delFromVasAuditlog primary key


*/
CREATE procedure [dbo].[DeleteSupplierFromVAS]
	@id int,
	@userName nvarchar(50)=null,
	@batchId uniqueidentifier
as
BEGIN Transaction

declare @supplierid uniqueidentifier
select @supplierid = supplierid from supplier where id = @id

declare @federalId nvarchar(50)
select @federalid=federalId from supplier where id=@id

----Auditlog
declare @recordId int
declare @actionTime  datetime
set @actionTime = getdate()
declare @transactionId int
insert into [Transaction](Type, ActionTime) values ('CMS', @actionTime)
select @transactionId = max(id) from [Transaction]	

declare @temp table
(
	tablename nvarchar(50),
	id int,
	vasid int,
	fieldname nvarchar(50),
	supplierId int,
	[content] nvarchar(500),
	[action] nvarchar(50)
)

declare @transferredflag  char(1)
select @transferredflag=transferredFlag from supplier where id = @id

declare @previousSupplierId int
select @previousSupplierId=id from (select id, row_number() over (order by id desc) as rownumber from supplier where federalid=@federalId) t where t.rownumber=2

declare @currentSupplierId int
select @currentSupplierId=currentsupplierid from vendor where federalId=(select federalId from supplier where id=@id)


if @transferredflag = 1
	begin 
	
		-----------------------	
		--SupplierPersonnel--
		-------------------------	
		if exists(select * from vendor where currentsupplierid=@id)
			begin
				insert into @temp
				(
					tablename,
					id,
					vasid,
					supplierid,
					[action]
				)
				select 'SupplierPersonnel', id, vasid, @id, 'delete' 
				from supplierpersonnel 
				where supplierid=@id 
					and transferredFlag='1'
					and vasid not in (select vasid from SupplierPersonnel 
										where transferredflag='1' and supplierid !=@id)

				--If current version, recover CMS to previous version
				declare @mycursor cursor
				set @mycursor = cursor for (select id from supplierpersonnel where supplierid = @previousSupplierId and transferredFlag = '1')
				open @mycursor
				fetch next from @mycursor into @recordId
				while @@fetch_status = 0
				begin					
					Insert @temp
						(TableName, Id,  VASId,  FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel', sp.Id, sp.vasid, 'V_c_vendor_id', sp.supplierid, @federalId, 'update'
						from SupplierPersonnel sp
						where  sp.id = @recordId

					Insert @temp
						(TableName, Id,  VASId, FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel', sp.Id, sp.vasid, 'name', sp.supplierid, sp.name, 'update'
						from SupplierPersonnel sp
						where  sp.id = @recordId
					
					Insert @temp
						(TableName, Id,  VASId, FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel', sp.Id, sp.vasid, 'phone', sp.supplierid, dbo.fnStripNonnumericChars(sp.phone),'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId 
					
					Insert @temp
						(TableName, Id,  VASId, FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel', sp.Id, sp.vasid, 'DOB', sp.supplierid, 
								case
								when sp.DOB ='1900/1/1' then null
								else sp.DOB
								end, 
								'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId 

					Insert @temp
						(TableName, Id,  VASId, FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel', sp.Id, sp.vasid,  'SSN', sp.supplierid, sp.SSN, 'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId 
					
					Insert @temp
						(TableName, Id,   VASId, FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel',sp.Id, sp.vasid, 'Title', sp.supplierid, sp.Title, 'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId 

					Insert @temp
						(TableName, Id,  VASId, FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel',sp.Id, sp.vasid, 'IsOwner', sp.supplierid, sp.IsOwner, 'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId  

					Insert @temp
						(TableName, Id, VASId, FieldName, supplierId, [Content],  Action)
						Select 	'SupplierPersonnel', sp.Id, sp.vasid,  'OwnedPercentage', sp.supplierid, sp.OwnedPercentage, 'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId  

					Insert @temp
						(TableName, Id, VASId,  FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel', sp.Id, sp.vasid,  'AddressLine1', sp.supplierid, sp.AddressLine1, 'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId  

			--		Insert @temp
			--			(TableName, Id, VASId, FieldName, supplierId, [Content],  Action)
			--			Select 	'SupplierPersonnel', sp.Id, sp.vasid, 'AddressLine2', sp.supplierid, sp.AddressLine2, 'update'
			--			from SupplierPersonnel sp 
			--			where sp.id = @recordId

					Insert @temp
						(TableName, Id, VASId, FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel',sp.Id, sp.vasid,'City', sp.supplierid, sp.City, 'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId  

					Insert @temp
						(TableName, Id, VASId,  FieldName, supplierId, [Content],Action)
						Select 	'SupplierPersonnel', sp.Id, sp.vasid, 'State', sp.supplierid, sp.State, 'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId  

					Insert @temp
						(TableName, Id, VASId,  FieldName, supplierId, [Content],  Action)
						Select 	'SupplierPersonnel', sp.Id, sp.vasid, 'ZipCode', sp.supplierid, sp.ZipCode, 'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId  

					Insert @temp
						(TableName, Id, VASId,  FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel',sp.Id, sp.vasid,  'EmploymentStartDate', sp.supplierid, 
								case
								when sp.EmploymentStartDate ='1900/1/1' then null
								else sp.EmploymentStartDate
								end, 
								'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId 

					Insert @temp
						(TableName, Id, VASId, FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel',sp.Id, sp.vasid,  'EmploymentEndDate', sp.supplierid, 
								case
								when sp.EmploymentEndDate ='1900/1/1' then null
								else sp.EmploymentEndDate
								end,  
								'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId  


					Insert @temp
						(TableName, Id, VASId,  FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel', sp.Id, sp.vasid,  'CurrentPositionStartDate', sp.supplierid, 
								case
								when sp.CurrentPositionStartDate ='1900/1/1' then null
								else sp.CurrentPositionStartDate
								end,
								'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId 

					Insert @temp
						(TableName, Id, VASId,  FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel', sp.Id, sp.vasid,  'CurrentPositionEndDate', sp.supplierid, 
								case
								when sp.CurrentPositionEndDate ='1900/1/1' then null
								else sp.CurrentPositionEndDate
								end,
								'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId 

					Insert @temp
						(TableName, Id, VASId, FieldName, supplierId, [Content],  Action)
						Select 	'SupplierPersonnel', sp.Id, sp.vasid,  'TitleCategory', sp.supplierid, sp.titlecategory, 'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId

					Insert @temp
						(TableName, Id, VASId,  FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel', sp.Id, sp.vasid,  'Employer', sp.supplierid, sp.Employer, 'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId 

					Insert @temp
						(TableName, Id, VASId, FieldName, supplierId, [Content],  Action)
						Select 	'SupplierPersonnel', Id, sp.vasid,  'SOURCE', sp.supplierid, sp.Source, 'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId  

					Insert @temp
						(TableName, Id, VASId, FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel', Id, sp.vasid,  'ChangeUser', sp.supplierid, @userName, 'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId  

					Insert @temp
						(TableName, Id, VASId, FieldName, supplierId, [Content], Action)
						Select 	'SupplierPersonnel', Id, sp.vasid,  'ChangeDate', sp.supplierid, @actionTime, 'update'
						from SupplierPersonnel sp 
						where sp.id = @recordId   
				
					fetch next from @mycursor into @recordId
				end
				close @mycursor
				deallocate @mycursor
			end
		else
			begin
				insert into @temp
				(
					tablename,
					id,
					vasid,
					supplierid,
					[action]
				)
				select 'SupplierPersonnel', id, vasid, @id, 'delete' 
				from supplierpersonnel 
				where supplierid=@id 
					and transferredFlag='1'
					and vasid not in (select vasid from Supplierpersonnel 
										where transferredflag='1' and supplierid !=@id)
			end


		-----------------------	
		--SupplierApprenticeshipProgram--
		-------------------------
		insert into @temp
		(
			tablename,
			id,
			vasid,
			supplierId,
			[action]
		)
		select 'SupplierApprenticeshipProgram', id, id, @id,'delete' from SupplierApprenticeshipProgram 
		where supplierid=@id and transferredFlag='1'



		-----------------------	
		--SupplierProjectStatistics--
		-------------------------
		insert into @temp
		(
			tablename,
			id,
			vasid,
			supplierId,
			[action]
		)
		select 'SupplierProjectStatistics', id, id, @id, 'delete' from SupplierProjectStatistics 
		where supplierid=@id and transferredFlag='1'
	
		-----------------------	
		--SupplierCategory--
		-------------------------	
		insert into @temp
		(
			tablename,
			id,
			vasid,
			supplierId,
			[action]
		)
		select 'SupplierCategory', id, id, @id, 'delete' from SupplierCategory 
		where supplierid=@id and transferredFlag='1'

		-----------------------	
		--SupplierDisqualification--
		-------------------------
		insert into @temp
		(
			tablename,
			id,
			vasid,
			supplierId,
			[action]
		)
		select 'SupplierDisqualification', id, id, @id, 'delete' from SupplierDisqualification 
		where supplierid=@id and TransferredFlag='1'

		-----------------------	
		--SupplierPersonnelProject--
		-------------------------
		insert into @temp
		(
			tablename,
			id,
			vasid,
			supplierId,
			[action]
		)
		select 'SupplierPersonnelProject', id, id, @id, 'delete' from SupplierPersonnelProject 
		where supplierid=@id and transferredFlag='1'
	
		-----------------------	
		--SupplierProjectVerification--
		-------------------------	
		insert into @temp
		(
			tablename,
			id,
			vasid,
			supplierId,
			[action]
		)
		select 'SupplierProjectVerification', id, id, @id,'delete' from SupplierProjectVerification 
		where supplierid=@id and transferredFlag='1'

		-----------------------	
		--SupplierStaticQualification--
		-------------------------
		insert into @temp
		(
			tablename,
			id,
			vasid,
			supplierId,
			[action]
		)
		select 'SupplierStaticQualification', id, id, @id, 'delete' from SupplierStaticQualification 
		where supplierid=@id and transferredFlag='1'
	
		-----------------------	
		--SupplierStaticCertification--
		-------------------------	
		insert into @temp
		(
			tablename,
			id,
			vasid,
			supplierId,
			[action]
		)
		select 'SupplierStaticCertification', id, id, @id, 'delete' from SupplierStaticCertification 
		where supplierid=@id and transferredFlag='1'

		-----------------------	
		--SupplierMentorWorkflow--
		-------------------------
--		insert into @temp
--		(
--			tablename,
--			id,
--			vasid,
--			supplierId, 
--			[action]
--		)
--		select 'SupplierMentorWorkflow', id, id, @id 'delete' from SupplierWorkflow 
--		where supplierid=@id and transferredFlag='1' and workflowtype = 'Mentor Workflow'


		-----------------------	
		--Supplier--
		-------------------------	
		if exists(select * from vendor where currentsupplierid=@id)
			begin
				insert into @temp
				(
					tablename,
					id,
					vasid,
					supplierId,
					[action]
				)
				select 'Supplier', id, vasid, @id, 'delete' from supplier
				where id=@id and transferredFlag='1'
					and vasid not in (select vasid from Supplier 
										where transferredflag='1' and id !=@id)

				--If current version, recover CMS to previous version
				if exists(select * from supplier where id=@previousSupplierId and transferredFlag='1')
					begin
						Insert @temp
							(TableName, Id, VASId, FieldName, SupplierId, [Content], Action)
							Select 	'Supplier', s.id, s.vasid, 'Company',@previousSupplierId, s.company,'update'
							from Supplier s 
							where s.id = @previousSupplierId 

						Insert @temp
							(TableName, Id, VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'Supplier', s.id, s.vasid, 'TradeNames', @previousSupplierId, s.TradeNames,'update'
							from Supplier s  
							where s.id = @previousSupplierId 

						Insert @temp
							(TableName, Id,  VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'Supplier', s.id, s.vasid,  'Phone', @previousSupplierId, dbo.fnStripNonnumericChars(s.Phone),'update'
							from Supplier s  
							where s.id = @previousSupplierId  

						Insert @temp
							(TableName, Id,  VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'Supplier', s.id, s.vasid,   'Fax', @previousSupplierId, dbo.fnStripNonnumericChars(s.Fax),'update'
							from Supplier s  
							where s.id = @previousSupplierId  

						Insert @temp
							(TableName, Id,  VASId, FieldName, SupplierId, [Content], Action)
							Select 	'Supplier', s.id,s.vasid,  'Url', @previousSupplierId, s.Url,'update'
							from Supplier s  
							where s.id = @previousSupplierId  

						Insert @temp
							(TableName, Id,  VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'Supplier', s.id, s.vasid, 'LegalStructure', @previousSupplierId, s.LegalStructure,'update'
							from Supplier s  
							where s.id = @previousSupplierId  

						Insert @temp
							(TableName, Id,  VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'Supplier', s.id, s.vasid, 'FederalId', @previousSupplierId, @federalId,'update'
							from Supplier s
							where s.id = @previousSupplierId

						--SupplierAddress
						Insert @temp
							(TableName, Id,  VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'SupplierAddress', sa.Id, s.vasid,  'AddressLine1', @previousSupplierId, sa.AddressLine1,'update'
							from SupplierAddress sa 
							inner join Supplier s
							on sa.SupplierId = s.Id 
							where sa.addresstype ='PHYSICAL' 
							and s.Id = @previousSupplierId  

						Insert @temp
							(TableName, Id,  VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'SupplierAddress', sa.Id,  s.vasid,  'AddressLine2', @previousSupplierId, sa.AddressLine2,'update'
							from SupplierAddress sa 
							inner join Supplier s
							on sa.SupplierId = s.Id 
							where sa.addresstype ='PHYSICAL' 
							and s.Id = @previousSupplierId  
						
						Insert @temp
							(TableName, Id, VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'SupplierAddress',sa.Id,  s.vasid,  'City', @previousSupplierId, sa.City,'update'
							from SupplierAddress sa 
							inner join Supplier s
							on sa.SupplierId = s.Id 
							where sa.addresstype ='PHYSICAL' 
							and s.Id = @previousSupplierId   

						Insert @temp
							(TableName, Id,  VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'SupplierAddress', sa.Id,  s.vasid,  'State', @previousSupplierId, sa.State,'update'
							from SupplierAddress sa 
							inner join Supplier s
							on sa.SupplierId = s.Id 
							where sa.addresstype ='PHYSICAL' 
							and s.Id = @previousSupplierId  

						Insert @temp
							(TableName, Id,  VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'SupplierAddress', sa.Id,  s.vasid,  'ZipCode', @previousSupplierId, sa.ZipCode,'update'
							from SupplierAddress sa 
							inner join Supplier s
							on sa.SupplierId = s.Id 
							where sa.addresstype ='PHYSICAL' 
							and s.Id = @previousSupplierId  

						Insert @temp
							(TableName, Id,  VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'VendorContact', sc.Id, s.vasid,  'Name', @previousSupplierId, sc.Name,'update'
							from VendorContact sc
							inner join Vendor v
							on sc.vendorid = v.Id
							inner join supplier s
							on v.federalId = s.federalId
							where sc.contacttype = 'Primary'
							and sc.Fromvendor ='Y' 
							and s.Id=@previousSupplierId  

						Insert @temp
							(TableName, Id, VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'VendorContact', sc.Id, s.vasid,  'Phone', @previousSupplierId, dbo.fnStripNonnumericChars(sc.Phone),'update'
							from VendorContact sc
							inner join Vendor v
							on sc.vendorid = v.Id
							inner join supplier s
							on v.federalId = s.federalId
							where sc.contacttype = 'Primary'
							and sc.Fromvendor ='Y' 
							and s.Id=@previousSupplierId   

						Insert @temp
							(TableName, Id,  VASId, FieldName, SupplierId, [Content], Action)
							Select 	'VendorContact', sc.Id,s.vasid,  'Fax', @previousSupplierId, dbo.fnStripNonnumericChars(sc.Fax),'update'
							from VendorContact sc
							inner join Vendor v
							on sc.vendorid = v.Id
							inner join supplier s
							on v.federalId = s.federalId
							where sc.contacttype = 'Primary'
							and sc.Fromvendor ='Y' 
							and s.Id=@previousSupplierId  

						Insert @temp
							(TableName, Id,  VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'VendorContact', sc.Id, s.vasid, 'Email', @previousSupplierId, sc.Email,'update'
							from VendorContact sc
							inner join Vendor v
							on sc.vendorid = v.Id
							inner join supplier s
							on v.federalId = s.federalId
							where sc.contacttype = 'Primary'
							and sc.Fromvendor ='Y' 
							and s.Id=@previousSupplierId  
						
						Insert @temp
							(TableName, Id,  VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'VendorContact', sc.Id, s.vasid, 'V_c_email2', @previousSupplierId, sc.Email,'update'
							from VendorContact sc
							inner join Vendor v
							on sc.vendorid = v.Id
							inner join supplier s
							on v.federalId = s.federalId
							where sc.contacttype = 'Secondary'
							and sc.Fromvendor ='Y' 
							and s.Id=@previousSupplierId  

						Insert @temp
							(TableName, Id,  VASId,  FieldName, SupplierId, [Content], Action)
							Select 	'Supplier', s.id, s.vasid, 'V_c_email3', @previousSupplierId, sp.propertyText,'update'
							from SupplierProperty sp
							inner join supplier s
							on sp.supplierId = s.Id
							where sp.propertyId = 442
							and s.Id=@previousSupplierId

						Insert @temp
							(TableName, Id, VASId, FieldName, SupplierId, [Content], Action)
							Select 	'Supplier', s.id, s.vasid,  'V_ChangeUser', @previousSupplierId, s.changeuser,'update'
							from Supplier s  
							where s.id = @previousSupplierId   

						Insert @temp
							(TableName, Id, VASId, FieldName, SupplierId, [Content], Action)
							Select 	'Supplier', s.id, s.vasid,  'V_ChangeDate', @previousSupplierId, s.changedate,'update'
							from Supplier s  
							where s.id = @previousSupplierId  
					end
			end
		else
			begin
				insert into @temp
				(
					tablename,
					id,
					vasid,
					supplierId,
					[action]
				)
				select 'Supplier', id, vasid, @id, 'delete' from supplier
				where id=@id and transferredFlag='1'
					and vasid not in (select vasid from Supplier 
										where transferredflag='1' and id !=@id)
			end

		-----------------------	
		--Supplier_EEOMaster--
		-------------------------
		if exists(select * from vendor where currentsupplierid=@id)
			begin
				insert into @temp
				(
					tablename,
					id,
					vasid,
					supplierId, 
					[Action]
				)
				select 'Supplier_EEOMaster', id, vasid, @id, 'delete' from Supplier 
				where id=@id and eeomastertransferredFlag='1'
					and vasid not in (select vasid from Supplier 
										where eeomastertransferredFlag='1' and id !=@id)

				--If current version, recover CMS to previous version
				if exists(select * from supplier where id=@previousSupplierId and eeomastertransferredFlag='1')
					begin
						Insert @temp
							(TableName, Id, VASId, FieldName, SupplierId, [Content], Action)
							Select 	'Supplier_EEOMaster', s.vasid, s.vasid, 'V_c_vendor_id', @previousSupplierId, @federalId, 'update'
							from Supplier s  
							where s.id = @previousSupplierId  

				
						Insert @temp
							(TableName, Id, VASId, FieldName, SupplierId, [Content], Action)
							Select 	'Supplier_EEOMaster',  s.vasid,  s.vasid, 'V_SuretyName', @previousSupplierId, ss.SuretyName, 'update'
							from 
								SupplierSurety ss
							inner join 
								Supplier s
							on
								ss.SupplierId = s.Id
							where 
								ss.SupplierId=@previousSupplierId and ss.IsPrimary='Y'  

						declare @averageSales  bigint
						select @averageSales = avg(t.totalamout) from (select top 3 totalamout from supplierprojectstatistics where supplierid = @previousSupplierId order by year desc) t
						
						Insert @temp
							(TableName, Id, VASId, FieldName, SupplierId, [Content], Action)
							select 'Supplier_EEOMaster',  s.vasid,  s.vasid, 'V_M_AVERAGE_SALES', @previousSupplierId, @averageSales, 'update'
							from supplier s
							where id=@previousSupplierId

						Insert @temp
							(TableName, Id, VASId, FieldName, SupplierId, [Content], Action)
							select 'Supplier_EEOMaster',  s.vasid,  s.vasid, 'V_C_RACE', @previousSupplierId, s.ethnicity, 'update'
							from supplier s
							where id=@previousSupplierId
					end
			end
		else 
			begin
				insert into @temp
				(
					tablename,
					id,
					vasid,
					supplierId, 
					[Action]
				)
				select 'Supplier_EEOMaster', id, vasid, @id, 'delete' from Supplier 
				where id=@id and eeomastertransferredFlag='1'
					and vasid not in (select vasid from Supplier 
										where eeomastertransferredFlag='1' and id !=@id)
			end

		-----------------------	
		--Supplier_REVStatus--
		-------------------------
--		insert into @temp
--		(
--			tablename,
--			id,
--			vasid,
--			supplierId, 
--			[action]
--		)
--		select 'Supplier_REVStatus', id, vasid, @id, 'delete' from Supplier 
--		where id=@id and revstatustransferredFlag='1'
	end
----Auditlog

INSERT INTO delFromVasSupplierPersonnelGovernmentAgency
           ([SupplierId]
           ,[Position]
           ,[OrganizationName]
           ,[Relationship]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelId]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (
			 select
				   SupplierId
				   ,Position
				   ,OrganizationName
				   ,Relationship
				   ,StartDate
				   ,EndDate
				   ,QuestionIds
				   ,PersonnelId
				   ,DocumentIds
				   ,Present
				   ,ChangeUser
				   ,ChangeDate
				   ,@batchId
				   from SupplierPersonnelGovernmentAgency
				   where SupplierId = @Id 
			);

Delete	SupplierPersonnelGovernmentAgency where SupplierId = @Id

INSERT INTO delFromVasSupplierPersonnelMixedInfo
           ([ID]
           ,[SupplierId]
           ,[Type]
           ,[ExpertiseField]
           ,[TotalYears]
           ,[YearsInSupplier]
           ,[Amount]
           ,[ContributionType]
           ,[StartDate]
           ,[EndDate]
           ,[IsOwner]
           ,[HeldPosition]
           ,[EmployeeName]
           ,[Relationship]
           ,[FirmId]
           ,[QuestionIds]
           ,[PersonnelId]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
     (select
			ID
           ,SupplierId
           ,[Type]
           ,ExpertiseField
           ,TotalYears
           ,YearsInSupplier
           ,Amount
           ,ContributionType
           ,StartDate
           ,EndDate
           ,IsOwner
           ,HeldPosition
           ,EmployeeName
           ,Relationship
           ,FirmId
           ,QuestionIds
           ,PersonnelId
           ,DocumentIds
           ,Present
           ,ChangeUser
           ,ChangeDate
           ,@batchId 
           from SupplierPersonnelMixedInfo
           where SupplierId = @Id)

Delete	SupplierPersonnelMixedInfo where SupplierId = @Id 

INSERT INTO [delFromVasSupplierPersonnel]
           ([Id]
           ,[SupplierId]
           ,[TypeId]
           ,[Status]
           ,[Name]
           ,[Title]
           ,[TitleCategory]
           ,[Phone]
           ,[Extension]
           ,[CellPhone]
           ,[Fax]
           ,[DOB]
           ,[Ethnicity]
           ,[Gender]
           ,[IsOwner]
           ,[IsKeyPerson]
           ,[SSN]
           ,[OwnedPercentage]
           ,[OwnedShares]
           ,[PaidAmount]
           ,[HowSharesAcquired]
           ,[ContributionAmount]
           ,[CommonOrPreferred]
           ,[SharesAcquiredDate]
           ,[RegistrationNumber]
           ,[EmploymentStartDate]
           ,[EmploymentEndDate]
           ,[CurrentPositionStartDate]
           ,[CurrentPositionEndDate]
           ,[IsHiredByFirm]
           ,[Employer]
           ,[Source]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[CertificationFileName]
           ,[Certification]
           ,[ResumeFileName]
           ,[Resume]
           ,[Comment]
           ,[IsVerified]
           ,[IsVerified2]
           ,[VerifyUser]
           ,[VerifyDate]
           ,[AmendId]
           ,[AmendFlag]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[CopyId]
           ,[VASId]
           ,[SupplierPersonnelId]
           ,[SharesAcquiredOtherReason]
           ,[OIGReviewed]
           ,[BatchId])
    (select 
			[Id]
           ,[SupplierId]
           ,[TypeId]
           ,[Status]
           ,[Name]
           ,[Title]
           ,[TitleCategory]
           ,[Phone]
           ,[Extension]
           ,[CellPhone]
           ,[Fax]
           ,[DOB]
           ,[Ethnicity]
           ,[Gender]
           ,[IsOwner]
           ,[IsKeyPerson]
           ,[SSN]
           ,[OwnedPercentage]
           ,[OwnedShares]
           ,[PaidAmount]
           ,[HowSharesAcquired]
           ,[ContributionAmount]
           ,[CommonOrPreferred]
           ,[SharesAcquiredDate]
           ,[RegistrationNumber]
           ,[EmploymentStartDate]
           ,[EmploymentEndDate]
           ,[CurrentPositionStartDate]
           ,[CurrentPositionEndDate]
           ,[IsHiredByFirm]
           ,[Employer]
           ,[Source]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[CertificationFileName]
           ,[Certification]
           ,[ResumeFileName]
           ,[Resume]
           ,[Comment]
           ,[IsVerified]
           ,[IsVerified2]
           ,[VerifyUser]
           ,[VerifyDate]
           ,[AmendId]
           ,[AmendFlag]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[CopyId]
           ,[VASId]
           ,[SupplierPersonnelId]
           ,[SharesAcquiredOtherReason]
           ,[OIGReviewed]
           ,@batchId
           from SupplierPersonnel where SupplierId = @Id);
           
Delete  SupplierPersonnel where SupplierId = @Id

INSERT INTO [delFromVasSupplierDocument]
           ([Id]
           ,[SupplierId]
           ,[Type]
           ,[Filename]
           ,[AttachmentId]
           ,[Status]
           ,[DocumentId]
           ,[TransactionId]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[DocumentNo]
           ,[ExpirationDate]
           ,[Description]
           ,[CopyId]
           ,[BatchId])
	 (select [Id]
           ,[SupplierId]
           ,[Type]
           ,[Filename]
           ,[AttachmentId]
           ,[Status]
           ,[DocumentId]
           ,[TransactionId]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[DocumentNo]
           ,[ExpirationDate]
           ,[Description]
           ,[CopyId]
           ,@batchId from SupplierDocument where SupplierId = @Id);
           
Delete  SupplierDocument where SupplierId = @Id

INSERT INTO delFromVasSupplierRelatedFirm
           ([Id]
           ,[SupplierId]
           ,[CompanyName]
           ,[CompanyTaxId]
           ,[CompanyDescription]
           ,[Phone]
           ,[Fax]
           ,[Url]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[Relationship]
           ,[Percentage]
           ,[RepresentativeName]
           ,[RepresentativeTitle]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[CopyId]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[CompanyName]
           ,[CompanyTaxId]
           ,[CompanyDescription]
           ,[Phone]
           ,[Fax]
           ,[Url]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[Relationship]
           ,[Percentage]
           ,[RepresentativeName]
           ,[RepresentativeTitle]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[CopyId]
           ,@batchId from SupplierRelatedFirm where SupplierId = @Id);
           
Delete	SupplierRelatedFirm where SupplierId = @Id

INSERT INTO delFromVasSupplierAddress
           ([Id]
           ,[SupplierId]
           ,[AddressType]
           ,[FromSupplier]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[ZipCode]
           ,[Country]
           ,[AddressId]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[County]
           ,[ContactId]
           ,[BatchId])
	(select [Id]
           ,[SupplierId]
           ,[AddressType]
           ,[FromSupplier]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[ZipCode]
           ,[Country]
           ,[AddressId]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[County]
           ,[ContactId]
           ,@batchId from SupplierAddress where SupplierId = @Id);

Delete  SupplierAddress where SupplierId = @Id

INSERT INTO [delFromVasSupplierCategory]
           ([Id]
           ,[SupplierId]
           ,[CategoryId]
           ,[IsApproved]
           ,[Average]
           ,[ApprovedAverage]
           ,[AmendId]
           ,[AmendFlag]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[CategoryId]
           ,[IsApproved]
           ,[Average]
           ,[ApprovedAverage]
           ,[AmendId]
           ,[AmendFlag]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,@batchId from SupplierCategory  where SupplierId = @Id);
           
Delete  SupplierCategory  where SupplierId = @Id

INSERT INTO [delFromVasSupplierNaicsCode]
           ([SupplierId]
           ,[NaicsCode]
           ,[BatchId])
    (select [SupplierId]
           ,[NaicsCode]
           ,@batchId from SupplierNaicsCode  where SupplierId = @Id);
           
Delete  SupplierNaicsCode  where SupplierId = @Id

INSERT INTO delFromVasCertification
           ([Id]
           ,[SupplierId]
           ,[CertifiedAgent]
           ,[CertificationType]
           ,[CertificationNo]
           ,[EffectiveDate]
           ,[ExpirationDate]
           ,[Certificate]
           ,[FaxIn]
           ,[Filename]
           ,[CertificationId]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransactionId]
           ,[Status]
           ,[AutoVerified]
           ,[Classification]
           ,[Contact]
           ,[Phone]
           ,[BatchId])
	(select [Id]
           ,[SupplierId]
           ,[CertifiedAgent]
           ,[CertificationType]
           ,[CertificationNo]
           ,[EffectiveDate]
           ,[ExpirationDate]
           ,[Certificate]
           ,[FaxIn]
           ,[Filename]
           ,[CertificationId]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransactionId]
           ,[Status]
           ,[AutoVerified]
           ,[Classification]
           ,[Contact]
           ,[Phone]
           ,@batchId from Certification  where SupplierId = @Id);

Delete  Certification  where SupplierId = @Id

INSERT INTO [delFromVasSupplierClassification]
           ([SupplierId]
           ,[Classification]
           ,[certified]
           ,[BatchId])
 (select [SupplierId]
           ,[Classification]
           ,[certified]
           ,@batchId from SupplierClassification  where SupplierId = @Id);
           
Delete  SupplierClassification  where SupplierId = @Id
--Delete  SupplierContact  where SupplierId = @Id

INSERT INTO [NYCSCA_VAS].[dbo].[delFromVasSupplierServiceArea]
           ([SupplierId]
           ,[ServiceArea]
           ,[ServiceType]
           ,[BatchId])
    (select [SupplierId]
           ,[ServiceArea]
           ,[ServiceType]
           ,@batchId from SupplierServiceArea where SupplierId = @Id);

Delete  SupplierServiceArea where SupplierId = @Id

INSERT INTO [delFromVasReference]
           ([Id]
           ,[SupplierId]
           ,[Company]
           ,[Name]
           ,[Phone]
           ,[ReferenceType]
           ,[Service]
           ,[ContractValue]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Company]
           ,[Name]
           ,[Phone]
           ,[ReferenceType]
           ,[Service]
           ,[ContractValue]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from Reference where SupplierId = @Id);
           
Delete  Reference where SupplierId = @Id
INSERT INTO [delFromVasSupplierInsurance]
           ([Id]
           ,[SupplierId]
           ,[Insurance]
           ,[Limit]
           ,[Provider]
           ,[PolicyNumber]
           ,[AdditionalInsured]
           ,[Agent]
           ,[Phone]
           ,[Fax]
           ,[Filename]
           ,[AttachmentId]
           ,[InsuranceId]
           ,[TransactionId]
           ,[Status]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[Company]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[AggregateLimit]
           ,[EffectiveDate]
           ,[ExpirationDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Insurance]
           ,[Limit]
           ,[Provider]
           ,[PolicyNumber]
           ,[AdditionalInsured]
           ,[Agent]
           ,[Phone]
           ,[Fax]
           ,[Filename]
           ,[AttachmentId]
           ,[InsuranceId]
           ,[TransactionId]
           ,[Status]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[Company]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[AggregateLimit]
           ,[EffectiveDate]
           ,[ExpirationDate]
           ,@batchId from SupplierInsurance where SupplierId = @Id)

Delete  SupplierInsurance where SupplierId = @Id

INSERT INTO [delFromVasSupplierSicCode]
           ([SupplierId]
           ,[SicCode]
           ,[BatchId])
    (select [SupplierId]
           ,[SicCode]
           ,@batchId from SupplierSicCode where SupplierId = @Id);
           
Delete  SupplierSicCode where SupplierId = @Id

INSERT INTO [delFromVasSupplierWorkflow]
           ([Id]
           ,[SupplierId]
           ,[WorkflowId]
           ,[TransactionId]
           ,[WorkflowType]
           ,[BusinessUnitId]
           ,[TransferredFlag]
           ,[BatchId])
    select [Id]
           ,[SupplierId]
           ,[WorkflowId]
           ,[TransactionId]
           ,[WorkflowType]
           ,[BusinessUnitId]
           ,[TransferredFlag]
           ,@batchId from SupplierWorkflow where SupplierId = @Id;
           
Delete  SupplierWorkflow where SupplierId = @Id

INSERT INTO [delFromVasOwner]
           ([Id]
           ,[SupplierId]
           ,[Name]
           ,[Title]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[Gender]
           ,[Ethnicity]
           ,[Percentage]
           ,[YearsExperience]
           ,[Filename]
           ,[Resume]
           ,[OwnerId]
           ,[ChangeUser]
           ,[Prefix]
           ,[MiddleName]
           ,[DOB]
           ,[SSN]
           ,[RegistrationNumber]
           ,[IsOwner]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[Country]
           ,[State]
           ,[ZipCode]
           ,[StartDate]
           ,[CommencementDate]
           ,[EndDate]
           ,[Description]
           ,[NotarizedCertification]
           ,[TotalAmount]
           ,[PaidAmount]
           ,[NumberOfShares]
           ,[SharesDate]
           ,[HowSharesAcquired]
           ,[CommonOrPreferred]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Name]
           ,[Title]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[Gender]
           ,[Ethnicity]
           ,[Percentage]
           ,[YearsExperience]
           ,[Filename]
           ,[Resume]
           ,[OwnerId]
           ,[ChangeUser]
           ,[Prefix]
           ,[MiddleName]
           ,[DOB]
  ,[SSN]
           ,[RegistrationNumber]
           ,[IsOwner]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[Country]
           ,[State]
           ,[ZipCode]
           ,[StartDate]
           ,[CommencementDate]
           ,[EndDate]
           ,[Description]
           ,[NotarizedCertification]
           ,[TotalAmount]
           ,[PaidAmount]
           ,[NumberOfShares]
           ,[SharesDate]
           ,[HowSharesAcquired]
           ,[CommonOrPreferred]
           ,@batchId from Owner where SupplierId = @Id);
           
Delete  Owner where SupplierId = @Id

INSERT INTO [delFromVasLicense]
           ([Id]
           ,[SupplierId]
           ,[LicenseType]
           ,[LicenseAgent]
           ,[LicenseNo]
           ,[ExpirationDate]
           ,[Filename]
           ,[Certificate]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[FaxIn]
           ,[LicenseId]
           ,[PersonnelId]
           ,[Corporation]
           ,[EffectiveDate]
           ,[Name]
           ,[Location]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[LicenseType]
           ,[LicenseAgent]
           ,[LicenseNo]
           ,[ExpirationDate]
           ,[Filename]
           ,[Certificate]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[FaxIn]
           ,[LicenseId]
           ,[PersonnelId]
           ,[Corporation]
           ,[EffectiveDate]
           ,[Name]
           ,[Location]
           ,@batchId from License where supplierId = @Id);
           
Delete	License where supplierId = @Id

INSERT INTO delFromVasGroupMember
           ([GroupId]
           ,[SupplierId]
           ,[BatchId])
    (select  [GroupId]
           ,[SupplierId]
           ,@batchId from GroupMember where SupplierId = @Id);
           
Delete  GroupMember where SupplierId = @Id

INSERT INTO delFromVasSupplierSales
           ([SupplierId]
           ,[Year]
           ,[Amount]
           ,[BatchId])
    (select [SupplierId]
           ,[Year]
           ,[Amount]
           ,@batchId from SupplierSales where SupplierId = @Id);
           
Delete  SupplierSales where SupplierId = @Id

INSERT INTO [delFromVasSupplierAccount]
           ([Id]
           ,[SupplierId]
           ,[DataGridType]
           ,[Title]
           ,[Type]
           ,[BankName]
           ,[Phone]
           ,[Fax]
           ,[Url]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[DataGridType]
           ,[Title]
           ,[Type]
           ,[BankName]
           ,[Phone]
           ,[Fax]
           ,[Url]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierAccount where SupplierId = @Id);
           
Delete  SupplierAccount where SupplierId = @Id

INSERT INTO [delFromVasSupplierApprenticeshipProgram]
           ([Id]
           ,[SupplierId]
           ,[Type]
           ,[ProgramName]
           ,[Number]
           ,[Trade]
           ,[ApprovedTrade]
           ,[Approved]
           ,[ApprovedNumber]
           ,[NumberOfYears]
           ,[VerifyName]
           ,[StartDate]
           ,[EndDate]
           ,[Comments]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Type]
           ,[ProgramName]
           ,[Number]
           ,[Trade]
           ,[ApprovedTrade]
           ,[Approved]
  ,[ApprovedNumber]
           ,[NumberOfYears]
           ,[VerifyName]
           ,[StartDate]
           ,[EndDate]
           ,[Comments]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,@batchId from SupplierApprenticeshipProgram where SupplierId = @Id);
           
Delete	SupplierApprenticeshipProgram where SupplierId = @Id

INSERT INTO [delFromVasSupplierBusinessMixedInfo]
           ([Id]
           ,[SupplierId]
           ,[Type]
           ,[ChangeType]
           ,[LocationType]
           ,[HolderName]
           ,[StartDate]
           ,[EndDate]
           ,[FirmId]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Type]
           ,[ChangeType]
           ,[LocationType]
           ,[HolderName]
           ,[StartDate]
           ,[EndDate]
           ,[FirmId]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierBusinessMixedInfo where SupplierId = @Id);
           
Delete	SupplierBusinessMixedInfo where SupplierId = @Id

INSERT INTO [delFromVasSupplierCertificationAppeal]
           ([Id]
           ,[SupplierId]
           ,[Agency]
           ,[Date]
           ,[ContactName]
           ,[Phone]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Agency]
           ,[Date]
           ,[ContactName]
           ,[Phone]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierCertificationAppeal where SupplierId = @Id);
           
Delete	SupplierCertificationAppeal where SupplierId = @Id

INSERT INTO delFromVasSupplierComment
           ([Id]
           ,[SupplierId]
           ,[Comments]
           ,[Type]
           ,[UserId]
           ,[FileLink]
           ,[FileName]
           ,[AttachmentId]
           ,[CreateDate]
           ,[Response]
           ,[Submitted]
           ,[QuestionIds]
           ,[ChangeDate]
           ,[ChangeUser]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Comments]
           ,[Type]
           ,[UserId]
           ,[FileLink]
           ,[FileName]
           ,[AttachmentId]
           ,[CreateDate]
           ,[Response]
           ,[Submitted]
           ,[QuestionIds]
           ,[ChangeDate]
           ,[ChangeUser]
           ,@batchId from SupplierComment where SupplierId = @Id);
           
Delete	SupplierComment where SupplierId = @Id

INSERT INTO [delFromVasSupplierCredit]
           ([Id]
           ,[SupplierId]
           ,[InstitutionName]
           ,[CreditAmount]
           ,[OwnedAmount]
           ,[OfficerName]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[IsRevolving]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[InstitutionName]
           ,[CreditAmount]
           ,[OwnedAmount]
           ,[OfficerName]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[IsRevolving]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierCredit where SupplierId = @Id);
           
Delete  SupplierCredit where SupplierId = @Id

INSERT INTO [NYCSCA_VAS].[dbo].[delFromVasSupplierDebt]
           ([Id]
           ,[SupplierId]
           ,[Creditor]
           ,[Borrower]
           ,[Type]
           ,[LoanedAmount]
           ,[OwnedAmount]
           ,[Terms]
           ,[GuarantorName]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Creditor]
           ,[Borrower]
           ,[Type]
           ,[LoanedAmount]
           ,[OwnedAmount]
           ,[Terms]
           ,[GuarantorName]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierDebt where SupplierId = @Id);
           
Delete	SupplierDebt where SupplierId = @Id

INSERT INTO [delFromVasSupplierDebtEvent]
           ([Id]
           ,[SupplierId]
           ,[Agency]
           ,[Court]
           ,[Description]
           ,[Status]
           ,[ContactName]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[CaseNumber]
           ,[DocketNumber]
           ,[County]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Agency]
           ,[Court]
           ,[Description]
           ,[Status]
           ,[ContactName]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[CaseNumber]
           ,[DocketNumber]
           ,[County]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierDebtEvent where SupplierId = @Id);
           
Delete	SupplierDebtEvent where SupplierId = @Id

INSERT INTO [delFromVasSupplierDisadvantagedEmployee]
           ([Id]
           ,[SupplierId]
           ,[Name]
           ,[Title]
           ,[Ethnicity]
           ,[Gender]
           ,[EmploymentStartDate]
           ,[EmploymentEndDate]
           ,[ResumeFileName]
           ,[Resume]
           ,[QuestionIds]
           ,[DocumentIds]
           ,[Comment]
           ,[IsVerified]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Name]
           ,[Title]
           ,[Ethnicity]
           ,[Gender]
           ,[EmploymentStartDate]
           ,[EmploymentEndDate]
           ,[ResumeFileName]
           ,[Resume]
           ,[QuestionIds]
           ,[DocumentIds]
           ,[Comment]
           ,[IsVerified]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierDisadvantagedEmployee where SupplierId = @Id);
           
Delete  SupplierDisadvantagedEmployee where SupplierId = @Id

INSERT INTO [delFromVasSupplierFailedContract]
      ([Id]
           ,[SupplierId]
           ,[Agency]
           ,[ContractNumber]
           ,[Description]
           ,[ContactName]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Agency]
           ,[ContractNumber]
           ,[Description]
           ,[ContactName]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierFailedContract where SupplierId = @Id);
           
Delete	SupplierFailedContract where SupplierId = @Id

INSERT INTO [NYCSCA_VAS].[dbo].[delFromVasSupplierGovernAction]
           ([Id]
           ,[SupplierId]
           ,[Agency]
           ,[ContactNumber]
           ,[ActionDescription]
           ,[ContactName]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[ActionDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Application]
           ,[Affiliate]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Agency]
           ,[ContactNumber]
           ,[ActionDescription]
           ,[ContactName]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[ActionDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Application]
           ,[Affiliate]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierGovernAction where SupplierId = @Id);
           
Delete  SupplierGovernAction where SupplierId = @Id

INSERT INTO [delFromVasSupplierInsuranceClaim]
           ([Id]
           ,[SupplierId]
           ,[Type]
           ,[Claimant]
           ,[Amount]
           ,[Insurer]
           ,[Disposition]
           ,[Description]
           ,[StartDate]
           ,[EndDate]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Type]
           ,[Claimant]
           ,[Amount]
           ,[Insurer]
           ,[Disposition]
           ,[Description]
           ,[StartDate]
           ,[EndDate]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierInsuranceClaim where SupplierId = @Id);
           
Delete  SupplierInsuranceClaim where SupplierId = @Id

INSERT INTO [delFromVasSupplierLawAction]
           ([Id]
           ,[SupplierId]
           ,[Type]
           ,[Court]
           ,[Nature]
           ,[IdType]
           ,[Name]
           ,[SSN]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[ActionDate]
           ,[Outcome]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Type]
           ,[Court]
           ,[Nature]
           ,[IdType]
           ,[Name]
           ,[SSN]
 ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[ActionDate]
           ,[Outcome]
           ,[QuestionIds]
           ,[PersonnelIds]
     ,[DocumentIds]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from  SupplierLawAction where SupplierId = @Id);
           
Delete	SupplierLawAction where SupplierId = @Id

INSERT INTO [delFromVasSupplierLawsuit]
           ([Id]
           ,[SupplierId]
           ,[CaptionOrAction]
           ,[PlaintiffOrDefendant]
           ,[Court]
           ,[DocketNumber]
           ,[ActionDate]
           ,[Outcome]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[IndexNumber]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select[Id]
           ,[SupplierId]
           ,[CaptionOrAction]
           ,[PlaintiffOrDefendant]
           ,[Court]
           ,[DocketNumber]
           ,[ActionDate]
           ,[Outcome]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[IndexNumber]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierLawsuit where SupplierId = @Id)
           
Delete  SupplierLawsuit where SupplierId = @Id

INSERT INTO [delFromVasSupplierOSHAStatistics]
           ([SupplierId]
           ,[Year]
           ,[NumberOfSerious]
           ,[NumberOfWillful]
           ,[NumberOfRepeat]
           ,[NumberOfFailure]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [SupplierId]
           ,[Year]
           ,[NumberOfSerious]
           ,[NumberOfWillful]
           ,[NumberOfRepeat]
           ,[NumberOfFailure]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierOSHAStatistics where SupplierId = @Id);
           
Delete	SupplierOSHAStatistics where SupplierId = @Id

INSERT INTO [delFromVasSupplierPayment]
           ([Id]
           ,[SupplierId]
           ,[ReceiverName]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[LoanedAmount]
           ,[PaidAmount]
           ,[Reason]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
	(select [Id]
           ,[SupplierId]
           ,[ReceiverName]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[LoanedAmount]
           ,[PaidAmount]
           ,[Reason]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierPayment where SupplierId = @Id);
           
Delete  SupplierPayment where SupplierId = @Id

INSERT INTO [delFromVasSupplierProject]
           ([Id]
           ,[SupplierId]
           ,[Type]
           ,[CategoryIds]
           ,[Agency]
           ,[Contractor]
           ,[Name]
           ,[BoroughId]
           ,[ContractNumber]
           ,[ContractAmount]
           ,[PrimeOrSub]
           ,[StartDate]
           ,[EndDate]
           ,[RepresentativeName]
           ,[RepresentativeTitle]
           ,[RepresentativePhone]
           ,[RepresentativeExtension]
           ,[RepresentativeCellPhone]
           ,[RepresentativeFax]
           ,[RepresentativeEmail]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[Description]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[Ongoing]
           ,[IsVerified]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Type]
           ,[CategoryIds]
           ,[Agency]
           ,[Contractor]
           ,[Name]
           ,[BoroughId]
           ,[ContractNumber]
           ,[ContractAmount]
           ,[PrimeOrSub]
           ,[StartDate]
           ,[EndDate]
           ,[RepresentativeName]
           ,[RepresentativeTitle]
           ,[RepresentativePhone]
           ,[RepresentativeExtension]
           ,[RepresentativeCellPhone]
           ,[RepresentativeFax]
           ,[RepresentativeEmail]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[Description]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[Ongoing]
           ,[IsVerified]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierProject where SupplierId = @Id);
           
Delete	SupplierProject where SupplierId = @Id

INSERT INTO [NYCSCA_VAS].[dbo].[delFromVasSupplierProjectStatistics]
           ([Id]
           ,[SupplierId]
           ,[Year]
           ,[TotalAmout]
           ,[NumberOfProjects]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Year]
           ,[TotalAmout]
           ,[NumberOfProjects]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,@batchId from SupplierProjectStatistics where SupplierId = @Id);
           
Delete	SupplierProjectStatistics where SupplierId = @Id

INSERT INTO [delFromVasSupplierProperty]
           ([Id]
           ,[SupplierId]
           ,[ParentId]
           ,[PropertyId]
           ,[PropertyValue]
           ,[PropertyDate]
           ,[PropertyText]
           ,[Selected]
           ,[AttachmentId]
           ,[AttachmentName]
           ,[ChangeDate]
           ,[ChangeUser]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[ParentId]
           ,[PropertyId]
           ,[PropertyValue]
           ,[PropertyDate]
           ,[PropertyText]
           ,[Selected]
           ,[AttachmentId]
           ,[AttachmentName]
           ,[ChangeDate]
           ,[ChangeUser]
           ,@batchId from SupplierProperty where SupplierId = @Id);
           
Delete	SupplierProperty where SupplierId = @Id

INSERT INTO [NYCSCA_VAS].[dbo].[delFromVasSupplierStatus]
           ([SupplierId]
           ,[TypeName]
           ,[Status]
           ,[ChangeDate]
           ,[BatchId])
    (select [SupplierId]
           ,[TypeName]
           ,[Status]
           ,[ChangeDate]
           ,@batchId from SupplierStatus where SupplierId = @Id);
           
Delete  SupplierStatus where SupplierId = @Id

INSERT INTO [delFromVasSupplierSurety]
           ([Id]
           ,[SupplierId]
           ,[IsPrimary]
           ,[Type]
           ,[SuretyName]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[Country]
           ,[ZipCode]
           ,[Phone]
           ,[Fax]
           ,[Agent]
           ,[LetterFileName]
           ,[BondingLetter]
           ,[IsRely]
           ,[OtherSupplierDescription]
           ,[SingleCapacity]
           ,[AggregateCapacity]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[Present]
           ,[OtherFirms]
           ,[ChangeUser]
           ,[EntryDate]
      ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[IsPrimary]
           ,[Type]
           ,[SuretyName]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
          ,[State]
           ,[Country]
           ,[ZipCode]
           ,[Phone]
           ,[Fax]
           ,[Agent]
           ,[LetterFileName]
           ,[BondingLetter]
           ,[IsRely]
           ,[OtherSupplierDescription]
           ,[SingleCapacity]
           ,[AggregateCapacity]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[Present]
           ,[OtherFirms]
           ,[ChangeUser]
           ,[EntryDate]
           ,[ChangeDate]
           ,@batchId from SupplierSurety where SupplierId = @Id);
           
Delete  SupplierSurety where SupplierId = @Id

INSERT INTO [delFromVasSupplierUnethicalPractice]
           ([Id]
           ,[SupplierId]
           ,[Description]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Description]
           ,[StartDate]
           ,[EndDate]
           ,[QuestionIds]
           ,[PersonnelIds]
           ,[DocumentIds]
           ,[Present]
           ,[ChangeUser]
           ,[ChangeDate]
           ,@batchId from SupplierUnethicalPractice where SupplierId = @Id);
           
Delete	SupplierUnethicalPractice where SupplierId = @Id

INSERT INTO [delFromVasSupplierUnspscCode]
           ([SupplierId]
           ,[UnspscCode]
           ,[BatchId])
    (select [SupplierId]
           ,[UnspscCode]
           ,@batchId from SupplierUnspscCode where SupplierId = @Id);
           
Delete  SupplierUnspscCode where SupplierId = @Id

INSERT INTO [delFromVasSupplierVersion]
           ([Id]
           ,[SupplierId]
           ,[VersionId]
           ,[Version]
           ,[VersionYear]
           ,[ApprovedDate]
           ,[ApprovedUser]
           ,[EffectiveDate]
           ,[ExpirationDate]
           ,[Status]
           ,[IsLocked]
           ,[ChangeDate]
           ,[ChangeUser]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[VersionId]
           ,[Version]
           ,[VersionYear]
           ,[ApprovedDate]
           ,[ApprovedUser]
           ,[EffectiveDate]
           ,[ExpirationDate]
           ,[Status]
           ,[IsLocked]
           ,[ChangeDate]
           ,[ChangeUser]
           ,@batchId from SupplierVersion where SupplierId = @Id);
           
Delete  SupplierVersion where SupplierId = @Id

INSERT INTO [delFromVasSupplierWorkflow]
           ([Id]
           ,[SupplierId]
           ,[WorkflowId]
           ,[TransactionId]
           ,[WorkflowType]
           ,[BusinessUnitId]
           ,[TransferredFlag]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[WorkflowId]
           ,[TransactionId]
           ,[WorkflowType]
           ,[BusinessUnitId]
           ,[TransferredFlag]
           ,@batchID from SupplierWorkflow where SupplierId = @Id);
           
Delete	SupplierWorkflow where SupplierId = @Id

INSERT INTO [delFromVasSupplierVendex]
           ([Id]
           ,[SupplierId]
           ,[HasAffiliate]
           ,[HasKeyPeople]
           ,[FirmCautions]
           ,[AffiliateCautions]
           ,[KeyPeopleCautions]
           ,[FirmMu]
           ,[AffiliateMu]
           ,[KeyPeopleMu]
           ,[FirmWarrants]
           ,[AffiliateWarrants]
           ,[KeyPeopleWarrants]
           ,[FirmJobs]
           ,[AffiliateJobs]
           ,[FirmJobsOmitted]
           ,[AffiliateJobsOmitted]
           ,[Details]
           ,[Approved]
       ,[CurrentTaxStatus]
           ,[CautionFileName]
           ,[CautionAttachmentId]
           ,[MuFileName]
           ,[MuAttachmentId]
           ,[TaxFileName]
           ,[TaxAttachmentId]
           ,[ChangeUser]
   ,[ChangeDate]
           ,[Type]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[HasAffiliate]
           ,[HasKeyPeople]
           ,[FirmCautions]
           ,[AffiliateCautions]
           ,[KeyPeopleCautions]
           ,[FirmMu]
           ,[AffiliateMu]
           ,[KeyPeopleMu]
           ,[FirmWarrants]
           ,[AffiliateWarrants]
           ,[KeyPeopleWarrants]
           ,[FirmJobs]
           ,[AffiliateJobs]
           ,[FirmJobsOmitted]
           ,[AffiliateJobsOmitted]
           ,[Details]
           ,[Approved]
           ,[CurrentTaxStatus]
           ,[CautionFileName]
           ,[CautionAttachmentId]
           ,[MuFileName]
           ,[MuAttachmentId]
           ,[TaxFileName]
           ,[TaxAttachmentId]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[Type]
           ,@batchId from SupplierVendex where supplierId=@Id);
           
Delete	SupplierVendex where supplierId=@Id

INSERT INTO [delFromVasSupplierChecklist]
           ([Id]
           ,[SupplierId]
           ,[CheckListId]
           ,[CheckListType]
           ,[IsApproved]
           ,[AuthorityName]
           ,[AuthorityNumber]
           ,[AuthorityDate]
           ,[AuthorityBy]
           ,[StatusType]
           ,[Status]
           ,[ChangeDate]
           ,[ChangeUser]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[CheckListId]
           ,[CheckListType]
           ,[IsApproved]
           ,[AuthorityName]
           ,[AuthorityNumber]
           ,[AuthorityDate]
           ,[AuthorityBy]
           ,[StatusType]
           ,[Status]
           ,[ChangeDate]
           ,[ChangeUser]
           ,@batchId from SupplierChecklist where supplierid=@Id);
           
Delete  SupplierChecklist where supplierid=@Id

INSERT INTO [delFromVasSupplierReport]
           ([Id]
           ,[SupplierId]
           ,[ReportTitle]
           ,[ReportComment]
           ,[ReportText]
           ,[BuyerId]
           ,[CreateDate]
           ,[ChangeUser]
           ,[FileName]
           ,[AttachmentId]
           ,[ChangeDate]
           ,[Type]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[ReportTitle]
           ,[ReportComment]
           ,[ReportText]
           ,[BuyerId]
           ,[CreateDate]
           ,[ChangeUser]
           ,[FileName]
           ,[AttachmentId]
           ,[ChangeDate]
           ,[Type]
           ,@batchId from  SupplierReport where supplierId= @Id);
           
Delete	SupplierReport where supplierId= @Id


INSERT INTO [delFromVasSupplierStaticQualification]
           ([Id]
           ,[SupplierId]
           ,[V_SD_PREQ_RCVD]
           ,[V_SD_ADDL_SENT]
           ,[V_SD_ADDL_RCVD]
           ,[V_SD_ADDL_SENT2]
           ,[V_SD_ADDL_RCVD2]
           ,[V_SD_SENT_IG]
           ,[V_C_APPR_IG]
           ,[V_SD_APPR_IG]
           ,[V_SD_PREQUAL_FROM]
           ,[V_SD_PREQUAL_TO]
           ,[V_B_DENIED]
           ,[V_SD_FINANCE_CHECK]
           ,[V_C_FINANCE_APPR]
           ,[V_M_MAX_BOND]
           ,[V_M_MAX_SINGLE_BOND]
           ,[V_SD_DB_CHECK]
           ,[V_SD_REF_CHECK]
           ,[V_SD_VENDEX_CHECK]
           ,[V_C_VENDEX_APPR]
           ,[V_M_EXP_RANGE_1]
           ,[V_M_EXP_RANGE_2]
           ,[V_SD_NOTICE_LTR]
           ,[V_m_ceiling_amt]
           ,[V_sd_fin_statement]
           ,[V_c_appl_withdrawn]
           ,[V_c_adm_closed]
           ,[V_SD_EMAIL_SENT]
           ,[V_C_APPR_apprent_program]
           ,[V_cd_action_date]
           ,[V_cd_reopen_date]
           ,[V_b_predenied]
           ,[V_SD_TO_REVIEWER]
           ,[V_C_REVIEWER_ID]
           ,[V_c_under_million]
           ,[V_SD_TO_DIRECTOR]
           ,[IsImported]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
   ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[V_SD_PREQ_RCVD]
           ,[V_SD_ADDL_SENT]
           ,[V_SD_ADDL_RCVD]
           ,[V_SD_ADDL_SENT2]
           ,[V_SD_ADDL_RCVD2]
           ,[V_SD_SENT_IG]
           ,[V_C_APPR_IG]
           ,[V_SD_APPR_IG]
           ,[V_SD_PREQUAL_FROM]
           ,[V_SD_PREQUAL_TO]
           ,[V_B_DENIED]
           ,[V_SD_FINANCE_CHECK]
           ,[V_C_FINANCE_APPR]
           ,[V_M_MAX_BOND]
           ,[V_M_MAX_SINGLE_BOND]
           ,[V_SD_DB_CHECK]
           ,[V_SD_REF_CHECK]
           ,[V_SD_VENDEX_CHECK]
           ,[V_C_VENDEX_APPR]
           ,[V_M_EXP_RANGE_1]
           ,[V_M_EXP_RANGE_2]
           ,[V_SD_NOTICE_LTR]
           ,[V_m_ceiling_amt]
           ,[V_sd_fin_statement]
           ,[V_c_appl_withdrawn]
           ,[V_c_adm_closed]
           ,[V_SD_EMAIL_SENT]
           ,[V_C_APPR_apprent_program]
           ,[V_cd_action_date]
           ,[V_cd_reopen_date]
           ,[V_b_predenied]
           ,[V_SD_TO_REVIEWER]
           ,[V_C_REVIEWER_ID]
           ,[V_c_under_million]
           ,[V_SD_TO_DIRECTOR]
           ,[IsImported]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,@batchId from SupplierStaticQualification where supplierid=@Id);
           
Delete  SupplierStaticQualification where supplierid=@Id

INSERT INTO [delFromVasSupplierStaticCertification]
           ([Id]
           ,[SupplierId]
           ,[V_c_eeo_type]
           ,[V_c_dw_code]
           ,[V_sd_dw_date]
           ,[V_SD_APPL_DATE]
           ,[V_sd_info_letter_sent_1]
           ,[V_sd_info_letter_received_1]
           ,[V_sd_info_letter_sent_2]
           ,[V_sd_info_letter_received_2]
           ,[V_sd_cert_date]
           ,[V_sd_recert_date]
           ,[V_sd_recert_notice_send]
           ,[V_sd_exp_date]
           ,[V_vc_dw_note]
           ,[IsImported]
           ,[IsApplied]
           ,[IsRecommendedByMWBE]
           ,[IsRecommendedBySupervisingAnalyst]
           ,[IsRecommendedByDirector]
           ,[ChangeDate]
           ,[ChangeUser]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[RecertTransferredFlag]
           ,[RecertTransferredDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[V_c_eeo_type]
           ,[V_c_dw_code]
           ,[V_sd_dw_date]
           ,[V_SD_APPL_DATE]
           ,[V_sd_info_letter_sent_1]
           ,[V_sd_info_letter_received_1]
           ,[V_sd_info_letter_sent_2]
           ,[V_sd_info_letter_received_2]
           ,[V_sd_cert_date]
           ,[V_sd_recert_date]
           ,[V_sd_recert_notice_send]
           ,[V_sd_exp_date]
           ,[V_vc_dw_note]
           ,[IsImported]
           ,[IsApplied]
           ,[IsRecommendedByMWBE]
           ,[IsRecommendedBySupervisingAnalyst]
           ,[IsRecommendedByDirector]
           ,[ChangeDate]
           ,[ChangeUser]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[RecertTransferredFlag]
           ,[RecertTransferredDate]
           ,@batchId from SupplierStaticCertification where supplierid=@Id);
           
Delete  SupplierStaticCertification where supplierid=@Id

INSERT INTO [delFromVasResponse]
           ([Id]
           ,[SectionId]
           ,[ParticipantId]
           ,[QuestionId]
           ,[AnswerId]
           ,[Selected]
           ,[ResponseText]
           ,[AttachmentId]
           ,[AttachmentName]
           ,[ChangeDate]
           ,[ChangeUser]
           ,[BatchId])
    (select [Id]
           ,[SectionId]
           ,[ParticipantId]
           ,[QuestionId]
           ,[AnswerId]
           ,[Selected]
           ,[ResponseText]
           ,[AttachmentId]
           ,[AttachmentName]
           ,[ChangeDate]
           ,[ChangeUser]
           ,@batchId from Response where ParticipantId = @Id);           

Delete  Response where ParticipantId = @Id

INSERT INTO [delFromVasBuyerComment]
           ([Id]
           ,[SupplierId]
           ,[BuyerId]
           ,[ReferenceId]
           ,[ReferenceType]
           ,[Comments]
           ,[CreateDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[BuyerId]
           ,[ReferenceId]
           ,[ReferenceType]
           ,[Comments]
           ,[CreateDate]
           ,@batchId from BuyerComment where SupplierId = @Id);
           
Delete  BuyerComment where SupplierId = @Id

INSERT INTO [delFromVasService]
           ([Id]
           ,[SupplierId]
           ,[Name]
           ,[Description]
           ,[Filename]
           ,[Picture]
           ,[ServiceId]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[Name]
           ,[Description]
           ,[Filename]
           ,[Picture]
           ,[ServiceId]
           ,@batchId from [Service] where SupplierId = @Id);
           
Delete  [Service] where SupplierId = @Id

INSERT INTO [delFromVasSupplier]
           ([Id]
           ,[SupplierType]
           ,[Company]
           ,[TradeNames]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[Url]
           ,[BusinessType]
           ,[LegalStructure]
           ,[FederalId]
           ,[StateIncorporation]
           ,[StateSalesTaxId]
           ,[SalesTaxState]
           ,[YearEstablished]
           ,[EmployeeTotal]
           ,[InsuranceCarrier]
           ,[DbNum]
           ,[PaymentTerm]
           ,[Description]
           ,[Gender]
           ,[Ethnicity]
           ,[IsCertified]
           ,[HasOnlineCatalog]
           ,[HasOnlineSell]
           ,[HasEdiCapable]
           ,[AcceptCreditCard]
           ,[CurrentSupplier]
           ,[AnnualSales]
           ,[CurrentContact]
           ,[CurrentPhone]
           ,[CurrentExtension]
           ,[CurrentLocation]
           ,[HasSupplierDiversityProgram]
           ,[IsPublicTraded]
           ,[PrimaryCategoryId]
           ,[CcrListed]
           ,[CageCode]
           ,[PreparerName]
           ,[PreparerPhone]
           ,[PreparerEmail]
           ,[ApplyUser]
           ,[ApplyDate]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[Status]
           ,[Password]
           ,[InternalVendorId]
           ,[Logo]
           ,[Picture]
           ,[SupplierId]
           ,[PaymentMethod]
           ,[Currency]
           ,[DiscountTerm]
           ,[ParentId]
           ,[UserName]
           ,[ParentDuns]
           ,[SupplierStatus]
           ,[QualSubmittedDate]
           ,[CertSubmittedDate]
           ,[QualifiedDate]
           ,[CertifiedDate]
           ,[Filename]
           ,[AttachmentId]
           ,[VASId]
           ,[LimitedListVettingDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[EEOMasterTransferredFlag]
           ,[EEOMasterTransferredDate]
           ,[REVSTATUSTransferredFlag]
           ,[REVSTATUSTransferredDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierType]
           ,[Company]
           ,[TradeNames]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[Url]
           ,[BusinessType]
           ,[LegalStructure]
           ,[FederalId]
           ,[StateIncorporation]
           ,[StateSalesTaxId]
           ,[SalesTaxState]
           ,[YearEstablished]
           ,[EmployeeTotal]
           ,[InsuranceCarrier]
           ,[DbNum]
           ,[PaymentTerm]
           ,[Description]
           ,[Gender]
           ,[Ethnicity]
           ,[IsCertified]
           ,[HasOnlineCatalog]
           ,[HasOnlineSell]
           ,[HasEdiCapable]
           ,[AcceptCreditCard]
           ,[CurrentSupplier]
           ,[AnnualSales]
           ,[CurrentContact]
           ,[CurrentPhone]
           ,[CurrentExtension]
           ,[CurrentLocation]
           ,[HasSupplierDiversityProgram]
           ,[IsPublicTraded]
           ,[PrimaryCategoryId]
           ,[CcrListed]
           ,[CageCode]
           ,[PreparerName]
           ,[PreparerPhone]
           ,[PreparerEmail]
           ,[ApplyUser]
           ,[ApplyDate]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[Status]
           ,[Password]
           ,[InternalVendorId]
           ,[Logo]
           ,[Picture]
           ,[SupplierId]
           ,[PaymentMethod]
           ,[Currency]
           ,[DiscountTerm]
           ,[ParentId]
           ,[UserName]
           ,[ParentDuns]
           ,[SupplierStatus]
           ,[QualSubmittedDate]
           ,[CertSubmittedDate]
           ,[QualifiedDate]
           ,[CertifiedDate]
           ,[Filename]
           ,[AttachmentId]
           ,[VASId]
           ,[LimitedListVettingDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[EEOMasterTransferredFlag]
           ,[EEOMasterTransferredDate]
           ,[REVSTATUSTransferredFlag]
           ,[REVSTATUSTransferredDate]
           ,@batchId from Supplier where ParentId = @Id);
           
Delete  Supplier where ParentId = @Id

INSERT INTO delFromVasSupplierDisqualification
           ([Id]
           ,[SupplierId]
           ,[DisqualStartDate]
           ,[DisqualEndDate]
           ,[Comments]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[DisqualStartDate]
           ,[DisqualEndDate]
           ,[Comments]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,@batchId from SupplierDisqualification where SupplierId = @Id);
           
Delete	SupplierDisqualification where SupplierId = @Id

INSERT INTO [delFromVasaspnet_Membership]
           ([ApplicationId]
           ,[UserId]
           ,[Password]
           ,[PasswordFormat]
           ,[PasswordSalt]
           ,[MobilePIN]
           ,[Email]
           ,[LoweredEmail]
           ,[PasswordQuestion]
           ,[PasswordAnswer]
           ,[IsApproved]
           ,[IsLockedOut]
           ,[CreateDate]
           ,[LastLoginDate]
           ,[LastPasswordChangedDate]
           ,[LastLockoutDate]
           ,[FailedPasswordAttemptCount]
           ,[FailedPasswordAttemptWindowStart]
           ,[FailedPasswordAnswerAttemptCount]
           ,[FailedPasswordAnswerAttemptWindowStart]
           ,[Comment]
           ,[BatchId])
    (select [ApplicationId]
           ,[UserId]
           ,[Password]
           ,[PasswordFormat]
           ,[PasswordSalt]
           ,[MobilePIN]
           ,[Email]
           ,[LoweredEmail]
           ,[PasswordQuestion]
           ,[PasswordAnswer]
           ,[IsApproved]
           ,[IsLockedOut]
           ,[CreateDate]
           ,[LastLoginDate]
           ,[LastPasswordChangedDate]
           ,[LastLockoutDate]
           ,[FailedPasswordAttemptCount]
           ,[FailedPasswordAttemptWindowStart]
           ,[FailedPasswordAnswerAttemptCount]
           ,[FailedPasswordAnswerAttemptWindowStart]
           ,[Comment]
           ,@batchId from aspnet_Membership where userid = @supplierid);
           
Delete	aspnet_Membership where userid = @supplierid 


INSERT INTO [delFromVasaspnet_Users]
           ([ApplicationId]
           ,[UserId]
           ,[UserName]
           ,[LoweredUserName]
           ,[MobileAlias]
           ,[IsAnonymous]
           ,[LastActivityDate]
           ,[BatchId])
    (select [ApplicationId]
           ,[UserId]
           ,[UserName]
           ,[LoweredUserName]
           ,[MobileAlias]
           ,[IsAnonymous]
           ,[LastActivityDate]
           ,@batchId from aspnet_Users where userid = @supplierid);
           
Delete	aspnet_Users where userid = @supplierid 

INSERT INTO [delFromVasSupplier]
           ([Id]
           ,[SupplierType]
           ,[Company]
           ,[TradeNames]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[Url]
           ,[BusinessType]
           ,[LegalStructure]
           ,[FederalId]
           ,[StateIncorporation]
           ,[StateSalesTaxId]
           ,[SalesTaxState]
           ,[YearEstablished]
           ,[EmployeeTotal]
           ,[InsuranceCarrier]
           ,[DbNum]
           ,[PaymentTerm]
           ,[Description]
           ,[Gender]
           ,[Ethnicity]
           ,[IsCertified]
           ,[HasOnlineCatalog]
           ,[HasOnlineSell]
           ,[HasEdiCapable]
           ,[AcceptCreditCard]
           ,[CurrentSupplier]
           ,[AnnualSales]
           ,[CurrentContact]
           ,[CurrentPhone]
           ,[CurrentExtension]
           ,[CurrentLocation]
           ,[HasSupplierDiversityProgram]
           ,[IsPublicTraded]
           ,[PrimaryCategoryId]
           ,[CcrListed]
           ,[CageCode]
           ,[PreparerName]
           ,[PreparerPhone]
           ,[PreparerEmail]
           ,[ApplyUser]
           ,[ApplyDate]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[Status]
           ,[Password]
           ,[InternalVendorId]
           ,[Logo]
           ,[Picture]
           ,[SupplierId]
           ,[PaymentMethod]
           ,[Currency]
           ,[DiscountTerm]
           ,[ParentId]
           ,[UserName]
           ,[ParentDuns]
           ,[SupplierStatus]
           ,[QualSubmittedDate]
           ,[CertSubmittedDate]
           ,[QualifiedDate]
           ,[CertifiedDate]
           ,[Filename]
           ,[AttachmentId]
           ,[VASId]
           ,[LimitedListVettingDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[EEOMasterTransferredFlag]
           ,[EEOMasterTransferredDate]
           ,[REVSTATUSTransferredFlag]
           ,[REVSTATUSTransferredDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierType]
           ,[Company]
           ,[TradeNames]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[Url]
           ,[BusinessType]
           ,[LegalStructure]
           ,[FederalId]
           ,[StateIncorporation]
           ,[StateSalesTaxId]
           ,[SalesTaxState]
           ,[YearEstablished]
           ,[EmployeeTotal]
           ,[InsuranceCarrier]
           ,[DbNum]
           ,[PaymentTerm]
           ,[Description]
           ,[Gender]
           ,[Ethnicity]
           ,[IsCertified]
           ,[HasOnlineCatalog]
           ,[HasOnlineSell]
           ,[HasEdiCapable]
           ,[AcceptCreditCard]
           ,[CurrentSupplier]
           ,[AnnualSales]
           ,[CurrentContact]
           ,[CurrentPhone]
           ,[CurrentExtension]
           ,[CurrentLocation]
           ,[HasSupplierDiversityProgram]
           ,[IsPublicTraded]
           ,[PrimaryCategoryId]
           ,[CcrListed]
           ,[CageCode]
           ,[PreparerName]
           ,[PreparerPhone]
           ,[PreparerEmail]
           ,[ApplyUser]
           ,[ApplyDate]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[Status]
           ,[Password]
           ,[InternalVendorId]
           ,[Logo]
           ,[Picture]
           ,[SupplierId]
           ,[PaymentMethod]
,[Currency]
           ,[DiscountTerm]
           ,[ParentId]
           ,[UserName]
           ,[ParentDuns]
           ,[SupplierStatus]
           ,[QualSubmittedDate]
           ,[CertSubmittedDate]
  ,[QualifiedDate]
           ,[CertifiedDate]
           ,[Filename]
           ,[AttachmentId]
           ,[VASId]
           ,[LimitedListVettingDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[EEOMasterTransferredFlag]
           ,[EEOMasterTransferredDate]
           ,[REVSTATUSTransferredFlag]
           ,[REVSTATUSTransferredDate]
           ,@batchId from Supplier where Id = @id);
           
Delete  Supplier where Id = @id

if not exists (select * from supplier where federalId =@federalId)
	begin
		insert into delFromVasVendorContactRole
		([VendorContactId],[VendorContactRoleId],[BatchId] )
		select [VendorContactId],[VendorContactRoleId], @batchId from vendorcontactrole where vendorcontactId in (select id from vendorcontact where vendorId in 	(select id from vendor where federalid=@federalId));
		
		delete from vendorcontactrole where vendorcontactId in (select id from vendorcontact where vendorId in 	(select id from vendor where federalid=@federalId))	
		
		INSERT INTO [delFromVasVendorContact]
           ([Id]
           ,[VendorId]
           ,[ContactType]
           ,[ContactRole]
           ,[FromVendor]
           ,[Name]
           ,[Title]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[ContactId]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[UserName]
           ,[Password]
           ,[Department]
           ,[FirstName]
           ,[LastName]
           ,[ApplyUser]
           ,[ApplyDate]
           ,[Status]
           ,[TimeZone]
           ,[BacthId])
           select [Id]
           ,[VendorId]
           ,[ContactType]
           ,[ContactRole]
           ,[FromVendor]
           ,[Name]
           ,[Title]
           ,[Phone]
           ,[Extension]
           ,[Fax]
           ,[Email]
           ,[ContactId]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[UserName]
           ,[Password]
           ,[Department]
           ,[FirstName]
           ,[LastName]
           ,[ApplyUser]
           ,[ApplyDate]
           ,[Status]
           ,[TimeZone]
           ,@batchId from vendorcontact where vendorid in (select id from vendor where federalid=@federalId);
           
		delete from vendorcontact where vendorid in (select id from vendor where federalid=@federalId)
		
		INSERT INTO [delFromVasVendorComment]
           ([Id]
           ,[VendorId]
           ,[SeqNo]
           ,[Comments]
           ,[Type]
           ,[UserId]
           ,[FileLink]
           ,[FileName]
           ,[AttachmentId]
           ,[CreateDate]
           ,[ChangeDate]
           ,[ChangeUser]
           ,[BatchId])
select [Id]
           ,[VendorId]
           ,[SeqNo]
           ,[Comments]
           ,[Type]
           ,[UserId]
           ,[FileLink]
           ,[FileName]
           ,[AttachmentId]
           ,[CreateDate]
           ,[ChangeDate]
           ,[ChangeUser]
           ,@batchId from vendorcomment where vendorid in (select id from vendor where federalid=@federalId);
           
		delete from vendorcomment where vendorid in (select id from vendor where federalid=@federalId)
		
		INSERT INTO [delFromVasVendor]
           ([Id]
           ,[Company]
           ,[FederalId]
           ,[CurrentSupplierId]
           ,[SupplierVersionId]
           ,[QualificationStatus]
           ,[QualifiedSupplierId]
           ,[QualifiedDate]
           ,[QualifiedExpDate]
           ,[CertificationStatus]
           ,[CertifiedSupplierId]
           ,[CertifiedDate]
           ,[CertifiedExpDate]
           ,[LastBidListDate]
           ,[PreviousLastBidListDate]
           ,[BatchId])
        select [Id]
           ,[Company]
           ,[FederalId]
           ,[CurrentSupplierId]
           ,[SupplierVersionId]
           ,[QualificationStatus]
           ,[QualifiedSupplierId]
       ,[QualifiedDate]
           ,[QualifiedExpDate]
           ,[CertificationStatus]
           ,[CertifiedSupplierId]
           ,[CertifiedDate]
           ,[CertifiedExpDate]
           ,[LastBidListDate]
           ,[PreviousLastBidListDate]
           ,@batchId from vendor where federalId=@federalId;
           
		delete vendor where federalId=@federalId
	end
else
	begin
		update 
			vendor 
		set 
			currentsupplierId = (select top 1 id from supplier where federalid=@federalId order by id desc),
			supplierversionId = (select top 1 id from supplier where federalid=@federalId order by id)
		where 
			federalid=@federalId
		
		update 
			supplierversion
		set
			status = 1, 
			islocked ='N'
		where
			supplierId= (select top 1 id from supplier where federalid=@federalId order by id desc)


		update sv
		set
			sv.versionid= (select top 1 id from supplier where federalid=@federalId order by id)
		from
			supplierversion sv
		inner join
			supplier s
		on
			sv.supplierId = s.Id
		where
			s.federalId = @federalId
	end

declare @rowcount int
set @rowcount = @@RowCount


           

----Auditlog
Insert 
	AuditLog
	(TableName, RecordId, VASId, FieldName, MainId, [Content], transactionid, action, actiontime, username, processedstatus)	
select  
	tablename, id, vasid, FieldName, SupplierId, [Content], @transactionId, [action], @actionTime, @userName, 'U' 
from @temp
----Auditlog

INSERT INTO [delFromVasAuditlog]
           (TableName, RecordId, VASId, FieldName, MainId, [Content], transactionid, action, actiontime, username, processedstatus,batchId)
select  
	tablename, id, vasid, FieldName, SupplierId, [Content], @transactionId, [action], @actionTime, @userName, 'U', @batchId
from @temp


if @@error = 0
	Commit Transaction   
else
	RollBack Transaction
return @rowcount

