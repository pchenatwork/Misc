﻿/*
*********************************************************************************************************************
Procedure:	DeletePlanSubcontractorDocument
Purpose:	Delete a row from PlanSubcontractorDocument table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/1/2010		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeletePlanSubcontractorDocument
	@id int
as

delete PlanSubcontractorDocument
where Id = @id
return @@RowCount

