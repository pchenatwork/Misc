﻿

CREATE procedure [dbo].[CopyPlanSubcontractorDocument]	
	@planSubcontractorId int, 
	@newPlanSubcontractorId int,
	@changeUser nvarchar(50)
as
begin
	insert [PlanSubcontractorDocument]
		( 
			PlanSubcontractorId, 
			Type, 
			Filename, 
			AttachmentId, 
			DocumentId, 
			DocumentNo, 
			ExpirationDate, 
			Description, 
			ChangeUser, 
			ChangeDate
		)
	select   
			@newPlanSubcontractorId, 
			Type, 
			Filename, 
			AttachmentId, 
			DocumentId, 
			DocumentNo, 
			ExpirationDate, 
			Description, 
			@changeUser, 
			GETDATE()
	from
		[PlanSubcontractorDocument]
	where
		PlanSubcontractorId=@planSubcontractorId
	
end



 


































