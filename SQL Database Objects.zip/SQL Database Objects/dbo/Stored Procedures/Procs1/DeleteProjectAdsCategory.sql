﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectAdsCategory
Purpose:	Delete a row from ProjectAdsCategory table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/30/2009		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteProjectAdsCategory
	@id int
as

delete ProjectAdsCategory
where Id = @id
return @@RowCount

