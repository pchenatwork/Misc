﻿/*

*********************************************************************************************************************

Procedure:	DeletePlan

Purpose:	Delete a row from Plan table.

---------------------------------------------------------------------------------------------------------------------

Date			Developer			Notes
==========		===================	===============================

8/1/2010		AECSOFTUSA\Lily			Created

*********************************************************************************************************************
exec DeletePlanSubcontractor @id=9370

select * from PlanSubcontractorpro a
Inner join PlanSubcontractor b on a.Planid=b.Planid and a.FederalId=b.FederalId and a.TaxId=b.TaxId
Where b.id=9367 @id

*/
CREATE procedure [dbo].[DeletePlanSubcontractor]

	@id int
as



begin transaction

begin try

	delete dbo.PlanSubcontractorCategory where PlanSubcontractorId = @id

	delete dbo.PlanSubcontractorCertification where PlanSubcontractorId  = @id

	delete dbo.PlanSubcontractorDocument where PlanSubcontractorId  = @id

	delete dbo.PlanSubcontractorProperty where PlanSubcontractorId  = @id

	delete dbo.PlanSubcontractorComment where PlanSubcontractorId  = @id

	delete dbo.PlanSubcontractorCommunicationComment where PlanSubcontractorId  = @id

	Delete a
	from PlanSubcontractorpro a
	Inner join PlanSubcontractor b on a.Planid=b.Planid and a.FederalId=b.FederalId and a.TaxId=b.TaxId
	Where b.id= @id	
	
	delete dbo.PlanSubcontractor where Id = @id						

	commit transaction

	return @@RowCount

end try

begin catch

	rollback transaction

	return 0

end catch
GO
