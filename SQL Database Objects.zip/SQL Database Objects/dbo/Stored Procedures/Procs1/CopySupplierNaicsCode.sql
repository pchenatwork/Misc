﻿



CREATE procedure [dbo].[CopySupplierNaicsCode]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin
	insert SupplierNaicsCode
		(	
			SupplierId,
			NaicsCode
		)
	select
			@newSupplierId,
			NaicsCode
	from SupplierNaicsCode where supplierId=@supplierId

end




