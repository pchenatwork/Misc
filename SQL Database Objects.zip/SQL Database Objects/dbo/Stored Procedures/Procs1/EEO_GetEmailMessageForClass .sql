﻿-- =============================================
-- Author:		PS
-- Create date: <Create Date,,>
-- Description:	This is to replace email placeholders before sending mails
-- =============================================

/*

	select 
		Name,
		Email,
		v.Company,
		v.FederalId ,vc.vendorid
	from 
		vendorcontact vc, vendor v
	where 
		vc.contacttype='Primary' and 
		vc.vendorid=24574 and 

EEO_GetEmailMessage 'xyz',6418,998
EEO_GetEmailMessage 'EEO_CLASS_CANCELLED',6418,998




select  e.vendorid
	from eeo_vendor e, eeo_workflowhistory wh
	where e.transactionid=wh.transactionid
	and wh.isactive=1


exec [dbo].[EEO_GetEmailMessage] @Name='EEO_CLASS_CANCELLED',@VendorId=17999,@userId=984,@extras='<?xml version="1.0"?>
<ArrayOfExtra xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <Extra Name="className" Value="Financial 2 " />
  <Extra Name="classType" Value="All" />
  <Extra Name="classDate" Value="2/29/2016" />
  <Extra Name="startTime" Value="8:30am" />
  <Extra Name="endTime" Value="9:30am" />
  <Extra Name="classId" Value="109" />
  <Extra Name="emailType" Value="ClassSchCancel" />
</ArrayOfExtra>'

exec [dbo].[EEO_GetEmailMessage] @Name='EEO_CLASS_CANCELLED',@VendorId=17999,@userId=984,@extras='<?xml version="1.0"?>
<ArrayOfExtra xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <Extra Name="className" Value="Financial 2 " />
  <Extra Name="classType" Value="All" />
  <Extra Name="classDate" Value="2/29/2016" />
  <Extra Name="startTime" Value="8:30am" />
  <Extra Name="endTime" Value="9:30am" />
  <Extra Name="classId" Value="109" />
  <Extra Name="emailType" Value="ClassSchCancel" />
</ArrayOfExtra>'

Select * from EEO_CLASSES_SCHE where C_CLASS_ID=35 and SD_CLASS_DATE !='11/15/2006' and SD_CLASS_DATE >GETDATE()

*/

CREATE PROCEDURE [dbo].[EEO_GetEmailMessageForClass ] 
	-- Add the parameters for the stored procedure here
	@Name varchar(100),
	@VendorId int,
	@userId int,
	@extras varchar(max)=null
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	declare @body varchar(8000)
	declare @fromEmail varchar(400)
	declare @fromName varchar(400)
	declare @toEmail varchar(400)
	declare @toName varchar(400)
	declare @Subject varchar(400)
	declare @ccEmail varchar(400)
	declare @bccEmail varchar(400)
	declare @workflowcomments varchar(1000)
	declare @VendorPrimaryContactName varchar(100)
	declare @vendorPrimaryContactEmail varchar(100)
	declare @vendorCompany varchar(200)
	declare @vendorFedId varchar(20)

	Declare @ADMINEMAIL varchar(750)
	Declare @APPEALSLINK varchar(750)
	Declare @COMPANY varchar(750)
	Declare @EXTERNALAPPOINTMENTSLINK varchar(750)
	Declare @EXTERNALCLASSLINK varchar(750)
	Declare @EXTERNALDOCSLINK varchar(750)
	Declare @ScopeBCMBaselineAssessment varchar(750)
	Declare @ToEmail1 varchar(750)
	declare @hdoc		int
	declare @className nvarchar(50)
	declare @classType nvarchar(50)
	declare @classDate nvarchar(50)
	declare @startTime nvarchar(50)	
	declare @endTime nvarchar(50)
	declare @schedule_Rows nvarchar(max)
	declare @classId nvarchar(50)
	declare @classRow nvarchar(50)
	
	select 
		@body=body ,
		@fromEmail=fromEmail,
		@fromName=FromName,
		@toEmail=ToEmail,
		@toName=ToName,
		@subject=[Subject],
		@ccEmail=CcEmail,
		@bccEmail=bccEmail

	from 
		emailmessage where name=@Name
	--table containing values to be replaced
	create table #Replace 
	(
		StringToReplace varchar(max) not null --primary key clustered
		,ReplacementString varchar(max) not null    
	)


	select 
		@VendorPrimaryContactName=Name,
		@VendorPrimaryContactEmail=Email,
		@vendorCompany=v.Company,
		@vendorFedId=v.FederalId 
	from 
		vendorcontact vc, vendor v
	where 
		vc.vendorid=@Vendorid and vc.contacttype='Primary'
		and vc.VendorId=v.id


	--insert into #Replace values('$ADMINEMAIL$','nycsca_do_business@nycsca.org')
	--insert into #Replace values('$COMPANY$','NYCSCA')
	--insert into #Replace values('$DATE$',GetDate())
	--insert into #Replace values('$EXTERNALCLASSLINK$','<a href=''http://scavasqa01.nycsca.org/EEO/External/MentorEx/Classes''>http://scavasqa01.nycsca.org/EEO/External/MentorEx/Classes </a>') 
	--insert into #Replace values('$EXTERNALDOCSLINK$','<a href=''http://scavasqa01.nycsca.org/EEO/External/MentorEx/Documents''>http://scavasqa01.nycsca.org/EEO/External/MentorEx/Documents</a>') 
	--insert into #Replace values('$APPEALSLINK$','<a href=''http://scavasqa01.nycsca.org/EEO/External/MentorEx/Appeals''>http://scavasqa01.nycsca.org/EEO/External/MentorEx/Appeals</a>') 
	--insert into #Replace values('$EXTERNALAPPOINTMENTSLINK$','<a href=''http://scavasqa01.nycsca.org/EEO/External/MentorEx/Appointments''>http://scavasqa01.nycsca.org/EEO/External/MentorEx/Appointments</a>')
	--insert into #Replace values('$ScopeBCMBaselineAssessment$','<a href=''http://scavasqa01.nycsca.org/EEO/Vendor/BaselineAssessment''>http://scavasqa01.nycsca.org/EEO/Vendor/BaselineAssessment</a>')

	


	Select @ADMINEMAIL=Value from EEO_CONFIG where [key]='ADMINEMAIL'
	Select @COMPANY =Value from EEO_CONFIG where [key]='COMPANY'
	Select @EXTERNALAPPOINTMENTSLINK=Value from EEO_CONFIG where [key]='EXTERNALAPPOINTMENTSLINK'
	Select @EXTERNALCLASSLINK=Value from EEO_CONFIG where [key]='EXTERNALCLASSLINK'
	Select @EXTERNALDOCSLINK=Value from EEO_CONFIG where [key]='EXTERNALDOCSLINK'
	Select @APPEALSLINK =Value from EEO_CONFIG where [key]='APPEALSLINK'
	Select @ScopeBCMBaselineAssessment=Value from EEO_CONFIG where [key]='ScopeBCMBaselineAssessment'
	Select @ToEmail1=Value from EEO_CONFIG where [key]='ToEmail'


	insert into #Replace values('$ADMINEMAIL$',@ADMINEMAIL)
	insert into #Replace values('$COMPANY$',@COMPANY)
	insert into #Replace values('$DATE$',GetDate())
	insert into #Replace values('$EXTERNALCLASSLINK$',@EXTERNALCLASSLINK) 
	insert into #Replace values('$EXTERNALDOCSLINK$',@EXTERNALDOCSLINK) 
	insert into #Replace values('$APPEALSLINK$',@APPEALSLINK) 
	insert into #Replace values('$EXTERNALAPPOINTMENTSLINK$',@EXTERNALAPPOINTMENTSLINK)
	insert into #Replace values('$ScopeBCMBaselineAssessment$',@ScopeBCMBaselineAssessment)

	--Class
	Set @className = ''
	Set @classType = ''
	Set @schedule_Rows = ''
	Set @classDate = ''
	Set @startTime = ''
	Set @endTime = ''
	Set @classRow = ''

	if (@extras!=null or  @extras !='')
		Begin 
		
			EXEC sp_xml_preparedocument @hdoc OUTPUT, @extras
			declare @extra Table
			(
				Name nvarchar(50),
				Value nvarchar(4000)
			)
			INSERT INTO @extra
			(
				Name,
				Value
			)
			SELECT
				Name,
				Value
			FROM OPENXML(@hDoc, '/ArrayOfExtra/Extra', 1)
			WITH
			(
				Name nvarchar(50),
				Value nvarchar(4000)
			)

		
			select @className = Value 
			from @extra
			where Name = 'className'
			select @classType = Value 
			from @extra
			where Name = 'classType'
			select @classDate = Value 
			from @extra
			where Name = 'classDate'
			select @startTime = Value 
			from @extra
			where Name = 'startTime'
			select @endTime = Value 
			from @extra
			where Name = 'endTime'
			select @classRow = Value 
			from @extra
			where Name = 'classRow'
			select @schedule_Rows = Value 
			from @extra
			where Name = 'schedule_Rows'
			Set @classId = ''
			select @classId = Value 
			from @extra
			where Name = 'classId'

																																																if exists(Select * from EEO_CLASSES_SCHE where C_CLASS_ID=@classId and SD_CLASS_DATE !=@classDate and SD_CLASS_DATE >GETDATE())
		begin
				Select (
						CASE 
							WHEN C_CLASS_type=1 THEN 'Preliminary' 
							whEN C_CLASS_type=2 THEN 'Orientation' 
							whEN C_CLASS_type=3 THEN 'Regular' 
							whEN C_CLASS_type=4 THEN 'Advanced' 
							whEN C_CLASS_type=5 THEN 'GradMentor' 
							whEN C_CLASS_type=6 THEN 'Module' 


						END) 
						ClassType,
				
				c.C_CLASS_NAME,s.SD_CLASS_DATE ,s.SD_START_TIME,s.SD_END_TIME,
				ROW_NUMBER() OVER(ORDER BY c.C_CLASS_NAME DESC) AS Row 
				into #t 
				from EEO_CLASSES_SCHE s
				Inner join EEO_CLASSES c on c.C_CLASS_ID=s.C_CLASS_ID
				where s.C_CLASS_ID=@classId and s.SD_CLASS_DATE !=@classDate and s.SD_CLASS_DATE >GETDATE() 

				declare @className1 nvarchar(50)
				declare @classType1 nvarchar(50)
				declare @classDate1 nvarchar(50)
				declare @startTime1 nvarchar(50)	
				declare @endTime1 nvarchar(50)
				Declare @i int,@icount int
				set @i=1
				Select @icount =count(*) from #t

				--Select @icount as count 


				WHILE @I <= @icount
				Begin
					Select	@className1=C_CLASS_NAME, 
							@classDate1= convert(varchar(10),SD_CLASS_DATE,101),
							@startTime1=SD_START_TIME,
							@endTime1=SD_END_TIME,
							@ClassType1=ClassType
					from	#t 
					where	[row]=@i 

					Set @schedule_Rows='<tr><td width="200" valign="top" style="width:119.7pt;border:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt">' +
						'<p class="MsoNormal"><span style="color:#1F497D">' + @classType1 + '<o:p></o:p></span></p>' +
						'</td>' +
						'<td width="200" valign="top" style="width:119.7pt;border:solid windowtext 1.0pt;border-left:none;padding:0in 5.4pt 0in 5.4pt">' +
						'<p class="MsoNormal"><span style="color:#1F497D">'
							+ @className1 +
						'<o:p></o:p></span></p>' +
						'</td>' +
						'<td width="200" valign="top" style="width:119.7pt;border:solid windowtext 1.0pt;border-left:none;padding:0in 5.4pt 0in 5.4pt">' +
						'<p class="MsoNormal"><span style="color:#1F497D">'
						+ @classDate1 +
						'<o:p></o:p></span></p>' +
						'</td>'+
						'<td width="200" valign="top" style="width:119.7pt;border:solid windowtext 1.0pt;border-left:none;padding:0in 5.4pt 0in 5.4pt"> '+
						'<p class="MsoNormal"><span style="color:#1F497D">'
						+@startTime1 +' - '+ @endTime1 +
						'<o:p></o:p></span></p>'+
						'</td></tr>'
					set @i=@I+1
				End
				drop table #t
			End
			--insert into #Replace values('$SCHEDULE_ROWS',@schedule_Rows)
			insert into #Replace values('$EEO_CLASSES_C_CLASS_NAME$',isnull(@className,''))
			insert into #Replace values('$EEO_CLASSES_C_CLASS_TYPE$',isnull(@classType1,''))
			insert into #Replace values('$EEO_CLASSES_SCHE_SD_CLASS_DATE$',isnull(@classDate,''))
			insert into #Replace values('$EEO_CLASSES_SCHE_SD_START_TIME$',isnull(@startTime,''))
			insert into #Replace values('$EEO_CLASSES_SCHE_SD_END_TIME$',isnull(@endTime,''))
			insert into #Replace values('$classRow$',@classRow)
			insert into #Replace values('$SCHEDULE_ROWS',@schedule_Rows)
		End
		
		
		
	--Vendor
	insert into #Replace values('$VENDORPRIMARYCONTACTEMAIL$',@VendorPrimaryContactEmail)
	insert into #Replace values('$VENDORPRIMARYCONTACT$',@VendorPrimaryContactName)
	insert into #Replace values('$VENDORCOMPANY$',@vendorCompany)
	insert into #Replace values('$FEDERALID$',@vendorCompany)
	
	set @workflowcomments=' '
	select  @workflowcomments=isnull(wh.comments ,' ')
	from eeo_vendor e, eeo_workflowhistory wh
	where e.vendorid=@vendorid
	and e.transactionid=wh.transactionid
	and wh.isactive=1
	
	insert into #Replace values('$WORKFLOWCOMMENTS$',@workflowcomments)
	
	/*
	
	insert into #Replace values('$MAJORITYOWNER$','')
	
	
	insert into #Replace values('$SUPPLIERPHYSICALADDRESS$','')

	insert into #Replace values('$SUPPLIERPHYSICALADDRESS2$','')
	insert into #Replace values('$SUPPLIERPHYSICALCITY$','')
	insert into #Replace values('$SUPPLIERPHYSICALSTATE$','')
	insert into #Replace values('$SUPPLIERPHYSICALZIP$','')

	insert into #Replace values('$SUPPLIERPHYSICALCOUNTRY$','')
	insert into #Replace values('$FEDERALID$','')
	insert into #Replace values('$QUALIFICATIONTYPE$','')

	insert into #Replace values('$USERFIRSTNAME$','')
	insert into #Replace values('$USERLASTNAME$','')
	insert into #Replace values('$VENDORCOMPANY$','')

	insert into #Replace values('$USEREMAIL$','')
	insert into #Replace values('$USERLASTNAME$','')
	insert into #Replace values('$SUPPLIERCOMPANY$','')
	insert into #Replace values('$USERFULLNAME$','')
	insert into #Replace values('$BDDANALYSTNAME$','')

	insert into #Replace values('$ADMINEMAIL$','')
	insert into #Replace values('$BDDANALYSTEMAIL$','')
	insert into #Replace values('$BDDMANAGEREMAIL$ ','')
	insert into #Replace values('$BDDDIRECTOREMAIL$','')
	insert into #Replace values('$CHIEFPROJECTOFFICEREMAIL$','')
	insert into #Replace values('$CMFIRMEMAILS$','')
	insert into #Replace values('$CONTSPECEMAIL$','')
	insert into #Replace values('$CQUMANAGEREMAIL$','')
	insert into #Replace values('$CQUMANAGEREMAIL$','')
	insert into #Replace values('$CQUDIRECTOREMAIL$','')
	insert into #Replace values('$CQUMANAGERMAIL$','')
	insert into #Replace values('$CQUREVIEWEREMAIL$','')
	insert into #Replace values('$CQUREVIEWEREMAIL$','')
	insert into #Replace values('$CQUMANAGEREMAIL$','')
	insert into #Replace values('$EEOCONTACTEMAIL$','')
	insert into #Replace values('$PRIMARYCONTACTEMAIL$','')
	insert into #Replace values('$PROJECTOFFICEREMAIL$','')
	insert into #Replace values('$REQUESTOREMAIL$','')
	insert into #Replace values('$REVIEWEREMAIL$','')
	insert into #Replace values('$SAFEMAIL$','')
	insert into #Replace values('$SAFPOEMAIL$','') 
	insert into #Replace values('$CQUMANAGEREMAIL$','') 
	insert into #Replace values('$CQUDIRECTOREMAIL','')
	insert into #Replace values('$SAFREVIEWEREMAIL$','')
	insert into #Replace values('$SUPPLIEREMAIL$','')
	insert into #Replace values('$U#USEREMAIL$','')
	insert into #Replace values('$USEREMAIL$','')
	insert into #Replace values('$VENDORCONTACTEMAIL$','')
	
	insert into #Replace values('$CONTSPECEMAIL$','')
	insert into #Replace values('$SUPPLIEREMAIL$','')
	insert into #Replace values('$U#USEREMAIL$','')
	insert into #Replace values('$USEREMAIL$','')

	insert into #Replace values('$VENDORRPRIMARYCONTACT$','')
	insert into #Replace values('$VENDORCONTACTNAME$','')
	insert into #Replace values('$CHIEFPROJECTOFFICERNAME$','')
	insert into #Replace values('$CMFIRMNAME$','')
	insert into #Replace values('$CONTSPECNAME$','')
	insert into #Replace values('$CQUMANAGERNAME$','')
	insert into #Replace values('$CQUREVIEWERNAME$','')
	insert into #Replace values('$EEOCONTACTNAME$','')
	insert into #Replace values('$REQUESTORNAME$','')
	insert into #Replace values('$REVIEWERFIRSTNAME$ $REVIEWERLASTNAME$','')
	insert into #Replace values('$SAFNAME$','')
	insert into #Replace values('$SAFREVIEWERNAME$','')
	insert into #Replace values('$SUPPLIERCOMPANY$','')
	insert into #Replace values('$VENDORCONTACTNAME$','')
	*/
	
	select 
		@body = replace(@body, StringToReplace, ReplacementString),
		@fromEmail=replace(@fromEmail, StringToReplace, ReplacementString),
		@fromName=replace(@fromName, StringToReplace, ReplacementString),
		@toEmail=replace(@toEmail, StringToReplace, ReplacementString),
		@toName=replace(@toName, StringToReplace, ReplacementString),
		@subject=replace(@subject, StringToReplace, ReplacementString),
		@ccEmail=replace(@ccEmail, StringToReplace, ReplacementString),
		@bccEmail=replace(@bccEmail, StringToReplace, ReplacementString)
	from #Replace 

	
	drop table #Replace

	select 
		Id as 'Id',
		Name as 'Name',
		[Description] as 'Description',
		@fromEmail as 'FromEmail',
		@FromName as 'FromName',
		--'pshaiknayeem@nycsca.org;jayaramanv@nycsca.org;VGALPERIN@nycsca.org;' as 'ToEmail',
		@ToEmail1 as 'ToEmail',
		@toName as 'ToName',
		@ccEmail as 'ccEmail',
		@bccEmail as 'bccEmail',
		@Subject as 'Subject',
		@body as 'Body',
		[Type] as 'Type',
		objects as 'Objects',
		Roles as 'Roles',
		[FileName] as 'FileName'
	from 
		emailmessage 
	where 
		name=@Name


Declare @emailHistoryId int
exec @emailHistoryId =[InsertEmailHistory] 'EEO',0,@Name,0,'System',@fromEmail,@ccEmail ,@subject 
exec InsertEmailLog @emailHistoryId,@userId,'Vendor',@toEmail,@body 
	

END
