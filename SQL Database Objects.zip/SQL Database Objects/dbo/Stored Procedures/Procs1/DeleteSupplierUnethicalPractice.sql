﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierUnethicalPractice
Purpose:	Delete a row from SupplierUnethicalPractice table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/10/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierUnethicalPractice
	@id int
as

delete SupplierUnethicalPractice
where Id = @id
return @@RowCount

