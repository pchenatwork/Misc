﻿/*
*********************************************************************************************************************
Procedure:	DeleteSubcontractorContact
Purpose:	Delete a row from SubcontractorContact table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/3/2008		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSubcontractorContact]
	@id int
as

delete SubcontractorContact
where Id = @id
return @@RowCount

