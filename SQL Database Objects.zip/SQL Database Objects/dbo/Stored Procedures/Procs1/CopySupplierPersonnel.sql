﻿
CREATE procedure [dbo].[CopySupplierPersonnel]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin

	insert SupplierPersonnel
		(
			SupplierPersonnelId,
			SupplierId,
			TypeId,
			Status,
			Name,
			Title,
			TitleCategory,
			Phone,
			Extension,
			CellPhone,
			Fax,
			DOB,
			Ethnicity,
			Gender,
			IsOwner,
			IsKeyPerson,
			SSN,
			OwnedPercentage,
			OwnedShares,
			PaidAmount,
			HowSharesAcquired,
			SharesAcquiredOtherReason,
			ContributionAmount,
			CommonOrPreferred,
			SharesAcquiredDate,
			RegistrationNumber,
			EmploymentStartDate,
			EmploymentEndDate,
			CurrentPositionStartDate,
			CurrentPositionEndDate,
			IsHiredByFirm,
			Employer,
			Source,
			AddressLine1,
			AddressLine2,
			City,
			State,
			Country,
			ZipCode,
			CertificationFileName,
			CertificationId,
			ResumeFileName,
			ResumeId,
			Comment,
			IsVerified,
			CopyId, 
			TransferredFlag,
			VASId,
			ChangeDate,
			ChangeUser
		)
	select
			newid(),
			@newSupplierId,
			TypeId,
			Status,
			Name,
			Title,
			TitleCategory,
			Phone,
			Extension,
			CellPhone,
			Fax,
			DOB,
			Ethnicity,
			Gender,
			IsOwner,
			IsKeyPerson,
			SSN,
			OwnedPercentage,
			OwnedShares,
			PaidAmount,
			HowSharesAcquired,
			SharesAcquiredOtherReason,
			ContributionAmount,
			CommonOrPreferred,
			SharesAcquiredDate,
			RegistrationNumber,
			EmploymentStartDate,
			EmploymentEndDate,
			CurrentPositionStartDate,
			CurrentPositionEndDate,
			IsHiredByFirm,
			Employer,
			Source,
			AddressLine1,
			AddressLine2,
			City,
			State,
			Country,
			ZipCode,
			CertificationFileName,
			CertificationId,
			ResumeFileName,
			ResumeId,
			Comment,
			IsVerified,
			Id, 
			TransferredFlag,
			VASId,
			getdate(),
			@changeUser
	from supplierpersonnel where supplierId=@supplierId


	update SupplierPersonnel set Status=0 where supplierid=@newSupplierId and status!=4
	update SupplierPersonnel set IsVerified='N' where supplierid=@newSupplierId 

	--delete inactive keypeople 
	--who does not have any ownership or ownership less than 5%
	--Or had ownership but more than 5 years ago
	Delete from SupplierPersonnel Where IsKeyPerson='Y' and supplierid=@newSupplierId
	and status=4 and (IsOwner ='N' or OwnedPercentage <5 or EmploymentEndDate <Dateadd(Year,-5,getdate()) ) 

	-- INSERT Personnel assigns
	insert into supplierproperty(SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName)
	select 
		@newSupplierId, sp.ParentId, sp.PropertyId, sp.PropertyValue, sp.PropertyDate,  CONVERT(nText, CONVERT(varchar(100), spNew.Id)), sp.Selected, sp.AttachmentId, sp.AttachmentName
	from 
		supplierproperty sp 
		INNER JOIN SupplierPersonnel spNew ON CONVERT(int, CONVERT(varchar(100),sp.PropertyText)) = spNew.CopyId 
			AND sp.supplierid=@supplierId 
			AND spNew.SupplierId = @newSupplierId
	where propertyid BETWEEN 31 AND 41
	
End
