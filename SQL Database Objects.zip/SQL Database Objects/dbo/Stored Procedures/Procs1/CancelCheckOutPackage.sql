﻿/*
*********************************************************************************************************************
Procedure:	CancelCheckOutPackage
Purpose:	Update CheckOut Info in Package table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
08/16/2007		Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CancelCheckOutPackage]
	@id int
as
Update Package
set
	CheckOutId = null,
	CheckOutType = null,
	CheckOutDate = null
where Id = @id
return  @@RowCount



