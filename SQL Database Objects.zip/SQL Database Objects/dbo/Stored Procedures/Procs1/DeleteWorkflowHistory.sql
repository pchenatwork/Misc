﻿




Create procedure DeleteWorkflowHistory
	@id int
as

delete WorkflowHistory
where Id = @id
return @@RowCount






