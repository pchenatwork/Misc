﻿/*
*********************************************************************************************************************
Procedure:	[EEO_LookUp]
Purpose:	Get all lookups 
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
07/14/2015		tmpvj1 venki		Created
*********************************************************************************************************************
Select LookupId,LookupType,Value,Description,ModifiedBy,ModifiedDate 
from EEO_LOOkup

Exec EEO_FindLookUp 20,1,'LookUpType','ASC','CONSULTANT','Cpa','',25
Exec EEO_FindLookUp 20,1,'LookUpType','ASC','','','',23

exec [dbo].[EEO_FindLookUp] @pageSize=20,@pageNumber=0,@orderBy=N'LookUpType',@sequence=N'ASC',@LookupType=N'Will',@value=NULL,@description=NULL,@LookupId=0


exec [dbo].[EEO_FindLookUp] @pageSize=20,@pageNumber=0,@orderBy=N'LookUpType',@sequence=N'ASC',@LookupType=N'GradMentorExtensionReason',@value=NULL,@description=NULL,@LookupId=0

*/
CREATE procedure [dbo].[EEO_FindLookUp]

	@pageSize int,
	@pageNumber int,
	@orderBy nvarchar(50),
	@sequence nvarchar(10),

	@LookupType nvarchar(50)=Null,
	@value nvarchar(50)=Null,
	@description nvarchar(50)=Null,
	@LookupId int=0
	
AS



set nocount on
declare @beginCount int
declare @endCount	int
declare @totalcount int



if @pageNumber>0 
       set @pageNumber=@pageNumber-1

set	@beginCount = @pageNumber * @pageSize + 1
set	@endCount	= @beginCount + @pageSize - 1


Declare @temp1 Table
	(
		OrderId int identity (1,1) Primary Key,
		LookupId	int,
		LookupType	varchar(150),
		Value	varchar(150),
		Description	varchar(100),
		ModifiedBy	varchar(200),
		ModifiedDate	datetime

	)


Insert Into @temp1(LookupId,LookupType,Value,Description,ModifiedBy,ModifiedDate)
select LookupId,LookupType,Value,Description
,(select FirstName+' ' +LastName from [User] where id=ModifiedBy)  as ModifiedBy
,ModifiedDate
from EEO_LOOkup
Where 
(@LookupType is null  or rtrim(LookupType) like '%'+ @LookupType + '%')
and (@value is null or rtrim(value) like '%'+@value+'%')
and (@description is null or rtrim(description) Like '%'+@description+ '%')
and (@LookupId=0 or LookupId=@LookupId)




ORDER BY 
		CASE @sequence 
		WHEN 'ASC' THEN 
			CASE @orderBy 
			When 'LookupType' Then LookupType
			When 'Value' Then Value
			When 'Description' Then Description
			Else ''
			END
		END ASC,

		CASE @sequence 
		WHEN 'DESC' THEN 
			CASE @orderBy 
			When 'LookupType' Then LookupType
			When 'Value' Then Value
			When 'Description' Then Description
			Else ''
			END
		END ASC
	
select @totalcount = count(*) from @temp1


if @pageSize > 0
		Delete from @temp1
		Where OrderId < @beginCount or OrderId > @endCount

select LookupId,LookupType,Value,Description,ModifiedBy,ModifiedDate,@totalcount as totalcount
FROM @temp1 t
order by t.OrderId






--ALTER procedure [dbo].[EEO_FindLookUp]
--@pageSize int,
--	@pageNumber int,
--	@orderBy nvarchar(50),
--	@sequence nvarchar(10),

--	@LookupType nvarchar(50)=Null,
--	@value nvarchar(50)=Null,
--	@description nvarchar(50)=Null,
--	@LookupId int=0
--As

--select 1 as LookupId,'' as LookupType,'' as Value,'' as Description,'' as ModifiedBy,getdate() as ModifiedDate,55 as totalcount
