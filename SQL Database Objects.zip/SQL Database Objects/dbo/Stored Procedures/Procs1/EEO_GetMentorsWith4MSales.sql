﻿

/*
*********************************************************************************************************************
Procedure:	 
Purpose:	 
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/10/2015		Pasha				Created
*********************************************************************************************************************
*/
CREATE PROCEDURE [dbo].[EEO_GetMentorsWith4MSales]
AS

Begin

select s.vendorid from
(
select e.VendorId, sum(sp.TotalAmout) as TotalSales 
from 
	eeo_vendor e
	inner join vendor v on e.VendorId=v.id
	inner join SupplierProjectStatistics sp on v.QualifiedSupplierId=sp.SupplierId
	inner join EEO_MENTOR_GRAD_DETAIL ed on v.id=ed.VENDORID and ed.C_MENTOR_TYPE='MENTOR'
where e.MentorFlag=6
and sp.Year>=year(sd_start_date)
group by e.VendorId
having sum(sp.TotalAmout)>4000000
)s
    
END
