﻿










CREATE procedure [dbo].[CopyPlanSubcontractorProperty]	
	@planSubcontractorId int, 
	@newPlanSubcontractorId int,
	@changeUser nvarchar(50)
as
begin
	insert [PlanSubcontractorProperty]
		( 
			PlanSubcontractorId, 
			PropertyId, 
			PropertyValue, 
			PropertyDate, 
			PropertyText, 
			Selected, 
			AttachmentId, 
			AttachmentName, 
			ChangeDate, 
			ChangeUser
		)
	select   
			@newPlanSubcontractorId, 
			PropertyId, 
			PropertyValue, 
			PropertyDate, 
			PropertyText, 
			Selected, 
			AttachmentId, 
			AttachmentName,  
			GETDATE(),
			@changeUser
	from
		[PlanSubcontractorProperty]
	where
		PlanSubcontractorId=@planSubcontractorId
	
end



 


































