﻿/*
*********************************************************************************************************************
Procedure:	DeleteSubcontractorDocument
Purpose:	Delete a row from SubcontractorDocument table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/12/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteSubcontractorDocument
	@id int
as

delete SubcontractorDocument
where Id = @id
return @@RowCount

