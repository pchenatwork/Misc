﻿

/*
*********************************************************************************************************************
Procedure:	CopyVettingQuestion
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
04/20/2008	Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CopyVettingQuestion]
	@questionId int
AS
Begin

Declare @newQuestionId int
declare @allQuestion table
(
	Id int,
	ParentId int
)
Insert Into @allQuestion ( Id, ParentId ) 
Select Id, ParentId From VettingQuestion 
Where Id = @questionId
While ( @@rowcount > 0 )
Begin
	Insert Into @allQuestion ( Id, ParentId ) 
	Select Id, ParentId From VettingQuestion 
	Where Id Not In ( Select Id From @allQuestion )
	And ParentId In ( Select Id From @allQuestion )
End
declare @tempQuestion Table
(
	Id				int,
	VettingId		int,
	ParentId		int,
	QuestionTypeId	int,
	QuestionText	ntext,
	Sequence		int,
	IsRequired		char(1),
	RowNumber		int,
	MaxLength		int,
	AnswerFormat	nvarchar(50),
	MaxValue		nvarchar(50),
	MinValue		nvarchar(50),
	DefaultValue	nvarchar(500),
	RepeatDirection	nvarchar(50),
	Score			int,
	IsActive		char(1)
)
Insert Into @tempQuestion
(
	Id,VettingId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,
	RowNumber,MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,
	RepeatDirection,Score,IsActive
)
Select 
	Id,VettingId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,
	RowNumber,MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,
	RepeatDirection,Score,IsActive
From VettingQuestion
Where Id in ( Select Id From @allQuestion )
--Insert Question
While Exists( Select * From @tempQuestion )
Begin
	Select @questionId = Id From @tempQuestion Order By ParentId desc, Id desc
	
	Insert Into VettingQuestion
	(
		VettingId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,
		RowNumber,MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,
		RepeatDirection,Score,IsActive
	)
	Select 
		VettingId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,
		RowNumber,MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,
		RepeatDirection,Score,IsActive
	From @tempQuestion
	Where Id = @questionId
	Set @newQuestionId = @@identity
	--Update record in @tempQuestion, make their QuestionId to new QuestionId
	Update @tempQuestion Set ParentId = @newQuestionId Where ParentId = @questionId
	
	Insert Into VettingAnswer(QuestionId,AnswerText,AnswerValue,Sequence,AnswerType,Score)
	Select @newQuestionId,AnswerText,AnswerValue,Sequence,AnswerType,Score
	From VettingAnswer
	Where QuestionId = @questionId

	Delete @tempQuestion Where Id = @questionId
End
return @newQuestionId
End






