﻿CREATE procedure [dbo].[DeleteWorkflowNode]
	@id int
as

delete WorkflowNodeUser
Where WorkflowNodeId in (Select Id From WorkflowNode Where Id = @id or NodeFromId = @id or NodeToId = @id)

delete WorkflowAction
Where WorkflowNodeId in (Select Id From WorkflowNode Where Id = @id or NodeFromId = @id or NodeToId = @id)

delete WorkflowCondition
Where WorkflowNodeId in (Select Id From WorkflowNode Where Id = @id or NodeFromId = @id or NodeToId = @id)

delete WorkflowNode
where Id = @id or NodeFromId = @id or NodeToId = @id

return @@RowCount


