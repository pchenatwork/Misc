﻿


/*
*********************************************************************************************************************
Procedure:	CopyScorecardTemplate
Purpose:	
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/21/2006		Lily Xiong		Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CopyScorecardTemplate]
	@id int
AS
Begin
Declare @newTemplateId int

Insert Into ScorecardTemplate
(
	UserId,
	Type,
	Country,
	Name,
	Description,
	Status,
	CreateDate
)
Select 
	UserId,
	Type,
	Country,
	Name + '_Copy',
	Description,
	0,
	getdate()
From ScorecardTemplate
Where Id = @id

set @newTemplateId = @@identity

-- Insert ScorecardTemplateCategory
Declare @categoryId int
Declare @newCategoryId int
declare @allCategory table
(
	Id int,
	ParentId int
)
Insert Into @allCategory( Id, ParentId ) 
Select Id, ParentId 
From ScorecardTemplateCategory
Where TemplateId = @id
While (@@rowcount>0)
Begin
	Insert Into @allCategory( Id, ParentId ) 
	Select Id, ParentId 
	From ScorecardTemplateCategory 
	Where Id Not In ( Select Id From @allCategory )
	And ParentId In ( Select Id From @allCategory )
End
declare @tempCategory Table
(
	Id		int,
	ParentId	int,
	Name		nvarchar(100),
	Type		nvarchar(10),
	Description nvarchar(500),
	Sequence	int,
	Weight		int
)
Insert Into @tempCategory
(
	Id,ParentId,Name,Type,Description,Sequence,Weight
)
Select 
	Id,ParentId,Name,Type,Description,Sequence,Weight
From ScorecardTemplateCategory
Where Id in ( Select Id From @allCategory )

--Insert ScorecardCategory
While Exists( Select * From @tempCategory )
Begin
	Select @categoryId = Id From @tempCategory Order By Id Desc
	
	Insert Into ScorecardTemplateCategory
	(
		TemplateId,ParentId,Name,Type,Description,Sequence,Weight
	)
	Select 
		@newTemplateId,ParentId,Name,Type,Description,Sequence,Weight
	From @tempCategory
	Where Id = @categoryId

	Set @newCategoryId = @@identity
	--Update record in @tempCategory, make their CategoryId to new CategoryId
	Update @tempCategory Set ParentId = @newCategoryId Where ParentId = @categoryId
	
	Insert Into ScorecardTemplateUserType
	(
		CategoryId, Type, UserType, UserId, Weight
	)
	Select @newCategoryId, Type, UserType, UserId, Weight
	From ScorecardTemplateUserType
	Where CategoryId = @categoryId

	Insert Into ScorecardTemplateQuestion
	(
		TemplateId,CategoryId,Name,Description,Sequence,Weight,Score,IsRequired,ScoreMethod
	)
	Select @newTemplateId,@newCategoryId,Name,Description,Sequence,Weight,Score,IsRequired,ScoreMethod
	From ScorecardTemplateQuestion
	Where CategoryId = @categoryId
	
	Delete @tempCategory Where Id = @categoryId
End

return @newTemplateId

End





