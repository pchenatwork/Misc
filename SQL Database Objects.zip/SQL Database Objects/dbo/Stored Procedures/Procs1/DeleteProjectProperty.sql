﻿



/*
*********************************************************************************************************************
Procedure:	DeleteProjectProperty
Purpose:	Delete a row from ProjectProperty table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
12/17/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteProjectProperty]
	@id int
as

delete ProjectProperty
where Id = @id


return @@RowCount






