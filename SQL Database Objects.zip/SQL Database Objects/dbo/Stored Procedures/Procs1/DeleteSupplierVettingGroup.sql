﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierVettingGroup
Purpose:	Delete a row from SupplierVettingGroup table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
12/2/2007		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierVettingGroup
	@id int
as

delete SupplierVettingGroup
where Id = @id
return @@RowCount

