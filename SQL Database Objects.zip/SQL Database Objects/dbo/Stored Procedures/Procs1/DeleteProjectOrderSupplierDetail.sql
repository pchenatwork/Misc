﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectOrderSupplierDetail
Purpose:	Delete a row from ProjectOrderSupplierDetail table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
5/21/2010		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteProjectOrderSupplierDetail
	@id int
as

delete ProjectOrderSupplierDetail
where Id = @id
return @@RowCount

