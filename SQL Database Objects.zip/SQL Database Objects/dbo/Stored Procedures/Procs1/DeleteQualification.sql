﻿CREATE procedure DeleteQualification
	@id int
as
delete [Action] where RuleId in ( select Id from [rule] where QualificationId = @id )
delete [rule] where QualificationId = @id
delete Qualification
where Id = @id
return @@RowCount


