﻿
/*
*********************************************************************************************************************
Procedure:	DeleteSupplier
Purpose:	Delete a row from Supplier table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
05/17/2013		David Kwok		Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSupplierApplicationFromVAS]
	@id int,
	@type nvarchar(50),
	@userName nvarchar(50)=null,
	@batchId uniqueidentifier
	
as

BEGIN Transaction

declare @actionTime  datetime
set @actionTime = getdate()
declare @transactionId int
insert into [Transaction](Type, ActionTime) values ('CMS', @actionTime)
select @transactionId = max(id) from [Transaction]
declare @workflowTransactionId int

if @type='Qual'
	begin
		select 
			@workflowTransactionId = transactionId 
		from 
			supplierworkflow 
		where 
			supplierid=@id   
			and workflowtype='Supplier Prequalification'

		
		INSERT INTO [delFromVasSupplierWorkflow]
           ([Id]
           ,[SupplierId]
           ,[WorkflowId]
           ,[TransactionId]
           ,[WorkflowType]
           ,[BusinessUnitId]
           ,[TransferredFlag]
           ,[BatchId])
		select [Id]
           ,[SupplierId]
           ,[WorkflowId]
           ,[TransactionId]
           ,[WorkflowType]
           ,[BusinessUnitId]
           ,[TransferredFlag]
           ,@batchId 
           from SupplierWorkflow 
           where
           supplierid=@id   
			and workflowtype='Supplier Prequalification'
           
		delete from 
		
			supplierworkflow 
		where 
			supplierid=@id   
			and workflowtype='Supplier Prequalification'

		INSERT INTO [NYCSCA_VAS].[dbo].[delFromVasSupplierStatus]
           ([SupplierId]
           ,[TypeName]
           ,[Status]
           ,[ChangeDate]
           ,[BatchId])
    (select [SupplierId]
           ,[TypeName]
           ,[Status]
           ,[ChangeDate]
           ,@batchId from SupplierStatus 
           where 
			supplierid =@id 
			and typename='Supplier Prequalification');
           
		
		delete from 
			supplierstatus 
		where 
			supplierid =@id 
			and typename='Supplier Prequalification'

		----Auditlog
		Insert 
			AuditLog
			(TableName, RecordId, VASId,  MainId, transactionid, action, actiontime, username, processedstatus)	
		select  
			'SupplierStaticQualification', id, id, SupplierId, @transactionId, 'delete', @actionTime, @userName, 'U' 
		from 
			SupplierStaticQualification
		where
			supplierId=@id
			and transferredflag='1'
		----Auditlog
		
		INSERT INTO [delFromVasAuditlog]
           (TableName, RecordId, VASId,  MainId, transactionid, action, actiontime, username, processedstatus, batchId)	
		select  
			'SupplierStaticQualification', id, id, SupplierId, @transactionId, 'delete', @actionTime, @userName, 'U', @batchId
		from 
			SupplierStaticQualification
		where
			supplierId=@id
			and transferredflag='1'

		INSERT INTO [delFromVasSupplierStaticQualification]
           ([Id]
           ,[SupplierId]
           ,[V_SD_PREQ_RCVD]
           ,[V_SD_ADDL_SENT]
           ,[V_SD_ADDL_RCVD]
           ,[V_SD_ADDL_SENT2]
           ,[V_SD_ADDL_RCVD2]
           ,[V_SD_SENT_IG]
           ,[V_C_APPR_IG]
           ,[V_SD_APPR_IG]
           ,[V_SD_PREQUAL_FROM]
           ,[V_SD_PREQUAL_TO]
           ,[V_B_DENIED]
           ,[V_SD_FINANCE_CHECK]
           ,[V_C_FINANCE_APPR]
           ,[V_M_MAX_BOND]
           ,[V_M_MAX_SINGLE_BOND]
           ,[V_SD_DB_CHECK]
           ,[V_SD_REF_CHECK]
           ,[V_SD_VENDEX_CHECK]
           ,[V_C_VENDEX_APPR]
           ,[V_M_EXP_RANGE_1]
           ,[V_M_EXP_RANGE_2]
           ,[V_SD_NOTICE_LTR]
           ,[V_m_ceiling_amt]
           ,[V_sd_fin_statement]
           ,[V_c_appl_withdrawn]
           ,[V_c_adm_closed]
           ,[V_SD_EMAIL_SENT]
           ,[V_C_APPR_apprent_program]
           ,[V_cd_action_date]
           ,[V_cd_reopen_date]
           ,[V_b_predenied]
           ,[V_SD_TO_REVIEWER]
           ,[V_C_REVIEWER_ID]
           ,[V_c_under_million]
           ,[V_SD_TO_DIRECTOR]
           ,[IsImported]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[V_SD_PREQ_RCVD]
           ,[V_SD_ADDL_SENT]
           ,[V_SD_ADDL_RCVD]
           ,[V_SD_ADDL_SENT2]
           ,[V_SD_ADDL_RCVD2]
           ,[V_SD_SENT_IG]
           ,[V_C_APPR_IG]
           ,[V_SD_APPR_IG]
           ,[V_SD_PREQUAL_FROM]
           ,[V_SD_PREQUAL_TO]
           ,[V_B_DENIED]
           ,[V_SD_FINANCE_CHECK]
           ,[V_C_FINANCE_APPR]
           ,[V_M_MAX_BOND]
           ,[V_M_MAX_SINGLE_BOND]
           ,[V_SD_DB_CHECK]
           ,[V_SD_REF_CHECK]
           ,[V_SD_VENDEX_CHECK]
           ,[V_C_VENDEX_APPR]
           ,[V_M_EXP_RANGE_1]
           ,[V_M_EXP_RANGE_2]
           ,[V_SD_NOTICE_LTR]
           ,[V_m_ceiling_amt]
           ,[V_sd_fin_statement]
           ,[V_c_appl_withdrawn]
           ,[V_c_adm_closed]
           ,[V_SD_EMAIL_SENT]
           ,[V_C_APPR_apprent_program]
           ,[V_cd_action_date]
           ,[V_cd_reopen_date]
           ,[V_b_predenied]
           ,[V_SD_TO_REVIEWER]
           ,[V_C_REVIEWER_ID]
           ,[V_c_under_million]
           ,[V_SD_TO_DIRECTOR]
           ,[IsImported]
           ,[ChangeUser]
           ,[ChangeDate]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,@batchId from SupplierStaticQualification where supplierid=@Id);

		delete from 
			SupplierStaticQualification 
		where 
			supplierid =@id 

		
		INSERT INTO [delFromVasWorkflowHistory]
           ([Id]
           ,[TransactionHeaderId]
           ,[WorkflowId]
           ,[CurrentNodeId]
           ,[ApprovalUserId]
           ,[ApprovalRoleId]
           ,[ApprovalConditionId]
           ,[ApprovalDate]
           ,[PrevHistoryId]
           ,[Status]
           ,[IsActive]
           ,[Comments]
           ,[DateCreated]
           ,[CreatedBy]
           ,[Version]
           ,[CreatedType]
           ,[DelegatorId]
           ,[BatchId])
        (select [Id]
           ,[TransactionHeaderId]
           ,[WorkflowId]
           ,[CurrentNodeId]
           ,[ApprovalUserId]
           ,[ApprovalRoleId]
           ,[ApprovalConditionId]
           ,[ApprovalDate]
           ,[PrevHistoryId]
           ,[Status]
           ,[IsActive]
           ,[Comments]
           ,[DateCreated]
           ,[CreatedBy]
           ,[Version]
           ,[CreatedType]
           ,[DelegatorId]
           ,@batchId from 
			workflowhistory 
		where 
			transactionheaderId = @workflowTransactionId);
		
		delete from 
			workflowhistory 
		where 
			transactionheaderId = @workflowTransactionId

		update 
			supplier 
		set 
			qualsubmitteddate=null 
		where 
			id=@id
	end

--delete cert workflow
if @type='Cert'
	begin
		select 
			@workflowTransactionId = transactionId 
		from 
			supplierworkflow 
		where 
			supplierid=@id   
			and workflowtype='Supplier Certification'

		INSERT INTO [delFromVasSupplierWorkflow]
           ([Id]
           ,[SupplierId]
           ,[WorkflowId]
           ,[TransactionId]
           ,[WorkflowType]
           ,[BusinessUnitId]
           ,[TransferredFlag]
           ,[BatchId])
		select [Id]
           ,[SupplierId]
           ,[WorkflowId]
           ,[TransactionId]
           ,[WorkflowType]
           ,[BusinessUnitId]
           ,[TransferredFlag]
           ,@batchId 
           from SupplierWorkflow 
           where
           supplierid=@id   
			and workflowtype='Supplier Certification'
           
		delete from 
			supplierworkflow 
		where 
			supplierid=@id   
			and workflowtype='Supplier Certification'
		
		INSERT INTO [NYCSCA_VAS].[dbo].[delFromVasSupplierStatus]
           ([SupplierId]
           ,[TypeName]
           ,[Status]
           ,[ChangeDate]
           ,[BatchId])
		(select [SupplierId]
           ,[TypeName]
           ,[Status]
           ,[ChangeDate]
           ,@batchId from SupplierStatus 
           where 
			supplierid =@id 
			and typename='Supplier Certification');
			
		delete from 
			supplierstatus 
		where 
			supplierid =@id 
			and typename='Supplier Certification'

		----Auditlog
		Insert 
			AuditLog
			(TableName, RecordId, VASId,  MainId, transactionid, action, actiontime, username, processedstatus)	
		select  
			'SupplierStaticCertification', id, id, SupplierId, @transactionId, 'delete', @actionTime, @userName, 'U' 
		from 
			SupplierStaticCertification
		where
			supplierId=@id
			and transferredflag='1'
			
		INSERT INTO [delFromVasAuditlog]
           (TableName, RecordId, VASId,  MainId, transactionid, action, actiontime, username, processedstatus, batchId)	
		select  
			'SupplierStaticQualification', id, id, SupplierId, @transactionId, 'delete', @actionTime, @userName, 'U', @batchId
		from 
			SupplierStaticCertification
		where
			supplierId=@id
			and transferredflag='1'


		----Auditlog
		INSERT INTO [delFromVasSupplierStaticCertification]
           ([Id]
           ,[SupplierId]
           ,[V_c_eeo_type]
           ,[V_c_dw_code]
           ,[V_sd_dw_date]
           ,[V_SD_APPL_DATE]
           ,[V_sd_info_letter_sent_1]
           ,[V_sd_info_letter_received_1]
           ,[V_sd_info_letter_sent_2]
           ,[V_sd_info_letter_received_2]
           ,[V_sd_cert_date]
           ,[V_sd_recert_date]
           ,[V_sd_recert_notice_send]
           ,[V_sd_exp_date]
           ,[V_vc_dw_note]
           ,[IsImported]
           ,[IsApplied]
           ,[IsRecommendedByMWBE]
           ,[IsRecommendedBySupervisingAnalyst]
           ,[IsRecommendedByDirector]
           ,[ChangeDate]
           ,[ChangeUser]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[RecertTransferredFlag]
           ,[RecertTransferredDate]
           ,[BatchId])
    (select [Id]
           ,[SupplierId]
           ,[V_c_eeo_type]
           ,[V_c_dw_code]
           ,[V_sd_dw_date]
           ,[V_SD_APPL_DATE]
           ,[V_sd_info_letter_sent_1]
           ,[V_sd_info_letter_received_1]
           ,[V_sd_info_letter_sent_2]
           ,[V_sd_info_letter_received_2]
           ,[V_sd_cert_date]
           ,[V_sd_recert_date]
           ,[V_sd_recert_notice_send]
           ,[V_sd_exp_date]
           ,[V_vc_dw_note]
           ,[IsImported]
           ,[IsApplied]
           ,[IsRecommendedByMWBE]
           ,[IsRecommendedBySupervisingAnalyst]
           ,[IsRecommendedByDirector]
           ,[ChangeDate]
           ,[ChangeUser]
           ,[TransferredFlag]
           ,[TransferredDate]
           ,[RecertTransferredFlag]
           ,[RecertTransferredDate]
           ,@batchId from 
			SupplierStaticCertification 
		where 
			supplierid =@id );
           
		delete from 
			SupplierStaticCertification 
		where 
			supplierid =@id 
	
	INSERT INTO [delFromVasWorkflowHistory]
           ([Id]
           ,[TransactionHeaderId]
           ,[WorkflowId]
           ,[CurrentNodeId]
           ,[ApprovalUserId]
           ,[ApprovalRoleId]
           ,[ApprovalConditionId]
           ,[ApprovalDate]
           ,[PrevHistoryId]
           ,[Status]
           ,[IsActive]
           ,[Comments]
           ,[DateCreated]
           ,[CreatedBy]
           ,[Version]
           ,[CreatedType]
           ,[DelegatorId]
           ,[BatchId])
        (select [Id]
           ,[TransactionHeaderId]
           ,[WorkflowId]
           ,[CurrentNodeId]
           ,[ApprovalUserId]
           ,[ApprovalRoleId]
           ,[ApprovalConditionId]
           ,[ApprovalDate]
           ,[PrevHistoryId]
           ,[Status]
           ,[IsActive]
           ,[Comments]
           ,[DateCreated]
           ,[CreatedBy]
           ,[Version]
           ,[CreatedType]
           ,[DelegatorId]
           ,@batchId from 
			workflowhistory 
		where 
			transactionheaderId = @workflowTransactionId);
			
		delete from 
			workflowhistory 
		where 
			transactionheaderId = @workflowTransactionId

		update 
			supplier 
		set 
			certsubmitteddate=null 
		where 
			id=@id
	end

if @@error = 0
	Commit Transaction   
else
	RollBack Transaction
return @@rowcount
