﻿/*  
*********************************************************************************************************************  
Procedure: DeleteBidderReject  
Purpose: Delete a row from BidderReject table.  
---------------------------------------------------------------------------------------------------------------------  
Date   Developer   Notes  
==========  =================== ===============================  
8/3/2018  NYCSCA\030111   Created  
*********************************************************************************************************************  
*/  
ALTER procedure DeleteBidderRejectByBidderId  
 @id int  
as  
	IF ( SELECT ISNULL(TransferredFlag,0) FROM BidderReject WHERE BidderId = @Id) = 1
	BEGIN
		DECLARE @VasID INT = (SELECT ID FROM BidderReject WHERE BidderID = @Id);
		Exec SP_VAS_AUTOMATIC_AUDITLOG	'BidderReject_CMS'	,@VasID	,@ID	, DEFAULT, DEFAULT, NULL, 'Bid And Award NON TIGGERED Workflow', 'Delete Rejected Bidder', @DeleteActionToCMS = 1;
	END  
	
	delete BidderReject  where BidderId = @id ; 	
	return @@RowCount  
GO