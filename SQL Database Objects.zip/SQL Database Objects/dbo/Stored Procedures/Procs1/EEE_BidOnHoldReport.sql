﻿IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[EEE_BidOnHoldReport]'))
   EXEC('CREATE PROCEDURE [dbo].[EEE_BidOnHoldReport] AS BEGIN SET NOCOUNT ON; END')
GO
/*
*******************************************************************************
Procedure:	 
Purpose:	 
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
07/19/2017      Rulong				Fix bid on hold report, show only current mentor
06/07/2019		PCHEN				Sync with TEST/Comment first created
    1. Completely re-factor for faster query
	2. On-Hold logic revised as
		(1) Current mentor/grad mentor (MentorFlag = 6/7) AND
		(2) Currently NOT Qualified AND 
		(3) Currently NOT Certified (No Certification Application == 'Certified' ) AND
		(4) EEO_VENDOR_BID.C_BID_SUSPENSION = 1 
202001	PCHEN
		(4.1) revise C_BID_SUSPENSION logic again, 
			take all C_BID_SUSPENSION = 1  into consideration
*******************************************************************************
*/
ALTER procedure [dbo].[EEE_BidOnHoldReport](@prog varchar(2))  
as  
begin  

DECLARE @tblEEOStatus TABLE (Prog_Status VARCHAR(2))
IF @prog = 'A' 
	INSERT INTO @tblEEOStatus (Prog_Status)
	VALUES('GC'),('GT'),('GG'),('GL'),('MC'),('MT'),('MG'),('ML')
ELSE IF @prog='M'  
	INSERT INTO @tblEEOStatus (Prog_Status)
	VALUES ('MC')
ELSE IF @prog='G'  
	INSERT INTO @tblEEOStatus (Prog_Status)
	VALUES('GC')
ELSE IF @prog='MG'  
	INSERT INTO @tblEEOStatus (Prog_Status)
	VALUES('GC'),('MC') ;

;WITH CTE_VENDOR_BID AS
(
	-- stored universe of current EEO Vendors with Suspension flag 
	SELECT CASE WHEN B.Id IS NULL THEN V.VendorId * -1 ELSE B.id END AS Id,  -- to avoid duplicated id key
		V.VendorId, 
		CASE WHEN ISNULL(B.C_BID_SUSPENSION, 0) = 0 THEN 0 ELSE 1 END as C_BID_SUSPENSION,
		b.SD_START, b.SD_TO, B.C_NOTE, B.C_REASON, B.SD_UPDATE, B.I_UPDATEDBY
	FROM EEO_Vendor V 
	LEFT JOIN (
	-- scan all C_BID_SUSPENSION=1 RECORD -- 202001 PCH revised --
		SELECT * ,ROW_NUMBER() OVER (PARTITION BY vendorid ORDER BY SD_UPDATE DESC) AS rnk FROM EEO_VENDOR_BID 
		WHERE C_BID_SUSPENSION = 1 AND SD_START < GETDATE() AND (SD_TO IS NULL OR SD_TO > GETDATE())
	) B ON V.VendorId = b.VENDORID 
	WHERE ISNULL(B.rnk, 1) = 1
	AND V.MentorFlag in (6,7) -- current mentor or grad mentor 
	AND EXISTS (SELECT 1 FROM EEO_vendorAllMentorProgs P WHERE V.VendorId = P.id
		and p.prog_status in (SELECT * from @tblEEOStatus)
		)
)

SELECT VB.VendorId,
	v.Company,
	v.FederalId,
	vb.SD_UPDATE,
	 isnull(au.UserName,'AUTO') AS I_updatedby,   
	vb.Id as bid_id,
	vb.SD_START,
	vb.SD_TO,
	vb.C_NOTE,  
	vb.C_REASON,  
	vb.C_BID_SUSPENSION,  
	(select stuff((select ', ' + prog_status from EEO_vendorAllMentorProgs where id = v.id FOR XML PATH('')),1,1,'')) ProgramStatus,
	CASE WHEN SSQ.Status = 'Qualified' THEN 'Qualified to ' +  CONVERT(nvarchar(30), sq.v_sd_prequal_to, 101)   
		ELSE SSQ.Status
	END AS CMS_VENDOR_STAT,
	vb.Id AS vendor_bid_id,
	'Y' AS OnholdRow   -- PCH Comment 20190611, Do we really need 'OnholdRow'?
	---,SSQ.Status as 'SSQ.Status', SSQ.SupplierId as 'SSQ.SupplierId', SQ.v_sd_prequal_to as 'SQ.v_sd_prequal_to',	SSC.Status as 'SSC.Status'
FROM CTE_VENDOR_BID VB 
JOIN Vendor V ON VB.VendorId = V.Id
JOIN SupplierStatus SSQ ON V.QualifiedSupplierId = SSQ.SupplierId AND SSQ.TypeName = 'Supplier Prequalification'
JOIN SupplierStaticQualification SQ ON V.QualifiedSupplierId = SQ.SupplierId
LEFT JOIN SupplierStatus SSC ON v.CertifiedSupplierId = SSC.SupplierId AND SSC.TypeName = 'Supplier Certification'
LEFT JOIN [User] u  on u.id = vb.I_updatedby  
LEFT JOIN [aspnet_Users] au  on au.UserId = u.UserId 
WHERE 1=1 
AND (
	VB.C_BID_SUSPENSION = 1 OR  --- Valid Suspension
	NOT (SSQ.Status = 'Qualified' AND SQ.V_SD_PREQUAL_TO > GETDATE()) OR  --- Not Qualified
	NOT (ISNULL(SSC.Status, 'Certified') like '%Certified') -- Not Certified
)
order by v.Company, vb.SD_START desc , vb.id desc    

end  
GO
/** Test **
exec EEE_BidOnHoldReport @prog=N'A'
**/
