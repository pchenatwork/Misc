﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierGovernAction
Purpose:	Delete a row from SupplierGovernAction table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/11/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierGovernAction
	@id int
as

delete SupplierGovernAction
where Id = @id
return @@RowCount

