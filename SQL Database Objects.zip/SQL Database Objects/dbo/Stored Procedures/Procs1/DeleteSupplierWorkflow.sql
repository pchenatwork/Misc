﻿










/*
*********************************************************************************************************************
Procedure:	DeleteSupplierSurety
Purpose:	Delete a row from SupplierSurety table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/11/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSupplierWorkflow]
	@id int
as


delete SupplierWorkflow
where Id = @id

return  @@RowCount













