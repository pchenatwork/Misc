﻿Create PROCEDURE [dbo].[EEO_GetDashboardCounter2016225] 
	-- Add the parameters for the stored procedure here
	@userId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    

      

    Declare  @Monthly_Assessment int
    Declare  @DirectorScopeAMontly_Assessment int
    Declare  @ActionPlanCounter int
	Declare  @Mentorswith4MSales int
    Declare  @MENTOR_Overdue_Monthly_AssessmentCounter int 
    Declare  @MENTOR_Overdue_Yearly_AssessmentCounter int 
    Declare  @GradMentor_YearlyAssessmentCounter   int 
    Declare  @Mentor_YearlyAssessmentCounter int
	Declare  @MentorAnnualBidCeilingCounter int

 
   
     exec dbo.EEO_GetCMMontlyDashboardCounter @Monthly_Assessment OUTPUT
  
     exec dbo.EEO_GetDirectorScopeAMontlyDashboardCounter @DirectorScopeAMontly_Assessment OUTPUT
     
     exec dbo.EEO_GetActionPlanCounter @ActionPlanCounter OUTPUT
     
     exec dbo.EEO_GetMentorsWith4MSalesCounter @Mentorswith4MSales OUTPUT

     exec dbo.EEO_GetOverdueMontlyAssessmentCounter @MENTOR_Overdue_Monthly_AssessmentCounter OUTPUT
     
     exec dbo.EEO_GetOverdueYearlyAssessmentCounter @MENTOR_Overdue_Yearly_AssessmentCounter OUTPUT
     
     exec dbo.EEO_GetGradMentorYearlyAssessmentCounter @GradMentor_YearlyAssessmentCounter OUTPUT
     
     exec dbo.EEO_GetMentorYearlyAssessmentCounter @Mentor_YearlyAssessmentCounter OUTPUT

	 exec dbo.EEO_GetMentorAnnualBidCeilingCounter @MentorAnnualBidCeilingCounter OUTPUT
     




     
    -- Insert statements for procedure here
	select 
		e.counterType + ' - ' + e.CounterName as CounterName, e.Url, r.RoleName as CounterType, e.CounterStatus,e.WorkflowAction,
		case when e.CounterStatus='UpdateTestScore' then
			 (
				select count(distinct ev.vendorid) 
				from EEO_MENTOR_GRAD_DETAIL e,eeo_vendor ev
				where 
					DATEADD(YEAR,-2,e.sd_grad_date)>dateadd(year, -2,getdate() ) and DATEADD(YEAR,-2,e.sd_grad_date)<getdate()
					and e.C_MENTOR_TYPE='MENTOR'
					and e.SD_ACTUAL_GRAD_DT is null
					and e.vendorid=ev.VendorId
					and ev.MentorFlag=6
					and e.SD_END is null
					and exists( -- Check if any pending classes exist
								select	ec.C_CLASS_ID	from	eeo_classes ec, EEO_CLASSES_SCHE ES 
								where	ec.c_class_Type=4	AND EC.C_CLASS_ID=es.C_CLASS_ID and es.SD_CLASS_DATE<getdate()
								
								except
								select vc.C_CLASS_ID from EEO_VENDOR_CLASSES vc, eeo_classes ec 
								where vc.vendorid=ev.vendorid and (vc.C_ATTENDED='Y' or (vc.C_ATTENDED='N' and vc.REVIEWED=1))
								and vc.C_CLASS_ID=ec.C_CLASS_ID
								and ec.C_CLASS_TYPE=4
								
								)

				)
			when e.CounterStatus='Tier2_Program' then
			 (
				select count(*) 
				from eeo_vendor ev
				where 
					status='Tier2_Program'
					and exists(-- Check if any pending classes exist
								select	ec.C_CLASS_ID	from	eeo_classes ec, EEO_CLASSES_SCHE ES 
								where	ec.c_class_Type=4	AND EC.C_CLASS_ID=es.C_CLASS_ID and es.SD_CLASS_DATE<getdate()
								except
								select vc.C_CLASS_ID from EEO_VENDOR_CLASSES vc, eeo_classes ec 
								where vc.vendorid=ev.vendorid and vc.C_ATTENDED='Y'
								and vc.C_CLASS_ID=ec.C_CLASS_ID
								and ec.C_CLASS_TYPE=4
								)

				)
				
			--when e.CounterStatus='ExcessiveAbsence' then
			--	( 
			--	select count(*) from eeo_vendor ev 
			--	where status='AdvancedClassesAbsent'

			--	--select count(*) 
			--	--from eeo_vendor ev
			--	--where 
			--	--	status='Tier2_Program'
			--	--	and exists(
			--	--				select vc.C_CLASS_ID 
			--	--				from EEO_VENDOR_CLASSES vc,EEO_CLASSES ec 
			--	--				where vc.vendorid=ev.vendorid 
			--	--				and vc.C_ATTENDED='N' 
			--	--				and vc.C_CLASS_ID=ec.C_CLASS_ID 
			--	--				and ec.C_CLASS_TYPE=4

			--	--				)
			--	)
			when e.CounterStatus='RequestedAppointments' then
				( 
				select count(*) 
				from eeo_vendor ev
				where 
					ev.vendorid in (
						select vendorid from EEO_VENDOR_APPOINTMENTS vc where isnull(C_SCHEDULED,0)=0 and isnull(upper(C_COMMENTS),'')!='DENIED'
						)
						
								
								
								
				)
			when e.CounterStatus='ScheduleAppointments' then
				( 
				select count(*) 
				from eeo_vendor ev
				where 
					ev.vendorid in (
						select vendorid from EEO_VENDOR_APPOINTMENTS vc where isnull(C_SCHEDULED,0)=1 and isnull(C_ATTENDED,0)=0 
						)
				)
			--when e.CounterStatus='AdvancedClassesUpdated' then
			--	( 
			--	select count(*) from eeo_vendor ev 
			--	where status='AdvancedClassesUpdated'

			--	--select count(*) 
			--	--from eeo_vendor ev
			--	--where 
			--	--	ev.vendorid in (
			--	--		select vendorid from EEO_VENDOR_CLASSES vc , eeo_classes e

			--	--		where vc.C_CLASS_ID=e.C_CLASS_ID
			--	--		and e.C_CLASS_TYPE=4
			--	--		and isnull(C_ATTENDED,'N')='Y'
			--	--		and ISNULL(rEVIEWED,0)=0
			--	--		and isnull(vc.TEST_SCORE ,-1)>=0

			--	--		)
			--	--and ev.MentorFlag=6
			--	--and ev.Status='AdvancedClassesUpdated'

			--	)
			when e.CounterStatus='ExcessiveAppointments' then
				( 
				select count(*) 
				from eeo_vendor ev
				where 
					ev.vendorid in (
								
								select  v.vendorid from (select  vendorid from EEO_VENDOR_APPOINTMENTS --where isnull(Reviewed,0) != 1
					group by I_CONSULTANT_LOOKUP_ID, vendorid, dbo.EEO_GetFiscalYear(SD_APPOINTMENT)
					having count(*) > 2) c, EEO_VENDOR_APPOINTMENTS v
					where c.VENDORID=v.VENDORID
					and  isnull(v.Reviewed,0) != 1 and isnull(c_scheduled,0)!=1
					)
								
				)
			when e.CounterStatus='SplAsmentScopB' then
			(
				select count(distinct vendorid) from eeo_special_Assessment where Status='New' or DATEADD(month, FollowUp, ReviewedDate)<=getdate() 
			)
			when e.CounterStatus='SplAsmentReviewer' then
			(
			select count(distinct Vendorid) from eeo_special_Assessment where Status='SB'
			)

            when e.CounterStatus='Mentor_YearlyAssessment_Counter' then
			 (
		        @Mentor_YearlyAssessmentCounter	        
	         )
        
            when e.CounterStatus='GM_YearlyAssessment_Counter' then
			(
		         @GradMentor_YearlyAssessmentCounter     
	         )
             when e.CounterStatus='Mentor_YearlyAssessment_Counter' then
			 (
		        @Mentor_YearlyAssessmentCounter	        
	         )
        
            when e.CounterStatus='Monthly_Assessment' then
			(
		         @Monthly_Assessment   
	         )
             when e.CounterStatus='DirectorScopeAMontly_Assessment' then
			(
		         @DirectorScopeAMontly_Assessment   
	         )
             when e.CounterStatus='ActionPlanCounter' then
			(
		         @ActionPlanCounter 
	         )
             when e.CounterStatus='4MSales' then (@Mentorswith4MSales)
             
             when e.CounterStatus='Mentor_Overdue_Monthly_Assessment' then
			(
		         @MENTOR_Overdue_Monthly_AssessmentCounter 
	         )
             when e.CounterStatus='Mentor_Overdue_Yearly_Assessment' then
			(
		         @MENTOR_Overdue_Yearly_AssessmentCounter 
	         )
             when e.CounterStatus='MentorAnnaulBidCeiling' then
			 (
		         @MentorAnnualBidCeilingCounter 
	         )
             
--select * from eeo_special_Assessment where Status=''	
-- select  DATEADD(month, 3, getdate()),getdate() 
-- delete eeo_special_Assessment where id =14			
		else
			(select count(vendorid)
			from eeo_vendor v
			where [Status]=e.counterstatus
			and not exists (select * from EEO_MENTOR_EXCEPTION where vendorid=v.VendorId and sd_end>getdate())
			)
		end as [Count]
	from	
		eeo_dashboard e,	eeo_dashboardrole er, 
		[user] u, 			aspnet_UsersInRoles ar,
		aspnet_roles r
	where 
		e.id=er.dashboardid
		and er.roleid=ar.RoleId
		and ar.UserId=u.UserId
		and u.id=@userId
		and e.display='Y'
		and ar.RoleId=r.RoleId
		
	order by r.RoleName,e.counterType ,sequence
END
