﻿CREATE PROC [dbo].[EEO_BIDCEILING_MATRIX_SCORING]
(
	 @VendorId int,
	 @AsstType char(1),
	 @Workflowtype varchar(150),
	 @PeriodId int,
	 @ScoredBy int
 )
 WITH RECOMPILE
AS

BEGIN
 DECLARE @cur_date datetime 
 declare @bidceiling_amount decimal 
 set @cur_date= getdate()


-- UPDATE BIDCEILING
select @bidceiling_amount=BidCiellingAmount from eeo_vendor 
  where VendorId = @VendorId


update EEO_MATRIX 
set BIDCEILING_AMOUNT = @bidceiling_amount 
where VENDORID = @VendorId and ASST_TYPE = @AsstType and INTV_SEQ=@PeriodId  

  DELETE FROM EEO_MATRIX_SCORE
    WHERE VENDORID= @VendorId 
		AND ASST_TYPE = @AsstType
		AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND WORKFLOWTYPE = @Workflowtype



     -- FINANCIAL GROWTH SCORING
        --SIMULTANIOUS PROJECTS
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,  1,
        CASE  
        WHEN SIMUL_PROJ = 1 THEN 0.5
        WHEN SIMUL_PROJ = 2 THEN 1.0
        WHEN SIMUL_PROJ = 3 THEN 1.0
        WHEN SIMUL_PROJ = 4 THEN 1.5
        WHEN SIMUL_PROJ = 5 THEN 1.5
        WHEN SIMUL_PROJ > 5 THEN 2.0
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
        
        --CURRENT PROJECTS
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,   2,  
        CASE  
			WHEN CURR_PROJ = 1 THEN 0.5
			WHEN CURR_PROJ = 2 THEN 1.0
			WHEN CURR_PROJ = 3 THEN 1.0
			WHEN CURR_PROJ = 4 THEN 1.5
			WHEN CURR_PROJ = 5 THEN 1.5
			WHEN CURR_PROJ > 5 THEN 2.0
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
        
        --OTHER GOVT EXP
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,  3,   
        CASE  
        WHEN isnull(OTHER_GOV_EXP, 'N') = 'N' THEN 0.0
        WHEN isnull(OTHER_GOV_EXP, 'N') = 'Y' THEN 4.0
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
        
        -- % JOB OUTSIDE SCA
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 4,   
        CASE  
        WHEN isnull(PCT_OUT_JOB, '0') = '0' THEN 0.0
        WHEN isnull(PCT_OUT_JOB, '0') = '1' THEN 0.25
        WHEN isnull(PCT_OUT_JOB, '0') = '2' THEN 0.5
        WHEN isnull(PCT_OUT_JOB, '0') = '3' THEN 0.75
        WHEN isnull(PCT_OUT_JOB, '0') = '4' THEN 1.0
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
        
        -- % RECEIVEABLE IN 60 DAY
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,  5,  
        CASE  
        WHEN isnull(PCT_RCVABLE_60DAY, '0') = '0' THEN 0.0
        WHEN isnull(PCT_RCVABLE_60DAY, '0') = '1' THEN 0.75
        WHEN isnull(PCT_RCVABLE_60DAY, '0') = '2' THEN 1.5
        WHEN isnull(PCT_RCVABLE_60DAY, '0') = '3' THEN 2.25
        WHEN isnull(PCT_RCVABLE_60DAY, '0') = '4' THEN 3.00
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
        
        -- % OF ANNUAL REV
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,  6,  
        CASE  
        WHEN isnull(PCT_OUT_JOB_REV, '0')  = '0' THEN 0.0
        WHEN isnull(PCT_OUT_JOB_REV, '0')  = '1' THEN 0.50
        WHEN isnull(PCT_OUT_JOB_REV, '0')  = '2' THEN 1.00
        WHEN isnull(PCT_OUT_JOB_REV, '0')  = '3' THEN 1.50
        WHEN isnull(PCT_OUT_JOB_REV, '0')  = '4' THEN 2.00
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype

		        --GROWTH IN MENTOR
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,  7,   
        CASE  
        WHEN isnull(PCT_YR_GROW_MENTOR, '0')  = '0' THEN 0.0
        WHEN isnull(PCT_YR_GROW_MENTOR, '0')  = '1' THEN 0.50
        WHEN isnull(PCT_YR_GROW_MENTOR, '0')  = '2' THEN 1.00
        WHEN isnull(PCT_YR_GROW_MENTOR, '0')  = '3' THEN 2.00
        WHEN isnull(PCT_YR_GROW_MENTOR, '0')  = '4' THEN 3.00
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
        
        -- CPA SERVICE
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,  8,   
        CASE  
        WHEN isnull(CPA_IND, 'N') = 'N' THEN 0.0
        WHEN isnull(CPA_IND, 'N') = 'Y' THEN 2.0
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
        
        -- CPA AUDIT
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,  9,  
        CASE  
        WHEN isnull(CPA_AUDIT_REVIEW_IND, 'N') = 'N' THEN 0.0
        WHEN isnull(CPA_AUDIT_REVIEW_IND, 'N') = 'Y' THEN 2.0
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype

        --PROFITABILITY
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 10,   
        CASE  
        WHEN isnull(PROFIT_3YR_IND, 'N') = 'N' THEN 0.0
        WHEN isnull(PROFIT_3YR_IND, 'N') = 'Y' THEN 2.0
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
        
        --EARNING INVESTMENT
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 11,    
        CASE  
        WHEN isnull(ERNG_INVEST_LASTYR, 0) = 0 THEN 0.0
        WHEN isnull(ERNG_INVEST_LASTYR, 0) = 1 THEN 0.50
        WHEN isnull(ERNG_INVEST_LASTYR, 0) = 2 THEN 1.0
        WHEN isnull(ERNG_INVEST_LASTYR, 0) = 3 THEN 1.5
        WHEN isnull(ERNG_INVEST_LASTYR, 0) = 4 THEN 2.0
        ELSE 0
        END , @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
    

	    --BONDING AND LOAN
        -- BONDING
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 12,  
        CASE  
        WHEN isnull(SCA_BONDING_Q, 'N') = 'N' THEN 0.0
        WHEN isnull(SCA_BONDING_Q, 'N') = 'Y' THEN 2.0
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
        
        -- LAON DEFAULT     
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,  13,   
        CASE 
        WHEN isnull(YR7_LOAN_DEFAULT, 'N') = 'N' THEN 0.0
        WHEN isnull(YR7_LOAN_DEFAULT, 'N') = 'Y' THEN -1.0
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
        
        --CREDIT LINE
        INSERT INTO EEO_MATRIX_SCORE
        SELECT  VENDORID, @PeriodId,@AsstType,@Workflowtype, 14,  
        CASE  
        WHEN isnull(NO_CARVER_LOAN, 0)  = 0 THEN 0.0
        WHEN isnull(NO_CARVER_LOAN, 0)  = 1 THEN 1.00
        WHEN isnull(NO_CARVER_LOAN, 0)  = 2 THEN 2.00
        WHEN isnull(NO_CARVER_LOAN, 0)  = 3 THEN 3.00
        WHEN isnull(NO_CARVER_LOAN, 0)  = 4 THEN 4.00
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
    
    --PROJECT MANAGEMENT
        --ESTIMATOR
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 15,  
        CASE  
        WHEN isnull(ESTIMATOR_IND, 'N')  = 'N' THEN 0.0
        WHEN isnull(ESTIMATOR_IND, 'N')  = 'Y' THEN 1.0
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


        --SCHEDULER
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 16,  
        CASE  
        WHEN isnull(SCHEDULER_IND, 'N')  = 'N' THEN 0.0
        WHEN isnull(SCHEDULER_IND, 'N')  = 'Y' THEN 1.0
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)             
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype

        --PROJECT MANAGER
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 17,   
        CASE  
        WHEN isnull(JOB_SITE_SUP_IND, 'N')  = 'N' THEN 0.0
        WHEN isnull(JOB_SITE_SUP_IND, 'N')  = 'Y' THEN 1.0
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype

        -- OSHA
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 18,   
        CASE  
        WHEN isnull(OSHA_TRAINING_IND, 'N')  = 'N' THEN 0.0
        WHEN isnull(OSHA_TRAINING_IND, 'N')  = 'Y' THEN 2.0
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)          
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


		--UNION ASSOCIATION
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 19,   
        CASE  
        WHEN isnull(UNION_ASSOTN, 'N')  = 'N' THEN 0.0
        WHEN isnull(UNION_ASSOTN, 'N')  = 'Y' THEN 1.5
        ELSE 0
        END, @cur_date, @ScoredBy 
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId) 
		AND ASST_TYPE = @AsstType
        AND WORKFLOWTYPE = @Workflowtype
		
		    
        -- OFFICE PERSONAL TRAINING
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 20,   
        CASE  
        WHEN isnull(OFFICE_TRAINING, 'N')  = 'N' THEN 0.0
        WHEN isnull(OFFICE_TRAINING, 'N')  = 'Y' THEN 1.0
        ELSE 0
        END, @cur_date, @ScoredBy  
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId) 
		AND ASST_TYPE = @AsstType
        AND WORKFLOWTYPE = @Workflowtype

		 -- FIELD PERSONAL TRAINING
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 21,   
        CASE  
        WHEN isnull(FIELD_TRAINING, 'N')  = 'N' THEN 0.0
        WHEN isnull(FIELD_TRAINING, 'N')  = 'Y' THEN 1.0
        ELSE 0
        END, @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId) 
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype

        
        --SCAFFOLDING CERTIFIED
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 22,  
        CASE  
        WHEN isnull(SCAFFOLDING_CERT, 'N')  = 'N' THEN 0.0
        WHEN isnull(SCAFFOLDING_CERT, 'N')  = 'Y' THEN 0.5
        ELSE 0
        END, @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
    
    --ADMINISTRATION
        --PAYROLL SERVICE 3RD PARTY
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 23,  
        CASE  
        WHEN isnull(PAYROLL_3RD_PARTY, 'N')  = 'N' THEN 0.0
        WHEN isnull(PAYROLL_3RD_PARTY, 'N')  = 'Y' THEN 0.5
        ELSE 0
        END, @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId) 
		AND ASST_TYPE = @AsstType       
		AND WORKFLOWTYPE = @Workflowtype  
        
        --OFFICE MANAGER
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 24,  
        CASE
        WHEN isnull(OFFICE_MGR, 'N')  = 'N' THEN 0.0
        WHEN isnull(OFFICE_MGR, 'N')  = 'Y' THEN 1.0
        ELSE 0
        END, @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)           
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype

        --CERTIFICATION
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 25,   
        CASE  
        WHEN isnull(CERT_ACCRED_IND, 'N')  = 'N' THEN 0.0
        WHEN isnull(CERT_ACCRED_IND, 'N')  = 'Y' THEN 3.5
        ELSE 0
        END, @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype

        --CFO
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 26,   
        CASE  
        WHEN isnull(CFO_IND, 'N')  = 'N' THEN 0.0
        WHEN isnull(CFO_IND, 'N')  = 'Y' THEN 1.0
        ELSE 0
        END, @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)          
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
	
    --MARKETING
        --MKT MATERIALS
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 27,  
        CASE  
        WHEN isnull(MRKT_MATERIALS, 0) = 0 THEN 0.0
        WHEN isnull(MRKT_MATERIALS, 0) = 1 THEN 0.5
        WHEN isnull(MRKT_MATERIALS, 0) = 2 THEN 1.5
        WHEN isnull(MRKT_MATERIALS, 0) = 3 THEN 2.0
        WHEN isnull(MRKT_MATERIALS, 0) = 4 THEN 2.5
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)  
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype

        --BUSINESS PLAN
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 28,  
        CASE  
        WHEN isnull(BUSINESS_PLAN, '0') = '0' THEN 0.0
        WHEN isnull(BUSINESS_PLAN, '0') = '1' THEN 2.0
        WHEN isnull(BUSINESS_PLAN, '0') = '2' THEN 4.0
        WHEN isnull(BUSINESS_PLAN, '0') = '3' THEN 6.0
        WHEN isnull(BUSINESS_PLAN, '0') = '4' THEN 8.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
        
        --MKT PROMOTION
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 29,  
        CASE  
        WHEN isnull(COMP_PROMOTION_EFFORT, 'N')  = 'N' THEN 0.0
        WHEN isnull(COMP_PROMOTION_EFFORT, 'N')  = 'Y' THEN 3.0
        ELSE 0
        END, @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId) 
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


        --BID OPPORTUNITY
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 30,  
        CASE  
        WHEN isnull(OUTSIDE_BID_OPORTUNITY, '0')  = '0' THEN 0.0
        WHEN isnull(OUTSIDE_BID_OPORTUNITY, '0')  = '1' THEN 1.5
        WHEN isnull(OUTSIDE_BID_OPORTUNITY, '0')  = '2' THEN 3.00
        WHEN isnull(OUTSIDE_BID_OPORTUNITY, '0')  = '3' THEN 4.50
        WHEN isnull(OUTSIDE_BID_OPORTUNITY, '0')  = '4' THEN 6.00
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)           
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


        --TRADE ORGANIZATION ASSOCIATION
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 31,   
        CASE
        WHEN isnull(TRADE_ORG_ASSOTN, 'N')  = 'N' THEN 0.0
        WHEN isnull(TRADE_ORG_ASSOTN, 'N')  = 'Y' THEN 1.5
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId) 
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


    --TECHNOLOGY
        -- WEB SITE
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,  32,   
        CASE  
        WHEN isnull(WEB_SITE_IND, 'N') = 'N' THEN 0.0
        WHEN isnull(WEB_SITE_IND, 'N') = 'Y' THEN 3.00
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId) 
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


        -- EST SOFT
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 33,   
        CASE  
        WHEN isnull(ESTMT_IND, 'N')  = 'N' THEN 0.0
        WHEN isnull(ESTMT_IND, 'N')  = 'Y' THEN 1.0
        ELSE 0.0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


        -- SCHE SOFT
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,  34,   
        CASE 
        WHEN isnull(SCHEDULING_IND, 'N')  = 'N' THEN 0.0
        WHEN isnull(SCHEDULING_IND, 'N')  = 'Y' THEN 1.0
        ELSE 0.0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


        -- BOOKKEEPING SOFT
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 35,   
        CASE  
        WHEN isnull(BOOKKEEPING_IND, 'N')  = 'N' THEN 0.0
        WHEN isnull(BOOKKEEPING_IND, 'N')  = 'Y' THEN 1.0
        ELSE 0.0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


        --PAYROLL SOFT
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 36,  
        CASE  
        WHEN isnull(PAYROLL_IND, 'N')  = 'N' THEN 0.0
        WHEN isnull(PAYROLL_IND, 'N')  = 'Y' THEN 1.0
        ELSE 0.0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)         
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype



        -- BACKUP PLAN             
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 37,  
        CASE  
        WHEN isnull(BACKUP_PLAN, '0')  = '0' THEN 0.0
        WHEN isnull(BACKUP_PLAN, 'N')  = '1' THEN 0.5
        WHEN isnull(BACKUP_PLAN, 'N')  = '2' THEN 0.75
        WHEN isnull(BACKUP_PLAN, 'N')  = '3' THEN 1.00
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)  
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype

    --TRAINING
        --CONT TRAINING
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,  38,  
        CASE  
        WHEN isnull(CONT_TRAINING_IND, 'N') = 'N' THEN 0.0
        WHEN isnull(CONT_TRAINING_IND, 'N') = 'Y' THEN 2.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId) 
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


        --ELECTIVE TRAINING
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 39,   
        CASE  
        WHEN isnull(ELECTIVE_TRAINING_IND, 'N') = 'N' THEN 0.0
        WHEN isnull(ELECTIVE_TRAINING_IND, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype

    --OFFICE VISIT
        -- GENERAL OFFICE CONDITION
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 40,  
        CASE
        WHEN isnull(V_OFFICE_SPACE, 'N') = 'N' THEN 0.0
        WHEN isnull(V_OFFICE_SPACE, 'N') = 'Y' THEN 2.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
        
        --SIGN
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 41,  
        CASE 
        WHEN isnull(V_OFFICE_SIGNBOARD, 'N') = 'N' THEN 0.0
        WHEN isnull(V_OFFICE_SIGNBOARD, 'N') = 'Y' THEN 2.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


        -- FILE MGMT
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 42,  
        CASE  
        WHEN isnull(V_GOOD_FILE_MGMT, 'N') = 'N' THEN 0.0
        WHEN isnull(V_GOOD_FILE_MGMT, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)        
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


        -- NEAT
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 43,   
        CASE  
        WHEN isnull(V_NEAT_APPEARANCE, 'N') = 'N' THEN 0.0
        WHEN isnull(V_NEAT_APPEARANCE, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)       
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


        -- EQUIPTMENT
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 44,  
        CASE
        WHEN isnull(V_REQ_OFFICE_EQUIPT, 'N') = 'N' THEN 0.0
        WHEN isnull(V_REQ_OFFICE_EQUIPT, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)       
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
		
		--OFFICE OPERATIONS
        --Goog schedule
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,  45,  
        CASE
        WHEN isnull(V_GOOD_STUFFING_SCHED, 'N') = 'N' THEN 0.0
        WHEN isnull(V_GOOD_STUFFING_SCHED, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType      
		AND WORKFLOWTYPE = @Workflowtype
        
        -- PLANS
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype,  46,  
        CASE 
        WHEN isnull(V_ORGANIZED_PLANS, 'N') = 'N' THEN 0.0
        WHEN isnull(V_ORGANIZED_PLANS, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
        
        -- ANSWERING SERVICE
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 47,  
        CASE  
        WHEN isnull(V_GOOD_ANSWERING_SRV, 'N') = 'N' THEN 0.0
        WHEN isnull(V_GOOD_ANSWERING_SRV, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType    
		AND WORKFLOWTYPE = @Workflowtype
        
        -- INVENTORY  
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 48,  
        CASE 
        WHEN isnull(V_GOOD_DEL_INVENTORY, 'N') = 'N' THEN 0.0
        WHEN isnull(V_GOOD_DEL_INVENTORY, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId) 
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
    
    --ACCESS TO INFORMATIONS     
        -- DATA SECURITY
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 49,  
        CASE 
        WHEN isnull(V_GOOD_DATA_SECURITY, 'N') = 'N' THEN 0.0
        WHEN isnull(V_GOOD_DATA_SECURITY, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId) 
		AND ASST_TYPE = @AsstType      
        AND WORKFLOWTYPE = @Workflowtype

        -- MAterials SECURITY
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 50,  
        CASE 
        WHEN isnull(V_GOOD_ACCT_SECURITY, 'N') = 'N' THEN 0.0
        WHEN isnull(V_GOOD_ACCT_SECURITY, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId) 
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
		 
        -- ACCT JOINT RESPONSIBILITY
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 51,  
        CASE
        WHEN isnull(V_JOINT_CHECK_SIGNING, 'N') = 'N' THEN 0.0
        WHEN isnull(V_JOINT_CHECK_SIGNING, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)      
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
            
        -- SEP OF CORP ACCT
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 52,  
        CASE
        WHEN isnull(V_SEP_CORP_FINANCE, 'N') = 'N' THEN 0.0
        WHEN isnull(V_SEP_CORP_FINANCE, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId) 
		AND ASST_TYPE = @AsstType 
		AND WORKFLOWTYPE = @Workflowtype
    
    --VIRTUAL OFFICE        
        -- WEB SITE MAINTAINANCE
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 53,  
        CASE
        WHEN isnull(V_WEB_WITH_CONTACT, 'N') = 'N' THEN 0.0
        WHEN isnull(V_WEB_WITH_CONTACT, 'N') = 'Y' THEN 2.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId) 
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
		
		        
        -- PROJ INFO IN WEB
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 54,  
        CASE
        WHEN isnull(V_WEB_UPD_WITH_PROJ, 'N') = 'N' THEN 0.0
        WHEN isnull(V_WEB_UPD_WITH_PROJ, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


        -- HAS CORP DOMAIN
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 55,  
        CASE
        WHEN isnull(V_HAS_DOMAIN_EMAILING, 'N') = 'N' THEN 0.0
        WHEN isnull(V_HAS_DOMAIN_EMAILING, 'N') = 'Y' THEN 2.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype


        --BUS CARD WITH EMAIL     
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 56,  
        CASE
        WHEN isnull(V_BUS_CARD_WITH_EMAIL, 'N') = 'N' THEN 0.0
        WHEN isnull(V_BUS_CARD_WITH_EMAIL, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
        AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
		
		--PDA FOR MGMT     
        INSERT INTO EEO_MATRIX_SCORE
        SELECT VENDORID, @PeriodId,@AsstType,@Workflowtype, 57,   
        CASE
        WHEN isnull(V_MGMT_CONTACT_FACILITY, 'N') = 'N' THEN 0.0
        WHEN isnull(V_MGMT_CONTACT_FACILITY, 'N') = 'Y' THEN 1.0
        ELSE 0
        END , @cur_date, @ScoredBy
        FROM EEO_MATRIX
        WHERE VENDORID = @VendorId
        AND (@PeriodId IS NULL OR INTV_SEQ = @PeriodId)
		AND ASST_TYPE = @AsstType
		AND WORKFLOWTYPE = @Workflowtype
End
