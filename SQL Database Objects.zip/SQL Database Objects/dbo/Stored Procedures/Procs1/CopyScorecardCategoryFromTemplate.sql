﻿
/*
*********************************************************************************************************************
Procedure:	CopyScorecardCategoryFromTemplate
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
11/21/2008	Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE PROCEDURE [dbo].[CopyScorecardCategoryFromTemplate]
	@id int,
	@templateId int
AS
Begin

Set NoCount On

Declare @projectType nvarchar(50)
Select @projectType = isnull(st.Country, '') 
From ScorecardTemplateCategory sc, ScorecardTemplate st
Where sc.Id = @templateId and sc.TemplateId = st.Id

Declare @scorecardType nvarchar(20)
Select @scorecardType = isnull(Type, '') From Scorecard
Where Id = @id

declare @workflowId int
Select @workflowId = Id From WorkflowList
Where Type = 'Evaluation'

Declare @cipType nvarchar(10)

if @projectType != '' and @projectType != 'IEH'
begin
	Select @cipType = 
		Case p.Resoa
			When 1 Then 'RESO A'
			Else 'CIP'
		End
	From ScorecardProject p, Scorecard s
	where p.Id = s.RefId
	and s.Id = @id
end
else if @projectType = 'IEH'
begin
	Select @cipType = 
		Case p.Type
			When 'Hazmat' Then 'Hazmat'
			Else 'Non-Hazmat'
		End
	From ScorecardProject p, Scorecard s
	where p.Id = s.RefId
	and s.Id = @id
end

select @cipType

Declare @newCategoryId int
Declare @questionId int
Declare @newQuestionId int
	
Insert Into ScorecardCategory
(
	ScorecardId,Name,Sequence,Weight,TemplateId
)
Select @id,Name,Sequence,Weight,Id
From ScorecardTemplateCategory
Where Id = @templateId

Set @newCategoryId = @@identity

declare @tempQuestion Table
(
	Id			int,
	Name		nvarchar(500),
	Description	ntext,
	Sequence	int,
	Weight		int,
	Score		int,
	IsRequired	char(1),
	ScoreMethod nvarchar(10),
	GroupName	nvarchar(50)
)

Insert Into @tempQuestion
(
	Id,Name,Description,Sequence,Weight,Score,IsRequired,ScoreMethod
)
Select Id,Name,Description,Sequence,Weight,Score,IsRequired,ScoreMethod
From ScorecardTemplateQuestion
Where CategoryId = @templateId

While Exists( Select * From @tempQuestion )
Begin
	Select @questionId = Id From @tempQuestion Order By Id desc

	Insert Into ScorecardQuestion
	(
		ScorecardId,CategoryId,Name,Description,Sequence,Weight,Score,IsRequired,ScoreMethod,TemplateId
	)
	Select @id,@newCategoryId,Name,Description,Sequence,Weight,Score,IsRequired,ScoreMethod,@questionId
	From @tempQuestion
	Where Id = @questionId

	Set @newQuestionId = @@identity

	Insert Into ScorecardQuestionUserType
	(
		QuestionId, UserType
	)
	Select @newQuestionId, UserType
	From ScorecardTemplateQuestionUserType
	Where QuestionId = @questionId and (isnull(Type, '') = '' or Type = @cipType)

	Delete @tempQuestion Where Id = @questionId
End

Insert Into ScorecardInvitee
(
	ScorecardId, UserId, UserType, SupervisorId, SupervisorType, WorkflowId, Status, CreateDate
)
Select distinct @id, pu.UserId, pu.UserType, pu.SupervisorId, 
Case pu.UserType
	When 'Design Project Manager' Then 'Design Manager'
	When 'Senior Project Officer' Then 'Chief Project Officer'
	When 'IEH Hygienist B' Then 'IEH Hygienist C'
	Else pu.UserType + ' Supervisor'
End, 
@workflowId, 0, getdate()
From ScorecardTemplateUserType st, CompanyBranch p, CompanyBranch c, ScorecardProjectUser pu, Scorecard s
Where st.CategoryId = @templateId
and pu.ScorecardProjectId = s.RefId
and s.Id = @id
and st.UserType = p.Name
and p.Id = c.ParentId
and c.Name = pu.UserType
and (st.Type = '' or st.Type = @cipType)

if @scorecardType = 'Capacity'
	Insert Into ScorecardUser
	(
		ScorecardId, UserId, UserType, Status, CreateDate
	)
	Select @id, pu.UserId, pu.UserType, 0, getdate()
	From ScorecardProjectUser pu, Scorecard s
	Where pu.ScorecardProjectId = s.RefId
	and s.Id = @id
	and pu.UserType in ('Design Project Manager', 'Design Manager', 'Deputy Director', 'Director')

else if @scorecardType = 'CIP'
begin
	Insert Into ScorecardUser
	(
		ScorecardId, UserId, UserType, Status, CreateDate
	)
	Select @id, pu.UserId, pu.UserType, 0, getdate()
	From ScorecardProjectUser pu, Scorecard s
	Where pu.ScorecardProjectId = s.RefId
	and s.Id = @id
	and pu.UserType in ('Design Project Manager', 'Design Manager')

	Insert Into ScorecardUser
	(
		ScorecardId, UserId, UserType, Status, CreateDate
	)
	Select @id, pu.UserId, pu.UserType, -1, getdate()
	From ScorecardProjectUser pu, Scorecard s
	Where pu.ScorecardProjectId = s.RefId
	and s.Id = @id
	and pu.UserType in ('Deputy Director', 'Director')
end
else if @scorecardType = 'CCFU'
	Insert Into ScorecardUser
	(
		ScorecardId, UserId, UserType, Status, CreateDate
	)
	Select @id, pu.UserId, pu.UserType, 0, getdate()
	From ScorecardProjectUser pu, Scorecard s
	Where pu.ScorecardProjectId = s.RefId
	and s.Id = @id
	and pu.UserType in ('Operations Director')

if 	@projectType = 'IEH'
	Insert Into ScorecardUser
	(
		ScorecardId, UserId, UserType, Status, CreateDate
	)
	Select @id, pu.UserId, pu.UserType, 0, getdate()
	From ScorecardProjectUser pu, Scorecard s
	Where pu.ScorecardProjectId = s.RefId
	and s.Id = @id
	and pu.UserType in ('IEH Hygienist C')

return 1

End