﻿/*
*********************************************************************************************************************
Procedure:	CancelCheckOutRfxDocument
Purpose:	Update CheckOut Info in RfxDocument table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
08/16/2007		Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CancelCheckOutRfxDocument]
	@id int
as
Update RfxDocument
set
	CheckOutId = null,
	CheckOutDate = null
where Id = @id
return  @@RowCount


