﻿
/*
*********************************************************************************************************************
Procedure:	 
Purpose:	 
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
09/11/2015		Syed			    Created
*********************************************************************************************************************
*/
CREATE PROCEDURE [dbo].[EEO_GetCMMontlyVendors1]
AS

Begin

Declare @vendorid as int
Declare @prev_vendorid as int
Declare @startDate as Datetime 
Declare @gradDate as Datetime 


Declare @DayOfMonth Int  
Declare @Month Int
Declare @Year Int
Declare @GradYear Int
Declare @PeriodId Int

set @PeriodId= 1
set @prev_vendorid= 0


DECLARE @ret int;


Declare @tempVendorPeriod Table
(
    Id int identity (1,1) Primary Key,
    PeriodId decimal(5,0),
    Vendorid int,
  	Period_StartDate Datetime,
    Period_EndDate Datetime
)
 
    DECLARE vendor_cursor CURSOR FOR 
        SELECT DISTINCT d.VENDORID ,  SD_START_DATE AS STARTDATE , SD_GRAD_DATE AS GRADDATE
		FROM dbo.EEO_MENTOR_GRAD_DETAIL d, eeo_vendor v
		WHERE d.C_MENTOR_TYPE ='MENTOR'
		and d.VENDORID=v.VendorId
		and v.MentorFlag in (6)
     
    OPEN vendor_cursor
        
        FETCH NEXT FROM vendor_cursor 
            INTO @vendorid, @startDate,@gradDate
            
        WHILE @@FETCH_STATUS = 0
        BEGIN
              SELECT 
                  @DayOfMonth = DAY ( @startDate ),
                  @Month = MONTH  ( @startDate ),
                  @Year =YEAR ( @startDate ),
                  @GradYear= YEAR(@gradDate)  

                  
                WHILE @Year < @GradYear-1
                BEGIN
                
                IF @prev_vendorid = @vendorid  
                    BEGIN
                     set @PeriodId = @PeriodId + 1    
                    END   
                ELSE
                    set @PeriodId =1
                    
                    
                    Insert Into @tempVendorPeriod
                    (   PeriodId ,
                        Vendorid,
                        Period_StartDate, 
                        Period_EndDate 
                    )
                    select    @PeriodId,
                              @vendorid,
                              DateAdd(day, @DayOfMonth - 1, 
                                  DateAdd(month, @Month - 1, 
                                      DateAdd(Year, @Year-1900  , 0))),
                                      
                                      
                           EOMONTH( DateAdd(day, @DayOfMonth- 1, 
                                  DateAdd(month, @Month - 1, 
                                      DateAdd(Year, @Year-1900 +1, 0)))) 
                                      
                                      
                    set @Year = @Year +1 
                    set @prev_vendorid = @vendorid
                            
                END
        

        
        
        FETCH NEXT FROM vendor_cursor 
            INTO @vendorid, @startDate,@gradDate
        END 
        CLOSE vendor_cursor;
        
    DEALLOCATE vendor_cursor;

  select * into ##temp2 from @tempVendorPeriod
    select distinct vendorid from 
    (
            SELECT Vendorid,PeriodId ,Period_StartDate,Period_EndDate, DATEADD(month,number+1,Period_StartDate) PeriodMonth
            from @tempVendorPeriod t, master..spt_values sv
            where sv.type = 'P' AND DATEADD(month,number+1,t.Period_StartDate) <t.Period_EndDate
    ) pm where exists(	select *  
						from  
							MV_SOLICIT_CONTRACT m, vendor v 
						where 
							ISNULL(m.C_VENDOR_ID,m.ME_VENDOR_ID)= V.FEDERALID
                            and v.id=pm.vendorid
                            and ( 
									DATEADD(dd, 1, EOMONTH(pm.PeriodMonth, -1))  >= DATEADD(dd, 1, EOMONTH(m.D_CONSTR_BEGIN , -1)) 
									AND EOMONTH(pm.PeriodMonth) <= EOMONTH(m.D_CONSTR_END) 
								)
							and not exists (
								select * from eeo_mentor_ppm_rating 
								where vendorid=v.id and proj_code=m.c_package_code 
								and MONTH_RATED between m.D_CONSTR_BEGIN and m.D_CONSTR_END
								)
						)
            
			


 
    
END
