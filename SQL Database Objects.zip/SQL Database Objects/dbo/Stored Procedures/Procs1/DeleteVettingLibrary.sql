﻿/*
*********************************************************************************************************************
Procedure:	DeleteVettingLibrary
Purpose:	Delete a row from VettingLibrary table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
2/15/2006		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteVettingLibrary]
	@id int
as
delete VettingLibrary
where Id = @id
return @@RowCount

