﻿




/*
*********************************************************************************************************************
Procedure:	DeleteSupplierSurety
Purpose:	Delete a row from SupplierSurety table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/11/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSupplierSurety]
	@id int
as

delete SupplierSurety
where Id = @id

return @@rowcount






