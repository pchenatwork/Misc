﻿---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*
*********************************************************************************************************************
Procedure:	 
Purpose:	 
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
09/11/2015		Syed			    Created
09/30/2015		Pasha				isnull(m.D_CONSTR_END,getdate()) added
									Made change to filter for Mentor firms only. Added
									Used eeo_latest_ppm_rating instead of using eeo_mentor_ppm_rating 
*********************************************************************************************************************
*/
CREATE PROCEDURE [dbo].[EEO_GetDirectorScopeAMontlyVendors]
AS

Begin

 SELECT DISTINCT VENDORID
   FROM EEO_LATEST_PPM_RATING WHERE  ISNULL(IS_SUBMITTED,0)=1 AND ISNULL(IS_APPROVED,0)=0 

/*
Declare @vendorid as int
Declare @prev_vendorid as int
Declare @startDate as Datetime 
Declare @endDate as Datetime 


Declare @DayOfMonth Int  
Declare @Month Int
Declare @Year Int
Declare @GradYear Int
Declare @PeriodId Int

set @PeriodId= 1
set @prev_vendorid= 0


DECLARE @ret int;


Declare @tempVendorPeriod Table
(
    Id int identity (1,1) Primary Key,
    PeriodId decimal(5,0),
    Vendorid int,
  	Period_StartDate Datetime,
    Period_EndDate Datetime
)
 
  

Declare @Days4MentorOverdueYearlyAssessment int 

Select @Days4MentorOverdueYearlyAssessment = ISNULL([value],0) from dbo.EEO_CONFIG
   	where [key] = 'Days4MentorOverdueYearlyAssessment'



DECLARE eeo_vendor_cursor CURSOR FOR 
		SELECT distinct GD.VENDORID,
				DATEFROMPARTS(YEAR(GD.SD_START_DATE),MONTH(GD.SD_START_DATE),1)  AS STARTDATE,   -- start of the month
				EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS ENDDATE  --  USE SD_EXT_GRAD_DATE FIRST OTHERWISE SD_GRAD_DATE AND EXCLUDE FINAL YEAR
		FROM (SELECT * FROM  DBO.EEO_MENTOR_GRAD_DETAIL 
						WHERE ID IN  
								(SELECT MAX(ID) AS ID   FROM DBO.EEO_MENTOR_GRAD_DETAIL  -- MAX RECORD FOR VENDOR WITH C_MENTOR_TYPE
									WHERE    C_MENTOR_TYPE='MENTOR'
									GROUP BY VENDORID,C_MENTOR_TYPE 
									)
		) GD , EEO_VENDOR EV, VENDOR V  
		WHERE  GD.VENDORID=EV.VENDORID
				AND EV.VENDORID =V.ID
				AND EV.MENTORFLAG IN (6) -- only those vendors marked as  MENTOR


 
OPEN eeo_vendor_cursor

FETCH NEXT FROM eeo_vendor_cursor 
    INTO @vendorid, @startDate,@endDate



WHILE @@FETCH_STATUS = 0
BEGIN
       Insert Into @tempVendorPeriod
		(   PeriodId ,
			Vendorid,
			Period_StartDate, 
			Period_EndDate  
		 )
		  SELECT number+1,
				 @vendorid,
				 DATEADD(year,number,@startDate) PeriodStart,
				 DATEADD(year,number+1,@startDate) PeriodEnd 
		from master..spt_values sv
			 where sv.type = 'P' AND DATEADD(year,number+1,@startDate) <= DATEADD(day, @Days4MentorOverdueYearlyAssessment,@endDate) 

 



        -- Get the next vendor.
FETCH NEXT FROM eeo_vendor_cursor 
    INTO @vendorid, @startDate,@endDate
END 
CLOSE eeo_vendor_cursor;
DEALLOCATE eeo_vendor_cursor;

 
    select distinct  Vendorid from 
    (
            SELECT Vendorid,PeriodId ,Period_StartDate,Period_EndDate, DATEADD(month,number+1,Period_StartDate) PeriodMonth
            from @tempVendorPeriod t, master..spt_values sv
            where sv.type = 'P' AND DATEADD(month,number+1,t.Period_StartDate) <t.Period_EndDate
    ) pm where exists(  select *  from  MV_SOLICIT_CONTRACT m, vendor v 
                        where 
                                        ISNULL(m.C_VENDOR_ID,m.ME_VENDOR_ID)= V.FEDERALID
                                        and v.id=pm.vendorid
                                        and ( DATEADD(dd, 1, EOMONTH(pm.PeriodMonth, -1))  >= DATEADD(dd, 1, EOMONTH(m.D_CONSTR_BEGIN , -1)) 
                                        AND EOMONTH(pm.PeriodMonth) <= EOMONTH(isnull(m.D_CONSTR_END,getdate())) )
                                        and  exists (select * from eeo_latest_ppm_rating where vendorid=v.id and proj_code=m.c_package_code and MONTH_RATED between m.D_CONSTR_BEGIN and isnull(m.D_CONSTR_END,getdate())
													and isnull(IS_SUBMITTED,0)=1 and isnull(is_approved,0)=0 ))
            



 */




    
END
