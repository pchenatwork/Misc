﻿-------------------

/*
*********************************************************************************************************************
Procedure:	 
Purpose:	 
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
09/11/2015		Syed			    Created
*********************************************************************************************************************
*/
CREATE PROCEDURE [dbo].[EEO_GetMatrixIntScoring]
(
     @MENTOR INT,
     @PERIOD_SEQ decimal(5,0),
	 @AsstType char(1),
	 @Workflowtype varchar(150),
     @SCORED_BY char(6)
 )
AS
BEGIN 

DECLARE @DT DATETIME
DECLARE @BID NUMERIC(6,2)
DECLARE @BIDI NUMERIC(6,2)
DECLARE @AWARD NUMERIC(6,2)
DECLARE @BOND NUMERIC(12,2)
DECLARE @LOAN NUMERIC(4,0)
DECLARE @CELLING NUMERIC(12,2)
DECLARE @STARTDTBID DATETIME
DECLARE @PCT NUMERIC(5,2)

SELECT @BID = 0.0
SELECT @AWARD = 0.0
SELECT @LOAN = 0

------------------------------
---- PERIOD START AND END DATE 
------------------------------ 
DECLARE @STARTDT DATETIME
DECLARE @ENDDT DATETIME


Declare @tempPeriod Table
(
    PeriodId int,
  	StartDate Datetime,
    EndDate Datetime
)

insert into @tempPeriod
   exec EEO_GetPMAssessmentPeriod @MENTOR
   
select @STARTDT=StartDate ,
       @ENDDT=EndDate  
from @tempPeriod  where PeriodId=@PERIOD_SEQ 

------------------------------
---- PERIOD START AND END DATE 
------------------------------ 
  
SELECT @DT = GETDATE()
 
------------------------------
---- DELETE PREVIOUS DATA 
------------------------------ 
DELETE FROM EEO_MATRIX_INT_SCORE 
  WHERE VENDORID=@MENTOR AND PERIOD_SEQ=@PERIOD_SEQ
  
 

-- BID CELLING
    IF EXISTS( SELECT COUNT(*) FROM EEO_VENDOR
    WHERE VendorId = @MENTOR)
    BEGIN
    INSERT INTO EEO_MATRIX_INT_SCORE 
    SELECT @MENTOR, @PERIOD_SEQ,1,
    CASE
        WHEN BIDCEILING_AMOUNT IS NULL THEN 0.00
        WHEN BIDCEILING_AMOUNT = 00.00 THEN 0.00
        WHEN BIDCEILING_AMOUNT BETWEEN 100 AND 100000 THEN 1.33
        WHEN BIDCEILING_AMOUNT BETWEEN 100000 AND 200000 THEN 2.67
        WHEN BIDCEILING_AMOUNT BETWEEN 200000 AND 300000.00 THEN 4.00
        WHEN BIDCEILING_AMOUNT BETWEEN 300000.00 AND 400000.00 THEN 5.33
        WHEN BIDCEILING_AMOUNT BETWEEN 400000.00 AND 500000.00 THEN 6.67
        WHEN BIDCEILING_AMOUNT BETWEEN 500000.00 AND 600000.00 THEN 8.00
        WHEN BIDCEILING_AMOUNT BETWEEN 600000.00 AND 700000.00 THEN 9.33
        WHEN BIDCEILING_AMOUNT BETWEEN 700000.00 AND 800000.00 THEN 10.67
        WHEN BIDCEILING_AMOUNT BETWEEN 800000.00 AND 900000.00 THEN 12.00
        WHEN BIDCEILING_AMOUNT BETWEEN 900000.00 AND 1000000.00 THEN 13.33
        WHEN BIDCEILING_AMOUNT BETWEEN 1000000.00 AND 1250000.00 THEN 14.67
        WHEN BIDCEILING_AMOUNT BETWEEN 1250000.00 AND 1500000.00 THEN 16.00
        WHEN BIDCEILING_AMOUNT BETWEEN 1500000.00 AND 1750000.00 THEN 17.33
        WHEN BIDCEILING_AMOUNT BETWEEN 1750000.00  AND 2000000.00 THEN 18.67
        ELSE 20.00
    END, @DT,@SCORED_BY, 'A'
    FROM EEO_MATRIX
    WHERE	VendorId = @MENTOR 
		and INTV_SEQ=@PERIOD_SEQ 
		and ASST_TYPE=  @AsstType
		and WORKFLOWTYPE=  @Workflowtype

    END
    ELSE
    BEGIN
    INSERT INTO EEO_MATRIX_INT_SCORE 
    VALUES (@MENTOR, @PERIOD_SEQ, 1, 0.0, @DT,@SCORED_BY, 'A')
    END
-- BID CELLING
            
     


--BID and AWARD PERCENTAGE
    
    -- No of Bid invitation
  SELECT @BIDI =( SELECT COUNT(*)
                    FROM  VENDOR V,RFDSUPPLIER RS, RFDPROJECT R, CMS_PROJECT_BID A, CMS_BIDDER B, SUPPLIER S
                    WHERE   V.Id = @MENTOR 
                        AND B.C_VENDOR_ID = V.FederalId
                        AND B.C_SOLICIT = A.C_SOLICIT
                        AND B.N_SOLICIT_SEQ = A.N_SOLICIT_SEQ
                        AND A.SD_IFB_DATE BETWEEN @STARTDT AND @ENDDT
                        AND RS.SUPPLIERID=S.ID
                        AND S.FEDERALID=B.C_VENDOR_ID
                        AND RS.RFDPROJECTID=R.ID
                        AND R.SOLICITATIONNO = A.C_SOLICIT
                        AND R.SOLICITSEQ = A.N_SOLICIT_SEQ 
                 )
    
    -- # OF BID SUBMITTED among those invitation
    SELECT @BID =  (SELECT count(PB.C_SOLICIT)  
                    FROM VENDOR V,CMS_BIDDER B, CMS_PROJECT_BID PB
                    WHERE B.N_SOLICIT_SEQ = PB.N_SOLICIT_SEQ
                    AND V.Id = @MENTOR
                    AND B.C_VENDOR_ID =  V.FEDERALID
                    AND PB.SD_ACTUAL_BID_OPEN IS NOT NULL 
                    AND PB.C_SOLICIT IN(SELECT A.C_SOLICIT
                            FROM VENDOR V,
                                 RFDSUPPLIER RS, 
                                 RFDPROJECT R, 
                                 CMS_PROJECT_BID A, 
                                 CMS_BIDDER B, 
                                 SUPPLIER S
                            WHERE   V.Id = @MENTOR
                                AND B.C_VENDOR_ID = V.FEDERALID
                                AND B.C_SOLICIT = A.C_SOLICIT
                                AND B.N_SOLICIT_SEQ = A.N_SOLICIT_SEQ
                                AND A.SD_IFB_DATE BETWEEN @STARTDT AND @ENDDT
                                AND RS.SUPPLIERID=S.ID
                                AND S.FEDERALID=B.C_VENDOR_ID
                                AND RS.RFDPROJECTID=R.ID
                                AND R.SOLICITATIONNO = A.C_SOLICIT
                                AND R.SOLICITSEQ = A.N_SOLICIT_SEQ )
                )
    
 
                    
-- # OF AWARD                            
SELECT @AWARD = (SELECT  COUNT(*)  
                FROM VENDOR V, SUBCONTRACTOR  A, CMS_CONTRACT B   
              WHERE  V.ID= @MENTOR
                     AND A.FEDERALID = V.FEDERALID  
                     AND A.CONTRACTNO = B.C_CONTRACT 
                     AND B.SD_EXECUTION IS NOT NULL
                     AND A.V_C_APPROVED in( 'Y', 'P')
                     AND A.SolicitNo IS NOT NULL
                     AND A.SolicitNo IN( SELECT A.C_SOLICIT 
                                            FROM         VENDOR V,
                                                         RFDSUPPLIER RS, 
                                                         RFDPROJECT R, 
                                                         CMS_PROJECT_BID A, 
                                                         CMS_BIDDER B, 
                                                         SUPPLIER S
                                            WHERE       V.Id = @MENTOR
                                                        AND B.C_VENDOR_ID = V.FEDERALID
                                                        AND B.C_SOLICIT = A.C_SOLICIT
                                                        AND B.N_SOLICIT_SEQ = A.N_SOLICIT_SEQ
                                                        AND A.SD_IFB_DATE BETWEEN @STARTDT AND @ENDDT
                                                        AND RS.SUPPLIERID=S.ID
                                                        AND S.FEDERALID=B.C_VENDOR_ID
                                                        AND RS.RFDPROJECTID=R.ID
                                                        AND R.SOLICITATIONNO = A.C_SOLICIT
                                                        AND R.SOLICITSEQ = A.N_SOLICIT_SEQ ))


            IF @BIDI > 0
                    BEGIN
                        SELECT @PCT = ROUND(@BID / @BIDI, 2) 
                        
                        IF @PCT > 0.5
                        BEGIN
                        INSERT INTO EEO_MATRIX_INT_SCORE 
                        VALUES( @MENTOR, @PERIOD_SEQ, 2,10.0, @DT,@SCORED_BY, 'A')
                        END
                        ELSE
                            IF @PCT > 0.4
                            BEGIN
                            INSERT INTO EEO_MATRIX_INT_SCORE 
                            VALUES( @MENTOR, @PERIOD_SEQ, 2,8.0, @DT,@SCORED_BY, 'A')
                            END
                            ELSE
                                IF @PCT > 0.3
                                BEGIN
                                INSERT INTO EEO_MATRIX_INT_SCORE 
                                VALUES( @MENTOR, @PERIOD_SEQ, 2,6.0, @DT,@SCORED_BY, 'A')
                                END
                                ELSE
                                    IF @PCT > 0.2
                                    BEGIN
                                    INSERT INTO EEO_MATRIX_INT_SCORE 
                                    VALUES( @MENTOR, @PERIOD_SEQ, 2,4.0, @DT,@SCORED_BY, 'A')
                                    END
                                    ELSE
                                        IF @PCT > 0.1
                                        BEGIN
                                        INSERT INTO EEO_MATRIX_INT_SCORE 
                                        VALUES( @MENTOR, @PERIOD_SEQ, 2,2.0, @DT,@SCORED_BY, 'A')
                                        END
                                        ELSE
                                            INSERT INTO EEO_MATRIX_INT_SCORE 
                                            VALUES( @MENTOR, @PERIOD_SEQ, 2,0.0, @DT,@SCORED_BY, 'A')
                        IF @BID > 0
                            BEGIN
                            SELECT @PCT = ROUND(@AWARD / @BID, 2)
                            IF @PCT > 0.5
                            BEGIN
                                INSERT INTO EEO_MATRIX_INT_SCORE 
                                VALUES( @MENTOR, @PERIOD_SEQ, 3,10.0, @DT,@SCORED_BY, 'A')
                            END
                                ELSE
                                IF @PCT > 0.4
                                BEGIN
                                    INSERT INTO EEO_MATRIX_INT_SCORE 
                                    VALUES( @MENTOR, @PERIOD_SEQ, 3,8.5, @DT,@SCORED_BY, 'A')
                                END
                                    ELSE
                                    IF @PCT > 0.3
                                    BEGIN
                                        INSERT INTO EEO_MATRIX_INT_SCORE 
                                        VALUES( @MENTOR, @PERIOD_SEQ, 3,6.6, @DT,@SCORED_BY, 'A')
                                    END
                                        ELSE
                                        IF @PCT > 0.2
                                        BEGIN
                                            INSERT INTO EEO_MATRIX_INT_SCORE 
                                            VALUES( @MENTOR, @PERIOD_SEQ, 3,5.0, @DT,@SCORED_BY, 'A')
                                        END
                                            ELSE
                                            IF @PCT > 0.1
                                            BEGIN
                                                INSERT INTO EEO_MATRIX_INT_SCORE 
                                                VALUES( @MENTOR, @PERIOD_SEQ, 3,3.3, @DT,@SCORED_BY, 'A')
                                            END
                                                ELSE
                                                IF @PCT > 0.05
                                                BEGIN
                                                    INSERT INTO EEO_MATRIX_INT_SCORE 
                                                    VALUES( @MENTOR, @PERIOD_SEQ, 3,1.5, @DT,@SCORED_BY, 'A')
                                                END
                                                    ELSE
                                                    BEGIN
                                                     INSERT INTO EEO_MATRIX_INT_SCORE 
                                                      VALUES( @MENTOR, @PERIOD_SEQ, 3,0.0, @DT,@SCORED_BY,'A')
                                                    ENd
                            END
                        ELSE
                            BEGIN
                            INSERT INTO EEO_MATRIX_INT_SCORE 
                            VALUES( @MENTOR, @PERIOD_SEQ, 3,0.0, @DT,@SCORED_BY, 'A')
                            END
                    END
                ELSE
                    BEGIN
                    INSERT INTO EEO_MATRIX_INT_SCORE 
                    VALUES( @MENTOR, @PERIOD_SEQ, 2,0.0, @DT,@SCORED_BY, 'P')
                    
                    INSERT INTO EEO_MATRIX_INT_SCORE 
                    VALUES( @MENTOR, @PERIOD_SEQ, 3,0.0, @DT,@SCORED_BY, 'P')
                    END

--BID and AWARD PERCENTAGE



 --BONDING AND LOAN
    --BONDING
    IF EXISTS( SELECT 1 FROM EEO_Vendor EV 
                 WHERE EV.VendorId= @MENTOR )
    BEGIN
        INSERT INTO EEO_MATRIX_INT_SCORE 
            SELECT @MENTOR, @PERIOD_SEQ, 4,
                    CASE
                        WHEN V_M_MAX_BOND IS NULL THEN 0.00
                        WHEN V_M_MAX_BOND = 00.00 THEN 0.00
                        WHEN V_M_MAX_BOND BETWEEN 1000.00 AND 250000.00 THEN 3.75
                        WHEN V_M_MAX_BOND BETWEEN 250000.00 AND 500000.00 THEN 7.5
                        WHEN V_M_MAX_BOND BETWEEN 500000.00 AND 750000.00 THEN 11.25
                        WHEN V_M_MAX_BOND > 750000.00  THEN 15.00
                        ELSE 0.0
                    END, @DT,@SCORED_BY, 'A'
                FROM VENDOR V, 
                     SUPPLIERSTATICQUALIFICATION S
                WHERE V.ID=@MENTOR AND V.QUALIFIEDSUPPLIERID=S.SUPPLIERID
    END
    ELSE
    BEGIN
            INSERT INTO EEO_MATRIX_INT_SCORE 
            VALUES( @MENTOR, @PERIOD_SEQ,  4,0.0, @DT,@SCORED_BY, 'A')
    END
    -- LOANS
    SELECT @PCT = 0.0
    SELECT @LOAN = (SELECT COUNT(*) 
        FROM  EEO_LOAN_DETAIL LD
        WHERE LD.VENDORID = @MENTOR 
        AND LD.C_APPROVAL = 'Y'
        AND LD.SD_DECISION_DT BETWEEN @STARTDT AND @ENDDT 
        )
    IF @LOAN = 0
        SELECT @PCT = 0.0
    IF @LOAN = 1 OR @LOAN = 2
        SELECT @PCT = 2.5
    IF @LOAN = 3 OR @LOAN = 4 OR @LOAN = 5
        SELECT @PCT = 5
    IF @LOAN = 6 OR @LOAN = 7 OR @LOAN = 8
        SELECT @PCT = 7.5
    IF @LOAN > 8
        SELECT @PCT = 10
    
    INSERT INTO EEO_MATRIX_INT_SCORE 
          VALUES (@MENTOR, @PERIOD_SEQ, 5, @PCT, @DT,@SCORED_BY, 'A')
    
 --BONDING AND LOAN    
    

                    
            
-- TECH PROJ MGMT
IF EXISTS ( SELECT 1 FROM EEO_LATEST_PPM_RATING 
              WHERE VENDORID = @MENTOR
              AND PERIOD_SEQ = @PERIOD_SEQ)
  BEGIN  

  INSERT INTO EEO_MATRIX_INT_SCORE 
    SELECT  @MENTOR,@PERIOD_SEQ,6,ISNULL(A.SCHEDULING_RT, 0),@DT,@SCORED_BY,A.BASIS
    FROM V_EEO_MENTOR_PPM_RATING A
    WHERE VENDORID = @MENTOR AND PERIOD_SEQ = @PERIOD_SEQ
     

  INSERT INTO EEO_MATRIX_INT_SCORE  
    SELECT @MENTOR, @PERIOD_SEQ, 7,
    ISNULL(A.SAFETY_RT, 0), @DT,@SCORED_BY, A.BASIS
    FROM V_EEO_MENTOR_PPM_RATING A
    WHERE VENDORID = @MENTOR
    AND PERIOD_SEQ = @PERIOD_SEQ
  
  INSERT INTO EEO_MATRIX_INT_SCORE  
    SELECT @MENTOR, @PERIOD_SEQ, 8,
    ISNULL(A.QUALITY_RT, 0), @DT,@SCORED_BY, A.BASIS
    FROM V_EEO_MENTOR_PPM_RATING A
    WHERE VENDORID = @MENTOR
    AND PERIOD_SEQ = @PERIOD_SEQ
    
  INSERT INTO EEO_MATRIX_INT_SCORE  
    SELECT @MENTOR, @PERIOD_SEQ, 9,
    ISNULL(A.MANAGEMENT_RT, 0), @DT,@SCORED_BY, A.BASIS
    FROM V_EEO_MENTOR_PPM_RATING A
    WHERE VENDORID = @MENTOR
    AND PERIOD_SEQ = @PERIOD_SEQ
  
   END
ELSE
 BEGIN
    INSERT INTO EEO_MATRIX_INT_SCORE  
     VALUES (@MENTOR, @PERIOD_SEQ, 6, 0.0, @DT,@SCORED_BY, 'A')
    
    INSERT INTO EEO_MATRIX_INT_SCORE  
        VALUES (@MENTOR, @PERIOD_SEQ, 7, 0.0, @DT,@SCORED_BY, 'A')
    
    INSERT INTO EEO_MATRIX_INT_SCORE  
        VALUES (@MENTOR, @PERIOD_SEQ, 8, 0.0, @DT,@SCORED_BY, 'A')
    
    INSERT INTO EEO_MATRIX_INT_SCORE  
        VALUES (@MENTOR, @PERIOD_SEQ, 9, 0.0, @DT,@SCORED_BY, 'A')
  END
  
-- TECH PROJ MGMT  
  
  
-- TECH PROJ VENDOR_CLASSES
  
  IF EXISTS( SELECT 1  FROM EEO_VENDOR_CLASSES VC , EEO_CLASSES C
                WHERE C.C_CLASS_ID  = VC.C_CLASS_ID 
                    AND C_CLASS_NAME IN ('How To Do Business With the SCA I',
                                            'How to do Business with the SCA')
                    AND VC.C_ATTENDED = 'Y'
                    AND VC.VENDORID = @MENTOR)
    BEGIN
       INSERT INTO EEO_MATRIX_INT_SCORE 
        VALUES (@MENTOR, @PERIOD_SEQ, 10, 3.75, @DT,@SCORED_BY, 'A')
    END
    ELSE
       INSERT INTO EEO_MATRIX_INT_SCORE 
        VALUES (@MENTOR, @PERIOD_SEQ, 10, 0.0, @DT,@SCORED_BY, 'A') 
    
    IF EXISTS( SELECT COUNT(*) 
                FROM EEO_VENDOR_CLASSES VC , EEO_CLASSES C
                WHERE C.C_CLASS_ID  = VC.C_CLASS_ID 
                    AND C_CLASS_NAME = 'Prevailing Wage'
                    AND VC.C_ATTENDED = 'Y'
                    AND VC.VENDORID = @MENTOR)
    BEGIN
       INSERT INTO EEO_MATRIX_INT_SCORE 
        VALUES (@MENTOR, @PERIOD_SEQ, 11, 3.75, @DT,@SCORED_BY, 'A')
    END
    ELSE
       INSERT INTO EEO_MATRIX_INT_SCORE 
        VALUES (@MENTOR, @PERIOD_SEQ, 11, 0.0, @DT,@SCORED_BY, 'A')
    
    IF EXISTS(SELECT COUNT(*) 
            FROM EEO_VENDOR_CLASSES VC , EEO_CLASSES C
            WHERE C.C_CLASS_ID  = VC.C_CLASS_ID 
                AND C_CLASS_NAME = 'Access to Bonding and Capital'
                AND VC.C_ATTENDED = 'Y'
                AND VC.VENDORID = @MENTOR)
    BEGIN
       INSERT INTO EEO_MATRIX_INT_SCORE 
        VALUES (@MENTOR, @PERIOD_SEQ, 12, 3.75, @DT,@SCORED_BY, 'A')
    END
    ELSE
       INSERT INTO EEO_MATRIX_INT_SCORE 
        VALUES (@MENTOR, @PERIOD_SEQ, 12, 0.0, @DT,@SCORED_BY, 'A')
    
    IF EXISTS( SELECT COUNT(*) 
                FROM EEO_VENDOR_CLASSES VC , EEO_CLASSES C
                WHERE C.C_CLASS_ID  = VC.C_CLASS_ID 
                    AND C_CLASS_NAME = 'OSHA 10-Hour'
                    AND VC.C_ATTENDED = 'Y'
                    AND VC.VENDORID = @MENTOR)
    BEGIN
       INSERT INTO EEO_MATRIX_INT_SCORE 
        VALUES (@MENTOR, @PERIOD_SEQ, 13, 3.75, @DT,@SCORED_BY, 'A')
    END
    ELSE
       INSERT INTO EEO_MATRIX_INT_SCORE 
        VALUES (@MENTOR, @PERIOD_SEQ, 13, 0.0, @DT,@SCORED_BY, 'A')
 -- TECH PROJ VENDOR_CLASSES   

 
 
 SELECT 
    S.VENDORID,S.PERIOD_SEQ,S.Q_ID AS QID,C.Q_CATEGORY AS CATEGORY,
    C.Q_DESC  AS [DESC],C.Q_TOTAL_VAL AS MAXSCORE,S.Q_VAL AS SCORE,
    S.DT_SCORED AS SCORED_DATE,S.SCORED_BY,S.BASIS 
FROM dbo.EEO_MATRIX_INT_SCORE S , EEO_MATRIX_INT_CODE C
 WHERE S.Q_ID = C.Q_ID AND VENDORID=@MENTOR AND PERIOD_SEQ=@PERIOD_SEQ  
 ORDER BY S.Q_ID
 

        

END
