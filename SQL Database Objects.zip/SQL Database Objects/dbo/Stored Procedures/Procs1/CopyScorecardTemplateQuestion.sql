﻿
/*
*********************************************************************************************************************
Procedure:	CopyScorecardTemplateQuestion
Purpose:	
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
05/29/2007		Lily Xiong		Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CopyScorecardTemplateQuestion]
	@id int

AS
Begin
Declare @newQuestionId int

Insert Into ScorecardTemplateQuestion
(
	TemplateId,
	CategoryId,
	Name,
	Description,
	Sequence,
	Weight,
	Score,
	IsRequired,
	ScoreMethod
)
Select 
	TemplateId,
	CategoryId,
	Name,
	Description,
	Sequence,
	Weight,
	Score,
	IsRequired,
	ScoreMethod
From ScorecardTemplateQuestion 
Where Id = @id

set @newQuestionId = @@identity

return @newQuestionId

End
