﻿



CREATE procedure [dbo].[CopyCertification]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin
	insert Certification
		(
			SupplierId,
			CertifiedAgent,
			CertificationType,
			CertificationNo,
			EffectiveDate,
			ExpirationDate,
			CertificateId,
			FaxIn,
			Filename,
			CertificationId,
			TransactionId,
			Status,
			AutoVerified,
			Classification,
			Contact,
			Phone,
			ChangeDate,
			ChangeUser
		)
	select
			@newSupplierId,
			CertifiedAgent,
			CertificationType,
			CertificationNo,
			EffectiveDate,
			ExpirationDate,
			CertificateId,
			FaxIn,
			Filename,
			newid(),
			TransactionId,
			Status,
			AutoVerified,
			Classification,
			Contact,
			Phone,
			getdate(),
			@changeUser
	from Certification where supplierId=@supplierId

end



