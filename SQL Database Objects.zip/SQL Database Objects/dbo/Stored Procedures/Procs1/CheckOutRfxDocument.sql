﻿/*
*********************************************************************************************************************
Procedure:	CheckOutRfxDocument
Purpose:	Update CheckOut Info in RfxDocument table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
08/16/2007		Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CheckOutRfxDocument]
	@id int,
	@checkOutId int
as
Update RfxDocument
set
	CheckOutId = @checkOutId,
	CheckOutDate = getdate()
where Id = @id
return  @@RowCount


