﻿
/*
*********************************************************************************************************************
Procedure:	CopyVettingList
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
11/14/2008	Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CopyVettingList]
	@id int,
	@projectId int,
	@libraryId int
AS
Begin

if @libraryId = 0
	Set @libraryId = null

Declare @newId int

-- Insert VettingList
Insert Into VettingList
( 
	Name,
	Description,
	Type,
	HasExpireDate,
	ExpireDate,
	Url,
	InternalUse,
	HasSchedule,
	WorkflowId,
	Status,
	ProjectId,
	LibraryId,
	VettingId
)
Select 
	Name,
	Description,
	Type,
	HasExpireDate,
	ExpireDate,
	Url,
	InternalUse,
	HasSchedule,
	WorkflowId,
	1,
	@projectId,
	@libraryId,
	newid()
From VettingList
Where Id = @id

Set @newId = @@identity

-- Insert VettingSchedule
Insert Into VettingSchedule
(
	VettingId,
	DueType,
	DueDate,
	DueEvent,
	DueNumber,
	DuePeriod,
	Frequency,
	RepeatNumber,
	WeekDays,
	ScheduleType,
	DayOfMonth,
	WeekNumber,
	SelectedMonths,
	EndType,
	EndDate,
	EndEvent,
	EndPeriod,
	RemindNumber,
	RemindPeriod
)
Select
	@newId,
	DueType,
	DueDate,
	DueEvent,
	DueNumber,
	DuePeriod,
	Frequency,
	RepeatNumber,
	WeekDays,
	ScheduleType,
	DayOfMonth,
	WeekNumber,
	SelectedMonths,
	EndType,
	EndDate,
	EndEvent,
	EndPeriod,
	RemindNumber,
	RemindPeriod
From VettingSchedule
Where VettingId = @id

-- Insert VettingQuestion
Declare @questionId int
Declare @newQuestionId int
declare @allQuestion table
(
	Id int,
	ParentId int
)
Insert Into @allQuestion( Id, ParentId ) 
Select Id, ParentId 
From VettingQuestion 
Where VettingId = @id
and IsActive = 'Y'

While (@@rowcount>0)
Begin
	Insert Into @allQuestion( Id, ParentId ) 
	Select Id, ParentId 
	From VettingQuestion 
	Where Id Not In ( Select Id From @allQuestion )
	And ParentId In ( Select Id From @allQuestion )
	And IsActive = 'Y'
End
declare @tempQuestion Table
(
	Id				int,
	ParentId		int,
	QuestionTypeId	int,
	QuestionText	ntext,
	Sequence		int,
	IsRequired		char(1),
	RowNumber		int,
	ColumnNumber	int,
	MaxLength		int,
	AnswerFormat	nvarchar(50),
	MaxValue		nvarchar(50),
	MinValue		nvarchar(50),
	DefaultValue	nvarchar(500),
	RepeatDirection	nvarchar(50),
	Score			int
)
Insert Into @tempQuestion
(
	Id,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,RowNumber,ColumnNumber,
	MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,RepeatDirection,Score
)
Select 
	Id,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,RowNumber,ColumnNumber,
	MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,RepeatDirection,Score
From VettingQuestion
Where Id in ( Select Id From @allQuestion )
--Insert VettingQuestion
While Exists( Select * From @tempQuestion )
Begin
	Select @questionId = Id From @tempQuestion Order By ParentId desc, Id desc
	
	Insert Into VettingQuestion
	(
		VettingId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,RowNumber,ColumnNumber,
		MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,RepeatDirection,Score,IsActive
	)
	Select 
		@newId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,RowNumber,ColumnNumber,
		MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,RepeatDirection,Score, 'Y'
	From @tempQuestion
	Where Id = @questionId
	Set @newQuestionId = @@identity

	--Update record in @tempQuestion, make their QuestionId to new QuestionId
	Update @tempQuestion Set ParentId = @newQuestionId Where ParentId = @questionId
	
	Insert Into VettingAnswer(QuestionId,AnswerText,AnswerValue,Sequence,AnswerType,Score)
	Select @newQuestionId,AnswerText,AnswerValue,Sequence,AnswerType,Score
	From VettingAnswer
	Where QuestionId = @questionId

	Insert Into VettingAttachment(VettingQuestionId,Filename,Description,AttachmentId)
	Select @newQuestionId,Filename,Description,AttachmentId
	From VettingAttachment
	Where VettingQuestionId = @questionId

	Delete @tempQuestion Where Id = @questionId
End

return @newId

End