﻿




CREATE procedure [dbo].[CopyReference]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)

as
begin
	insert Reference
		(
			SupplierId,
			Company,
			Name,
			Phone,
			ReferenceType,
			Service,
			ContractValue,
			ChangeDate,
			ChangeUser

		)
	select
			@newSupplierId,
			Company,
			Name,
			Phone,
			ReferenceType,
			Service,
			ContractValue,
			getdate(),
			@changeUser
	from Reference where supplierId=@supplierId




end







