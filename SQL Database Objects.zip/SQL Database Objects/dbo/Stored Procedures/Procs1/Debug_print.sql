﻿create procedure Debug_print(@procname varchar(100), @debug_stmt varchar(500))
as

begin
insert into debug values (@procname,@debug_stmt)
end
