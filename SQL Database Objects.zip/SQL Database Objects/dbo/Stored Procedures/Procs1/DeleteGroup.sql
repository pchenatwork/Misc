﻿/*
*********************************************************************************************************************
Procedure:	DeleteGroup
Purpose:	Delete a row from Group table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/23/2004		AECSOFT\lily			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteGroup
	@id int
as
BEGIN Transaction
delete GroupMember
where GroupId = @id
delete [Group]
where Id = @id
if @@error = 0
	Commit Transaction
else
	RollBack Transaction
return @@RowCount


