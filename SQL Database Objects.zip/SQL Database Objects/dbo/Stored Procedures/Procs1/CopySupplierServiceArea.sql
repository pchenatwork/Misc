﻿



CREATE procedure [dbo].[CopySupplierServiceArea]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)

as
begin
	insert SupplierServiceArea
		(	
			SupplierId,
			ServiceArea,
			ServiceType
		)
	select
			@newSupplierId,
			ServiceArea,
			ServiceType
	from SupplierServiceArea where supplierId=@supplierId

end




