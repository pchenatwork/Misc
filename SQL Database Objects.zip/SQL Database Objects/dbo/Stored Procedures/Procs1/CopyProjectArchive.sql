﻿
/*
*********************************************************************************************************************
Procedure:	CopyProject
Purpose:	Copy existing record in Project table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
04/29/2011 		Bill Cooper			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CopyProjectArchive]
	@id int,
	@notes varchar(max)
	
as
begin


declare @projectId int
declare @newProjectId int
set @projectId = @id

-- Project
insert into Project ( SolicitationNo,ZipCode,WorkflowId,Type,TransNumber,TransmittalAvailableComments,TransferredFlag,TransferredDate,TransactionId,StatusName,Status,State,SPO,SolicitSeq,SolicitPkgRcvdDate,SolicitPkgRcvdCompleteDate,S01900Comments,S01500Comments,S01010Comments,Room,RfcId,RevisedBidOpeningDateTime,ProjectId,ProjectDuration,PreBidMeetingLoc,PreBidMeetingDateTime,PO,PlanedBidOpeningDateTime,PhasExhComments,PackageNo,OtherRecipients,MinAmt,MaxAmt,LLWNo,IsTransmittalAvailable,IsS01900Completed,IsS01500Completed,IsS01010Completed,IsPreBidMeetingMandatory,IsPhasExhCompleted,IsLimited,IsIEHIncluded,IsEstIncluded,IsChecklistAvailable,IFBDate,IEHIncludedComments,IEHComments,HaveRecordsDelivered,HasSigninLogReceived,HasIEHApproved,HasFIDApproved,HasFIDApprovalBeenGranted,HasDurationSignedOff,HasCPOSignedOff,HasComputerSignedOff,FinancialScores,FIDGrantedComments,FIDComments,EstIncludedComments,DurationSignedComments,DrawingComments,DoesBreakdownRequested,DocsPrice,DocsAvailableDate,DesignNo,Description,Criteria,CPOSignedComments,CPO,Country,CostEstAmt,RevisedCostEstAmt,CostAmt,ContractSpecialist,ContractNo,ComputerSignedComments,Comments,CMRep,City,ChecklistAvailableComments,ChangeUser,ChangeDate,CentralFileDateTime,BreakdownComments,Boro,AwardSupplierId,AwardBidderId,AreDrawingCompleted,AreAlternatesCalledFor,AreAllowancesIncluded,AreAllFirmsLimitedList,AltProjectDuration,AllowanceComments,AllowanceAmt,AERep,AdsMinAmt,AdsMaxAmt,AddressLine2,AddressLine1,ActualDocsAvailableDate,ActualBidOpeningDateTime,ArchiveDate,ArchiveNotes,ArchiveParent)
select SolicitationNo + '-C',ZipCode,WorkflowId,Type,TransNumber,TransmittalAvailableComments,TransferredFlag,TransferredDate,TransactionId,StatusName,Status,State,SPO,SolicitSeq,SolicitPkgRcvdDate,SolicitPkgRcvdCompleteDate,S01900Comments,S01500Comments,S01010Comments,Room,RfcId,RevisedBidOpeningDateTime,ProjectId,ProjectDuration,PreBidMeetingLoc,PreBidMeetingDateTime,PO,PlanedBidOpeningDateTime,PhasExhComments,PackageNo,OtherRecipients,MinAmt,MaxAmt,LLWNo,IsTransmittalAvailable,IsS01900Completed,IsS01500Completed,IsS01010Completed,IsPreBidMeetingMandatory,IsPhasExhCompleted,IsLimited,IsIEHIncluded,IsEstIncluded,IsChecklistAvailable,IFBDate,IEHIncludedComments,IEHComments,HaveRecordsDelivered,HasSigninLogReceived,HasIEHApproved,HasFIDApproved,HasFIDApprovalBeenGranted,HasDurationSignedOff,HasCPOSignedOff,HasComputerSignedOff,FinancialScores,FIDGrantedComments,FIDComments,EstIncludedComments,DurationSignedComments,DrawingComments,DoesBreakdownRequested,DocsPrice,DocsAvailableDate,DesignNo,Description,Criteria,CPOSignedComments,CPO,Country,CostEstAmt,RevisedCostEstAmt,CostAmt,ContractSpecialist,ContractNo,ComputerSignedComments,Comments,CMRep,City,ChecklistAvailableComments,ChangeUser,ChangeDate,CentralFileDateTime,BreakdownComments,Boro,AwardSupplierId,AwardBidderId,AreDrawingCompleted,AreAlternatesCalledFor,AreAllowancesIncluded,AreAllFirmsLimitedList,AltProjectDuration,AllowanceComments,AllowanceAmt,AERep,AdsMinAmt,AdsMaxAmt,AddressLine2,AddressLine1,ActualDocsAvailableDate,ActualBidOpeningDateTime,GETDATE(),@notes,@id from Project
where Id = @projectId


set @newProjectId = @@IDENTITY


-- ProjectRevisedEstimate
insert into ProjectRevisedEstimate (ProjectId,Comments,Amount,ReasonCode,ChangeUser,ChangeDate)
select @newProjectId,Comments,Amount,ReasonCode,ChangeUser,ChangeDate
from ProjectRevisedEstimate 
where ProjectId = @projectId


-- Bidder
insert into Bidder ( TransferredFlag,TransferredDate,SupplierId,Status,SolicitSeq,SolicitationNo,RejectComments,Rank,ProjectId,PickUpDate,MOCSSubmittedDate,MOCSSignedDate,MOCSReceivedDate,IsMocs,IsBidBond,IsBaseOrAlternate,IsBAFO,FinalAmt,DropOffDate,CostEstAmt,Comments,ChangeUser,ChangeDate,BaseAmt,AwardStatus,AmtAdjustment,AlternateAmt9,AlternateAmt8,AlternateAmt7,AlternateAmt6,AlternateAmt5,AlternateAmt4,AlternateAmt3,AlternateAmt2,AlternateAmt10,AlternateAmt1)
select TransferredFlag,TransferredDate,SupplierId,Status,SolicitSeq,SolicitationNo,RejectComments,Rank,@newProjectId,PickUpDate,MOCSSubmittedDate,MOCSSignedDate,MOCSReceivedDate,IsMocs,IsBidBond,IsBaseOrAlternate,IsBAFO,FinalAmt,DropOffDate,CostEstAmt,Comments,ChangeUser,ChangeDate,BaseAmt,AwardStatus,AmtAdjustment,AlternateAmt9,AlternateAmt8,AlternateAmt7,AlternateAmt6,AlternateAmt5,AlternateAmt4,AlternateAmt3,AlternateAmt2,AlternateAmt10,AlternateAmt1 from Bidder
where ProjectId = @projectId


-- Set Award Bidder
update p
set AwardBidderId = nb.Id
,AwardSupplierId = nb.SupplierId
from Bidder ob,Bidder nb,Project p
where ob.SupplierId = nb.SupplierId
and ob.ProjectId = @projectId
and nb.ProjectId = @newProjectId
and p.Id = @newProjectId


-- BidderApprenticeshipProgram
insert into BidderApprenticeshipProgram ( VerifyName,Type,TransferredFlag,TransferredDate,Trade,StartDate,ProgramName,NumberOfYears,Number,EndDate,Comments,ChangeUser,ChangeDate,BidderId,ApprovedTrade,ApprovedNumber,Approved)
select x.VerifyName,x.Type,x.TransferredFlag,x.TransferredDate,x.Trade,x.StartDate,x.ProgramName,x.NumberOfYears,x.Number,x.EndDate,x.Comments,x.ChangeUser,x.ChangeDate,nb.Id,x.ApprovedTrade,x.ApprovedNumber,x.Approved 
from Bidder ob,Bidder nb,BidderApprenticeshipProgram x 
where ob.SupplierId = nb.SupplierId
and ob.ProjectId = @projectId
and nb.ProjectId = @newProjectId
and x.BidderId = ob.Id

-- BidderBreakdown
insert into BidderBreakdown ( Variance,SCACost,EstimateCost,ContractorCost,Comments,ChangeUser,ChangeDate,BreakdownId,BidderId)
select x.Variance,x.SCACost,x.EstimateCost,x.ContractorCost,x.Comments,x.ChangeUser,x.ChangeDate,x.BreakdownId,nb.Id
from Bidder ob,Bidder nb,BidderBreakdown x 
where ob.SupplierId = nb.SupplierId
and ob.ProjectId = @projectId
and nb.ProjectId = @newProjectId
and x.BidderId = ob.Id

-- BidderReject
insert into BidderReject ( TransferredFlag,TransferredDate,RejectCode,ChangeUser,ChangeDate,BidderId)
select x.TransferredFlag,x.TransferredDate,x.RejectCode,x.ChangeUser,x.ChangeDate,nb.Id
from Bidder ob,Bidder nb,BidderReject x 
where ob.SupplierId = nb.SupplierId
and ob.ProjectId = @projectId
and nb.ProjectId = @newProjectId
and x.BidderId = ob.Id

-- BidderWicks
insert into BidderWicks ( PlumbingSupplierId,HVACSupplierId,ElectricalSupplierId,ChangeUser,ChangeDate,BidderId)
select x.PlumbingSupplierId,x.HVACSupplierId,x.ElectricalSupplierId,x.ChangeUser,x.ChangeDate,nb.Id 
from Bidder ob,Bidder nb,BidderWicks x 
where ob.SupplierId = nb.SupplierId
and ob.ProjectId = @projectId
and nb.ProjectId = @newProjectId
and x.BidderId = ob.Id

-- Contract
insert into Contract ( WorkflowId,Type,TransferredFlag,TransferredDate,TransactionId,SupplierId,StatusName,Status,SolicitSeq,SolicitationNo,ProjectId,ProjectDuration,IsLowest,IsBAFO,ExecutionDate,Description,ContractNo,ContractId,Comments,ChangeUser,ChangeDate,BidderId,Amount,AltProjectDuration)
select WorkflowId,Type,TransferredFlag,TransferredDate,TransactionId,SupplierId,StatusName,Status,SolicitSeq,SolicitationNo,@newProjectId,ProjectDuration,IsLowest,IsBAFO,ExecutionDate,Description,ContractNo,ContractId,Comments,ChangeUser,ChangeDate,BidderId,Amount,AltProjectDuration from Contract
where ProjectId = @projectId

-- Package
insert into Package ( WorkflowId,Version,UserType,UserId,Type,TransactionId,Status,RfxDocumentId,ProjectId,PackageId,NeedMerge,Name,IdNo,FileName,Extension,Description,CreatorId,CreateDate,Comments,CheckOutType,CheckOutId,CheckOutDate,ChangeUser,ChangeDate,Attachment,ApprovalType,AddendumId)
select WorkflowId,Version,UserType,UserId,Type,TransactionId,Status,RfxDocumentId,@newProjectId,PackageId,NeedMerge,Name,IdNo,FileName,Extension,Description,CreatorId,CreateDate,Comments,CheckOutType,CheckOutId,CheckOutDate,ChangeUser,ChangeDate,Attachment,ApprovalType,AddendumId from Package
where ProjectId = @projectId

-- PackageHistory
insert into PackageHistory ( Version,UserType,UserId,ProjectId,PackageId,HistoryId,FileName,Extension,Comments,ChangeUser,ChangeDate,Attachment,AddendumId)
select Version,UserType,UserId,@newProjectId,PackageId,HistoryId,FileName,Extension,Comments,ChangeUser,ChangeDate,Attachment,AddendumId from PackageHistory
where ProjectId = @projectId

-- ProjectAddendum
insert into ProjectAddendum ( WorkflowId,Type,TransactionId,StatusName,Status,ProjectId,PickupDate,NumberOfSheets,NumberOfPages,IsDelivered,DoesReproductionRequested,Description,Comments,ChangeUser,ChangeDate)
select WorkflowId,Type,TransactionId,StatusName,Status,@newProjectId,PickupDate,NumberOfSheets,NumberOfPages,IsDelivered,DoesReproductionRequested,Description,Comments,ChangeUser,ChangeDate from ProjectAddendum
where ProjectId = @projectId

-- ProjectAdsCategory
insert into ProjectAdsCategory ( ProjectId,ChangeUser,ChangeDate,CategoryId)
select @newProjectId,ChangeUser,ChangeDate,CategoryId from ProjectAdsCategory
where ProjectId = @projectId

-- ProjectAlternate
insert into ProjectAlternate ( Type,ProjectId,IsSelected,Description,ChangeUser,ChangeDate)
select Type,@newProjectId,IsSelected,Description,ChangeUser,ChangeDate from ProjectAlternate
where ProjectId = @projectId

-- ProjectAward
insert into ProjectAward ( Variance,Type,TransNumber,Task,ProjectId,LLWPercent,LLWNo,IsReso,ExpenditureType,EstLLWAmt,ContractLLWAmt,ChangeUser,ChangeDate,BudgetAmt,AwardNumber,AuthorizedAmt)
select Variance,Type,TransNumber,Task,@newProjectId,LLWPercent,LLWNo,IsReso,ExpenditureType,EstLLWAmt,ContractLLWAmt,ChangeUser,ChangeDate,BudgetAmt,AwardNumber,AuthorizedAmt from ProjectAward
where ProjectId = @projectId

-- ProjectBAFO
insert into ProjectBAFO ( Witness,ProjectId,IsFinal,Comments,ChangeUser,ChangeDate,BidderId,Amount)
select Witness,@newProjectId,IsFinal,Comments,ChangeUser,ChangeDate,BidderId,Amount from ProjectBAFO
where ProjectId = @projectId

-- ProjectBidHistory
insert into ProjectBidHistory ( WorkflowId,TransactionId,SupplierId,StatusName,Status,ProjectId,ChangeUser,ChangeDate,BidderId)
select WorkflowId,TransactionId,SupplierId,StatusName,Status,@newProjectId,ChangeUser,ChangeDate,BidderId from ProjectBidHistory
where ProjectId = @projectId

-- ProjectBidPart
insert into ProjectBidPart ( Type,TransferredFlag,TransferredDate,ReorderQuantity,RefId,ProjectId,PartId,MinReqQuantity,Location,DrawingId,DrawingDesc,Description,ChangeUser,ChangeDate)
select Type,TransferredFlag,TransferredDate,ReorderQuantity,RefId,@newProjectId,PartId,MinReqQuantity,Location,DrawingId,DrawingDesc,Description,ChangeUser,ChangeDate from ProjectBidPart
where ProjectId = @projectId

-- ProjectBidPartLocation
insert into ProjectBidPartLocation ( SchoolName,ProjectId,ProjectBidPartId,Location,IsCentralFile,DocsType,Comments,ChangeUser,ChangeDate)
select SchoolName,@newProjectId,ProjectBidPartId,Location,IsCentralFile,DocsType,Comments,ChangeUser,ChangeDate from ProjectBidPartLocation
where ProjectId = @projectId

-- ProjectComment
insert into ProjectComment ( UserId,Type,Submitted,RefId,ProjectId,CreateDate,Comments,ChangeUser,ChangeDate)
select UserId,Type,Submitted,RefId,@newProjectId,CreateDate,Comments,ChangeUser,ChangeDate from ProjectComment
where ProjectId = @projectId

-- ProjectDocument
insert into ProjectDocument ( Type,RefId,ProjectId,IsApproved,FileName,Comments,ChangeUser,ChangeDate,Attachment)
select Type,RefId,@newProjectId,IsApproved,FileName,Comments,ChangeUser,ChangeDate,Attachment from ProjectDocument
where ProjectId = @projectId

-- ProjectItem
insert into ProjectItem ( ZipCode,TransferredFlag,TransferredDate,SourceOfFunds,SchoolAddressLine2,SchoolAddressLine1,School,ProjectId,PlanYear,LLWDesc,LLW,IsResoA,IsMentor,IsFIDApproved,ChangeUser,ChangeDate,Boro,AuthCostEstAmt,AuthCostAmt)
select ZipCode,TransferredFlag,TransferredDate,SourceOfFunds,SchoolAddressLine2,SchoolAddressLine1,School,@newProjectId,PlanYear,LLWDesc,LLW,IsResoA,IsMentor,IsFIDApproved,ChangeUser,ChangeDate,Boro,AuthCostEstAmt,AuthCostAmt from ProjectItem
where ProjectId = @projectId

-- ProjectOfficial
insert into ProjectOfficial ( UserId,SignDate,ProjectId,ChangeUser,ChangeDate)
select UserId,SignDate,@newProjectId,ChangeUser,ChangeDate from ProjectOfficial
where ProjectId = @projectId

-- ProjectOrder
insert into ProjectOrder ( WorkflowId,TransactionId,StatusName,Status,ProjectId,Priority,OriginalSize,NumberOfSheetsInRoll5,NumberOfSheetsInRoll4,NumberOfSheetsInRoll3,NumberOfSheetsInRoll2,NumberOfSheetsInRoll1,NumberOfSheets,NumberOfRolls,NumberOfPages,NumberOfBooks,Comments,ChangeUser,ChangeDate)
select WorkflowId,TransactionId,StatusName,Status,@newProjectId,Priority,OriginalSize,NumberOfSheetsInRoll5,NumberOfSheetsInRoll4,NumberOfSheetsInRoll3,NumberOfSheetsInRoll2,NumberOfSheetsInRoll1,NumberOfSheets,NumberOfRolls,NumberOfPages,NumberOfBooks,Comments,ChangeUser,ChangeDate from ProjectOrder
where ProjectId = @projectId

-- ProjectOrderDetail
insert into ProjectOrderDetail ( SentToPrinterQuantity,SentToPrinterDate,ReceiptNo,RcvdFromPrinterQuantity,RcvdFromPrinterDate,ProjectOrderId,ProjectId,ProjectBidPartId,PrinterFlag,OrderRcvdDate,OrderedQuantity,ChangeUser,ChangeDate)
select SentToPrinterQuantity,SentToPrinterDate,ReceiptNo,RcvdFromPrinterQuantity,RcvdFromPrinterDate,ProjectOrderId,@newProjectId,ProjectBidPartId,PrinterFlag,OrderRcvdDate,OrderedQuantity,ChangeUser,ChangeDate from ProjectOrderDetail
where ProjectId = @projectId

-- ProjectOrderSupplier
insert into ProjectOrderSupplier ( WorkflowId,TransactionId,SupplierId,StatusName,Status,ProjectOrderId,ProjectId,Priority,Comments,ChangeUser,ChangeDate)
select WorkflowId,TransactionId,SupplierId,StatusName,Status,ProjectOrderId,@newProjectId,Priority,Comments,ChangeUser,ChangeDate from ProjectOrderSupplier
where ProjectId = @projectId

-- ProjectOrderSupplierDetail
insert into ProjectOrderSupplierDetail ( SentToPrinterQuantity,SentToPrinterDate,ReceiptNo,RcvdFromPrinterQuantity,RcvdFromPrinterDate,ProjectOrderSupplierId,ProjectId,ProjectBidPartId,PrinterFlag,OrderRcvdDate,OrderedQuantity,ChangeUser,ChangeDate)
select SentToPrinterQuantity,SentToPrinterDate,ReceiptNo,RcvdFromPrinterQuantity,RcvdFromPrinterDate,ProjectOrderSupplierId,@newProjectId,ProjectBidPartId,PrinterFlag,OrderRcvdDate,OrderedQuantity,ChangeUser,ChangeDate from ProjectOrderSupplierDetail
where ProjectId = @projectId

-- ProjectProperty
insert into ProjectProperty ( Selected,PropertyValue,PropertyText,PropertyId,PropertyDate,ProjectId,ParentId,ChangeUser,ChangeDate,AttachmentName,Attachment)
select Selected,PropertyValue,PropertyText,PropertyId,PropertyDate,@newProjectId,ParentId,ChangeUser,ChangeDate,AttachmentName,Attachment from ProjectProperty
where ProjectId = @projectId

-- ProjectQuestion
insert into ProjectQuestion ( WorkflowId,UserType,UserId,TransactionId,StatusName,Status,Question,ProjectId,IdNo,FileName,CreateDate,ChangeDate,Attachment)
select WorkflowId,UserType,UserId,TransactionId,StatusName,Status,Question,@newProjectId,IdNo,FileName,CreateDate,ChangeDate,Attachment from ProjectQuestion
where ProjectId = @projectId

-- ProjectReport
insert into ProjectReport ( Type,ReportTitle,ReportText,ReportComment,ProjectId,FileName,CreateDate,ChangeUser,ChangeDate,BuyerId,Attachment)
select Type,ReportTitle,ReportText,ReportComment,@newProjectId,FileName,CreateDate,ChangeUser,ChangeDate,BuyerId,Attachment from ProjectReport
where ProjectId = @projectId

-- ProjectSupplier
insert into ProjectSupplier ( SupplierId,Status,ProjectId,Comments,ChangeUser,ChangeDate)
select SupplierId,Status,@newProjectId,Comments,ChangeUser,ChangeDate from ProjectSupplier
where ProjectId = @projectId

-- ProjectTransactionDetail
insert into ProjectTransactionDetail ( TransferredFlag,TransferredDate,Quantity,ProjectTransactionId,ProjectId,ProjectBidPartId,ChangeUser,ChangeDate)
select TransferredFlag,TransferredDate,Quantity,ProjectTransactionId,@newProjectId,ProjectBidPartId,ChangeUser,ChangeDate from ProjectTransactionDetail
where ProjectId = @projectId

-- ProjectTransactionUser
insert into ProjectTransactionUser ( ProjectTransactionId,ProjectId,PrintUserId,LastName,InactiveDate,FirstName,ChangeUser,ChangeDate,AccessUserId,AccessType,AccessCode)
select ProjectTransactionId,@newProjectId,PrintUserId,LastName,InactiveDate,FirstName,ChangeUser,ChangeDate,AccessUserId,AccessType,AccessCode from ProjectTransactionUser
where ProjectId = @projectId


-- ProjectWorkflow
insert into ProjectWorkflow ( WorkflowType,WorkflowId,TransferredFlag,TransactionId,Status, Statusname, ProjectId)
select WorkflowType,WorkflowId,TransferredFlag,-1,Status, Statusname, @newProjectId from ProjectWorkflow
where ProjectId = @projectId

declare @nextTransactionId int
set @nextTransactionId = isnull((select max(TransactionHeaderId) + 1 from WorkflowHistory), 1)

-- set trasaction Ids
update pw 
set TransactionId = x.TransactionId
from ProjectWorkflow pw,
	(
		select pw.Id,((ROW_NUMBER() OVER(ORDER BY pw.id))  - 1 + @nextTransactionId ) as TransactionId
		from ProjectWorkflow pw
		where ProjectId = @newProjectId
	) x
where ProjectId = @newProjectId
and x.Id = pw.Id





insert into WorkflowHistory(TransactionHeaderId,WorkflowId,CurrentNodeId,ApprovalUserId,ApprovalRoleId,ApprovalConditionId,ApprovalDate,PrevHistoryId,Status,IsActive,Comments,DateCreated,CreatedBy,Version,CreatedType,DelegatorId)

select pwn.TransactionId
		,who.WorkflowId
		,who.CurrentNodeId
		,who.ApprovalUserId
		,who.ApprovalRoleId
		,who.ApprovalConditionId
		,who.ApprovalDate
		,who.PrevHistoryId
		,who.Status
		,who.IsActive
		,who.Comments
		,who.DateCreated
		,who.CreatedBy
		,who.Version
		,who.CreatedType
		,who.DelegatorId
from ProjectWorkflow pwo,ProjectWorkflow pwn,WorkflowHistory who
where pwo.WorkflowId = pwn.WorkflowId
and pwo.ProjectId = @projectId
and pwn.ProjectId = @newProjectId
and who.TransactionHeaderId = pwo.TransactionId

end
return  @@identity

