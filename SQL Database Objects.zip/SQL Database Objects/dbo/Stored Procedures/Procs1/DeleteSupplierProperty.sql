﻿



/*
*********************************************************************************************************************
Procedure:	DeleteSupplierProperty
Purpose:	Delete a row from SupplierProperty table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/10/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSupplierProperty]
	@id int
as

delete SupplierProperty
where Id = @id


return @@RowCount






