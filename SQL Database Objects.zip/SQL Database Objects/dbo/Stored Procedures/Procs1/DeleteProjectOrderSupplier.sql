﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectOrderSupplier
Purpose:	Delete a row from ProjectOrderSupplier table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
5/21/2010		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE  procedure [dbo].[DeleteProjectOrderSupplier]
	@id int
as

delete ProjectOrderSupplierDetail
where ProjectOrderSupplierId = @id

delete ProjectOrderSupplier
where Id = @id
return @@RowCount

