﻿CREATE procedure [dbo].[DeleteUser]
	@userId uniqueidentifier
as

Delete UserLog
where UserId in (Select Id From [User] where UserId = @userId)
Delete UserCategory
where UserId in (Select Id From [User] where UserId = @userId)
Delete UserAffiliate
where UserId in (Select Id From [User] where UserId = @userId)
delete [User]
where UserId = @userId
return @@RowCount






