﻿/*
 Rules for Overdue Monthly Assessment counter
    a.	Counter should consider Mentor firms only (should be enrolled into mentor program)
    b.	Should list mentor firms that have any UnSubmitted projects from previous months 
    e.g. if the assessment is supposed to be completed between Dec 15th to Jan 15th. On Jan 16th the vendor should be part of the counter. System should have capability to configure from and to dates.


*/
CREATE PROCEDURE [dbo].[EEO_GetOverdueMontlyAssessmentCounter]
(
	 @userId int,
     @ret int OUTPUT
)
AS
Begin
 DECLARE @tableVar table
    (
         Vendorid int
    )
    Insert into @tableVar
       exec  dbo.EEO_GetOverdueMontlyAssessmentVendors  @userId



    
    SELECT @ret = Count(*)FROM @tableVar
   
    IF (@ret IS NULL) 
        SET @ret = 0;
        
        
   
END
