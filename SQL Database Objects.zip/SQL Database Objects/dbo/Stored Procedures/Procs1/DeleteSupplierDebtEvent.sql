﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierDebtEvent
Purpose:	Delete a row from SupplierDebtEvent table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/11/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierDebtEvent
	@id int
as

delete SupplierDebtEvent
where Id = @id
return @@RowCount

