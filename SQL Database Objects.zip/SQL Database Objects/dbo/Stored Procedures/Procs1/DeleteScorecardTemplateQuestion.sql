﻿
/*
*********************************************************************************************************************
Procedure:	DeleteScorecardTemplateQuestion
Purpose:	Delete a row from ScorecardTemplateQuestion table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/4/2006		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteScorecardTemplateQuestion]
	@id int
as

delete ScorecardTemplateQuestionUserType
where QuestionId = @id

delete ScorecardTemplateQuestion
where Id = @id
return @@RowCount


