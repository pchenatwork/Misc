﻿/*
*********************************************************************************************************************
Procedure:	CopyMenu
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
11/02/2005	Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CopyMenu]
	@id int
AS
Begin
Declare @newId int
-- Insert Menu
Insert Into Menu
( 
	Text, ToolTip, ImgLeft, ImgRight, Url, DisplayOrder, ParentId, ApplicationId, Display, Type
)
Select Text, ToolTip, ImgLeft, ImgRight, Url + '_Copy', DisplayOrder, ParentId, ApplicationId, Display, Type
From Menu
Where Id = @id
Set @newId = @@identity

Insert Into PermissionDetail(PermissionId, MenuId, Type, ControlName, PermissionValue, Description, Status)
Select PermissionId, @newId, Type, ControlName, PermissionValue, Description, Status
From PermissionDetail
Where MenuId = @id

return @newId
End




