﻿CREATE procedure [dbo].[DeletePlanSubcontractorCommentAttachment] 
	@id int
AS

Update PlanSubcontractorComment
Set FileName = null,
	AttachmentId = null
Where Id = @id
return @@rowcount
