﻿/*
*********************************************************************************************************************
Procedure:	DeleteBoilerPlateTransactionDetail
Purpose:	Delete a row from BoilerPlateTransactionDetail table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
1/20/2011		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteBoilerPlateTransactionDetail
	@id int
as

delete BoilerPlateTransactionDetail
where Id = @id
return @@RowCount

