﻿CREATE procedure [dbo].[DeleteLicenseAttachment] 
	@id int
AS

Update License
Set FileName = null,
	CertificateId = null
Where Id = @id
return @@rowcount
