﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierInsuranceClaim
Purpose:	Delete a row from SupplierInsuranceClaim table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/11/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteSupplierInsuranceClaim
	@id int
as

delete SupplierInsuranceClaim
where Id = @id
return @@RowCount

