﻿Create procedure DeleteSupplierEvaluationReference
	@id int
as

delete SupplierEvaluationReference
where Id = @id
return @@RowCount

