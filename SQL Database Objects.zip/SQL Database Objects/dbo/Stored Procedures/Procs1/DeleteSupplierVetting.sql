﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierVetting
Purpose:	Delete a row from SupplierVetting table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/23/2007		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierVetting
	@id int
as

delete SupplierVetting
where Id = @id
return @@RowCount

