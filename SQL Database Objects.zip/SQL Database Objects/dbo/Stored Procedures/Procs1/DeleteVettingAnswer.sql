﻿/*
*********************************************************************************************************************
Procedure:	DeleteVettingAnswer
Purpose:	Delete a row from VettingAnswer table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/22/2007		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteVettingAnswer
	@id int
as

delete VettingAnswer
where Id = @id
return @@RowCount

