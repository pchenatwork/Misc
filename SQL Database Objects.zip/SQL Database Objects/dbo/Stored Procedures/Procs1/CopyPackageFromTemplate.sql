﻿




/*
*********************************************************************************************************************
Procedure:	CopyPackageFromTemplate
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
08/27/2007	Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CopyPackageFromTemplate]
	@projectId int,
	@addendumId int,
	@type nvarchar(20),
	@templateId int,
	@userName nvarchar(50)
AS
Begin
Set NoCount On

--if @type='soliciation' or @type = 'addendum'
--	begin
		begin transaction
		begin try
			-- Insert Package
			Insert Into Package
			( 
				ProjectId,
				AddendumId,
				Type,
				Name,
				Description,
				FileName,
				Extension,
				Version,
				NeedMerge,
				AttachmentId,
				ChangeUser,
				ChangeDate,
				RfxDocumentId,
				PackageId,
				Status
			) 
			Select  
				@projectId,
				@addendumId,
				@type,
				Name, 
				Description,
				FileName,
				Extension,
				'1.0',
				NeedMerge,
				AttachmentId,
				@userName,
				getdate(),
				Id,
				newid(),
				Status
			From RfxDocument
			Where LibraryId = @templateId and Status = 1

			insert PackageHistory
			(
				ProjectId,
				AddendumId,
				PackageId,
				AttachmentId,
				FileName,
				Extension,
				Version,
				ChangeUser,
				ChangeDate,
				HistoryId
			)
			Select
				@projectId,
				@addendumId,
				a.Id,
				a.AttachmentId,
				a.FileName,
				a.Extension,
				a.Version,
				a.ChangeUser,
				getdate(),
				newid()
			From Package a, RfxDocument e
			Where a.ProjectId = @projectId
				and a.AddendumId = @addendumId
				and a.RfxdocumentId = e.Id
				and e.LibraryId = @templateId
			
			commit transaction
			return 1
		end try
		begin catch
			rollback transaction
			return 0
		end catch

--	end
End





