﻿






/*
*********************************************************************************************************************
Procedure:	DeleteRfdProject
Purpose:	Delete a row from RfdProject table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
6/3/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteRfdProject]
	@id int,
	@userName nvarchar(50) =null
as


--insert auditlog
declare @actionTime  datetime
set @actionTime = getdate()
declare @transactionId int
insert into [Transaction](Type, ActionTime) values ('CMS', @actionTime)
select @transactionId = max(id) from [Transaction]	
Insert AuditLog
	(TableName, RecordId, VASId,  MainId, TransactionID, Action, ActionTime, UserName, ProcessedStatus)
	select  'RfdSupplier', rs.id, rs.id, rs.rfdprojectId, @transactionId, 'delete', @actionTime, @userName, 'U'
	from 
		RfdSupplier rs
	inner join
		RfdProject rp
	on 
		rs.RfdProjectId = rp.Id
	where
		rp.Id=@id
		and rs.transferredflag='1'
----------


delete RfdItem
where RfdProjectId = @id

delete RfdComment
where RfdProjectId = @id

delete RfdSupplier
where RfdProjectId = @id

delete RfdProject
where Id = @id
return @@RowCount





