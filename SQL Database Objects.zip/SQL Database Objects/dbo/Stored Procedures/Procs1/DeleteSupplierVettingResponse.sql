﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierVettingResponse
Purpose:	Delete a row from SupplierVettingResponse table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/23/2007		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSupplierVettingResponse]
	@id int
as

delete SupplierVettingResponse
where Id = @id
return @@RowCount

