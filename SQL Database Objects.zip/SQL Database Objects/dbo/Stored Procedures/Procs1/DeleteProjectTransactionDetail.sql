﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectTransactionDetail
Purpose:	Delete a row from ProjectTransactionDetail table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
5/21/2010		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteProjectTransactionDetail
	@id int
as

delete ProjectTransactionDetail
where Id = @id
return @@RowCount

