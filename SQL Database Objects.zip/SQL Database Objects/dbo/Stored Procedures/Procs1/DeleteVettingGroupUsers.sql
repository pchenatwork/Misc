﻿/*
*********************************************************************************************************************
Procedure:	DeleteVettingGroupUsers
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
05/22/2008	Lily Xiong		Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteVettingGroupUsers]
	@vettingGroupId int,
	@vettingGroupUsersXml ntext
AS
Declare @hdoc int
-- Convert VettingGroupUser data from XML to in memory table. 
EXEC sp_xml_preparedocument @hDoc OUTPUT, @vettingGroupUsersXml
Delete From VettingGroupUser
where VettingGroupId = @vettingGroupId
and UserId in (Select UserId FROM OPENXML(@hDoc, '/ArrayOfVettingGroupUser/VettingGroupUser', 1)
	with
	(
		UserId int
	)
)
--Release the internal representation of the XML document.
EXEC sp_xml_removedocument @hDoc
RETURN 1


