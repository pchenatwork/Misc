IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[EEO_GetProjectRatings]'))
   EXEC('CREATE PROCEDURE [dbo].[EEO_GetProjectRatings] AS BEGIN SET NOCOUNT ON; END')
GO
/*
*******************************************************************************
Procedure:	EEO_GetProjectRatings
Purpose:	Get data for "MENTOR->Vendor Management::Scope A Assessment'
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
08/02/2017      PCHEN               Comment section first created
    1. Sync with Staging DB
    2. URS(11-1445800) got purchased by AECom(13-5511947), Combine two EINs into one

2/23/2021       Rekha               Included LSP Projects
*******************************************************************************
*/

 ALTER PROCEDURE [dbo].[EEO_GetProjectRatings]
    -- Add the parameters for the stored procedure here
    @vendorId int,
    @periodId int,
    @userid  int
AS

Begin

SET NOCOUNT ON;

------------------------------
---- PERIOD START AND END DATE 
------------------------------ 

Declare @periodStartDate as Datetime 
Declare @periodEndDate as Datetime 
Declare @periodmonth  as Datetime 
Declare @title as nvarchar(100)
              
selecT  @title = LTRIM(RTRIM(ISNULL(u.Title, ''))) from   [user] u
  where u.Id=@userid
  
---** 20170802 PCH AECOM took over USR, so bind these two EIN together
DECLARE @t_CombinedEINs TABLE (
    TaxID NVARCHAR(100)
)
IF @title IN ('11-1445800', '13-5511947')
    INSERT INTO @t_CombinedEINs VALUES ('11-1445800'), ('13-5511947')
---**SELECT  '@t_CombinedEINs' as tbl, @title as '@title', * FROM @t_CombinedEINs
---**      

Declare @tempPeriod Table
(
    PeriodId int,
    AST_StartDate Datetime,
    AST_EndDate Datetime
)

insert into @tempPeriod
   exec EEO_GetPMAssessmentPeriod @vendorId
   
select @periodStartDate=AST_StartDate ,
       @periodEndDate=AST_EndDate  
from @tempPeriod  where PeriodId=@periodId 

------------------------------
---- PERIOD START AND END DATE 
------------------------------ 
   
 
---** print  'PS-' +  CONVERT(varchar(11), @periodStartDate,101)

---** print  'PE-' +  CONVERT(varchar(11),@periodEndDate, 101)
 

-------------------------
---- PROJECTS WITH DETAILS  
-------------------------

Declare @tempProject  Table
(  
    VENDORID int,
    PERIODID int,
    PROJECT_CODE varchar(10),
    PERIOD_MONTH  datetime,
    START_DATE datetime,
    END_DATE datetime,
    PCT_COMPLETE	int

)

Declare @tempLSPProject  Table
(  
    PROJECT_NAME varchar(22),
    VENDORID int,
    PERIODID int,
    PROJECT_CODE varchar(10),
    LLW_NO varchar(22),
    PERIOD_MONTH  datetime,
    START_DATE datetime,
    END_DATE datetime,
    PCT_COMPLETE	int

)

DECLARE month_cursor CURSOR FOR 
    SELECT DATEADD(month,number,@PeriodStartDate) [PeriodMonth]
        FROM master..spt_values
       WHERE type = 'P'
            AND DATEADD(month,number,@PeriodStartDate) <=  @PeriodEndDate;
        
OPEN month_cursor

FETCH NEXT FROM month_cursor 
    INTO @periodmonth
 
---**   print 'PM-' +  CONVERT(varchar(11), @periodmonth)
        
WHILE @@FETCH_STATUS = 0
BEGIN
 
 
 INSERT INTO  @tempProject (  VENDORID,PERIODID,PROJECT_CODE  ,START_DATE ,END_DATE ,PERIOD_MONTH,PCT_COMPLETE)
         SELECT DISTINCT  
                        V.ID AS VENDORID,
                        @periodId AS PERIODID,
                        PAC.C_PROJ_CODE AS PROJECT_CODE,
                        PAC.CONST_BEGIN AS START_DATE,
                        ISNULL(PAC.CO_DATE, null) AS END_DATE,
                        @periodmonth,
                        CAST(CAST(PAC.PCT_BY_CONTRACT  AS float) AS INT)
                    FROM V_EEO_PROJECT_ORCMS_ACTIVITY PAC 
                            --INNER JOIN VENDOR V ON  ISNULL(PAC.C_VENDOR_ID,PAC.ME_VENDOR_ID)= V.FEDERALID   
                            INNER JOIN VENDOR V ON  PAC.VENDOR_ID= V.FEDERALID   
                WHERE  V.ID=@vendorId 
                AND  ( DATEADD(dd, 1, EOMONTH(@periodmonth, -1))  >= DATEADD(dd, 1, EOMONTH(PAC.CONST_BEGIN , -1)) 
                                AND EOMONTH(@periodmonth) <= EOMONTH(ISNULL(PAC.CO_DATE, GETDATE()) ) )
                AND (@title=''  
                    or (LEN(@title)>0 
                        and isnull(PAC.ME_CONTRACT,'X') in (
                            select c_contract 
                            from MV_SOLICIT_CONTRACT 
                            where C_VENDOR_ID=@title 
                            OR C_VENDOR_ID IN (SELECT TaxID FROM @t_CombinedEINs) 
                            union select 'X'))
                    )

					INSERT INTO  @tempLSPProject (PROJECT_NAME,  VENDORID,PERIODID,PROJECT_CODE,LLW_NO,START_DATE ,END_DATE ,PERIOD_MONTH,PCT_COMPLETE)
         SELECT DISTINCT 
						LSP.ProjectName as PROJECT_NAME,
                        V.ID AS VENDORID,
                        @periodId AS PERIODID,
                        LSP.ProjectCode AS PROJECT_CODE,
						LSP.LLWNo AS LLW_NO,
                        LSP.StartDate AS START_DATE,
                        ISNULL(LSP.EndDate, null) AS END_DATE,
                        @periodmonth,
                       -- CAST(CAST(PAC.PCT_BY_CONTRACT  AS float) AS INT)
					   NULL 
                    FROM VW_LSPProjects LSP                            
                            INNER JOIN VENDOR V ON  LSP.VendorTaxId = V.FEDERALID   
                    WHERE  V.ID=@vendorId 
                   AND  ( DATEADD(dd, 1, EOMONTH(@periodmonth, -1))  >= DATEADD(dd, 1, EOMONTH(LSP.StartDate , -1)) 
                                AND EOMONTH(@periodmonth) <= EOMONTH(ISNULL(LSP.EndDate, GETDATE()) ) )


  FETCH NEXT FROM month_cursor 
    INTO @periodmonth
END 
CLOSE month_cursor;
DEALLOCATE month_cursor;     

-------------------------
---- PROJECTS WITH DETAILS  
-------------------------

-------------------------
---- PROJECTS RATINGS 
-------------------------
  SELECT PR.*,SP.REQUESTEDCOMMENT, SP.SPLASSESSMENTTYPE  FROM 
  
  (   
         SELECT     R.VENDORID,
                    PERIOD_SEQ AS PERIODID,    
                    'Dummy' AS  PROJECT_CODE,
                    R.MONTH_RATED AS  PERIOD_MONTH,
                    NULL AS START_DATE,
                    NULL AS   END_DATE, 
                    R.DATE_RATED,
                    R.SCHEDULING_RT,
                    R.SAFETY_RT,
                    R.QUALITY_RT,
                    R.MANAGEMENT_RT,
                    R.FIN_RT,
                    R.UPDATED_DATE,
                    R.UPDATED_BY,
                    R.BASIS,
                    R.APPROVAL_DATE,
                    R.APPROVED_BY,
                    R.GC_COMMENTS,
                    R.SUB_COMMENTS,
                    R.SCOPE_B_COMMENTS,
                    R.DMP_COMMENTS,
                    0 AS PCT_COMPLETE,
                    ISNULL(R.IS_SUBMITTED,0) as IS_SUBMITTED,
                    ISNULL(R.IS_APPROVED,0) as IS_APPROVED ,
                    R.INFORMALTRAINING,
                    R.INFORMALTRAINING_COMMENTS,
                    R.SPECIALASSESSMENTID,
                    '' as LLW_CODE,
                    '' as LLW_DESC 
        from EEO_LATEST_PPM_RATING R   
            WHERE PROJ_CODE ='Dummy'
               AND R.VENDORID=@vendorId
               AND PERIOD_SEQ=@periodId
               
                
        UNION ALL 
       
  Select     p.VENDORID,
                    p.PERIODID,    
                    P.PROJECT_CODE,
                    P.PERIOD_MONTH,
                    P.START_DATE,
                    P.END_DATE, 
                    R.DATE_RATED,
                    R.SCHEDULING_RT,
                    R.SAFETY_RT,
                    R.QUALITY_RT,
                    R.MANAGEMENT_RT,
                    R.FIN_RT,
                    R.UPDATED_DATE,
                    R.UPDATED_BY,
                    R.BASIS,
                    R.APPROVAL_DATE,
                    R.APPROVED_BY,
                    R.GC_COMMENTS,
                    R.SUB_COMMENTS,
                    R.SCOPE_B_COMMENTS,
                    R.DMP_COMMENTS,
                    ISNULL( R.PCT_COMPLETE,ISNULL( P.PCT_COMPLETE,0))  AS PCT_COMPLETE,
                    ISNULL(R.IS_SUBMITTED,0) as IS_SUBMITTED,
                    ISNULL(R.IS_APPROVED,0) as IS_APPROVED ,
                    R.INFORMALTRAINING,
                    R.INFORMALTRAINING_COMMENTS,
                    R.SPECIALASSESSMENTID,
                    dbo.EEO_GetLlwCodes(P.PROJECT_CODE) AS LLW_CODE ,
                    '' as LLW_DESC
        from EEO_LATEST_PPM_RATING R RIGHT JOIN  @tempProject  P ON R.PROJ_CODE = P.PROJECT_CODE  
                                 
                AND R.VENDORID = P.VENDORID 
                AND R.PERIOD_SEQ  =P.PERIODID
                AND (R.MONTH_RATED BETWEEN DATEADD(dd, 1, EOMONTH(P.PERIOD_MONTH, -1))   AND EOMONTH(P.PERIOD_MONTH)) 

				UNION ALL 
       
  Select     p.VENDORID,
                    p.PERIODID,    
                    P.PROJECT_CODE,
                    P.PERIOD_MONTH,
                    P.START_DATE,
                    P.END_DATE, 
                    R.DATE_RATED,
                    R.SCHEDULING_RT,
                    R.SAFETY_RT,
                    R.QUALITY_RT,
                    R.MANAGEMENT_RT,
                    R.FIN_RT,
                    R.UPDATED_DATE,
                    R.UPDATED_BY,
                    R.BASIS,
                    R.APPROVAL_DATE,
                    R.APPROVED_BY,
                    R.GC_COMMENTS,
                    R.SUB_COMMENTS,
                    R.SCOPE_B_COMMENTS,
                    R.DMP_COMMENTS,
                    ISNULL( R.PCT_COMPLETE,ISNULL( P.PCT_COMPLETE,0))  AS PCT_COMPLETE,
                    ISNULL(R.IS_SUBMITTED,0) as IS_SUBMITTED,
                    ISNULL(R.IS_APPROVED,0) as IS_APPROVED ,
                    R.INFORMALTRAINING,
                    R.INFORMALTRAINING_COMMENTS,
                    R.SPECIALASSESSMENTID,
                    P.LLW_NO, -- dbo.EEO_GetLlwCodes(P.PROJECT_CODE) AS LLW_CODE ,
                    '' as LLW_DESC
        from  EEO_LATEST_PPM_RATING R RIGHT JOIN @tempLSPProject  P ON R.PROJ_CODE = P.PROJECT_CODE  
                                 
                AND R.VENDORID = P.VENDORID 
                AND R.PERIOD_SEQ  =P.PERIODID
                AND (R.MONTH_RATED BETWEEN DATEADD(dd, 1, EOMONTH(P.PERIOD_MONTH, -1))   AND EOMONTH(P.PERIOD_MONTH)) 
         ) PR  LEFT JOIN EEO_SPECIAL_ASSESSMENT SP  ON PR.SPECIALASSESSMENTID = SP.ID
ORDER BY  PR.PERIOD_MONTH, PR.PROJECT_CODE
       

-------------------------
---- PROJECTS RATINGS 
-------------------------  
   
  
END