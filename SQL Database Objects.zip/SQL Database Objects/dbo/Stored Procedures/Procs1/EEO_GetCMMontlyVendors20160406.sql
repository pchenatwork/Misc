﻿ 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

/*
*********************************************************************************************************************
Procedure:	 
Purpose:	 
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
09/11/2015		Syed			    Created
9/30/2015		Pasha				isnull(m.D_CONSTR_END,getdate()) added
									Made change to filter for Mentor firms only. Added
									Used eeo_latest_ppm_rating instead of using eeo_mentor_ppm_rating 
									Modified the end logic of getting counter
*********************************************************************************************************************
*/
CREATE PROCEDURE [dbo].[EEO_GetCMMontlyVendors20160406]
AS

Begin

Declare @vendorid as int
Declare @prev_vendorid as int
Declare @startDate as Datetime 
Declare @endDate as Datetime 


Declare @DayOfMonth Int  
Declare @Month Int
Declare @Year Int
Declare @EndYear Int
Declare @PeriodId Int

set @PeriodId= 1
set @prev_vendorid= 0


DECLARE @ret int;


Declare @tempVendorPeriod Table
(
    Id int identity (1,1) Primary Key,
    PeriodId decimal(5,0),
    Vendorid int,
  	Period_StartDate Datetime,
    Period_EndDate Datetime
)
 
  

Declare @Days4MentorOverdueYearlyAssessment int 

Select @Days4MentorOverdueYearlyAssessment = ISNULL([value],0) from dbo.EEO_CONFIG
   	where [key] = 'Days4MentorOverdueYearlyAssessment'



DECLARE eeo_vendor_cursor CURSOR FOR 
		SELECT distinct GD.VENDORID,
				DATEFROMPARTS(YEAR(GD.SD_START_DATE),MONTH(GD.SD_START_DATE),1)  AS STARTDATE,   -- start of the month
				EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS ENDDATE  --  USE SD_EXT_GRAD_DATE FIRST OTHERWISE SD_GRAD_DATE AND EXCLUDE FINAL YEAR
		FROM (SELECT * FROM  DBO.EEO_MENTOR_GRAD_DETAIL 
						WHERE ID IN  
								(SELECT MAX(ID) AS ID   FROM DBO.EEO_MENTOR_GRAD_DETAIL  -- MAX RECORD FOR VENDOR WITH C_MENTOR_TYPE
									WHERE    C_MENTOR_TYPE='MENTOR'
									GROUP BY VENDORID,C_MENTOR_TYPE 
									)
		) GD , EEO_VENDOR EV, VENDOR V  
		WHERE  GD.VENDORID=EV.VENDORID
				AND EV.VENDORID =V.ID
				AND EV.MENTORFLAG IN (6) -- only those vendors marked as  MENTOR


 
OPEN eeo_vendor_cursor
	FETCH NEXT FROM eeo_vendor_cursor 
		INTO @vendorid, @startDate,@endDate

	WHILE @@FETCH_STATUS = 0
	BEGIN

		   Insert Into @tempVendorPeriod
			(   PeriodId ,
				Vendorid,
				Period_StartDate, 
				Period_EndDate  
			 )
			  SELECT number+1,
					 @vendorid,
					 DATEADD(year,number,@startDate) PeriodStart,
					 DATEADD(year,number+1,@startDate) PeriodEnd 
			from master..spt_values sv
				 where sv.type = 'P' AND DATEADD(year,number+1,@startDate) <= DATEADD(day, @Days4MentorOverdueYearlyAssessment,@endDate) 

			-- Get the next vendor.
	FETCH NEXT FROM eeo_vendor_cursor 
		INTO @vendorid, @startDate,@endDate
	END 

CLOSE eeo_vendor_cursor;
DEALLOCATE eeo_vendor_cursor;


Select distinct pm.vendorid
	from 
		(
			SELECT Vendorid,PeriodId ,Period_StartDate,Period_EndDate, DATEADD(month,number+1,Period_StartDate) PeriodMonth
			from 
				@tempVendorPeriod t, master..spt_values sv
			where sv.type = 'P' and DATEADD(month,number+1,t.Period_StartDate) <t.Period_EndDate
		) pm 
		inner join vendor v on v.id=pm.vendorid
		left outer join  MV_SOLICIT_CONTRACT m on m.ME_VENDOR_ID=v.FederalId
	where 
		( 
				DATEADD(dd, 1, EOMONTH(pm.PeriodMonth, -1))  >= DATEADD(dd, 1, EOMONTH(m.D_CONSTR_BEGIN , -1)) 
			AND EOMONTH(pm.PeriodMonth) <= EOMONTH(isnull(m.D_CONSTR_END,getdate())) 
		)
    and PeriodMonth  <= GETDATE() --  check only period months less then or equal to today date
 	and GETDATE() BETWEEN PeriodMonth  AND EOMONTH(PeriodMonth) --  
	and  not exists (
				select * 
				from eeo_latest_ppm_rating  
				where vendorid=pm.vendorid
					and PROJ_CODE=m.c_package_code
					and EOMONTH(MONTH_RATED)=	EOMONTH(PeriodMonth)	 -- very important						
					and isnull(IS_SUBMITTED,0)=1
		)	
 
    
END
