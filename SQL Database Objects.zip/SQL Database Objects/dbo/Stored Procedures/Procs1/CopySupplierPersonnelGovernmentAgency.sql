﻿





CREATE procedure [dbo].[CopySupplierPersonnelGovernmentAgency]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin

------------Generate DocumentIds
declare @tempDocument table
(
	Id int,
	documentId nvarchar(4000)
)

declare @tempDocument2 table
(
	Id int,
	documentIds nvarchar(4000)
)


insert into @tempDocument
(	
	id,
	documentId
)
select t.id, convert(nvarchar(4000), sp.id) from 
	(SELECT s.id, substring('|' + s.documentIds + '|', t.N + 1, charindex('|', '|' + s.documentIds + '|', t.N + 1) - t.N - 1) as documentId
		FROM Tally t,  SupplierPersonnelGovernmentAgency s
		WHERE substring('|' + s.documentIds + '|', t.N, 1) = '|'
		AND t.N < len('|' + s.documentIds + '|')
		and s.supplierid=@supplierId) t, 
	SupplierDocument sp
	where t.documentId = sp.copyid
	and sp.supplierid=@newSupplierId


;WITH CTE ( Id, documentIds, documentId, length ) 
      AS ( SELECT Id, CAST( '' AS NVARCHAR(4000) ), CAST( '' AS NVARCHAR(4000) ), 0
             FROM @tempDocument
            GROUP BY Id
            UNION ALL
           SELECT t.Id, CAST( c.documentIds + 
                  CASE WHEN length = 0 THEN '' ELSE '|' END + t.documentId AS NVARCHAR(4000) ), 
                  CAST( t.documentId AS NVARCHAR(4000)), length + 1
             FROM CTE c
            INNER JOIN @tempDocument t
               ON c.Id = t.Id
            WHERE t.documentId > c.documentId )

insert into @tempDocument2
(	
	Id,
	documentIds
)
SELECT Id, documentIds 
			FROM ( SELECT Id, documentIds, 
						RANK() OVER ( PARTITION BY Id ORDER BY length DESC )
				   FROM CTE ) D ( Id, documentIds, rank )
			WHERE rank = 1 



--------Copy rows	
	
	insert SupplierPersonnelGovernmentAgency
		(
			SupplierId,
			Position,
			OrganizationName,
			Relationship,
			StartDate,
			EndDate,
			QuestionIds,
			PersonnelId,
			DocumentIds,
			ChangeDate,
			ChangeUser
		)
	select
			@newSupplierId,
			Position,
			OrganizationName,
			Relationship,
			StartDate,
			EndDate,
			QuestionIds,
			sp.id,
			td.DocumentIds,
			getdate(),
			@changeUser
	from SupplierPersonnelGovernmentAgency s
	left join @tempDocument2 td
	on s.Id = td.Id
	left join supplierpersonnel sp
	on s.personnelId = sp.copyId
	where s.supplierId=@supplierId
	and DateDiff(day, s.EndDate, DateAdd(year, -5, getdate())) < 0

end









