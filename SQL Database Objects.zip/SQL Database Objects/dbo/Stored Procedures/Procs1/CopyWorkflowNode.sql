﻿
/*
*********************************************************************************************************************
Procedure:	CopyWorkflowNode
Purpose:	Copy existing workflownode into WorkflowNode table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
06/09/2006 		Lily Xiong		Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CopyWorkflowNode]
	@id int	
as
begin
	Declare @newId int
	
	Insert into WorkflowNode
	(
		WorkflowId,
		UserStepId,
		Name,
		Description,
		Type,
		ConditionId,
		NodeFromId,
		NodeToId,
		TimeToSkip,
		Counter,
		IsSkip,
		IsPermCtrl,
		Action1,
		Action2,
		Action3,
		Action4,
		Action5,
		Action6,
		EmailAction
	)
	Select	WorkflowId,
		UserStepId,
		Name + '_Copy',
		Description,
		Type,
		ConditionId,
		NodeFromId,
		NodeToId,
		TimeToSkip,
		Counter,
		IsSkip,
		IsPermCtrl,
		Action1,
		Action2,
		Action3,
		Action4,
		Action5,
		Action6,
		EmailAction
	From WorkflowNode
	Where Id = @id
	
	Set @newId = @@identity

	Insert Into WorkflowCondition
	(
		WorkflowNodeId,
		Name,
		Type,
		Description,
		DisplayOrder,
		DisplayName,
		ErrorMessage,
		FunctionName,
		FunctionValue,
		Condition,
		ConditionXml,
		Score,
		Status
	)
	select @newId,
		Name,
		Type,
		Description,
		DisplayOrder,
		DisplayName,
		ErrorMessage,
		FunctionName,
		FunctionValue,
		Condition,
		ConditionXml,
		Score,
		Status
	From WorkflowCondition
	where WorkflowNodeId = @id

	Insert Into WorkflowAction
	(
		WorkflowNodeId,
		Name,
		Type,
		Description,
		DisplayOrder,
		DisplayName,
		FunctionName,
		FunctionValue,
		Status
	)
	select @newId,
		Name,
		Type,
		Description,
		DisplayOrder,
		DisplayName,
		FunctionName,
		FunctionValue,
		Status
	From WorkflowAction
	where WorkflowNodeId = @id

	Insert Into WorkflowNodeUser
	(
		WorkflowNodeId,
		UserId,
		Status,
		RoleId
	)
	select @newId,
		UserId,
		Status,
		RoleId
	From WorkflowNodeUser
	where WorkflowNodeId = @id

	return @newId
end



