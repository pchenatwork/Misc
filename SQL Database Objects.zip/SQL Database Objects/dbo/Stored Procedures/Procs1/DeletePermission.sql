﻿



CREATE procedure [dbo].[DeletePermission]
	@id int
as

delete PermissionDetail where PermissionId = @id
delete Permission where Id = @id

return @@RowCount







