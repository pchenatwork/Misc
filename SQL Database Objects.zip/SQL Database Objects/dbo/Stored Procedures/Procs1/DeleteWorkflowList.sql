﻿CREATE procedure [dbo].[DeleteWorkflowList]
	@id int
as

delete WorkflowNodeUser
Where WorkflowNodeId in (Select Id From WorkflowNode Where WorkflowId = @id)

delete WorkflowAction
Where WorkflowNodeId in (Select Id From WorkflowNode Where WorkflowId = @id)

delete WorkflowCondition
Where WorkflowNodeId in (Select Id From WorkflowNode Where WorkflowId = @id)

delete WorkflowNode
where WorkflowId = @id

delete WorkflowList
where Id = @id

return @@RowCount


