﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE Procedure [dbo].[EEO_CheckMentor1Year]
	-- Add the parameters for the stored procedure here
	@vendorId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	--SET NOCOUNT ON;

    -- Insert statements for procedure here
	declare @currentStatus varchar(50)
	declare @count int
	

	set @count =(
					select 
						count(*)
					from 
						eeo_mentor_grad_detail e
					where vendorId=@vendorId 
						and datediff(D,isnull(SD_ACTUAL_GRAD_DT,'1/1/2100'),getdate())>365 
						and C_MENTOR_TYPE='MENTOR'
						and		not exists(select * from eeo_mentor_grad_detail where vendorid=e.VENDORID and C_MENTOR_TYPE='GRAD MENTOR')
				)
		


	select @count
	return @count
END
