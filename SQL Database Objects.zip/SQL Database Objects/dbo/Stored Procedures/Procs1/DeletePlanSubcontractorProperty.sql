﻿/*
*********************************************************************************************************************
Procedure:	DeletePlanSubcontractorProperty
Purpose:	Delete a row from PlanSubcontractorProperty table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/24/2010		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure DeletePlanSubcontractorProperty
	@id int
as

delete PlanSubcontractorProperty
where Id = @id
return @@RowCount

