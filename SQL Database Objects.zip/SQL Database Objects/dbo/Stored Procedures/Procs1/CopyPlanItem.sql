﻿










CREATE procedure [dbo].[CopyPlanItem]	
	@planId int, 
	@newPlanId int,
	@changeUser nvarchar(50)
as
begin
	insert [PlanItem]
		( 
			PlanId, 
			LLW, 
			School, 
			SchoolAddressLine1, 
			SchoolAddressLine2, 
			Boro, 
			ZipCode, 
			LLWDesc, 
			ChangeUser, 
			ChangeDate
		)
	select  
			@newPlanId, 
			LLW, 
			School, 
			SchoolAddressLine1, 
			SchoolAddressLine2, 
			Boro, 
			ZipCode, 
			LLWDesc, 
			@changeUser, 
			GETDATE()
	from
		[PlanItem]
	where
		planId=@planId
	
end



 


































