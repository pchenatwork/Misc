﻿


CREATE procedure [dbo].[EEO_AssessmentFullRpt_syed]
	@vendorId int,
	@assessPeriod int
as
begin




declare @Days4AdjustingYears int 
declare @AssessmentStartDateGracePeriod int 
declare @AssessmentEndDateGracePeriod int 


Select @Days4AdjustingYears= ISNULL([value],0) from dbo.EEO_CONFIG
where [key] = 'Days4AdjustingYears'

 Select @AssessmentStartDateGracePeriod= ISNULL([value],0) from dbo.EEO_CONFIG
where [key] = 'AssessmentStartDateGracePeriod'

Select @AssessmentEndDateGracePeriod= ISNULL([value],0) from dbo.EEO_CONFIG
where [key] = 'AssessmentEndDateGracePeriod'


Declare @tempVendorPeriod Table
(
		Id int identity (1,1) Primary Key,
		PeriodId decimal(5,0),
		Vendorid int,
		Period_StartDate Datetime,
		Period_EndDate Datetime,
		MentorType varchar(30),
		AssessmentType char(1)
)

       
       
                           INSERT INTO @tempVendorPeriod
                                  (   
                                         Vendorid,
                                         PeriodId ,
                                         Period_StartDate, 
                                         Period_EndDate ,
                                         MentorType,
                                         AssessmentType
                                         )
                                  SELECT DISTINCT VENDORID,  NUMBER+1 AS PERIODID,
                                                DATEADD(YEAR,NUMBER,START_DATE) AS AST_StartDate,
                                                DATEADD(YEAR,NUMBER+1,START_DATE)  AS AST_EndDate,
                                             'MENTOR' AS MENTOR_TYPE,
                                                'Y' AS ASSESSMEN_TTYPE
                                  FROM MASTER..SPT_VALUES , 
                                                                     (      SELECT DISTINCT  
                                                                                                GD.VENDORID,
                                                                                                DATEFROMPARTS(YEAR(GD.SD_START_DATE),MONTH(GD.SD_START_DATE),1)  AS START_DATE,   -- start of the month
                                                                                                EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS END_DATE,  --  USE SD_EXT_GRAD_DATE FIRST OTHERWISE SD_GRAD_DATE AND EXCLUDE FINAL YEAR
                                                                                                EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS ACTUAL_END_DATE ,
                                                                                                GD.C_MENTOR_TYPE              
                                                                           FROM (SELECT * FROM  DBO.EEO_MENTOR_GRAD_DETAIL 
                                                                                                WHERE ID IN  
                                                                                                              (SELECT MAX(ID) AS ID   FROM DBO.EEO_MENTOR_GRAD_DETAIL  -- MAX RECORD FOR VENDOR WITH C_MENTOR_TYPE
                                                                                                                    WHERE C_MENTOR_TYPE='MENTOR' --  Mentor firms only
                                                                                                                     GROUP BY VENDORID,C_MENTOR_TYPE 
                                                                                                                     )
                                                                                        ) GD  , EEO_VENDOR EV
                                                                           WHERE GD.VENDORID=EV.VENDORID
                                                                                         AND EV.MENTORFLAG IN (6) -- only those vendors marked as  MENTOR
                                                                     ) AS P
                                  WHERE TYPE = 'P'
                                  AND DATEADD(YEAR,NUMBER+1,P.START_DATE)   <= 
                                                DATEADD( DAY, ISNULL(365-ISNULL(@AssessmentEndDateGracePeriod,0),0), P.END_DATE )   

                                  UNION

                                  SELECT DISTINCT VENDORID,  NUMBER+1 AS PERIODID,
                                                DATEADD(YEAR,NUMBER,START_DATE) AS AST_StartDate,
                                                DATEADD(YEAR,NUMBER+1,START_DATE)  AS AST_EndDate,
                                                'GRAD MENTOR'  AS MENTOR_TYPE,
                                                'Y' AS ASSESSMEN_TTYPE
                                  FROM MASTER..SPT_VALUES , 
                                                                     (      SELECT DISTINCT  
                                                                                                GD.VENDORID,
                                                                                                DATEFROMPARTS(YEAR(GD.SD_START_DATE),MONTH(GD.SD_START_DATE),1)  AS START_DATE,   -- start of the month
                                                                                                EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS END_DATE,  --  USE SD_EXT_GRAD_DATE FIRST OTHERWISE SD_GRAD_DATE AND EXCLUDE FINAL YEAR
                                                                                                EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS ACTUAL_END_DATE ,
                                                                                                GD.C_MENTOR_TYPE              
                                                                           FROM (SELECT * FROM  DBO.EEO_MENTOR_GRAD_DETAIL 
                                                                                                WHERE ID IN  
                                                                                                              (SELECT MAX(ID) AS ID   FROM DBO.EEO_MENTOR_GRAD_DETAIL  -- MAX RECORD FOR VENDOR WITH C_MENTOR_TYPE
                                                                                                                    WHERE C_MENTOR_TYPE='GRAD MENTOR' --  Mentor firms only
                                                                                                                     GROUP BY VENDORID,C_MENTOR_TYPE 
                                                                                                                     )
                                                                                        ) GD  , EEO_VENDOR EV
                                                                            WHERE GD.VENDORID=EV.VENDORID
                                                                                         AND EV.MENTORFLAG IN (7) -- only those vendors marked as  MENTOR
                                                                     ) AS P
                                  WHERE TYPE = 'P'
                                  AND DATEADD(YEAR,NUMBER+1,P.START_DATE)   <= 
                                                DATEADD( DAY, ISNULL(365-ISNULL(@AssessmentEndDateGracePeriod,0),0), P.END_DATE )  
                                    
                                  ORDER BY  VENDORID,MENTOR_TYPE




                      UPDATE @tempVendorPeriod 
                           SET AssessmentType='F' 
                     From @tempVendorPeriod tmpp
                                  WHERE PeriodId = (
                                         SELECT max(PeriodId) FROM @tempVendorPeriod tmp
                                            WHERE  tmp.Vendorid=tmpp.Vendorid
                                            group by Vendorid
                           ) 



	
		
		select 
			v.id VendorId,
			convert(varchar, c.PeriodId)+': ' + convert(char(12), c.Period_StartDate)+' to '+convert(char(12), c.Period_EndDate) period,
			v.FederalId, 
			v.Company,
			a.dt_scored Date_Scored,
			isnull(a.score,0) Assessment_score,
			isnull(b.score,0) Internal_Score,
			isnull(a.score,0) * .4 + isnull(b.score,0) * .6 combined_Score,
			m.mentor_yr 
		 from eeo_matrix m
			inner join vendor v on m.vendorid = v.id 
			inner join @tempVendorPeriod c   	on m.vendorid = c.Vendorid and m.INTV_SEQ = c.PeriodId
			left outer join eeo_v_matrix_score a on a.vendorid = m.vendorid  and  m.INTV_SEQ = a.INTV_SEQ
			left outer join eeo_v_matrix_int_score b on m.vendorid = b.vendorid and m.INTV_SEQ = b.PERIOD_SEQ  
		where  (@vendorId = -1 or   m.VENDORID = @vendorId)
			and (@assessPeriod = -1 or m.INTV_SEQ = @assessPeriod)
			and m.ASST_TYPE ='Y'
			and m.INTV_COMPLETED=1
		order by v.Company, c.id





end
