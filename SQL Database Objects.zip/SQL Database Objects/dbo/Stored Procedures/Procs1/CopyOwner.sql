﻿


CREATE procedure [dbo].[CopyOwner]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin
	insert Owner
		(
			SupplierId,
			Name,
			Title,
			Phone,
			Extension,
			Fax,
			Email,
			Gender,
			Ethnicity,
			Percentage,
			YearsExperience,
			Filename,
			Resume,
			OwnerId,
			ChangeUser,
			Prefix,
			MiddleName,
			DOB,
			SSN,
			RegistrationNumber,
			IsOwner,
			AddressLine1,
			AddressLine2,
			City,
			Country,
			State,
			ZipCode,
			StartDate,
			CommencementDate,
			EndDate,
			Description,
			NotarizedCertification,
			TotalAmount,
			PaidAmount,
			NumberOfShares,
			SharesDate,
			HowSharesAcquired,
			CommonOrPreferred

		)
	select
			@newSupplierId,
			Name,
			Title,
			Phone,
			Extension,
			Fax,
			Email,
			Gender,
			Ethnicity,
			Percentage,
			YearsExperience,
			Filename,
			Resume,
			newid(),
			ChangeUser,
			Prefix,
			MiddleName,
			DOB,
			SSN,
			RegistrationNumber,
			IsOwner,
			AddressLine1,
			AddressLine2,
			City,
			Country,
			State,
			ZipCode,
			StartDate,
			CommencementDate,
			EndDate,
			Description,
			NotarizedCertification,
			TotalAmount,
			PaidAmount,
			NumberOfShares,
			SharesDate,
			HowSharesAcquired,
			CommonOrPreferred
	from Owner where supplierId=@supplierId

end





