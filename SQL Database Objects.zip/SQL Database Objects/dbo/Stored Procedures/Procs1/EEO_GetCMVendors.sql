﻿/*
*********************************************************************************************************************
Procedure:	 
Purpose:	 
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
09/11/2015		Syed			    Created
*********************************************************************************************************************
*/
CREATE PROCEDURE [dbo].[EEO_GetCMVendors]
(
    @mentorType varchar(30),
    @completionStartInterval int,
    @completionEndInterval int
)
AS

Begin

Declare @vendorid as int
Declare @prev_vendorid as int
Declare @startDate as Datetime 
Declare @gradDate as Datetime 


Declare @DayOfMonth Int  
Declare @Month Int
Declare @Year Int
Declare @GradYear Int
Declare @PeriodId Int

set @PeriodId= 1
set @prev_vendorid= 0


DECLARE @ret int;


Declare @temp1 Table
(
    Id int identity (1,1) Primary Key,
    PeriodId decimal(5,0),
    Vendorid int,
  	Period_StartDate Datetime,
    Period_EndDate Datetime,
   	Completion_StartDate Datetime,
    Completion_EndDate Datetime
)
 
    DECLARE vendor_cursor CURSOR FOR 
        SELECT DISTINCT VENDORID ,  SD_START_DATE AS STARTDATE , SD_GRAD_DATE AS GRADDATE
            FROM dbo.EEO_MENTOR_GRAD_DETAIL WHERE C_MENTOR_TYPE =@mentorType
     
    OPEN vendor_cursor
        
        FETCH NEXT FROM vendor_cursor 
            INTO @vendorid, @startDate,@gradDate
            
        WHILE @@FETCH_STATUS = 0
        BEGIN
              SELECT 
                  @DayOfMonth = DAY ( @startDate ),
                  @Month = MONTH  ( @startDate ),
                  @Year =YEAR ( @startDate ),
                  @GradYear= YEAR(@gradDate)  

                  
                WHILE @Year < @GradYear-1
                BEGIN
                
                IF @prev_vendorid = @vendorid  
                    BEGIN
                     set @PeriodId = @PeriodId + 1    
                    END   
                ELSE
                    set @PeriodId =1
                    
                    
                    Insert Into @temp1
                    (   PeriodId ,
                        Vendorid,
                        Period_StartDate, 
                        Period_EndDate,
                        Completion_StartDate,
                        Completion_EndDate
                    )
                    select    @PeriodId,
                              @vendorid,
                              DateAdd(day, @DayOfMonth - 1, 
                                  DateAdd(month, @Month - 1, 
                                      DateAdd(Year, @Year-1900  , 0))),
                                      
                                      
                           EOMONTH( DateAdd(day, @DayOfMonth- 1, 
                                  DateAdd(month, @Month - 1, 
                                      DateAdd(Year, @Year-1900 +1, 0)))),
                           
                         DateAdd(week,@completionStartInterval ,  
                            DateAdd(day, @DayOfMonth- 1, 
                                  DateAdd(month, @Month - 1, 
                                      DateAdd(Year, @Year-1900 +1, 0)))),
                           
                          DateAdd(month,@completionEndInterval, 
                            DateAdd(day, @DayOfMonth- 1, 
                                  DateAdd(month, @Month - 1, 
                                      DateAdd(Year, @Year-1900 +1, 0)))) 
                                      
                                      
                    set @Year = @Year +1 
                    set @prev_vendorid = @vendorid
                            
                END
        

        
        
        FETCH NEXT FROM vendor_cursor 
            INTO @vendorid, @startDate,@gradDate
        END 
        CLOSE vendor_cursor;
        
    DEALLOCATE vendor_cursor;


    IF @mentorType = 'GRAD MENTOR' 
    BEGIN
     SELECT * FROM @TEMP1 A
            WHERE GETDATE() BETWEEN A.COMPLETION_STARTDATE  AND A.COMPLETION_ENDDATE
                AND  NOT EXISTS (SELECT * FROM EEO_MATRIX B
                                          WHERE  B.ASST_TYPE='Y' 
                                                AND B.INTV_COMPLETED =1
                                                AND B.WORKFLOWTYPE IN 
                                                (
                                                    'GradMentorYearly'
                                                  --  'GradMentorEnrollment',
                                                  --  'GradMentorGraduation',
                                                   -- 'GradMentorBidCeilingReview'
                                                )
                                                AND A.VENDORID = B.VENDORID  
                                                AND A.PERIODID = B.INTV_SEQ) 
    END
     
    
                                            
    IF @mentorType = 'MENTOR' 
    BEGIN                                      
                                              
      SELECT * FROM @TEMP1 A
        WHERE GETDATE() BETWEEN A.COMPLETION_STARTDATE  AND A.COMPLETION_ENDDATE
            AND  NOT EXISTS (SELECT * FROM EEO_MATRIX B
                                      WHERE  B.ASST_TYPE='Y' 
                                            AND B.INTV_COMPLETED =1
                                            AND B.WORKFLOWTYPE IN 
                                            (
                                                'MentorYearly'
                                                --'MentorEnrollmentWorkflow',
                                               -- 'AppealsWorkflow',
                                               -- 'Tier2Workflow',
                                               -- 'MentorGraduationWorkflow'
                                            )
                                            AND A.VENDORID = B.VENDORID  
                                            AND A.PERIODID = B.INTV_SEQ) 
    END                                 
                                      
                                      
                                      
                                      

    
END
