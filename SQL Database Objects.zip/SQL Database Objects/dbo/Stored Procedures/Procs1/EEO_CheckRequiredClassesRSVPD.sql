﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE Procedure [dbo].[EEO_CheckRequiredClassesRSVPD]
	-- Add the parameters for the stored procedure here
	@vendorId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	--SET NOCOUNT ON;

    -- Insert statements for procedure here
	declare @currentStatus varchar(50)
	declare @classType varchar(1)
	declare @count int
	select @currentStatus=status from eeo_vendor where vendorid=@vendorId


	if @currentStatus='Preliminary_Class_Details_Emailed' 
		begin
			set @classType='1'
		end

	
	set @count =(
				select count(*)
			from
				(
				select	C_CLASS_ID	from	eeo_classes ec where	ec.c_class_Type=@classType
				except
				select vc.C_CLASS_ID from EEO_VENDOR_CLASSES vc where vc.vendorid=@vendorId and (C_RSVPD='Y' or C_ATTENDED='Y')
				) c

				)
		


	select @count
	return @count
END
