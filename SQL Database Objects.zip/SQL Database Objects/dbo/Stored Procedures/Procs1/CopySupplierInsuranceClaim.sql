﻿







CREATE procedure [dbo].[CopySupplierInsuranceClaim]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin


	insert SupplierInsuranceClaim
		(
			SupplierId,
			Type,
			Claimant,
			Amount,
			Insurer,
			Disposition,
			Description,
			StartDate,
			EndDate,
			ChangeDate,
			ChangeUser
		)
	select
			@newSupplierId,
			Type,
			Claimant,
			Amount,
			Insurer,
			Disposition,
			Description,
			StartDate,
			EndDate,
			getdate(),
			@changeUser
	from SupplierInsuranceClaim s
	where s.supplierId=@supplierId
	and DateDiff(day, s.StartDate, DateAdd(year, -5, getdate())) < 0
	and Type='Errors & Omissions'

	insert SupplierInsuranceClaim
		(
			SupplierId,
			Type,
			Claimant,
			Amount,
			Insurer,
			Disposition,
			Description,
			StartDate,
			EndDate,
			ChangeDate,
			ChangeUser
		)
	select
			@newSupplierId,
			Type,
			Claimant,
			Amount,
			Insurer,
			Disposition,
			Description,
			StartDate,
			EndDate,
			getdate(),
			@changeUser
	from SupplierInsuranceClaim s
	where s.supplierId=@supplierId
	and Type not in ('Errors & Omissions')

end








