﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierVendex
Purpose:	Delete a row from SupplierVendex table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/20/2008		AECSOFTUSA\angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierVendex
	@id int
as

delete SupplierVendex
where Id = @id
return @@RowCount

