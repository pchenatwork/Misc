﻿CREATE PROCEDURE DeleteSupplierPicture 
(
@supplierId int
)AS
Begin
	Update Supplier Set PictureId = null where Id = @supplierId
End


