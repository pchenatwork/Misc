                   
ALTER procedure [dbo].[BidAndAward_ReplacePlaceHolder]                        
 @Id  INT = 3  -- Project 1ID                         
AS                        
BEGIN                        
                         
 SET NOCOUNT ON;                          
                         
 --Set @Id = 27;                        
                        
 -- Create Temp Table for all Keys requried. --                        
 CREATE TABLE #REPLACE ([Key] VARCHAR(100), [Value] VARCHAR(MAX), [IsNumeric] BIT DEFAULT 0, [IsUser] BIT DEFAULT 0, [IsPredicate] BIT DEFAULT 0 );                        
                        
 -- Get all details for Known Place Holders from Original tables --                        
 SELECT * INTO #_Project FROM Project (NOLOCK)   WHERE ID   = @Id ;                        
 SELECT * INTO #_Prop    FROM ProjectProperty (NOLOCK) WHERE ProjectID  = @Id ;                        
 SELECT * INTO #_Item    FROM ProjectItem (NOLOCK)  WHERE PROJECTID  = @Id ;                        
 SELECT * INTO #_School  FROM CMS_SCHOOL(NOLOCK)   WHERE c_school_name IN (SELECT School FROM #_Item);                        
 -- Bidder Info --                        
 SELECT B.* INTO #_Bidder  FROM   Bidder   (NOLOCK) B                          
       LEFT OUTER JOIN BidderReject (NOLOCK) R On B.Id = R.BidderId                         
       WHERE PROJECTID  = @Id AND [RANK] > 0 AND R.Id IS NULL;                        
 SELeCT * INTO #_BidderAll FROM   Bidder(NOLOCK) WHERE PROJECTID  = @Id;                        
                         
 SELECT dbo.FormatUserName(u.FirstName, u.LastName)  AS [Name] ,                        
   ISNULL(u.Email, '')        AS [Email] ,                        
   ISNULL(u.Phone, '')        AS [Phone]                        
 INTO #_Specialist                        
 FROM [User] u (NOLOCK)                         
   INNER JOIN aspnet_Users   au (NOLOCK) ON u.UserId = au.UserId                        
   INNER JOIN aspnet_Membership m  (NOLOCK) ON u.UserId = m.UserId                         
 WHERE au.UserName = ( SELECT ContractSpecialist From #_Project );                        
                          
 DECLARE @_TransNum Varchar(100) = (SELECT TRANSNUMBER FROM #_Project )                     
                      
 --SELECT TOP 1                        
 --  (Case When l_mentor = 1 Then 'Line' When l_mentor_graduate = 1 Then 'GradMentor' Else 'CIP' End )   As 'ProjectType',                        
 --  *                        
 --INTO #_Rfc                        
 --FROM MV_VAS_RFC_ALL  (NOLOCK)                        
 --WHERE Transm_number = ( @_TransNum );                       
                   
                  
  SELECT TOP 1                    
  (Case                      
  When PTS.ISCAPACITYPROJECT = 1 Then 'Line'                      
  When PTS.I_MENTOR = 2 Then 'Mentor'                      
  When PTS.I_MENTOR = 3 Then 'GradMentor'                     
  Else 'CIP'                      
   End )  As [ProjectType] ,                   
   PTS.N_LIQUID_DAMAGES as [m_liquidamages],dbo.[Currency_ToWords](PTS.N_LIQUID_DAMAGES)    [LIQUID_DAMAGES] , PTS.N_HVAC_AMT M_HVAC, PTS.N_PLUMBING_AMT M_PLUMBING, PTS.N_ELECTRICAL_AMT M_ELECTRICAL,ll.C_LLW_CODE [LLW_CODE] ,                  
  ll.C_FUNDING_SOURCE_DESC [FUNDING_SOURCE_DESC],pts.DM_NETWORK_ID as [design_mgr]                  
   INTO #_Rfc                    
 FROM MV_VAS_PTS_RFC_ALL PTS  (NOLOCK)                    
 left join MV_VAS_RFC_ALL ra on ra.transm_number = PTS.C_TRANSM_NUMBER                  
 inner join MV_VAS_PTS_RFC_LLW_ALL ll on ll.CONTRACT_REQ_ID_FK = pts.CONTRACT_REQ_ID_PK                  
 WHERE  C_TRANSM_NUMBER  = ( @_TransNum );                    
                   
                          
 SELECT * INTO #_Rfd FROM Rfdproject WHERE transnumber = ( @_TransNum );                         
                        
 SELECT * INTO #_Alternates FROM ProjectAlternate WHERE ProjectId = @Id;                       
                        
                         
 -- REQUIRED VARIABLES FROM TABLES AS USED AT MULTIPLES PLACES --                        
 DECLARE @_School VARCHAR(MAX);                        
 WITH          SchoolNames AS (  SELECT DISTINCT School From  #_Item )                         
 SELECT @_School     = STUFF( ( SELECT ',' + School From SchoolNames FOR XML PATH('') ), 1, 1, '') ;                     
                        
 DECLARE @_Address VARCHAR(MAX);                        
 WITH          Addresses AS (  SELECT DISTINCT                        
                  LTRIM(RTRIM(School))      + ',' +                         
                  LTRIM(RTRIM(ISNULL(SchoolAddressLine1,''))) + ',' +               
                  LTRIM(RTRIM(ISNULL(SchoolAddressLine2,''))) + ',' +                         
                  LTRIM(RTRIM(ISNULL(ZipCode,''))) As Adds From  #_Item )                         
 SELECT @_Address     = STUFF( ( SELECT '~' + Adds From Addresses FOR XML PATH('') ), 1, 1, '~') ;                        
                         
 DECLARE @_Boro  VARCHAR(25)  = ( SELECT [Name] FROM Borough WHERE Code = ( SELECT TOP 1 c_boro_code  FROM #_School ) );                         
 DECLARE @_Design VARCHAR(25)  = ( SELECT LTRIM(RTRIM( ISNULL( [PackageNo] , [DesignNo]) ) )    FROM #_Project );                        
 DECLARE @_Solit  VARCHAR(25)  = ( SELECT LTRIM(RTRIM([SolicitationNo] )) +'-'+LTRIM(RTRIM([SolicitSeq])) FROM #_Project );                        
 DECLARE @_Amount NUMERIC(15,2) = ( SELECT CostAmt               FROM #_Project );                        
   
 --DECLARE @_BidAmount NUMERIC(15,2) = (  select ISNULL(BidAmt, 0 ) from #_Bidder where Id in (SELECT AwardBidderId FROM #_Project)    );      
 -- BOFA AMOUNT IS NOW CONSIDERED FOR INTENT AWARD LETTER  
 DECLARE @_BidAmount NUMERIC(15,2) = ( select case when bafo.Amount > 0   then  ISNULL(cast(bafo.Amount as money), 0 )   
          else ISNULL(cast(b.BIDAMT as money), 0 )   end [BidAmt]  
          from #_Bidder b   
          left join ProjectBAFO bafo on bafo.ProjectId = b.ProjectId and bafo.BidderId = b.Id 
          where b.Id in (SELECT AwardBidderId FROM #_Project));      
                     
 DECLARE @_EstAmount NUMERIC(15,2) = ( SELECT CostEstAmt              FROM #_Project );                         
 DECLARE @_Opening DATETIME  = ( SELECT ISNULL(dbo.CHECKMINDATE(ActualBidOpeningDateTime),ISNULL(dbo.CHECKMINDATE(RevisedBidOpeningDateTime),                        
        PlanedBidOpeningDateTime))        FROM #_Project );                         
                        
 -- Update with NULL for unfilled Date Columns                        
 UPDATE #_Project SET PreBidMeetingDateTime  = NULL WHERE PreBidMeetingDateTime  = '1900-01-01 00:00:00.000';                        
 UPDATE #_Project SET ActualBidOpeningDateTime = NULL WHERE ActualBidOpeningDateTime = '1900-01-01 00:00:00.000';                        
 UPDATE #_Project SET PlanedBidOpeningDateTime = NULL WHERE PlanedBidOpeningDateTime = '1900-01-01 00:00:00.000';                        
 UPDATE #_Project SET RevisedBidOpeningDateTime = NULL WHERE RevisedBidOpeningDateTime = '1900-01-01 00:00:00.000';                        
 UPDATE #_Project SET SolicitPkgRcvdDate   = NULL WHERE SolicitPkgRcvdDate   = '1900-01-01 00:00:00.000';                        
 UPDATE #_Project SET SolicitPkgRcvdCompleteDate = NULL WHERE SolicitPkgRcvdCompleteDate = '1900-01-01 00:00:00.000';                        
 UPDATE #_Project SET ActualDocsAvailableDate = NULL WHERE ActualDocsAvailableDate = '1900-01-01 00:00:00.000';                        
 UPDATE #_Project SET DocsAvailableDate   = NULL WHERE DocsAvailableDate   = '1900-01-01 00:00:00.000';                        
 UPDATE #_Project SET ArchiveDate    = NULL WHERE ArchiveDate    = '1900-01-01 00:00:00.000';                        
 UPDATE #_Project SET BidTransferredDate   = NULL WHERE BidTransferredDate   = '1900-01-01 00:00:00.000';                        
 UPDATE #_Project SET V_SD_ACTUAL_BID_OPEN  = NULL WHERE V_SD_ACTUAL_BID_OPEN  = '1900-01-01 00:00:00.000';                        
                                        
 -- INSERTING THE REPLACEABLE ITEMS  --                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$DATE$'       ,  ( SELECT CONVERT(VARCHAR(20), GETDATE() ,107) )                );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BORO$'       ,  ( @_Boro            )                );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$DESCRIPTION$'     ,  ( SELECT     [Description]             FROM #_Project )   );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$SOLICITATIONNO$'     ,  ( @_Solit            )                );                     INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$FISCALYEAR$'      ,  ( SUBSTRING( @_Solit,1,2)        )         
   
    
      );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$PREBIDLOCATION$'     ,  ( SELECT LTRIM(RTRIM([PreBidMeetingLoc]))           FROM #_Project )   );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$ROOM$'     ,  ( SELECT LTRIM(RTRIM([Room]))           FROM #_Project )   );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$PREBIDDATE$'      ,  ( SELECT CONVERT(VARCHAR(20), dbo.CHECKMINDATE(COALESCE([PreBidMeetingDateTime], [PlanedBidOpeningDateTime])) ,107)  FROM #_Project )   );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$PREBIDTIME$'      ,  ( SELECT Format(dbo.CHECKMINDATE(COALESCE([PreBidMeetingDateTime], [PlanedBidOpeningDateTime])),'hh:mm tt')  FROM #_Project )   );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$PERFORMANCEPERIOD$'    ,  ( SELECT LTRIM(RTRIM([ProjectDuration]       ))      FROM #_Project )   );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$PERFORMANCEPERIODONORBEFORE$' ,  ( SELECT LTRIM(RTRIM([ProjectDuration]       ))      FROM #_Project )   );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDOPENINGDATE$'     ,  ( SELECT CONVERT(VARCHAR(20), @_Opening      ,101)            )   );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BOD$'       ,  ( SELECT CONVERT(VARCHAR(30), @_Opening      ,107)      FROM #_Project )   );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDOPENINGTIME$'     ,  ( SELECT REVERSE(SUBSTRING(REVERSE(Convert(varchar(30), @_Opening, 100)), 1,7)) FROM #_Project )   );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$DOCSAVAILABLE$'     ,  ( SELECT CONVERT(VARCHAR(30), ISNULL(ActualDocsAvailableDate, DocsAvailableDate),100) FROM #_Project )  );                        
 INSERT INTO #REPLACE ([Key], [Value], [IsUser])  VALUES ( '$PO$'        ,  ( SELECT LTRIM(RTRIM([PO]      ))         FROM #_Project ), 1  );                        
 INSERT INTO #REPLACE ([Key], [Value], [IsUser])  VALUES ( '$CPO$'       ,  ( SELECT LTRIM(RTRIM([CPO]      ))         FROM #_Project ), 1  );                        
 INSERT INTO #REPLACE ([Key], [Value], [IsUser])  VALUES ( '$SPO$'       ,  ( SELECT LTRIM(RTRIM([SPO]      ))         FROM #_Project ), 1  );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$CONTRACT$'      ,  (  SELECT LTRIM(RTRIM(ContractNo))           FROM #_Project));                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$DESIGN$'       ,  ( @_Design          )                );                                                    
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$SCHOOL$'       ,  ( @_School          )                );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$PROJECTADDRESS$'     ,  ( @_Address         )                );                        
                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDPROJECTADDRESS$'    ,  ( SELECT AddressLine1 +','+ AddressLine2 +',' + Boro + ','+ City +',' + State + ','+ ZipCode  FROM #_Project   )                );                        
            
 -- BUG ID: #1663            
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$PREBID-MANDATE$'    ,  ( select  CASE WHEN (SELECT IsPreBidMeetingMandatory FROM #_Project) = 'Y' then '' else 'NOSHOW' end   ) );                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$PREBID-NOTMANDATE$'    ,  ( select  CASE WHEN (SELECT IsPreBidMeetingMandatory FROM #_Project) = 'N' then '' else 'NOSHOW' end   ) );                        
 --END            
                        
                        
                                                     
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$CONTSPECNAME$'     ,  ( SELECT LTRIM(RTRIM([Name]   ))         FROM #_Specialist ));                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$CONSTRUCTIONSPECIALIST$'   ,  ( SELECT LTRIM(RTRIM([Name]   ))   FROM #_Specialist )); --REPEATED - TO BE CHECKED --                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$EMAILADDRESS$'     ,  ( SELECT LTRIM(RTRIM([Email]   ))         FROM #_Specialist ));                        
 INSERT INTO #REPLACE ([Key], [Value])   VALUES ( '$CONTSPECPHONE$'     ,  ( SELECT LTRIM(RTRIM([Phone]   ))         FROM #_Specialist ));                                       
                          
 -- RFC --                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$PROJECTTYPE$'     ,  ( SELECT  LTRIM(RTRIM([ProjectType]       ))   FROM #_Rfc )   );                         
 INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$LIQUIDATEDDAMAGES$'    ,  ISNULL((CONVERT(varchar(40), CAST((SELECT m_liquidamages from #_Rfc ) AS money),1 )),'0.0'), 1  );                       
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$LIQUIDATEDDAMAGES_WORDS$'  ,  ISNULL(( SELECT  LTRIM(RTRIM([LIQUID_DAMAGES]))   FROM #_Rfc ),'Zero Dollars'));                       
                      
                        
 INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$ALLOWANCEAMOUNT$'    ,  ( SELECT  CONVERT(NUMERIC(15,2), AllowanceAmt)    FROM #_Project ), 1  );                         
INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$LLW$'       ,  ( SELECT  LTRIM(RTRIM([LLW_CODE]        ))   FROM #_Rfc )   );                         
 INSERT INTO #REPLACE ([Key], [Value], [IsUser])  VALUES ( '$DESIGNMGR$'      ,  ( SELECT  LTRIM(RTRIM([design_mgr]       ))   FROM #_Rfc ), 1  );                        
 INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$CONTRACTAMT$'     ,  (ISNULL(CONVERT(varchar(50), CAST(@_BidAmount AS money), 1),0.0)                       ), 1  );                         
 INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$BUDGETNUMBER$'     ,  ( @_Amount                      ), 1  );                         
 INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$ENGINEERESTIMATE$'    ,  ( @_Amount                      ), 1  );                         
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$FUNDINGSOURCE$'     ,  ( SELECT  LTRIM(RTRIM([FUNDING_SOURCE_DESC]     ))   FROM #_Rfc )   );                         
                         
                        
                        
 -- EMAIL TEMPLATE WORK BEGINS                        
                        
                         
 INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$PACKAGENO$', ( SELECT LTRIM(RTRIM([PackageNo])) FROM #_Project ));                         
                        
 -- EMAIL TEMPLATE WORK ENDS                        
                        
                        
 -- Properties --                        
 DECLARE @_Wicks VARCHAR(1) = IIF( Exists( SELECT 1 FROM #_Prop WHERE Propertyid IN (110, 111, 112) AND CAST(PropertyText AS [NVARCHAR](Max)) IN ('True' ,'Y') ), '1', '0' ) ;      
 INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$WICKSAVAILABLE$'     ,  @_Wicks      , 1        ) ;                         
 DECLARE @_WicksHvac   Bit = IIF( Exists( SELECT 1 FROM #_Prop WHERE Propertyid IN (110) AND CAST(PropertyText AS [NVARCHAR](Max)) IN ('True' ,'Y') ), 1, 0 ) ;                         
 DECLARE @_WicksElectric  Bit = IIF( Exists( SELECT 1 FROM #_Prop WHERE Propertyid IN (111) AND CAST(PropertyText AS [NVARCHAR](Max)) IN ('True' ,'Y') ), 1, 0 ) ;                        
 DECLARE @_WicksPlumbing  Bit = IIF( Exists( SELECT 1 FROM #_Prop WHERE Propertyid IN (112) AND CAST(PropertyText AS [NVARCHAR](Max)) IN ('True' ,'Y') ), 1, 0 ) ;                        
 DECLARE @_WicksLess10000 Bit = IIF( Exists( SELECT 1 FROM #_Prop WHERE Propertyid IN (113) AND CAST(PropertyText AS [NVARCHAR](Max)) IN ('True' ,'Y') ), 1, 0 ) ;                        
                        
 -- Wicks Logic --                        
 /*                        
   -- Logic --                        
   If there is no Wicks or Wicks Less than 10000 Show Para1 and Do not Show Para2, Para3, para4                        
   If there is Wicks Do not Show Para1 and Show Para2, Para3, para4, But if any of the Wicks Amount is < 1000000 (1 million) do not show Para 3                         
 */                        
 IF (@_Wicks = '0' OR @_WicksLess10000 = 1)                        
 BEGIN                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$WICKS1$'     ,  '' );                         
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$WICKS2$'     ,  'NOSHOW' );                         
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$WICKS3$'     ,  'NOSHOW' );                           
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$WICKS4$'     ,  'NOSHOW' );                         
 END                        
 ELSE                        
 BEGIN                          
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$WICKS1$'     ,  'NOSHOW' );                         
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$WICKS2$'     ,  '' );                         
  IF ( ( SELECT M_HVAC FROM #_Rfc ) < 1000000  OR ( SELECT M_ELECTRICAL FROM #_Rfc ) < 1000000 OR ( SELECT M_PLUMBING FROM #_Rfc ) < 1000000 )                        
   INSERT INTO #REPLACE ([Key], [Value])   VALUES ( '$WICKS3$'     ,  'NOSHOW' );                            
  ELSE                        
   INSERT INTO #REPLACE ([Key], [Value])   VALUES ( '$WICKS3$'     ,  '' );                          
                          
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$WICKS4$'     ,  '' );                         
 END                        
                        
 -- NEW CODE FOR VERIFYING SELECTIVE WICKS TO SHOW WITH THE CORRECT WICKS IN TEXT   -- DT 03/01/2019                        
 IF (@_Wicks = '0')                         
  BEGIN                        
  INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$WICKSAVAILABILITY$' ,  'NOSHOW') ;                        
  INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$HIDEONWICKSAVAILABILITY$','') ;                         
  END                        
 ELSE                        
 BEGIN                        
  INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$WICKSAVAILABILITY$','') ;                        
                           
  INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$HIDEONWICKSAVAILABILITY$','NOSHOW') ; -- HIDE ONE PARAGRAPH WHEN WICKS EXISTS                        
                             
  IF @_WicksHvac > 0                         
   BEGIN                        
    IF(@_WicksPlumbing > 0)                        
     INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$WICKSHVAC$', 'HVAC,');                         
    ELSE                        
     INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$WICKSHVAC$', 'HVAC');                         
   END                        
  ELSE                         
   INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$WICKSHVAC$', '');                         
                        
  IF @_WicksPlumbing > 0                         
   INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$WICKSPLUM$', 'Plumbing and Gas Fitting');                         
  ELSE                         
   INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$WICKSPLUM$', '');                         
                        
                          
  IF @_WicksElectric > 0                          
  BEGIN                        
   IF(@_WicksHvac > 0 OR  @_WicksPlumbing > 0)                        
     INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$WICKSELECTRIC$', 'and Electric Work');                        
    ELSE                        
     INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$WICKSELECTRIC$', 'Electric Work');                        
END                        
  ELSE                         
   INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$WICKSELECTRIC$', '');                         
 END                        
                        
 --end of new code                         
          
 -- Amount Range Check --                        
 DECLARE @_EstAmountRange VARCHAR(2) = (SELECT TOP  1 PropertyText FROM #_Prop WHERE PropertyId = 118);                        
 INSERT INTO #REPLACE ([Key], [Value], [IsPredicate]) VALUES ( '$CHECK250$'      ,  ( IIF( @_EstAmountRange  =  '0' , 'X', '' ) ), 1        );                        
 INSERT INTO #REPLACE ([Key], [Value], [IsPredicate]) VALUES ( '$CHECK500$'      ,  ( IIF( @_EstAmountRange  =  '1' , 'X', '' ) ), 1        );                       
 INSERT INTO #REPLACE ([Key], [Value], [IsPredicate]) VALUES ( '$CHECK750$'      ,  ( IIF( @_EstAmountRange  =  '2' , 'X', '' ) ), 1        );                        
 INSERT INTO #REPLACE ([Key], [Value], [IsPredicate]) VALUES ( '$CHECK1000$'      ,  ( IIF( @_EstAmountRange  =  '3' , 'X', '' ) ), 1        );                        
 INSERT INTO #REPLACE ([Key], [Value], [IsPredicate]) VALUES ( '$CHECK4000$'      ,  ( IIF( @_EstAmountRange  =  '4' , 'X', '' ) ), 1        );                        
 INSERT INTO #REPLACE ([Key], [Value], [IsPredicate]) VALUES ( '$CHECKMORE$'      ,  ( IIF( @_EstAmountRange  =  '5' , 'X', '' ) ), 1        );                        
                         
 -- Allowances --                        
 IF ( (SELECT AreAllowancesIncluded From #_Project) = 'Y')                        
 BEGIN                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$ALLOWANCE1$'     ,  '' );                         
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$ALLOWANCE2$'     ,  'NOSHOW' );                        
 END                        
 ELSE                        
 BEGIN                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$ALLOWANCE1$'     ,  'NOSHOW' );                         
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$ALLOWANCE2$'     ,  '' );                        
 END                        
                         
                        
 --Alternates                        
 IF ( (SELECT AreAlternatesCalledFor From #_Project) = 'Y')                        
 BEGIN                        
   INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$ALTERNATES$', '' );                         
                        
   IF( (SELECT COUNT(*) FROM #_Alternates WHERE Type= 'Alt +/-' or Type = 'Deduct' or Type= 'Add') > 0)                         
   BEGIN                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$ALTERNATEPLUSMINUS$' , '');                         
   END                        
   ELSE                        
   BEGIN                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$ALTERNATEPLUSMINUS$' , 'NOSHOW');                         
   END                        
                      
    IF( (SELECT COUNT(*) FROM #_Alternates WHERE Type= 'Other') > 0)                         
   BEGIN                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$LUMPSUMALTERNATEBID$' , '');                         
   END                        
   ELSE                        
   BEGIN                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$LUMPSUMALTERNATEBID$' , 'NOSHOW');                         
   END                        
 END                        
 ELSE                        
 BEGIN                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$ALTERNATES$',  'NOSHOW' );                         
 END                        
                        
                        
 -- Bid Results --                        
 INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$TOTALBIDDERS$'     ,  ( SELECT  COUNT(1)  FROM #_BidderAll )   );                         
                         
 DECLARE @_RankNum1 INT = ( SELECT TOP 1 [Rank] FROM #_Bidder ORDER BY [Rank] );                        
 DECLARE @_RankNum2 INT = ( SELECT TOP 1 [Rank] FROM #_Bidder WHERE [Rank] > @_RankNum1 ORDER BY [Rank] );                        
 DECLARE @_RankNum3 INT = ( SELECT TOP 1 [Rank] FROM #_Bidder WHERE [Rank] > @_RankNum2  ORDER BY [Rank] );                        
                         
                         
 IF (@_RankNum1 IS NOT NULL)                        
 BEGIN                        
  DECLARE @_BidFedID  VARCHAR(20)  = (SELECT FederalID  FROM Supplier WHERE Id  = (SELECT TOP 1 SupplierID From #_Bidder WHERE [Rank] = @_RankNum1 ) );                        
  DECLARE @_Company  VARCHAR(200) = (SELECT Company  FROM Vendor  WHERE FEDERALID = @_BidFedID              );                        
  DECLARE @_Rank1Amount FLOAT(8)  = (SELECT TOP 1 BaseAmt FROM #_Bidder WHERE [Rank] = @_RankNum1                );                        
                        
  DECLARE @_Variance  FLOAT(8)  = ABS(@_Rank1Amount - @_EstAmount);                        
  DECLARE @_Percent  FLOAT(8)  = ( @_variance / IIF(@_EstAmount > 0.00, @_EstAmount, 1) ) * 100;                        
  DECLARE @_EstimateBar VARCHAR(10)  = IIF(@_EstAmount > @_Rank1Amount, 'above', 'below');                        
  DECLARE @_Color   VARCHAR(10)  = IIF( @_EstimateBar = 'above', 'Red', '');                        
                        
  --SELECT @_Rank1Amount, @_Variance, @_Percent, @_Color                        
                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDRANK1_COMPANY$'   ,  @_Company                     );                         
  INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$BIDRANK1_LUMPSUMAMOUNT$'  ,  (SELECT TOP 1 CONVERT(VARCHAR(18), CONVERT(DECIMAL(10,2), @_Rank1Amount))), 1    );                         
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDRANK1_LUMPSUMRANK$'  ,   @_RankNum1                    );                         
                           
  INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$VARIANCEBIDAMOUNT$'   ,  (SELECT TOP 1 CONVERT(VARCHAR(18), CONVERT(DECIMAL(10,2), @_Variance))), 1     );                        
  INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$VARIANCEBIDAMOUNTPERCENTAGE$',  (SELECT TOP 1 CONVERT(VARCHAR(18), CONVERT(DECIMAL(10,2), @_Percent ))), 1     );                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$ESTIMATEBARVALUE$'   ,  @_EstimateBar                    );                         
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BARCOLOR$'     ,  @_Color                     );                         
 END                        
 ELSE                        
 BEGIN                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDRANK1_COMPANY$'   , ''  )                        
  INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$BIDRANK1_LUMPSUMAMOUNT$'  , '0', 1 )                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDRANK1_LUMPSUMRANK$'  , '0'  )                        
                          
  INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$VARIANCEBIDAMOUNT$'   , '0', 1 )                        
  INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$VARIANCEBIDAMOUNTPERCENTAGE$', '0', 1 )                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$ESTIMATEBARVALUE$'   , ''  )                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BARCOLOR$'     , ''  )                        
 END                        
                         
 IF (@_RankNum2 IS NOT NULL)                        
 BEGIN                        
  SET @_BidFedID      = (SELECT FederalID FROM Supplier WHERE Id  = (SELECT TOP 1 SupplierID From #_Bidder WHERE [Rank] = @_RankNum2)        );                        
  SET @_Company     = (SELECT Company FROM Vendor  WHERE FEDERALID = @_BidFedID                     );                        
                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDRANK2_COMPANY$'   ,  ISNULL(@_Company,'')                 );                         
  INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$BIDRANK2_LUMPSUMAMOUNT$'  ,  (SELECT TOP 1 ISNULL(CONVERT(VARCHAR(18), CONVERT(DECIMAL(10,2), BaseAmt)),'0') FROM #_Bidder WHERE [Rank] = @_RankNum2), 1);                         
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDRANK2_LUMPSUMRANK$'  ,   ISNULL(@_RankNum2,'')                 );                         
 END                        
 ELSE                        
 BEGIN                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDRANK2_COMPANY$'   ,  ''  );                         
  INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$BIDRANK2_LUMPSUMAMOUNT$'  ,  0.00, 1);                         
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDRANK2_LUMPSUMRANK$'  ,  ''  );                         
 END                        
                          
 IF (@_RankNum3 IS NOT NULL)                        
 BEGIN                        
  SET @_BidFedID      = (SELECT FederalID FROM Supplier WHERE Id  = (SELECT TOP 1 SupplierID From #_Bidder WHERE [Rank] = @_RankNum3) );                        
  SET @_Company     = (SELECT Company FROM Vendor  WHERE FEDERALID = @_BidFedID           );                        
                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDRANK3_COMPANY$'   ,  ISNULL(@_Company,'')                  );                         
  INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$BIDRANK3_LUMPSUMAMOUNT$'  ,  (SELECT TOP 1 ISNULL(CONVERT(VARCHAR(18), CONVERT(DECIMAL(10,2), BaseAmt)),'0') FROM #_Bidder WHERE [Rank] = @_RankNum3), 1);                         
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDRANK3_LUMPSUMRANK$'  ,   ISNULL(@_RankNum3,'')                  );                         
 END                        
 ELSE                        
 BEGIN                        
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDRANK3_COMPANY$'   ,  ''  );                         
  INSERT INTO #REPLACE ([Key], [Value], [IsNumeric]) VALUES ( '$BIDRANK3_LUMPSUMAMOUNT$'  ,  0.00, 1);                         
  INSERT INTO #REPLACE ([Key], [Value])    VALUES ( '$BIDRANK3_LUMPSUMRANK$'  ,  ''  );                         
 END                        
                 
                        
                         
 -- NOTICE INTENT AWARD                        
                         
 SELECT s.Company,s.CurrentContact,s.Phone,s.PreparerName,s.PreparerPhone, sa.AddressLine1 + ' ' + sa.AddressLine2 + ', ' + sa.City + ', '+ sa.[State] + ', ' + sa.ZipCode + ', ' + sa.Country as [Address] INTO #_ListedBidder FROM Bidder (NOLOCK) B        
  
    
      
        
          
            
              
                
                 
 inner JOIN Project (NOLOCK) p on  b.Id = p.AwardBidderId and p.Id = @Id                         
 inner JOIN Supplier (NOLOCK) S ON S.Id = B.SupplierId                        
 inner  join SupplierAddress (NOLOCK) sa on sa.SupplierId = b.SupplierId and sa.AddressType = 'MAILING';   
                         
 INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$CONTACT$' ,  (  SELECT LTRIM(RTRIM([PreparerName]))  FROM #_ListedBidder));                        
 INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$CONTRACTOR$'      ,  (  SELECT LTRIM(RTRIM([Company]))  FROM #_ListedBidder));                        
 INSERT INTO #REPLACE ([Key], [Value]) VALUES ( '$CONTRACTORADDRESS$'    ,  (  SELECT LTRIM(RTRIM([Address]))  FROM #_ListedBidder));                        
                        
                        
 --END                        
                        
 -- Performance Period On before Calculation --                        
 /*                        
  -- Logic                        
  If project duration is <= 365 days then + 30 days                         
  If project duration is >= 365 and < 766 days then + 60 days                         
  If project duration is > 766 days then + 90 days                         
  If Line Job                    then + 190                         
                        
 */                         
 DECLARE @Duration INT = ( SELECT ProjectDuration FROM #_Project);      
 DECLARE @OnOrBefore INT = CASE                         
        WHEN (SELECT ProjectType FROM #_Rfc) = 'Line' THEN 180                        
        WHEN @Duration <= 365 THEN 30                        
        WHEN @Duration > 365 AND @Duration <= 730 THEN 60                        
        WHEN @Duration > 730 THEN 90                        
         END                        
 UPDATE #REPLACE SET VALUE = CAST( (CAST([VALUE] AS NUMERIC(18)) + @OnOrBefore ) AS VARCHAR(50)  )  WHERE [KEY] = '$PERFORMANCEPERIODONORBEFORE$';                        
                        
              
 -- Update to possible eliminated values --                        
 UPDATE #REPLACE SET [VALUE]  = '' WHERE VALUE IN ('01/01/1900', '00:00:00');                        
 UPDATE #REPLACE SET [IsUser] = 0  WHERE ISNULL(LTRIM(RTRIM([VALUE])), '') = '' AND IsUser = 1;                        
                        
 -- Getting all the user information from CES_MENTOR_EMPLOYEE Table which is populated --                        
 WHILE ( EXISTS (SELECT * FROM #REPLACE WHERE IsUser = 1 ) )                        
 BEGIN                         
                        
  DECLARE @_UserID VARCHAR(20) = (SELECT TOP 1 [VALUE] FROM #REPLACE WHERE IsUser = 1 );                        
                        
  UPDATE  #REPLACE                         
  SET   [Value]  =  (SELECT TOP 1 LTRIM(RTRIM(CME.[c_first_name])) + ' ' + LTRIM(RTRIM(CME.[c_last_name]))                
         FROM  CES_MENTOR_EMPLOYEE CME                         
         WHERE  CME.C_EMP_ID = @_USERID )                          
    , [IsUser] = 0                        
  WHERE  [Value]  = @_UserID                         
    AND  [IsUser] = 1;                        
                        
 END                        
                         
 -- DROP TEMP TABLES --                        
 DROP TABLE #_Project;                        
 DROP TABLE #_Prop;                        
 DROP TABLE #_Item;                        
 DROP TABLE #_School;                        
 DROP TABLE #_Specialist;                        
 DROP TABLE #_Rfc;                        
 DROP TABLE #_Rfd;                        
 DROP TABLE #_Bidder;                        
 DROP TABLE #_Alternates;                        
                         
 SELECT SUBSTRING([KEY], 2, LEN([KEY]) - 2)  AS 'Key',                           
   [VALUE]         AS 'Value',                        
   [KEY]         AS 'PlaceHolder',                        
   [IsNumeric]        AS 'Number',                        
   [IsPredicate]       AS 'Predicate'                        
                           
 FROM #REPLACE FOR XML PATH('KeyPair') , ROOT('Dictionary');                        
                        
 DROP TABLE #REPLACE;                        
                        
 SET NOCOUNT OFF;                        
      
END 