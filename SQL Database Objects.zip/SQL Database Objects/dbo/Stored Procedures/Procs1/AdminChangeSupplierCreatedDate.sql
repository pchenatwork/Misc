﻿-- =============================================
-- Author:		David Kowk
-- Create date: 6/1/2015
-- Description:	Change Created Date of Supplier Application
-- =============================================
CREATE PROCEDURE [dbo].[AdminChangeSupplierCreatedDate]

	@federalid varchar(50),
	@changeDate datetime

AS
BEGIN

	SET XACT_ABORT ON;

	BEGIN TRANSACTION;

	Update SupplierStaticQualification set ChangeDate=@changeDate where SupplierId in (select currentsupplierid from vendor where federalid=@federalid);

	Update Supplier set ApplyDate=@changeDate where id in (select currentsupplierid from vendor where federalid=@federalid);

	Update WorkflowHistory set DateCreated = @changeDate where TransactionHeaderId in (select Transactionid From dbo.SupplierWorkflow where SupplierId in (select currentsupplierid from vendor where federalid=@federalid));

	COMMIT TRANSACTION;


END
