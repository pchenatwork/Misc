﻿/*
*********************************************************************************************************************
Procedure:	DeleteSubcontractorWorkerComp
Purpose:	Delete a row from SubcontractorWorkerComp table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/3/2008		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSubcontractorWorkerComp]
	@id int
as

delete SubcontractorWorkerComp
where Id = @id
return @@RowCount

