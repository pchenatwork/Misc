﻿/*
*********************************************************************************************************************
Procedure:	DeleteChangeHistory
Purpose:	Delete a row from ChangeHistory table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/3/2008		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteChangeHistory
	@id int
as

delete ChangeHistory
where Id = @id
return @@RowCount

