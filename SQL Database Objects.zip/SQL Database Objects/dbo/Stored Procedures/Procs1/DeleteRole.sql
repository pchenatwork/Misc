﻿
-- Stored Procedure

CREATE procedure [dbo].[DeleteRole]
	@roleId uniqueidentifier
as

DELETE FROM WorkflowNodeUser WHERE RoleId = @roleId

DELETE FROM PermissionRole WHERE RoleId = @roleId

DELETE FROM OutlookPermission WHERE RoleId = @roleId

return @@RowCount






