﻿
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[DeletePlan]'))
   EXEC('CREATE PROCEDURE [dbo].[DeletePlan] AS BEGIN SET NOCOUNT ON; END')
GO

/*
*******************************************************************************
Procedure:	DeletePlan
Purpose:	Delete a row from Plan table.
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/1/2010		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeletePlan]
	@id int
as

declare @temp table
(
	plansubcontractorid int
)

begin transaction

begin try
	insert into @temp 
		(plansubcontractorid) 
	select 
		Id 
	from 
		PlanSubcontractor 
	where PlanId = @id
	
	delete dbo.PlanComment where PlanId = @id	
	
	delete dbo.PlanCommunicationComment where PlanId = @id	
		
	delete dbo.PlanItem where PlanId = @id	

	delete dbo.PlanProperty where PlanId = @id	

	delete dbo.PlanWaiverProject where PlanWaiverId in (select Id from PlanWaiver where PlanId = @id)
		
	delete dbo.PlanWaiverCategory where PlanWaiverId in (select Id from PlanWaiver where PlanId = @id)
		
	delete dbo.PlanWaiverDocument where PlanWaiverId in (select Id from PlanWaiver where PlanId = @id)

	delete dbo.PlanWaiver where PlanId = @id
	
	delete dbo.PlanSubcontractorCategory where PlanSubcontractorId in (select plansubcontractorid from @temp)

	delete dbo.PlanSubcontractorCertification where PlanSubcontractorId in (select plansubcontractorid from @temp)
	
	delete dbo.PlanSubcontractorDocument where PlanSubcontractorId in (select plansubcontractorid from @temp)
	
	delete dbo.PlanSubcontractorComment where PlanSubcontractorId in (select plansubcontractorid from @temp)

	delete dbo.PlanSubcontractorCommunicationComment where PlanSubcontractorId in (select plansubcontractorid from @temp)

	delete dbo.PlanSubcontractorProperty where PlanSubcontractorId in (select plansubcontractorid from @temp)
	
	delete dbo.PlanSubcontractorPro where PlanId = @id

	delete dbo.PlanSubcontractor where PlanId = @id
					
	delete [Plan] where Id = @id
	
	commit transaction
	return @@RowCount
end try
begin catch
	rollback transaction
	return 0
end catch

GO