﻿CREATE procedure [dbo].[DeletePlanCommentAttachment] 
	@id int
AS

Update PlanComment
Set FileName = null,
	AttachmentId = null
Where Id = @id
return @@rowcount
