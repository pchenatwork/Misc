﻿/*
*********************************************************************************************************************
Procedure:	DeleteVettingAttachment
Purpose:	Delete a row from VettingAttachment table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/22/2007		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteVettingAttachment
	@id int
as

delete VettingAttachment
where Id = @id
return @@RowCount

