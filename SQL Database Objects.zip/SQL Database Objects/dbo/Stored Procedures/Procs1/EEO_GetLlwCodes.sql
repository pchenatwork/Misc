﻿
CREATE PROCEDURE [dbo].[EEO_GetLlwCodes]
	(
	@package_code varchar(10)
	)
AS

Begin
	 SELECT DISTINCT R.LLW_CODE FROM MV_VAS_RFC_ALL R WHERE R.PACKAGE_CODE= @package_code
end
