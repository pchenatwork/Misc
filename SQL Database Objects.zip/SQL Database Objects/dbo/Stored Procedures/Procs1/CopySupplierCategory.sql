﻿






CREATE procedure [dbo].[CopySupplierCategory]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin
	
------Auditlog
--	Insert AuditLog_Meta
--	(TableName, RecordId, VASId,  MainId, TransactionID, Action, ActionTime, UserName, ProcessedStatus)
--	select 'SupplierCategory', Id, Id, @newSupplierId, null, 'delete', null, null, null from SupplierCategory
--	where supplierId=@supplierId and transferredFlag = 1
------------------

	insert SupplierCategory
		(
			SupplierId,
			CategoryId,
			Average,
			ChangeDate,
			ChangeUser
		)
	select
			@newSupplierId,
			CategoryId,
			Average,
			getdate(),
			@changeUser
	from SupplierCategory where supplierId=@supplierId

end










