﻿CREATE PROC [dbo].[EEO_GetGraduateEligibleVendors]
As

select 
	distinct ev.* 
from 
	EEO_MENTOR_GRAD_DETAIL e,eeo_vendor ev,EEO_WorkFlowHistory eh
where 
	--DATEADD(MONTH,48,sd_start_date)<getdate() and DATEADD(MONTH,48,sd_start_date)>getdate()-365 -- in the 4th year
	--DATEADD(YEAR,-1,e.sd_grad_date)>dateadd(year, -1,getdate() ) and DATEADD(YEAR,-1,e.sd_grad_date)<getdate()
	--e.SD_GRAD_DATE >DATEADD(YEAR,-1,getdate()) and e.SD_GRAD_DATE<getdate()
	e.SD_GRAD_DATE >DATEADD(M,-6,getdate()) and e.SD_GRAD_DATE<DATEADD(m,6,getdate())
and C_MENTOR_TYPE='MENTOR'
and SD_ACTUAL_GRAD_DT is null -- Not yet graduated
and e.VENDORID=ev.VendorId
and ev.MentorFlag=6
and ev.TransactionId=eh.TransactionId
and eh.WorkFlowId!=18 -- mentor graduation workflow already started
and not exists(select * from EEO_MENTOR_GRAD_DETAIL where vendorid=e.VENDORID and C_MENTOR_TYPE='GRAD MENTOR')
and not exists(select * from EEO_MENTOR_GRAD_DETAIL where vendorid=e.VENDORID and (SD_END is not null or sd_end <Getdate())
)
