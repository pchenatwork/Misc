﻿
CREATE procedure [dbo].[CheckInRfxDocument] 
	@id int,
	@attachmentId bigint = null,
	@fileName nvarchar(100) = null,
	@extension nvarchar(10) = null,
	@version nvarchar(10) = null,
	@comments ntext = null,
	@changeUser nvarchar(50)
As
Begin
Set NoCount on

Begin Transaction

Update RfxDocument
Set 
	AttachmentId = @attachmentId,
	FileName = @fileName,
	Extension = @extension,
	Version = @version,
	CheckOutId = null,
	CheckOutDate = null,
	ChangeUser = @changeUser,
	ChangeDate = getdate()
Where Id = @id

Update RfxDocument
Set IsDirty = 'Y'
Where Id = @id and isnull(RefId, 0) <> 0

Update RfxDocument
Set IsDirty = 'Y'
Where isnull(RefId, 0) = @id

declare @userId int
Select @userId = u.Id
From [User] u, aspnet_Users au
where u.UserId = au.UserId
and au.UserName = @changeUser

insert RfxDocumentHistory
	(
		DocumentId,
		AttachmentId,
		FileName,
		Extension,
		Version,
		Comments,
		ChangeUser,
		ChangeDate,
		HistoryId,
		UserId
	)
values
	(
		@id,
		@attachmentId,
		@fileName,
		@extension,
		@version,
		@comments,
		@changeUser,
		getdate(),
		newid(),
		@userId
	)

if @@error = 0
begin
	Commit Transaction
	return 1
end
else
begin
	RollBack Transaction
	return 0
end
End