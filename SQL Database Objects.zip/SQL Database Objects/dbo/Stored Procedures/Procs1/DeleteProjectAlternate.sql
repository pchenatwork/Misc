﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectAlternate
Purpose:	Delete a row from ProjectAlternate table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/30/2009		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteProjectAlternate
	@id int
as

delete ProjectAlternate
where Id = @id
return @@RowCount

