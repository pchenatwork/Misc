﻿/*
*********************************************************************************************************************
Procedure:	DeleteRfc
Purpose:	Delete a row from Rfc table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/30/2009		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteRfc]
	@id int
as
BEGIN Transaction

delete RfcDocument
where RfcId = @id

delete RfcItem
where RfcId = @id

delete Rfc
where Id = @id

if @@error = 0
	Commit Transaction
else
	RollBack Transaction
return @@RowCount

