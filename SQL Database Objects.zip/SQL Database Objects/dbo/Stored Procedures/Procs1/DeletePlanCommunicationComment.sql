﻿/*
*********************************************************************************************************************
Procedure:	DeletePlanComment
Purpose:	Delete a row from PlanComment table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
12/15/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
create procedure [dbo].[DeletePlanCommunicationComment]
	@id int
as

delete PlanCommunicationComment
where Id = @id
return @@RowCount

