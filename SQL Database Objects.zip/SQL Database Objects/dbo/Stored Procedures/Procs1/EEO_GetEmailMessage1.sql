﻿-- =============================================
-- Author:		PS
-- Create date: <Create Date,,>
-- Description:	This is to replace email placeholders before sending mails
-- =============================================

/*

	select 
		Name,
		Email,
		v.Company,
		v.FederalId ,vc.vendorid
	from 
		vendorcontact vc, vendor v
	where 
		vc.contacttype='Primary' and 
		vc.vendorid=24574 and 

EEO_GetEmailMessage 'xyz',6418,998
EEO_GetEmailMessage 'EEO_CLASS_CANCELLED',6418,998
EEO_GetEmailMessage 'EEO_GRADMENTOR_VENDOR_INVITE',6418,998




select  e.vendorid
	from eeo_vendor e, eeo_workflowhistory wh
	where e.transactionid=wh.transactionid
	and wh.isactive=1

*/

CREATE PROCEDURE [dbo].[EEO_GetEmailMessage1] 
	-- Add the parameters for the stored procedure here
	@Name varchar(100),
	@VendorId int,
	@userId int,
	@extras varchar(max)=null
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	Declare @appointmentId int
	Declare @cancelledComments varchar(500)



    -- Insert statements for procedure here
	declare @body varchar(8000)
	declare @fromEmail varchar(400)
	declare @fromName varchar(400)
	declare @toEmail varchar(400)
	declare @toName varchar(400)
	declare @Subject varchar(400)
	declare @ccEmail varchar(400)
	declare @bccEmail varchar(400)
	declare @workflowcomments varchar(1000)
	declare @VendorPrimaryContactName varchar(100)
	declare @vendorPrimaryContactEmail varchar(100)
	declare @vendorCompany varchar(200)
	declare @vendorFedId varchar(20)

	Declare @ADMINEMAIL varchar(750)
	Declare @APPEALSLINK varchar(750)
	Declare @COMPANY varchar(750)
	Declare @EXTERNALAPPOINTMENTSLINK varchar(750)
	Declare @EXTERNALCLASSLINK varchar(750)
	Declare @EXTERNALDOCSLINK varchar(750)
	Declare @ScopeBCMBaselineAssessment varchar(750)
	Declare @ToEmail1 varchar(750)
	declare @consultant varchar(400)
	declare @appointmentdate DATE
	declare @appointmenttime TIME
	declare @scopeb varchar(200)
	declare @scopeBEmailList varchar(MAX)

	
		if (@extras!=null or  @extras !='')
		Begin
			declare @hdoc		int
			declare @emailType varchar(100)
		--	set @extras=replace(replace(@extras,'\"','"'),'\r\n','') -- PS remove escape charecs from the xml

			print @extras
			EXEC sp_xml_preparedocument @hdoc OUTPUT, @extras

			declare @extra Table
			(
				Name nvarchar(50),
				Value nvarchar(4000)
			)

			INSERT INTO @extra
			(
				Name,
				Value
			)
			SELECT
				Name,
				Value
			FROM OPENXML(@hDoc, '/ArrayOfExtra/Extra', 1)
			WITH
			(
				Name nvarchar(50),
				Value nvarchar(4000)
			)
		
		 
			select @appointmentId = CAST(CAST( isnull(Value,'0') AS float) AS INT)  
			from @extra
			where Name = 'appointmentId'
		
		 
			SELECT  @cancelledComments=C_CANCEL_COMMENTS, @consultant=E.VALUE , @appointmentdate=SD_APPOINTMENT, @appointmenttime=T_APPOINTMENT ,
					@scopeb=u.Email
			FROM 
				EEO_VENDOR_APPOINTMENTS A INNER JOIN EEO_LOOKUP E ON A.I_CONSULTANT_LOOKUP_ID = E.LOOKUPID
				left join [user] u on a.I_UPDATEDBY=u.id
			WHERE a.ID = @appointmentId



			select 
				@emailType = Value 
			from 
				@extra
			where 
				Name = 'emailType'

			
			if(@emailType Like 'ClassSchCance%')
				begin

					exec EEO_GetEmailMessageForClass  @Name, @VendorId,@userId,@extras			
					Return
				end

		End
	
	select 
		@body=body ,
		@fromEmail=fromEmail,
		@fromName=FromName,
		@toEmail=ToEmail,
		@toName=ToName,
		@subject=[Subject],
		@ccEmail=CcEmail,
		@bccEmail=bccEmail

	from 
		emailmessage where name=@Name
	--table containing values to be replaced
	create table #Replace 
	(
		StringToReplace varchar(1000) not null primary key clustered
		,ReplacementString varchar(1000) not null    
	)


	select 
		@VendorPrimaryContactName=Name,
		@VendorPrimaryContactEmail=Email,
		@vendorCompany=v.Company,
		@vendorFedId=v.FederalId 
	from 
		vendorcontact vc, vendor v
	where 
		vc.vendorid=@Vendorid and vc.contacttype='Primary'
		and vc.VendorId=v.id


	SELECT 
			@scopeBEmailList = COALESCE(@scopeBEmailList+';' ,'') + u.Email 
	from   
			aspnet_Roles r, aspnet_UsersInRoles ar , [user] u
	where 
				  r.RoleId = ar.RoleId 
			and   r.RoleName = 'Mentor CM -- Scope B'
			and   ar.UserId=u.UserId



 
		

	--insert into #Replace values('$ADMINEMAIL$','nycsca_do_business@nycsca.org')
	--insert into #Replace values('$COMPANY$','NYCSCA')
	--insert into #Replace values('$DATE$',GetDate())
	--insert into #Replace values('$EXTERNALCLASSLINK$','<a href=''http://scavasqa01.nycsca.org/EEO/External/MentorEx/Classes''>http://scavasqa01.nycsca.org/EEO/External/MentorEx/Classes </a>') 
	--insert into #Replace values('$EXTERNALDOCSLINK$','<a href=''http://scavasqa01.nycsca.org/EEO/External/MentorEx/Documents''>http://scavasqa01.nycsca.org/EEO/External/MentorEx/Documents</a>') 
	--insert into #Replace values('$APPEALSLINK$','<a href=''http://scavasqa01.nycsca.org/EEO/External/MentorEx/Appeals''>http://scavasqa01.nycsca.org/EEO/External/MentorEx/Appeals</a>') 
	--insert into #Replace values('$EXTERNALAPPOINTMENTSLINK$','<a href=''http://scavasqa01.nycsca.org/EEO/External/MentorEx/Appointments''>http://scavasqa01.nycsca.org/EEO/External/MentorEx/Appointments</a>')
	--insert into #Replace values('$ScopeBCMBaselineAssessment$','<a href=''http://scavasqa01.nycsca.org/EEO/Vendor/BaselineAssessment''>http://scavasqa01.nycsca.org/EEO/Vendor/BaselineAssessment</a>')

	


	Select @ADMINEMAIL=Value from EEO_CONFIG where [key]='ADMINEMAIL'
	Select @COMPANY =Value from EEO_CONFIG where [key]='COMPANY'
	Select @EXTERNALAPPOINTMENTSLINK=Value from EEO_CONFIG where [key]='EXTERNALAPPOINTMENTSLINK'
	Select @EXTERNALCLASSLINK=Value from EEO_CONFIG where [key]='EXTERNALCLASSLINK'
	Select @EXTERNALDOCSLINK=Value from EEO_CONFIG where [key]='EXTERNALDOCSLINK'
	Select @APPEALSLINK =Value from EEO_CONFIG where [key]='APPEALSLINK'
	Select @ScopeBCMBaselineAssessment=Value from EEO_CONFIG where [key]='ScopeBCMBaselineAssessment'
	Select @ToEmail1=Value from EEO_CONFIG where [key]='ToEmail'
	
 
  
 		
 
	


	insert into #Replace values('$ADMINEMAIL$',@ADMINEMAIL)
	insert into #Replace values('$COMPANY$',@COMPANY)
	insert into #Replace values('$DATE$',GetDate())
	insert into #Replace values('$EXTERNALCLASSLINK$',@EXTERNALCLASSLINK) 
	insert into #Replace values('$EXTERNALDOCSLINK$',@EXTERNALDOCSLINK) 
	insert into #Replace values('$APPEALSLINK$',@APPEALSLINK) 
	insert into #Replace values('$EXTERNALAPPOINTMENTSLINK$',@EXTERNALAPPOINTMENTSLINK)
	insert into #Replace values('$ScopeBCMBaselineAssessment$',@ScopeBCMBaselineAssessment)
	
	
	insert into #Replace values('$C_CANCEL_COMMENTS$',isnull(@cancelledComments,''))
	insert into #Replace values('$CONSULTANT$',isnull(@consultant,''))
	insert into #Replace values('$APPOINTMENTDATE$',isnull(@appointmentdate,''))
	insert into #Replace values('$APPOINTMENTTIME$',isnull(@appointmenttime,''))
	insert into #Replace values('$SCOPEBEMAIL$',isnull(@scopeb,''))
	insert into #Replace values('$SCOPEBEMAILLIST$',isnull(@scopeBEmailList,''))
	



	

	--Vendor
	insert into #Replace values('$VENDORPRIMARYCONTACTEMAIL$',@VendorPrimaryContactEmail)
	insert into #Replace values('$VENDORPRIMARYCONTACT$',@VendorPrimaryContactName)
	insert into #Replace values('$VENDORCOMPANY$',@vendorCompany)
	insert into #Replace values('$FEDERALID$',@vendorCompany)
	
	/*
	set @workflowcomments=' '
	select  @workflowcomments=isnull(wh.comments ,' ')
	from eeo_vendor e, eeo_workflowhistory wh
	where e.vendorid=@vendorid
	and e.transactionid=wh.transactionid
	and wh.isactive=1
	
	insert into #Replace values('$WORKFLOWCOMMENTS$',@workflowcomments)
	*/
	/*
	
	insert into #Replace values('$MAJORITYOWNER$','')
	
	
	insert into #Replace values('$SUPPLIERPHYSICALADDRESS$','')

	insert into #Replace values('$SUPPLIERPHYSICALADDRESS2$','')
	insert into #Replace values('$SUPPLIERPHYSICALCITY$','')
	insert into #Replace values('$SUPPLIERPHYSICALSTATE$','')
	insert into #Replace values('$SUPPLIERPHYSICALZIP$','')

	insert into #Replace values('$SUPPLIERPHYSICALCOUNTRY$','')
	insert into #Replace values('$FEDERALID$','')
	insert into #Replace values('$QUALIFICATIONTYPE$','')

	insert into #Replace values('$USERFIRSTNAME$','')
	insert into #Replace values('$USERLASTNAME$','')
	insert into #Replace values('$VENDORCOMPANY$','')

	insert into #Replace values('$USEREMAIL$','')
	insert into #Replace values('$USERLASTNAME$','')
	insert into #Replace values('$SUPPLIERCOMPANY$','')
	insert into #Replace values('$USERFULLNAME$','')
	insert into #Replace values('$BDDANALYSTNAME$','')

	insert into #Replace values('$ADMINEMAIL$','')
	insert into #Replace values('$BDDANALYSTEMAIL$','')
	insert into #Replace values('$BDDMANAGEREMAIL$ ','')
	insert into #Replace values('$BDDDIRECTOREMAIL$','')
	insert into #Replace values('$CHIEFPROJECTOFFICEREMAIL$','')
	insert into #Replace values('$CMFIRMEMAILS$','')
	insert into #Replace values('$CONTSPECEMAIL$','')
	insert into #Replace values('$CQUMANAGEREMAIL$','')
	insert into #Replace values('$CQUMANAGEREMAIL$','')
	insert into #Replace values('$CQUDIRECTOREMAIL$','')
	insert into #Replace values('$CQUMANAGERMAIL$','')
	insert into #Replace values('$CQUREVIEWEREMAIL$','')
	insert into #Replace values('$CQUREVIEWEREMAIL$','')
	insert into #Replace values('$CQUMANAGEREMAIL$','')
	insert into #Replace values('$EEOCONTACTEMAIL$','')
	insert into #Replace values('$PRIMARYCONTACTEMAIL$','')
	insert into #Replace values('$PROJECTOFFICEREMAIL$','')
	insert into #Replace values('$REQUESTOREMAIL$','')
	insert into #Replace values('$REVIEWEREMAIL$','')
	insert into #Replace values('$SAFEMAIL$','')
	insert into #Replace values('$SAFPOEMAIL$','') 
	insert into #Replace values('$CQUMANAGEREMAIL$','') 
	insert into #Replace values('$CQUDIRECTOREMAIL','')
	insert into #Replace values('$SAFREVIEWEREMAIL$','')
	insert into #Replace values('$SUPPLIEREMAIL$','')
	insert into #Replace values('$U#USEREMAIL$','')
	insert into #Replace values('$USEREMAIL$','')
	insert into #Replace values('$VENDORCONTACTEMAIL$','')
	
	insert into #Replace values('$CONTSPECEMAIL$','')
	insert into #Replace values('$SUPPLIEREMAIL$','')
	insert into #Replace values('$U#USEREMAIL$','')
	insert into #Replace values('$USEREMAIL$','')

	insert into #Replace values('$VENDORRPRIMARYCONTACT$','')
	insert into #Replace values('$VENDORCONTACTNAME$','')
	insert into #Replace values('$CHIEFPROJECTOFFICERNAME$','')
	insert into #Replace values('$CMFIRMNAME$','')
	insert into #Replace values('$CONTSPECNAME$','')
	insert into #Replace values('$CQUMANAGERNAME$','')
	insert into #Replace values('$CQUREVIEWERNAME$','')
	insert into #Replace values('$EEOCONTACTNAME$','')
	insert into #Replace values('$REQUESTORNAME$','')
	insert into #Replace values('$REVIEWERFIRSTNAME$ $REVIEWERLASTNAME$','')
	insert into #Replace values('$SAFNAME$','')
	insert into #Replace values('$SAFREVIEWERNAME$','')
	insert into #Replace values('$SUPPLIERCOMPANY$','')
	insert into #Replace values('$VENDORCONTACTNAME$','')
	*/
	
	--select @toEmail , replace(@toEmail, StringToReplace, ReplacementString)
	--	from #Replace 
 
	select 
		@body = replace(@body, StringToReplace, ReplacementString),
		@fromEmail=replace(@fromEmail, StringToReplace, ReplacementString),
		@fromName=replace(@fromName, StringToReplace, ReplacementString),
		@toEmail=replace(@toEmail, StringToReplace, ReplacementString),
		@toName=replace(@toName, StringToReplace, ReplacementString),
		@subject=replace(@subject, StringToReplace, ReplacementString),
		@ccEmail=replace(@ccEmail, StringToReplace, ReplacementString),
		@bccEmail=replace(@bccEmail, StringToReplace, ReplacementString)
	from #Replace 

	
	drop table #Replace

	select 
		Id as 'Id',
		Name as 'Name',
		[Description] as 'Description',
		@fromEmail as 'FromEmail',
		@FromName as 'FromName',
		--@ToEmail1 as 'ToEmail', --'pshaiknayeem@nycsca.org;jayaramanv@nycsca.org;VGALPERIN@nycsca.org;' as 'ToEmail',
		@toEmail as 'ToEmail',
		@toName as 'ToName',
		@ccEmail as 'ccEmail',
		@bccEmail as 'bccEmail',
		@Subject as 'Subject',
		@body as 'Body',
		[Type] as 'Type',
		objects as 'Objects',
		Roles as 'Roles',
		[FileName] as 'FileName'
	from 
		emailmessage 
	where 
		name=@Name


Declare @emailHistoryId int
exec @emailHistoryId =[InsertEmailHistory] 'EEO',0,@Name,0,'System',@fromEmail,@ccEmail ,@subject 
exec InsertEmailLog @emailHistoryId,@userId,'Vendor',@toEmail,@body 
	

END
