﻿
/*
*********************************************************************************************************************
Procedure:	DeleteSupplierBusinessMixedInfo
Purpose:	Delete a row from SupplierBusinessMixedInfo table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/11/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteSupplierBusinessMixedInfo
	@id int
as

delete SupplierBusinessMixedInfo
where Id = @id
return @@RowCount

