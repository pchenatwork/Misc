﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierComment
Purpose:	Delete a row from SupplierComment table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
4/14/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierComment
	@id int
as

delete SupplierComment
where Id = @id
return @@RowCount

