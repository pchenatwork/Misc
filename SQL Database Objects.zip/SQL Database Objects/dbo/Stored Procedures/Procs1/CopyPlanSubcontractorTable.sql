﻿










CREATE procedure [dbo].[CopyPlanSubcontractorTable]	
	@planId int, 
	@newPlanId int,
	@changeUser nvarchar(50)
as
begin
	insert [PlanSubcontractor]
		( 
			PlanSubContractorId, 
			PlanId, 
			Type,
			ContractType, 
			TaxId, 
			ContractNo, 
			SolicitId, 
			SolicitNo, 
			SupplierId, 
			Company, 
			FederalId, 
			ContactName, 
			ContactPhone, 
			ContactEmail, 
			IsSupplierOnly, 
			IsInternalSupplier, 
			CertName, 
			CertExpirationDate, 
			IsReconciled, 
			SAFOverride, 
			SAFSubmittedDate, 
			SAFStatusDate, 
			SAFEstimate, 
			VerifiedEstimate, 
			AddressLine1, 
			AddressLine2, 
			City, 
			State, 
			ZipCode, 
			Country, 
			Phone, 
			Fax, 
			EstValue, 
			ApprovedValue, 
			WorkDescription, 
			StartDate, 
			EndDate, 
			IsNonMinority,
			SAFIsNonMinority,
			SupportDescription, 
			IsWicks, 
			IsUpload,
			EverTBD, 
			Tier, 
			Phase, 
			ParentId, 
			ParentCompany, 
			RequestRcvdDate, 
			CreateDate, 
			Status,
			StatusName,
			WorkflowId,
			TransactionId,
			ChangeDate, 
			ChangeUser, 
			CreateSupplierId
		)
	select  
			NEWID(), 
			@newPlanId, 
			'Verification',
			ContractType, 
			TaxId, 
			ContractNo, 
			SolicitId, 
			SolicitNo, 
			SupplierId, 
			Company, 
			FederalId, 
			ContactName, 
			ContactPhone, 
			ContactEmail, 
			IsSupplierOnly, 
			IsInternalSupplier, 
			CertName, 
			CertExpirationDate, 
			IsReconciled, 
			SAFOverride, 
			SAFSubmittedDate, 
			SAFStatusDate, 
			SAFEstimate, 
			VerifiedEstimate, 
			AddressLine1, 
			AddressLine2, 
			City, 
			State, 
			ZipCode, 
			Country, 
			Phone, 
			Fax, 
			EstValue, 
			ApprovedValue, 
			WorkDescription, 
			StartDate, 
			EndDate, 
			IsNonMinority,
			SAFIsNonMinority,
			SupportDescription, 
			IsWicks, 
			IsUpload, 
			EverTBD, 
			Tier, 
			Phase, 
			ParentId, 
			ParentCompany, 
			RequestRcvdDate, 
			CreateDate, 
			Status,
			StatusName,
			WorkflowId,
			TransactionId,
			GETDATE(),
			@changeUser, 
			CreateSupplierId
	from
		[PlanSubcontractor]
	where
		planId=@planId
	
end



 


































