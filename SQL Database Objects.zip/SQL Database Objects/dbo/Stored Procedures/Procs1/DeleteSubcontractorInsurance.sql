﻿/*
*********************************************************************************************************************
Procedure:	DeleteSubcontractorInsurance
Purpose:	Delete a row from SubcontractorInsurance table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/3/2008		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSubcontractorInsurance]
	@id int
as

delete SubcontractorInsurance
where Id = @id
return @@RowCount

