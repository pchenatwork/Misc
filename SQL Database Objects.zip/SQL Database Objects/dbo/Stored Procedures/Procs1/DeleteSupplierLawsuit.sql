﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierLawsuit
Purpose:	Delete a row from SupplierLawsuit table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/11/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierLawsuit
	@id int
as

delete SupplierLawsuit
where Id = @id
return @@RowCount

