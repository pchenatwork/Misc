﻿/*
*********************************************************************************************************************
Procedure:	DeleteSubcontractorVendex
Purpose:	Delete a row from SubcontractorVendex table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/20/2008		AECSOFTUSA\angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteSubcontractorVendex
	@id int
as

delete SubcontractorVendex
where Id = @id
return @@RowCount

