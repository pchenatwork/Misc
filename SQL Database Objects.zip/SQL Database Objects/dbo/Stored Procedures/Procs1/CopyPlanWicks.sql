﻿CREATE procedure [dbo].[CopyPlanWicks]
	@planId int,
	@changeUser nvarchar(50)
as
begin
	begin transaction
	begin try
		declare @ElectricalFederalId nvarchar(20)
		set @ElectricalFederalId = ''
		declare @PlumbingFederalId nvarchar(20)
		set @PlumbingFederalId = ''
		declare @HVACFederalId nvarchar(20)		
		set @HVACFederalId = ''
		declare @AwardDate datetime
		set @AwardDate='1900/1/1'

		declare @solicitSeq int
		set @solicitSeq = (select solicitseq from [Plan] where ID=@planId)

		Select
			@ElectricalFederalId = C_ELECTRICAL,
			@PlumbingFederalId = C_PLUMBING,
			@HVACFederalId = C_HVAC
		From 
			cms_Bidder_Wicks bw
		inner join
			[Plan] p
		on
			bw.c_vendor_id = p.FederalId
		Where 
			bw.N_SOLICIT_SEQ = @solicitSeq
			and p.Id = @planId

	
		Select
			@AwardDate = isnull(mv.D_AWARD_INTENT, '1900/1/1')
		from
			MV_SOLICIT_CONTRACT mv	
		inner join
			[Plan] p
		on
			isnull(mv.c_contract, '') = isnull(p.ContractNo, '') 
			and isnull(mv.me_contract, '') = isnull(p.MeContractNo, '')
			and isnull(mv.n_solicit_seq, 0) = isnull(p.SolicitSeq, 0)
		where 
			p.Id = @planId
		
		
		Declare @temp TABLE
		(
			PlanSubcontractorId int,
			SubcontractorId int
		)
		
		Declare  @temp1 table
		(
			Classification nvarchar(50),
			IsCertifiedByNY char(1),
			CertifiedAgent nvarchar(50)
		)
		
		insert into PlanSubcontractor
		(
			PlanSubContractorId,
			PlanId,
			Type,
			ContractType,
			TaxId,
			ContractNo,
			SolicitId, 
			SolicitNo,
			SupplierId,
			Company,
			FederalId,
			ContactName, 
			ContactPhone, 
			ContactEmail, 
			IsSupplierOnly, 
			IsInternalSupplier,
			CertName, 
			CertExpirationDate, 
			IsReconciled, 
			SAFOverride, 
			SAFSubmittedDate, 
			SAFStatusDate, 
			SAFEstimate, 
			VerifiedEstimate, 
			AddressLine1,
			AddressLine2,
			City,
			State,
			ZipCode,
			Country,
			Phone,
			Fax,
			EstValue,
			ApprovedValue,
			WorkDescription,
			StartDate,
			EndDate,
			IsNonMinority,
			SAFIsNonMinority,
			SupportDescription,
			IsWicks,
			IsUpload,
			EverTBD, 
			Tier, 
			Phase, 
			ParentId, 
			ParentCompany, 
			RequestRcvdDate, 
			CreateDate, 
			Status,
			StatusName,
			WorkflowId,
			ChangeDate, 
			ChangeUser, 
			CreateSupplierId,
			SAFId
		)
		output inserted.Id, inserted.SAFId	
		into @temp
		select 
			NEWID(),
			@planId,
			'',
			'',
			s.TaxId,
			s.ContractNo,
			p.SolicitSeq, 
			p.SolicitNo,
			s.SupplierId,
			s.Company,
			s.FederalId,
			'', 
			'', 
			'', 
			'N', 
			'', 
			'', 
			'1900/1/1', 
			'', 
			'', 
			'1900/1/1',
			'1900/1/1',
			'', 
			'', 
			s.AddressLine1,
			s.AddressLine2,
			s.City,
			s.State,
			s.ZipCode,
			s.Country,
			s.Phone,
			s.Fax,
			s.EstValue,
			s.EstValue,
			s.WorkDescription,
			s.StartDate,
			s.EndDate,
			case
			when isnull(s.Mbe, '') ! ='Y' and  isnull(s.Wbe, '') !='Y' and  isnull(s.Lbe, '') !='Y' 
				and isnull(s.SBSMbe, '') !='Y' and  isnull(s.SBSWbe, '') !='Y' and  isnull(s.SBSLbe, '') !='Y' then 'Y'
			else 'N' end,
			'',
			s.SupportDescription,
			'Y',
			IsUpload, 
			'N', 
			0, 
			[dbo].[ProjectPhase](@AwardDate, p.ProjectDuration, isnull(s.StartDate, '1900/1/1')),
			0, 
			'', 
			'1900/1/1',
			GETDATE(), 
			0,
			'',
			0,
			GETDATE(),
			@changeUser, 
			0,
			s.Id
		from 
			Subcontractor s
		inner join
			[plan] p
		on
			s.contractNo = p.contractNo
			and isnull(s.IsWicks, '')='Y' 
			and s.FederalId in (@ElectricalFederalId, @PlumbingFederalId, @HVACFederalId)
			and p.Id = @planId
			and s.status in (13, 17)
			and s.Id not in (select isnull(SAFId, 0) from PlanSubcontractor)

		

		declare @planSubContractorId int
		declare @subContractorId int
		declare @amount float
		declare @expirationDate datetime	
		declare @mycursor cursor
		set @mycursor = cursor for (select PlanSubcontractorid from @temp)
		open @mycursor
		fetch next from @mycursor into @planSubContractorId
		while @@fetch_status = 0
			
			begin 
				set @subContractorId = (select SubcontractorId from @temp where PlanSubcontractorId = @planSubContractorId)
				

				Insert into PlanSubcontractorCategory
				(
					PlanSubcontractorId,
					CategoryId,
					ChangeDate,
					ChangeUser,
					SAFId
				)
				select 
					@planSubContractorId,
					CategoryId,
					ChangeDate,
					ChangeUser,
					Id
				from 
					SubcontractorCategory
				where
					SubcontractorId = @subContractorId
		
				insert into @temp1
				(
					Classification,
					IsCertifiedByNY,
					CertifiedAgent
				)
				select
					Upper(t.Classification),
					case 
					when CharIndex('SBS', t.Classification)>0 then 'N'
					else 'Y' 
					end as IsCertifiedByNY,
					case 
					when CharIndex('SBS', t.Classification)>0 then 'SBS'
					else NULL 
					end as CertifiedAgent		
				from 
					(SELECT Classification, Iscertify
					FROM (select * From Subcontractor where id =@subContractorId) s
					  UNPIVOT(Iscertify FOR
						Classification IN(MBE, WBE, LBE, SBSMBE, SBSWBE, SBSLBE))  AS U) t		
				where
					isnull(t.Iscertify, 'N') in ('Y')
			
				
				if not exists(select * from @temp1)		
					insert into @temp1
					(
						Classification,
						IsCertifiedByNY
					)
					select
						'NonMinority',
						''			
				
				
				insert into PlanSubcontractorCertification
				(
					PlanSubcontractorId,
					Classification,
					IsCertifiedByNY,
					CertifiedAgent,
					CertificationId,
					Amount,
					ChangeUser,
					ChangeDate
				)
				select
					@planSubContractorId,
					Classification,
					IsCertifiedByNY,
					CertifiedAgent,
					NEWID(),
					0,
					@changeUser,
					GETDATE()
				from
					@temp1
			
																		
				update t1
				set
					t1.Amount = p.EstValue
				from
					(select top 1 * from planSubcontractorcertification where planSubcontractorId = @planSubContractorId order by Id) t1
				inner join
					PlanSubcontractor p
				on
					t1.PlanSubcontractorId = p.Id
					
				delete from @temp1	
				
				fetch next from @mycursor into @planSubContractorId
				
			end		

		commit transaction
		return 1
	end try

	begin catch
		rollback transaction
		return 0
	end catch

end
