﻿CREATE procedure [dbo].[DeleteVendorCommentAttachment] 
	@id int
AS

Update VendorComment
Set FileName = null,
	AttachmentId = null
Where Id = @id
return @@rowcount
