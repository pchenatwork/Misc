﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierVettings
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
11/23/2007	Lily Xiong		Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSupplierVettings]
	@vettingId int,
	@supplierVettingsXml ntext
AS
Declare @hdoc int

-- Convert GroupSupplier data from XML to in memory table. 
EXEC sp_xml_preparedocument @hDoc OUTPUT, @supplierVettingsXml

Delete From SupplierVetting
where VettingId = @vettingId
and SupplierId in (Select SupplierId 
	FROM OPENXML(@hDoc, '/ArrayOfSupplierVetting/SupplierVetting', 1)
	with
	(
		SupplierId int
	)
)
--Release the internal representation of the XML document.
EXEC sp_xml_removedocument @hDoc
RETURN 1



