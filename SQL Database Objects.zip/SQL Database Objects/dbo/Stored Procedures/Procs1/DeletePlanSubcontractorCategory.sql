﻿/*
*********************************************************************************************************************
Procedure:	DeletePlanSubcontractorCategory
Purpose:	Delete a row from PlanSubcontractorCategory table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/1/2010		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeletePlanSubcontractorCategory
	@id int
as

delete PlanSubcontractorCategory
where Id = @id
return @@RowCount

