﻿





CREATE procedure [dbo].[CopyLicense]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin
	insert License
		(
			SupplierId,
			LicenseType,
			LicenseAgent,
			LicenseNo,
			ExpirationDate,
			Filename,
			Certificate,
			FaxIn,
			LicenseId,
			PersonnelId,
			Corporation,
			EffectiveDate,
			ChangeDate,
			ChangeUser

		)
	select
			@newSupplierId,
			l.LicenseType,
			l.LicenseAgent,
			l.LicenseNo,
			l.ExpirationDate,
			l.Filename,
			l.Certificate,
			l.FaxIn,
			newid(),
			sp.Id,
			l.Corporation,
			l.EffectiveDate,
			getdate(),
			@changeUser
	from License l, SupplierPersonnel sp 
	where l.supplierId=@supplierId
		and l.personnelId = sp.CopyId
		and DateDiff(day, l.ExpirationDate, getdate()) < 0

end








