﻿IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[DeletePlanSubcontractorByPlan]'))
   EXEC('CREATE PROCEDURE [dbo].[DeletePlanSubcontractorByPlan] AS BEGIN SET NOCOUNT ON; END')
GO

/*
*********************************************************************************************************************
Procedure:	DeletePlan
Purpose:	Delete a row from Plan table.
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/1/2010		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure [dbo].[DeletePlanSubcontractorByPlan]
	@id int
as

declare @temp table
(
	plansubcontractorid int
)

begin transaction

begin try
	insert into @temp 
		(plansubcontractorid) 
	select 
		Id 
	from 
		PlanSubcontractor 
	where PlanId = @id

	delete dbo.PlanSubcontractorCategory where PlanSubcontractorId in (select plansubcontractorid from @temp)

	delete dbo.PlanSubcontractorCertification where PlanSubcontractorId in (select plansubcontractorid from @temp)
	
	delete dbo.PlanSubcontractorDocument where PlanSubcontractorId in (select plansubcontractorid from @temp)

	delete dbo.PlanSubcontractorProperty where PlanSubcontractorId in (select plansubcontractorid from @temp)
	
	delete dbo.PlanSubcontractorPro where PlanId = @id

	delete dbo.PlanSubcontractor where PlanId = @id
	
	commit transaction
	return @@RowCount
end try
begin catch
	rollback transaction
	return 0
end catch
GO
