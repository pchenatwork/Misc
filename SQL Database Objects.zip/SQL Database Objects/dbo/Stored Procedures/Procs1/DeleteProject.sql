﻿

/*
*********************************************************************************************************************
Procedure:	DeleteProject
Purpose:	Delete a row from Project table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/30/2009		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteProject]
	@id int
as

begin transaction
declare @tempBidder table
(
	id int
)

	delete ContractItem
	Where ContractId in (select Id from [Contract] Where ProjectId = @id)

	delete [Contract]
	Where ProjectId = @id
	
	delete ProjectRevisedEstimate
	Where ProjectId = @id
	
	delete PackageHistory
	Where ProjectId = @id
	
	delete ProjectAddendum
	where projectid = @id

	delete Package
	Where ProjectId = @id

	delete dbo.ProjectAdsCategory
	where projectid = @id

	delete ProjectAlternate
	Where ProjectId = @id
	
	delete ProjectAward
	Where ProjectId = @id

	delete dbo.ProjectBAFO
	Where ProjectId = @id
	
	delete dbo.ProjectBidHistory
	Where ProjectId = @id
	
	delete ProjectBidPartLocation
	Where ProjectId = @id

	delete ProjectComment
	Where ProjectId = @id

	delete ProjectDocument
	Where ProjectId = @id

	delete ProjectItem
	Where ProjectId = @id

	delete ProjectOfficial
	Where ProjectId = @id
	
	delete ProjectOrderSupplierDetail
	Where ProjectOrderSupplierId in (Select Id from ProjectOrderSupplier Where ProjectOrderId in (Select Id from ProjectOrder Where ProjectId = @id))
	
	delete ProjectOrderSupplier
	Where ProjectOrderId in (Select Id from ProjectOrder Where ProjectId = @id)
	
	delete ProjectOrderDetail
	Where ProjectBidPartId in (Select Id from ProjectBidPart where ProjectId = @id)
	
	delete ProjectOrder
	Where ProjectId = @id

	delete ProjectProperty
	Where ProjectId = @id

	delete ProjectQuestion
	Where ProjectId = @id

	delete ProjectReport
	Where ProjectId = @id

	delete ProjectSupplier
	Where ProjectId = @id
	
	delete ProjectTransactionUser
	Where ProjectTransactionId in (select Id from ProjectTransaction Where ProjectId = @id)
	
	delete ProjectTransactionDetail
	Where ProjectTransactionId in (select Id from ProjectTransaction Where ProjectId = @id)
	
	delete ProjectTransaction
	Where ProjectId = @id
	
	delete ProjectBidPart
	Where ProjectId = @id

	delete ProjectWorkflow
	Where ProjectId = @id

	insert into @tempBidder
	(
		Id
	)
	select
		Id
	from Bidder where projectid=@id


	delete BidderApprenticeshipProgram where bidderId in (select id from @tempBidder)
	delete BidderBreakdown where bidderId in (select id from @tempBidder)
	delete BidderReject where bidderId in (select id from @tempBidder)
	delete BidderWicks where bidderId in (select id from @tempBidder)

	delete bidder
	Where ProjectId = @id

	delete Project
	where Id = @id



if @@error = 0
	Commit Transaction   
else
	RollBack Transaction
return @@RowCount


