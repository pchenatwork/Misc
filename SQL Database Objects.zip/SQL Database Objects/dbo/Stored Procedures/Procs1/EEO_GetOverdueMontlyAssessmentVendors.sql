﻿IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[EEO_GetOverdueMontlyAssessmentVendors]'))
   EXEC('CREATE PROCEDURE [dbo].[EEO_GetOverdueMontlyAssessmentVendors] AS BEGIN SET NOCOUNT ON; END')
GO
/*
 Rules for Overdue Monthly Assessment counter
    a.	Counter should consider Mentor firms only (should be enrolled into mentor program)
    b.	Should list mentor firms that have any UnSubmitted projects from previous months 
    e.g. if the assessment is supposed to be completed between Dec 15th to Jan 15th. On Jan 16th the vendor should be part of the counter. System should have capability to configure from and to dates.
*/
/*
*******************************************************************************
Procedure:	EEO_GetOverdueMontlyAssessmentVendors
Purpose:	Called by EEO_GetDashboardCounter.SQL
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
08/02/2017      PCHEN               Comment section first created
    1. Sync with Staging DB
    2. URS(11-1445800) got purchased by AECom(13-5511947), Combine two EINs into one
*******************************************************************************
*/
ALTER PROCEDURE [dbo].[EEO_GetOverdueMontlyAssessmentVendors]
        @userId int
AS

Begin

    Declare @vendorid as int
    Declare @prev_vendorid as int
    Declare @startDate as Date 
    Declare @endDate as Date 
    Declare @currentDate date
    set @currentDate=getdate()

    Declare @DayOfMonth Int  
    Declare @Month Int
    Declare @Year Int
    Declare @EndYear Int
    Declare @PeriodId Int

    set @PeriodId= 1
    set @prev_vendorid= 0


    DECLARE @ret int;


    Declare @tempVendorPeriod Table
    (
        Id int identity (1,1) Primary Key,
        PeriodId decimal(5,0),
        Vendorid int,
        Period_StartDate Datetime,
        Period_EndDate Datetime
    )
 
  

    Declare @Days4MonthlyAssessment int
    Declare @title as nvarchar(100) 

    Select @Days4MonthlyAssessment = ISNULL([value],0) from dbo.EEO_CONFIG
        where [key] = 'Days4MonthlyAssessment'

    selecT  @title =u.Title from   [user] u
     where u.Id=@userid
    
    ---** 20170802 PCH AECOM took over USR, bind these two EIN together
    DECLARE @t_CombinedEINs TABLE (
        TaxID NVARCHAR(100)
    )
    IF @title IN ('11-1445800', '13-5511947')
        INSERT INTO @t_CombinedEINs VALUES ('11-1445800'), ('13-5511947')
    --- **

    DECLARE eeo_vendor_cursor CURSOR FOR 
            SELECT distinct GD.VENDORID,
                    DATEFROMPARTS(YEAR(GD.SD_START_DATE),MONTH(GD.SD_START_DATE),1)  AS STARTDATE,   -- start of the month
                    EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS ENDDATE  --  USE SD_EXT_GRAD_DATE FIRST OTHERWISE SD_GRAD_DATE AND EXCLUDE FINAL YEAR
            FROM (SELECT * FROM  DBO.EEO_MENTOR_GRAD_DETAIL 
                            WHERE ID IN  
                                    (SELECT MAX(ID) AS ID   FROM DBO.EEO_MENTOR_GRAD_DETAIL  -- MAX RECORD FOR VENDOR WITH C_MENTOR_TYPE
                                        WHERE    C_MENTOR_TYPE='MENTOR'
                                        GROUP BY VENDORID,C_MENTOR_TYPE 
                                        )
            ) GD , EEO_VENDOR EV, VENDOR V  
            WHERE  GD.VENDORID=EV.VENDORID
                    AND EV.VENDORID =V.ID
                    AND EV.MENTORFLAG IN (6) -- only those vendors marked as  MENTOR


 
    OPEN eeo_vendor_cursor
        FETCH NEXT FROM eeo_vendor_cursor 
            INTO @vendorid, @startDate,@endDate

        WHILE @@FETCH_STATUS = 0
        BEGIN

               Insert Into @tempVendorPeriod
                (   PeriodId ,
                    Vendorid,
                    Period_StartDate, 
                    Period_EndDate  
                 )
                  SELECT number+1,
                         @vendorid,
                         DATEADD(year,number,@startDate) PeriodStart,
                        DATEADD(DAY,-1,	DATEADD(year,number+1,@startDate)) PeriodEnd 
                from master..spt_values sv
                     where sv.type = 'P' AND DATEADD(year,number,@startDate) <= DATEADD(day, @Days4MonthlyAssessment,@endDate) 

                -- Get the next vendor.
        FETCH NEXT FROM eeo_vendor_cursor 
            INTO @vendorid, @startDate,@endDate
        END 

    CLOSE eeo_vendor_cursor;
    DEALLOCATE eeo_vendor_cursor;


    Select distinct pm.vendorid,m.ME_CONTRACT
    from 
        (
            SELECT Vendorid,PeriodId ,Period_StartDate,Period_EndDate, DATEADD(month,number,Period_StartDate) PeriodMonth
                from @tempVendorPeriod t, master..spt_values sv
                where sv.type = 'P' and DATEADD(month,number,t.Period_StartDate) <t.Period_EndDate
        ) pm 
        inner join vendor v on v.id=pm.vendorid
        left outer join  MV_SOLICIT_CONTRACT m on  ISNULL(m.C_VENDOR_ID,m.ME_VENDOR_ID)= V.FEDERALID 
    where 
        PeriodMonth  >= DATEADD(dd, 1, EOMONTH(m.D_CONSTR_BEGIN , -1)) 
        and EOMONTH(pm.PeriodMonth) <= EOMONTH(isnull(m.D_CONSTR_END,@currentDate)) 
        
        and PeriodMonth  <= EOMONTH(@currentDate, -1)  -- ********** check only period months less then or equal to last month 			**********
        and  not exists (
                    select * 
                    from eeo_latest_ppm_rating  
                    where vendorid=pm.vendorid
                        and PROJ_CODE=m.c_package_code
                        and EOMONTH(MONTH_RATED)=	EOMONTH(PeriodMonth)	 -- very important						
                        and isnull(IS_SUBMITTED,0)=1
            )
        
        and (@userId=0 or 
                (@userId<> 0 and (@title=''  or (@title!='' and m.ME_CONTRACT in (select c_contract from MV_SOLICIT_CONTRACT where C_VENDOR_ID=@title OR C_VENDOR_ID IN (SELECT TaxID FROM @t_CombinedEINs))))))	
     
END
GO

