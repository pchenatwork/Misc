﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE Procedure [dbo].[EEO_CheckDirectorApprovalforEnrollment]
	-- Add the parameters for the stored procedure here
	@vendorId int,
	@approvalRejection char
AS
BEGIN
	declare @count int
	

	
	if @approvalRejection='1' -- Appeals
		Begin
					set @count =(
					select 
						count(*)
					from
						EEO_MENTOR_APPEALS e
					where
						vendorid=@vendorid
						and B_APPROVE=1

					)
		
		end
	else if @approvalRejection='2' -- BDD Director graduation approval
		Begin
					set @count =(
						select count(*)
					from (
						select 
							top 1 *
						from
							EEO_VENDOR_PROPERTY e
						where
							vendorid=@vendorid
							and e.PROPERTYID=8
							order by changedate desc
						) w
					where w.PROPERTYVALUE=iif(@approvalRejection='2','Approved','Denied')

					)
		
		end
	else if @approvalRejection='3' -- Director MP graduation approval
		Begin
					set @count =(
					select 
						count(*)
					from
						EEO_VENDOR_PROPERTY e
					where
						vendorid=@vendorid
						and e.PROPERTYID=16
						and e.PROPERTYVALUE=iif(@approvalRejection='3','Approved','Denied')

					)
		
		end
	else if @approvalRejection='4' -- BDD Director GM Enrollment Approval
		Begin
					set @count =(
					select 
						count(*)
					from
						EEO_VENDOR_PROPERTY e
					where
						vendorid=@vendorid
						and e.PROPERTYID=3
						and e.PROPERTYVALUE=iif(@approvalRejection='4','Approved','Denied')

					)
		
		end
	else if @approvalRejection='5' -- Director MP GM Enrollment approval
		Begin
					set @count =(
					select 
						count(*)
					from
						EEO_VENDOR_PROPERTY e
					where
						vendorid=@vendorid
						and e.PROPERTYID=10
						and e.PROPERTYVALUE=iif(@approvalRejection='5','Approved','Denied')

					)
		
		end
	else if @approvalRejection='6' -- Director MP GM Enrollment approval
		Begin
					set @count =(
					select 
						count(*)
					from
						EEO_VENDOR_PROPERTY e
					where
						vendorid=@vendorid
						and e.PROPERTYID=4
						and e.PROPERTYVALUE=iif(@approvalRejection='6','Approved','Denied')

					)
		
		end
	else
		begin
	
		set @count =(
						select count(*)
					from (
						select 
							top 1 *
						from
							EEO_VENDOR_PROPERTY e
						where
							vendorid=@vendorid
							and e.PROPERTYID=7
							order by changedate desc
						) w
					where w.PROPERTYVALUE=iif(@approvalRejection='A','Approved','Denied')

					)
		

			end
	select @count
	return @count
END
