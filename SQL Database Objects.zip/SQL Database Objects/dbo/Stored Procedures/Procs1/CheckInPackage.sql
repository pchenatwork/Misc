﻿
CREATE procedure [dbo].[CheckInPackage] 
	@id int,
	@changeUser nvarchar(50)
As
Begin
Set NoCount on

Update Package
Set CheckOutId = null,
	CheckOutType = null,
	CheckOutDate = null,
	ChangeUser = @changeUser,
	ChangeDate = getdate()
Where Id = @id

return @@rowcount

End
