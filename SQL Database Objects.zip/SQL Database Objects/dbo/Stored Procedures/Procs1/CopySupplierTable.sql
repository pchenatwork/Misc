﻿



CREATE procedure [dbo].[CopySupplierTable]	
	@id int,
	@changeUser nvarchar(50)
as
begin
	
	insert Supplier
		(
			SupplierType,
			Company,
			TradeNames,
			Phone,
			Extension,
			Fax,
			Email,
			Url,
			BusinessType,
			LegalStructure,
			FederalId,
			StateIncorporation,
			StateSalesTaxId,
			SalesTaxState,
			YearEstablished,
			EmployeeTotal,
			InsuranceCarrier,
			DbNum,
			PaymentTerm,
			Description,
			Gender,
			Ethnicity,
			IsCertified,
			HasOnlineCatalog,
			HasOnlineSell,
			HasEdiCapable,
			AcceptCreditCard,
			CurrentSupplier,
			AnnualSales,
			CurrentContact,
			CurrentPhone,
			CurrentExtension,
			CurrentLocation,
			HasSupplierDiversityProgram,
			IsPublicTraded,
			PrimaryCategoryId,
			CcrListed,
			CageCode,
			PreparerName,
			PreparerPhone,
			PreparerEmail,
			Status,
			Password,
			InternalVendorId,
			LogoId,
			PictureId,
			SupplierId,
			PaymentMethod,
			Currency,
			DiscountTerm,
			ParentId,
			UserName,
			ParentDuns,
			SupplierStatus,
			TransferredFlag,
			EEOMasterTransferredFlag,
			REVStatusTransferredFlag,
			VASId, 
			ApplyDate,
			ApplyUser,
			ChangeDate,
			ChangeUser
		)
	select
			SupplierType,
			Company,
			TradeNames,
			Phone,
			Extension,
			Fax,
			Email,
			Url,
			BusinessType,
			LegalStructure,
			FederalId,
			StateIncorporation,
			StateSalesTaxId,
			SalesTaxState,
			YearEstablished,
			EmployeeTotal,
			InsuranceCarrier,
			DbNum,
			PaymentTerm,
			Description,
			Gender,
			Ethnicity,
			IsCertified,
			HasOnlineCatalog,
			HasOnlineSell,
			HasEdiCapable,
			AcceptCreditCard,
			CurrentSupplier,
			AnnualSales,
			CurrentContact,
			CurrentPhone,
			CurrentExtension,
			null,
			HasSupplierDiversityProgram,
			IsPublicTraded,
			PrimaryCategoryId,
			'Y',
			CageCode,
			PreparerName,
			PreparerPhone,
			PreparerEmail,
			Status,
			Password,
			InternalVendorId,
			LogoId,
			PictureId,
			newid(),
			PaymentMethod,
			Currency,
			DiscountTerm,
			ParentId,
			UserName,
			ParentDuns,
			SupplierStatus,
			TransferredFlag,
			EEOMasterTransferredFlag,
			REVStatusTransferredFlag,
			VASId,
			getdate(),
			ApplyUser,
			getdate(),
			@changeUser			
	from supplier where id=@id


return @@Identity


end















