﻿

/*
*********************************************************************************************************************
Procedure:	DeleteProjectReport
Purpose:	Delete a row from ProjectReport table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
1/18/2010		AECSOFTUSA\angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteProjectReport
	@id int
as

delete ProjectReport
where Id = @id
return @@RowCount

