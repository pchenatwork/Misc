﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierRelatedFirm
Purpose:	Delete a row from SupplierRelatedFirm table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/12/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierRelatedFirm
	@id int
as

delete SupplierRelatedFirm
where Id = @id
return @@RowCount

