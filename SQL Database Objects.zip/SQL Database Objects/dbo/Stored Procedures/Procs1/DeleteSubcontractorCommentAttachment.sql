﻿CREATE procedure [dbo].[DeleteSubcontractorCommentAttachment] 
	@id int
AS

Update SubcontractorComment
Set FileName = null,
	AttachmentId = null
Where Id = @id
return @@rowcount
