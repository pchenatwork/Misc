﻿/*
*********************************************************************************************************************
Procedure:	 
Purpose:	 
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
09/11/2015		Syed			    Created
*********************************************************************************************************************
*/
CREATE PROCEDURE [dbo].[EEO_GetCMMontlyDashboardCounter]
(
	@userId int,
     @ret int OUTPUT
)
AS

Begin

    declare @tableVar table
    (
         Vendorid int
    )

	  
    
    Insert into @tableVar
       exec  dbo.EEO_GetCMMontlyVendors  @userId



    
    SELECT @ret = Count(*)FROM @tableVar
    IF (@ret IS NULL) 
        SET @ret = 0;
        
                                             
                                      
    
END
