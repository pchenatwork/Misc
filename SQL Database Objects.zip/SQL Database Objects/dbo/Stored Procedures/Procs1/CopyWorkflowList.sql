﻿




/*
*********************************************************************************************************************
Procedure:	CopyWorkflowList
Purpose:	Copy existing workflowlist into WorkflowList table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
12/27/2005 		Lily Xiong		Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CopyWorkflowList]
	@id int,
	@projectId int
	
as
begin
	Declare @newId int
	
	insert into WorkflowList
	(
		Type,
		ProjectId,
		Name,
		Description,
		Status,
		EmailType
	)
	select Type,
		@projectId,
		name + '_Copy', 
		Description,
		Status,
		EmailType
	from WorkflowList
	Where id = @id
	
	Set @newId = @@identity
	
	Insert into WorkflowNode
	(
		WorkflowId,
		UserStepId,
		Name,
		Description,
		Type,
		ConditionId,
		NodeFromId,
		NodeToId,
		TimeToSkip,
		Counter,
		IsSkip,
		IsPermCtrl,
		Action1,
		Action2,
		Action3,
		Action4,
		Action5,
		Action6,
		EmailAction,
		TempNodeId
	)
	Select	@newId,
		UserStepId,
		Name,
		Description,
		Type,
		ConditionId,
		0,
		0,
		TimeToSkip,
		Counter,
		IsSkip,
		IsPermCtrl,
		Action1,
		Action2,
		Action3,
		Action4,
		Action5,
		Action6,
		EmailAction,
		Id
	From WorkflowNode
	Where WorkflowId = @id
		and Type <> 1

	Insert into WorkflowNode
	(
		WorkflowId,
		UserStepId,
		Name,
		Description,
		Type,
		ConditionId,
		NodeFromId,
		NodeToId,
		TimeToSkip,
		Counter,
		IsSkip,
		IsPermCtrl,
		Action1,
		Action2,
		Action3,
		Action4,
		Action5,
		Action6,
		EmailAction,
		TempNodeId
	)
	Select @newId,
		UserStepId,
		Name,
		Description,
		Type,
		ConditionId,
		NodeFromId,
		NodeToId,
		TimeToSkip,
		Counter,
		IsSkip,
		IsPermCtrl,
		Action1,
		Action2,
		Action3,
		Action4,
		Action5,
		Action6,
		EmailAction,
		Id
	From WorkflowNode
	Where WorkflowId = @id
		and type = 1

	Update n1
	Set n1.NodeFromId = n2.Id
	From WorkflowNode n1, WorkflowNode n2
	where n1.WorkflowId = @newId
		and n2.WorkflowId = @newId
		and n1.NodeFromId = n2.TempNodeId

	Update n1
	Set n1.NodeToId = n2.Id
	From WorkflowNode n1, WorkflowNode n2
	where n1.WorkflowId = @newId
		and n2.WorkflowId = @newId
		and n1.NodeToId = n2.TempNodeId

	Insert Into WorkflowCondition
	(
		WorkflowNodeId,
		Name,
		Type,
		Description,
		DisplayOrder,
		DisplayName,
		ErrorMessage,
		FunctionName,
		FunctionValue,
		Condition,
		ConditionXml,
		Score,
		Status
	)
	select nn.Id,
		t.Name,
		t.Type,
		t.Description,
		t.DisplayOrder,
		t.DisplayName,
		t.ErrorMessage,
		t.FunctionName,
		t.FunctionValue,
		t.Condition,
		t.ConditionXml,
		t.Score,
		t.Status
	From WorkflowCondition t, WorkflowNode n, WorkflowNode nn
	where t.WorkflowNodeId = n.Id
		and n.WorkflowId = @id
		and nn.WorkflowId = @newId
		and n.Id = nn.TempNodeId

	Insert Into WorkflowAction
	(
		WorkflowNodeId,
		Name,
		Type,
		Description,
		DisplayOrder,
		DisplayName,
		FunctionName,
		FunctionValue,
		Status
	)
	select nn.Id,
		t.Name,
		t.Type,
		t.Description,
		t.DisplayOrder,
		t.DisplayName,
		t.FunctionName,
		t.FunctionValue,
		t.Status
	From WorkflowAction t, WorkflowNode n, WorkflowNode nn
	where t.WorkflowNodeId = n.Id
		and n.WorkflowId = @id
		and nn.WorkflowId = @newId
		and n.Id = nn.TempNodeId

	Insert Into WorkflowNodeUser
	(
		WorkflowNodeId,
		UserId,
		Status,
		RoleId
	)
	select nn.Id,
		t.UserId,
		t.Status,
		t.RoleId
	From WorkflowNodeUser t, WorkflowNode n, WorkflowNode nn
	where t.WorkflowNodeId = n.Id
		and n.WorkflowId = @id
		and nn.WorkflowId = @newId
		and n.Id = nn.TempNodeId

	return @newId
end



