﻿/*

exec EEO_ActionPlanReport @AssessmentPeriod=N'3',@VendorId=17295,@Type=N'AA'

exec EEO_ActionPlanReport @VendorId=17718,@Type=N'AA',
@BeginDate='1900-01-01 00:00:00',@EndDate='1900-01-01 00:00:00'



exec EEO_ActionPlanReport @VendorId=0,@Type=N'AA',
@BeginDate='2015-11-03 00:00:00',@EndDate='2015-11-05 00:00:00'



select * from EEO_ACTION_PLANS where vendorid=17295

select distinct (count(vendorid)) As TotAs,'' As scopA,'' As scopA
from EEO_ACTION_PLANS 
Union


select count(*) As scopA,''
from EEO_ACTION_PLANS 
Where category like '%Scope A%'
Union
select '',count(*) As scopB
from EEO_ACTION_PLANS 
Where category not like '%Scope A%'

select * from EEO_ACTION_PLANS where VendorId= 18597 and PeriodId=2
select * from EEO_ACTION_PLANS where VendorId= 18597 and PeriodId=2

select * from EEO_ACTION_PLANS where VendorId= 17999 



exec EEO_ActionPlanReport @VendorId=0,@Type=N'AA',
@BeginDate='2015-11-30 00:00:00',@EndDate='2015-11-30 00:00:00'

*/

CREATE proc EEO_ActionPlanReport
(
--@AssessmentPeriod varchar(50) =null,
@VendorId int  =null,
@Type varchar(50)  =null,
@BeginDate DateTime =null,
@EndDate DateTime =null
)
As

if(@BeginDate='1900-01-01 00:00:00')
	Set @BeginDate=null
if(@EndDate ='1900-01-01 00:00:00')
	Set @EndDate =null


select UPPER(v.Company) as Company, ap.VendorId,ap.PeriodId,upper(ap.Category) as Category,ap.ActualScore,ap.MaxScore,
(select UPPER(FirstName+' '+LastName) From [User] where id =ap.ActionBy) as ActionBy
,convert(varchar(10),ap.UPDATED_DATE,101) As ActionDate--ap.ActionDate
,ap.Comments,'' As AssessmentPeriod
from EEO_ACTION_PLANS ap
Inner join Vendor v on v.Id=ap.VendorId
where 
ap.VENDORID=case when @VendorId =0 then ap.VENDORID else @VendorId end
--and  
--ap.PeriodId=case when @AssessmentPeriod =0 then ap.periodid else @AssessmentPeriod end
and
(
	(@Type='AA' and ap.Category =ap.Category )
	or
	(@Type='SA' and ap.Category Like '%Scope A%' )
	or
	(@Type='SB' and ap.Category not Like '%Scope B%' )
)
and  
(
--@BeginDate is null or 
ap.UPDATED_DATE >= @BeginDate
and
--@EndDate is null or 
ap.UPDATED_DATE <= DATEADD(day, 1, @EndDate) --@EndDate
)
order by ap.UPDATED_DATE Asc
