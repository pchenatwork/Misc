﻿/*
*********************************************************************************************************************
Procedure:	DeleteSection
Purpose:	Delete a row from Section table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/29/2004		Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteSection
	@id int
as
declare @question table
( 
Id int
)
Insert @question ( Id ) ( Select Id From Question Where SectionId = @id )
Delete Answer Where QuestionId in ( Select Id From @question ) 
Delete Question Where Id in ( Select Id From @question)
delete Section
where Id = @id
return @@RowCount


