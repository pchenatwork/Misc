﻿

/*
*********************************************************************************************************************
Procedure:	 
Purpose:	 
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/10/2015		Pasha				Created
*********************************************************************************************************************
*/
Create PROCEDURE [dbo].[EEO_GetMentorAnnualBidCeilingCounter]
(
 @ret int OUTPUT
)
AS

Begin

 declare @tableVar table
    (
         Vendorid int
    )

	  
    
    Insert into @tableVar
       exec  dbo.EEO_GetMentorAnnualBidCeiling  



    
    SELECT @ret = Count(*)FROM @tableVar
    IF (@ret IS NULL) 
        SET @ret = 0;
END
