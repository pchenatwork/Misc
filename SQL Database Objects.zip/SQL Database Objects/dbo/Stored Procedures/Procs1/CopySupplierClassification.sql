﻿



CREATE procedure [dbo].[CopySupplierClassification]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin
	insert SupplierClassification
		(	
			SupplierId,
			Classification,
			certified

		)
	select
			@newSupplierId,
			Classification,
			certified
	from SupplierClassification where supplierId=@supplierId

end




