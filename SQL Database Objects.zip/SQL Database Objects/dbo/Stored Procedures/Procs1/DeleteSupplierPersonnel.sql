﻿







/*
*********************************************************************************************************************
Procedure:	DeleteSupplierPersonnel
Purpose:	Delete a row from SupplierPersonnel table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/12/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSupplierPersonnel]
	@id int
as

begin tran

declare @supplierid int
declare @isKeyPerson char(1)
declare @transferredFlag char(1)
select @supplierid = supplierid, @isKeyPerson=isKeyPerson, @transferredFlag=transferredFlag from supplierpersonnel where Id=@id

delete SupplierPersonnelProject where supplierpersonnelId=@id
delete SupplierPersonnel where Id = @id

declare @rowcount int
set @rowcount = @@RowCount
--
----auditlog
--if @transferredFlag = '1' and @isKeyPerson='Y'
--	Insert AuditLog_Meta
--		(TableName, RecordId, VASId,  MainId, TransactionID, Action, ActionTime, UserName, ProcessedStatus)
--		select 'SupplierPersonnel', id,vasid, @supplierid, null, 'delete',null,null, null 
--			from suppleirpersonnel where id=@id
----

if @@error = 0
	Commit Transaction   
else
	RollBack Transaction
return @rowcount









