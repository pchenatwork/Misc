﻿










CREATE procedure [dbo].[CopyPlanStatistics]	
	@planId int, 
	@newPlanId int,
	@changeUser nvarchar(50)
as
begin
	insert [PlanStatistics]
		( 
			PlanId, 
			Type, 
			MBEAmount, 
			WBEAmount, 
			LBEAmount, 
			NonMinorityAmount, 
			TotalAmount, 
			PertOfPlanAmount, 
			ChangeUser, 
			ChangeDate
		)
	select  
			@newPlanId, 
			Type, 
			MBEAmount, 
			WBEAmount, 
			LBEAmount, 
			NonMinorityAmount, 
			TotalAmount, 
			PertOfPlanAmount, 
			@changeUser, 
			GETDATE()
	from
		[PlanStatistics]
	where
		planId=@planId
	
end



 


































