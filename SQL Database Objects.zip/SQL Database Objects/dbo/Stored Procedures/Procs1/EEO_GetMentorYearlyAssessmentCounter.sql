﻿CREATE PROCEDURE [dbo].[EEO_GetMentorYearlyAssessmentCounter]
(
  @ret int OUTPUT
)
AS

Begin


 declare @tableVar table
    (
         Vendorid int
    )

	  
    
    Insert into @tableVar
       exec  dbo.EEO_GetMentorYearlyAssessmentVendors  



    
    SELECT @ret = Count(*)FROM @tableVar
   
    IF (@ret IS NULL) 
        SET @ret = 0;
        
        
   
END
