﻿



CREATE procedure [dbo].[CopySupplierInsurance]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin
	insert SupplierInsurance
		(
			SupplierId,
			Insurance,
			Limit,
			Provider,
			PolicyNumber,
			AdditionalInsured,
			Agent,
			Phone,
			Fax,
			Filename,
			AttachmentId,
			InsuranceId,
			TransactionId,
			Status,
			Company,
			AddressLine1,
			AddressLine2,
			City,
			State,
			Country,
			ZipCode,
			AggregateLimit,
			EffectiveDate,
			ExpirationDate,
			ChangeDate,
			ChangeUser
		)
	select
			@newSupplierId,
			Insurance,
			Limit,
			Provider,
			PolicyNumber,
			AdditionalInsured,
			Agent,
			Phone,
			Fax,
			Filename,
			AttachmentId,
			newid(),
			TransactionId,
			Status,
			Company,
			AddressLine1,
			AddressLine2,
			City,
			State,
			Country,
			ZipCode,
			AggregateLimit,
			EffectiveDate,
			ExpirationDate,
			getdate(),
			@changeUser
	from SupplierInsurance where supplierId=@supplierId

end




