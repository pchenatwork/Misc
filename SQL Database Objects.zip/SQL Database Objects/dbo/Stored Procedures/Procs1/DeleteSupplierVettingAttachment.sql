﻿CREATE procedure [dbo].[DeleteSupplierVettingAttachment] 
	@id int
AS

Update SupplierVetting
Set FileName = null,
	AttachmentId = null
Where Id = @id
return @@rowcount
