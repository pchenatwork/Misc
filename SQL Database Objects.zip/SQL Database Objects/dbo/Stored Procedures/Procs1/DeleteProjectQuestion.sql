﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectQuestion
Purpose:	Delete a row from ProjectQuestion table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
2/29/2008		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteProjectQuestion]
	@id int
as

BEGIN Transaction

delete ProjectAnswer
Where QuestionId = @id

delete ProjectQuestion
where Id = @id

if @@error = 0
begin
	Commit Transaction
	return 1
end
else
begin
	RollBack Transaction
	return 0
end


