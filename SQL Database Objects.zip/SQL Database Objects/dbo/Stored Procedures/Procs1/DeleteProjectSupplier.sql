﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectSupplier
Purpose:	Delete a row from ProjectSupplier table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
1/18/2010		AECSOFTUSA\angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteProjectSupplier
	@id int
as

delete ProjectSupplier
where Id = @id
return @@RowCount

