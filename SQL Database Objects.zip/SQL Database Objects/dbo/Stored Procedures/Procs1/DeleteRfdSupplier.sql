﻿





/*
*********************************************************************************************************************
Procedure:	DeleteRfdSupplier
Purpose:	Delete a row from RfdSupplier table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/26/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteRfdSupplier]
	@id int,
	@userName nvarchar(50)=null
as


--insert auditlog
declare @actionTime  datetime
set @actionTime = getdate()
declare @transactionId int
insert into [Transaction](Type, ActionTime) values ('CMS', @actionTime)
select @transactionId = max(id) from [Transaction]	
Insert AuditLog
	(TableName, RecordId, VASId,  MainId, TransactionID, Action, ActionTime, UserName, ProcessedStatus)
	select  'RfdSupplier', @id, @id, rfdprojectId, @transactionId, 'delete', @actionTime, @userName, 'U'
	from 
		RfdSupplier
	where
		Id=@id
		and transferredflag='1'
----------


delete RfdSupplier
where Id = @id
return @@RowCount







