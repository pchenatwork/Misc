﻿/*
*********************************************************************************************************************
Procedure:	DeleteContract
Purpose:	Delete a row from Contract table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/11/2010		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteContract]
	@id int
as

begin transaction

delete [ContractItem]
where ContractId = @id

delete [Contract]
where Id = @id

if @@error = 0
	Commit Transaction   
else
	RollBack Transaction
return @@RowCount

