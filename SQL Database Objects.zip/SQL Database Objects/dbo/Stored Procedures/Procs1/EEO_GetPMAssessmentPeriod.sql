﻿/*
*********************************************************************************************************************
Procedure:	 
Purpose:
Busniess Rule : 1. First get the mentor graduation START_DATE AND END_DATE for particular vendor using its Mentor Type 
				2. Exclude final year in the list
				3. Create list of periods . for that consider following rule 
					a) period end date be less then today date + grace period (defined in the config)
					b) for each year period , increment the PeriodCounter

---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
09/11/2015		Syed			    Created
10/20/2015		Syed				Updated Logic to  consistent behaviour with counter  
*********************************************************************************************************************
*/
CREATE PROCEDURE [dbo].[EEO_GetPMAssessmentPeriod]
	-- Add the parameters for the stored procedure here
	@vendorId int 
AS

Begin

Declare @Days4MonthlyAssessment int 

Select @Days4MonthlyAssessment = ISNULL([value],0) from dbo.EEO_CONFIG
   	where [key] = 'Days4MonthlyAssessment'





	SELECT	NUMBER+1 AS PeriodCounter,
			DATEADD(YEAR,NUMBER,START_DATE) AS AST_StartDate,
			DATEADD(DAY,-1,	DATEADD(YEAR,NUMBER+1,START_DATE))  AS AST_EndDate 
						FROM MASTER..SPT_VALUES , 
						(	SELECT DISTINCT  
										GD.VENDORID,
										DATEFROMPARTS(YEAR(GD.SD_START_DATE),MONTH(GD.SD_START_DATE),1)  AS START_DATE,   -- start of the month
										EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS END_DATE,  --  USE SD_EXT_GRAD_DATE FIRST OTHERWISE SD_GRAD_DATE 
										EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS ACTUAL_END_DATE ,
										GD.C_MENTOR_TYPE              
							FROM (SELECT * FROM  DBO.EEO_MENTOR_GRAD_DETAIL 
										WHERE ID IN  
												(SELECT MAX(ID) AS ID   FROM DBO.EEO_MENTOR_GRAD_DETAIL  -- MAX RECORD FOR VENDOR WITH C_MENTOR_TYPE
							 						WHERE VENDORID =@vendorId AND C_MENTOR_TYPE='MENTOR' 
													GROUP BY VENDORID,C_MENTOR_TYPE 
													)
						 			) GD  , EEO_VENDOR EV
							WHERE GD.VENDORID=EV.VENDORID
									--AND EV.MENTORFLAG IN (6) -- only those vendors marked as  MENTOR
						) AS P
	WHERE TYPE = 'P'
	AND DATEADD(DAY,-1,	DATEADD(YEAR,NUMBER,START_DATE))   <=  DATEADD(day, @Days4MonthlyAssessment, P.END_DATE)
			--DATEADD( DAY, ISNULL(365-ISNULL(@AssessmentEndDateGracePeriod,0),0),  
			--							CASE WHEN P.END_DATE >= getdate() THEN getdate()  -- Consider today date if P.END_DATE is greater or equal to P.END_DATE
			--								ELSE P.END_DATE
			--							END)  
 


    
END

