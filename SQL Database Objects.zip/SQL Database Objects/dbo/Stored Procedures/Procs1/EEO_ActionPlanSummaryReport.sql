﻿/*
exec EEO_ActionPlanSummaryReport @AssessmentPeriod=N'3',@VendorId=17295,@Type=N'AA'
select * From vendor where id=17295

exec EEO_ActionPlanSummaryReport @VendorId=17718,@Type=N'AA',@BeginDate='1900-01-01 00:00:00',@EndDate='1900-01-01 00:00:00'

exec EEO_ActionPlanSummaryReport @VendorId=0,@Type=N'AA',
@BeginDate=null,@EndDate=null

exec EEO_ActionPlanReport @VendorId=17718,@Type=N'SA',
@BeginDate=NULL,@EndDate=NULL

*/
CREATE proc EEO_ActionPlanSummaryReport
(
--@AssessmentPeriod varchar(50) =null,
@VendorId int  =null,
@Type varchar(50)  =null,
@BeginDate DateTime =null,
@EndDate DateTime =null
)
As

if(@BeginDate='1900-01-01 00:00:00')
	Set @BeginDate=null
if(@EndDate ='1900-01-01 00:00:00')
	Set @EndDate =null



select v.Company, ap.VendorId,ap.PeriodId,ap.Category,ap.ActualScore,ap.MaxScore,
(select FirstName+' '+LastName From [User] where id =ap.ActionBy) as ActionBy
,ap.ActionDate,ap.Comments,'' As AssessmentPeriod
into #ActionPlanSummaryReport 
from EEO_ACTION_PLANS ap
Inner join Vendor v on v.Id=ap.VendorId
where 
ap.VENDORID=case when @VendorId =0 then ap.VENDORID else @VendorId end
--and  
--ap.PeriodId=case when @AssessmentPeriod =0 then ap.periodid else @AssessmentPeriod end
and
(
	(@Type='AA' and ap.Category =ap.Category )
	or
	(@Type='SA' and ap.Category Like '%Scope A%' )
	or
	(@Type='SB' and ap.Category not Like '%Scope A%' )
)
and  
(
--@BeginDate is null or 
ap.UPDATED_DATE >= @BeginDate
and
--@EndDate is null  or 
ap.UPDATED_DATE <=DATEADD(day, 1, @EndDate)-- @EndDate
)


Select max(ScopeA) as ScopeA,max(ScopeB) as ScopeB,max(ScopeA)+ max(ScopeB)  as TotAction from 
(
Select Count(*) As ScopeA,'' As ScopeB  from #ActionPlanSummaryReport
Where category like '%Scope A%'
Union
Select '' As ScopeB,Count(*) As ScopeB  from #ActionPlanSummaryReport
Where category Not like '%Scope A%'
) a
