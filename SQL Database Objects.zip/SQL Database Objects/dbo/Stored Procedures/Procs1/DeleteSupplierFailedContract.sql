﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierFailedContract
Purpose:	Delete a row from SupplierFailedContract table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/10/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierFailedContract
	@id int
as

delete SupplierFailedContract
where Id = @id
return @@RowCount

