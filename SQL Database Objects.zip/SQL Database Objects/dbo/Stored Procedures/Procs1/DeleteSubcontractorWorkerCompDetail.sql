﻿/*
*********************************************************************************************************************
Procedure:	DeleteSubcontractorWorkerCompDetail
Purpose:	Delete a row from SubcontractorWorkerCompDetail table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/3/2008		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSubcontractorWorkerCompDetail]
	@id int
as

delete SubcontractorWorkerCompDetail
where Id = @id
return @@RowCount

