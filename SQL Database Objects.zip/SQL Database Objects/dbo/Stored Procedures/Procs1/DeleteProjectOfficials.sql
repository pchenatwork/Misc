﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectOfficials
Purpose:	Delete a row from ProjectOfficials table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
1/18/2010		AECSOFTUSA\angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteProjectOfficials
	@id int
as

delete ProjectOfficials
where Id = @id
return @@RowCount

