﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierPayment
Purpose:	Delete a row from SupplierPayment table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/12/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierPayment
	@id int
as

delete SupplierPayment
where Id = @id
return @@RowCount

