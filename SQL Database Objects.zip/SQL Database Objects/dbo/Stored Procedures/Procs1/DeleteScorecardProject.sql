﻿/*
*********************************************************************************************************************
Procedure:	DeleteScorecardProject
Purpose:	Delete a row from ScorecardProject table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/21/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteScorecardProject]
	@id int
as

delete ScorecardProjectUser
where ScorecardProjectId = @id

delete ScorecardProject
where Id = @id
return @@RowCount

