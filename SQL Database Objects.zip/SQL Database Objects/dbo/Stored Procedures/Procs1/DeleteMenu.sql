﻿CREATE procedure DeleteMenu
	@id int
as
delete PermissionDetail where MenuId = @id
delete Menu where Id = @id
return @@RowCount



