﻿
/*
*********************************************************************************************************************
Procedure:	DeleteScorecardTemplate
Purpose:	Delete a row from ScorecardTemplate table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/3/2006		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteScorecardTemplate]
	@id int
as

delete ScorecardTemplateQuestionUserType
where QuestionId in (Select Id From ScorecardTemplateQuestion Where TemplateId = @id)

delete ScorecardTemplateQuestion
where CategoryId in (Select Id From ScorecardTemplateCategory Where TemplateId = @id)

delete ScorecardTemplateUserType
where CategoryId in (Select Id From ScorecardTemplateCategory Where TemplateId = @id)

delete ScorecardTemplateCategory
where TemplateId = @id

delete ScorecardTemplate
where Id = @id

return @@RowCount
