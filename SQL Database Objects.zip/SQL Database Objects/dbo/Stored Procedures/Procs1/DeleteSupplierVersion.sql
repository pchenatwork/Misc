﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierVersion
Purpose:	Delete a row from SupplierVersion table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/8/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierVersion
	@id int
as

delete SupplierVersion
where Id = @id
return @@RowCount

