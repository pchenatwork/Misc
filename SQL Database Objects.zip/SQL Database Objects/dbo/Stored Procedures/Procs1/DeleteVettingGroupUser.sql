﻿/*
*********************************************************************************************************************
Procedure:	DeleteVettingGroupUser
Purpose:	Delete a row from VettingGroupUser table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
05/22/2008		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteVettingGroupUser]
	@vettingGroupId int,
	@userId int
as
delete VettingGroupUser
where VettingGroupId = @vettingGroupId
and UserId = @userId
return @@RowCount

