﻿

CREATE procedure [dbo].[CopySubcontractor]	
	@id int, 
	@federalId nvarchar(50)
as
begin

declare @latestId int
Set @latestId = 0

Select @latestId = max(Id) From Subcontractor
Where FederalId = @federalId
and Id != @id

if @latestId > 0
begin
	Insert SubcontractorContact
	(
			SubcontractorId,
			Type,
			Name,
			AddressLine1,
			AddressLine2,
			City,
			State,
			ZipCode,
			Country,
			Phone,
			Extension,
			Fax,
			ChangeUser,
			ChangeDate
	)
	Select
			@id,
			Type,
			Name,
			AddressLine1,
			AddressLine2,
			City,
			State,
			ZipCode,
			Country,
			Phone,
			Extension,
			Fax,
			ChangeUser,
			getdate()
	From SubcontractorContact
	Where SubcontractorId = @latestId

	insert SubcontractorApprenticeshipProgram
		(
			SubcontractorId, 
			Type, 
			ProgramName, 
			Number, 
			Trade, 
			ApprovedTrade, 
			Approved, 
			ApprovedNumber, 
			NumberOfYears,
			VerifyName, 
			StartDate, 
			EndDate, 
			Comments, 
			ChangeUser, 
			ChangeDate, 
			SupplierApprenticeshipId		
		)
	Select
			@id,
			Type, 
			ProgramName, 
			Number, 
			Trade, 
			ApprovedTrade, 
			Approved, 
			ApprovedNumber, 
			NumberOfYears,
			VerifyName, 
			StartDate, 
			EndDate, 
			Comments, 
			ChangeUser, 
			getdate(), 
			SupplierApprenticeshipId
	From SubcontractorApprenticeshipProgram
	Where SubcontractorId = @latestId

	insert SubcontractorLicense
		(
			SubcontractorId,
			LicenseType, 
			LicenseNo, 
			ExpirationDate, 
			SupplierLicenseId, 
			ChangeUser, 
			ChangeDate, 
			PersonnelId
		
		)
	Select
			@id,
			LicenseType, 
			LicenseNo, 
			ExpirationDate, 
			SupplierLicenseId, 
			ChangeUser, 
			getdate(), 
			PersonnelId	
	From SubcontractorLicense
	Where SubcontractorId = @latestId

	insert SubcontractorInsurance
		(
			SubcontractorId,
			Type,
			Insurer,
			PolicyNo,
			EffectiveDate,
			Agent,
			AddressLine1,
			AddressLine2,
			City,
			State,
			ZipCode,
			Country,
			AccountExec,
			Phone,
			Fax,
			ChangeUser,
			ChangeDate
		)
	Select
			@id,
			Type,
			Insurer,
			PolicyNo,
			EffectiveDate,
			Agent,
			AddressLine1,
			AddressLine2,
			City,
			State,
			ZipCode,
			Country,
			AccountExec,
			Phone,
			Fax,
			ChangeUser,
			getdate()
	From SubcontractorInsurance
	Where SubcontractorId = @latestId

	insert SubcontractorWorkerComp
		(
			SubcontractorId,
			WCExpMode,
			RatingDate,
			WCBureauRiskNo,
			LocationOfPayroll,
			Contact,
			ChangeUser,
			ChangeDate
		)
	Select
			@id,
			WCExpMode,
			RatingDate,
			WCBureauRiskNo,
			LocationOfPayroll,
			Contact,
			ChangeUser,
			getdate()
	From SubcontractorWorkerComp
	Where SubcontractorId = @latestId

	insert SubcontractorWorkerCompDetail
		(
			SubcontractorId,
			Classification,
			Code,
			Payroll,
			ChangeUser,
			ChangeDate
		)
	Select
			@id,
			Classification,
			Code,
			Payroll,
			ChangeUser,
			getdate()
	From SubcontractorWorkerCompDetail
	Where SubcontractorId = @latestId

end

return 1

end

