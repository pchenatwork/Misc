﻿CREATE PROCEDURE [dbo].[EEO_GetGradMentorYearlyAssessmentCounter]
(
  @ret int OUTPUT
)
AS

Begin

  DECLARE @tableVar table
    (
         Vendorid int
    )
    Insert into @tableVar
       exec  dbo.EEO_GetGradMentorYearlyAssessmentVendors  



    
    SELECT @ret = Count(*)FROM @tableVar
   
    IF (@ret IS NULL) 
        SET @ret = 0;
END
