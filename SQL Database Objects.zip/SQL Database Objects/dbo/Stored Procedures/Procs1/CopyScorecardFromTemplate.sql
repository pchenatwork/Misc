﻿
/*
*********************************************************************************************************************
Procedure:	CopyScorecardFromTemplate
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
11/26/2008	Lily Xiong			Created
01/04/2019  Jeff Wigdor			Support for VP for Capital Planning
*********************************************************************************************************************
*/
CREATE PROCEDURE [dbo].[CopyScorecardFromTemplate]
	@id int,
	@templateId int
AS
Begin

Set NoCount On

declare @workflowId int
Select @workflowId = Id From WorkflowList
Where Type = 'Evaluation'

Declare @projectType nvarchar(50)
Select @projectType = isnull(st.Country, '') 
From ScorecardTemplate st
Where st.Id = @templateId

Declare @iehType nvarchar(10)
if @projectType = 'IEH'
begin
	Select @iehType = 
		Case p.Type
			When 'HazMat' Then 'HazMat'
			Else 'Non-HazMat'
		End
	From ScorecardProject p, Scorecard s
	where p.Id = s.RefId
	and s.Id = @id
end

-- Insert ScorecardCategory
Declare @categoryId int
Declare @newCategoryId int
Declare @questionId int
Declare @newQuestionId int
declare @allCategory table
(
	Id int,
	ParentId int
)
Insert Into @allCategory( Id, ParentId ) 
Select Id, ParentId 
From ScorecardTemplateCategory
Where TemplateId = @templateId
While(@@rowcount>0 )
Begin
	Insert Into @allCategory( Id, ParentId ) 
	Select Id, ParentId 
	From ScorecardTemplateCategory 
	Where Id Not In ( Select Id From @allCategory )
	And ParentId In ( Select Id From @allCategory )
End
declare @tempCategory Table
(
	Id			int,
	ParentId	int,
	Name		nvarchar(100),
	Sequence	int,
	Weight		int
)
Insert Into @tempCategory
(
	Id,ParentId,Name,Sequence,Weight
)
Select 
	Id,ParentId,Name,Sequence,Weight
From ScorecardTemplateCategory
Where Id in ( Select Id From @allCategory )

declare @tempQuestion Table
(
	Id			int,
	Name		nvarchar(500),
	Description	ntext,
	Sequence	int,
	Weight		int,
	Score		int,
	IsRequired	char(1),
	ScoreMethod nvarchar(10),
	GroupName	nvarchar(50)
)

--Insert ScorecardCategory
While Exists( Select * From @tempCategory )
Begin
	Select @categoryId = Id From @tempCategory Order By Id desc
	
	Insert Into ScorecardCategory
	(
		ScorecardId,ParentId,Name,Sequence,Weight,TemplateId
	)
	Select 
		@id,ParentId,Name,Sequence,Weight,@templateId
	From @tempCategory
	Where Id = @categoryId

	Set @newCategoryId = @@identity

	--Update record in @tempCategory, make their CategoryId to new CategoryId
	Update @tempCategory Set ParentId = @newCategoryId Where ParentId = @categoryId
	
	Insert Into @tempQuestion
	(
		Id,Name,Description,Sequence,Weight,Score,IsRequired,ScoreMethod
	)
	Select Id,Name,Description,Sequence,Weight,Score,IsRequired,ScoreMethod
	From ScorecardTemplateQuestion
	Where CategoryId = @categoryId

	While Exists( Select * From @tempQuestion )
	Begin
		Select @questionId = Id From @tempQuestion Order By Id desc

		Insert Into ScorecardQuestion
		(
			ScorecardId,CategoryId,Name,Description,Sequence,Weight,Score,IsRequired,ScoreMethod,TemplateId
		)
		Select @id,@newCategoryId,Name,Description,Sequence,Weight,Score,IsRequired,ScoreMethod,@questionId
		From @tempQuestion
		Where Id = @questionId

		Set @newQuestionId = @@identity

		Insert Into ScorecardQuestionUserType
		(
			QuestionId, UserType
		)
		Select @newQuestionId, UserType
		From ScorecardTemplateQuestionUserType
		Where QuestionId = @questionId and (isnull(Type, '') = '' or Type = @iehType)

		Delete @tempQuestion Where Id = @questionId
	End

	Delete @tempCategory Where Id = @categoryId
End

Insert Into ScorecardInvitee
(
	ScorecardId, UserId, UserType, SupervisorId, SupervisorType, WorkflowId, Status, CreateDate
)
Select distinct @id, pu.UserId, pu.UserType, pu.SupervisorId, 
	Case pu.UserType
		When 'Senior Project Officer' Then 'Chief Project Officer'
		When 'Director of Mentor Program' Then 'VP for Construction Mgmt'
		Else pu.UserType + ' Supervisor'
	End, @workflowId, 0, getdate()
From ScorecardTemplateCategory sc, ScorecardTemplateUserType st, CompanyBranch p, CompanyBranch c, ScorecardProjectUser pu, Scorecard s
Where sc.TemplateId = @templateId
and sc.Id = st.CategoryId
and pu.ScorecardProjectId = s.RefId
and s.Id = @id
and st.UserType = p.Name
and p.Id = c.ParentId
and c.Name = pu.UserType
and (st.Type = '' or st.Type = @iehType)

Insert Into ScorecardUser
(
	ScorecardId, UserId, UserType, Status, CreateDate
)
Select @id, pu.UserId, pu.UserType, 0, getdate()
From ScorecardProjectUser pu, Scorecard s
Where pu.ScorecardProjectId = s.RefId
and s.Id = @id
and s.Type = 'Mentor A' and pu.UserType in ('Chief Project Officer', 'VP for Construction Mgmt')

Insert Into ScorecardUser
(
	ScorecardId, UserId, UserType, Status, CreateDate
)
Select @id, pu.UserId, pu.UserType, 0, getdate()
From ScorecardProjectUser pu, Scorecard s
Where pu.ScorecardProjectId = s.RefId
and s.Id = @id
and s.Type = 'Mentor B' and pu.UserType in ('VP for Construction Mgmt', 'VP of Admin', 'VP of Capital Planning')

Insert Into ScorecardUser
(
	ScorecardId, UserId, UserType, Status, CreateDate
)
Select @id, pu.UserId, pu.UserType, 0, getdate()
From ScorecardProjectUser pu, Scorecard s, ScorecardProject p
Where pu.ScorecardProjectId = s.RefId
and s.Id = @id and pu.ScorecardProjectId = p.Id
and s.Type in ('Hazmat Contract', 'Non-Hazmat Contract') 
and ((p.Type = 'Hazmat' and pu.UserType = 'IEH Deputy Director') or 
	(p.Type != 'Hazmat' and pu.UserType = 'IEH Manager'))

return 1

End
