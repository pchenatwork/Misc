﻿CREATE Procedure [dbo].[CreateCategories]
As
Delete From Categories

Insert Into Categories( Id, ParentId ) 
Select Id, isnull(ParentId, 0) From Category 

While ( @@rowcount > 0 )
Begin
	Insert Into Categories( Id, ParentId )
	Select distinct c1.Id, c2.ParentId
	From Categories c1, Categories c2
	Where c1.ParentId = c2.Id
	and c1.Id Not In ( Select a.Id From Categories a where a.ParentId = c2.ParentId )
End

Insert Into Categories( Id, ParentId ) 
Select Id, Id From Category

