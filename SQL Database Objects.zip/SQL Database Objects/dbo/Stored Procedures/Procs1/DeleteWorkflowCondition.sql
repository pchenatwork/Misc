﻿

Create procedure DeleteWorkflowCondition
	@id int
as

delete WorkflowCondition
where Id = @id
return @@RowCount




