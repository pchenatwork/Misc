﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectComment
Purpose:	Delete a row from ProjectComment table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
12/17/2009		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteProjectComment
	@id int
as

delete ProjectComment
where Id = @id
return @@RowCount

