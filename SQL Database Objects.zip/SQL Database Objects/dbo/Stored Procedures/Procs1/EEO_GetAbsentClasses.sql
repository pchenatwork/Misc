﻿CREATE Procedure [dbo].[EEO_GetAbsentClasses]  
 -- Add the parameters for the stored procedure here  
 @vendorId int,  
 @classType int  
AS  
BEGIN  
 -- SET NOCOUNT ON added to prevent extra result sets from  
 -- interfering with SELECT statements.  
 --SET NOCOUNT ON;  
  
    -- Insert statements for procedure here  
 declare @currentStatus varchar(50)  
 declare @count int  
 select @currentStatus=status from eeo_vendor where vendorid=@vendorId  
  
 print @currentStatus  
 print @classType  
 if  @classType=12   
   set @count =(  
     select max(x.Missed_Count) from   
     (  
      select count(vc.C_CLASS_ID)  as Missed_Count,vc.VENDORID, ec.ModuleId  
      from EEO_VENDOR_CLASSES vc,eeo_classes ec   
      where  isnull(C_ATTENDED,'X')='N'  
       and isnull(vc.C_REASON_EXCUSED,'')=''  
       and vc.C_CLASS_ID=ec.C_CLASS_ID  
       and ec.C_CLASS_TYPE=4   
       and ec.ModuleId is not null  
         
      group by  vc.VENDORID, ec.ModuleId  
     )   
     x where x.VENDORID =  @vendorId  
      
     )  
 Else if  @classType=10  
   set @count =(  
     select max(x.Missed_Count) from   
     (  
      select count(vc.C_CLASS_ID)  as Missed_Count,vc.VENDORID, ec.ModuleId  
      from EEO_VENDOR_CLASSES vc,eeo_classes ec   
      where  isnull(C_ATTENDED,'X')='N'  
       and isnull(vc.C_REASON_EXCUSED,'')=''  
       and vc.C_CLASS_ID=ec.C_CLASS_ID  
       and ec.C_CLASS_TYPE=4   
       and ec.ModuleId is not null  
       and isnull(vc.REVIEWED,0)=0   
         
      group by  vc.VENDORID, ec.ModuleId  
     )   
     x where x.VENDORID =  @vendorId  
      
     )  
      
       
 else If @currentStatus='Tier2_Program'  
   
  set @count =(  
      
     select count(vc.C_CLASS_ID)   
     from EEO_VENDOR_CLASSES vc,eeo_classes ec   
     where vc.vendorid=@vendorId and  (isnull(vc.C_ATTENDED,'N')='N' and  isnull(vc.,'N')='N'
     and vc.C_CLASS_ID=ec.C_CLASS_ID  
     and ec.C_CLASS_TYPE=@classType  
      
     )  
   
   
 Else if  @currentStatus='AdvancedClassesAbsent'  or @classType=4  
   --set @count =(  
   --  -- This gives count of classes that are missed and not execused by BDD Analyst  
   --  select count(vc.C_CLASS_ID)   
   --  from EEO_VENDOR_CLASSES vc,eeo_classes ec   
   --  where vc.vendorid=@vendorId and vc.REVIEWED=1   
   --  and isnull(C_ATTENDED,'X')='N'  
   --  and isnull(vc.C_REASON_EXCUSED,'')=''  
   --  and vc.C_CLASS_ID=ec.C_CLASS_ID  
   --  and ec.C_CLASS_TYPE=4  
      
   --  )  
   set @count =(  
     select max(x.Missed_Count) from   
     (  
      select count(vc.C_CLASS_ID)  as Missed_Count,vc.VENDORID, ec.ModuleId  
      from EEO_VENDOR_CLASSES vc,eeo_classes ec   
      where   vc.REVIEWED=1   
       and isnull(C_ATTENDED,'X')='N'  
       and isnull(vc.C_REASON_EXCUSED,'')=''  
       and vc.C_CLASS_ID=ec.C_CLASS_ID  
       and ec.C_CLASS_TYPE=4   
       and ec.ModuleId is not null  
      group by  vc.VENDORID, ec.ModuleId  
     )   
     x where x.VENDORID =  @vendorId  
    )  
  
 else if @classType=2 --Orientation class  
  begin  
   set @count =(  
      select count(*)  
      from  
       (  
       select C_CLASS_ID from eeo_classes ec where ec.c_class_Type=@classType   
       except  
       select   
        vc.C_CLASS_ID   
       from   
        EEO_VENDOR_CLASSES vc, EEO_CLASSES ec   
       where   
        vc.vendorid=@vendorId   
        and vc.C_CLASS_ID = ec.C_CLASS_ID  
        and ec.C_CLASS_TYPE <>7  
          
       )c  
      )  
    
   if @count>0  
    set @count=-1  
  
   -- check if the orientation class is attended or reviewed  
   if @count=0  
    begin  
     set @count=(  
        Select count(*)   
        From   
         eeo_vendor_Classes ev, eeo_classes e  
        Where ev.vendorid=@vendorId and isnull(C_ATTENDED,'N')='N' and isNull(Reviewed,'')<>'' and rtrim(isnull(C_REASON_EXCUSED,''))=''  
         and ev.C_CLASS_ID=e.C_CLASS_ID  
         and e.C_CLASS_Type=2  
        )  
  
    end  
    
  end   
       
 Else  
  
  set @count =(  
      
     select count(vc.C_CLASS_ID)   
     from EEO_VENDOR_CLASSES vc,eeo_classes ec   
     where vc.vendorid=@vendorId and  isnull(vc.C_ATTENDED,'N')='N'   
     and isnull(vc.REVIEWED,'0')='1' and ltrim(vc.C_REASON_EXCUSED)=''  
     and vc.C_CLASS_ID=ec.C_CLASS_ID  
     and ec.C_CLASS_TYPE=@classType  
      
     )  
  
    
  
 select @count  
 return @count  
END  