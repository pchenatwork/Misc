﻿










CREATE procedure [dbo].[CopyPlan]	
	@id int, 
	@changeUser nvarchar(50)
as
begin
	declare @planId int
	set @planId = @id
	
	begin transaction

	begin try
		declare @newPlanId int
		--Plan
		exec  @newPlanId = [CopyPlanTable] @planId, @changeUser
		
		--PlanItem
		exec [CopyPlanItem] @planId, @newPlanId, @changeUser
		
		--PlanStatistics
		exec [CopyPlanStatistics] @planId, @newPlanId, @changeUser
	
		--PlanSubcontractor
		exec [CopyPlanSubcontractor] @planId, @newPlanId, @changeUser
					
		commit transaction
		
		return @newPlanId 
		
	end try
	begin catch
		rollback transaction
		return 0
	end catch

end



 


































