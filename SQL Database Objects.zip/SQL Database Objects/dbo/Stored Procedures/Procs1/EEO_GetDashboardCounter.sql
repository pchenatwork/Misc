﻿IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[EEO_GetDashboardCounter]'))
   EXEC('CREATE PROCEDURE [dbo].[EEO_GetDashboardCounter] AS BEGIN SET NOCOUNT ON; END')
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
*******************************************************************************
Procedure:	EEO_GetDashboardCounter
Purpose:	Get data for "Mentor->Dashboard'
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
08/02/2017      PCHEN               Comment section first created
    1. Sync with Staging
    2. URS(11-1445800) got purchased by AECom(13-5511947), Combine two EINs into one
	3. FIX for 00129097 (Tudor, 9/9/2019)
*******************************************************************************
*/


ALTER PROCEDURE [dbo].[EEO_GetDashboardCounter]
    -- Add the parameters for the stored procedure here
    @userId int
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    
     CREATE TABLE #TEMPDASHBOARDCOUNTER ( 
           DASHBOARDID  INT,
           ROLEID UNIQUEIDENTIFIER,
           COUNTERNAME  VARCHAR(500),
           URL VARCHAR(500),
           COUNTERTYPE VARCHAR(50),
           COUNTERSTATUS VARCHAR(50),
           WORKFLOWACTION INT
    );


    
    INSERT INTO #TEMPDASHBOARDCOUNTER
            SELECT 
                ER.DASHBOARDID,
                ER.ROLEID ROLEID,
                E.COUNTERTYPE + ' - ' + E.COUNTERNAME AS COUNTERNAME,
                E.URL,
                R.ROLENAME AS COUNTERTYPE,
                E.COUNTERSTATUS,
                E.WORKFLOWACTION
            FROM	
                EEO_DASHBOARD E,	
                GETDASHBOARDROLES(@USERID)  ER, 
                ASPNET_ROLES R
            WHERE 
                E.ID=ER.DASHBOARDID
                AND ER.ROLEID=R.ROLEID
            ORDER BY R.ROLENAME,E.COUNTERTYPE ,SEQUENCE
         
         
 

      

        Declare  @Monthly_Assessment int=0
        Declare  @DirectorScopeAMontly_Assessment int=0
        Declare  @ActionPlanCounter int=0
        Declare  @Mentorswith4MSales int=0
        Declare  @MENTOR_Overdue_Monthly_AssessmentCounter int =0
        Declare  @MENTOR_Overdue_Monthly_AssessmentCounter_TDX int =0
        Declare  @MENTOR_Overdue_Monthly_AssessmentCounter_URS int =0
        Declare  @MENTOR_Overdue_Yearly_AssessmentCounter int =0
        Declare  @GradMentor_YearlyAssessmentCounter   int =0
        Declare  @Mentor_YearlyAssessmentCounter int=0
        Declare  @MentorAnnualBidCeilingCounter int=0


 
        IF EXISTS (SELECT * FROM #TEMPDASHBOARDCOUNTER WHERE COUNTERSTATUS='Monthly_Assessment' )  
        BEGIN
            exec dbo.EEO_GetCMMontlyDashboardCounter @userId,@Monthly_Assessment OUTPUT
        END 

        IF EXISTS (SELECT * FROM #TEMPDASHBOARDCOUNTER WHERE COUNTERSTATUS='DirectorScopeAMontly_Assessment' )  
        BEGIN
             exec dbo.EEO_GetDirectorScopeAMontlyDashboardCounter @DirectorScopeAMontly_Assessment OUTPUT
        END 

         
        IF EXISTS (SELECT * FROM #TEMPDASHBOARDCOUNTER WHERE COUNTERSTATUS='ActionPlanCounter')  
        BEGIN
            exec dbo.EEO_GetActionPlanCounter @ActionPlanCounter OUTPUT
        END 
        
        IF EXISTS (SELECT * FROM #TEMPDASHBOARDCOUNTER WHERE COUNTERSTATUS='4MSales')  
        BEGIN
            exec dbo.EEO_GetMentorsWith4MSalesCounter @Mentorswith4MSales OUTPUT
        END 

        IF EXISTS (SELECT * FROM #TEMPDASHBOARDCOUNTER WHERE COUNTERSTATUS='Mentor_Overdue_Yearly_Assessment')  
        BEGIN
            exec dbo.EEO_GetOverdueYearlyAssessmentCounter @MENTOR_Overdue_Yearly_AssessmentCounter OUTPUT
        END 
         
        IF EXISTS (SELECT * FROM #TEMPDASHBOARDCOUNTER WHERE COUNTERSTATUS='GM_YearlyAssessment_Counter')  
        BEGIN
            exec dbo.EEO_GetGradMentorYearlyAssessmentCounter @GradMentor_YearlyAssessmentCounter OUTPUT
        END 
         
        IF EXISTS (SELECT * FROM #TEMPDASHBOARDCOUNTER WHERE COUNTERSTATUS='Mentor_YearlyAssessment_Counter' )  
        BEGIN
            exec dbo.EEO_GetMentorYearlyAssessmentCounter @Mentor_YearlyAssessmentCounter OUTPUT
        END 

        IF EXISTS (SELECT * FROM #TEMPDASHBOARDCOUNTER WHERE COUNTERSTATUS='MentorAnnaulBidCeiling')  
        BEGIN
             exec dbo.EEO_GetMentorAnnualBidCeilingCounter @MentorAnnualBidCeilingCounter OUTPUT
        END 



       --  exec dbo.EEO_GetOverdueMontlyAssessmentCounter @userId,@MENTOR_Overdue_Monthly_AssessmentCounter OUTPUT
     
      --   exec dbo.EEO_GetOverdueMontlyAssessmentCounterTDX  @MENTOR_Overdue_Monthly_AssessmentCounter_TDX OUTPUT

         --exec dbo.EEO_GetOverdueMontlyAssessmentCounterURS  @MENTOR_Overdue_Monthly_AssessmentCounter_URS OUTPUT


        Declare @title as nvarchar(100) 
            selecT  @title =u.Title from   [user] u  where u.Id=@userid
        
        ---** 20170802 PCH AECOM took over USR, so bind these two EIN together
        DECLARE @t_CombinedEINs TABLE (
            TaxID NVARCHAR(100)
        )
        IF @title IN ('11-1445800', '13-5511947')
            INSERT INTO @t_CombinedEINs VALUES ('11-1445800'), ('13-5511947')
        --- ** SELECT  '@t_CombinedEINs' as tbl, * FROM @t_CombinedEINs
        --- **

        BEGIN
                DECLARE @tableOverDueMonthly table
                (
                    Vendorid int,
                    contractid varchar(20)
                )

                Insert into @tableOverDueMonthly
                exec  dbo.EEO_GetOverdueMontlyAssessmentVendors  @userId


                IF EXISTS (SELECT * FROM #TEMPDASHBOARDCOUNTER WHERE COUNTERSTATUS='Mentor_Overdue_Monthly_Assessment_TDX' )  
                BEGIN
             
                    select @MENTOR_Overdue_Monthly_AssessmentCounter_TDX = Count(*) from @tableOverDueMonthly t
                    where t.contractid in (select c_contract from MV_SOLICIT_CONTRACT where C_VENDOR_ID='13-3039254')
                END 


                IF EXISTS (SELECT * FROM #TEMPDASHBOARDCOUNTER WHERE COUNTERSTATUS='Mentor_Overdue_Monthly_Assessment_URS' )  
                BEGIN
                    select @MENTOR_Overdue_Monthly_AssessmentCounter_URS = Count(*) from @tableOverDueMonthly t
                    where t.contractid in (select c_contract from MV_SOLICIT_CONTRACT where C_VENDOR_ID='11-1445800')
                END 


                IF EXISTS (SELECT * FROM #TEMPDASHBOARDCOUNTER WHERE COUNTERSTATUS='Mentor_Overdue_Monthly_Assessment' )  
                BEGIN
                    select @MENTOR_Overdue_Monthly_AssessmentCounter = Count(distinct Vendorid) 
                    from @tableOverDueMonthly t
                    where (@userId=0 or 
                            (@userId<> 0 and ( 
                                @title=''  or 
                                (@title!='' and t.contractid in (
                                        select c_contract 
                                        from MV_SOLICIT_CONTRACT 
                                        where C_VENDOR_ID=@title 
                                           OR C_VENDOR_ID IN (SELECT TaxID FROM @t_CombinedEINs)
                                        )
                                 ))
                             )
                          )	
                END 

     
        END

    
        -- Insert statements for procedure here
        select e.CounterName, e.Url, e.CounterType, e.CounterStatus,e.WorkflowAction,
            case when e.CounterStatus='UpdateTestScore' then
                 (
                    select count(distinct ev.vendorid) 
                    from EEO_MENTOR_GRAD_DETAIL e,eeo_vendor ev
                    where 
                        DATEADD(YEAR,-2,e.sd_grad_date)>dateadd(year, -2,getdate() ) and DATEADD(YEAR,-2,e.sd_grad_date)<getdate()
                        and e.C_MENTOR_TYPE='MENTOR'
                        and e.SD_ACTUAL_GRAD_DT is null
                        and e.vendorid=ev.VendorId
                        and ev.MentorFlag=6
                        and e.SD_END is null
                        and exists( -- Check if any pending classes exist
                                    select	ec.C_CLASS_ID	from	eeo_classes ec, EEO_CLASSES_SCHE ES 
                                    where	ec.c_class_Type=4	AND EC.C_CLASS_ID=es.C_CLASS_ID and es.SD_CLASS_DATE<getdate()
                                
                                    except
                                    select vc.C_CLASS_ID from EEO_VENDOR_CLASSES vc, eeo_classes ec 
                                    where vc.vendorid=ev.vendorid and (vc.C_ATTENDED='Y' or (vc.C_ATTENDED='N' and vc.REVIEWED=1))
                                    and vc.C_CLASS_ID=ec.C_CLASS_ID
                                    and ec.C_CLASS_TYPE=4
                                
                                    )

                    )
                when e.CounterStatus='Tier2_Program' then
                 (
                    select count(*) 
                    from eeo_vendor ev
                    where 
                        status='Tier2_Program'
                        and exists(-- Check if any pending classes exist
                                    select	ec.C_CLASS_ID	from	eeo_classes ec, EEO_CLASSES_SCHE ES 
                                    where	ec.c_class_Type=4	AND EC.C_CLASS_ID=es.C_CLASS_ID and es.SD_CLASS_DATE<getdate()
                                    except
                                    select vc.C_CLASS_ID from EEO_VENDOR_CLASSES vc, eeo_classes ec 
                                    where vc.vendorid=ev.vendorid and vc.C_ATTENDED='Y'
                                    and vc.C_CLASS_ID=ec.C_CLASS_ID
                                    and ec.C_CLASS_TYPE=4
                                    )

                    )
                
                --when e.CounterStatus='ExcessiveAbsence' then
                --	( 
                --	select count(*) from eeo_vendor ev 
                --	where status='AdvancedClassesAbsent'

                --	--select count(*) 
                --	--from eeo_vendor ev
                --	--where 
                --	--	status='Tier2_Program'
                --	--	and exists(
                --	--				select vc.C_CLASS_ID 
                --	--				from EEO_VENDOR_CLASSES vc,EEO_CLASSES ec 
                --	--				where vc.vendorid=ev.vendorid 
                --	--				and vc.C_ATTENDED='N' 
                --	--				and vc.C_CLASS_ID=ec.C_CLASS_ID 
                --	--				and ec.C_CLASS_TYPE=4

                --	--				)
                --	)
                when e.CounterStatus='RequestedAppointments' then
                    ( 
                    select count(*) 
                    from eeo_vendor ev
                    where 
                        ev.vendorid in (
                            select vendorid from EEO_VENDOR_APPOINTMENTS vc where isnull(C_SCHEDULED,0)=0 and isnull(upper(C_COMMENTS),'')!='DENIED'
                            )
                        
                                
                                
                                
                    )
                when e.CounterStatus='ScheduleAppointments' then
                    ( 
                    select count(*) 
                    from eeo_vendor ev
                    where 
                        ev.vendorid in (
                            select vendorid from EEO_VENDOR_APPOINTMENTS vc where isnull(C_SCHEDULED,0)=1 and isnull(C_ATTENDED,0)=0 
                            )
                    )
                --when e.CounterStatus='AdvancedClassesUpdated' then
                --	( 
                --	select count(*) from eeo_vendor ev 
                --	where status='AdvancedClassesUpdated'

                --	--select count(*) 
                --	--from eeo_vendor ev
                --	--where 
                --	--	ev.vendorid in (
                --	--		select vendorid from EEO_VENDOR_CLASSES vc , eeo_classes e

                --	--		where vc.C_CLASS_ID=e.C_CLASS_ID
                --	--		and e.C_CLASS_TYPE=4
                --	--		and isnull(C_ATTENDED,'N')='Y'
                --	--		and ISNULL(rEVIEWED,0)=0
                --	--		and isnull(vc.TEST_SCORE ,-1)>=0

                --	--		)
                --	--and ev.MentorFlag=6
                --	--and ev.Status='AdvancedClassesUpdated'

                --	)
                when e.CounterStatus='ExcessiveAppointments' then
                    ( 
                    select count(*) 
                    from eeo_vendor ev
                    where 
                        ev.vendorid in (
                                
                                    select  v.vendorid from (select  vendorid from EEO_VENDOR_APPOINTMENTS --where isnull(Reviewed,0) != 1
                        group by I_CONSULTANT_LOOKUP_ID, vendorid, dbo.EEO_GetFiscalYear(SD_APPOINTMENT)
                        having count(*) > 2) c, EEO_VENDOR_APPOINTMENTS v
                        where c.VENDORID=v.VENDORID
                        and  isnull(v.Reviewed,0) != 1 and isnull(c_scheduled,0)!=1
                        )
                                
                    )
                when e.CounterStatus='SplAsmentScopB' then
                (
                    --filter only in mentor program
                    select count(distinct s.Vendorid) from eeo_special_Assessment s,EEO_Vendor v 
                    where s.VendorId = v.VendorId
                    and v.MentorFlag = 6
                    and s.Status='New' or DATEADD(month, FollowUp, ReviewedDate)<=getdate() 
                    --select count(distinct vendorid) from eeo_special_Assessment where Status='New' or DATEADD(month, FollowUp, ReviewedDate)<=getdate() 
                )
                when e.CounterStatus='SplAsmentReviewer' then
                (
                select count(distinct Vendorid) from eeo_special_Assessment where Status='SB'
                )

                when e.CounterStatus='1MBonding' then
                (
                  --   Select count(distinct v.id) From SupplierSurety s, EEO_Vendor ev,vendor v
                     --Where s.SupplierId = isnull (v.QualifiedSupplierId,v.currentsupplierid) 
                     --and ev.VendorId = v.Id
                     --and ev.MentorFlag = 6
                     --and SingleCapacity>=1000000 
                     --and ev.status <> 'Graduated'
                     Select count(distinct VendorId) From EEO_Vendor
                     where AcceleGradEligible in (1,2)
                     and MentorFlag = 6
                 
                     
                )
                when e.CounterStatus='Mentor_YearlyAssessment_Counter' then
                 (
                    @Mentor_YearlyAssessmentCounter	        
                 )
        
                when e.CounterStatus='GM_YearlyAssessment_Counter' then
                (
                     @GradMentor_YearlyAssessmentCounter     
                 )
                 when e.CounterStatus='Mentor_YearlyAssessment_Counter' then
                 (
                    @Mentor_YearlyAssessmentCounter	        
                 )
        
                when e.CounterStatus='Monthly_Assessment' then
                (
                     @Monthly_Assessment   
                 )
                 when e.CounterStatus='DirectorScopeAMontly_Assessment' then
                (
                     @DirectorScopeAMontly_Assessment   
                 )
                 when e.CounterStatus='ActionPlanCounter' then
                (
                     @ActionPlanCounter 
                 )
                 when e.CounterStatus='4MSales' then (@Mentorswith4MSales)
             
                 when e.CounterStatus='Mentor_Overdue_Monthly_Assessment' then
                (
                     @MENTOR_Overdue_Monthly_AssessmentCounter 
                 )
                 when e.CounterStatus='Mentor_Overdue_Monthly_Assessment_TDX' then
                (
                     @MENTOR_Overdue_Monthly_AssessmentCounter_TDX 
                 )
                 when e.CounterStatus='Mentor_Overdue_Monthly_Assessment_URS' then
                (
                     @MENTOR_Overdue_Monthly_AssessmentCounter_URS 
                 )
                  when e.CounterStatus='Mentor_Overdue_Yearly_Assessment' then
                (
                     @MENTOR_Overdue_Yearly_AssessmentCounter 
                 )
                 when e.CounterStatus='MentorAnnaulBidCeiling' then
                 (
                     @MentorAnnualBidCeilingCounter 
                 )
				 --TS: bugfix for 00129097
				 when e.COUNTERSTATUS='Preliminary_Class_RSVPD' then
				(
					select count(distinct Vendorid)
					from eeo_vendor v, #TempDashboardCounter e
					where [Status]=e.counterstatus
					and e.COUNTERSTATUS='Preliminary_Class_RSVPD' 
					and not exists (select * from EEO_MENTOR_EXCEPTION where vendorid=v.VendorId and sd_end>getdate())
					and v.MentorFlag=1
				)
             
    --select * from eeo_special_Assessment where Status=''	
    -- select  DATEADD(month, 3, getdate()),getdate() 
    -- delete eeo_special_Assessment where id =14			
            else
                (select count(vendorid)
                from eeo_vendor v
                where [Status]=e.counterstatus
                and not exists (select * from EEO_MENTOR_EXCEPTION where vendorid=v.VendorId and sd_end>getdate())
                )
            end as [Count]
        from #TEMPDASHBOARDCOUNTER e
        
        order by  e.counterType  

    Drop table #TempDashboardCounter
END

GO

/*
exec [dbo].[EEO_GetDashboardCounter] @userId=1247
exec [dbo].[EEO_GetDashboardCounter] @userId=1072

*/
