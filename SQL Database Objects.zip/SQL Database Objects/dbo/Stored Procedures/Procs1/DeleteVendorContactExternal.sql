﻿IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_NAME = 'DeleteVendorContactExternal')
BEGIN
	DROP PROCEDURE [dbo].[DeleteVendorContactExternal]  
END;
GO

/*
*********************************************************************************************************************
Procedure:	DeleteVendorContactExternal
Purpose:	Delete a row from VendorContactExternal table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/9/2004		AECSOFT\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteVendorContactExternal]
	@id int
as


delete from VendorContactExternalRole where VendorContactExternalId = @id
delete from VendorContactExternal where Id = @id
return @@RowCount
Go





