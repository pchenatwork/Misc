﻿CREATE PROC [dbo].[EEO_GetMentorsWithIn2Yrs]
As

select 
	ev.* 
from 
	EEO_MENTOR_GRAD_DETAIL e,eeo_vendor ev,eeo_workflowhistory eh
where 
	--DATEADD(YEAR,2,e.SD_ACTUAL_GRAD_DT)>getdate() 
	e.SD_ACTUAL_GRAD_DT>dateadd(year,-2,GETDATE()) 
and e.SD_ACTUAL_GRAD_DT <getdate()
and e.C_MENTOR_TYPE='MENTOR'
and e.SD_ACTUAL_GRAD_DT is not null
and e.vendorid=ev.VendorId
--and ev.MentorFlag=6  -- in Mentor Program
and ev.TransactionId=eh.TransactionId
and eh.WorkFlowId<>20
and (e.SD_END is null or e.sd_end >getdate())
and not exists(select * from EEO_MENTOR_GRAD_DETAIL where vendorid=e.VENDORID and C_MENTOR_TYPE='GRAD MENTOR')


--select * from EEO_WorkFlowList
