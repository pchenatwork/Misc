﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectBidPart
Purpose:	Delete a row from ProjectBidPart table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/30/2009		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteProjectBidPart]
	@id int
as

begin transaction
begin try
	declare @rowCount int
	
	delete pb1
	from
		ProjectBidPart pb1
	inner join
		(select * from ProjectBidPart where Id=@id) pb2
	on
		pb1.PartId = pb2.PartId and pb1.ProjectId = pb2.ProjectId

	if @@RowCount > 0
		set @rowCount = 1
	else set @rowCount = 0

--	update pb1
--	set pb1.partId = pb2.rownumber
--	from
--		projectbidpart pb1
--	inner join
--		(select *, row_number() over (partition by projectId, [Type] order by Id) as rownumber from ProjectBidPart) pb2 
--	on
--		pb1.Id = pb2.Id
--	where 
--		pb1.[type] in ('Book', 'Addendum')
--
--
--	update pb1
--	set pb1.drawingId = pb2.rownumber
--	from
--		projectbidpart pb1
--	inner join
--		(select *, row_number() over (partition by projectId, [Type] order by Id) as rownumber from ProjectBidPart) pb2 
--	on
--		pb1.Id = pb2.Id
--	where
--		pb1.[type]='Drawing'
--
--
--
--	update pb1
--	set 
--		pb1.partId = pb2.BookQuantity + 1 
--	from
--		ProjectBidPart pb1
--	inner join
--		(select projectId, 
--			count(case when [type]='Book' then Id end) as BookQuantity, 
--			count(case when [type]='Drawing' then Id end) as DrawingQuantity
--		from projectbidpart group by projectId) pb2
--	on
--		pb1.projectId = pb2.ProjectId
--	where
--		pb1.Type='Drawing'
--
--
--	update pb1
--	set 
--		pb1.partId = 
--		case 
--		when pb2.DrawingQuantity = 0 then pb1.partId + pb2.BookQuantity
--		when pb2.DrawingQuantity > 0 then pb1.partId + pb2.BookQuantity + 1
--		end
--	from
--		ProjectBidPart pb1
--	inner join
--		(select projectId, 
--			count(case when [type]='Book' then Id end) as BookQuantity, 
--			count(case when [type]='Drawing' then Id end) as DrawingQuantity
--		from projectbidpart group by projectId) pb2
--	on
--		pb1.projectId = pb2.ProjectId
--	where
--		pb1.Type='Addendum'

	commit transaction
	return @rowCount
end try
begin catch
	rollback transaction
	return 0
end catch