﻿

/*
*********************************************************************************************************************
Procedure:	DeleteJobSchedule
Purpose:	Delete a row from JobSchedule table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/3/2004		AECSOFT\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteJobSchedule]
	@id int
as
delete ScheduleHistory
where JobId = @id

delete JobSchedule
where Id = @id
return @@RowCount






