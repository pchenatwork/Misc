﻿/*  
*********************************************************************************************************************  
Procedure: DeleteBidderReject  
Purpose: Delete a row from BidderReject table.  
---------------------------------------------------------------------------------------------------------------------  
Date   Developer   Notes  
==========  =================== ===============================  
1/18/2010  AECSOFTUSA\angel   Created  
*********************************************************************************************************************  
*/  
ALTER procedure DeleteBidderReject  
 @id int  
as  

	IF ( SELECT ISNULL(TransferredFlag,0) FROM BidderReject WHERE Id = @Id) = 1
	BEGIN
		DECLARE @VasID INT = (SELECT BidderID FROM BidderReject WHERE BidderId = @Id);
		Exec SP_VAS_AUTOMATIC_AUDITLOG	'BidderReject_CMS'	,@Id	,@VasID	, DEFAULT, DEFAULT, NULL, 'Bid And Award NON TIGGERED Workflow', 'Delete Rejected Bidder', @DeleteActionToCMS = 1;
	END
  
	delete BidderReject  where Id = @id  
	return @@RowCount  
GO