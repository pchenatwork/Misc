﻿
/*
*********************************************************************************************************************
Procedure:	CopyProject
Purpose:	Copy existing record in Project table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
04/29/2011 		Bill Cooper			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CopyProject]
	@id int
	
as
begin

declare @nextTransactionId int


declare @projectId int
declare @newProjectId int
set @projectId = @id

-- Project
insert into Project ( SolicitationNo,ZipCode,WorkflowId,Type,TransNumber,TransmittalAvailableComments,TransferredFlag,TransferredDate,TransactionId,StatusName,Status,State,SPO,SolicitSeq,SolicitPkgRcvdDate,SolicitPkgRcvdCompleteDate,S01900Comments,S01500Comments,S01010Comments,Room,RfcId,RevisedBidOpeningDateTime,ProjectId,ProjectDuration,PreBidMeetingLoc,PreBidMeetingDateTime,PO,PlanedBidOpeningDateTime,PhasExhComments,PackageNo,OtherRecipients,MinAmt,MaxAmt,LLWNo,IsTransmittalAvailable,IsS01900Completed
,IsS01500Completed,IsS01010Completed,IsPreBidMeetingMandatory,IsPhasExhCompleted,IsLimited,IsIEHIncluded,IsEstIncluded,IsChecklistAvailable,IFBDate,IEHIncludedComments,IEHComments,HaveRecordsDelivered,HasSigninLogReceived,HasIEHApproved,HasFIDApproved,HasFIDApprovalBeenGranted,HasDurationSignedOff,HasCPOSignedOff,HasComputerSignedOff,FinancialScores,FIDGrantedComments,FIDComments,EstIncludedComments,DurationSignedComments,DrawingComments,DoesBreakdownRequested,DocsPrice,DocsAvailableDate,DesignNo,Description,Criteria,CPOSignedComments,CPO,Country,CostEstAmt,RevisedCostEstAmt,CostAmt,ContractSpecialist,ContractNo,ComputerSignedComments,Comments,CMRep,City,ChecklistAvailableComments,ChangeUser,ChangeDate,CentralFileDateTime,BreakdownComments,Boro,AwardSupplierId,AwardBidderId,AreDrawingCompleted,AreAlternatesCalledFor,AreAllowancesIncluded,AreAllFirmsLimitedList,AltProjectDuration,AllowanceComments,AllowanceAmt,AERep,AdsMinAmt,AdsMaxAmt,AddressLine2,AddressLine1,ActualDocsAvailableDate,ActualBidOpeningDateTime)
select SolicitationNo + '-C',ZipCode,WorkflowId,Type,TransNumber,TransmittalAvailableComments,TransferredFlag,TransferredDate,TransactionId,StatusName,Status,State,SPO,SolicitSeq,SolicitPkgRcvdDate,SolicitPkgRcvdCompleteDate,S01900Comments,S01500Comments,
S01010Comments,Room,RfcId,RevisedBidOpeningDateTime,ProjectId,ProjectDuration,PreBidMeetingLoc,PreBidMeetingDateTime,PO,PlanedBidOpeningDateTime,PhasExhComments,PackageNo,OtherRecipients,MinAmt,MaxAmt,LLWNo,IsTransmittalAvailable,IsS01900Completed,IsS01500Completed,IsS01010Completed,IsPreBidMeetingMandatory,IsPhasExhCompleted,IsLimited,IsIEHIncluded,IsEstIncluded,IsChecklistAvailable,IFBDate,IEHIncludedComments,IEHComments,HaveRecordsDelivered,HasSigninLogReceived,HasIEHApproved,HasFIDApproved,
HasFIDApprovalBeenGranted,HasDurationSignedOff,HasCPOSignedOff,HasComputerSignedOff,FinancialScores,FIDGrantedComments,FIDComments,EstIncludedComments,DurationSignedComments,DrawingComments,DoesBreakdownRequested,DocsPrice,DocsAvailableDate,DesignNo,Description,
Criteria,CPOSignedComments,CPO,Country,CostEstAmt,RevisedCostEstAmt,CostAmt,ContractSpecialist,ContractNo,ComputerSignedComments,Comments,CMRep,City,ChecklistAvailableComments,ChangeUser,ChangeDate,CentralFileDateTime,BreakdownComments,Boro,AwardSupplierId,
AwardBidderId,AreDrawingCompleted,AreAlternatesCalledFor,AreAllowancesIncluded,AreAllFirmsLimitedList,AltProjectDuration,AllowanceComments,AllowanceAmt,AERep,AdsMinAmt,AdsMaxAmt,AddressLine2,AddressLine1,ActualDocsAvailableDate,ActualBidOpeningDateTime from
 Project
where Id = @projectId


set @newProjectId = @@IDENTITY


-- ProjectRevisedEstimate
insert into ProjectRevisedEstimate (ProjectId,Comments,Amount,ReasonCode,ChangeUser,ChangeDate)
select @newProjectId,Comments,Amount,ReasonCode,ChangeUser,ChangeDate
from ProjectRevisedEstimate 
where ProjectId = @projectId


-- Bidder
insert into Bidder ( TransferredFlag,TransferredDate,SupplierId,Status,SolicitSeq,SolicitationNo,RejectComments,Rank,ProjectId,PickUpDate,MOCSSubmittedDate,MOCSSignedDate,MOCSReceivedDate,IsMocs,IsBidBond,IsBaseOrAlternate,IsBAFO,FinalAmt,DropOffDate,
CostEstAmt,Comments,ChangeUser,ChangeDate,BaseAmt,AwardStatus,AmtAdjustment,AlternateAmt9,AlternateAmt8,AlternateAmt7,AlternateAmt6,AlternateAmt5,AlternateAmt4,AlternateAmt3,AlternateAmt2,AlternateAmt10,AlternateAmt1)
select TransferredFlag,TransferredDate,SupplierId,Status,SolicitSeq,SolicitationNo,RejectComments,Rank,@newProjectId,PickUpDate,MOCSSubmittedDate,MOCSSignedDate,MOCSReceivedDate,IsMocs,IsBidBond,IsBaseOrAlternate,IsBAFO,FinalAmt,DropOffDate,CostEstAmt,
Comments,ChangeUser,ChangeDate,BaseAmt,AwardStatus,AmtAdjustment,AlternateAmt9,AlternateAmt8,AlternateAmt7,AlternateAmt6,AlternateAmt5,AlternateAmt4,AlternateAmt3,AlternateAmt2,AlternateAmt10,AlternateAmt1 from Bidder
where ProjectId = @projectId


-- Set Award Bidder
update p
set AwardBidderId = nb.Id
,AwardSupplierId = nb.SupplierId
from Bidder ob,Bidder nb,Project p
where ob.SupplierId = nb.SupplierId
and ob.ProjectId = @projectId
and nb.ProjectId = @newProjectId
and p.Id = @newProjectId

-- BidderApprenticeshipProgram
insert into BidderApprenticeshipProgram ( VerifyName,Type,TransferredFlag,TransferredDate,Trade,StartDate,ProgramName,NumberOfYears,Number,EndDate,Comments,ChangeUser,ChangeDate,BidderId,ApprovedTrade,ApprovedNumber,Approved)
select x.VerifyName,x.Type,x.TransferredFlag,x.TransferredDate,x.Trade,x.StartDate,x.ProgramName,x.NumberOfYears,x.Number,x.EndDate,x.Comments,x.ChangeUser,x.ChangeDate,nb.Id,x.ApprovedTrade,x.ApprovedNumber,x.Approved 
from Bidder ob,Bidder nb,BidderApprenticeshipProgram x 
where ob.SupplierId = nb.SupplierId
and ob.ProjectId = @projectId
and nb.ProjectId = @newProjectId
and x.BidderId = ob.Id

-- BidderBreakdown
insert into BidderBreakdown ( Variance,SCACost,EstimateCost,ContractorCost,Comments,ChangeUser,ChangeDate,BreakdownId,BidderId)
select x.Variance,x.SCACost,x.EstimateCost,x.ContractorCost,x.Comments,x.ChangeUser,x.ChangeDate,x.BreakdownId,nb.Id
from Bidder ob,Bidder nb,BidderBreakdown x 
where ob.SupplierId = nb.SupplierId
and ob.ProjectId = @projectId
and nb.ProjectId = @newProjectId
and x.BidderId = ob.Id

-- BidderReject
insert into BidderReject ( TransferredFlag,TransferredDate,RejectCode,ChangeUser,ChangeDate,BidderId)
select x.TransferredFlag,x.TransferredDate,x.RejectCode,x.ChangeUser,x.ChangeDate,nb.Id
from Bidder ob,Bidder nb,BidderReject x 
where ob.SupplierId = nb.SupplierId
and ob.ProjectId = @projectId
and nb.ProjectId = @newProjectId
and x.BidderId = ob.Id

-- BidderWicks
insert into BidderWicks ( PlumbingSupplierId,HVACSupplierId,ElectricalSupplierId,ChangeUser,ChangeDate,BidderId)
select x.PlumbingSupplierId,x.HVACSupplierId,x.ElectricalSupplierId,x.ChangeUser,x.ChangeDate,nb.Id 
from Bidder ob,Bidder nb,BidderWicks x 
where ob.SupplierId = nb.SupplierId
and ob.ProjectId = @projectId
and nb.ProjectId = @newProjectId
and x.BidderId = ob.Id

-- ProjectBAFO
insert into ProjectBAFO ( Witness,ProjectId,IsFinal,Comments,ChangeUser,ChangeDate,BidderId,Amount)
select x.Witness,@newProjectId,x.IsFinal,x.Comments,x.ChangeUser,x.ChangeDate,nb.Id,x.Amount
from Bidder ob,Bidder nb,ProjectBAFO x 
where ob.SupplierId = nb.SupplierId
and ob.ProjectId = @projectId
and nb.ProjectId = @newProjectId
and x.BidderId = ob.Id
and x.ProjectId = @projectId


declare @tempProjectTransaction table(id INT IDENTITY(1, 1), oid int,nid int)

insert into ProjectTransaction(ProjectId,BidderId,SupplierId,UserId,TransactionType,TransactionDate,NumberOfSets,PaymentType,TransactionAmt,CreditAvailableAmt,CreditBalanceAmt,CreditIssuedAmt,CreditAppliedAmt,DueAmt,ExtDocsAmt,IsPaymentReceived,VoidedDate
,Comments,ChangeDate,ChangeUser,TransferredFlag,TransferredDate,CommentTransferredFlag,CommentTransferredDate)
   OUTPUT  inserted.Id INTO @tempProjectTransaction (nid)
select @newProjectId,0,x.SupplierId,x.UserId,x.TransactionType,x.TransactionDate,x.NumberOfSets,x.PaymentType,x.TransactionAmt,x.CreditAvailableAmt,x.CreditBalanceAmt,x.CreditIssuedAmt,x.CreditAppliedAmt,x.DueAmt,x.ExtDocsAmt,x.IsPaymentReceived,
x.VoidedDate,x.Comments,x.ChangeDate,x.ChangeUser,x.TransferredFlag,x.TransferredDate,x.CommentTransferredFlag,x.CommentTransferredDate
from ProjectTransaction x
where x.ProjectId = @projectId


update t
set oid = x.Id
from @tempProjectTransaction t
	left join 	
	(
		select p.Id,((ROW_NUMBER() OVER(ORDER BY p.id))) as record
		from ProjectTransaction p
		where ProjectId = @projectId
	) x on t.id = x.record
	

declare @tempProjectAddendum table(id INT IDENTITY(1, 1), oid int,nid int)

-- ProjectAddendum
insert into ProjectAddendum ( WorkflowId,Type,TransactionId,StatusName,Status,ProjectId,PickupDate,NumberOfSheets,NumberOfPages,IsDelivered,DoesReproductionRequested,Description,Comments,ChangeUser,ChangeDate)
   OUTPUT  inserted.Id INTO @tempProjectAddendum (nid)
select WorkflowId,Type,TransactionId,StatusName,Status,@newProjectId,PickupDate,NumberOfSheets,NumberOfPages,IsDelivered,DoesReproductionRequested,Description,Comments,ChangeUser,ChangeDate 
from ProjectAddendum
where ProjectId = @projectId
order by Id

update t
set oid = x.Id
from @tempProjectAddendum t
	left join 	
	(
		select p.Id,((ROW_NUMBER() OVER(ORDER BY p.id))) as record
		from ProjectAddendum p
		where ProjectId = @projectId
	) x on t.id = x.record



set @nextTransactionId = isnull((select max(TransactionHeaderId) + 1 from WorkflowHistory), 1)
-- set trasaction Ids
update p
set p.TransactionId = x.TransactionId
from ProjectAddendum p,
	(
		select p.Id,((ROW_NUMBER() OVER(ORDER BY p.id))  - 1 + @nextTransactionId ) as TransactionId
		from ProjectAddendum p
		where ProjectId = @newProjectId
	) x
where ProjectId = @newProjectId
and x.Id = p.Id

insert into WorkflowHistory(TransactionHeaderId,WorkflowId,CurrentNodeId,ApprovalUserId,ApprovalRoleId,ApprovalConditionId,ApprovalDate,PrevHistoryId,Status,IsActive,Comments,DateCreated,CreatedBy,Version,CreatedType,DelegatorId)
select pwn.TransactionId,who.WorkflowId,who.CurrentNodeId,who.ApprovalUserId,who.ApprovalRoleId,who.ApprovalConditionId,who.ApprovalDate,who.PrevHistoryId,who.Status,who.IsActive,who.Comments,who.DateCreated,who.CreatedBy,who.Version,who.CreatedType,who.DelegatorId
from ProjectAddendum pwo,ProjectAddendum pwn,@tempProjectAddendum t,WorkflowHistory who
where pwo.WorkflowId = pwn.WorkflowId
and pwo.Id = t.oid
and pwn.Id = t.nid
and who.TransactionHeaderId = pwo.TransactionId

update WorkflowHistory
set PrevHistoryId = Id - 1
where TransactionHeaderId in (select TransactionId from ProjectAddendum where ProjectId = @newProjectId)
and PrevHistoryId <> 0


declare @tempPackage table(id INT IDENTITY(1, 1), oid int,nid int)

-- Package
insert into Package ( WorkflowId,Version,UserType,UserId,Type,TransactionId,Status,RfxDocumentId,ProjectId,PackageId,NeedMerge,Name,IdNo,FileName,Extension,Description,CreatorId,CreateDate,Comments,CheckOutType,CheckOutId,CheckOutDate,ChangeUser,ChangeDate,AttachmentId,ApprovalType,AddendumId)
   OUTPUT  inserted.Id INTO @tempPackage (nid)
select x.WorkflowId,x.Version,x.UserType,x.UserId,x.Type,x.TransactionId,x.Status,x.RfxDocumentId,@newProjectId,x.PackageId,x.NeedMerge,x.Name,x.IdNo,x.FileName,x.Extension,x.Description,x.CreatorId,x.CreateDate,x.Comments,x.CheckOutType,x.CheckOutId,x.CheckOutDate,x.ChangeUser,x.ChangeDate,x.AttachmentId,x.ApprovalType,ISNULL(t.nid,0)
from Package x
	left join @tempProjectAddendum t on x.AddendumId = t.oid
where x.ProjectId = @projectId


update t
set oid = x.Id
from @tempPackage t
	left join 	
	(
		select p.Id,((ROW_NUMBER() OVER(ORDER BY p.id))) as record
		from Package p
		where ProjectId = @projectId
	) x on t.id = x.record


-- PackageHistory
insert into PackageHistory ( Version,UserType,UserId,ProjectId,PackageId,HistoryId,FileName,Extension,Comments,ChangeUser,ChangeDate,AttachmentId,AddendumId)
select x.Version,x.UserType,x.UserId,@newProjectId,np.Id,x.HistoryId,x.FileName,x.Extension,x.Comments,x.ChangeUser,x.ChangeDate,x.AttachmentId,np.AddendumId 
from PackageHistory x,@tempPackage t
	left join Package np on t.nid = np.Id
where x.Id = t.oid


-- ProjectAdsCategory
insert into ProjectAdsCategory ( ProjectId,ChangeUser,ChangeDate,CategoryId)
select @newProjectId,ChangeUser,ChangeDate,CategoryId from ProjectAdsCategory
where ProjectId = @projectId

-- ProjectAlternate
insert into ProjectAlternate ( Type,ProjectId,IsSelected,Description,ChangeUser,ChangeDate)
select Type,@newProjectId,IsSelected,Description,ChangeUser,ChangeDate from ProjectAlternate
where ProjectId = @projectId

-- ProjectAward
insert into ProjectAward ( Variance,Type,TransNumber,Task,ProjectId,LLWPercent,LLWNo,IsReso,ExpenditureType,EstLLWAmt,ContractLLWAmt,ChangeUser,ChangeDate,BudgetAmt,AwardNumber,AuthorizedAmt)
select Variance,Type,TransNumber,Task,@newProjectId,LLWPercent,LLWNo,IsReso,ExpenditureType,EstLLWAmt,ContractLLWAmt,ChangeUser,ChangeDate,BudgetAmt,AwardNumber,AuthorizedAmt from ProjectAward
where ProjectId = @projectId


declare @tempProjectBidPart table(id INT IDENTITY(1, 1), oid int,nid int)

-- ProjectBidPart
insert into ProjectBidPart ( Type,TransferredFlag,TransferredDate,ReorderQuantity,RefId,ProjectId,PartId,MinReqQuantity,Location,DrawingId,DrawingDesc,Description,ChangeUser,ChangeDate)
   OUTPUT  inserted.Id INTO @tempProjectBidPart (nid)
select Type,TransferredFlag,TransferredDate,ReorderQuantity,RefId,@newProjectId,PartId,MinReqQuantity,Location,DrawingId,DrawingDesc,Description,ChangeUser,ChangeDate from ProjectBidPart
where ProjectId = @projectId
--##ProjectOrderDetail
--##ProjectOrderSupplierDetail


update t
set oid = x.Id
from @tempProjectBidPart t
	left join 	
	(
		select p.Id,((ROW_NUMBER() OVER(ORDER BY p.id))) as record
		from ProjectBidPart p
		where ProjectId = @projectId
	) x on t.id = x.record



-- ProjectTransactionDetail
insert into ProjectTransactionDetail ( TransferredFlag	,TransferredDate	,Quantity	,ProjectTransactionId	,ProjectBidPartId,ChangeUser	,ChangeDate)
select								x.TransferredFlag	,x.TransferredDate	,x.Quantity ,pt.nid				     ,pbp.nId			 ,x.ChangeUser	,x.ChangeDate 
from ProjectTransactionDetail x
	left join @tempProjectTransaction pt on x.ProjectTransactionId = pt.oid
	left join @tempProjectBidPart pbp on x.ProjectBidPartId = pbp.oid
where x.ProjectTransactionId in (select oid from @tempProjectTransaction)




-- ProjectBidPartLocation
insert into ProjectBidPartLocation ( SchoolName,ProjectId,ProjectBidPartId,Location,IsCentralFile,DocsType,Comments,ChangeUser,ChangeDate)
select SchoolName,@newProjectId,ProjectBidPartId,Location,IsCentralFile,DocsType,Comments,ChangeUser,ChangeDate from ProjectBidPartLocation
where ProjectId = @projectId

-- ProjectComment
insert into ProjectComment ( UserId,Type,Submitted,RefId,ProjectId,CreateDate,Comments,ChangeUser,ChangeDate)
select UserId,Type,Submitted,RefId,@newProjectId,CreateDate,Comments,ChangeUser,ChangeDate from ProjectComment
where ProjectId = @projectId

-- ProjectDocument
insert into ProjectDocument ( Type,RefId,ProjectId,IsApproved,FileName,Comments,ChangeUser,ChangeDate,AttachmentId)
select Type,RefId,@newProjectId,IsApproved,FileName,Comments,ChangeUser,ChangeDate,AttachmentId from ProjectDocument
where ProjectId = @projectId

-- ProjectItem
insert into ProjectItem ( ZipCode,TransferredFlag,TransferredDate,SourceOfFunds,SchoolAddressLine2,SchoolAddressLine1,School,ProjectId,PlanYear,LLWDesc,LLW,IsResoA,IsMentor,IsFIDApproved,ChangeUser,ChangeDate,Boro,AuthCostEstAmt,AuthCostAmt)
select ZipCode,TransferredFlag,TransferredDate,SourceOfFunds,SchoolAddressLine2,SchoolAddressLine1,School,@newProjectId,PlanYear,LLWDesc,LLW,IsResoA,IsMentor,IsFIDApproved,ChangeUser,ChangeDate,Boro,AuthCostEstAmt,AuthCostAmt from ProjectItem
where ProjectId = @projectId

-- ProjectOfficial
insert into ProjectOfficial ( UserId,SignDate,ProjectId,ChangeUser,ChangeDate)
select UserId,SignDate,@newProjectId,ChangeUser,ChangeDate from ProjectOfficial
where ProjectId = @projectId


declare @tempProjectOrder table(id INT IDENTITY(1, 1), oid int,nid int)
-- ProjectOrder
insert into ProjectOrder ( WorkflowId,TransactionId,StatusName,Status,ProjectId,Priority,OriginalSize,NumberOfSheetsInRoll5,NumberOfSheetsInRoll4,NumberOfSheetsInRoll3,NumberOfSheetsInRoll2,NumberOfSheetsInRoll1,NumberOfSheets,NumberOfRolls,NumberOfPages,
NumberOfBooks,Comments,ChangeUser,ChangeDate)
   OUTPUT  inserted.Id INTO @tempProjectOrder (nid)
select WorkflowId,-1,StatusName,Status,@newProjectId,Priority,OriginalSize,NumberOfSheetsInRoll5,NumberOfSheetsInRoll4,NumberOfSheetsInRoll3,NumberOfSheetsInRoll2,NumberOfSheetsInRoll1,NumberOfSheets,NumberOfRolls,NumberOfPages,NumberOfBooks,Comments,ChangeUser,ChangeDate from ProjectOrder
where ProjectId = @projectId
--##ProjectOrderDetail
--##ProjectOrderSupplier


update t
set oid = x.Id
from @tempProjectOrder t
	left join 	
	(
		select p.Id,((ROW_NUMBER() OVER(ORDER BY p.id))) as record
		from ProjectOrder p
		where ProjectId = @projectId
	) x on t.id = x.record
	
	
set @nextTransactionId = isnull((select max(TransactionHeaderId) + 1 from WorkflowHistory), 1)
-- set trasaction Ids
update p
set p.TransactionId = x.TransactionId
from ProjectOrder p,
	(
		select p.Id,((ROW_NUMBER() OVER(ORDER BY p.id))  - 1 + @nextTransactionId ) as TransactionId
		from ProjectOrder p
		where ProjectId = @newProjectId
	) x
where ProjectId = @newProjectId
and x.Id = p.Id

insert into WorkflowHistory(TransactionHeaderId,WorkflowId,CurrentNodeId,ApprovalUserId,ApprovalRoleId,ApprovalConditionId,ApprovalDate,PrevHistoryId,Status,IsActive,Comments,DateCreated,CreatedBy,Version,CreatedType,DelegatorId)
select pwn.TransactionId,who.WorkflowId,who.CurrentNodeId,who.ApprovalUserId,who.ApprovalRoleId,who.ApprovalConditionId,who.ApprovalDate,who.PrevHistoryId,who.Status,who.IsActive,who.Comments,who.DateCreated,who.CreatedBy,who.Version,who.CreatedType,who.DelegatorId
from ProjectOrder pwo,ProjectOrder pwn,@tempProjectOrder t,WorkflowHistory who
where pwo.WorkflowId = pwn.WorkflowId
and pwo.Id = t.oid
and pwn.Id = t.nid
and who.TransactionHeaderId = pwo.TransactionId

update WorkflowHistory
set PrevHistoryId = Id - 1
where TransactionHeaderId in (select TransactionId from ProjectOrder where ProjectId = @newProjectId)
and PrevHistoryId <> 0


-- ProjectOrderDetail
insert into ProjectOrderDetail ( ProjectOrderId,ProjectBidPartId,SentToPrinterQuantity,SentToPrinterDate,ReceiptNo,RcvdFromPrinterQuantity,RcvdFromPrinterDate,ProjectId,PrinterFlag,OrderRcvdDate,OrderedQuantity,ChangeUser,ChangeDate)
select po.nid,pbp.nid,SentToPrinterQuantity,SentToPrinterDate,ReceiptNo,RcvdFromPrinterQuantity,RcvdFromPrinterDate,@newProjectId,PrinterFlag,OrderRcvdDate,OrderedQuantity,ChangeUser,ChangeDate 
from ProjectOrderDetail x
	left join @tempProjectOrder po on x.ProjectOrderId = po.oid
	left join @tempProjectBidPart pbp on x.ProjectBidPartId = pbp.oid
where x.ProjectId = @projectId



declare @tempProjectOrderSupplier table(id INT IDENTITY(1, 1), oid int,nid int)
-- ProjectOrderSupplier
insert into ProjectOrderSupplier ( ProjectOrderId,WorkflowId,TransactionId,SupplierId,StatusName,Status,ProjectId,Priority,Comments,ChangeUser,ChangeDate)
   OUTPUT  inserted.Id INTO @tempProjectOrderSupplier (nid)
select po.nid,WorkflowId,-1,SupplierId,StatusName,Status,@newProjectId,Priority,Comments,ChangeUser,ChangeDate 
from ProjectOrderSupplier x
	left join @tempProjectOrder po on x.ProjectOrderId = po.oid
where x.ProjectId = @projectId
--##ProjectOrderSupplierDetail


update t
set oid = x.Id
from @tempProjectOrderSupplier t
	left join 	
	(
		select p.Id,((ROW_NUMBER() OVER(ORDER BY p.id))) as record
		from ProjectOrderSupplier p
		where ProjectId = @projectId
	) x on t.id = x.record



set @nextTransactionId = isnull((select max(TransactionHeaderId) + 1 from WorkflowHistory), 1)
-- set trasaction Ids
update p
set p.TransactionId = x.TransactionId
from ProjectOrderSupplier p,
	(
		select p.Id,((ROW_NUMBER() OVER(ORDER BY p.id))  - 1 + @nextTransactionId ) as TransactionId
		from ProjectOrderSupplier p
		where ProjectId = @newProjectId
	) x
where ProjectId = @newProjectId
and x.Id = p.Id

insert into WorkflowHistory(TransactionHeaderId,WorkflowId,CurrentNodeId,ApprovalUserId,ApprovalRoleId,ApprovalConditionId,ApprovalDate,PrevHistoryId,Status,IsActive,Comments,DateCreated,CreatedBy,Version,CreatedType,DelegatorId)
select pwn.TransactionId,who.WorkflowId,who.CurrentNodeId,who.ApprovalUserId,who.ApprovalRoleId,who.ApprovalConditionId,who.ApprovalDate,who.PrevHistoryId,who.Status,who.IsActive,who.Comments,who.DateCreated,who.CreatedBy,who.Version,who.CreatedType,who.
DelegatorId
from ProjectOrderSupplier pwo,ProjectOrderSupplier pwn,@tempProjectOrderSupplier t,WorkflowHistory who
where pwo.WorkflowId = pwn.WorkflowId
and pwo.Id = t.oid
and pwn.Id = t.nid
and who.TransactionHeaderId = pwo.TransactionId

update WorkflowHistory
set PrevHistoryId = Id - 1
where TransactionHeaderId in (select TransactionId from ProjectOrderSupplier where ProjectId = @newProjectId)
and PrevHistoryId <> 0

-- ProjectOrderSupplierDetail
insert into ProjectOrderSupplierDetail ( ProjectOrderSupplierId,ProjectBidPartId,SentToPrinterQuantity,SentToPrinterDate,ReceiptNo,RcvdFromPrinterQuantity,RcvdFromPrinterDate,ProjectId,PrinterFlag,OrderRcvdDate,OrderedQuantity,ChangeUser,ChangeDate)
select  pos.nid,pbp.nid,SentToPrinterQuantity,SentToPrinterDate,ReceiptNo,RcvdFromPrinterQuantity,RcvdFromPrinterDate,@newProjectId,PrinterFlag,OrderRcvdDate,OrderedQuantity,ChangeUser,ChangeDate 
from ProjectOrderSupplierDetail x
	left join @tempProjectOrderSupplier pos on x.ProjectOrderSupplierId = pos.oid
	left join @tempProjectBidPart pbp on x.ProjectBidPartId = pbp.oid
where x.ProjectId = @projectId


-- ProjectProperty
insert into ProjectProperty ( Selected,PropertyValue,PropertyText,PropertyId,PropertyDate,ProjectId,ParentId,ChangeUser,ChangeDate,AttachmentName,AttachmentId)
select Selected,PropertyValue,PropertyText,PropertyId,PropertyDate,@newProjectId,ParentId,ChangeUser,ChangeDate,AttachmentName,AttachmentId from ProjectProperty
where ProjectId = @projectId

-- ProjectQuestion
insert into ProjectQuestion ( WorkflowId,UserType,UserId,TransactionId,StatusName,Status,Question,ProjectId,IdNo,FileName,CreateDate,ChangeDate,AttachmentId)
select WorkflowId,UserType,UserId,TransactionId,StatusName,Status,Question,@newProjectId,IdNo,FileName,CreateDate,ChangeDate,AttachmentId from ProjectQuestion
where ProjectId = @projectId

-- ProjectReport
insert into ProjectReport ( Type,ReportTitle,ReportText,ReportComment,ProjectId,FileName,CreateDate,ChangeUser,ChangeDate,BuyerId,AttachmentId)
select Type,ReportTitle,ReportText,ReportComment,@newProjectId,FileName,CreateDate,ChangeUser,ChangeDate,BuyerId,AttachmentId from ProjectReport
where ProjectId = @projectId

-- ProjectSupplier
insert into ProjectSupplier ( SupplierId,Status,ProjectId,Comments,ChangeUser,ChangeDate)
select SupplierId,Status,@newProjectId,Comments,ChangeUser,ChangeDate from ProjectSupplier
where ProjectId = @projectId


-- ProjectWorkflow
insert into ProjectWorkflow ( WorkflowType,WorkflowId,TransferredFlag,TransactionId,Status, Statusname,ProjectId)
select WorkflowType,WorkflowId,TransferredFlag,-1,Status, Statusname,@newProjectId from ProjectWorkflow
where ProjectId = @projectId


set @nextTransactionId = isnull((select max(TransactionHeaderId) + 1 from WorkflowHistory), 1)
-- set trasaction Ids
update pw 
set TransactionId = x.TransactionId
from ProjectWorkflow pw,
	(
		select pw.Id,((ROW_NUMBER() OVER(ORDER BY pw.id))  - 1 + @nextTransactionId ) as TransactionId
		from ProjectWorkflow pw
		where ProjectId = @newProjectId
	) x
where ProjectId = @newProjectId
and x.Id = pw.Id


insert into WorkflowHistory(TransactionHeaderId,WorkflowId,CurrentNodeId,ApprovalUserId,ApprovalRoleId,ApprovalConditionId,ApprovalDate,PrevHistoryId,Status,IsActive,Comments,DateCreated,CreatedBy,Version,CreatedType,DelegatorId)

select pwn.TransactionId
		,who.WorkflowId
		,who.CurrentNodeId
		,who.ApprovalUserId
		,who.ApprovalRoleId
		,who.ApprovalConditionId
		,who.ApprovalDate
		,who.PrevHistoryId
		,who.Status
		,who.IsActive
		,who.Comments
		,who.DateCreated
		,who.CreatedBy
		,who.Version
		,who.CreatedType
		,who.DelegatorId
from ProjectWorkflow pwo,ProjectWorkflow pwn,WorkflowHistory who
where pwo.WorkflowId = pwn.WorkflowId
and pwo.ProjectId = @projectId
and pwn.ProjectId = @newProjectId
and who.TransactionHeaderId = pwo.TransactionId

update WorkflowHistory
set PrevHistoryId = Id - 1
where TransactionHeaderId in (
	select TransactionId from ProjectWorkflow where ProjectId = @newProjectId
)
and PrevHistoryId <> 0

end
return  @@identity

