﻿/*
BDD Analyst Yearly Assessment Overdue Counter


•	Should be Mentor firms Only
•	Assessments not completed within the specified time period (this should be configurable)
    o	E.g. if the assessment is supposed to be done from Dec 1st 2015 to Mar 1st  2016 and the assessment is not submitted, on March 2nd  2016 the firm should appear in the counter. Dec 1st to Mar 1st should be configurable. On Dec 1st 2016, the firm should be off the counter as this is going to be part of Scope B’s yearly assessment counter.



*/
CREATE PROCEDURE [dbo].[EEO_GetOverdueYearlyAssessmentCounter]
(
  @ret int OUTPUT
)
AS

Begin
 DECLARE @tableVar table
    (
         Vendorid int
    )
    Insert into @tableVar
       exec  dbo.EEO_GetOverdueYearlyAssessmentVendors  



    
    SELECT @ret = Count(*)FROM @tableVar
   
    IF (@ret IS NULL) 
        SET @ret = 0;
        
        
   
END
