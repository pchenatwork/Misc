﻿
/*
*********************************************************************************************************************
Procedure:	DeleteSupplierCertificationAppeal
Purpose:	Delete a row from SupplierCertificationAppeal table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/11/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierCertificationAppeal
	@id int
as

delete SupplierCertificationAppeal
where Id = @id
return @@RowCount

