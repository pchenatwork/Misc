﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE Procedure [dbo].[EEO_CheckRequiredClassesAttended]
	-- Add the parameters for the stored procedure here
	@vendorId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	--SET NOCOUNT ON;

    -- Insert statements for procedure here
	declare @currentStatus varchar(50)
	declare @classType varchar(1)
	declare @count int
	select @currentStatus=status from eeo_vendor where vendorid=@vendorId


	if @currentStatus='Preliminary_Class_RSVPD' or @currentStatus ='Preliminary_Class_Details_Emailed'
		begin
			set @classType=1
		end
	else if @currentStatus='Tier2_Program' or @currentStatus='AdvancedClassesUpdated' or @currentStatus='AdvancedClassesAbsent' 
		begin
			set @classType=4
		end
	else if @currentStatus='Orientation__Class_Details_Emailed' 
		begin
			set @classType=2
		end
	
	set @count =(
				select count(*)
			from
				(
				select	C_CLASS_ID	from	eeo_classes ec where	ec.c_class_Type=@classType	
				except
				select 
					vc.C_CLASS_ID 
				from 
					EEO_VENDOR_CLASSES vc 
				where 
					vc.vendorid=@vendorId 
					--and (isnull(C_ATTENDED,'N') ='Y' or (isnull(C_REASON_EXCUSED,'')<>'' and isnull(C_ATTENDED,'N') ='N'))
					and (isnull(C_ATTENDED,'N') ='Y' or 
							(
								(
									isnull(C_REASON_EXCUSED,'')<>'' 
									Or 
									(isnull(REVIEWED,'')<>'' and @classType=2)  -- For Orientation class just check whether Reviewer Reviewed the attendance
								)
								and isnull(C_ATTENDED,'N') ='N'
							)
						)

				) c

				)
		


	select @count
	return @count
END
