﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierCheckList
Purpose:	Delete a row from SupplierCheckList table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/27/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierCheckList
	@id int
as

delete SupplierCheckList
where Id = @id
return @@RowCount

