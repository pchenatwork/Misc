﻿CREATE procedure [dbo].[DeleteRule]
	@id int
as
BEGIN Transaction
delete [Action] where RuleId = @id
delete [Rule]
where Id = @id
if @@error = 0
	Commit Transaction   
else
	RollBack Transaction
return @@RowCount



