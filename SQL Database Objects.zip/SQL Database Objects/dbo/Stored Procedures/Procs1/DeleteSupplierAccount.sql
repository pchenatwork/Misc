﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierAccount
Purpose:	Delete a row from SupplierAccount table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/11/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierAccount
	@id int
as

delete SupplierAccount
where Id = @id
return @@RowCount

