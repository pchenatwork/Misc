﻿


CREATE procedure [dbo].[DeleteSupplierPersonnelProject]
	@id int
as

--auditlog
declare @transactionId int
declare @actionTime datetime
insert into [Transaction](Type, ActionTime) values ('CMS', @actionTime)
select @transactionId = max(id) from [Transaction]	

declare @supplierid int
declare @transferredflag char(1)
select	@supplierId = supplierId,
		@transferredflag= transferredflag
from SupplierPersonnelProject where Id=@id
----


delete SupplierPersonnelProject
where Id = @id

declare @rowCount int
set @rowCount = @@RowCount


--auditlog
if @transferredflag='1'
	begin 
		Insert AuditLog
				(TableName, RecordId, VASId,  MainId, TransactionID, Action, ActionTime, UserName, ProcessedStatus)
				values('SupplierPersonnelProject', @id,@id, @supplierid, @transactionId, 'delete',@actionTime,null, 'U')
	end
--

return @rowCount







