﻿



CREATE procedure [dbo].[CopySupplierSicCode]
	@supplierId int,	
	@newSupplierId int,
	@changeUser nvarchar(50)
as
begin
	insert SupplierSicCode
		(	
			SupplierId,
			SicCode
		)
	select
			@newSupplierId,
			SicCode
	from SupplierSicCode where supplierId=@supplierId

end




