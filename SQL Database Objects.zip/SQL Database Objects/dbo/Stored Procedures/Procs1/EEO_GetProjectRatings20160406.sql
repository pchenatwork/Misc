﻿CREATE PROCEDURE [dbo].[EEO_GetProjectRatings20160406]
	-- Add the parameters for the stored procedure here
	@vendorId int,
    @periodId int,
	@userid  int
AS

Begin


------------------------------
---- PERIOD START AND END DATE 
------------------------------ 

Declare @periodStartDate as Datetime 
Declare @periodEndDate as Datetime 
Declare @periodmonth  as Datetime 
Declare @title as nvarchar(100)
              
selecT  @title =u.Title from   [user] u
  where u.Id=@userid
  
   

Declare @tempPeriod Table
(
    PeriodId int,
  	AST_StartDate Datetime,
    AST_EndDate Datetime
)

insert into @tempPeriod
   exec EEO_GetPMAssessmentPeriod @vendorId
   
select @periodStartDate=AST_StartDate ,
       @periodEndDate=AST_EndDate  
from @tempPeriod  where PeriodId=@periodId 

------------------------------
---- PERIOD START AND END DATE 
------------------------------ 
   
   
 


 

-------------------------
---- PROJECTS WITH DETAILS  
-------------------------

Declare @tempProject  Table
(  
    VENDORID int,
    PERIODID int,
    PROJECT_CODE varchar(10),
    PERIOD_MONTH  datetime,
    START_DATE datetime,
    END_DATE datetime,
    PCT_COMPLETE	int,
	LLW_CODE varchar(6),
	LLW_DESC varchar(35)

)


DECLARE month_cursor CURSOR FOR 
    SELECT DATEADD(month,number,@PeriodStartDate) [PeriodMonth]
        FROM master..spt_values
       WHERE type = 'P'
            AND DATEADD(month,number+1,@PeriodStartDate) <=  @PeriodEndDate;
        
OPEN month_cursor

FETCH NEXT FROM month_cursor 
    INTO @periodmonth
 

        
WHILE @@FETCH_STATUS = 0
BEGIN
 
 
 INSERT INTO  @tempProject (  VENDORID,PERIODID,PROJECT_CODE  ,START_DATE ,END_DATE ,PERIOD_MONTH,PCT_COMPLETE,LLW_CODE,LLW_DESC)
        SELECT DISTINCT  
                V.ID AS VENDORID,
                @periodId AS PERIODID,
                SC.C_PACKAGE_CODE AS PROJECT_CODE,
                SC.D_CONSTR_BEGIN AS START_DATE,
                ISNULL(SC.D_CONSTR_END, GETDATE()) AS END_DATE,
                @periodmonth,
                CAST(CAST(SC.PCT_BY_CONTRACT  AS float) AS INT),
				R.LLW_CODE,
				R.llw_desc                
            FROM MV_SOLICIT_CONTRACT SC 
					INNER JOIN VENDOR V ON  ISNULL(C_VENDOR_ID,ME_VENDOR_ID)= V.FEDERALID 
					INNER JOIN MV_VAS_RFC_ALL R ON  SC.c_package_code= r.package_code
        WHERE  V.ID=@vendorId 
        AND  ( DATEADD(dd, 1, EOMONTH(@periodmonth, -1))  >= DATEADD(dd, 1, EOMONTH(SC.D_CONSTR_BEGIN , -1)) 
                        AND EOMONTH(@periodmonth) <= EOMONTH(ISNULL(SC.D_CONSTR_END, GETDATE()) ) )
		AND (@title=''  or (@title!='' and SC.ME_CONTRACT in (select c_contract from MV_SOLICIT_CONTRACT where C_VENDOR_ID=@title)))

  FETCH NEXT FROM month_cursor 
    INTO @periodmonth
END 
CLOSE month_cursor;
DEALLOCATE month_cursor;     


--select VENDORID,PERIODID,PROJECT_CODE, START_DATE,PERIOD_MONTH, END_DATE   from @tempProject  P
--    ORDER BY PROJECT_CODE,PERIOD_MONTH
  
-------------------------
---- PROJECTS WITH DETAILS  
-------------------------

-------------------------
---- PROJECTS RATINGS 
-------------------------
  SELECT PR.*,SP.REQUESTEDCOMMENT, SP.SPLASSESSMENTTYPE  FROM 
  
  (   
         SELECT     R.VENDORID,
                    PERIOD_SEQ AS PERIODID,    
                    'Dummy' AS  PROJECT_CODE,
                    R.MONTH_RATED AS  PERIOD_MONTH,
                    NULL AS START_DATE,
                    NULL AS   END_DATE, 
                    R.DATE_RATED,
                    R.SCHEDULING_RT,
                    R.SAFETY_RT,
                    R.QUALITY_RT,
                    R.MANAGEMENT_RT,
					R.FIN_RT,
                    R.UPDATED_DATE,
                    R.UPDATED_BY,
                    R.BASIS,
                    R.APPROVAL_DATE,
                    R.APPROVED_BY,
                    R.GC_COMMENTS,
                    R.SUB_COMMENTS,
                    R.SCOPE_B_COMMENTS,
                    R.DMP_COMMENTS,
                    0 AS PCT_COMPLETE,
                    R.IS_SUBMITTED,
                    R.IS_APPROVED,
					R.INFORMALTRAINING,
					R.INFORMALTRAINING_COMMENTS,
					R.SPECIALASSESSMENTID,
					'' as LLW_CODE,
					'' as LLW_DESC 
        from EEO_LATEST_PPM_RATING R   
            WHERE PROJ_CODE ='Dummy'
               AND R.VENDORID=@vendorId
		       AND PERIOD_SEQ=@periodId
               
                
        UNION ALL 
       
  Select     p.VENDORID,
                    p.PERIODID,    
                    P.PROJECT_CODE,
                    P.PERIOD_MONTH,
                    P.START_DATE,
                    P.END_DATE, 
                    R.DATE_RATED,
                    R.SCHEDULING_RT,
                    R.SAFETY_RT,
                    R.QUALITY_RT,
                    R.MANAGEMENT_RT,
					R.FIN_RT,
                    R.UPDATED_DATE,
                    R.UPDATED_BY,
                    R.BASIS,
                    R.APPROVAL_DATE,
                    R.APPROVED_BY,
                    R.GC_COMMENTS,
                    R.SUB_COMMENTS,
                    R.SCOPE_B_COMMENTS,
                    R.DMP_COMMENTS,
                    ISNULL( R.PCT_COMPLETE,ISNULL( P.PCT_COMPLETE,0))  AS PCT_COMPLETE,
                    R.IS_SUBMITTED,
                    R.IS_APPROVED,
					R.INFORMALTRAINING,
					R.INFORMALTRAINING_COMMENTS,
					R.SPECIALASSESSMENTID,
					P.LLW_CODE,
					P.LLW_DESC
        from EEO_LATEST_PPM_RATING R RIGHT JOIN  @tempProject  P ON R.PROJ_CODE = P.PROJECT_CODE AND R.LLWCode=P.LLW_CODE
								 
                AND R.VENDORID = P.VENDORID 
                AND R.PERIOD_SEQ  =P.PERIODID
                AND (R.MONTH_RATED BETWEEN DATEADD(dd, 1, EOMONTH(P.PERIOD_MONTH, -1))   AND EOMONTH(P.PERIOD_MONTH)) 
         ) PR  LEFT JOIN EEO_SPECIAL_ASSESSMENT SP  ON PR.SPECIALASSESSMENTID = SP.ID
ORDER BY  PR.PERIOD_MONTH, PR.PROJECT_CODE
       

-------------------------
---- PROJECTS RATINGS 
-------------------------  
   
  
END
