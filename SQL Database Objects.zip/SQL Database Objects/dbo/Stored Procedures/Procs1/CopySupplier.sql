﻿


CREATE procedure [dbo].[CopySupplier]	
	@id int, 
	@type nvarchar(50),
	@changeUser nvarchar(50)
as
begin

declare @supplierId int
set @supplierId = @id

if not exists(select * from supplierversion where supplierid=@supplierId and status = 1)
	return 0

if @type='Pre'
	begin
		begin transaction

		begin try
			declare @versionId int
			declare @questionIds nvarchar(1000)	



			-----------------------
			---SupplierVersion-----
			-----------------------

			--insert into SupplierVersion for version1
--			if not exists (select * from SupplierVersion where supplierId = @supplierId)
--			begin				
--				insert SupplierVersion (SupplierId, VersionId, Status, IsLocked, ChangeDate)
--				values (@supplierId, @supplierId, 0, 'Y', getdate())
--			end
			
			select @versionId = versionId from supplierversion where supplierId=@supplierId

			--update the latest version record in SupplierVersion
			declare @approvedDate datetime
			declare @approvedUserId nvarchar(50)
			select @approvedDate= DateCreated, @approvedUserId = CreatedBy 
			from (select  top 1 wh.DateCreated, wh.CreatedBy 
				from workflowhistory wh
				inner join supplierworkflow sw
				on sw.transactionid = wh.transactionheaderid
				inner join workflowNode wn
				on wh.currentnodeid = wn.Id
					where wn.Name='Qualified'
						and wn.workflowId = (select Id from workflowList where name='Supplier Prequalification')
						and sw.supplierId = @supplierId
				order by wh.datecreated desc) t
			
			update SupplierVersion
			set VersionYear = convert(nvarchar(50), datepart(year,@approvedDate)),
				ApprovedDate = @approvedDate,
				ApprovedUser = @approvedUserId,
				EffectiveDate = @approvedDate,
				ExpirationDate = Dateadd(year, 3, @approvedDate),
				Status = 0,
				IsLocked = 'Y', 
				ChangeDate = getdate()
			where supplierId=@supplierId


			-----------------------
			---Copy----------------
			-----------------------

			declare @newSupplierId int

			--Supplier
			exec  @newSupplierId = [CopySupplierTable] @supplierId, @changeUser
			print 'Supplier is done'

			--SupplierProperty Table
			/*
			insert into supplierproperty(SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachment, AttachmentName)
			select @newSupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachment, AttachmentName
				from supplierproperty where supplierid=@supplierId 
					--internal
					and propertyId not in (10, 50, 51, 54)
					--osha.ascx 
					and propertyId not in (62, 63, 64, 65)
					--
					and (propertyId <447 or (propertyId >495 and propertyId <501) or propertyId in (2001,2003,2004))
					and convert(nvarchar(1000), isnull(propertytext, '')) <>'N'
			*/
		
			insert into supplierproperty(SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName)
			select 
				@newSupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName
			from 
				supplierproperty 
			where 
				supplierid=@supplierId 
				and propertyid in (1,2,3,4,5,8,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27)
				
			print 'SupplierProperty is done'

			--SupplierPersonnel
			exec [CopySupplierPersonnel] @supplierId, @newSupplierId, @changeUser
			print 'SupplierPersonnel is done'
			
			--SupplierCategory	
			exec [CopySupplierCategory] @supplierId, @newSupplierId, @changeUser
			print 'SupplierCategory is done'
				--SupplierAccount
			
			exec [CopySupplierAccount] @supplierId, @newSupplierId, @changeUser
			print 'SupplierAccount is done'

			--SupplierAddress
			exec [CopySupplierAddress] @supplierId, @newSupplierId, @changeUser
			print 'SupplierAddress is done'

			--SupplierClassification
			exec [CopySupplierClassification] @supplierId, @newSupplierId, @changeUser
			print 'SupplierClassification is done'

-- was commented out from here down

			--SupplierDocument
			exec [CopySupplierDocument] @supplierId, @newSupplierId, @changeUser
			print 'SupplierDocument is done'

			--SupplierRelatedFirm
			exec [CopySupplierRelatedFirm] @supplierId, @newSupplierId, @changeUser
			print 'SupplierRelatedFirm is done'

			--Certification
			exec [CopyCertification] @supplierId, @newSupplierId, @changeUser
			print 'Certification is done'

			--License
			exec [CopyLicense] @supplierId, @newSupplierId, @changeUser
			print 'License is done'

			--Owner
			exec [CopyOwner] @supplierId, @newSupplierId, @changeUser
			print 'Owner is done'

			--Reference
			exec [CopyReference] @supplierId, @newSupplierId, @changeUser
			print 'Reference is done'

		
			
			----SupplierApprenticeshipProgram
			exec [CopySupplierApprenticeshipProgram] @supplierId, @newSupplierId, @changeUser
			--if not exists(select * from SupplierApprenticeshipProgram where supplierid=@newSupplierId and Type='AddApprenticeship') 
			--	delete from supplierproperty where supplierid=@newSupplierId and propertyid = 109
			print 'SupplierApprenticeshipProgram is done'

			----SupplierBusinessMixedInfo
			exec [CopySupplierBusinessMixedInfo] @supplierId, @newSupplierId, @changeUser
			--if not exists(select * from SupplierBusinessMixedInfo where supplierid=@newSupplierId and Type='AddShared') 
			--	delete from supplierproperty where supplierid=@newSupplierId and propertyid = 82

			--if not exists(select * from SupplierBusinessMixedInfo where supplierid=@newSupplierId and Type='AddChange')
			--	delete from supplierproperty where supplierid=@newSupplierId and propertyid = 83

			--set @questionIds=''
			--select @questionIds = @questionIds + '|' + QuestionIds from SupplierBusinessMixedInfo where supplierid=@newSupplierId and Type='AddFirm1'
			--delete from  supplierproperty where supplierid=@newSupplierId and propertyId in (84, 85, 86, 87) and propertyId not in (select item from dbo.split(@questionIds, '|'))
			
			--set @questionIds=''
			--select @questionIds = @questionIds + '|' + QuestionIds from SupplierBusinessMixedInfo where supplierid=@newSupplierId and Type='AddFirm2'
			--delete from supplierproperty where supplierid=@newSupplierId and propertyId in (88, 89) and propertyId not in (select item from dbo.split(@questionIds, '|'))

			print 'SupplierBusinessMixedInfo is done'
			
				
			----SupplierCertificationAppeal
			exec [CopySupplierCertificationAppeal] @supplierId, @newSupplierId, @changeUser
			print 'SupplierCertificationAppeal is done'

			----SupplierCredit
			exec [CopySupplierCredit] @supplierId, @newSupplierId, @changeUser
			print 'SupplierCredit is done'

			----SupplierDebt
			exec [CopySupplierDebt] @supplierId, @newSupplierId, @changeUser
			--set @questionIds=''
			--select @questionIds = @questionIds + '|' + QuestionIds from SupplierDebt where supplierid=@newSupplierId
			--delete from  supplierproperty where supplierid=@newSupplierId and propertyId in (98,99,100) and propertyId not in (select item from dbo.split(@questionIds, '|'))
			print 'SupplierDebt is done'
			
			----SupplierDebtEvent
			exec [CopySupplierDebtEvent] @supplierId, @newSupplierId, @changeUser
			--set @questionIds=''
			--select @questionIds = @questionIds + '|' + QuestionIds from SupplierDebtEvent where supplierid=@newSupplierId
			--delete from  supplierproperty where supplierid=@newSupplierId and propertyId in (101,102,103) and propertyId not in (select item from dbo.split(@questionIds, '|'))
			print 'SupplierDebtEvent is done'	

			----SupplierDisadvantagedEmployee
			exec [CopySupplierDisadvantagedEmployee] @supplierId, @newSupplierId, @changeUser
			print 'SupplierDisadvantagedEmployee is done'

			----SupplierFailedContract
			exec [CopySupplierFailedContract] @supplierId, @newSupplierId, @changeUser
			--set @questionIds=''
			--select @questionIds = @questionIds + '|' + QuestionIds from SupplierFailedContract where supplierid=@newSupplierId
			--delete from  supplierproperty where supplierid=@newSupplierId and propertyId in (106,107) and propertyId not in (select item from dbo.split(@questionIds, '|'))
			print 'SupplierFailedContract is done'

			----SupplierGovernAction
			exec [CopySupplierGovernAction] @supplierId, @newSupplierId, @changeUser
			--set @questionIds=''
			--select @questionIds = @questionIds + '|' + QuestionIds from SupplierGovernAction where supplierid=@newSupplierId
			--delete from  supplierproperty where supplierid=@newSupplierId and propertyId in (112,113,114,115,116,117,118,119,120,121,122) and propertyId not in (select item from dbo.split(@questionIds, '|'))
			print 'SupplierGovernAction is done'

			----SupplierInsurance
			exec [CopySupplierInsurance] @supplierId, @newSupplierId, @changeUser
			print 'SupplierInsurance is done'

			----SupplierInsuranceClaim
			exec [CopySupplierInsuranceClaim] @supplierId, @newSupplierId, @changeUser
			--if not exists(select * from SupplierInsuranceClaim where supplierid=@newSupplierId and Type='Errors & Omissions') 
			--	delete from supplierproperty where supplierid=@newSupplierId and propertyid = 97
			print 'SupplierInsuranceClaim is done'

			----SupplierLawAction	
			exec [CopySupplierLawAction] @supplierId, @newSupplierId, @changeUser

			--set @questionIds=''
			--select @questionIds = @questionIds + '|' + QuestionIds from SupplierLawAction where supplierid=@newSupplierId and Type='AddLegalAction'
			--delete from  supplierproperty where supplierid=@newSupplierId and propertyId in (126,127,128,129,130,131,132, 133, 134, 135, 136) and propertyId not in (select item from dbo.split(@questionIds, '|'))
			
			--set @questionIds=''
			--select @questionIds = @questionIds + '|' + QuestionIds from SupplierLawAction where supplierid=@newSupplierId and Type='AddInvestigation'
			--delete from  supplierproperty where supplierid=@newSupplierId and propertyId in (137, 138, 139, 140, 141) and propertyId not in (select item from dbo.split(@questionIds, '|'))
			
			--if not exists(select * from SupplierBusinessMixedInfo where supplierid=@newSupplierId and Type='AddViolation')
			--	delete from supplierproperty where supplierid=@newSupplierId and propertyid = 142
			print 'SupplierLawAction is done'

			----SupplierLawsuit
			exec [CopySupplierLawsuit] @supplierId, @newSupplierId, @changeUser
			--set @questionIds=''
			--select @questionIds = @questionIds + '|' + QuestionIds from SupplierLawsuit where supplierid=@newSupplierId
			--delete from  supplierproperty where supplierid=@newSupplierId and propertyId in (123,124,125) and propertyId not in (select item from dbo.split(@questionIds, '|'))
			print 'SupplierLawsuit is done'	

			----SupplierNaicsCode
			exec [CopySupplierNaicsCode] @supplierId, @newSupplierId, @changeUser
			print 'SupplierNaicsCode is done'

			----SupplierPayment
			exec [CopySupplierPayment] @supplierId, @newSupplierId, @changeUser
			--set @questionIds=''
			--select @questionIds = @questionIds + '|' + QuestionIds from SupplierPayment where supplierid=@newSupplierId
			--delete from  supplierproperty where supplierid=@newSupplierId and propertyId in (104,105) and propertyId not in (select item from dbo.split(@questionIds, '|'))
			print 'SupplierPayment is done'	

			----SupplierPersonnelGovernmentAgency
			exec [CopySupplierPersonnelGovernmentAgency] @supplierId, @newSupplierId, @changeUser
			--if not exists(select * from SupplierPersonnelGovernmentAgency where supplierid=@newSupplierId) 
			--	delete from supplierproperty where supplierid=@newSupplierId and propertyid = 111
			print 'SupplierPersonnelGovernmentAgency is done'

			----SupplierPersonnelMixedInfo
			exec [CopySupplierPersonnelMixedInfo] @supplierId, @newSupplierId, @changeUser
			--if exists(select * from SupplierPersonnelMixedInfo where supplierid=@newSupplierId and Type='AddOwnOtherFirm')
			--	delete from supplierproperty where supplierid=@newSupplierId and propertyid = 91
			print 'SupplierPersonnelMixedInfo is done'

			----SupplierProject
			exec [CopySupplierProject] @supplierId, @newSupplierId, @changeUser
			print 'SupplierProject is done'

			----SupplierProjectStatistics
			--exec [CopySupplierProjectStatistics] @supplierId, @newSupplierId, @changeUser
			--print 'SupplierProjectStatistics is done'

			----SupplierSales
			--exec [CopySupplierSales] @supplierId, @newSupplierId, @changeUser
			--print 'SupplierSales is done'

			----SupplierOSHAStatistics
			--exec [CopySupplierOSHAStatistics] @supplierId, @newSupplierId, @changeUser
			--print 'SupplierOSHAStatistics is done'

			----SupplierServiceArea
			exec [CopySupplierServiceArea] @supplierId, @newSupplierId, @changeUser
			print 'SupplierServiceArea is done'

			----SupplierSicCode
			exec [CopySupplierSicCode] @supplierId, @newSupplierId, @changeUser
			print 'SupplierSicCode is done'

			----SupplierSurety
			exec [CopySupplierSurety] @supplierId, @newSupplierId, @changeUser
			print 'SupplierSurety is done'

			----SupplierUnethicalPractice
			exec [CopySupplierUnethicalPractice] @supplierId, @newSupplierId, @changeUser
			--set @questionIds=''
			--select @questionIds = @questionIds + '|' + QuestionIds from SupplierUnethicalPractice where supplierid=@newSupplierId
			--delete from  supplierproperty where supplierid=@newSupplierId and propertyId in (143,144,145, 146,147,148,149,150,151,152) and propertyId not in (select item from dbo.split(@questionIds, '|'))
			print 'SupplierUnethicalPractice is done'

--			--SupplierStaticQualification
--			exec [CopySupplierStaticQualification] @supplierId, @newSupplierId, @changeUser
--
--			--SupplierStaticCertification
--			exec [CopySupplierStaticCertification] @supplierId, @newSupplierId, @changeUser
			
-- was commented to here

			-----------------------
			---SupplierVersion-----
			-----------------------
			-- create new version
			insert SupplierVersion (SupplierId, VersionId, Status, IsLocked, ChangeDate)
			values (@newSupplierId, @versionId, 1, 'N', getdate())

			update vendor set currentsupplierid=@newSupplierId where federalId = 
				(select federalId from supplier where id=@supplierId)

			print 'commit'
			Commit Transaction 
			return @newSupplierId  
			
		end try

		begin catch

			print ERROR_MESSAGE() 
			RollBack Transaction
			return 0

		end catch

	end

if @type='Post'
	begin
--		declare @transferredFlag int
--		select @transferredFlag = transferredflag from supplierworkflow 
--			where supplierId= (select versionId from supplierversion where supplierId = @supplierId)
--				and workflowType='Supplier Certification'
--
--		update supplierworkflow set transferredFlag = @transferredFlag 
--			where supplierId = @supplierId
--				and workflowType='Supplier Certification'

		-- Requal and Recert Status by [Frank]
		declare @status int
		set @status = 0

		if exists ( select * from supplier s, supplierversion sv 
			where s.Id = sv.supplierId and s.Id != @supplierId
				and CertifiedDate is not null
				and versionId in (select versionId from supplierversion where supplierId = @supplierId)
			)
			begin
				set @status = 1
			end


		if exists ( select * from supplier s, supplierversion sv 
			where s.Id = sv.supplierId and s.Id != @supplierId
				and QualifiedDate is not null
				and versionId in (select versionId from supplierversion where supplierId = @supplierId)
			)
			begin
				set @status = @status + 2
			end
	


		update supplier set status = @status where id = @supplierId
		----

		return @supplierId
	end
end

