﻿/*
*********************************************************************************************************************
Procedure:	SupplierCESReport
Purpose:	Supplier CES Report.
---------------------------------------------------------------------------------------------------------------------
Date			Developer				Notes
==========		===================		===============================
08/28/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DisqualifiedReport]
as
set nocount on

select
	s.Id,
	s.Company,
	replace(isnull(sa.AddressLine1, ''), '|', ' ') + ' ' + replace(isnull(sa.AddressLine2, ''), '|', ' ') as AddressLine1, 
	isnull(sa.city, '') + ', ' + ISNULL(sa.State, '') + ' ' + ISNULL(sa.ZipCode, '') + ', ' + ISNULL(sa.country, '') as AddressLine2,
	isnull(vc.name, '') as ContactName,
	ISNULL(s.Phone, '') as Phone,
	ISNULL(s.fax, '') as Fax
from
	(select * from vendor where qualificationstatus in ('Disqualified', 'Suspended')) v
left join
	(select * from VendorContact where ContactType='Primary') vc
on
	v.Id = vc.vendorId
left join
	Supplier s
on
	v.QualifiedSupplierId = s.Id	
left join
	(select * from SupplierAddress where Addresstype='PHYSICAL') sa
on
	s.Id = sa.SupplierId
	


	
	

	


	
	
	


