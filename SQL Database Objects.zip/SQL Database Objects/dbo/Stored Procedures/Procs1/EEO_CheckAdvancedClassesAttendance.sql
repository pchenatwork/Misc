﻿
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE Procedure [dbo].[EEO_CheckAdvancedClassesAttendance]
	-- Add the parameters for the stored procedure here
	@vendorId int
AS
BEGIN

	declare @count int

		set @count =(
				select count(*)
				from	EEO_VENDOR_CLASSES ec, eeo_classes e
				where	ec.C_CLASS_ID=e.C_CLASS_ID
					and	e.C_CLASS_TYPE=4
					and	ec.VENDORID=@vendorId
					and ec.C_ATTENDED is not null

	)

		select @count
	return @count


end
