﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierDisadvantagedEmployee
Purpose:	Delete a row from SupplierDisadvantagedEmployee table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/19/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE  procedure DeleteSupplierDisadvantagedEmployee
	@id int
as

delete SupplierDisadvantagedEmployee
where Id = @id
return @@RowCount

