﻿/*
*********************************************************************************************************************
Procedure:	DeleteScorecardAttachment
Purpose:	Delete a row from ScorecardAttachment table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
01/17/2008		Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteScorecardAttachment]
	@id int
as
delete ScorecardAttachment
where Id = @id
return @@RowCount


