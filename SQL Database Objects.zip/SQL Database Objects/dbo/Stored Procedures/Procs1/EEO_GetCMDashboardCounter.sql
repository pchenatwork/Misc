﻿
/*
*********************************************************************************************************************
Procedure:	 
Purpose:	 
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
09/11/2015		Syed			    Created
*********************************************************************************************************************
*/
CREATE PROCEDURE [dbo].[EEO_GetCMDashboardCounter]
(
    @mentorType varchar(30),
    @completionStartInterval int,
    @completionEndInterval int,
    @ret int OUTPUT
)
AS

Begin

    declare @tableVar table
    (
        Id int,
        PeriodId decimal(5,0),
        Vendorid int,
        Period_StartDate Datetime,
        Period_EndDate Datetime,
        Completion_StartDate Datetime,
        Completion_EndDate Datetime
    )

	  
    
    Insert into @tableVar
       exec  dbo.EEO_GetCMVendors @mentorType , @completionStartInterval , @completionEndInterval 



    
    SELECT @ret = Count(*)FROM @tableVar
    IF (@ret IS NULL) 
        SET @ret = 0;
        
                                             
                                      
    
END
