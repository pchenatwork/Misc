﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierVettingResponseAttachment
Purpose:	Delete attachment from SupplierVettingResponse table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
12/08/2007		AECSOFT\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSupplierVettingResponseAttachment]
	@id int
as
Update SupplierVettingResponse
	Set AttachmentId = null,
	AttachmentName = null
where Id = @id
return @@RowCount


