﻿

/*
*********************************************************************************************************************
Procedure:	 
Purpose:	 
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/10/2015		Pasha				Created
*********************************************************************************************************************
*/
CREATE PROCEDURE [dbo].[EEO_GetMentorAnnualBidCeiling]
AS

Begin

select distinct vendorid
from eeo_matrix 
where intv_Completed =1 
and isnull(BIDCEILING_DOC_UPLOADED,0)=1
and isnull(BIDCEILING_AMOUNT,0)=0
END
