﻿



Create procedure DeleteWorkflowNodeUser
	@id int
as

delete WorkflowNodeUser
where Id = @id
return @@RowCount





