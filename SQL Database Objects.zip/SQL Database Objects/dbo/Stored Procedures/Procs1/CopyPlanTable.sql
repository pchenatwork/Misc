﻿CREATE procedure [dbo].[CopyPlanTable]	
	@id int, 
	@changeUser nvarchar(50)
as
begin
	insert [Plan]
		(
			PlanId,
			Type,
			ProjectId,
			ContractId,
			SolicitSeq,
			SolicitNo,
			ContractNo,
			MeContractNo,
			Description,
			Comments,
			EEOContactName,
			EEOContactPhone,
			EEOContactEmail,
			SubcontPercentage,
			MWLBEGoal,
			RevisedMWLBEGoal,
			WaiverPercentage,
			RevisedPercentage,
			PlanApprovalDate,
			IsWaiver,
			ProjectDuration,
			AwardDate,
			ChangeUser,
			ChangeDate
		)
	select 
			NEWID(),
			'Verification',
			ProjectId,
			ContractId,
			SolicitSeq,
			SolicitNo,
			ContractNo,
			MeContractNo,
			Description,
			Comments,
			EEOContactName,
			EEOContactPhone,
			EEOContactEmail,
			SubcontPercentage,
			MWLBEGoal,
			RevisedMWLBEGoal,
			WaiverPercentage,
			RevisedPercentage,
			PlanApprovalDate,
			IsWaiver,
			ProjectDuration,
			AwardDate,
			@changeUser,
			GETDATE()
	from
		[Plan]
	where
		Id=@id
	
	return @@identity
end



 


