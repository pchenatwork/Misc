﻿/*
*********************************************************************************************************************
Procedure:	DeleteVettingList
Purpose:	Delete a row from VettingList table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/31/2007		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteVettingList]
	@id int
as

Begin Transaction

Delete VettingAnswer Where QuestionId in ( Select Id From VettingQuestion Where VettingId = @id ) 

Delete VettingAttachment Where VettingQuestionId in ( Select Id From VettingQuestion Where VettingId = @id ) 

Delete VettingQuestion Where VettingId = @id

Delete VettingInGroup Where VettingId = @id

Delete VettingList where Id = @id

if @@error = 0
	Commit Transaction
else
	RollBack Transaction

return @@RowCount


