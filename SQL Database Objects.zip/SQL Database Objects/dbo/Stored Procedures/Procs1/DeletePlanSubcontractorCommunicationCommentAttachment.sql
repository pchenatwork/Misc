﻿CREATE procedure [dbo].[DeletePlanSubcontractorCommunicationCommentAttachment] 
	@id int
AS

Update PlanSubcontractorCommunicationComment
Set FileName = null,
	AttachmentId = null
Where Id = @id
return @@rowcount
