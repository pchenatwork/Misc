﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectTransaction
Purpose:	Delete a row from ProjectTransaction table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
5/21/2010		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteProjectTransaction
	@id int
as

delete ProjectTransaction
where Id = @id
return @@RowCount

