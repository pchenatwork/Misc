﻿/*
*********************************************************************************************************************
Procedure:	CopyEmailMessage
Purpose:	Copy existing msg  into EmailMessage table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/02/2005 		Lily Xiong		Created
*********************************************************************************************************************
*/
CREATE procedure CopyEmailMessage
	@id int
	
as
begin
	insert into EmailMessage
	(
		Name,
		Type,
		Description,
		FromEmail,
		FromName,
		ToEmail,
		ToName,
		CcEmail,
		BccEmail,
		Subject,
		Body,
		Objects,
		Roles
	)
	select name + '_Copy', 
		Type,
		Description,
		FromEmail,
		FromName,
		ToEmail,
		ToName,
		CcEmail,
		BccEmail,
		Subject,
		Body,
		Objects,
		Roles
	from EmailMessage
	Where id = @id
end
return  @@identity



