﻿/*
*********************************************************************************************************************
Procedure:	DeleteScorecardAnswer
Purpose:	Delete a row from ScorecardAnswer table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/4/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteScorecardAnswer
	@id int
as

delete ScorecardAnswer
where Id = @id
return @@RowCount

