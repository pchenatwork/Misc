﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierDocumentHistory
Purpose:	Delete a row from SupplierDocumentHistory table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/29/2009		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierDocumentHistory
	@id int
as

delete SupplierDocumentHistory
where Id = @id
return @@RowCount

