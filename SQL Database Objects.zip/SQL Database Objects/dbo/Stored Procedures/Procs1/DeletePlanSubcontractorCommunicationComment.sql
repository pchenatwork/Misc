﻿/*
*********************************************************************************************************************
Procedure:	DeletePlanComment
Purpose:	Delete a row from PlanComment table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
12/15/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
create procedure [dbo].[DeletePlanSubcontractorCommunicationComment]
	@id int
as

delete PlanSubcontractorCommunicationComment
where Id = @id
return @@RowCount

