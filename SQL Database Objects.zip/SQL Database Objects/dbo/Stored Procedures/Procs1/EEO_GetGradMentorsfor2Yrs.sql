﻿CREATE PROC [dbo].[EEO_GetGradMentorsfor2Yrs]
As

select 
	e.SD_EXT_GRAD_DATE,e.sd_grad_date, ev.* 
from 
	EEO_MENTOR_GRAD_DETAIL e,eeo_vendor ev,eeo_workflowhistory eh
where 
	--DATEADD(YEAR,2,e.SD_START_DATE)	>getdate() 
	isnull(SD_EXT_GRAD_DATE,sd_grad_date) >getdate() and isnull(SD_EXT_GRAD_DATE,sd_grad_date)<GETDATE()+60 --and  isnull(SD_EXT_GRAD_DATE,sd_grad_date)>GETDATE() 
and e.C_MENTOR_TYPE='GRAD MENTOR'
and e.SD_ACTUAL_GRAD_DT is null
and (e.SD_END is null or e.sd_end>getdate())
and e.VENDORID=ev.VendorId
and ev.TransactionId=eh.TransactionId
and eh.WorkFlowId<>21
--As per the BRD to be eligible for Graduation, vendor needs to complete all the required classes
and exists (select * 
			from 
				eeo_vendor_classes ev, eeo_classes ec 
			where 
				ev.vendorid=e.VENDORID 
				and ev.C_CLASS_ID=ec.C_CLASS_ID 
				and ec.C_CLASS_TYPE=5 
				and (isnull(ev.C_ATTENDED,'N')='Y' or REVIEWED=1)
			)

--select * from EEO_classes order by c_class_name
