﻿









CREATE procedure [dbo].[CreateCMSReconciliationReport]
as
begin

--????M_EXPER_FROM, M_EXPER_TO
--????NumberOfYears char(2)?
--????M_AVERAGE_SALES
--????License Table
	begin transaction
	begin try
		declare @tempCurrentVendor table
		(
			SupplierId int,
			VersionId int
		)

		insert into @tempCurrentVendor
		(
			SupplierId,
			VersionId
		)
		select supplierId, versionid from supplierversion where status=1


if exists(select name from sysobjects where name='cms_report_vendor' and type='U')
	drop table dbo.cms_report_vendor 
if exists(select name from sysobjects where name='cms_report_vendor_detail' and type='U')
	drop table dbo.cms_report_vendor_detail
if exists(select name from sysobjects where name='cms_report_prime_apprent' and type='U')
	drop table dbo.cms_report_prime_apprent 
if exists(select name from sysobjects where name='cms_report_yearly_sales' and type='U')
	drop table dbo.cms_report_yearly_sales 
if exists(select name from sysobjects where name='cms_report_vendor_trade' and type='U')
	drop table dbo.cms_report_vendor_trade 
if exists(select name from sysobjects where name='cms_report_prequal_hist' and type='U')
	drop table dbo.cms_report_prequal_hist 
if exists(select name from sysobjects where name='cms_report_vendor_disqual' and type='U')
	drop table dbo.cms_report_vendor_disqual 
if exists(select name from sysobjects where name='cms_report_eeo_master' and type='U')
	drop table dbo.cms_report_eeo_master  
if exists(select name from sysobjects where name='cms_report_eeo_detail' and type='U')
	drop table dbo.cms_report_eeo_detail 
if exists(select name from sysobjects where name='cms_report_eeo_detail_recert' and type='U')
	drop table dbo.cms_report_eeo_detail_recert 
if exists(select name from sysobjects where name='cms_report_vendor_solicitation' and type='U')
	drop table dbo.cms_report_vendor_solicitation 
if exists(select name from sysobjects where name='cms_report_vendor_verification' and type='U')
	drop table dbo.cms_report_vendor_verification 

--	
select * into dbo.cms_report_vendor from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Vendor')
select * into dbo.cms_report_vendor_detail from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM vendor_detail')
select * into dbo.cms_report_prime_apprent from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Prime_apprent')
select * into dbo.cms_report_yearly_sales from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM yearly_sales')
select * into dbo.cms_report_vendor_trade from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM vendor_trade')
select * into dbo.cms_report_prequal_hist from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM prequal_hist')
select * into dbo.cms_report_vendor_disqual from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM vendor_disqual')

select 
	c_vendor_id,
	c_race,
	c_bonding_co, 
	vc_mentor_notes,
	m_average_sales,
	VASID 
into  dbo.cms_report_eeo_master from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM eeo_master')
select * into dbo.cms_report_eeo_detail from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM eeo_detail')
select * into dbo.cms_report_eeo_detail_recert from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM eeo_detail_recert')
select * into dbo.cms_report_vendor_solicitation from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM vendor_solicitation')
select * into dbo.cms_report_vendor_verification from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM vendor_verification')


--
delete from CMSReConciliationReport

---------------------
----Prequal_hist-----
---------------------

		--C_VENDOR_ID
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_c_vendor_id',
			s.federalId,
			'PREQUAL_HIST',
			'C_VENDOR_ID',
			v.c_vendor_id,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			Supplier s
		on
			s.Id = s1.supplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_c_vendor_id' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_c_vendor_id' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--m_max_single_bond
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_m_max_single_bond',
			convert(decimal(18,2), s1.V_m_max_single_bond),
			'PREQUAL_HIST',
			'm_max_single_bond',
			v.m_max_single_bond,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_m_max_single_bond' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_m_max_single_bond' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId
		


		--m_max_bond
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_m_max_bond',
			convert(decimal(18,2), s1.V_m_max_bond),
			'PREQUAL_HIST',
			'm_max_bond',
			v.m_max_bond,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_m_max_single_bond' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_m_max_bond' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_PREQ_RCVD
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_PREQ_RCVD',
			case s1.V_SD_PREQ_RCVD
			when '1900/1/1' then null
			else s1.V_SD_PREQ_RCVD
			end,
			'PREQUAL_HIST',
			'SD_PREQ_RCVD',
			case v.SD_PREQ_RCVD
			when '1900/1/1' then null
			else v.SD_PREQ_RCVD
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_PREQ_RCVD' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_PREQ_RCVD' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_ADDL_SENT
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_ADDL_SENT',
			case s1.V_SD_ADDL_SENT
			when '1900/1/1' then null
			else s1.V_SD_ADDL_SENT
			end,
			'PREQUAL_HIST',
			'SD_ADDL_SENT',
			case v.SD_ADDL_SENT
			when '1900/1/1' then null
			else v.SD_ADDL_SENT
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_ADDL_SENT' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_ADDL_SENT' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_ADDL_SENT2
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_ADDL_SENT2',
			case s1.V_SD_ADDL_SENT2
			when '1900/1/1' then null
			else s1.V_SD_ADDL_SENT2
			end,
			'PREQUAL_HIST',
			'SD_ADDL_SENT2',
			case v.SD_ADDL_SENT2
			when '1900/1/1' then null
			else v.SD_ADDL_SENT2
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_ADDL_SENT2' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_ADDL_SENT2' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_ADDL_RCVD
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_ADDL_RCVD',
			case s1.V_SD_ADDL_RCVD
			when '1900/1/1' then null
			else s1.V_SD_ADDL_RCVD
			end,
			'PREQUAL_HIST',
			'SD_ADDL_RCVD',
			case v.SD_ADDL_RCVD
			when '1900/1/1' then null
			else v.SD_ADDL_RCVD
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_ADDL_RCVD' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_ADDL_RCVD' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_ADDL_RCVD2
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_ADDL_RCVD2',
			case s1.V_SD_ADDL_RCVD2
			when '1900/1/1' then null
			else s1.V_SD_ADDL_RCVD2
			end,
			'PREQUAL_HIST',
			'SD_ADDL_RCVD2',
			case v.SD_ADDL_RCVD2
			when '1900/1/1' then null
			else v.SD_ADDL_RCVD2
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_ADDL_RCVD2' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_ADDL_RCVD2' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_SENT_IG
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_SENT_IG',
			case s1.V_SD_SENT_IG
			when '1900/1/1' then null
			else s1.V_SD_SENT_IG
			end,
			'PREQUAL_HIST',
			'SD_SENT_IG',
			case v.SD_SENT_IG
			when '1900/1/1' then null
			else v.SD_SENT_IG
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_SENT_IG' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_SENT_IG' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--SD_APPR_IG
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_APPR_IG',
			case s1.V_SD_APPR_IG
			when '1900/1/1' then null
			else s1.V_SD_APPR_IG
			end,
			'PREQUAL_HIST',
			'SD_APPR_IG',
			case v.SD_APPR_IG
			when '1900/1/1' then null
			else v.SD_APPR_IG
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_APPR_IG' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_APPR_IG' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_PREQUAL_FROM
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_PREQUAL_FROM',
			case s1.V_SD_PREQUAL_FROM
			when '1900/1/1' then null
			else s1.V_SD_PREQUAL_FROM
			end,
			'PREQUAL_HIST',
			'SD_PREQUAL_FROM',
			case v.SD_PREQUAL_FROM
			when '1900/1/1' then null
			else v.SD_PREQUAL_FROM
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_PREQUAL_FROM' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_PREQUAL_FROM' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_PREQUAL_TO
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_PREQUAL_TO',
			case s1.V_SD_PREQUAL_TO
			when '1900/1/1' then null
			else s1.V_SD_PREQUAL_TO
			end,
			'PREQUAL_HIST',
			'SD_PREQUAL_TO',
			case v.SD_PREQUAL_TO
			when '1900/1/1' then null
			else v.SD_PREQUAL_TO
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_PREQUAL_TO' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_PREQUAL_TO' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_REF_CHECK
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_REF_CHECK',
			case s1.V_SD_REF_CHECK
			when '1900/1/1' then null
			else s1.V_SD_REF_CHECK
			end,
			'PREQUAL_HIST',
			'SD_REF_CHECK',
			case v.SD_REF_CHECK
			when '1900/1/1' then null
			else v.SD_REF_CHECK
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_REF_CHECK' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_REF_CHECK' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--C_APPR_IG
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_C_APPR_IG',
			V_C_APPR_IG,
			'PREQUAL_HIST',
			'C_APPR_IG',
			v.C_APPR_IG,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_C_APPR_IG' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_C_APPR_IG' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_FINANCE_CHECK
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_FINANCE_CHECK',			
			case s1.V_SD_FINANCE_CHECK
			when '1900/1/1' then null
			else s1.V_SD_FINANCE_CHECK
			end,
			'PREQUAL_HIST',
			'SD_FINANCE_CHECK',
			case v.SD_FINANCE_CHECK
			when '1900/1/1' then null
			else v.SD_FINANCE_CHECK
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_FINANCE_CHECK' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_FINANCE_CHECK' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--M_EXP_RANGE_1
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_M_EXP_RANGE_1',
			case
			when s1.V_M_EXP_RANGE_1 is null then '0.00'
			else convert(decimal(18,2), s1.V_M_EXP_RANGE_1)
			end,
			'PREQUAL_HIST',
			'M_EXP_RANGE_1',
			case
			when v.M_EXP_RANGE_1 is null then '0.00'
			else v.M_EXP_RANGE_1
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_M_EXP_RANGE_1' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_M_EXP_RANGE_1' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId
		
		--M_EXP_RANGE_2
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_M_EXP_RANGE_2',
			case
			when s1.V_M_EXP_RANGE_2 is null then '0.00'
			else convert(decimal(18,2), s1.V_M_EXP_RANGE_2)
			end,
			'PREQUAL_HIST',
			'M_EXP_RANGE_2',
			case
			when v.M_EXP_RANGE_2 is null then '0.00'
			else v.M_EXP_RANGE_2
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_M_EXP_RANGE_2' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_M_EXP_RANGE_2' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--m_ceiling_amt
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_m_ceiling_amt',
			convert(decimal(18,2), s1.V_m_ceiling_amt),
			'PREQUAL_HIST',
			'm_ceiling_amt',
			v.m_ceiling_amt,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_m_ceiling_amt' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_m_ceiling_amt' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--c_adm_closed
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_c_adm_closed',
			s1.V_c_adm_closed,
			'PREQUAL_HIST',
			'c_adm_closed',
			v.c_adm_closed,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_c_adm_closed' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_c_adm_closed' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_DB_CHECK
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_DB_CHECK',			
			case s1.V_SD_DB_CHECK
			when '1900/1/1' then null
			else s1.V_SD_DB_CHECK
			end,
			'PREQUAL_HIST',
			'SD_DB_CHECK',
			case v.SD_DB_CHECK
			when '1900/1/1' then null
			else v.SD_DB_CHECK
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_DB_CHECK' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_DB_CHECK' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_NOTICE_LTR
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_NOTICE_LTR',
			case s1.V_SD_NOTICE_LTR
			when '1900/1/1' then null
			else s1.V_SD_NOTICE_LTR
			end,
			'PREQUAL_HIST',
			'SD_NOTICE_LTR',
			case v.SD_NOTICE_LTR
			when '1900/1/1' then null
			else v.SD_NOTICE_LTR
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_NOTICE_LTR' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_NOTICE_LTR' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_EMAIL_SENT
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_EMAIL_SENT',
			case s1.V_SD_EMAIL_SENT
			when '1900/1/1' then null
			else s1.V_SD_EMAIL_SENT
			end,
			'PREQUAL_HIST',
			'SD_EMAIL_SENT',
			case v.SD_EMAIL_SENT
			when '1900/1/1' then null
			else v.SD_EMAIL_SENT
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_EMAIL_SENT' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_EMAIL_SENT' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_FIN_STATEMENT
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_FIN_STATEMENT',
			case s1.V_SD_FIN_STATEMENT
			when '1900/1/1' then null
			else s1.V_SD_FIN_STATEMENT
			end,
			'PREQUAL_HIST',
			'SD_FIN_STATEMENT',
			case v.SD_FIN_STATEMENT
			when '1900/1/1' then null
			else v.SD_FIN_STATEMENT
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_FIN_STATEMENT' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_FIN_STATEMENT' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--C_APPR_apprent_program
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_C_APPR_apprent_program',
			s1.V_C_APPR_apprent_program,
			'PREQUAL_HIST',
			'C_APPR_apprent_program',
			v.C_APPR_apprent_program,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_C_APPR_apprent_program' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_C_APPR_apprent_program' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--c_appl_withdrawn
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_c_appl_withdrawn',
			s1.V_c_appl_withdrawn,
			'PREQUAL_HIST',
			'c_appl_withdrawn',
			v.c_appl_withdrawn,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_C_APPR_apprent_program' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_C_APPR_apprent_program' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--cd_action_date
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_cd_action_date',
			case s1.V_cd_action_date
			when '1900/1/1' then null
			else s1.V_cd_action_date
			end,
			'PREQUAL_HIST',
			'cd_action_date',
			case v.cd_action_date
			when '1900/1/1' then null
			else v.cd_action_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_cd_action_date' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_cd_action_date' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_VENDEX_CHECK
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_SD_VENDEX_CHECK',
			case s1.V_SD_VENDEX_CHECK
			when '1900/1/1' then null
			else s1.V_SD_VENDEX_CHECK
			end,
			'PREQUAL_HIST',
			'SD_VENDEX_CHECK',
			case v.SD_VENDEX_CHECK
			when '1900/1/1' then null
			else v.SD_VENDEX_CHECK
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_SD_VENDEX_CHECK' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_SD_VENDEX_CHECK' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--C_FINANCE_APPR
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_C_FINANCE_APPR',
			s1.V_C_FINANCE_APPR,
			'PREQUAL_HIST',
			'C_FINANCE_APPR',
			v.C_FINANCE_APPR,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_C_FINANCE_APPR' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_C_FINANCE_APPR' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--b_predenied
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_b_predenied',
			s1.V_b_predenied,
			'PREQUAL_HIST',
			'b_predenied',
			v.b_predenied,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_b_predenied' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_b_predenied' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--cd_reopen_date
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_cd_reopen_date',
			case s1.V_cd_reopen_date
			when '1900/1/1' then null
			else s1.V_cd_reopen_date
			end,
			'PREQUAL_HIST',
			'cd_reopen_date',
			case v.cd_reopen_date
			when '1900/1/1' then null
			else v.cd_reopen_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_cd_reopen_date' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_cd_reopen_date' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--C_VENDEX_APPR
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_C_VENDEX_APPR',
			s1.V_C_VENDEX_APPR,
			'PREQUAL_HIST',
			'C_VENDEX_APPR',
			v.C_VENDEX_APPR,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_C_VENDEX_APPR' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_C_VENDEX_APPR' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--b_denied
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticQualification',
			'V_b_denied',
			s1.V_b_denied,
			'PREQUAL_HIST',
			'b_denied',
			v.b_denied,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticQualification where transferredFlag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_prequal_hist v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticQualification' 
				and fieldname='V_b_denied' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticQualification' 
										and a2.fieldname='V_b_denied' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


---------------------------------------------
----eeo_detail, eoo_detail_recert-----
--------------------------------------

		--C_VENDOR_ID
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_c_vendor_id',
			s.federalId,
			'EEO_DETAIL',
			'C_VENDOR_ID',
			v.c_vendor_id,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			Supplier s
		on
			s1.supplierId = s.Id
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_c_vendor_id' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_c_vendor_id' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	
		
		union all

		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification_Recert',
			'V_c_vendor_id',
			s.federalId,
			'EEO_DETAIL_RECERT',
			'C_VENDOR_ID',
			v.c_vendor_id,
			a.ProcessedStatus, s1.changeDate,
			s1.recerttransferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where recerttransferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			Supplier s
		on
			s1.supplierid = s.Id
		left join
			cms_report_eeo_detail_recert v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification_Recert' 
				and fieldname='V_c_vendor_id' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification_Recert' 
										and a2.fieldname='V_c_vendor_id' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	


		--C_EEO_TYPE
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_C_EEO_TYPE',
			s1.V_C_EEO_TYPE,
			'EEO_DETAIL',
			'C_EEO_TYPE',
			v.C_EEO_TYPE,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_C_EEO_TYPE' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_C_EEO_TYPE' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	


		union all

		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification_Recert',
			'V_C_EEO_TYPE',
			s1.V_C_EEO_TYPE,
			'EEO_DETAIL_RECERT',
			'C_EEO_TYPE',
			v.C_EEO_TYPE,
			a.ProcessedStatus, s1.changeDate,
			s1.recerttransferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where recerttransferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail_recert v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification_Recert' 
				and fieldname='V_C_EEO_TYPE' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification_Recert' 
										and a2.fieldname='V_C_EEO_TYPE' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		--SD_APPL_DATE
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_SD_APPL_DATE',
			case s1.V_SD_APPL_DATE
			when '1900/1/1' then null
			else s1.V_SD_APPL_DATE
			end,
			'EEO_DETAIL',
			'SD_APPL_DATE',
			case v.SD_APPL_DATE
			when '1900/1/1' then null
			else v.SD_APPL_DATE
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_SD_APPL_DATE' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_SD_APPL_DATE' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId
	
		union all

		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification_Recert',
			'V_SD_APPL_DATE',
			case s1.V_SD_APPL_DATE
			when '1900/1/1' then null
			else s1.V_SD_APPL_DATE
			end,
			'EEO_DETAIL_RECERT',
			'SD_APPL_DATE',
			case v.SD_APPL_DATE
			when '1900/1/1' then null
			else v.SD_APPL_DATE
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.recerttransferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where recerttransferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail_recert v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification_Recert' 
				and fieldname='V_SD_APPL_DATE' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification_Recert' 
										and a2.fieldname='V_SD_APPL_DATE' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--c_dw_code
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_c_dw_code',
			s1.V_c_dw_code,
			'EEO_DETAIL',
			'c_dw_code',
			v.c_dw_code,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_c_dw_code' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_c_dw_code' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId
	
		union all

		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification_Recert',
			'V_c_dw_code',
			s1.V_c_dw_code,
			'EEO_DETAIL_RECERT',
			'c_dw_code',
			v.c_dw_code,
			a.ProcessedStatus, s1.changeDate,
			s1.recerttransferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where recerttransferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail_recert v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification_Recert' 
				and fieldname='V_c_dw_code' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification_Recert' 
										and a2.fieldname='V_c_dw_code' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId
		

		--c_completed
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_c_completed',
			case 
			when s1.V_c_dw_code in ('A', 'I', 'P', 'Y', 'R') then 'N'
			else 'Y'
			end,
			'EEO_DETAIL',
			'c_completed',
			v.c_completed,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_c_completed' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_c_completed' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId		


		--sd_dw_date
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_sd_dw_date',
			case s1.V_sd_dw_date
			when '1900/1/1' then null
			else s1.V_sd_dw_date
			end,
			'EEO_DETAIL',
			'sd_dw_date',
			case v.sd_dw_date
			when '1900/1/1' then null
			else v.sd_dw_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_sd_dw_date' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_sd_dw_date' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	
		
		union all

		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification_Recert',
			'V_sd_dw_date',
			case s1.V_sd_dw_date
			when '1900/1/1' then null
			else s1.V_sd_dw_date
			end,
			'EEO_DETAIL_RECERT',
			'sd_dw_date',
			case v.sd_dw_date
			when '1900/1/1' then null
			else v.sd_dw_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.recerttransferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where recerttransferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail_recert v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification_Recert' 
				and fieldname='V_sd_dw_date' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification_Recert' 
										and a2.fieldname='V_sd_dw_date' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		--vc_dw_note
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_vc_dw_note',
			s1.V_vc_dw_note,
			'EEO_DETAIL',
			'vc_dw_note',
			v.vc_dw_note,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_vc_dw_note' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_vc_dw_note' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	
	
		union all

		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification_Recert',
			'V_vc_dw_note',
			s1.V_vc_dw_note,
			'EEO_DETAIL_RECERT',
			'vc_dw_note',
			v.vc_dw_note,
			a.ProcessedStatus, s1.changeDate,
			s1.recerttransferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where recerttransferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail_recert v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification_Recert' 
				and fieldname='V_vc_dw_note' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification_Recert' 
										and a2.fieldname='V_vc_dw_note' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		--sd_recert_notice_send
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_sd_recert_notice_send',
			case s1.V_sd_recert_notice_send
			when '1900/1/1' then null
			else s1.V_sd_recert_notice_send
			end,
			'EEO_DETAIL',
			'sd_recert_notice_send',
			case v.sd_recert_notice_send
			when '1900/1/1' then null
			else v.sd_recert_notice_send
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()

		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_sd_recert_notice_send' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_sd_recert_notice_send' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	


		--sd_info_letter_sent_1
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_sd_info_letter_sent_1',
			case s1.V_sd_info_letter_sent_1
			when '1900/1/1' then null
			else s1.V_sd_info_letter_sent_1
			end,
			'EEO_DETAIL',
			'sd_info_letter_sent_1',
			case v.sd_info_letter_sent_1
			when '1900/1/1' then null
			else v.sd_info_letter_sent_1
			end,			
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_sd_info_letter_sent_1' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_sd_info_letter_sent_1' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		union all

		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification_Recert',
			'V_sd_info_letter_sent_1',
			case s1.V_sd_info_letter_sent_1
			when '1900/1/1' then null
			else s1.V_sd_info_letter_sent_1
			end,
			'EEO_DETAIL_RECERT',
			'sd_info_letter_sent_1',
			case v.sd_info_letter_sent_1
			when '1900/1/1' then null
			else v.sd_info_letter_sent_1
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.recerttransferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where recerttransferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail_recert v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification_Recert' 
				and fieldname='V_sd_info_letter_sent_1' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification_Recert' 
										and a2.fieldname='V_sd_info_letter_sent_1' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	



		--sd_info_letter_received_1
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_sd_info_letter_received_1',
			case s1.V_sd_info_letter_received_1
			when '1900/1/1' then null
			else s1.V_sd_info_letter_received_1
			end,
			'EEO_DETAIL',
			'sd_info_letter_received_1',
			case v.sd_info_letter_received_1
			when '1900/1/1' then null
			else v.sd_info_letter_received_1
			end,			
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_sd_info_letter_received_1' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_sd_info_letter_received_1' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	
	
		union all

		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification_Recert',
			'V_sd_info_letter_received_1',
			case s1.V_sd_info_letter_received_1
			when '1900/1/1' then null
			else s1.V_sd_info_letter_received_1
			end,
			'EEO_DETAIL_RECERT',
			'sd_info_letter_received_1',
			case v.sd_info_letter_received_1
			when '1900/1/1' then null
			else v.sd_info_letter_received_1
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.recerttransferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where recerttransferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail_recert v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification_Recert' 
				and fieldname='V_sd_info_letter_received_1' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification_Recert' 
										and a2.fieldname='V_sd_info_letter_received_1' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		--sd_info_letter_sent_2
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_sd_info_letter_sent_2',
			case s1.V_sd_info_letter_sent_2
			when '1900/1/1' then null
			else s1.V_sd_info_letter_sent_2
			end,
			'EEO_DETAIL',
			'sd_info_letter_sent_2',
			case v.sd_info_letter_sent_2
			when '1900/1/1' then null
			else v.sd_info_letter_sent_2
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_sd_info_letter_sent_2' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_sd_info_letter_sent_2' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	
	
		union all

		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification_Recert',
			'V_sd_info_letter_sent_2',
			case s1.V_sd_info_letter_sent_2
			when '1900/1/1' then null
			else s1.V_sd_info_letter_sent_2
			end,
			'EEO_DETAIL_RECERT',
			'sd_info_letter_sent_2',
			case v.sd_info_letter_sent_2
			when '1900/1/1' then null
			else v.sd_info_letter_sent_2
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.recerttransferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where recerttransferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail_recert v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification_Recert' 
				and fieldname='V_sd_info_letter_sent_2' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification_Recert' 
										and a2.fieldname='V_sd_info_letter_sent_2' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		--sd_info_letter_received_2
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_sd_info_letter_received_2',
			case s1.V_sd_info_letter_received_2
			when '1900/1/1' then null
			else s1.V_sd_info_letter_received_2
			end,
			'EEO_DETAIL',
			'sd_info_letter_received_2',
			case v.sd_info_letter_received_2
			when '1900/1/1' then null
			else v.sd_info_letter_received_2
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_sd_info_letter_received_2' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_sd_info_letter_received_2' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	
	
		union all

		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification_Recert',
			'V_sd_info_letter_received_2',
			case s1.V_sd_info_letter_received_2
			when '1900/1/1' then null
			else s1.V_sd_info_letter_received_2
			end,
			'EEO_DETAIL_RECERT',
			'sd_info_letter_received_2',
			case v.sd_info_letter_received_2
			when '1900/1/1' then null
			else v.sd_info_letter_received_2
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.recerttransferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where recerttransferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail_recert v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification_Recert' 
				and fieldname='V_sd_info_letter_received_2' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification_Recert' 
										and a2.fieldname='V_sd_info_letter_received_2' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		--sd_cert_date
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_sd_cert_date',
			case s1.V_sd_cert_date
			when '1900/1/1' then null
			else s1.V_sd_cert_date
			end,
			'EEO_DETAIL',
			'sd_cert_date',
			case v.sd_cert_date
			when '1900/1/1' then null
			else v.sd_cert_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_sd_cert_date' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_sd_cert_date' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		union all

		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification_Recert',
			'V_sd_cert_date',
			case s1.V_sd_cert_date
			when '1900/1/1' then null
			else s1.V_sd_cert_date
			end,
			'EEO_DETAIL_RECERT',
			'sd_cert_date',
			case v.sd_cert_date
			when '1900/1/1' then null
			else v.sd_cert_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.recerttransferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where recerttransferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail_recert v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification_Recert' 
				and fieldname='V_sd_cert_date' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification_Recert' 
										and a2.fieldname='V_sd_cert_date' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		--sd_recert_date
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_sd_recert_date',
			case s1.V_sd_recert_date
			when '1900/1/1' then null
			else s1.V_sd_recert_date
			end,
			'EEO_DETAIL',
			'sd_recert_date',
			case v.sd_recert_date
			when '1900/1/1' then null
			else v.sd_recert_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_sd_recert_date' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_sd_recert_date' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		union all

		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification_Recert',
			'V_sd_recert_date',
			case s1.V_sd_recert_date
			when '1900/1/1' then null
			else s1.V_sd_recert_date
			end,
			'EEO_DETAIL_RECERT',
			'sd_recert_date',
			case v.sd_recert_date
			when '1900/1/1' then null
			else v.sd_recert_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.recerttransferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where recerttransferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail_recert v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification_Recert' 
				and fieldname='V_sd_recert_date' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification_Recert' 
										and a2.fieldname='V_sd_recert_date' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	


		--sd_exp_date
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification',
			'V_sd_exp_date',
			case s1.V_sd_exp_date
			when '1900/1/1' then null
			else s1.V_sd_exp_date
			end,
			'EEO_DETAIL',
			'sd_exp_date',
			case v.sd_exp_date
			when '1900/1/1' then null
			else v.sd_exp_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where transferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification' 
				and fieldname='V_sd_exp_date' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification' 
										and a2.fieldname='V_sd_exp_date' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	
		
		union all

		select
			t.supplierId,
			s1.Id,
			'SupplierStaticCertification_Recert',
			'V_sd_exp_date',
			case s1.V_sd_exp_date
			when '1900/1/1' then null
			else s1.V_sd_exp_date
			end,
			'EEO_DETAIL_RECERT',
			'sd_exp_date',
			case v.sd_exp_date
			when '1900/1/1' then null
			else v.sd_exp_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.recerttransferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierStaticCertification where recerttransferredFlag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_eeo_detail_recert v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierStaticCertification_Recert' 
				and fieldname='V_sd_exp_date' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierStaticCertification_Recert' 
										and a2.fieldname='V_sd_exp_date' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	


-------------------------------
-------VENDOR_VERIFICATION-----
-------------------------------

		--C_VENDOR_ID
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierProjectVerification',
			'V_c_vendor_id',
			s.federalId,
			'VENDOR_VERIFICATION',
			'C_VENDOR_ID',
			v.C_VENDOR_ID,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierProjectVerification where transferredflag=1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			Supplier s
		on
			s1.supplierId = s.Id
		left join
			cms_report_VENDOR_VERIFICATION v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierProjectVerification' 
				and fieldname='V_c_vendor_id' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierProjectVerification' 
										and a2.fieldname='V_c_vendor_id' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		--C_SOLICIT
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierProjectVerification',
			'ProjectNumber',
			s1.ProjectNumber,
			'VENDOR_VERIFICATION',
			'C_SOLICIT',
			v.C_SOLICIT,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierProjectVerification where transferredflag=1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_VERIFICATION v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierProjectVerification' 
				and fieldname='ProjectNumber' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierProjectVerification' 
										and a2.fieldname='ProjectNumber' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId			
		
		--N_SOLICIT_SEQ
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierProjectVerification',
			'ProjectId',
			s1.ProjectId,
			'VENDOR_VERIFICATION',
			'N_SOLICIT_SEQ',
			v.N_SOLICIT_SEQ,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierProjectVerification where transferredflag=1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_VERIFICATION v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierProjectVerification' 
				and fieldname='ProjectId' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierProjectVerification' 
										and a2.fieldname='ProjectId' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		--N_NO_CEO
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierProjectVerification',
			'NoCEO',
			case 
			when s1.NoCEO='Y' then '1'
			when s1.NoCEO='N' then '0'
			end,
			'VENDOR_VERIFICATION',
			'N_NO_CEO',
			v.N_NO_CEO,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierProjectVerification where transferredflag=1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_VERIFICATION v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierProjectVerification' 
				and fieldname='NoCEO' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierProjectVerification' 
										and a2.fieldname='NoCEO' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	


		--N_NO_CFO
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierProjectVerification',
			'NoCFO',
			case 
			when s1.NoCFO='Y' then '1'
			when s1.NoCFO='N' then '0'
			end,
			'VENDOR_VERIFICATION',
			'N_NO_CFO',
			v.N_NO_CFO,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierProjectVerification where transferredflag=1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_VERIFICATION v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierProjectVerification' 
				and fieldname='NoCFO' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierProjectVerification' 
										and a2.fieldname='NoCFO' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		--N_NO_COO
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierProjectVerification',
			'NoCOO',
			case 
			when s1.NoCOO='Y' then '1'
			when s1.NoCOO='N' then '0'
			end,
			'VENDOR_VERIFICATION',
			'N_NO_COO',
			v.N_NO_COO,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierProjectVerification where transferredflag=1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_VERIFICATION v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierProjectVerification' 
				and fieldname='NoCOO' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierProjectVerification' 
										and a2.fieldname='NoCOO' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	


		--N_NO_OWNER
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierProjectVerification',
			'NoOwner',
			s1.NoOwner,
			'VENDOR_VERIFICATION',
			'N_NO_OWNER',
			v.N_NO_OWNER,			
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierProjectVerification where transferredflag=1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_VERIFICATION v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierProjectVerification' 
				and fieldname='NoOwner' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierProjectVerification' 
										and a2.fieldname='NoOwner' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		--C_EXPLAIN
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierProjectVerification',
			'Explain',
			case 
			when s1.Explain is null then ''
			else ltrim(rtrim(s1.Explain))
			end,
			'VENDOR_VERIFICATION',
			'C_EXPLAIN',
			case
			when v.C_EXPLAIN is null then ''
			else ltrim(rtrim(v.C_EXPLAIN))
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierProjectVerification where transferredflag=1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_VERIFICATION v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierProjectVerification' 
				and fieldname='Explain' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierProjectVerification' 
										and a2.fieldname='Explain' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

----------------------
----YEARLY_SALES-----
---------------------

		--C_VENDOR_ID
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierProjectStatistics',
			'V_c_vendor_id',
			s.federalId,
			'YEARLY_SALES',
			'C_VENDOR_ID',
			v.C_VENDOR_ID,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierProjectStatistics where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			Supplier s
		on
			s1.supplierId = s.Id
		left join
			cms_report_YEARLY_SALES v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierProjectStatistics' 
				and fieldname='V_c_vendor_id' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierProjectStatistics' 
										and a2.fieldname='V_c_vendor_id' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	


		--M_SALES
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierProjectStatistics',
			'TotalAmount',
			convert(decimal(18,2), s1.TotalAmout),
			'YEARLY_SALES',
			'M_SALES',
			v.M_SALES,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierProjectStatistics where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_YEARLY_SALES v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierProjectStatistics' 
				and fieldname='TotalAmount' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierProjectStatistics' 
										and a2.fieldname='TotalAmount' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		--c_year
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierProjectStatistics',
			'Year',
			s1.Year,
			'YEARLY_SALES',
			'c_year',
			v.c_year,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierProjectStatistics where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_YEARLY_SALES v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierProjectStatistics' 
				and fieldname='Year' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierProjectStatistics' 
										and a2.fieldname='Year' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

-------------------------------
---VENDOR_SOLICITATION----
-------------------------------

		--C_VENDOR_ID
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierPersonnelProject',
			'V_c_vendor_id',
			s.federalId,
			'VENDOR_SOLICITATION',
			'C_VENDOR_ID',
			v.C_VENDOR_ID,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnelProject where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			Supplier s
		on
			s1.supplierId = s.Id
		left join
			cms_report_VENDOR_SOLICITATION v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnelProject' 
				and fieldname='V_c_vendor_id' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnelProject' 
										and a2.fieldname='V_c_vendor_id' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	

		--C_SOLICIT
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierPersonnelProject',
			'ProjectNumber',
			s1.ProjectNumber,
			'VENDOR_SOLICITATION',
			'C_SOLICIT',
			v.C_SOLICIT,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnelProject where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_SOLICITATION v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnelProject' 
				and fieldname='ProjectNumber' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnelProject' 
										and a2.fieldname='ProjectNumber' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	
		
		
		--N_SOLICIT_SEQ
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierPersonnelProject',
			'ProjectId',
			s1.ProjectId,
			'VENDOR_SOLICITATION',
			'N_SOLICIT_SEQ',
			v.N_SOLICIT_SEQ,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnelProject where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_SOLICITATION v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnelProject' 
				and fieldname='ProjectId' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnelProject' 
										and a2.fieldname='ProjectId' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId	
		

		--EMP_VASId
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierPersonnelProject',
			'V_EMP_VASId',
			s2.vasId,
			'VENDOR_SOLICITATION',
			'EMP_VASId',
			v2.VASId,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnelProject where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_SOLICITATION v
		on 
			s1.Id = v.vasid
		inner join 
			supplierpersonnel s2
		on
			s1.supplierpersonnelid = s2.id
		inner join
			cms_report_vendor_detail v2
		on
			v.N_EMP_ID = v2.N_EMP_ID
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnelProject' 
				and fieldname='V_EMP_VASId' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnelProject' 
										and a2.fieldname='V_EMP_VASId' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

-------------------------------
---VENDOR_DETAIL--------------
-------------------------------

		--C_VENDOR_ID
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'V_c_vendor_id',
			s.federalId,			
			'VENDOR_DETAIL',
			'C_VENDOR_ID',
			v.c_vendor_id,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			Supplier s
		on
			s1.supplierId = s.Id
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='V_c_vendor_id' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='V_c_vendor_id' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--C_PHONE_1
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'Phone',
			case 
			when isnull(rtrim(ltrim(s1.Phone)), '')='' then null
			else dbo.fnStripNonnumericChars(rtrim(ltrim(s1.Phone)))
			end,			
			'VENDOR_DETAIL',
			'C_PHONE_1',
			case 
			when isnull(v.C_PHONE_1, '')='' then null
			else rtrim(ltrim(dbo.decryptfield(v.C_PHONE_1)))
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='Phone' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='Phone' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--sd_birth_date
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'DOB',
			case 
			when isnull(s1.DOB, '')='' then null
			else s1.DOB
			end,
			'VENDOR_DETAIL',
			'sd_birth_date',
			case 
			when isnull(v.sd_birth_date, '')='' then null
			else dbo.DecryptDateField(v.sd_birth_date)
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='DOB' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='DOB' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--c_ss_number
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'SSN',
			case 
			when isnull(rtrim(ltrim(s1.SSN)), '')='' then null
			else rtrim(ltrim(s1.SSN))
			end,
			'VENDOR_DETAIL',
			'c_ss_number',
			case 
			when isnull(v.c_ss_number, '')='' then null
			else rtrim(ltrim(dbo.DecryptField(v.c_ss_number)))
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='SSN' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='SSN' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--b_owner
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'IsOwner',
			case 
			when s1.IsOwner='N' then '0'
			when s1.IsOwner='Y' then '1'
			end,
			'VENDOR_DETAIL',
			'b_owner',
			v.b_owner,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='IsOwner' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='IsOwner' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--Ownership
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'OwnedPercentage',
			s1.OwnedPercentage,
			'VENDOR_DETAIL',
			'Ownership',
			Ownership,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='OwnedPercentage' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='OwnedPercentage' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--c_address_1
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'AddressLine1',
			case
			when isnull(rtrim(ltrim(dbo.GetItemFromSplitedListWithSpace(s1.AddressLine1, '|', 1))),'') ='' then null
			else ltrim(rtrim(dbo.GetItemFromSplitedListWithSpace(s1.AddressLine1, '|', 1))) 
			end,
			'VENDOR_DETAIL',
			'c_address_1',
			case
			when isnull(v.c_address_1, '') ='' then null
			else rtrim(ltrim(dbo.DecryptField(v.c_address_1)))
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()

		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='AddressLine1' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='AddressLine1' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--c_address_2
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'AddressLine1',
			case
			when isnull(ltrim(rtrim(dbo.GetItemFromSplitedListWithSpace(s1.AddressLine1, '|', 2))),'') ='' then null
			else ltrim(rtrim(dbo.GetItemFromSplitedListWithSpace(s1.AddressLine1, '|', 2)))
			end,
			'VENDOR_DETAIL',
			'c_address_2',
			case
			when isnull(v.c_address_2, '') ='' then null
			else rtrim(ltrim(dbo.DecryptField(v.c_address_2)))
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='AddressLine1' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='AddressLine1' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId



		--c_address_3
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'AddressLine1',
			case
			when isnull(rtrim(ltrim(dbo.GetItemFromSplitedListWithSpace(s1.AddressLine1, '|', 3))),'') ='' then null
			else ltrim(rtrim(dbo.GetItemFromSplitedListWithSpace(s1.AddressLine1, '|', 3))) 
			end,
			'VENDOR_DETAIL',
			'c_address_3',
			case
			when isnull(v.c_address_3, '') ='' then null
			else rtrim(ltrim(dbo.DecryptField(v.c_address_3)))
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='AddressLine1' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='AddressLine1' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--c_city
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'City',
			case
			when isnull(s1.City, '') ='' then null
			else s1.City
			end,
			'VENDOR_DETAIL',
			'c_city',
			case
			when isnull(v.c_city, '') ='' then null
			else dbo.DecryptField(v.c_city)
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='City' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='City' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--c_state
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'State',
			case
			when isnull(s1.State, '') ='' then null
			else s1.State
			end,
			'VENDOR_DETAIL',
			'c_state',
			case
			when isnull(v.c_state, '') ='' then null
			else dbo.DecryptField(v.c_state)
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='State' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='State' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--c_zipcode
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'ZipCode',
			case
			when isnull(s1.ZipCode, '') ='' then null
			else s1.ZipCode
			end,
			'VENDOR_DETAIL',
			'c_zipcode',
			case
			when isnull(v.c_zipcode, '') ='' then null
			else dbo.DecryptField(v.c_zipcode)
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='ZipCode' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='ZipCode' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--d_emplym_start_date
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'EmploymentStartDate',
			case
			when s1.EmploymentStartDate ='1900/1/1' then null
			else s1.EmploymentStartDate
			end,
			'VENDOR_DETAIL',
			'd_emplym_start_date',
			case
			when isnull(v.d_emplym_start_date, '') ='' then null
			else v.d_emplym_start_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='EmploymentStartDate' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='EmploymentStartDate' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--d_posn_start_date
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'CurrentPositionStartDate',
			case
			when s1.CurrentPositionStartDate ='1900/1/1' then null
			else s1.CurrentPositionStartDate
			end,
			'VENDOR_DETAIL',
			'd_posn_start_date',
			case
			when isnull(v.d_posn_start_date, '') ='' then null
			else v.d_posn_start_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='CurrentPositionStartDate' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='CurrentPositionStartDate' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--d_emplym_end_date
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'EmploymentEndDate',
			case
			when s1.EmploymentEndDate ='1900/1/1' then null
			else s1.EmploymentEndDate
			end,
			'VENDOR_DETAIL',
			'd_emplym_end_date',
			case
			when isnull(v.d_emplym_end_date, '') ='' then null
			else v.d_emplym_end_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='EmploymentEndDate' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='EmploymentEndDate' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--d_posn_end_date
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'CurrentPositionEndDate',
			case
			when s1.CurrentPositionEndDate ='1900/1/1' then null
			else s1.CurrentPositionEndDate
			end,
			'VENDOR_DETAIL',
			'd_posn_end_date',
			case
			when isnull(v.d_posn_end_date, '') ='' then null
			else v.d_posn_end_date
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='CurrentPositionEndDate' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='CurrentPositionEndDate' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--c_first_name
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'Name',
			case
			when isnull(dbo.GetItemFromSplitedList(s1.Name, '|', 2), '')='' then null
			else dbo.GetItemFromSplitedList(s1.Name, '|', 2)
			end,
			'VENDOR_DETAIL',
			'c_first_name',
			case
			when isnull(v.c_first_name, '') ='' then null
			else ltrim(rtrim(v.c_first_name))
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='Name' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='Name' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--c_last_name
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'Name',
			case
			when isnull(dbo.GetItemFromSplitedList(s1.Name, '|', 4), '')='' then null
			else dbo.GetItemFromSplitedList(s1.Name, '|', 4)
			end,
			'VENDOR_DETAIL',
			'c_last_name',
			case
			when isnull(v.c_last_name, '') ='' then null
			else ltrim(rtrim(v.c_last_name))
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='Name' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='Name' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--C_NAME_SUFFIX
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'Name',
			case
			when isnull(dbo.GetItemFromSplitedList(s1.Name, '|', 5), '')='' then null
			else dbo.GetItemFromSplitedList(s1.Name, '|', 5)
			end,
			'VENDOR_DETAIL',
			'C_NAME_SUFFIX',
			case
			when isnull(v.C_NAME_SUFFIX, '') ='' then null
			else ltrim(rtrim(v.C_NAME_SUFFIX))
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='Name' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='Name' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--c_title
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'Title',
			case
			when isnull(s1.Title, '')='' then null
			else s1.Title
			end,
			'VENDOR_DETAIL',
			'c_title',
			case
			when isnull(v.c_title, '') ='' then null
			else v.c_title
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='Title' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='Title' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--C_TITLE_CATEGORY
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'TitleCategory',
			case
			when isnull(s1.TitleCategory, '')='' then null
			else s1.TitleCategory
			end,
			'VENDOR_DETAIL',
			'C_TITLE_CATEGORY',
			case
			when isnull(v.C_TITLE_CATEGORY, '') ='' then null
			else v.C_TITLE_CATEGORY
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='TitleCategory' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='TitleCategory' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId



		--C_SOURCE
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'SOURCE',
			s1.SOURCE,
			'VENDOR_DETAIL',
			'C_SOURCE',
			v.C_SOURCE,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='SOURCE' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='SOURCE' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--c_employer
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierPersonnel',
			'Employer',
			case
			when isnull(s1.Employer, '') = '' then null
			else s1.Employer
			end,
			'VENDOR_DETAIL',
			'c_employer',
			case
			when isnull(v.c_employer, '') = '' then null
			else v.c_employer
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierPersonnel where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DETAIL v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierPersonnel' 
				and fieldname='Employer' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierPersonnel' 
										and a2.fieldname='Employer' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


----------------------------------
-------EEO_MENTOR_DETAIL------
----------------------------------
--		--sd_start_date
--		insert into CMSReConciliationReport
--		(
--			VASSupplierId,
--			VASId,
--			VASTableName,
--			VASColumnName,
--			VASContent,
--			CMSTableName,
--			CMSColumnName,
--			CMSContent,
--			ProcessedStatus, VASChangeDate,
--			TransferredDate,
--			CreateDate
--		)
--		select
--			t.supplierId,
--			s1.transactionid,
--			'SupplierMentorWorkflow',
--			'V_sd_start_date',
--			case
--			when s2.propertydate ='1900/1/1' then null
--			else s2.propertydate
--			end,
--			'EEO_MENTOR_DETAIL',
--			case
--			when isnull(v.sd_start_date, '') = '' then null
--			else v.sd_start_date
--			end
--		from 
--			@tempCurrentVendor t
--		inner join
--			(select * from SupplierWorkflow where workflowtype='Mentor Workflow') s1
--		on
--			t.supplierId = s1.supplierId
--		inner join
--			(select * from SupplierProperty where propertyid=525) s2
--		on 
--			t.SupplierId = s2.SupplierId
--		inner join
--			cms_report_EEO_MENTOR_DETAIL v
--		on 
--			s1.transactionid = v.vasid
--		left join
--			(select recordid, processedstatus 
--			from 
--				auditlog  a1
--			where 
--				tablename='SupplierMentorWorkflow' 
--				and fieldname='V_sd_start_date' 
--				and transactionid = (select max(a2.transactionid) 
--									from 
--										auditlog  a2 
--									where 
--										a2.tablename='SupplierMentorWorkflow' 
--										and a2.fieldname='V_sd_start_date' 
--										and a1.recordId = a2.recordId)) a
--		on
--			s1.Id = a.recordId
--
--		--sd_grad_date
--		insert into CMSReConciliationReport
--		(
--			VASSupplierId,
--			VASId,
--			VASTableName,
--			VASColumnName,
--			VASContent,
--			CMSTableName,
--			CMSColumnName,
--			CMSContent,
--			ProcessedStatus, VASChangeDate,
--			TransferredDate,
--			CreateDate
--		)
--		select
--			t.supplierId,
--			s1.transactionid,
--			'SupplierMentorWorkflow',
--			'V_sd_grad_date',
--			case
--			when s2.propertydate ='1900/1/1' then null
--			else s2.propertydate
--			end,
--			'EEO_MENTOR_DETAIL',
--			case
--			when isnull(v.sd_grad_date, '') = '' then null
--			else v.sd_grad_date
--			end
--		from 
--			@tempCurrentVendor t
--		inner join
--			(select * from SupplierWorkflow where workflowtype='Mentor Workflow') s1
--		on
--			t.supplierId = s1.supplierId
--		inner join
--			(select * from SupplierProperty where propertyid=526) s2
--		on 
--			t.SupplierId = s2.SupplierId
--		inner join
--			cms_report_EEO_MENTOR_DETAIL v
--		on 
--			s1.transactionid = v.vasid
--		left join
--			(select recordid, processedstatus 
--			from 
--				auditlog  a1
--			where 
--				tablename='SupplierMentorWorkflow' 
--				and fieldname='V_sd_grad_date' 
--				and transactionid = (select max(a2.transactionid) 
--									from 
--										auditlog  a2 
--									where 
--										a2.tablename='SupplierMentorWorkflow' 
--										and a2.fieldname='V_sd_grad_date' 
--										and a1.recordId = a2.recordId)) a
--		on
--			s1.Id = a.recordId


--------------------------------
-----VENDOR_DISQUAL---
--------------------------------

		--C_VENDOR_ID
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierDisqualification',
			'V_c_vendor_id',
			s.federalId,
			'VENDOR_DISQUAL',
			'C_VENDOR_ID',
			v.c_vendor_id,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierDisqualification where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			Supplier s
		on
			s1.supplierId = s.Id
		left join
			cms_report_VENDOR_DISQUAL v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierDisqualification' 
				and fieldname='V_c_vendor_id' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierDisqualification' 
										and a2.fieldname='V_c_vendor_id' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--SD_DISQUAL_FROM
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierDisqualification',
			'DisqualStartDate',
			case
			when s1.DisqualStartDate ='1900/1/1' then null
			else s1.DisqualStartDate
			end,
			'VENDOR_DISQUAL',
			'SD_DISQUAL_FROM',
			case
			when isnull(v.SD_DISQUAL_FROM, '') ='' then null
			else v.SD_DISQUAL_FROM
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierDisqualification where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DISQUAL v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierDisqualification' 
				and fieldname='DisqualStartDate' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierDisqualification' 
										and a2.fieldname='DisqualStartDate' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--SD_DISQUAL_TO
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierDisqualification',
			'DisqualEndDate',
			case
			when s1.DisqualEndDate ='1900/1/1' then null
			else s1.DisqualEndDate
			end,
			'VENDOR_DISQUAL',
			'SD_DISQUAL_TO',
			case
			when isnull(v.SD_DISQUAL_TO, '') ='' then null
			else v.SD_DISQUAL_TO
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierDisqualification where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_VENDOR_DISQUAL v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierDisqualification' 
				and fieldname='DisqualEndDate' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierDisqualification' 
										and a2.fieldname='DisqualEndDate' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


--------------------------
-------VENDOR_TRADE--
--------------------------

		--C_VENDOR_ID
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierCategory',
			'V_c_vendor_id',
			s.federalId,
			'VENDOR_TRADE',
			'C_VENDOR_ID',
			v.C_VENDOR_ID,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierCategory where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			Supplier s
		on
			s1.supplierId = s.Id
		left join
			cms_report_VENDOR_TRADE v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierCategory' 
				and fieldname='V_c_vendor_id' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierCategory' 
										and a2.fieldname='V_c_vendor_id' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--c_trade_code
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierCategory',
			'V_c_trade_code',
			case
			when isnull(s2.Code, '') = '' then null
			else s2.Code
			end,
			'VENDOR_TRADE',
			'c_trade_code',
			case
			when isnull(v.c_trade_code, '') ='' then null
			else v.c_trade_code
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierCategory where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			Category s2
		on
			s1.CategoryId = s2.Id
		left join
			cms_report_VENDOR_TRADE v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierCategory' 
				and fieldname='V_c_trade_code' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierCategory' 
										and a2.fieldname='V_c_trade_code' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--M_EXPER_FROM
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierCategory',
			'V_M_EXPER_FROM',
			case
			when isnull(s2.V_M_EXP_RANGE_1, '') = '' then null
			else convert(nvarchar(100), convert(decimal(18,2), s2.V_M_EXP_RANGE_1))
			end,
			'VENDOR_TRADE',
			'M_EXPER_FROM',
			case
			when isnull(v.M_EXPER_FROM, '') ='' then null
			else v.M_EXPER_FROM
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierCategory where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			SupplierStaticQualification s2
		on
			s1.SupplierId = s2.SupplierId
		left join
			cms_report_VENDOR_TRADE v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierCategory' 
				and fieldname='V_M_EXPER_FROM' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierCategory' 
										and a2.fieldname='V_M_EXPER_FROM' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--M_EXPER_TO
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierCategory',
			'V_M_EXPER_TO',
			case
			when isnull(s2.V_M_EXP_RANGE_2, '') = '' then null
			else convert(nvarchar(100), convert(decimal(18,2), s2.V_M_EXP_RANGE_2))
			end,
			'VENDOR_TRADE',
			'M_EXPER_TO',
			case
			when isnull(v.M_EXPER_TO, '') ='' then null
			else v.M_EXPER_TO
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierCategory where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			SupplierStaticQualification s2
		on
			s1.SupplierId = s2.SupplierId
		left join
			cms_report_VENDOR_TRADE v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierCategory' 
				and fieldname='V_M_EXPER_TO' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierCategory' 
										and a2.fieldname='V_M_EXPER_TO' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--c_trade_code
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierCategory',
			'V_c_trade_code',
			case
			when isnull(s2.Code, '') = '' then null
			else s2.Code
			end,
			'VENDOR_TRADE',
			'c_trade_code',
			case
			when isnull(v.c_trade_code, '') ='' then null
			else v.c_trade_code
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierCategory where transferredflag = 1 ) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			Category s2
		on
			s1.CategoryId = s2.Id
		left join
			cms_report_VENDOR_TRADE v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierCategory' 
				and fieldname='V_c_trade_code' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierCategory' 
										and a2.fieldname='V_c_trade_code' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--C_LICENSE(only works for new data)
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select 
			t.supplierId,
			t.Id,
			'License',
			'LicenseNo',
			t.LicenseNo,
			'VENDOR_TRADE',
			'C_LICENSE',
			t.c_license,
			t.ProcessedStatus, t.changeDate,
			t.transferredDate,
			getdate()
		from
			(select
				t.supplierId,
				s1.Id,
				l.LicenseNo,
				v.c_license,
				a.ProcessedStatus, s1.changeDate,
				s1.transferredDate,
				row_number()over (partition by s1.supplierId, s1.categoryId order by l.Id) as rownumber
			from 
				@tempCurrentVendor t
			inner join
				(select * from SupplierCategory where transferredflag = 1 ) s1
			on 
				t.SupplierId = s1.SupplierId
			inner join
				Category s2
			on
				s1.CategoryId = s2.Id
			inner join
				tradecodelicense tcl
			on
				s2.code = tcl.tradecode
			inner join
				License l
			on
				s1.supplierId = l.supplierId
				and l.licenseType = tcl.name		
			left join
				cms_report_VENDOR_TRADE v
			on 
				s1.Id = v.vasid
			left join
				(select recordid, processedstatus 
				from 
					auditlog  a1
				where 
					tablename='License' 
					and fieldname='LicenseNo' 
					and transactionid = (select max(a2.transactionid) 
										from 
											auditlog  a2 
										where 
											a2.tablename='License' 
											and a2.fieldname='LicenseNo' 
											and a1.recordId = a2.recordId)) a
			on
				s1.Id = a.recordId) t
		where
			rownumber =1
		


-----------------------------------
--PRIME_APPRENT-----
-----------------------------------
		--C_VENDOR_ID
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierApprenticeshipProgram',
			'V_c_vendor_id',
			s.federalId,
			'PRIME_APPRENT',
			'C_VENDOR_ID',
			v.c_vendor_id,			
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierApprenticeshipProgram where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		inner join
			Supplier s
		on
			s1.supplierId = s.Id
		left join
			cms_report_PRIME_APPRENT v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierApprenticeshipProgram' 
				and fieldname='V_c_vendor_id' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierApprenticeshipProgram' 
										and a2.fieldname='V_c_vendor_id' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--C_APRN_CODE
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierApprenticeshipProgram',
			'ProgramName',
			case
			when isnull(s1.ProgramName, '') = '' then null
			else s1.ProgramName
			end,
			'PRIME_APPRENT',
			'C_APRN_CODE',
			case
			when isnull(v.C_APRN_CODE, '') ='' then null
			else v.C_APRN_CODE
			end,			
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierApprenticeshipProgram where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_PRIME_APPRENT v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierApprenticeshipProgram' 
				and fieldname='ProgramName' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierApprenticeshipProgram' 
										and a2.fieldname='ProgramName' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--C_LOCAL_NUMBER
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierApprenticeshipProgram',
			'Number',
			case
			when isnull(s1.Number, '') = '' then null
			else s1.Number
			end,
			'PRIME_APPRENT',
			'C_LOCAL_NUMBER',
			case
			when isnull(v.C_LOCAL_NUMBER, '') ='' then null
			else v.C_LOCAL_NUMBER
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierApprenticeshipProgram where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_PRIME_APPRENT v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierApprenticeshipProgram' 
				and fieldname='Number' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierApprenticeshipProgram' 
										and a2.fieldname='Number' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--C_APRN_TERM
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierApprenticeshipProgram',
			'NumberOfYears',
			case
			when isnull(s1.NumberOfYears, 0) = 0 then null
			else s1.NumberOfYears
			end,
			'PRIME_APPRENT',
			'C_APRN_TERM',
			case
			when isnull(v.C_APRN_TERM, '0') ='0' then null
			else convert(int, v.C_APRN_TERM)
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierApprenticeshipProgram where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_PRIME_APPRENT v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierApprenticeshipProgram' 
				and fieldname='NumberOfYears' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierApprenticeshipProgram' 
										and a2.fieldname='NumberOfYears' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--SD_AFFL_FROM
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierApprenticeshipProgram',
			'StartDate',
			case
			when isnull(s1.StartDate, '1900/1/1/') ='1900/1/1'  then null
			else s1.StartDate
			end,
			'PRIME_APPRENT',
			'SD_AFFL_FROM',
			case
			when isnull(v.SD_AFFL_FROM, '') ='' then null
			else v.SD_AFFL_FROM
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierApprenticeshipProgram where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_PRIME_APPRENT v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierApprenticeshipProgram' 
				and fieldname='StartDate' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierApprenticeshipProgram' 
										and a2.fieldname='StartDate' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--SD_AFFL_TO
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierApprenticeshipProgram',
			'EndDate',
			case
			when isnull(s1.EndDate, '1900/1/1/') ='1900/1/1'  then null
			else s1.EndDate
			end,
			'PRIME_APPRENT',
			'SD_AFFL_TO',
			case
			when isnull(v.SD_AFFL_TO, '') ='' then null
			else v.SD_AFFL_TO
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierApprenticeshipProgram where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_PRIME_APPRENT v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierApprenticeshipProgram' 
				and fieldname='EndDate' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierApprenticeshipProgram' 
										and a2.fieldname='EndDate' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--C_APRN_ATP_CODE
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.Id,
			'SupplierApprenticeshipProgram',
			'Trade',
			case
			when isnull(s1.Trade, '') =''  then null
			else s1.Trade
			end,
			'PRIME_APPRENT',
			'C_APRN_ATP_CODE',
			case
			when isnull(v.C_APRN_ATP_CODE, '') ='' then null
			else v.C_APRN_ATP_CODE
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from SupplierApprenticeshipProgram where transferredflag = 1) s1
		on 
			t.SupplierId = s1.SupplierId
		left join
			cms_report_PRIME_APPRENT v
		on 
			s1.Id = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierApprenticeshipProgram' 
				and fieldname='Trade' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierApprenticeshipProgram' 
										and a2.fieldname='Trade' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


-----------------------
--EEO_MASTER---
-----------------------
		--C_VENDOR_ID
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier_EEOMaster',
			'V_c_vendor_id',
			s1.federalId,
			'EEO_MASTER',
			'C_VENDOR_ID',
			v.c_vendor_id,
			a.processedstatus, s2.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where eeomastertransferredflag = 1 ) s1
		on 
			t.SupplierId = s1.Id
		inner join
			(select * from SupplierSurety where isprimary='Y') s2
		on
			t.supplierid=s2.supplierid
		left join
			cms_report_EEO_MASTER v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier_EEOMaster' 
				and fieldname='V_c_vendor_id' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier_EEOMaster' 
										and a2.fieldname='V_c_vendor_id' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--c_bonding_co
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier_EEOMaster',
			'V_SuretyName',
			case
			when isnull(s2.suretyname, '') =''  then null
			else s2.suretyname
			end,
			'EEO_MASTER',
			'c_bonding_co',
			case
			when isnull(v.c_bonding_co, '') ='' then null
			else v.c_bonding_co
			end,
			a.processedstatus, s2.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where eeomastertransferredflag = 1 ) s1
		on 
			t.SupplierId = s1.Id
		inner join
			(select * from SupplierSurety where isprimary='Y') s2
		on
			t.supplierid=s2.supplierid
		left join
			cms_report_EEO_MASTER v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier_EEOMaster' 
				and fieldname='V_SuretyName' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier_EEOMaster' 
										and a2.fieldname='V_SuretyName' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--M_AVERAGE_SALES



		--C_RACE
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier_EEOMaster',
			'V_C_RACE',
			case
			when isnull(s1.ethnicity, '') =''  then null
			else s1.ethnicity
			end,
			'EEO_MASTER',
			'C_RACE',
			case
			when isnull(v.C_RACE, '') ='' then null
			else v.C_RACE
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where eeomastertransferredflag = 1 ) s1
		on 
			t.SupplierId = s1.Id
		left join
			cms_report_EEO_MASTER v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier_EEOMaster' 
				and fieldname='V_C_RACE' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier_EEOMaster' 
										and a2.fieldname='V_C_RACE' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

---------------------------
----Vendor-----------------
---------------------------
		--C_VENDOR_ID
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier',
			'V_c_vendor_Id',
			s1.federalId,
			'VENDOR',
			'C_VENDOR_ID',
			v.c_vendor_id,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier' 
				and fieldname='V_c_vendor_Id' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier' 
										and a2.fieldname='V_c_vendor_Id' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--c_name
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier',
			'Company',
			case
			when isnull(s1.Company, '') =''  then null
			else s1.Company
			end,
			'VENDOR',
			'c_name',
			case
			when isnull(v.c_name, '') ='' then null
			else v.c_name
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier' 
				and fieldname='Company' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier' 
										and a2.fieldname='Company' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--c_dba
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier',
			'TradeNames',
			case
			when isnull(s1.TradeNames, '') =''  then null
			else s1.TradeNames
			end,
			'VENDOR',
			'c_dba',
			case
			when isnull(v.c_dba, '') ='' then null
			else v.c_dba
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier' 
				and fieldname='TradeNames' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier' 
										and a2.fieldname='TradeNames' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--c_phone_2
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier',
			'Phone',
			case
			when isnull(dbo.fnStripNonnumericChars(s1.Phone), '') =''  then null
			else dbo.fnStripNonnumericChars(s1.Phone)
			end,
			'VENDOR',
			'c_phone_2',
			case
			when isnull(dbo.fnStripNonnumericChars(v.c_phone_2), '') ='' then null
			else dbo.fnStripNonnumericChars(v.c_phone_2)
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier' 
				and fieldname='Phone' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier' 
										and a2.fieldname='Phone' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--c_fax
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier',
			'Fax',
			case
			when isnull(dbo.fnStripNonnumericChars(s1.Fax), '') =''  then null
			else dbo.fnStripNonnumericChars(s1.Fax)
			end,
			'VENDOR',
			'c_fax',
			case
			when isnull(dbo.fnStripNonnumericChars(v.c_fax), '') ='' then null
			else dbo.fnStripNonnumericChars(v.c_fax)
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier' 
				and fieldname='Fax' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier' 
										and a2.fieldname='Fax' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--web_address
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier',
			'Url',
			case
			when isnull(s1.Url, '') =''  then null
			else s1.Url
			end,
			'VENDOR',
			'web_address',
			case
			when isnull(v.web_address, '') ='' then null
			else v.web_address
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier' 
				and fieldname='Url' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier' 
										and a2.fieldname='Url' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--C_ENTITY_CODE
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier',
			'LegalStructure',
			case
			when isnull(s1.LegalStructure, '') =''  then null
			else s1.LegalStructure
			end,
			'VENDOR',
			'C_ENTITY_CODE',
			case
			when isnull(v.C_ENTITY_CODE, '') ='' then null
			else v.C_ENTITY_CODE
			end,
			a.ProcessedStatus, s1.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier' 
				and fieldname='LegalStructure' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier' 
										and a2.fieldname='LegalStructure' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId



		--????SD_TO_REVIEWER, C_REVIEWER_ID, c_under_million, SD_TO_DIRECTOR are application level in VAS, but vendor level in CMS 
		--SD_TO_REVIEWER
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier',
			'V_SD_TO_REVIEWER',
			case
			when isnull(s2.V_SD_TO_REVIEWER, '1900/1/1') ='1900/1/1'  then null
			else s2.V_SD_TO_REVIEWER
			end,
			'VENDOR',
			'SD_TO_REVIEWER',
			case
			when isnull(v.SD_TO_REVIEWER, '') ='' then null
			else v.SD_TO_REVIEWER
			end,
			a.processedstatus, s2.changeDate,
			s2.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			SupplierStaticQualification s2
		on 
			t.supplierId = s2.supplierid
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier' 
				and fieldname='V_SD_TO_REVIEWER' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier' 
										and a2.fieldname='V_SD_TO_REVIEWER' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		
		--C_REVIEWER_ID
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier',
			'V_C_REVIEWER_ID',
			case
			when isnull(s2.V_C_REVIEWER_ID, '') =''  then null
			else s2.V_C_REVIEWER_ID
			end,
			'VENDOR',
			'C_REVIEWER_ID',
			case
			when isnull(v.C_REVIEWER_ID, '') ='' then null
			else v.C_REVIEWER_ID
			end,
			a.processedstatus, s2.changeDate,
			s2.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			SupplierStaticQualification s2
		on 
			t.supplierId = s2.supplierid
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier' 
				and fieldname='V_C_REVIEWER_ID' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier' 
										and a2.fieldname='V_C_REVIEWER_ID' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--c_under_million
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier',
			'V_c_under_million',
			case
			when isnull(s2.V_c_under_million, '') =''  then 'N'
			else s2.V_c_under_million
			end,
			'VENDOR',
			'c_under_million',
			case
			when isnull(v.c_under_million, '') ='' then 'N'
			else v.c_under_million
			end,
			a.processedstatus, s2.changeDate,
			s2.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			SupplierStaticQualification s2
		on 
			t.supplierId = s2.supplierid
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier' 
				and fieldname='V_c_under_million' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier' 
										and a2.fieldname='V_c_under_million' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId


		--SD_TO_DIRECTOR
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier',
			'V_SD_TO_DIRECTOR',
			case
			when isnull(s2.V_SD_TO_DIRECTOR, '1900/1/1') ='1900/1/1'  then null
			else s2.V_SD_TO_DIRECTOR
			end,
			'VENDOR',
			'SD_TO_DIRECTOR',
			case
			when isnull(v.SD_TO_DIRECTOR, '') ='' then null
			else v.SD_TO_DIRECTOR
			end,
			a.processedstatus, s2.changeDate,
			s2.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			SupplierStaticQualification s2
		on 
			t.supplierId = s2.supplierid
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier' 
				and fieldname='V_SD_TO_DIRECTOR' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier' 
										and a2.fieldname='V_SD_TO_DIRECTOR' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		--c_Bldg
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierAddress',
			'AddressLine1',
			case
			when isnull(ltrim(rtrim(dbo.GetItemFromSplitedList(s2.AddressLine1, '|', 1))), '') =''  then null
			else substring(ltrim(rtrim(dbo.GetItemFromSplitedList(s2.AddressLine1, '|', 1))), 1,7)
			end,
			'VENDOR',
			'c_Bldg',
			case
			when isnull(v.c_Bldg, '') ='' then null
			else v.c_Bldg
			end,
			a.processedstatus, s2.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			(select * from SupplierAddress where addresstype='PHYSICAL') s2
		on
			t.supplierId = s2.supplierId
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierAddress' 
				and fieldname='AddressLine1' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierAddress' 
										and a2.fieldname='AddressLine1' 
										and a1.recordId = a2.recordId)) a
		on
			s2.Id = a.recordId


		--c_Street
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierAddress',
			'AddressLine1',
			case
			when isnull(ltrim(rtrim(dbo.GetItemFromSplitedList(s2.AddressLine1, '|', 2))), '') =''  then null
			else substring(ltrim(rtrim(dbo.GetItemFromSplitedList(s2.AddressLine1, '|', 2))), 1,7)
			end,
			'VENDOR',
			'c_Street',
			case
			when isnull(ltrim(rtrim(v.c_Street)), '') ='' then null
			else substring(ltrim(rtrim(v.c_Street)), 1, 7)
			end,
			a.processedstatus, s2.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			(select * from SupplierAddress where addresstype='PHYSICAL') s2
		on
			t.supplierId = s2.supplierId
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierAddress' 
				and fieldname='AddressLine1' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierAddress' 
										and a2.fieldname='AddressLine1' 
										and a1.recordId = a2.recordId)) a
		on
			s2.Id = a.recordId


		--c_address_2
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierAddress',
			'AddressLine2',
			case
			when isnull(ltrim(rtrim(s2.AddressLine2)), '') =''  then null
			else substring(ltrim(rtrim(s2.AddressLine2)), 1, 28)
			end,
			'VENDOR',
			'c_address_2',
			case
			when isnull(ltrim(rtrim(v.c_address_2)), '') ='' then null
			else substring(ltrim(rtrim(v.c_address_2)), 1, 28)
			end,
			a.processedstatus, s2.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			(select * from SupplierAddress where addresstype='PHYSICAL') s2
		on
			t.supplierId = s2.supplierId
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierAddress' 
				and fieldname='AddressLine2' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierAddress' 
										and a2.fieldname='AddressLine2' 
										and a1.recordId = a2.recordId)) a
		on
			s2.Id = a.recordId


--		--c_address_1
--		insert into CMSReConciliationReport
--		(
--			VASSupplierId,
--			VASId,
--			VASTableName,
--			VASColumnName,
--			VASContent,
--			CMSTableName,
--			CMSColumnName,
--			CMSContent,
--			ProcessedStatus, VASChangeDate,
--			TransferredDate,
--			CreateDate
--		)
--		select
--			t.supplierId,
--			s1.vasId,
--			'SupplierAddress',
--			'AddressLine1',
--			case
--			when isnull(replace(s2.AddressLine1, '|', ' ') , '') =''  then null
--			else replace(s2.AddressLine1, '|', ' ')
--			end,
--			'VENDOR',
--			'c_address_1',
--			case
--			when isnull(v.c_address_1, '') ='' then null
--			else v.c_address_1
--			end,
--			a.processedstatus, s2.changeDate,
--			s1.transferredDate,
--			getdate()
--		from 
--			@tempCurrentVendor t
--		inner join
--			(select * from Supplier where transferredflag = 1) s1
--		on 
--			t.SupplierId = s1.Id
--		inner join
--			(select * from SupplierAddress where addresstype='PHYSICAL') s2
--		on
--			t.supplierId = s2.supplierId
--		left join
--			cms_report_VENDOR v
--		on 
--			s1.vasId = v.vasid
--		left join
--			(select recordid, processedstatus 
--			from 
--				auditlog  a1
--			where 
--				tablename='SupplierAddress' 
--				and fieldname='AddressLine1' 
--				and transactionid = (select max(a2.transactionid) 
--									from 
--										auditlog  a2 
--									where 
--										a2.tablename='SupplierAddress' 
--										and a2.fieldname='AddressLine1' 
--										and a1.recordId = a2.recordId)) a
--		on
--			s2.Id = a.recordId

		--C_CITY
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierAddress',
			'City',
			case
			when isnull(s2.City, '') =''  then null
			else s2.City
			end,
			'VENDOR',
			'C_CITY',
			case
			when isnull(v.C_CITY, '') ='' then null
			else v.C_CITY
			end,			
			a.processedstatus, s2.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			(select * from SupplierAddress where addresstype='PHYSICAL') s2
		on
			t.supplierId = s2.supplierId
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierAddress' 
				and fieldname='City' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierAddress' 
										and a2.fieldname='City' 
										and a1.recordId = a2.recordId)) a
		on
			s2.Id = a.recordId

		--C_STATE
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierAddress',
			'State',
			case
			when isnull(s2.State, '') =''  then null
			else s2.State
			end,
			'VENDOR',
			'C_STATE',
			case
			when isnull(v.C_STATE, '') ='' then null
			else v.C_STATE
			end,
			a.processedstatus, s2.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			(select * from SupplierAddress where addresstype='PHYSICAL') s2
		on
			t.supplierId = s2.supplierId
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierAddress' 
				and fieldname='State' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierAddress' 
										and a2.fieldname='State' 
										and a1.recordId = a2.recordId)) a
		on
			s2.Id = a.recordId


		--C_ZIPCODE
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'SupplierAddress',
			'ZipCode',
			case
			when isnull(s2.ZipCode, '') =''  then null
			else s2.ZipCode
			end,
			'VENDOR',
			'C_ZIPCODE',
			case
			when isnull(v.C_ZIPCODE, '') ='' then null
			else v.C_ZIPCODE
			end,
			a.processedstatus, s2.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			(select * from SupplierAddress where addresstype='PHYSICAL') s2
		on
			t.supplierId = s2.supplierId
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='SupplierAddress' 
				and fieldname='ZipCode' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='SupplierAddress' 
										and a2.fieldname='ZipCode' 
										and a1.recordId = a2.recordId)) a
		on
			s2.Id = a.recordId



		--c_contact
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'VendorContact',
			'Name',
			case
			when isnull(s3.Name, '') =''  then null
			else substring(s3.Name, 1, 18)
			end,
			'VENDOR',
			'c_contact',
			case
			when isnull(v.c_contact, '') ='' then null
			else v.c_contact
			end,
			a.ProcessedStatus, s3.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			Vendor s2
		on 
			s2.federalId = s1.federalId
		inner join
			(select * from VendorContact where FromVendor='Y' and ContactType='Primary') s3
		on
			s2.Id = s3.vendorId
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='VendorContact' 
				and fieldname='Name' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='VendorContact' 
										and a2.fieldname='Name' 
										and a1.recordId = a2.recordId)) a
		on
			s3.Id = a.recordId


		--c_phone_1
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'VendorContact',
			'Phone',
			case
			when isnull(dbo.fnStripNonnumericChars(s3.Phone), '') =''   then null
			else dbo.fnStripNonnumericChars(s3.Phone)
			end,
			'VENDOR',
			'c_phone_1',
			case
			when isnull(dbo.fnStripNonnumericChars(v.c_phone_1), '') ='' then null
			else dbo.fnStripNonnumericChars(v.c_phone_1)
			end,
			a.ProcessedStatus, s3.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			Vendor s2
		on 
			s2.federalId = s1.federalId
		inner join
			(select * from VendorContact where FromVendor='Y' and ContactType='Primary') s3
		on
			s2.Id = s3.vendorId
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='VendorContact' 
				and fieldname='Phone' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='VendorContact' 
										and a2.fieldname='Phone' 
										and a1.recordId = a2.recordId)) a
		on
			s3.Id = a.recordId



		--c_cellular
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'VendorContact',
			'Fax',
			case
			when isnull(dbo.fnStripNonnumericChars(s3.Fax), '') =''   then null
			else dbo.fnStripNonnumericChars(s3.Fax)
			end,
			'VENDOR',
			'c_cellular',
			case
			when isnull(dbo.fnStripNonnumericChars(v.c_cellular), '') ='' then null
			else dbo.fnStripNonnumericChars(v.c_cellular)
			end,			
			a.ProcessedStatus, s3.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			Vendor s2
		on 
			s2.federalId = s1.federalId
		inner join
			(select * from VendorContact where FromVendor='Y' and ContactType='Primary') s3
		on
			s2.Id = s3.vendorId
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='VendorContact' 
				and fieldname='Fax' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='VendorContact' 
										and a2.fieldname='Fax' 
										and a1.recordId = a2.recordId)) a
		on
			s3.Id = a.recordId

		--c_email
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'VendorContact',
			'Email',
			case
			when isnull(s3.Email, '') =''   then null
			else s3.Email
			end,
			'VENDOR',
			'c_email',
			case
			when isnull(v.c_email, '') ='' then null
			else v.c_email
			end,
			a.ProcessedStatus, s3.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			Vendor s2
		on 
			s2.federalId = s1.federalId
		inner join
			(select * from VendorContact where FromVendor='Y' and ContactType='Primary') s3
		on
			s2.Id = s3.vendorId
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='VendorContact' 
				and fieldname='Email' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='VendorContact' 
										and a2.fieldname='Email' 
										and a1.recordId = a2.recordId)) a
		on
			s3.Id = a.recordId


		--secondary_email
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'VendorContact',
			'Email',
			case
			when isnull(s3.Email, '') =''   then null
			else s3.Email
			end,
			'VENDOR',
			'c_contact',
			case
			when isnull(v.secondary_email, '') ='' then null
			else v.secondary_email
			end,
			a.ProcessedStatus, s3.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			Vendor s2
		on 
			s2.federalId = s1.federalId
		inner join
			(select * from VendorContact where FromVendor='Y' and ContactType='Secondary') s3
		on
			s2.Id = s3.vendorId
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='VendorContact' 
				and fieldname='Email' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='VendorContact' 
										and a2.fieldname='Email' 
										and a1.recordId = a2.recordId)) a
		on
			s3.Id = a.recordId

		--c_email3
		insert into CMSReConciliationReport
		(
			VASSupplierId,
			VASId,
			VASTableName,
			VASColumnName,
			VASContent,
			CMSTableName,
			CMSColumnName,
			CMSContent,
			ProcessedStatus, VASChangeDate,
			TransferredDate,
			CreateDate
		)
		select
			t.supplierId,
			s1.vasId,
			'Supplier',
			'V_c_email3',
			case
			when isnull(convert(nvarchar(100),s2.PropertyText), '') =''  then null
			else convert(nvarchar(100),s2.PropertyText)
			end,
			'VENDOR',
			'c_email3',
			case
			when isnull(v.c_email3, '') ='' then null
			else v.c_email3
			end,
			a.processedstatus, s2.changeDate,
			s1.transferredDate,
			getdate()
		from 
			@tempCurrentVendor t
		inner join
			(select * from Supplier where transferredflag = 1) s1
		on 
			t.SupplierId = s1.Id
		inner join
			(select * from SupplierProperty where propertyId=442) s2
		on
			t.supplierId = s2.supplierId
		left join
			cms_report_VENDOR v
		on 
			s1.vasId = v.vasid
		left join
			(select recordid, processedstatus 
			from 
				auditlog  a1
			where 
				tablename='Supplier' 
				and fieldname='V_c_email3' 
				and transactionid = (select max(a2.transactionid) 
									from 
										auditlog  a2 
									where 
										a2.tablename='Supplier' 
										and a2.fieldname='V_c_email3' 
										and a1.recordId = a2.recordId)) a
		on
			s1.Id = a.recordId

		commit transaction
		return 0
	end try

	begin catch
		RollBack Transaction
		return 1
	end catch


end



































