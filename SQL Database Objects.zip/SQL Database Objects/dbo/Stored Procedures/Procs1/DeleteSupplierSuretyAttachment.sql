﻿



CREATE PROCEDURE [dbo].[DeleteSupplierSuretyAttachment]
(
@id int
)AS
Begin

Update  SupplierSurety
set  LetterFileName ='',
	BondingLetterId = null
Where Id = @id
return @@rowcount
End










