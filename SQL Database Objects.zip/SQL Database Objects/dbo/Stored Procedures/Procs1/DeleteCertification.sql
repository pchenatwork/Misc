﻿/*
*********************************************************************************************************************
Procedure:	DeleteCertification
Purpose:	Delete a row from Certification table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/12/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteCertification
	@id int
as

delete Certification
where Id = @id
return @@RowCount

