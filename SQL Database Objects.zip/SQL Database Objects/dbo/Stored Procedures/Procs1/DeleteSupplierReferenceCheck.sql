﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierReferenceCheck
Purpose:	Delete a row from SupplierReferenceCheck table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
6/23/2008		AECSOFTUSA\angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteSupplierReferenceCheck
	@id int
as

delete SupplierReferenceCheck
where Id = @id
return @@RowCount

