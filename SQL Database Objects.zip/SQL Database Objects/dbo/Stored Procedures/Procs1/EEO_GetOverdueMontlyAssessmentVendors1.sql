﻿/*
 Rules for Overdue Monthly Assessment counter
    a.	Counter should consider Mentor firms only (should be enrolled into mentor program)
    b.	Should list mentor firms that have any UnSubmitted projects from previous months 
    e.g. if the assessment is supposed to be completed between Dec 15th to Jan 15th. On Jan 16th the vendor should be part of the counter. System should have capability to configure from and to dates.


*/
Create PROCEDURE [dbo].[EEO_GetOverdueMontlyAssessmentVendors1]
AS

Begin

 


    SELECT distinct x.VendorId FROM        
        (
         SELECT  P.VENDORID, P.PROJECT_CODE , DATEADD(month,number+1,  P.START_DATE) as ASSMENT_MONTH
                    FROM master..spt_values , 
                        (
                            SELECT DISTINCT  
                                    V.ID AS VENDORID,
                                    SC.C_PACKAGE_CODE AS PROJECT_CODE,
                                    SC.D_CONSTR_BEGIN AS START_DATE,
									D.SD_START_DATE ,
                                    CASE 
											 WHEN SC.D_CONSTR_END <   GETDATE()  THEN SC.D_CONSTR_END
											 ELSE  GETDATE() 
									END AS END_DATE               
                            FROM VENDOR V, MV_SOLICIT_CONTRACT SC,EEO_VENDOR EV  ,EEO_MENTOR_GRAD_DETAIL D
                            WHERE  V.ID = EV.VENDORID  
								AND V.ID = D.VENDORID
								AND D.C_MENTOR_TYPE = 'MENTOR'
                                AND V.FEDERALID = ISNULL(C_VENDOR_ID,ME_VENDOR_ID)
                                AND EV.MENTORFLAG=6											 -- only those vendors marked as  MENTOR
                                AND SC.D_CONSTR_BEGIN IS NOT NULL 
                            ) as P
                   WHERE type = 'P'
                        AND DATEADD(month,number+1,P.START_DATE) < P.END_DATE   
						AND p.START_DATE > p.SD_START_DATE
                       
         ) as X 
         
     WHERE NOT EXISTS ( 
            SELECT 1 FROM DBO.EEO_MENTOR_PPM_RATING R 
            WHERE X.VENDORID = R.VENDORID 
                AND X.PROJECT_CODE = R.PROJ_CODE
                AND  MONTH(X.ASSMENT_MONTH) = MONTH(R.MONTH_RATED) 
                AND YEAR(X.ASSMENT_MONTH) = YEAR(R.MONTH_RATED) 
				)
     
    
END
