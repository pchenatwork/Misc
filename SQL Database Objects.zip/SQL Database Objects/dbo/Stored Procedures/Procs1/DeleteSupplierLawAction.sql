﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierLawAction
Purpose:	Delete a row from SupplierLawAction table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/13/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteSupplierLawAction
	@id int
as

delete SupplierLawAction
where Id = @id
return @@RowCount

