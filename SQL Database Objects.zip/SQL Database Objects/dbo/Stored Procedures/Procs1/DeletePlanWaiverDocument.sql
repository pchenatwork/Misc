﻿/*
*********************************************************************************************************************
Procedure:	DeletePlanWaiverDocument
Purpose:	Delete a row from PlanWaiverDocument table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
9/3/2010		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure DeletePlanWaiverDocument
	@id int
as

delete PlanWaiverDocument
where Id = @id
return @@RowCount

