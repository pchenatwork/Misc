﻿---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================
-- Author:		David Kwok
-- Create date: 12/07/2015
-- Description:	Get list of companies that have assessment scores for report
-- =============================================
CREATE PROCEDURE [dbo].[EEO_AssessmentScoreCompanies]
AS
begin




declare @Days4AdjustingYears int 
declare @AssessmentStartDateGracePeriod int 
declare @AssessmentEndDateGracePeriod int 


Select @Days4AdjustingYears= ISNULL([value],0) from dbo.EEO_CONFIG
where [key] = 'Days4AdjustingYears'

 Select @AssessmentStartDateGracePeriod= ISNULL([value],0) from dbo.EEO_CONFIG
where [key] = 'AssessmentStartDateGracePeriod'

Select @AssessmentEndDateGracePeriod= ISNULL([value],0) from dbo.EEO_CONFIG
where [key] = 'AssessmentEndDateGracePeriod'

Declare @tempVendorPeriod Table
(
		Id int identity (1,1) Primary Key,
		PeriodId decimal(5,0),
		Vendorid int,
		Period_StartDate Datetime,
		Period_EndDate Datetime,
		MentorType varchar(30),
		AssessmentType char(1)
)

       
       
INSERT INTO @tempVendorPeriod
        (   
                Vendorid,
                PeriodId ,
                Period_StartDate, 
                Period_EndDate ,
                MentorType,
                AssessmentType
                )
        SELECT DISTINCT VENDORID,  NUMBER+1 AS PERIODID,
                    DATEADD(YEAR,NUMBER,START_DATE) AS AST_StartDate,
                    DATEADD(YEAR,NUMBER+1,START_DATE)  AS AST_EndDate,
                    'MENTOR' AS MENTOR_TYPE,
                    'Y' AS ASSESSMEN_TTYPE
        FROM MASTER..SPT_VALUES , 
                                            (      SELECT DISTINCT  
                                                                    GD.VENDORID,
                                                                    DATEFROMPARTS(YEAR(GD.SD_START_DATE),MONTH(GD.SD_START_DATE),1)  AS START_DATE,   -- start of the month
                                                                    EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS END_DATE,  --  USE SD_EXT_GRAD_DATE FIRST OTHERWISE SD_GRAD_DATE AND EXCLUDE FINAL YEAR
                                                                    EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS ACTUAL_END_DATE ,
                                                                    GD.C_MENTOR_TYPE              
                                                FROM (SELECT * FROM  DBO.EEO_MENTOR_GRAD_DETAIL 
                                                                    WHERE ID IN  
                                                                                    (SELECT MAX(ID) AS ID   FROM DBO.EEO_MENTOR_GRAD_DETAIL  -- MAX RECORD FOR VENDOR WITH C_MENTOR_TYPE
                                                                                        WHERE C_MENTOR_TYPE='MENTOR' --  Mentor firms only
                                                                                            GROUP BY VENDORID,C_MENTOR_TYPE 
                                                                                            )
                                                            ) GD  , EEO_VENDOR EV
                                                WHERE GD.VENDORID=EV.VENDORID
                                                                AND EV.MENTORFLAG IN (6) -- only those vendors marked as  MENTOR
                                        ) AS P
        WHERE TYPE = 'P'
        AND DATEADD(YEAR,NUMBER+1,P.START_DATE)   <= 
                    DATEADD( DAY, ISNULL(365-ISNULL(@AssessmentEndDateGracePeriod,0),0), P.END_DATE )   

        UNION

        SELECT DISTINCT VENDORID,  NUMBER+1 AS PERIODID,
                    DATEADD(YEAR,NUMBER,START_DATE) AS AST_StartDate,
                    DATEADD(YEAR,NUMBER+1,START_DATE)  AS AST_EndDate,
                    'GRAD MENTOR'  AS MENTOR_TYPE,
                    'Y' AS ASSESSMEN_TTYPE
        FROM MASTER..SPT_VALUES , 
                                            (      SELECT DISTINCT  
                                                                    GD.VENDORID,
                                                                    DATEFROMPARTS(YEAR(GD.SD_START_DATE),MONTH(GD.SD_START_DATE),1)  AS START_DATE,   -- start of the month
                                                                    EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS END_DATE,  --  USE SD_EXT_GRAD_DATE FIRST OTHERWISE SD_GRAD_DATE AND EXCLUDE FINAL YEAR
                                                                    EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS ACTUAL_END_DATE ,
                                                                    GD.C_MENTOR_TYPE              
                                                FROM (SELECT * FROM  DBO.EEO_MENTOR_GRAD_DETAIL 
                                                                    WHERE ID IN  
                                                                                    (SELECT MAX(ID) AS ID   FROM DBO.EEO_MENTOR_GRAD_DETAIL  -- MAX RECORD FOR VENDOR WITH C_MENTOR_TYPE
                                                                                        WHERE C_MENTOR_TYPE='GRAD MENTOR' --  Mentor firms only
                                                                                            GROUP BY VENDORID,C_MENTOR_TYPE 
                                                                                            )
                                                            ) GD  , EEO_VENDOR EV
                                                WHERE GD.VENDORID=EV.VENDORID
                                                                AND EV.MENTORFLAG IN (7) -- only those vendors marked as  MENTOR
                                            ) AS P
        WHERE TYPE = 'P'
        AND DATEADD(YEAR,NUMBER+1,P.START_DATE)   <= 
                    DATEADD( DAY, ISNULL(365-ISNULL(@AssessmentEndDateGracePeriod,0),0), P.END_DATE )  
                                    
        ORDER BY  VENDORID,MENTOR_TYPE




UPDATE @tempVendorPeriod 
SET AssessmentType='F' 
From @tempVendorPeriod tmpp
        WHERE PeriodId = (
                SELECT max(PeriodId) FROM @tempVendorPeriod tmp
                WHERE  tmp.Vendorid=tmpp.Vendorid
                group by Vendorid
) 


--select -1 as vendorId,  'All' as Company ,1 as OrderCol
--union

select 
distinct
v.id vendorId,
ltrim(v.Company) as Company,
2 as OrderCol
into #tmptbl
from @tempVendorPeriod a
inner join vendor v
on a.vendorid = v.id 
order by Company,OrderCol, v.id



Select * from 
(
select 'All' as Company ,-1 as vendorId,1 as OrderCol,0 as RowNum 
union
select Company,vendorId,OrderCol,ROW_NUMBER() OVER(ORDER BY Company Asc) AS RowNum from #tmptbl 
)a 
order by a.RowNum
end


-- EEO_AssessmentScoreCompanies
