﻿/*
*********************************************************************************************************************
Procedure:	DeleteSubcontractorComment
Purpose:	Delete a row from SubcontractorComment table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
4/14/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure [dbo].[DeleteSubcontractorComment]
	@id int
as

delete SubcontractorComment
where Id = @id
return @@RowCount

