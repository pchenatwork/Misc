﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierPersonnelGovernmentAgency
Purpose:	Delete a row from SupplierPersonnelGovernmentAgency table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/10/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
Create procedure DeleteSupplierPersonnelGovernmentAgency
	@id int
as

delete SupplierPersonnelGovernmentAgency
where Id = @id
return @@RowCount

