﻿/*
*********************************************************************************************************************
Procedure:	DeleteSubContractorLicense
Purpose:	Delete a row from SubContractorLicense table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/3/2008		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteSubContractorApprenticeshipProgram
	@id int
as

delete SubContractorApprenticeshipProgram
where Id = @id
return @@RowCount

