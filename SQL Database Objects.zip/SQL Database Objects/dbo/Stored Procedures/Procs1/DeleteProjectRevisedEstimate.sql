﻿
/*
*********************************************************************************************************************
Procedure:	DeleteProjectRevisedEstimate
Purpose:	Delete a row from ProjectRevisedEstimate table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
05/13/2011		AECSOFTUSA\Bill Cooper		Created
*********************************************************************************************************************
*/
Create procedure [dbo].[DeleteProjectRevisedEstimate]
	@id int
as

delete ProjectRevisedEstimate
where Id = @id
return @@RowCount


