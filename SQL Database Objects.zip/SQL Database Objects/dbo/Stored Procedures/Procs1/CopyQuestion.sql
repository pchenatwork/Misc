﻿/*
*********************************************************************************************************************
Procedure:	CopyQuestion
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
04/03/2005	Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE PROCEDURE CopyQuestion
(
	@questionId int
)
AS
Begin
Declare @newQuestionId int
Declare @sectionId int
Declare @parentId int
Declare @tempQuestion Table
(
	Id		int,
	SectionId	int,
	ParentId	int,
	QuestionTypeId	int,
	QuestionText	ntext,
	Sequence	int,
	IsRequired	char(1),
	RowNumber	int,
	ColumnNumber	int,
	MaxLength	int,
	AnswerFormat	nvarchar(50),
	MaxValue	nvarchar(50),
	MinValue	nvarchar(50),
	DefaultValue	nvarchar(50),
	RepeatDirection	nvarchar(50),
	Score		int,
	Searchable	char(1)
)
Declare @tempAnswer Table
(
	Id		int,
	QuestionId	int,
	AnswerText	ntext,
	Sequence	int,
	AnswerType	nvarchar(20),
	AnswerValue	nvarchar(50),
	Score		int
)
Insert Into @tempQuestion
(
	Id,SectionId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,	
	RowNumber,ColumnNumber,MaxLength,AnswerFormat,MaxValue,	MinValue,DefaultValue,RepeatDirection,Score,Searchable
)
Select 
	Id,SectionId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,
	RowNumber,ColumnNumber,MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,RepeatDirection,Score,Searchable
From Question
Where ParentId = @questionId
While ( @@rowcount > 0 )
Begin
	Insert Into @tempQuestion
	(
		Id,SectionId,ParentId,QuestionTypeId,QuestionText,Sequence, IsRequired,	
		RowNumber,ColumnNumber,MaxLength,AnswerFormat,MaxValue,	MinValue,DefaultValue,RepeatDirection, Score,Searchable
	)
	Select 
		Id,SectionId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,
		RowNumber,ColumnNumber,MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,RepeatDirection, Score,Searchable
	From Question
	Where ( Id Not In ( Select Id From @tempQuestion ) ) And( ParentId In ( Select Id From @tempQuestion ) )
End
Insert Into @tempAnswer (Id,QuestionId,AnswerText,Sequence,AnswerType, AnswerValue, Score )
Select Id,QuestionId,AnswerText,Sequence,AnswerType, AnswerValue, Score 
From Answer
Where QuestionId in ( Select Id From @tempQuestion ) Or QuestionId = @questionId
-- Copy the question itself
Insert Into Question
(
	SectionId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,	
	RowNumber,ColumnNumber,MaxLength,AnswerFormat,MaxValue,	MinValue,DefaultValue,RepeatDirection, Score,Searchable
)
Select 
	SectionId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,
	RowNumber,ColumnNumber,MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,RepeatDirection, Score,Searchable
From Question
Where Id = @questionId
Set @newQuestionId = @@identity
--update the new question's Sequence
Select @sectionId = SectionId, @parentId = ParentId From Question 
Where Id = @questionId
Update Question Set Sequence = 
( Select Max(Sequence) + 1 From Question Where SectionId = @sectionId And ParentId = @parentId )
Where Id = @newQuestionId
--Update record in @tempQuestion, @tempAnswer make their QuestionId to new QuestionId
Update @tempQuestion Set ParentId = @newQuestionId Where ParentId = @questionId
Update @tempAnswer Set QuestionId = @newQuestionId Where QuestionId = @questionId
--Insert Sub Question
While Exists( Select * From @tempQuestion )
Begin
	Select @questionId = Id From @tempQuestion Order By Id Desc
	
	Insert Into Question
	(
		SectionId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,	
		RowNumber,ColumnNumber,MaxLength,AnswerFormat,MaxValue,	MinValue,DefaultValue,RepeatDirection, Score,Searchable
	)
	Select 
		SectionId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,
		RowNumber,ColumnNumber,MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,RepeatDirection, Score,Searchable
	From @tempQuestion
	Where Id = @questionId
	Set @newQuestionId = @@identity
	--Update record in @tempQuestion, @tempAnswer make their QuestionId to new QuestionId
	Update @tempQuestion Set ParentId = @newQuestionId Where ParentId = @questionId
	Update @tempAnswer Set QuestionId = @newQuestionId Where QuestionId = @questionId
	Delete @tempQuestion Where Id = @questionId
End
-- Insert Answer
Insert Into Answer(QuestionId,AnswerText,Sequence,AnswerType,AnswerValue, Score)
Select QuestionId,AnswerText,Sequence,AnswerType,AnswerValue, Score 
From @tempAnswer
End




