﻿




/*
*********************************************************************************************************************
Procedure:	DeleteApplication
Purpose:	Delete Qual/Cert Application.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
12/03/2004		Lily Xiong		Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSupplierApplication]
	@id int,
	@type nvarchar(50),
	@userName nvarchar(50)=null
	
as

BEGIN Transaction

declare @actionTime  datetime
set @actionTime = getdate()
declare @transactionId int
insert into [Transaction](Type, ActionTime) values ('CMS', @actionTime)
select @transactionId = max(id) from [Transaction]
declare @workflowTransactionId int

if @type='Qual'
	begin
		select 
			@workflowTransactionId = transactionId 
		from 
			supplierworkflow 
		where 
			supplierid=@id   
			and workflowtype='Supplier Prequalification'

		delete from 
			supplierworkflow 
		where 
			supplierid=@id   
			and workflowtype='Supplier Prequalification'

		delete from 
			supplierstatus 
		where 
			supplierid =@id 
			and typename='Supplier Prequalification'

		----Auditlog
		Insert 
			AuditLog
			(TableName, RecordId, VASId,  MainId, transactionid, action, actiontime, username, processedstatus)	
		select  
			'SupplierStaticQualification', id, id, SupplierId, @transactionId, 'delete', @actionTime, @userName, 'U' 
		from 
			SupplierStaticQualification
		where
			supplierId=@id
			and transferredflag='1'
		----Auditlog

		delete from 
			SupplierStaticQualification 
		where 
			supplierid =@id 

		delete from 
			workflowhistory 
		where 
			transactionheaderId = @workflowTransactionId

		update 
			supplier 
		set 
			qualsubmitteddate=null 
		where 
			id=@id
	end

--delete cert workflow
if @type='Cert'
	begin
		select 
			@workflowTransactionId = transactionId 
		from 
			supplierworkflow 
		where 
			supplierid=@id   
			and workflowtype='Supplier Certification'

		delete from 
			supplierworkflow 
		where 
			supplierid=@id   
			and workflowtype='Supplier Certification'

		delete from 
			supplierstatus 
		where 
			supplierid =@id 
			and typename='Supplier Certification'

		----Auditlog
		Insert 
			AuditLog
			(TableName, RecordId, VASId,  MainId, transactionid, action, actiontime, username, processedstatus)	
		select  
			'SupplierStaticCertification', id, id, SupplierId, @transactionId, 'delete', @actionTime, @userName, 'U' 
		from 
			SupplierStaticCertification
		where
			supplierId=@id
			and transferredflag='1'
		----Auditlog

		delete from 
			SupplierStaticCertification 
		where 
			supplierid =@id 
	
		delete from 
			workflowhistory 
		where 
			transactionheaderId = @workflowTransactionId

		update 
			supplier 
		set 
			certsubmitteddate=null 
		where 
			id=@id
	end

if @@error = 0
	Commit Transaction   
else
	RollBack Transaction
return @@rowcount






