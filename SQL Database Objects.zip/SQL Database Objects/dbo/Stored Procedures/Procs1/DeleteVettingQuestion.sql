﻿/*
*********************************************************************************************************************
Procedure:	DeleteVettingQuestion
Purpose:	Delete a row from VettingQuestion table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/22/2007		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteVettingQuestion]
	@id int
as

Set NoCount On

declare @isActive char(1)
Select @isActive = IsActive From VettingQuestion
Where Id = @id

BEGIN Transaction

if @isActive = 'N'
Begin
	delete SupplierVettingResponse
	Where QuestionId = @id
End

delete VettingAttachment
Where VettingQuestionId = @id

delete VettingAnswer
Where QuestionId = @id

delete VettingQuestion
Where Id = @id

if @@error = 0
	Commit Transaction
else
	RollBack Transaction
return @@RowCount