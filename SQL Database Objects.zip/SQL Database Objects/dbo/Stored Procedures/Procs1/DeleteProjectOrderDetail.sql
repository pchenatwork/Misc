﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectOrderDetail
Purpose:	Delete a row from ProjectOrderDetail table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
5/21/2010		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteProjectOrderDetail
	@id int
as

delete ProjectOrderDetail
where Id = @id
return @@RowCount

