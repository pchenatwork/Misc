﻿ 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*
BDD Analyst Yearly Assessment Overdue Counter


•	Should be Mentor firms Only
•	Assessments not completed within the specified time period (this should be configurable)
    o	E.g. if the assessment is supposed to be done from Dec 1st 2015 to Mar 1st  2016 and the assessment is not submitted, on March 2nd  2016 the firm should appear in the counter. Dec 1st to Mar 1st should be configurable. On Dec 1st 2016, the firm shou
ld be off the counter as this is going to be part of Scope B’s yearly assessment counter.



*/
CREATE PROCEDURE [dbo].[EEO_GetOverdueYearlyAssessmentVendors]
 
AS

Begin

declare @Days4AdjustingYears int 
declare @AssessmentStartDateGracePeriod int 
declare @AssessmentEndDateGracePeriod int 


Select @Days4AdjustingYears= ISNULL([value],0) from dbo.EEO_CONFIG
 where [key] = 'Days4AdjustingYears'
 
 Select @AssessmentStartDateGracePeriod= ISNULL([value],0) from dbo.EEO_CONFIG
 where [key] = 'AssessmentStartDateGracePeriod'

 Select @AssessmentEndDateGracePeriod= ISNULL([value],0) from dbo.EEO_CONFIG
 where [key] = 'AssessmentEndDateGracePeriod'


    SELECT DISTINCT Y.VENDORID 
	FROM (
			SELECT DISTINCT VENDORID, PERIODID 
			FROM 
			(
				SELECT DISTINCT VENDORID,  NUMBER+1 AS PERIODID,
								DATEADD(YEAR,NUMBER,START_DATE) AS AST_StartDate,
								DATEADD(YEAR,NUMBER+1,START_DATE)  AS AST_EndDate 
						FROM MASTER..SPT_VALUES , 
											(	SELECT DISTINCT  
															GD.VENDORID,
															DATEFROMPARTS(YEAR(GD.SD_START_DATE),MONTH(GD.SD_START_DATE),1)  AS START_DATE,   -- start of the month
															DATEADD(YEAR,-1,EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE))) AS END_DATE,  --  USE SD_EXT_GRAD_DATE FIRST OTHERWISE SD_GRAD_DATE AND EXCLUDE FINAL YEAR
															EOMONTH(ISNULL(GD.SD_EXT_GRAD_DATE,GD.SD_GRAD_DATE)) AS ACTUAL_END_DATE ,
															GD.C_MENTOR_TYPE              
												FROM (SELECT * FROM  DBO.EEO_MENTOR_GRAD_DETAIL 
															WHERE ID IN  
																	(SELECT MAX(ID) AS ID   FROM DBO.EEO_MENTOR_GRAD_DETAIL  -- MAX RECORD FOR VENDOR WITH C_MENTOR_TYPE
							 											WHERE C_MENTOR_TYPE='MENTOR' --  Mentor firms only
																		GROUP BY VENDORID,C_MENTOR_TYPE 
																		)
						 								) GD  , EEO_VENDOR EV
												WHERE GD.VENDORID=EV.VENDORID
													  AND EV.MENTORFLAG IN (6) -- only those vendors marked as  MENTOR
											) AS P
						WHERE TYPE = 'P'
						AND DATEADD(YEAR,NUMBER+1,P.START_DATE)   <= 
								DATEADD( DAY, ISNULL(365-ISNULL(@AssessmentEndDateGracePeriod,0),0),      
															CASE WHEN P.END_DATE >= getdate() THEN getdate()  -- Consider today date if P.END_DATE is greater or equal to P.END_DATE
																ELSE P.END_DATE
															END)   

					 	AND GETDATE()  NOT BETWEEN  DATEADD( DAY, ISNULL(@AssessmentStartDateGracePeriod,0), P.START_DATE)  -- 
												AND
										        DATEADD( DAY, ISNULL(@AssessmentEndDateGracePeriod,0),DATEADD(YEAR,NUMBER+1,P.START_DATE))  

						  
				) X 
	) AS Y WHERE  NOT EXISTS ( 
                SELECT 1 FROM DBO.EEO_MATRIX M 
                WHERE Y.VENDORID = M.VENDORID 
                    AND Y.PERIODID = M.INTV_SEQ
                    AND M.ASST_TYPE ='Y'
					AND M.WORKFLOWTYPE ='MentorYearly'
					AND M.INTV_COMPLETED=1
         )
         
     
END
