﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierCredit
Purpose:	Delete a row from SupplierCredit table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
3/11/2008		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure DeleteSupplierCredit
	@id int
as

delete SupplierCredit
where Id = @id
return @@RowCount

