﻿CREATE PROCEDURE DeleteSupplierLogo 
(
@supplierId int
)AS
Begin
	Update Supplier set LogoId=null where Id = @supplierId
End


