﻿










CREATE procedure [dbo].[CopyPlanSubcontractorCategory]	
	@planSubcontractorId int, 
	@newPlanSubcontractorId int,
	@changeUser nvarchar(50)
as
begin
	insert [PlanSubcontractorCategory]
		( 
			PlanSubcontractorId, 
			CategoryId, 
			ChangeUser, 
			ChangeDate
		)
	select   
			@newPlanSubcontractorId, 
			CategoryId, 
			@changeUser, 
			GETDATE()
	from
		[PlanSubcontractorCategory]
	where
		PlanSubcontractorId=@planSubcontractorId
	
end



 


































