﻿/*
*********************************************************************************************************************
Procedure:	DeletePlanWaiverProject
Purpose:	Delete a row from PlanWaiverProject table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
9/3/2010		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
Create procedure DeletePlanWaiverProject
	@id int
as

delete PlanWaiverProject
where Id = @id
return @@RowCount

