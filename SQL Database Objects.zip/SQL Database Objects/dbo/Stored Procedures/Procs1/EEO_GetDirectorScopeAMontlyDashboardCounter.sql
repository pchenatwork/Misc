﻿/*
*********************************************************************************************************************
Procedure:	 
Purpose:	 
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
09/11/2015		Syed			    Created
*********************************************************************************************************************
*/
CREATE PROCEDURE [dbo].[EEO_GetDirectorScopeAMontlyDashboardCounter]
(
     @ret int OUTPUT
)
AS

Begin

    declare @tableVar table
    (
         Vendorid int
    )

	  
    
    Insert into @tableVar
       exec  dbo.EEO_GetDirectorScopeAMontlyVendors  



    
    SELECT @ret = Count(*)FROM @tableVar
    IF (@ret IS NULL) 
        SET @ret = 0;
        
                                             
                                      
    
END
