﻿
/*
*********************************************************************************************************************
Procedure:	DeleteBidderApprenticeshipProgram
Purpose:	Delete a row from BidderApprenticeshipProgram table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
12/31/2009		AECSOFTUSA\angel			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteBidderApprenticeshipProgram]
	@id int
as

delete BidderApprenticeshipProgram
where Id = @id
return @@RowCount


