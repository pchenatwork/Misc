﻿/*
*********************************************************************************************************************
Procedure:	DeleteSupplierVettingGroups
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
11/27/2007	Lily Xiong		Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteSupplierVettingGroups]
	@vettingGroupId int,
	@supplierVettingGroupsXml ntext
AS
Declare @hdoc int

-- Convert GroupSupplier data from XML to in memory table. 
EXEC sp_xml_preparedocument @hDoc OUTPUT, @supplierVettingGroupsXml

declare @supplier Table
(
	SupplierId int
)

Insert Into @supplier(SupplierId)
Select SupplierId
FROM OPENXML(@hDoc, '/ArrayOfSupplierVettingGroup/SupplierVettingGroup', 1)
WITH
(
	SupplierId int
)

--Release the internal representation of the XML document.
EXEC sp_xml_removedocument @hDoc

Begin Transaction

delete from SupplierVettingGroup
Where VettingGroupId = @vettingGroupId
and SupplierId in (Select SupplierId From @supplier)

delete from SupplierVetting
Where SupplierId in (Select SupplierId From @supplier)
and VettingId not in (Select VettingId From SupplierVettingGroup Where SupplierId in (Select SupplierId From @supplier))
and Status = 1

if @@error = 0
begin
	Commit Transaction
	return 1
end
else
begin
	RollBack Transaction
	return 0
end



