USE [NYCSCA_VAS_STAGE]
GO

/****** Object:  StoredProcedure [dbo].[auditlog_Resubmit_From_Transaction]    Script Date: 2/28/2019 9:49:26 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[auditlog_Resubmit_From_Transaction] 
       @BadTxnID int,
          @StartAtThisTxn int = 1
AS
BEGIN
       SET NOCOUNT ON;

       print concat('Resubmitting items for transaction: ',@BadTxnID)

       declare @VASTableName varchar(50) = ''
       declare @VASid int = 0
       declare @TxnsTouched table (TransactionID int)
       declare @cursor as cursor
       --
       set @cursor = cursor for
              select distinct tablename, vasid from auditlog
              where transactionid = @BadTxnID
              order by tablename

       -- loop variables
       declare @cmsrows int = 0
       declare @cmstable varchar(50)
       declare @peektable table (vid int)
       declare @peeksql nvarchar(1000)
       declare @lastaction nvarchar(10)
       declare @actiontbl table (txn int, lst nvarchar(10))
          declare @startpoint int = 0

          -- set starting point for tablerow updates
          --    can either start from this transaction forward, or can do all historical including prior to this transaction
          if @StartAtThisTxn = 1
          begin

                -- find the beginning auditlog ID for this txn and specify that as the starting point
                select top 1 @startpoint = Id from auditlog where TransactionId = @BadTxnID order by Id asc

          end

       open @cursor
       fetch next from @cursor into @VASTableName, @VASid
       while @@FETCH_STATUS = 0
       begin
              
              print concat('Processing ',@VASTableName, ' ',@VASid)

              -- reset loop variables
              delete from @peektable
              delete from @actiontbl

              -- for each tablename/recordid pair

              select top 1 @cmstable = CMSTableName from vas_cms_map where VASTableName = @VASTableName
              set @peeksql = 'select * from openquery(NYCSCA_CMS, ''select VASId from ' + @cmstable + ' where VASId = ' + cast(@VASid as varchar(10)) + ''')'

              insert @peektable
                     exec sp_executesql @peeksql

              select @cmsrows = count(*) from @peektable

              -- get last action for this tablerow
              insert into @actiontbl (txn,lst)
                     select Top 1 TransactionId, [Action] from auditlog where tablename = @VASTableName and VASId = @VASid group by TransactionId, [Action] order by TransactionId desc
              select @lastaction = lst from @actiontbl

              if @lastaction not in ('delete')
              begin
                     -- our last update was not a delete, replay all updates for this tablerow 
                     insert into @TxnsTouched
                       exec auditlog_Replay_All_TableRow @VASTableName, @VASid, @startpoint, @cmsrows
              end
              else
                     if @cmsrows > 0
                     begin
                           -- our last update was a delete but rows still exist, replay updates
                           --   when we delete from SubcontractorCategory the records remain in CMS, not sure why but that might result in unnecessary work
                           insert into @TxnsTouched
                             exec auditlog_Replay_All_TableRow @VASTableName, @VASid, @startpoint, @cmsrows
                     end
                     else
                           print concat('Skipping resync for ',@VASTableName,' ',@VASid,' because not in CMS and last action was delete') 
              
              fetch next from @cursor into @VASTableName, @VASid

       end

       close @cursor

       -- we just replayed all prior & subsequent updates to these tablerows,
       --  but what about the other tablerows in subsequent failed transactions that are still in 'E'?
       -- Touched transactions should be checked manually for orphaned 'E' records where others in it are now 'S'
       
       print 'Touched transactions:'

       declare @touched varchar(max)
       declare @txn int = 0
       set @cursor = cursor for
              select distinct TransactionID from @TxnsTouched order by TransactionID asc

       open @cursor
       fetch next from @cursor into @txn
       while @@FETCH_STATUS = 0
       begin
              
              if LEN(@touched) > 0
                     set @touched = @touched + ','

              set @touched = concat(@touched,@txn)

              fetch next from @cursor into @txn
       end    

       print @touched
       print 'Review those transactions for orphaned error records'

       close @cursor
       deallocate @cursor

END
GO


