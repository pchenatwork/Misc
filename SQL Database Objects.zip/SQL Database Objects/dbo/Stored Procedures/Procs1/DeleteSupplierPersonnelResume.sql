﻿



CREATE PROCEDURE [dbo].[DeleteSupplierPersonnelResume]
(
@id int
)AS
Begin

Update  SupplierPersonnel
set  ResumeFilename ='',
	ResumeId = null
Where Id = @id
return @@rowcount
End










