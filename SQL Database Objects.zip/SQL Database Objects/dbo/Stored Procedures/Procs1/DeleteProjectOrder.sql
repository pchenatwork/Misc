﻿/*
*********************************************************************************************************************
Procedure:	DeleteProjectOrder
Purpose:	Delete a row from ProjectOrder table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
5/21/2010		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[DeleteProjectOrder]
	@id int
as

delete ProjectOrderSupplierDetail
where ProjectOrderSupplierId in (select Id from ProjectOrderSupplier where ProjectOrderId=@id)

delete ProjectOrderSupplier
where ProjectOrderId=@id

delete ProjectOrderDetail
where ProjectOrderId=@id

delete ProjectOrder
where Id = @id
return @@RowCount

