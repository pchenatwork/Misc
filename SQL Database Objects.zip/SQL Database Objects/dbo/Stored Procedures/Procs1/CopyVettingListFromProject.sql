﻿

/*
*********************************************************************************************************************
Procedure:	CopyVettingListFromProject
Purpose:	
Input XML:
------------------------------------------------------------------------------------------------------------------------------------------------------------
Date		Developer			Notes
==========	===================	===============================
11/14/2008	Lily Xiong			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[CopyVettingListFromProject]
	@newProjectId int,
	@newLibraryId int,
	@oldProjectId int,
	@oldLibraryId int
AS
Begin

if @newLibraryId = 0
	Set @newLibraryId = null

-- Insert VettingList
Insert Into VettingList
( 
	Name,
	Description,
	Type,
	HasExpireDate,
	ExpireDate,
	Url,
	InternalUse,
	HasSchedule,
	WorkflowId,
	Status,
	ProjectId,
	LibraryId,
	VettingId,
	CopyId
)
Select 
	Name,
	Description,
	Type,
	HasExpireDate,
	ExpireDate,
	Url,
	InternalUse,
	HasSchedule,
	WorkflowId,
	1,
	@newProjectId,
	@newLibraryId,
	newid(),
	Id
From VettingList
Where ProjectId = @oldProjectId
and isnull(LibraryId, 0) = @oldLibraryId

-- Insert VettingSchedule
Insert Into VettingSchedule
(
	VettingId,
	DueType,
	DueDate,
	DueEvent,
	DueNumber,
	DuePeriod,
	Frequency,
	RepeatNumber,
	WeekDays,
	ScheduleType,
	DayOfMonth,
	WeekNumber,
	SelectedMonths,
	EndType,
	EndDate,
	EndEvent,
	EndPeriod,
	RemindNumber,
	RemindPeriod
)
Select
	v.Id,
	s.DueType,
	s.DueDate,
	s.DueEvent,
	s.DueNumber,
	s.DuePeriod,
	s.Frequency,
	s.RepeatNumber,
	s.WeekDays,
	s.ScheduleType,
	s.DayOfMonth,
	s.WeekNumber,
	s.SelectedMonths,
	s.EndType,
	s.EndDate,
	s.EndEvent,
	s.EndPeriod,
	s.RemindNumber,
	s.RemindPeriod
From VettingSchedule s, VettingList v
Where s.VettingId = v.CopyId
and v.ProjectId = @newProjectId
and isnull(v.LibraryId, 0) = isnull(@newLibraryId, 0)

-- Insert VettingQuestion
Declare @vettingId int
Declare @questionId int
Declare @newQuestionId int
declare @allQuestion table
(
	Id int,
	ParentId int,
	VettingId int
)
Insert Into @allQuestion(Id, ParentId, VettingId) 
Select q.Id, q.ParentId, v.Id
From VettingQuestion q, VettingList v
Where q.VettingId = v.CopyId
and v.ProjectId = @newProjectId
and isnull(v.LibraryId, 0) = isnull(@newLibraryId, 0)
and q.IsActive = 'Y'

While (@@rowcount>0)
Begin
	Insert Into @allQuestion(Id, ParentId, VettingId) 
	Select q.Id, q.ParentId, v.Id
	From VettingQuestion q, VettingList v
	Where q.VettingId = v.CopyId
	And q.Id Not In ( Select Id From @allQuestion )
	And q.ParentId In ( Select Id From @allQuestion )
	And q.IsActive = 'Y'
End
declare @tempQuestion Table
(
	Id				int,
	ParentId		int,
	QuestionTypeId	int,
	QuestionText	ntext,
	Sequence		int,
	IsRequired		char(1),
	RowNumber		int,
	ColumnNumber	int,
	MaxLength		int,
	AnswerFormat	nvarchar(50),
	MaxValue		nvarchar(50),
	MinValue		nvarchar(50),
	DefaultValue	nvarchar(500),
	RepeatDirection	nvarchar(50),
	Score			int,
	VettingId		int
)
Insert Into @tempQuestion
(
	Id,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,RowNumber,ColumnNumber,
	MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,RepeatDirection,Score,VettingId
)
Select 
	q.Id,q.ParentId,q.QuestionTypeId,q.QuestionText,q.Sequence,q.IsRequired,q.RowNumber,q.ColumnNumber,
	q.MaxLength,q.AnswerFormat,q.MaxValue,q.MinValue,q.DefaultValue,q.RepeatDirection,q.Score,a.VettingId
From VettingQuestion q, @allQuestion a
Where q.Id = a.Id
--Insert VettingQuestion
While Exists( Select * From @tempQuestion )
Begin
	Select @questionId = Id, @vettingId = VettingId From @tempQuestion Order By ParentId desc, Id desc
	
	Insert Into VettingQuestion
	(
		VettingId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,RowNumber,ColumnNumber,
		MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,RepeatDirection,Score,IsActive
	)
	Select 
		@vettingId,ParentId,QuestionTypeId,QuestionText,Sequence,IsRequired,RowNumber,ColumnNumber,
		MaxLength,AnswerFormat,MaxValue,MinValue,DefaultValue,RepeatDirection,Score, 'Y'
	From @tempQuestion
	Where Id = @questionId
	Set @newQuestionId = @@identity

	--Update record in @tempQuestion, make their QuestionId to new QuestionId
	Update @tempQuestion Set ParentId = @newQuestionId Where ParentId = @questionId
	
	Insert Into VettingAnswer(QuestionId,AnswerText,AnswerValue,Sequence,AnswerType,Score)
	Select @newQuestionId,AnswerText,AnswerValue,Sequence,AnswerType,Score
	From VettingAnswer
	Where QuestionId = @questionId

	Insert Into VettingAttachment(VettingQuestionId,Filename,Description,AttachmentId)
	Select @newQuestionId,Filename,Description,AttachmentId
	From VettingAttachment
	Where VettingQuestionId = @questionId

	Delete @tempQuestion Where Id = @questionId
End

return 1

End








