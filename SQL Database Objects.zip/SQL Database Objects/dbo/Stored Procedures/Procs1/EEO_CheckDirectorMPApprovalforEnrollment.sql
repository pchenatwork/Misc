﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE Procedure [dbo].[EEO_CheckDirectorMPApprovalforEnrollment]
	-- Add the parameters for the stored procedure here
	@vendorId int,
	@approvalRejection char
AS
BEGIN
	declare @count int
	

	--select * from EEO_VENDOR_PROPERTY_DESC where propertype='MentorGraduation'

	if @approvalRejection='2'
		begin
		print 'asdasd'
				set @count =(
					select 
						count(*)
					from
						EEO_VENDOR_PROPERTY e
					where
						vendorid=@vendorid
						and e.PROPERTYID=16
						--and (@approvalRejection ='' or e.PROPERTYVALUE=iif(@approvalRejection='2','Approved','Denied'))

					)
		end
	else if @approvalRejection='3'
		begin
			print 'erere'
				set @count =(
					select 
						count(*)
					from
						EEO_VENDOR_PROPERTY e
					where
						vendorid=@vendorid
						and e.PROPERTYID=27
						and e.PROPERTYVALUE='Approved'
						--and (@approvalRejection ='' or e.PROPERTYVALUE=iif(@approvalRejection='2','Approved','Denied'))

					)
		end
	else
		begin
		print 'asdasd'
		set @count =(
					select 
						count(*)
					from
						EEO_VENDOR_PROPERTY e
					where
						vendorid=@vendorid
						and e.PROPERTYID=14
						and (@approvalRejection ='' or e.PROPERTYVALUE=iif(@approvalRejection='A','Approved','Denied'))

					)
		
		end

	select @count
	return @count
END
