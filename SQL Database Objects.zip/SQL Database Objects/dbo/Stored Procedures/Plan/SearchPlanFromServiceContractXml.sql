﻿IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[SearchPlanFromServiceContractXml]'))
   EXEC('CREATE PROCEDURE [dbo].[SearchPlanFromServiceContractXml] AS BEGIN SET NOCOUNT ON; END')
GO


/*
*******************************************************************************
Procedure:	SearchPlanFromServiceContractXml
Purpose:	Get mock-up plan data by Service Contract (SUP may or may not created in VAS Yet).
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
04/00/2020		PCHEN				Created
*******************************************************************************
*/

ALTER procedure [dbo].[SearchPlanFromServiceContractXml]
       @pageSize int,
       @pageNumber int,
       @orderBy nvarchar(50),
       @sequence nvarchar(10),
       @status int,
       @extraXml ntext
as
begin

BEGIN -- Extract search tokens from extraXML to in memory table. 
-- Search tokens
DECLARE @contractNo varchar(50) = ''
      , @solicitNo varchar(50) = ''
      , @Company varchar(100) = ''
      , @TaxId varchar(100) = ''
      , @CTypeCode VARCHAR(10)
      , @ExecFromDate VARCHAR(50)
      , @ExecToDate VARCHAR(50)
      , @TermFromDate VARCHAR(50)
      , @TermToDate VARCHAR(50)

declare @hdoc int
declare @extra Table
(
       Name nvarchar(50),
       Value nvarchar(2000)
)
EXEC sp_xml_preparedocument @hdoc OUTPUT, @extraXml
INSERT INTO @extra
(
       Name,
       Value
)
SELECT
       Name,
       Value
FROM OPENXML(@hDoc, '/ArrayOfExtra/Extra', 1)
WITH
(
       Name nvarchar(50),
       Value nvarchar(2000)
)
select @contractNo=Value from @extra where Name='ContractNo'
select @solicitNo=Value from @extra where Name='SolicitNo'
select @Company=Value from @extra where Name='Company'
select @TaxId=Value from @extra where Name='TaxId'
select @ExecFromDate=Value from @extra where Name='ExecFromDate'
select @ExecToDate=Value from @extra where Name='ExecToDate'
select @TermFromDate=Value from @extra where Name='TermFromDate'
select @TermToDate=Value from @extra where Name='TermToDate'
EXEC sp_xml_removedocument @hdoc
END 

DECLARE @tBase TABLE(
    Id INT,
    PlanId uniqueidentifier, PlanGroup VARCHAR(20),
    ContractNo VARCHAR(50), ContractType VARCHAR(50), Description VARCHAR(100),
    SolicitNo VARCHAR(50),  SolicitSeq INT,
    AwardAmount decimal(18,2), AwardDate DATETIME,
    ExecutionDate DATETIME,  -- Using ExecutionDate from [MV_SOLICIT_CONTRACT]
    FederalId VARCHAR(15), Company VARCHAR(200),
    Status int, Statusname VARCHAR(50),
    WorkflowId INT, TransactionId INT
    )
        
INSERT INTO @tBase
SELECT P.Id, P.PlanId, ISNULL(P.PlanGroup, '2')  -- PlanGroup='2' dedicated to A&E Service Contract 
, ISNULL(S.C_CONTRACT, S.ME_CONTRACT) AS C_CONTRACT, S.C_CTYPE_CODE, S.VC_DESCRIPTION
, S.C_SOLICIT, S.N_SOLICIT_SEQ
, S.CONTRACT_AWARD_AMOUNT + ISNULL(A.AMT, 0) AS AWARD_AMT, C.SD_AWARD_INTENT_LTR as AWARD_DATE
, C.SD_EXECUTION
, V.FederalId, V.Company
, ISNULL(P.Status, 0), P.StatusName
, P.WorkflowId, P.TransactionId
FROM MV_SOLICIT_CONTRACT S 
-- LEFT JOIN CMS_PROJECT_RFP R ON B.N_SOLICIT_SEQ = R.N_SOLICIT_SEQ 
JOIN cms_CONTRACT C ON ISNULL(S.C_CONTRACT, S.ME_CONTRACT) = C.C_CONTRACT
LEFT JOIN (SELECT C_CONTRACT, SUM(M_AWARD_AMOUNT) AS AMT FROM ORCMS_MV_SUPAGR GROUP BY C_CONTRACT) A ON A.C_CONTRACT = C.C_CONTRACT
LEFT JOIN [Plan] P ON  P.ContractNo = C.C_CONTRACT AND S.N_SOLICIT_SEQ = P.SolicitSeq
LEFT JOIN Vendor V ON ISNULL(S.C_VENDOR_ID, S.ME_VENDOR_ID) = V.FederalId
WHERE S.C_CTYPE_CODE IN ('AC', 'AE','AL','AM') -- 'AS') -- OR R.C_SUB_CODE in (490,493,494,495,496,470))
AND (LEN(@contractno) = 0 OR CONVERT(INT, [dbo].[fnStripNonnumericChars](@contractno)) = CONVERT(INT, [dbo].[fnStripNonnumericChars](C.C_CONTRACT)))
AND (LEN(@SolicitNo) = 0 OR (LEN(@solicitNo) > 2 AND S.C_SOLICIT LIKE '%'+@SolicitNo+'%'))
AND (LEN(@Company)=0 OR (LEN(@Company) > 2 AND V.Company LIKE '%' + @Company + '%'))
AND (LEN(@TaxId) = 0 OR V.FederalId = @TaxId )
AND (@Status=-1 OR p.Status=@Status)
AND (@ExecFromDate='1/1/1900' or C.SD_EXECUTION >= @ExecFromDate)
AND (@ExecToDate='1/1/1900' or C.SD_EXECUTION <= @ExecToDate)
AND (@TermFromDate='1/1/1900' or 
    ISNULL(ISNULL(ISNULL(C.RENEWAL_TERM_TO_3, C.RENEWAL_TERM_TO_2), C.RENEWAL_TERM_TO_1), C.INITIAL_TERM_TO) >= @TermFromDate)
AND (@TermToDate='1/1/1900' or 
    ISNULL(ISNULL(ISNULL(C.RENEWAL_TERM_TO_3, C.RENEWAL_TERM_TO_2), C.RENEWAL_TERM_TO_1), C.INITIAL_TERM_TO) <= @TermToDate)

declare @totalcount int = @@ROWCOUNT 

select
       ISNULL(T.Id, ROW_NUMBER() OVER(ORDER BY SolicitNo) * -1) As '@Id', -- If Id doesn't exist, using negetive row_number
       T.PlanId              As '@PlanId',
       T.ContractType          As '@Type',
       T.SolicitSeq           As '@SolicitSeq',
       T.SolicitNo        As '@SolicitNo',
       T.ContractNo           As '@ContractNo', 
       '?'  As '@MeContractNo',
       T.Description          As '@Description',
       T.ExecutionDate As '@NTPDate',   ---*** Note Using ExecutionDate as NTP Date
       T.AwardDate  AS '@AwardDate',
       T.AwardAmount       As '@ContractAmount',
       T.FederalId          as '@FederalId',
       T.Company  AS '@Company',
       T.Status        As '@Status',
       T.StatusName           As '@StatusName',
       T.WorkflowId           As '@WorkflowId',
       T.TransactionId        As '@TransactionId',
       '??Comments'            As '@Comments',
       '??EEOContactName'             As '@EEOContactName',
       '??EEOContactPhone'            As '@EEOContactPhone',
       '??EEOContactEmail'            As '@EEOContactEmail',
       -1          As '@SubcontPercentage',   --Total Proposed %
       -1            As '@MWLBEGoal',
       -1           As '@RevisedMWLBEGoal',
       -1           As '@WaiverPercentage',
       -1          As '@RevisedPercentage',
       NULL           As '@PlanApprovalDate',
       '?'             As '@IsWaiver',
       -1 As'@ProjectDuration',
       -1  As '@SubmittedAmount', --Total Submitted $
       -1 as '@EstimateAmount', --Total Proposed $
       -1 As '@MWLBEEstimateAmount',
       -1 As '@MWLBEEstimatePercentage', --Proposed MWLBE %
       -1  As '@ApprovedAmount', --Total Actual $
       -1  As '@MWLBEApprovedAmount', --Total Actual MWLBE $
       -1  As '@MWLBEApprovedPercentage', -- Actual MWLBE %
       -1 As '@PercentageCompletion',
       -1 As '@PerformanceInclusion',
       '??Analyst' as '@Analyst',
       '??AnalystFullName' as '@AnalystFullName',
       '??SchoolName' as '@SchoolName',
       '??BoroName' as '@BoroName',
       '??ProjectOfficer' as '@ProjectOfficer',
       T.PlanGroup AS '@PlanGroup',
       '??ChangeUser??'           As '@ChangeUser',
       NULL           As '@ChangeDate',  
       @totalcount          as '@TotalRecordNumber',
       ''     As '@Result'
from @tBase T
ORDER BY 
    CASE WHEN UPPER(@sequence) IN ('DESC') THEN 
        CASE @orderBy
            WHEN 'Company' THEN T.Company
            WHEN 'FederalId' THEN T.FederalId
            WHEN 'ContractNo' THEN T.ContractNo
            WHEN 'SolicitNo' THEN T.SolicitNo
            ELSE '' 
        END
    END DESC,  
    CASE WHEN UPPER(@sequence) NOT IN ('DESC') THEN 
        CASE @orderBy
            WHEN 'Company' THEN T.Company
            WHEN 'FederalId' THEN T.FederalId
            WHEN 'ContractNo' THEN T.ContractNo
            WHEN 'SolicitNo' THEN T.SolicitNo
            ELSE ''
        END 
    END ASC
OFFSET @pageSize * @pageNumber ROWS
FETCH NEXT @pageSize ROWS ONLY
FOR XML PATH('Plan'), ROOT('ArrayOfPlan')
end
GO

/*
exec SearchPlanFromServiceContractXml @pageSize=15,@pageNumber=0,@orderBy=N'Company',@sequence=N'DESC',@status=-1,@extraXml=N'<?xml version="1.0"?>
<ArrayOfExtra xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Extra Name="ContractNo" Value="" />
  <Extra Name="SolicitNo" Value="" />
  <Extra Name="TaxId" Value="" />
</ArrayOfExtra>'
*/