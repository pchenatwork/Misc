﻿IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[GetPlanFinancialXML]'))
   EXEC('CREATE PROCEDURE [dbo].[GetPlanFinancialXML] AS BEGIN SET NOCOUNT ON; END')
GO

/*
*******************************************************************************
Procedure:	GetPlanFinancialXML
Purpose:	Get Plan Financial data with PaymentItems
Backgroud:  For Prof/Service Contract MWBE compliance Rating
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
05/00/2020		PCHEN				Created
*******************************************************************************
*/
ALTER procedure [dbo].[GetPlanFinancialXML]
       @PlanId int
as

SELECT 
    P.Id as '@PlanId',
    p.ContractNo as '@ContractNo',
    CAST(p.ContractAmount as decimal(12,2)) As '@AwardAmt',
    P.AwardDate As '@AwardDate',
    (SELECT SUM(M_AWARD_AMOUNT) from ORCMS_MV_SUPAGR S WHERE S.C_CONTRACT = P.ContractNo) AS '@SupplementalAmt',
    (SELECT SUM(N_ATP_AMOUNT + N_CO_AMOUNT) From ORCMS_VW_ATP_HEADER A where A.C_CONTRACT =  P.ContractNo) AS '@TotalPaymentAmt',
    (  
        SELECT P.Id as '@PlanId'
            , A.C_CONTRACT as '@ContractNo'
            , RTRIM(S.FederalId) AS '@FederalId'
            , CASE WHEN RTRIM(S.FederalId) = P.FederalId THEN 'P' ELSE 'S' END AS '@PrimeSub'
            , S.IsMBE AS '@IsMBE', S.IsWBE AS '@IsWBE'
            , (A.N_ATP_AMOUNT+A.N_CO_AMOUNT)*B.F_PCT AS '@PaymentAmt'
            --, B.F_PCT AS '@PaymentPct'
            , A.D_ATP_APPROVED_ON AS '@PaymentDate'
            , A.C_NTP_NO AS '@RefNo'
            , CONVERT(VARCHAR(50),B.F_PCT *100) + '|' + CONVERT(VARCHAR(50), (A.N_ATP_AMOUNT+A.N_CO_AMOUNT)) AS '@Result'
        FROM [PlanSubcontractor] S 
        JOIN ORCMS_VW_ATP_HEADER A ON P.ContractNo = A.C_CONTRACT
        JOIN ORCMS_VW_ACPT_TRANS_DIST B ON A.C_NTP_NO = B.C_NTP_NO AND B.C_TAX_ID = S.FederalId
        WHERE P.Id=S.PlanId
        FOR XML PATH('PlanPaymentItem'), ROOT('ArrayOfPlanPaymentItem'), TYPE  
    )
FROM [Plan] P
WHERE p.Id = @PlanId
FOR XML PATH('PlanFinancial')  

GO
/*
exec GetPlanFinancialXML @PlanId=3480
*/
