﻿IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[GetPlanXml]'))
   EXEC('CREATE PROCEDURE [dbo].[GetPlanXml] AS BEGIN SET NOCOUNT ON; END')
GO
/*
*********************************************************************************************************************
Procedure:	GetPlanXml
Purpose:	Get a row from Plan table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/11/2010		AECSOFTUSA\Angel	Created
05/04/2020		PCHEN				Sync with Prod
	Map 'Company' to '@Company'
*********************************************************************************************************************
*/
ALTER procedure [dbo].[GetPlanXml]
	@id int
as

declare @company nvarchar(50)
declare @reviewer nvarchar(50)
declare @duration nvarchar(50)


set @company = (select Company from vendor where FederalId = (select FederalId from [Plan] where ID=@id))
set @reviewer= (select CONVERT(nvarchar(50), propertytext) from PlanProperty where PlanId = @id and PropertyId = 15)


--select
--	@Duration = ISNULL(n_duration, 0)
--from
--	MV_SOLICIT_CONTRACT mv	
--inner join
--	[Plan] p
--on
--	isnull(mv.c_contract, '') = isnull(p.ContractNo, '') 
--	and isnull(mv.me_contract, '') = isnull(p.MeContractNo, '')
--	and isnull(mv.n_solicit_seq, 0) = isnull(p.SolicitSeq, 0)
--where
--	p.Id = @id
		
					
select
	p.Id		As '@Id',
	p.PlanId		As '@PlanId',
	p.Type		As '@Type',
	p.ProjectId		As '@ProjectId',
	p.ContractId		As '@ContractId',
	p.SolicitSeq		As '@SolicitSeq',
	p.SolicitNo       As '@SolicitNo',
	p.ContractNo		As '@ContractNo',
	p.MeContractNo	As '@MeContractNo',
	p.SupplierId		As '@SupplierId',
	p.FederalId		As '@FederalId',
	p.ContractAmount	As '@ContractAmount',
	p.Description		As '@Description',
	p.Comments		As '@Comments',
	p.EEOContactName		As '@EEOContactName',
	p.EEOContactPhone		As '@EEOContactPhone',
	p.EEOContactEmail		As '@EEOContactEmail',
	p.SubcontPercentage		As '@SubcontPercentage',  --Total Proposed %
	p.MWLBEGoal		As '@MWLBEGoal',
	p.RevisedMWLBEGoal		As '@RevisedMWLBEGoal',
	p.WaiverPercentage		As '@WaiverPercentage',
	p.RevisedPercentage		As '@RevisedPercentage',
	p.PlanApprovalDate		As '@PlanApprovalDate',
	p.IsWaiver		As '@IsWaiver',
	p.ProjectDuration  As '@ProjectDuration',
	p.AwardDate As '@AwardDate',
	p.Status		As '@Status',
	p.StatusName		As '@StatusName',
	p.WorkflowId		As '@WorkflowId',
	p.TransactionId		As '@TransactionId',
	dbo.SubmittedAmount(@id)  As '@SubmittedAmount', -- Total Submitted $
	
	--isnull(p.ContractAmount, 0) *  isnull(p.SubcontPercentage, 0)/100 as '@EstimateAmount', --Total Proposed $
	
	/*SUP Calculation Grid changes Release 5.0 */
	--isnull((select sum(estvalue) from plansubcontractor where planid=p.id and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))),0) as '@EstimateAmount', 
	/*New Change 06/10/2015*/
	CASE when exists(select * from PlanSubcontractorPro where planid=p.id) then
	isnull((select sum(estvalue) from PlanSubcontractorPro where planid=p.id and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))),0) 
	else
	isnull((select sum(estvalue) from PlanSubcontractor where planid=p.id and safid=0 and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))),0) 
	end
	as '@EstimateAmount', 


	dbo.EstimateMWLBESubcontractorAmount(@id) + dbo.EstimateMWLBESupplierAmount(@id) As '@MWLBEEstimateAmount', --Total Proposed MWLBE $
	/*New Change 06/10/2015*/


	--CONVERT([decimal](18,2), dbo.Percentage((dbo.EstimateMWLBESubcontractorAmount(@id) + dbo.EstimateMWLBESupplierAmount(@id)), isnull(p.ContractAmount, 0) *  isnull(p.SubcontPercentage, 0)/100)*100, 0) As '@MWLBEEstimatePercentage', --Proposed MWLBE %
	convert(decimal(18,2),dbo.Percentage((dbo.EstimateMWLBESubcontractorAmount(@id) + dbo.EstimateMWLBESupplierAmount(@id)), 
					isnull(
							(
								select sum(estvalue) 
								from plansubcontractor 
								where planid=p.id 
								and safid=0
							and  rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, ''))))
							,0)
						)*100) As '@MWLBEEstimatePercentage',

	CASE when exists(select * from PlanSubcontractorPro where planid=p.id) then
		case when p.contractamount !=0 then	isnull((select sum(estvalue) from PlanSubcontractorPro where planid= p.id and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))
)/ p.contractamount,0) *100
		else null end 
	ELSE
		case when p.contractamount !=0 then	isnull((select sum(estvalue) from PlanSubcontractor where planid= p.id and safid=0 and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))
)/ p.contractamount,0) *100
		else null end 
	END
	as '@EstimateAmountPercentage',
	
	dbo.ApprovedSubcontractorAmount(@id) + dbo.ApprovedSupplierAmount(@id) As '@ApprovedAmount', --Total Actual $
	dbo.ApprovedMWLBESubcontractorAmount(@id) + dbo.ApprovedMWLBESupplierAmount(@id)  As '@MWLBEApprovedAmount', --Total Actual MWLBE $
	dbo.PerformanceInclusion(@id)  As '@MWLBEApprovedPercentage', -- Actual MWLBE %

	dbo.[PercentageCompletion](@id) As '@PercentageCompletion',
	dbo.[PerformanceInclusion](@id) As '@PerformanceInclusion',
	p.ChangeUser		As '@ChangeUser',
	p.ChangeDate		As '@ChangeDate',
	isnull(@company, '')  As '@Result',
	isnull(@company, '')  As '@Company',
	isnull(p.PlanGroup, '') AS '@PlanGroup',

	--TFS# 563 The following email went out when an analyst was closing out a project. 
	--When an analyst close out a project and the evaluation is satisfactory - (in this instance, it was), 
	--there should not be any email sent to the vendor. Can you please stop this email being sent in the future project closeouts?
	isnull((select top 1 propertytext from planproperty 	where propertyid in (31,25) and planid=p.id and cast(propertyText as  varchar(50))='Satisfactory'	),'') as '@Evaluation',
	isnull(convert(nvarchar(50), pp17.propertytext), '') as '@SchoolName',
	isnull(convert(nvarchar(50), pp18.propertytext), '') as '@Property18',
	isnull(convert(nvarchar(50), pp19.propertytext), '') as '@BoroName', 
	(
	select
		i.Id				As '@Id',
		i.PlanId				As '@PlanId',
		i.LLW				As '@LLW',
		i.LLWDesc			As '@LLWDesc',
		i.School			As '@School',
		i.SchoolAddressLine1	As '@SchoolAddressLine1',
		i.SchoolAddressLine2	As '@SchoolAddressLine2',
		i.Boro				As '@Boro',
		i.ZipCode			As '@ZipCode',
		i.ChangeUser		As '@ChangeUser',
		i.ChangeDate		As '@ChangeDate'
	from 
		PlanItem i
	where i.planId = p.Id
	Order By i.LLW
	FOR XML PATH('PlanItem'), ROOT('ArrayOfPlanItem'), TYPE
	)
from 
	[Plan] p
	left outer join
		(select * from planProperty where propertyId = 17) pp17

	on
		p.Id = pp17.PlanId

	left outer join
		(select * from planProperty where propertyId = 18) pp18

	on
		p.Id = pp18.PlanId
	left outer join
		(select * from planProperty where propertyId = 19) pp19

	on
		p.Id = pp19.PlanId
where
	p.Id = @id
FOR XML PATH('Plan')

GO

/*
exec GetPlanXml @id=3479
*/