﻿IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[FindPlanByOutlookXml]'))
   EXEC('CREATE PROCEDURE [dbo].[FindPlanByOutlookXml] AS BEGIN SET NOCOUNT ON; END')
GO
/*    
*******************************************************************************    
Procedure: FindPlanByOutlookXml  
Purpose:  
-------------------------------------------------------------------------------    
Date        Developer           Notes    
==========  =================== ===============================    
?           ?
03/05/2018  PCHEN               Sync with Staging DB
    Copy MWLBEEstimatePercentage logic from GetPlanXML.sql
11/25/2019	TSaru				Fixed IN00142243. 
	Reordered columns to avoid error: Attribute-centric column '@...' must not come after a non-attribute-centric sibling in XML hierarchy in FOR XML PATH.
05/14/2020  PCHEN
	Added PlanGroup to seperate existing SUM and Service Contract SUP
*******************************************************************************    
*/  
ALTER procedure [dbo].[FindPlanByOutlookXml]
--Declare 
	@pageSize int,
	@pageNumber int,
	@orderBy nvarchar(50),
	@sequence nvarchar(10),
	@userId int,
	@type nvarchar(50),
	@userName_Sup nvarchar(50)=''
AS

--Set @pageSize=20
--Set @pageNumber=0
--Set @orderBy=N'ContractNo'
--Set @sequence=N'ASC'
--Set @userId=2
--Set @type=N'FindItem750'

set nocount on

--declare @userName varchar(50)
--Select substring(@roleName,1,charindex('~',@roleName)-1)
--Select @userName=substring(@roleName,charindex('~',@roleName)+1,Len(@roleName))


declare @beginCount int
declare @endCount int
declare @totalcount int
set @beginCount = @pageNumber * @pageSize + 1
set @endCount = @beginCount + @pageSize - 1

declare @username nvarchar(50)
select @username = au.Username from [User] u, aspnet_users au
	where u.Id = @userId and u.UserId = au.UserId
	

Declare @temp Table
(
	PlanId int
)


------------ SUP Status ----------
-- (FindItem740)New Plan
IF ( @type = 'FindItem740' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 0 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))

END

-- (FindItem741) Plan Submitted
IF ( @type = 'FindItem741' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 1 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))

END

-- (FindItem742) Pending Plan Waiver Request
IF ( @type = 'FindItem742' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 3 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))

END

-- (FindItem743)Waiver Request More Info
IF ( @type = 'FindItem743' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 7 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))

END

-- (FindItem744)Plan Compliance Analyst Reviewed with Waiver
IF ( @type = 'FindItem744' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 4 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))

END

-- (FindItem745) Plan Rejected
IF ( @type = 'FindItem745' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 11 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))

END

-- (FindItem746)Waiver More Info Submitted
IF ( @type = 'FindItem746' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 8 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))

END

-- (FindItem747)Plan Compliance Analyst Reviewed
IF ( @type = 'FindItem747' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 2 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))

END

-- (FindItem748)Plan Compliance Manager Reviewed with Waiver
IF ( @type = 'FindItem748' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 5 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))

END

-- (FindItem749)Plan Compliance Verified
IF ( @type = 'FindItem749' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 6 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))

END

---Batch get Percentage Completion 
declare @temp2 table
(
	PlanId int,
	PercentageCompletion float
)
insert into @temp2
(	
	PlanId,
	PercentageCompletion
)
select 
	p.Id,
	v.pct_by_contract
From 
	MV_SOLICIT_CONTRACT v
inner join 
	[plan] p	
on 
	isnull(c_contract, me_contract) = p.ContractNo
	and isnull(v.n_solicit_seq, 0) = isnull(p.solicitSeq, 0)
where 
	p.status in (6)
	
-- (FindItem750)Plan Phase 1 Completed
IF ( @type = 'FindItem750' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Inner join  @temp2 t on s.Id = t.PlanId 
	Inner join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	
		and isnull(t.PercentageCompletion, 0)>=35
		and isnull(t.PercentageCompletion, 0)<50
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
     AND ISNULL(s.PlanGroup, '') = ''

END

-- (FindItem751)Plan Phase 2 Completed
IF ( @type = 'FindItem751' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Inner join @temp2 t on s.Id = t.PlanId 
	Inner join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
		and isnull(t.PercentageCompletion, 0)>=50
		and isnull(t.PercentageCompletion, 0)<90
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
     AND ISNULL(s.PlanGroup, '') = ''

END

-- (FindItem752)Plan Phase 3 Completed
IF ( @type = 'FindItem752' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Inner join @temp2 t on s.Id = t.PlanId
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
		and isnull(t.PercentageCompletion, 0)>=90
		and isnull(t.PercentageCompletion, 0)<95
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
     AND ISNULL(s.PlanGroup, '') = ''
END


-- (FindItem753)Plan Pending Analyst Commitment Review
IF ( @type = 'FindItem753' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 12 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
    
END


-- (FindItem754)Plan Pending Director Commitment Review
IF ( @type = 'FindItem754' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 13 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem755)Plan Pending Sr Director Commitment Review
IF ( @type = 'FindItem755' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 14 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem756)Plan Pending VP Commitment Review
IF ( @type = 'FindItem756' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 15 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem757)Close Out
IF ( @type = 'FindItem757' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and s.status = 16 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem758)Waivers Approved
IF ( @type = 'FindItem758' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and status = 6 and isnull(isWaiver, 'N') ='Y'  AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem759)Waiver Denied
IF ( @type = 'FindItem759' )
BEGIN
	Insert Into @temp ( PlanId )
	select s.Id
	from [Plan] s
	Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=s.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	and isnull(isWaiver, 'N') ='Y' 
	and status = 11 AND ISNULL(s.PlanGroup, '') = ''
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem760)Evaluation Satisfactory
IF ( @type = 'FindItem760' )
BEGIN
	Insert Into @temp ( PlanId )
	select distinct(s.Id)
	from [Plan] s, (select * From PlanProperty where propertyId in (25, 31,15) ) pp
	where s.Id = pp.planId
	and (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), pp.propertytext), ''))  
	and status = 16 AND ISNULL(s.PlanGroup, '') = ''
	and convert(nvarchar(50), pp.PropertyText) = 'Satisfactory'
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem761)Evaluation Marginal
IF ( @type = 'FindItem761' )
BEGIN
	Insert Into @temp ( PlanId )
	select distinct(s.Id)
	from [Plan] s, (select * From PlanProperty where propertyId in (25, 31,15) ) pp
	where s.Id = pp.planId 
	and (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), pp.propertytext), ''))
	and status = 16 AND ISNULL(s.PlanGroup, '') = ''
	and convert(nvarchar(50),pp.PropertyText) = 'Marginal'
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem762)Evaluation Unsatisfactory
IF ( @type = 'FindItem762' )
BEGIN
	Insert Into @temp ( PlanId )
	select distinct(s.Id)
	from [Plan] s, (select * From PlanProperty where propertyId in (25, 31,15) ) pp
	where s.Id = pp.planId 
	and (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), pp.propertytext), ''))
	and status = 16 AND ISNULL(s.PlanGroup, '') = ''
	and convert(nvarchar(50),pp.PropertyText) = 'Unsatisfactory'
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

---- (FindItem763)GC's Evaluation of Subs
--IF ( @type = 'FindItem763' )
--BEGIN
--	Insert Into @temp ( PlanId )
--	select s.Id
--	from [Plan] s
--	where s.status = 16
--	and (( @userId = 1 and s.type = 'Line')
--		or ( @userId = 2 and s.type = 'CIP')
--		or ( @userId = 3 and s.type = 'Mentor')
--		or ( @userId = 4 and s.type = 'Mentor Grad'))
--END

---- (FindItem764)Subs Evaluation of GC's
--IF ( @type = 'FindItem764' )
--BEGIN
--	Insert Into @temp ( PlanId )
--	select s.Id
--	from [Plan] s
--	where s.status = 16
--	and (( @userId = 1 and s.type = 'Line')
--		or ( @userId = 2 and s.type = 'CIP')
--		or ( @userId = 3 and s.type = 'Mentor')
--		or ( @userId = 4 and s.type = 'Mentor Grad'))
--END

------------ End SUP Status ----------


/***********Release 4.0******************/
IF ( @type = 'FindItem789' )
BEGIN
Insert Into @temp ( PlanId )
   select distinct planid
   from
   (
   select p.planid
   from 
         plansubcontractor p
         inner join suppliervetting s on s.contactid=p.supplierid
         Inner join (select * from planProperty where propertyId in (25, 31,15)) B On B.PlanId=p.planId
         Inner join [Plan] pl on pl.id=p.planid
   where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
   --(@userName='' or @userName= isnull(convert(nvarchar(50), B.propertytext), '')) 
   and 
   s.VettingId =2
   and s.VettingName like '%'+ p.Contractno + '%'
   --and s.contactid=p.supplierid
   and s.status=3
and s.Review =0
      and (( @userId = 1 and pl.type = 'Line')
		or ( @userId = 2 and pl.type = 'CIP')
		or ( @userId = 3 and pl.type = 'Mentor')
		or ( @userId = 4 and pl.type = 'Mentor Grad'))
   union 
   select p.planid
   from 
         plansubcontractor p
         inner join suppliervetting s on s.contactid=p.supplierid
         Inner join (select * from planProperty where propertyId in (25, 31,15)) B On B.PlanId=p.planId
         Inner join [Plan] pl on pl.id=p.planid
   where 
   (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
   --(@userName='' or @userName= isnull(convert(nvarchar(50), B.propertytext), '')) 
   and
   s.VettingId =1
   and s.VettingName like '%'+ p.Contractno + '%'
   and s.contactid=(select qualifiedsupplierid from vendor where federalid=p.taxid)
   and s.status=3
   and s.Review =0
     and (( @userId = 1 and pl.type = 'Line')
		or ( @userId = 2 and pl.type = 'CIP')
		or ( @userId = 3 and pl.type = 'Mentor')
		or ( @userId = 4 and pl.type = 'Mentor Grad'))
   ) v

END




		
declare @temp1 table
(
	OrderId int identity (1,1) Primary Key,
	PlanId int,
	Company nvarchar(100),
	Reviewer nvarchar(50)
)

Insert Into @temp1
	(PlanId, 
	Company,
	Reviewer)
select 
	t.Id,
	t.Company,
	t.Reviewer
from
	(SELECT 
		p.Id,
		p.Type,
		p.ContractNo,
		p.Description,
		p.Status,
		v.Company, 
		isnull(convert(nvarchar(50), pp.propertytext), '') as Reviewer 
	From 
		[Plan] p
	left join 
		Vendor v
	on
		p.FederalId = v.federalId
	left join
		(select * from planProperty where propertyId = 15) pp
	on
		p.Id = pp.PlanId
	inner join 
		@temp te
	on
		p.Id = te.PlanId
	) t
ORDER BY 
	CASE @sequence 
	WHEN 'ASC' THEN 
		CASE @orderBy 
	        	WHEN 'ContractNo' THEN t.ContractNo
	        	WHEN 'Type' THEN t.Type
	        	WHEN 'VendorName' THEN t.Company
	        	WHEN 'Reviewer' THEN t.Reviewer
		ELSE ''
		END
	END ASC,
	CASE @sequence 
	WHEN 'ASC' THEN 
		CASE @orderBy 
				WHEN 'Status' THEN t.Status
		ELSE ''
		END
	END ASC,
	CASE @sequence	
	WHEN 'DESC' THEN 
		CASE @orderBy 
	        	WHEN 'ContractNo' THEN t.ContractNo
	        	WHEN 'Type' THEN t.Type
	        	WHEN 'VendorName' THEN t.Company
	        	WHEN 'Reviewer' THEN t.Reviewer
		ELSE ''
		END
	END DESC,
	CASE @sequence 
	WHEN 'DESC' THEN 
		CASE @orderBy 
				WHEN 'Status' THEN t.Status
		ELSE ''
		END
	END DESC
	
select @totalcount = count(*) from @temp1
if @pageSize > 0
	Delete from @temp1
	Where OrderId < @beginCount or OrderId > @endCount

select
	--Id		As '@Id',
	--p.PlanId		As '@PlanId',
	--Type		As '@Type',
	--ProjectId		As '@ProjectId',
	--ContractId		As '@ContractId',
	--SolicitSeq		As '@SolicitSeq',
	--SolicitNo        As '@Solicit',
	--ContractNo		As '@ContractNo',
	--MeContractNo	As '@MeContractNo',
	--ContractAmount	As '@ContractAmount',
	--Description		As '@Description',
	--Comments		As '@Comments',
	--EEOContactName		As '@EEOContactName',
	--EEOContactPhone		As '@EEOContactPhone',
	--EEOContactEmail		As '@EEOContactEmail',
	--SubcontPercentage		As '@SubcontPercentage',
	--MWLBEGoal		As '@MWLBEGoal',
	--RevisedMWLBEGoal		As '@RevisedMWLBEGoal',
	--WaiverPercentage		As '@WaiverPercentage',
	--RevisedPercentage		As '@RevisedPercentage',
	--PlanApprovalDate		As '@PlanApprovalDate',
	--ProjectDuration As'@ProjectDuration',
	--AwardDate	As '@AwardDate',
	--IsWaiver		As '@IsWaiver',
	--Status		As '@Status',
	--StatusName		As '@StatusName',
	--WorkflowId		As '@WorkflowId',
	--TransactionId		As '@TransactionId',
	--dbo.[PercentageCompletion](p.Id) As '@PercentageCompletion',
	--dbo.[PerformanceInclusion](p.Id) As '@PerformanceInclusion',
	--ChangeUser		As '@ChangeUser',
	--ChangeDate		As '@ChangeDate',
	dbo.ApprovedSubcontractorAmount(p.Id) + dbo.ApprovedSupplierAmount(p.Id) As '@ApprovedAmount', --Total Actual $
	dbo.ApprovedMWLBESubcontractorAmount(p.Id) + dbo.ApprovedMWLBESupplierAmount(p.Id)  As '@MWLBEApprovedAmount', --Total Actual MWLBE $
	dbo.PerformanceInclusion(p.Id)  As '@MWLBEApprovedPercentage', -- Actual MWLBE %

	dbo.[PercentageCompletion](p.Id) As '@PercentageCompletion',
	dbo.[PerformanceInclusion](p.Id) As '@PerformanceInclusion',
	p.ChangeUser		As '@ChangeUser',
	p.ChangeDate		As '@ChangeDate',
	---------------------
	t.Company + '|' + t.Reviewer		As '@Result',
	@totalcount		as '@TotalRecordNumber',
	p.Id		As '@Id',
	p.PlanId		As '@PlanId',
	Type		As '@Type',
	ProjectId		As '@ProjectId',
	ContractId		As '@ContractId',
	SolicitSeq		As '@SolicitSeq',
	SolicitNo        As '@Solicit',
	ContractNo		As '@ContractNo',
	MeContractNo	As '@MeContractNo',
	ContractAmount	As '@ContractAmount',
	Description		As '@Description',
	Comments		As '@Comments',
	EEOContactName		As '@EEOContactName',
	EEOContactPhone		As '@EEOContactPhone',
	EEOContactEmail		As '@EEOContactEmail',
	SubcontPercentage		As '@SubcontPercentage',   --Total Proposed %
	MWLBEGoal		As '@MWLBEGoal',
	RevisedMWLBEGoal		As '@RevisedMWLBEGoal',
	WaiverPercentage		As '@WaiverPercentage',
	RevisedPercentage		As '@RevisedPercentage',
	PlanApprovalDate		As '@PlanApprovalDate',
	IsWaiver		As '@IsWaiver',
	ProjectDuration As'@ProjectDuration',
	AwardDate As '@AwardDate',
	Status		As '@Status',
	StatusName		As '@StatusName',
	WorkflowId		As '@WorkflowId',
	TransactionId		As '@TransactionId',
	dbo.SubmittedAmount(p.Id)  As '@SubmittedAmount', --Total Submitted $
	isnull(p.ContractAmount, 0) *  isnull(p.SubcontPercentage, 0)/100 as '@EstimateAmount', --Total Proposed $
	dbo.EstimateMWLBESubcontractorAmount(p.Id) + dbo.EstimateMWLBESupplierAmount(p.Id) As '@MWLBEEstimateAmount', --Total Proposed MWLBE $
	----CONVERT([decimal](18,2), dbo.Percentage((dbo.EstimateMWLBESubcontractorAmount(p.Id) + dbo.EstimateMWLBESupplierAmount(p.Id)), isnull(p.ContractAmount, 0) *  isnull(p.SubcontPercentage, 0)/100)*100, 0) As '@MWLBEEstimatePercentage', --Proposed MWLBE %
	convert(decimal(18,2), 
        dbo.Percentage(
            (dbo.EstimateMWLBESubcontractorAmount(p.Id) + dbo.EstimateMWLBESupplierAmount(p.Id)),
            isnull(
                (select sum(estvalue) from plansubcontractor 
                    where planid=p.id and safid=0
                    and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))
                    ) , 0)
        ) * 100 
    )AS MWLBEEstimatePercentage,   -- Proposed MWLBE %
	
	(
	select
		i.Id				As '@Id',
		i.PlanId				As '@PlanId',
		i.LLW				As '@LLW',
		i.LLWDesc			As '@LLWDesc',
		i.School			As '@School',
		i.SchoolAddressLine1	As '@SchoolAddressLine1',
		i.SchoolAddressLine2	As '@SchoolAddressLine2',
		i.Boro				As '@Boro',
		i.ZipCode			As '@ZipCode',
		i.ChangeUser		As '@ChangeUser',
		i.ChangeDate		As '@ChangeDate'
	from 
		PlanItem i
	where i.planId = p.Id
	Order By i.LLW
	FOR XML PATH('PlanItem'), ROOT('ArrayOfPlanItem'), TYPE
	)
from 
	@temp1 t
inner join 	[Plan] p on	t.PlanId = p.Id	
Left outer join (select * from planProperty where propertyId = 15) B On B.PlanId=p.Id
	where (@userName_Sup='' or @userName_Sup= isnull(convert(nvarchar(50), B.propertytext), ''))  
	
Order By t.OrderId
FOR XML PATH('Plan'), ROOT('ArrayOfPlan')

