﻿IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[SearchPlanXml]'))
   EXEC('CREATE PROCEDURE [dbo].[SearchPlanXml] AS BEGIN SET NOCOUNT ON; END')
GO

/*    
*******************************************************************************    
Procedure: SearchPlanXml  
Purpose:  
-------------------------------------------------------------------------------    
Date        Developer           Notes    
==========  =================== ===============================    
03/05/2018  PCHEN               Sync with Staging DB
    Sync MWLBEEstimatePercentage logic from GetPlanXML.sql
3/19/2018   PCHEN               Fixing Search by Borough bug
    Note: Getting borough from MV_SOLICIT_CONTRACT still weak, Not all boro are populated
4/9/2020    PCHEN               Sync with Stage DB
    1) Rename output @Solicit to @SolicitNo to match entity "Plan"'s defination
    2) Newly introduced 'PlanGroup' Column; 
    3) Company to '@Company'
    4) Limited search to '[Plan].PlanGroup is NULL' to seperate out from A&E Prof/Service Plan
*******************************************************************************    
*/    

ALTER procedure [dbo].[SearchPlanXml]
       @pageSize int,
       @pageNumber int,
       @orderBy nvarchar(50),
       @sequence nvarchar(10),
       @userId int,
       @status int,
       @extraXml ntext
as
begin
declare @hdoc int
declare @isNumeric bit  =0
-- Convert Response data from XML to in memory table. 
EXEC sp_xml_preparedocument @hdoc OUTPUT, @extraXml

  if  @orderBy IN ('Status', 'AwardAmt' , 'pctComplete', 'mwlbeEstimatePercentage' ,  'mwlbeEstimateAmount' ,'mwlbeApprovedPercentage'  ,  'mwlbeApprovedAmount'  )
  BEGIN
		set @isNumeric =1
  END

declare @extra Table
(
       Name nvarchar(50),
       Value nvarchar(2000)
)
INSERT INTO @extra
(
       Name,
       Value
)
SELECT
       Name,
       Value
FROM OPENXML(@hDoc, '/ArrayOfExtra/Extra', 1)
WITH
(
       Name nvarchar(50),
       Value nvarchar(2000)
)

declare @contractNo nvarchar(50)
declare @contractType nvarchar(50)
declare @vendor nvarchar(50)
declare @federalId nvarchar(50)
declare @analyst nvarchar(50)
declare @borough nvarchar(50)
declare @schoolName nvarchar(50)
declare @mentorGrad nvarchar(50)

declare @fromApprovedMWLBE nvarchar(50)
declare @toApprovedMWLBE nvarchar(50)

declare @fromAwardDate nvarchar(50)
declare @toAwardDate nvarchar(50)

declare @beginCount int
declare @endCount int
declare @totalcount int

set @contractNo=''
set @contractType=''
set @vendor=''
set @federalId=''
set @analyst=''
set @borough=''
set @schoolName=''
set @mentorGrad=''

set @fromApprovedMWLBE = ''
set @toApprovedMWLBE  = ''

set @fromAwardDate = '1/1/1900'
set @toAwardDate = '1/1/1900'


set @beginCount = @pageNumber * @pageSize + 1
set @endCount = @beginCount + @pageSize - 1

select @contractNo=Value
from @extra
where Name='Contract'

select @contractType=Value
from @extra
where Name='ContractType'

select @vendor=Value
from @extra
where Name='PrimeVendor'

select @federalId=Value
from @extra
where Name='PrimeFederalId'

select @analyst=Value
from @extra
where Name='Analyst'

select @schoolName=Value
from @extra
where Name='SchoolName'

select @borough=Value
from @extra
where Name='Borough'

select @mentorGrad=Value
from @extra
where Name='MentorGrad'

select @fromApprovedMWLBE=Value
from @extra
where Name='FromApprovedMWLBE'

select @toApprovedMWLBE=Value
from @extra
where Name='ToApprovedMWLBE'

select @fromAwardDate=Value
from @extra
where Name='FromAwardDate'

select @toAwardDate=Value
from @extra
where Name='ToAwardDate'

EXEC sp_xml_removedocument @hdoc

Declare @temp1 Table
(
       OrderId int identity (1,1) Primary Key,
       PlanId int,
       Company nvarchar(100),
       FederalId nvarchar(20),
       Reviewer nvarchar(50),
       SchoolName nvarchar(50),
       BoroName nvarchar(50),
       ProjectOfficer nvarchar(50),
       pctComplete float,
       MWLBEEstimateAmount float,
       MWLBEEstimatePercentage decimal(18,2),
       MWLBEApprovedAmount float,
       MWLBEApprovedPercentage float
)
Insert Into @temp1
       (PlanId, 
       Company,
       FederalId,
       Reviewer,
       SchoolName,
       BoroName,
       ProjectOfficer,
       pctComplete,
       MWLBEEstimateAmount,
       MWLBEEstimatePercentage,
       MWLBEApprovedAmount,
       MWLBEApprovedPercentage)
select 
       t.Id,
       t.Company,
       t.FederalId,
       t.Reviewer,
       t.SchoolName,
       t.BoroName,
       t.ProjectOfficer,
       pctComplete,
       MWLBEEstimateAmount,
       MWLBEEstimatePercentage,
       MWLBEApprovedAmount,
       MWLBEApprovedPercentage
from
       (SELECT 
              p.Id,
              p.Type,
              p.ContractNo,
              p.Description,
              p.Status,
              v.Company,
              v.FederalId, 
              isnull(convert(nvarchar(50), pp.propertytext), '') as Reviewer,
              isnull(convert(nvarchar(50), pp17.propertytext), '') as SchoolName,
              isnull(convert(nvarchar(50), pp19.propertytext), '') as BoroName,
              isnull(convert(nvarchar(50), pp20.propertytext), '') as ProjectOfficer,
              isnull(dbo.[PercentageCompletion](p.Id),0) as pctComplete,
              isnull(dbo.EstimateMWLBESubcontractorAmount(p.Id),0) + isnull(dbo.EstimateMWLBESupplierAmount(p.Id),0) As MWLBEEstimateAmount,
              ---- CONVERT([decimal](18,2), dbo.Percentage((dbo.EstimateMWLBESubcontractorAmount(p.Id) + dbo.EstimateMWLBESupplierAmount(p.Id)), isnull(p.ContractAmount, 0) *  isnull(p.SubcontPercentage, 0)/100)*100, 0) As MWLBEEstimatePercentage,
                convert(decimal(18,2), 
                    dbo.Percentage(
                        (dbo.EstimateMWLBESubcontractorAmount(p.Id) + dbo.EstimateMWLBESupplierAmount(p.Id)),
                        isnull(
                            (select sum(estvalue) from plansubcontractor 
                                where planid=p.id and safid=0
                                and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))
                                ) , 0)
                    ) * 100 
                )AS MWLBEEstimatePercentage, -- Proposed MWLBE %
              dbo.ApprovedMWLBESubcontractorAmount(p.Id) + dbo.ApprovedMWLBESupplierAmount(p.Id)  As MWLBEApprovedAmount, --Total Actual MWLBE $
              dbo.PerformanceInclusion(p.Id)  As MWLBEApprovedPercentage -- Actual MWLBE %
       From 
              [Plan] p
       left join 
              Vendor v
       on
              p.FederalId = v.federalId
       left join
              (select * from planProperty where propertyId = 15) pp

       on
              p.Id = pp.PlanId

       left outer join
              (select * from planProperty where propertyId = 17) pp17

       on
              p.Id = pp17.PlanId

       left outer join
              (select * from planProperty where propertyId = 19) pp19

       on
              p.Id = pp19.PlanId
       left outer join
              (select * from planProperty where propertyId = 20) pp20

       on
              p.Id = pp20.PlanId
       where  ISNULL(P.PlanGroup,'') ='' AND -- 202004 PCHEN Newly introduced "PlanGroup" column
              (@contractNo='' or isnull(p.ContractNo, p.mecontractNo) like '%' + @contractNo + '%') 
              and (@federalId='' or ltrim(rtrim(@federalId)) = ltrim(rtrim(p.FederalId)))
              and (@vendor='' or  v.Company like '%' + @vendor + '%')
              and (@contractType='' or @contractType='All' or @contractType = p.Type)
              and (@analyst='' or @analyst= isnull(convert(nvarchar(50), pp.propertytext), '')) 
              /*and (@borough='' or @borough=(select convert(nvarchar(50), propertytext) from planProperty pp where propertyId = 18 and pp.planId = p.Id))*/
              and (@borough='' 
                    OR EXISTS (SELECT 1 FROM MV_SOLICIT_CONTRACT S 
                        WHERE S.C_SOLICIT = P.SolicitNo
                        AND s.N_SOLICIT_SEQ = p.SolicitSeq
                        AND s.C_BORO_CODE = @borough))
              and (@schoolName='' or @schoolName=(select convert(nvarchar(50), propertytext) from planProperty pp where propertyId = 17 and pp.planId = p.Id))         
              and (@mentorGrad='' or (@mentorGrad='N' and p.Type!='Mentor Grad'))
              --and ((@status = -1 and p.status<>16) or p.status = @status )
              and ((@status = -1 and p.status not in(16,17))  or (p.status = @status and @status<>-1))
              and (@fromApprovedMWLBE='' or dbo.[PerformanceInclusion](p.Id) >= CONVERT(float, @fromApprovedMWLBE))
              and (@toApprovedMWLBE='' or dbo.[PerformanceInclusion](p.Id) <= CONVERT(float, @toApprovedMWLBE))
              and (@fromAwardDate='1/1/1900' or p.AwardDate >= @fromAwardDate)
              and (@toAwardDate='1/1/1900' or p.AwardDate <= @toAwardDate)
              -- TFS Work item #617 Move all "closed out" projects from the search grid
              --and (Case @status when -1 then p.status else @status end <> Case @status When -1 then  16 else -2 End)

       ) t
       
select @totalcount = @@rowcount             

--if @pageSize > 0
--       Delete from @temp1 Where OrderId < @beginCount or OrderId > @endCount
       
select
       Id            As '@Id',
       p.PlanId             As '@PlanId',
       Type          As '@Type',
       ProjectId            As '@ProjectId',
       ContractId           As '@ContractId',
       SolicitSeq           As '@SolicitSeq',
       SolicitNo        As '@SolicitNo',
       ContractNo           As '@ContractNo',
       MeContractNo  As '@MeContractNo',
       ContractAmount       As '@ContractAmount',
       Description          As '@Description',
       p.federalid          as '@FederalId',
       Comments             As '@Comments',
       EEOContactName             As '@EEOContactName',
       EEOContactPhone            As '@EEOContactPhone',
       EEOContactEmail            As '@EEOContactEmail',
       SubcontPercentage          As '@SubcontPercentage',   --Total Proposed %
       MWLBEGoal            As '@MWLBEGoal',
       RevisedMWLBEGoal           As '@RevisedMWLBEGoal',
       WaiverPercentage           As '@WaiverPercentage',
       RevisedPercentage          As '@RevisedPercentage',
       PlanApprovalDate           As '@PlanApprovalDate',
       IsWaiver             As '@IsWaiver',
       ProjectDuration As'@ProjectDuration',
       AwardDate As '@AwardDate',
       Status        As '@Status',
       StatusName           As '@StatusName',
       WorkflowId           As '@WorkflowId',
       TransactionId        As '@TransactionId',
       dbo.SubmittedAmount(p.Id)  As '@SubmittedAmount', --Total Submitted $
       isnull(p.ContractAmount, 0) *  isnull(p.SubcontPercentage, 0)/100 as '@EstimateAmount', --Total Proposed $
       --dbo.EstimateMWLBESubcontractorAmount(p.Id) + dbo.EstimateMWLBESupplierAmount(p.Id) As '@MWLBEEstimateAmount', --Total Proposed MWLBE $
       t.MWLBEEstimateAmount As '@MWLBEEstimateAmount',
       --CONVERT([decimal](18,2), dbo.Percentage((dbo.EstimateMWLBESubcontractorAmount(p.Id) + dbo.EstimateMWLBESupplierAmount(p.Id)), isnull(p.ContractAmount, 0) *  isnull(p.SubcontPercentage, 0)/100)*100, 0) As '@MWLBEEstimatePercentage', --Proposed MWLBE %
       t.MWLBEEstimatePercentage As '@MWLBEEstimatePercentage', --Proposed MWLBE %

       dbo.ApprovedSubcontractorAmount(p.Id) + dbo.ApprovedSupplierAmount(p.Id) As '@ApprovedAmount', --Total Actual $
       
       --dbo.ApprovedMWLBESubcontractorAmount(p.Id) + dbo.ApprovedMWLBESupplierAmount(p.Id)  As '@MWLBEApprovedAmount', --Total Actual MWLBE $
       --dbo.PerformanceInclusion(p.Id)  As '@MWLBEApprovedPercentage', -- Actual MWLBE %
       t.MWLBEApprovedAmount  As '@MWLBEApprovedAmount', --Total Actual MWLBE $
       t.MWLBEApprovedPercentage  As '@MWLBEApprovedPercentage', -- Actual MWLBE %
       dbo.[PercentageCompletion](p.Id) As '@PercentageCompletion',
       dbo.[PerformanceInclusion](p.Id) As '@PerformanceInclusion',
       ChangeUser           As '@ChangeUser',
       ChangeDate           As '@ChangeDate',
       t.Company     As '@Result',
       t.Company     As '@Company',
       ISNULL(p.PlanGroup,'')   AS '@PlanGroup',
       @totalcount          as '@TotalRecordNumber',
       t.reviewer as '@Analyst',
       (
              select concat(u.FirstName,' ',u.LastName) as Name
              from [User] u
              inner join aspnet_Users au
              on au.UserName = t.reviewer and au.UserId = u.UserId
       ) as '@AnalystFullName',
       t.SchoolName as '@SchoolName',
       t.BoroName as '@BoroName',
       t.ProjectOfficer as '@ProjectOfficer',
       (
       select
              i.Id                       As '@Id',
              i.PlanId                          As '@PlanId',
              i.LLW                      As '@LLW',
              i.LLWDesc                  As '@LLWDesc',
              i.School                   As '@School',
              i.SchoolAddressLine1 As '@SchoolAddressLine1',
              i.SchoolAddressLine2 As '@SchoolAddressLine2',
              i.Boro                     As '@Boro',
              i.ZipCode                  As '@ZipCode',
              i.ChangeUser         As '@ChangeUser',
              i.ChangeDate         As '@ChangeDate'
       from 
              PlanItem i
       where i.planId = p.Id
       Order By i.LLW
       FOR XML PATH('PlanItem'), ROOT('ArrayOfPlanItem'), TYPE
       ),
       (
       select 
              vs.VendorId as '@VendorId',
              vs.Certification as '@Certification',
              vs.Status as '@Status',
              vs.CertifiedDate as '@CertifiedDate',
              vs.ExpirationDate as '@ExpirationDate',
              vs.PartnerSource as '@PartnerSource'
       from
              VendorSBSCertification vs
              inner join vendor v on vs.vendorid=v.id
       where
              v.federalid=p.federalid
              and p.awarddate between vs.certifieddate and isnull(vs.expirationdate,Getdate())
       FOR XML PATH('VendorSBSCertification'), ROOT('ArrayOfVendorSBSCertification'), TYPE
       )
                     
       
from 
       @temp1 t 
       inner join [Plan] p on     t.PlanId = p.Id      
       
ORDER BY 
 				  CASE 
				   WHEN @sequence ='ASC' AND @isNumeric=0   THEN 
						  CASE @orderBy 
								 WHEN 'ContractNo' THEN ContractNo
								 WHEN 'Type' THEN Type
								 WHEN 'VendorName' THEN t.Company
								 WHEN 'VendorID' THEN t.FederalId
								 WHEN 'Reviewer' THEN t.Reviewer
								 WHEN 'Description' THEN convert(nvarchar(max),Description)
						  ELSE ''
						  END
				   END ASC,
				   CASE  
				   WHEN @sequence='ASC' AND  @isNumeric=1 THEN 
						  CASE @orderBy 
									   WHEN 'Status' THEN Status
									   WHEN 'AwardAmt' THEN ContractAmount  
									   WHEN 'pctComplete' THEN t.pctComplete
									   when 'mwlbeEstimatePercentage' then t.MWLBEEstimatePercentage
									   when 'mwlbeEstimateAmount' then t.MWLBEEstimateAmount
									   when 'mwlbeApprovedPercentage' then t.MWLBEApprovedPercentage
									   when 'mwlbeApprovedAmount' then t.MWLBEApprovedAmount
						  ELSE ''
						  END
				   END ASC,
				   CASE        
				   WHEN @sequence='DESC' AND @isNumeric=0  THEN 
						  CASE @orderBy 
								 WHEN 'ContractNo' THEN ContractNo
								 WHEN 'Type' THEN Type
								 WHEN 'VendorName' THEN t.Company
								 WHEN 'VendorID' THEN t.FederalId
								 WHEN 'Reviewer' THEN t.Reviewer
									   WHEN 'Description' THEN convert(nvarchar(max),Description)
						  ELSE ''
						  END
				   END DESC,
				   CASE  
				   WHEN @sequence='DESC' AND  @isNumeric=1 THEN 
						  CASE @orderBy 
									   WHEN 'Status' THEN Status
									   WHEN 'AwardAmt' THEN ContractAmount  
									   WHEN 'pctComplete' THEN t.pctComplete
									   when 'mwlbeEstimatePercentage' then t.MWLBEEstimatePercentage
									   when 'mwlbeEstimateAmount' then t.MWLBEEstimateAmount
									   when 'mwlbeApprovedPercentage' then t.MWLBEApprovedPercentage
									   when 'mwlbeApprovedAmount' then t.MWLBEApprovedAmount
						  ELSE ''
						  END
				   END DESC
		
		OFFSET @pageSize *  @pageNumber   ROWS
		FETCH NEXT @pageSize ROWS ONLY OPTION (RECOMPILE)
		FOR XML PATH('Plan'), ROOT('ArrayOfPlan')

	
end

GO

/**
exec SearchPlanXml @pageSize=20,@pageNumber=0,@orderBy=N'ContractNo',@sequence=N'ASC',@userId=0,@status=12,@extraXml=N'<?xml version="1.0"?>
<ArrayOfExtra xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Extra Name="Contract" Value="" />
  <Extra Name="ContractType" Value="All" />
  <Extra Name="Borough" Value="" />
  <Extra Name="FromApprovedMWLBE" Value="" />
  <Extra Name="ToApprovedMWLBE" Value="" />
  <Extra Name="PrimeFederalId" Value="" />
  <Extra Name="PrimeVendor" Value="" />
  <Extra Name="FromAwardDate" Value="1/1/1900" />
  <Extra Name="ToAwardDate" Value="1/1/1900" />
  <Extra Name="Analyst" Value="" />
  <Extra Name="SchoolName" Value="" />
</ArrayOfExtra>'
*/