﻿IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[UpdateVendorMultiplierCalcTokens]'))
   EXEC('CREATE PROCEDURE [dbo].[UpdateVendorMultiplierCalcTokens] AS BEGIN SET NOCOUNT ON; END')
GO
/*
*******************************************************************************
Procedure:	UpdateVendorMultiplierCalcTokens
Purpose:	Recalculat CalcTokens from InputTokens
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/1/2020		PCHEN				First Create
*******************************************************************************
*/
ALTER procedure [dbo].[UpdateVendorMultiplierCalcTokens]
    @RfpRequestMultiplierId INT,
    @MultiplierTypeId INT = 0,
	@ChangeUser varchar(50),
    @IsTest bit = 0
as
BEGIN
DECLARE @tCalcHdr TABLE(CalcId INT NULL, 
    RequestId INT, MTypeId INT, MType VARCHAR(50), 
    L2 DECIMAL(9,2), L6 INT)

INSERT INTO @tCalcHdr (RequestId, MTypeId, MType, L2, L6) 
SELECT @RfpRequestMultiplierId, A.Id, A.ShortName, A.L2_MultiComp, A.L6_ProfPct
FROM MultiplierType A, RfpRequestMultiplier B
WHERE B.id = @RfpRequestMultiplierId AND (
    1=2
    OR (ShortName='Home'     AND B.HasHome=1)
    OR (ShortName='Field'    AND B.HasField=1)
    OR (ShortName='HomeEmg'  AND B.HasHomeEmg=1)
    OR (ShortName='FieldEmg' AND B.HasFieldEmg=1)
    OR (ShortName='StaffPre' AND B.HasStaffPre=1)
    OR (ShortName='StaffSel' AND B.HasStaffSel=1)
    OR (ShortName='QuasiPre' AND B.HasQuasiPre=1)
    OR (ShortName='QuasiSel' AND B.HasQuasiSel=1)
)
AND (ISNULL(@MultiplierTypeId,0) = 0 OR A.Id=@MultiplierTypeId)

DECLARE @tTokens TABLE(
    MTypeId INT,  MType VARCHAR(50), 
    InputToken INT, ValueOvrd BIGINT, 
    CalcToken INT, InputLine VARCHAR(10), CalcLine VARCHAR(10))
INSERT INTO @tTokens (MTypeId,  MType, InputToken, ValueOvrd, CalcToken, InputLine, CalcLine)
select H.MTypeId, H.MType, EI.IntVal AS InputTokenEnumId,
T.ValueOvrd * M.Factor,EC.IntVal AS CalcTokenEnumId
,M.InputToken AS InputLine, M.CalcToken AS CalcLine
from MultiplierTokenMapping M
JOIN Enums EC ON M.CalcToken = EC.CodeVal  AND EC.PropertyName = 'CalculationToken' AND EC.Entity='Multiplier'
JOIN Enums EI ON M.InputToken = EI.CodeVal AND EI.PropertyName = 'InputToken' AND EI.Entity = 'Multiplier'
JOIN VendorMultiplierInputToken T ON EI.IntVal = T.TokenEnumId 
JOIN VendorMultiplierInput A  ON T.VendorMultiplierInputId = A.Id 
JOIN @tCalcHdr H ON H.RequestId = A.RfpRequestMultiplierId AND (
    (H.MType = 'Home'    AND M.Home=1) OR 
    (H.MType = 'HomeEmg' AND M.HomeEmg=1) OR 
    (H.MType = 'Field'   AND M.Field=1) OR
    (H.MType = 'FieldEmg' AND M.FieldEmg =1) OR
    (H.MType = 'StaffPre' AND M.StaffPre=1) OR
    (H.MType = 'StaffSel' AND M.StaffSel=1) OR
    (H.MType = 'QuasiPre' AND M.QuasiPre=1) OR
    (H.MType = 'QuasiSel' AND M.QuasiSel=1) 
    )

-- Get All Calc Tokens for each MultiplierTypeId
DECLARE @tCalcTokens TABLE(
    CalcId INT NULL, CalcTokenId INT, MTypeId INT, TokenEnumId INT, Line VARCHAR(20), ParentTokenId INT, Val BIGINT)
INSERT INTO @tCalcTokens (MTypeId, TokenEnumId, Val)
SELECT MTypeId, CalcToken, SUM(ValueOvrd) AS Val
    FROM @tTokens GROUP BY MTypeId, CalcToken

BEGIN TRAN
BEGIN TRY
-- 1: Create Calc Header if not exists yet
INSERT INTO dbo.VendorMultiplierCalc
   (RfpRequestMultiplierId, MultiplierTypeId, L2_Sec1Component, L6_ProfitPct
     ,CreateUser,CreateDate,ChangeUser,ChangeDate)
SELECT RequestId, MTypeId, L2, L6
    , @ChangeUser, GetDate(), @ChangeUser, GETDATE()
FROM @tCalcHdr A 
WHERE NOT EXISTS(SELECT 1 FROM VendorMultiplierCalc B WHERE A.RequestId = B.RfpRequestMultiplierId AND A.MTypeId = B.MultiplierTypeId)

-- 2: Update @tCalcHdr Id (HdrId to [CalcToken] table
UPDATE A SET A.CalcId = B.Id
FROM @tCalcHdr A JOIN VendorMultiplierCalc B ON A.RequestId = B.RfpRequestMultiplierId AND A.MTypeId = B.MultiplierTypeId

-- 3: Get ALL Calculation Tokens
UPDATE A SET A.CalcId = B.CalcId
FROM @tCalcTokens A JOIN @tCalcHdr B ON A.MTypeId = B.MTypeId

-- ** Update [VendorMultiplierCalcToken] Now **
-- 1 Update existing none-presented Token to 0
UPDATE A SET A.ValueOvrd = 0, 
    A.ChangeDate=GETDATE(), A.ChangeUser=@ChangeUser
FROM VendorMultiplierCalcToken A 
WHERE A.VendorMultiplierCalcId IN (SELECT CalcId FROM @tCalcHdr)
AND NOT EXISTS (SELECT 1 FROM @tCalcTokens B 
    WHERE A.VendorMultiplierCalcId = B.CalcId 
    AND A.TokenEnumId = B.TokenEnumId)
AND A.ValueOvrd <> 0

-- 2 Update existing presented to new Value
UPDATE A SET A.ValueOvrd = ISNULL(B.Val, 0),
   A.ChangeUser = @ChangeUser,
   A.ChangeDate = GETDATE()
FROM VendorMultiplierCalcToken A 
JOIN @tCalcTokens B ON A.VendorMultiplierCalcId = B.CalcId AND A.TokenEnumId = B.TokenEnumId
WHERE A.ValueOvrd <> B.Val

-- 3 Insert New values
INSERT INTO VendorMultiplierCalcToken(
    VendorMultiplierCalcId, TokenEnumId, ValueOvrd, Line, ParentTokenId,
    CreateUser, CreateDate, ChangeUser, ChangeDate)
SELECT CalcId, TokenEnumId, ISNULL(Val, 0), Line, ParentTokenId,
    @ChangeUser, GETDATE(), @ChangeUser, GETDATE()
FROM @tCalcTokens A 
WHERE NOT EXISTS(SELECT 1 FROM VendorMultiplierCalcToken B 
    WHERE A.CalcId = B.VendorMultiplierCalcId 
    AND A.TokenEnumId=B.TokenEnumId)

IF @IsTest = 1 
BEGIN
    SELECT '@tCalcHdr' as t, * FROM @tCalcHdr
    SELECT '' AS '[VendorMultiplierCalc]', A.* from VendorMultiplierCalc A
    JOIN @tCalcHdr B ON A.RfpRequestMultiplierId = B.RequestId AND A.MultiplierTypeId = B.MTypeId
    select '' as '@tTokens', * from @tTokens where isnull(valueovrd, 0) > 0 Order by MTypeId, InputToken    
    SELECT '' AS '@tCalcTokens', * from @tCalcTokens where ISNULL(val, 0) > 0 order by MTypeId, TokenEnumId
    select '' AS '[VendorMultiplierCalcToken]', * from VendorMultiplierCalcToken WHERE VendorMultiplierCalcId
        in (SELECT CalcId FROM @tCalcHdr)
        ORDER By VendorMultiplierCalcId, TokenEnumId
    ROLLBACK TRAN;
END
ELSE
    COMMIT TRAN;
    
    RETURN 1;
END TRY
BEGIN CATCH
    ROLLBACK TRAN
    RETURN -1
END CATCH
END
GO

    /*

DECLARE @RC int
DECLARE @RfpRequestMultiplierId int = 1
DECLARE @MultiplierTypeId INT = 4
DECLARE @ChangeUser varchar(50) = 'TMPPCH'
DECLARE @IsTest bit = 1
EXECUTE @RC = [dbo].[UpdateVendorMultiplierCalcTokens] 
   @RfpRequestMultiplierId
  ,@MultiplierTypeId
  ,@ChangeUser
  ,@IsTest
SELECT '@RC=', @RC
GO
   */
