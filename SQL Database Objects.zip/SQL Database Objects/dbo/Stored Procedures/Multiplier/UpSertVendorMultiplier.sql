﻿IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[UpSertVendorMultiplier]'))
   EXEC('CREATE PROCEDURE [dbo].[UpSertVendorMultiplier] AS SELECT 1')
GO  

/*
*******************************************************************************
Procedure:	UpSertVendorMultiplier
Purpose:	
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
12/30/2020		PCHEN				First Create
*******************************************************************************
*/
ALTER PROCEDURE [dbo].[UpSertVendorMultiplier]
	@Id int = 0,
	@VendorId INT,
    @TaxId VARCHAR(15),
    @Company VARCHAR(255),
    @YearReported VARCHAR(10),
    @Home DECIMAL(9,2),
    @HomeEmg DECIMAL(9,2),
    @Field DECIMAL(9,2),
    @FieldEmg DECIMAL(9,2),
    @StaffSel DECIMAL(9,2),
    @StaffPre DECIMAL(9,2),
    @QuasiSel DECIMAL(9,2),
    @QuasiPre DECIMAL(9,2),
    @Comment VARCHAR(MAX),
    @ChangeUser VARCHAR(50)
AS
BEGIN TRY
    IF (@Id=0 OR NOT EXISTS(SELECT 1 FROM VendorMultiplier WHERE Id=@Id))
    BEGIN -- Insert
       INSERT INTO [dbo].[VendorMultiplier]
           ([VendorId]
           ,[TaxId]
           ,[Company]
           ,[YearReported]
           ,[Home]
           ,[HomeEmg]
           ,[Field]
           ,[FieldEmg]
           ,[StaffSel]
           ,[StaffPre]
           ,[QuasiSel]
           ,[QuasiPre]
           ,[Comment]
           ,[RfpRequestMultiplierId]
           ,[CreateUser]
           ,[CreateDate]
           ,[ChangeUser]
           ,[ChangeDate])
        VALUES
           (@VendorId
           ,@TaxId
           ,@Company
           ,@YearReported
           ,@Home
           ,@HomeEmg
           ,@Field
           ,@FieldEmg
           ,@StaffSel
           ,@StaffPre
           ,@QuasiSel
           ,@QuasiPre
           ,@Comment
           ,0
           ,@ChangeUser
           ,GETDATE()
           ,@ChangeUser
           ,GETDATE())
       SET @Id = @@identity
    END
    ELSE
        UPDATE [dbo].[VendorMultiplier]
           SET [YearReported] = @YearReported
              ,[Home] = @Home
              ,[HomeEmg] = @HomeEmg
              ,[Field] = @Field
              ,[FieldEmg] = @FieldEmg
              ,[StaffSel] = @StaffSel
              ,[StaffPre] = @StaffPre
              ,[QuasiSel] = @QuasiSel
              ,[QuasiPre] = @QuasiPre
              ,[Comment] = @Comment
              ,[ChangeUser] = @ChangeUser
              ,[ChangeDate] = GETDATE()
         WHERE Id = @Id

    RETURN @Id
END TRY
BEGIN CATCH
    RETURN -1
END CATCH
GO
