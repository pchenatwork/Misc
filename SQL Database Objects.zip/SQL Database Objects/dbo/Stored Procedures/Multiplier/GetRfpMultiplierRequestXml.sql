﻿IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[GetRfpMultiplierRequestXml]'))
   EXEC('CREATE PROCEDURE [dbo].[GetRfpMultiplierRequestXml] AS BEGIN SET NOCOUNT ON; END')
GO
/*
*******************************************************************************
Procedure:	GetRfpMultiplierRequestXml
Purpose:	Get a row from RfpRequest table.
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
08/2020		    PCHEN				Created
*******************************************************************************
*/
ALTER procedure [dbo].[GetRfpMultiplierRequestXml]
	@id int
as
Set NoCount On		
					
SELECT M.Id   AS '@Id'
    , M.RfpRequestId AS '@RfpRequestId'
    , R.SolicitNo as '@SolicitNo'
    , M.VendorId as '@VendorId'
    , M.TaxId as '@TaxId'
    , (SELECT Company FROM Vendor V WHERE V.Id = M.VendorId) AS '@Company'
    , M.YearRequested as '@YearRequested'
    , M.IsJV AS '@IsJV'
    , M.JV1VendorId AS '@JV1VendorId'
    , M.JV1TaxId AS '@JV1TaxId'
    , M.JV2VendorId AS '@JV2VendorId'
    , M.JV2TaxId AS '@JV2TaxId'
    , M.HasHome AS '@HasHome'
    , M.HasHomeEmg AS '@HasHomeEmg'
    , M.HasField AS '@HasField'
    , M.HasFieldEmg AS '@HasFieldEmg'
    , M.HasQuasiPre AS '@HasQuasiPre'
    , M.HasQuasiSel AS '@HasQuasiSel'
    , M.HasStaffPre AS '@HasStaffPre'
    , M.HasStaffSel AS '@HasStaffSel'
    , CASE WHEN M.IsJV = 0 
            THEN (select id from vendormultiplierinput I where I.VendorId=M.VendorId AND I.RfpRequestMultiplierId = M.Id)
            ELSE (select id from vendormultiplierinput I where I.VendorId=M.JV1VendorId AND I.RfpRequestMultiplierId = M.Id) END
            AS '@Input1Id'
    , (select id from vendormultiplierinput I where I.VendorId=M.JV2VendorId AND I.RfpRequestMultiplierId = M.Id) 
            AS '@Input2Id'
    , R.StatusId as '@StatusId'
    , CASE R.StatusId WHEN 0 THEN 'New Request' WHEN 1 THEN 'In Progress' WHEN 2 THEN 'Finished' END AS '@StatusDesc'
    , M.WorkflowId as '@WorkflowId'
    , M.TransactionId as '@TransactionId'
    , M.Status as '@Status'    
    , M.StatusName as '@StatusName'  
    , M.StatusDate as '@StatusDate'    
	, M.CreateUser   AS '@CreateUser'
	, M.CreateDate   AS '@CreateDate'
	, M.ChangeUser   AS '@ChangeUser'
	, M.ChangeDate   AS '@ChangeDate'
  FROM RfpRequestMultiplier M JOIN RfpRequest R on M.RfpRequestId = R.Id
where M.Id = @id
FOR XML PATH('RfpRequestMultiplier')

GO

/*
exec GetRfpMultiplierRequestXml @id=3

select * from RfpRequestMultiplier
select * from vendormultiplierinput
*/
