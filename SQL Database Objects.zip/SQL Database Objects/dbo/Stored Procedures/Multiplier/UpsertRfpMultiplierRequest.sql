﻿IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[UpsertRfpMultiplierRequest]'))
   EXEC('CREATE PROCEDURE [dbo].[UpsertRfpMultiplierRequest] AS BEGIN SET NOCOUNT ON; END')
GO
/*
*******************************************************************************
Procedure:	UpsertRfpMultiplierRequest
Purpose:	
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/1/2020		PCHEN				First Create
*******************************************************************************
*/
ALTER procedure [dbo].[UpsertRfpMultiplierRequest]
	@Id INT = 0,
    @SolicitNo VARCHAR(20),
    @YearRequested varchar(10)=null,
	@TaxId VARCHAR(15),
    @IsJV bit,
    @JV1TaxId VARCHAR(15)=null,
    @JV2TaxId VARCHAR(15)=null,
    @HasHome bit,
    @HasHomeEmg bit,
    @HasField bit,
    @HasFieldEmg bit,
    @HasStaffSel bit,
    @HasStaffPre bit,
    @HasQuasiSel bit,
    @HasQuasiPre bit,
    @StatusId INT = -1, -- 0: New Request 1: Submitted 2: Approved 3: Denial
	@EmpId varchar(50)
as
BEGIN
    DECLARE @VendorId INT, @Company VARCHAR(255),
        @JV1VendorId INT, @JV1Company VARCHAR(255),
        @JV2VendorId INT, @JV2Company VARCHAR(255)

    BEGIN -- Validation
    SELECT @VendorId = Id, @Company=Company FROM Vendor WHERE FederalId=@TaxId
    If (ISNULL(@VendorId, 0 ) = 0) return -1; -- Vendor not exist
    If (@IsJV=1)
    BEGIN
        SELECT @JV1VendorId = Id, @JV1Company=Company FROM Vendor WHERE FederalId = @JV1TaxId
        SELECT @JV2VendorId = Id, @JV2Company=Company FROM Vendor WHERE FederalId = @JV2TaxId
        IF (ISNULL(@JV1VendorId, 0 ) = 0 OR ISNULL(@JV2VendorId, 0 ) = 0) RETURN -1;
    END
    END -- End Validation
           
BEGIN TRAN
BEGIN TRY
    IF (@Id= 0 OR NOT EXISTS (SELECT 1 FROM RfpRequestMultiplier WHERE Id=@Id))
    BEGIN -- Insert Begin
        DECLARE @RfpRequestId INT
        INSERT INTO [dbo].[RfpRequest]
            ([SolicitNo]
            ,[ReqType] ,[ReqSubType]
            ,[ReqDate]
            ,[FromEmpId]
            ,[StatusId],[StatusDate]
            ,[CreateUser],[CreateDate],[ChangeUser],[ChangeDate])
         VALUES
            (@SolicitNo
            ,'Multiplier' ,''
            ,GETDATE() -- <ReqDate, datetime,>
            ,@EmpId -- <FromEmpId, varchar(10),>
            ,CASE @StatusId WHEN -1 THEN 0 ELSE @StatusId END ,GETDATE() 
            ,@EmpId,GETDATE(),@EmpId,GetDate()
            )
        SET @RfpRequestId = @@identity

        INSERT INTO [dbo].[RfpRequestMultiplier]
               ([RfpRequestId]
               ,[VendorId] ,[TaxId]
               ,[YearRequested]
               ,[IsJV] ,[JV1VendorId] ,[JV1TaxId] ,[JV2VendorId] ,[JV2TaxId]
               ,[HasHome] ,[HasHomeEmg]
               ,[HasField] ,[HasFieldEmg]
               ,[HasStaffSel] ,[HasStaffPre]
               ,[HasQuasiSel] ,[HasQuasiPre]
               ,[WorkflowId]
               ,[TransactionId]
               ,[CreateUser] ,[CreateDate] ,[ChangeUser] ,[ChangeDate])
         VALUES
               (@RfpRequestId
               ,@VendorId ,@TaxId 
               ,@YearRequested
               ,@IsJV ,@JV1VendorId ,@JV1TaxId ,@JV2VendorId ,@JV2TaxId
               ,@HasHome ,@HasHomeEmg 
               ,@HasField ,@HasFieldEmg 
               ,@HasStaffSel ,@HasStaffPre
               ,@HasQuasiSel ,@HasQuasiPre
               ,-1 -- <WorkflowId, int,>
               ,-1 -- <TransactionId, int,>
               ,@EmpId  ,GETDATE() ,@EmpId  ,GETDATE()
               )    
        SET @Id = @@identity

        /* *** --**-- 11/06/2020 --** JV is not supported yet
        If (@IsJV=1 AND 1=2) 
        BEGIN  -- JV Firm, 
        INSERT INTO [dbo].[VendorMultiplier]
               ([VendorId]
               ,[TaxId]
               ,[Company]
               --,[YearRequested]
               --,[YearReported]
               ,[Home]
               ,[HomeEmg]
               ,[Field]
               ,[FieldEmg]
               ,[StaffSel]
               ,[StaffPre]
               ,[QuasiSel]
               ,[QuasiPre]
               ,[Comment]
               ,[StatusId]
               --,[StatusName]
               ,[RfpRequestMultiplierId]
               ,[CreateUser]
               ,[CreateDate]
               ,[ChangeUser]
               ,[ChangeDate])
         VALUES
               (@JV1VendorId -- <VendorId, int,>
               ,@JV1TaxId -- <TaxId, varchar(15),>
               ,@JV1Company -- <Company, varchar(255),>
               --,<YearRequested, varchar(255),>
               --,<YearReported, varchar(10),>
               ,CASE WHEN @HasHome='Y' THEN 1 ELSE NULL END -- <Home, decimal(9,2),>
               ,CASE WHEN @HasHomeEmg='Y' THEN 1 ELSE NULL END -- <HomeEmg, decimal(9,2),>
               ,CASE WHEN @HasField='Y' THEN 1 ELSE NULL END -- <Field, decimal(9,2),>
               ,CASE WHEN @HasFieldEmg='Y' THEN 1 ELSE NULL END -- <FieldEmg, decimal(9,2),>
               ,CASE WHEN @HasStaffSel='Y' THEN 1 ELSE NULL END -- <StaffSel, decimal(9,2),>
               ,CASE WHEN @HasStaffPre='Y' THEN 1 ELSE NULL END -- <StaffPre, decimal(9,2),>
               ,CASE WHEN @HasQuasiSel='Y' THEN 1 ELSE NULL END -- <QuasiSel, decimal(9,2),>
               ,CASE WHEN @HasQuasiPre='Y' THEN 1 ELSE NULL END -- <QuasiPre, decimal(9,2),>
               ,'' -- <Comment, varchar(max),>
               ,0 -- <StatusId, int,>
               --,'New' -- <StatusName, varchar(100),>
               ,@RfpRequestMultiplierId -- <RfpRequestMultiplierId, int,>
               ,@EmpId -- <CreateUser, varchar(50),>
               ,GETDATE() -- <CreateDate, datetime,>
               ,@EmpId -- <ChangeUser, varchar(50),>
               ,GETDATE() --<ChangeDate, datetime,>
               ) 
        INSERT INTO [dbo].[VendorMultiplier]
               ([VendorId]
               ,[TaxId]
               ,[Company]
               --,[YearRequested]
               --,[YearReported]
               ,[Home]
               ,[HomeEmg]
               ,[Field]
               ,[FieldEmg]
               ,[StaffSel]
               ,[StaffPre]
               ,[QuasiSel]
               ,[QuasiPre]
               ,[Comment]
               ,[StatusId]
               --,[StatusName]
               ,[RfpRequestMultiplierId]
               ,[CreateUser]
               ,[CreateDate]
               ,[ChangeUser]
               ,[ChangeDate])
         VALUES
               (@JV2VendorId -- <VendorId, int,>
               ,@JV2TaxId -- <TaxId, varchar(15),>
               ,@JV2Company -- <Company, varchar(255),>
               --,<YearRequested, varchar(255),>
               --,<YearReported, varchar(10),>
               ,CASE WHEN @HasHome='Y' THEN 1 ELSE NULL END -- <Home, decimal(9,2),>
               ,CASE WHEN @HasHomeEmg='Y' THEN 1 ELSE NULL END -- <HomeEmg, decimal(9,2),>
               ,CASE WHEN @HasField='Y' THEN 1 ELSE NULL END -- <Field, decimal(9,2),>
               ,CASE WHEN @HasFieldEmg='Y' THEN 1 ELSE NULL END -- <FieldEmg, decimal(9,2),>
               ,CASE WHEN @HasStaffSel='Y' THEN 1 ELSE NULL END -- <StaffSel, decimal(9,2),>
               ,CASE WHEN @HasStaffPre='Y' THEN 1 ELSE NULL END -- <StaffPre, decimal(9,2),>
               ,CASE WHEN @HasQuasiSel='Y' THEN 1 ELSE NULL END -- <QuasiSel, decimal(9,2),>
               ,CASE WHEN @HasQuasiPre='Y' THEN 1 ELSE NULL END -- <QuasiPre, decimal(9,2),>
               ,'' -- <Comment, varchar(max),>
               ,0 -- <StatusId, int,>
               --,'New' -- <StatusName, varchar(100),>
               ,@RfpRequestMultiplierId -- <RfpRequestMultiplierId, int,>
               ,@EmpId -- <CreateUser, varchar(50),>
               ,GETDATE() -- <CreateDate, datetime,>
               ,@EmpId -- <ChangeUser, varchar(50),>
               ,GETDATE() --<ChangeDate, datetime,>
               )       
        END     
        **** */
    END -- Insert End
    ELSE
    BEGIN -- Update Begin
        IF (@StatusId <> -1)
            UPDATE RfpRequest SET StatusId = @StatusId,StatusDate = GETDATE(),
                ChangeUser = @EmpId, ChangeDate=GETDATE()
                WHERE Id = (Select RfpRequestId from RfpRequestMultiplier WHERE Id = @Id)

        UPDATE RfpRequestMultiplier SET 
            YearRequested = ISNULL(@YearRequested, YearRequested),
            IsJV = @IsJV, 
            JV1VendorId = @JV1VendorId,
            JV1TaxId = @JV1TaxId,
            JV2VendorId = @JV2VendorId,
            JV2TaxId = @JV2TaxId,
            HasHome = @HasHome, 
            HasHomeEmg = @HasHomeEmg, 
            HasField = @HasField, 
            HasFieldEmg = @HasFieldEmg, 
            HasQuasiPre = @HasQuasiPre, 
            HasQuasiSel = @HasQuasiSel, 
            HasStaffPre = @HasStaffPre, 
            HasStaffSel = @HasStaffSel,
            ChangeUser = @EmpId,
            ChangeDate = GETDATE()
        WHERE Id = @Id

    END  -- Update End
       
    -- populate [VendorMultiplier] with default multipiers
    IF NOT EXISTS(SELECT 1 FROM VendorMultiplier WHERE RfpRequestMultiplierId = @Id)
        INSERT INTO [dbo].[VendorMultiplier]
           ([VendorId],[TaxId],[Company]
           , Home, HomeEmg
           , Field, FieldEmg
           , StaffSel, StaffPre
           , QuasiSel, QuasiPre
           , RfpRequestMultiplierId
           ,CreateUser,CreateDate,ChangeUser,ChangeDate)
        SELECT R.VendorId, V.FederalId, V.Company
           ,CASE WHEN HasHome=1 THEN 1 ELSE NULL END 
           ,CASE WHEN HasHomeEmg=1 THEN 1 ELSE NULL END
           ,CASE WHEN HasField=1 THEN 1 ELSE NULL END
           ,CASE WHEN HasFieldEmg=1 THEN 1 ELSE NULL END
           ,CASE WHEN HasStaffSel=1 THEN 1 ELSE NULL END
           ,CASE WHEN HasStaffPre=1 THEN 1 ELSE NULL END
           ,CASE WHEN HasQuasiSel=1 THEN 1 ELSE NULL END
           ,CASE WHEN HasQuasiPre=1 THEN 1 ELSE NULL END
           ,R.Id -- <RfpRequestMultiplierId, int,>
           ,@EmpId ,GETDATE(),@EmpId ,GETDATE()
        FROM RfpRequestMultiplier R JOIN Vendor V ON R.VendorId = V.Id
        WHERE R.Id=@Id
    ELSE
        UPDATE M SET   
            Home = CASE WHEN HasHome=1 THEN COALESCE(Home, 1) ELSE null END
          , HomeEmg = CASE WHEN HasHomeEmg=1 THEN COALESCE(HomeEmg,1) ELSE NULL END
          , Field = CASE WHEN HasField=1 THEN COALESCE(Field,1) ELSE NULL END
          , FieldEmg = CASE WHEN HasFieldEmg=1 THEN COALESCE(FieldEmg,1) ELSE NULL END
          , StaffSel = CASE WHEN HasStaffSel=1 THEN COALESCE(StaffSel,1) ELSE NULL END
          , StaffPre =  CASE WHEN HasStaffPre=1 THEN COALESCE(StaffPre,1) ELSE NULL END
          , QuasiSel = CASE WHEN HasQuasiSel=1 THEN COALESCE(QuasiSel,1) ELSE NULL END
          , QuasiPre = CASE WHEN HasQuasiPre=1 THEN COALESCE(QuasiPre,1) ELSE NULL END
        FROM VendorMultiplier M JOIN RfpRequestMultiplier R ON M.RfpRequestMultiplierId = R.Id
        AND R.Id = @Id    

	COMMIT TRAN
    return @Id
END TRY
BEGIN CATCH
    ROLLBACK TRAN
    RETURN 0
END CATCH

END
GO

/* ---- Testing Code ----
USE [VASRFP]
GO

DECLARE @RC int
DECLARE @Id int = 1
DECLARE @SolicitNo varchar(20) = '20-00042R'
DECLARE @YearRequested varchar(10) = '2018,2019'
DECLARE @TaxId varchar(15) = '23-2935505'
DECLARE @IsJV bit = 0
DECLARE @JV1TaxId varchar(15) = NULL
DECLARE @JV2TaxId varchar(15) = NULL
DECLARE @HasHome bit = 0
DECLARE @HasHomeEmg bit = 0
DECLARE @HasField bit =1
DECLARE @HasFieldEmg bit=0
DECLARE @HasStaffSel bit=1
DECLARE @HasStaffPre bit=0
DECLARE @HasQuasiSel bit=1
DECLARE @HasQuasiPre bit=0
DECLARE @StatusId int=0
DECLARE @EmpId varchar(50)='TMPPCH'

EXECUTE @RC = [dbo].[UpsertRfpMultiplierRequest] 
   @Id
  ,@SolicitNo
  ,@YearRequested
  ,@TaxId
  ,@IsJV
  ,@JV1TaxId
  ,@JV2TaxId
  ,@HasHome
  ,@HasHomeEmg
  ,@HasField
  ,@HasFieldEmg
  ,@HasStaffSel
  ,@HasStaffPre
  ,@HasQuasiSel
  ,@HasQuasiPre
  ,@StatusId
  ,@EmpId

  SELECT '@RC=', @RC
GO



*/