﻿IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('[dbo].[UpdateVendorMultiplierCalcResult]'))
   EXEC('CREATE PROCEDURE [dbo].[UpdateVendorMultiplierCalcResult] AS BEGIN SET NOCOUNT ON; END')
GO
/*
*******************************************************************************
Procedure:	UpdateVendorMultiplierCalcResult
Purpose:	Save Multiplier Calculation Form Section III
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/1/2020		PCHEN				First Create
*******************************************************************************
*/
ALTER procedure [dbo].[UpdateVendorMultiplierCalcResult]
    @Id INT,
    @Line2 decimal(9,2),
    @Line6 int,
    @Multiplier decimal(9,2),
    @Comment VARCHAR(max),
	@ChangeUser varchar(50)
as
BEGIN

DECLARE @MultiplierReqId INT, @TypeId INT
SELECT @MultiplierReqId = RfpRequestMultiplierId, @TypeId = MultiplierTypeId FROM VendorMultiplierCalc WHERE Id = @Id
if @@ROWCOUNT <> 1 RETURN -2

BEGIN TRAN
BEGIN TRY
    UPDATE VendorMultiplierCalc SET
        L2_Sec1Component = @line2,
        L6_ProfitPct = @Line6,
        L8_Multiplier = @Multiplier,
        Comment = @Comment,
        ChangeUser = @ChangeUser, ChangeDate=GETDATE()
        WHERE Id = @Id

    UPDATE VendorMultiplier SET
        Home = CASE WHEN @TypeId = 1 THEN @Multiplier ELSE HOME END,
        HomeEmg = CASE WHEN @TypeId = 2 THEN @Multiplier ELSE HomeEmg END,
        Field = CASE WHEN @TypeId = 3 THEN @Multiplier ELSE Field END,
        FieldEmg = CASE WHEN @TypeId = 4 THEN @Multiplier ELSE FieldEmg END,
        StaffSel = CASE WHEN @TypeId = 5 THEN @Multiplier ELSE StaffSel END,
        StaffPre = CASE WHEN @TypeId = 6 THEN @Multiplier ELSE StaffPre END,
        QuasiSel = CASE WHEN @TypeId = 7 THEN @Multiplier ELSE QuasiSel END,
        QuasiPre = CASE WHEN @TypeId = 8 THEN @Multiplier ELSE QuasiPre END,
        ChangeDate=GETDATE(), ChangeUser = @ChangeUser
    WHERE RfpRequestMultiplierId = @MultiplierReqId    

    COMMIT TRAN;    
    RETURN 1;
END TRY
BEGIN CATCH
    ROLLBACK TRAN
    RETURN -1
END CATCH
END
GO

