USE [msdb]
GO

/****** Object:  Job [Scripts to run for UAT]    Script Date: 5/31/2019 1:32:18 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 5/31/2019 1:32:18 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Scripts to run for UAT', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'aec', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [UAT Script]    Script Date: 5/31/2019 1:32:18 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'UAT Script', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/* ** DDL change list 20170614 ***
    1. DeletePlan
    2. DeletePlanSubcontractor
    3. DeletePlanSubcontractorByPlan
    4. InsertPlanSubcontractor
    5. UpdatePlanSubcontractor
    6. ModifyEIN
    7. ModifySolicitNo    
 * ******************************** */
USE [NYCSCA_VAS_STAGE]
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = ''P'' AND OBJECT_ID = OBJECT_ID(''[dbo].[DeletePlan]''))
   EXEC(''CREATE PROCEDURE [dbo].[DeletePlan] AS BEGIN SET NOCOUNT ON; END'')
GO

/*
*******************************************************************************
Procedure:	DeletePlan
Purpose:	Delete a row from Plan table.
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/1/2010		AECSOFTUSA\Lily		Created
6/9/2017		SCA\PCHEN			Added remove record from [PlanSubcontractorPro]
*******************************************************************************
*/
ALTER PROCEDURE [dbo].[DeletePlan]
	@id int
as

declare @temp table
(
	plansubcontractorid int
)

begin transaction

begin try
	insert into @temp 
		(plansubcontractorid) 
	select 
		Id 
	from 
		PlanSubcontractor 
	where PlanId = @id
	
	delete dbo.PlanComment where PlanId = @id	
	
	delete dbo.PlanCommunicationComment where PlanId = @id	
		
	delete dbo.PlanItem where PlanId = @id	

	delete dbo.PlanProperty where PlanId = @id	

	delete dbo.PlanWaiverProject where PlanWaiverId in (select Id from PlanWaiver where PlanId = @id)
		
	delete dbo.PlanWaiverCategory where PlanWaiverId in (select Id from PlanWaiver where PlanId = @id)
		
	delete dbo.PlanWaiverDocument where PlanWaiverId in (select Id from PlanWaiver where PlanId = @id)

	delete dbo.PlanWaiver where PlanId = @id
	
	delete dbo.PlanSubcontractorCategory where PlanSubcontractorId in (select plansubcontractorid from @temp)

	delete dbo.PlanSubcontractorCertification where PlanSubcontractorId in (select plansubcontractorid from @temp)
	
	delete dbo.PlanSubcontractorDocument where PlanSubcontractorId in (select plansubcontractorid from @temp)
	
	delete dbo.PlanSubcontractorComment where PlanSubcontractorId in (select plansubcontractorid from @temp)

	delete dbo.PlanSubcontractorCommunicationComment where PlanSubcontractorId in (select plansubcontractorid from @temp)

	delete dbo.PlanSubcontractorProperty where PlanSubcontractorId in (select plansubcontractorid from @temp)
	
	delete dbo.PlanSubcontractorPro where PlanId = @id

	delete dbo.PlanSubcontractor where PlanId = @id
					
	delete [Plan] where Id = @id
	
	commit transaction
	return @@RowCount
end try
begin catch
	rollback transaction
	return 0
end catch

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = ''P'' AND OBJECT_ID = OBJECT_ID(''[dbo].[DeletePlanSubcontractor]''))
   EXEC(''CREATE PROCEDURE [dbo].[DeletePlanSubcontractor] AS BEGIN SET NOCOUNT ON; END'')
GO

/*
*******************************************************************************
Procedure:	DeletePlanSubcontractor
Purpose:	Delete a row from Plan table.
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/1/2010		AECSOFTUSA\Lily		Created
6/9/2017		SCA\PCHEN			Fix delete to PlanSubcontractorpro
*******************************************************************************
*/
ALTER PROCEDURE [dbo].[DeletePlanSubcontractor]
	@id int
as

DECLARE @isExternal BIT = 0
IF (@id < 0)
    -- 20170614 PC, 
	-- @id is deliberately marked up to negitive value from Application for deletion from "External"
    SELECT @isExternal = 1, @id = (-1)*@id

begin transaction

begin try

	delete dbo.PlanSubcontractorCategory where PlanSubcontractorId = @id

	delete dbo.PlanSubcontractorCertification where PlanSubcontractorId  = @id

	delete dbo.PlanSubcontractorDocument where PlanSubcontractorId  = @id

	delete dbo.PlanSubcontractorProperty where PlanSubcontractorId  = @id

	delete dbo.PlanSubcontractorComment where PlanSubcontractorId  = @id

	delete dbo.PlanSubcontractorCommunicationComment where PlanSubcontractorId  = @id

	if (@isExternal = 1)
	    Delete dbo.PlanSubcontractorPro Where id= @id	
	
	delete dbo.PlanSubcontractor where Id = @id						

	commit transaction

	return @@RowCount

end try

begin catch

	rollback transaction

	return 0

end catch
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = ''P'' AND OBJECT_ID = OBJECT_ID(''[dbo].[DeletePlanSubcontractorByPlan]''))
   EXEC(''CREATE PROCEDURE [dbo].[DeletePlanSubcontractorByPlan] AS BEGIN SET NOCOUNT ON; END'')
GO

/*
*******************************************************************************
Procedure:	DeletePlanSubcontractorByPlan
Purpose:	Delete a row from Plan table.
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/1/2010		AECSOFTUSA\Lily		Created
6/9/2017		SCA\PCHEN			Added delete [PlanSubcontractorPro]
*******************************************************************************
*/
ALTER PROCEDURE [dbo].[DeletePlanSubcontractorByPlan]
	@id int
as

declare @temp table
(
	plansubcontractorid int
)

begin transaction

begin try
	insert into @temp 
		(plansubcontractorid) 
	select 
		Id 
	from 
		PlanSubcontractor 
	where PlanId = @id

	delete dbo.PlanSubcontractorCategory where PlanSubcontractorId in (select plansubcontractorid from @temp)

	delete dbo.PlanSubcontractorCertification where PlanSubcontractorId in (select plansubcontractorid from @temp)
	
	delete dbo.PlanSubcontractorDocument where PlanSubcontractorId in (select plansubcontractorid from @temp)

	delete dbo.PlanSubcontractorProperty where PlanSubcontractorId in (select plansubcontractorid from @temp)
	
	delete dbo.PlanSubcontractorPro where PlanId = @id

	delete dbo.PlanSubcontractor where PlanId = @id
	
	commit transaction
	return @@RowCount
end try
begin catch
	rollback transaction
	return 0
end catch
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = ''P'' AND OBJECT_ID = OBJECT_ID(''[dbo].[InsertPlanSubcontractor]''))
   EXEC(''CREATE PROCEDURE [dbo].[InsertPlanSubcontractor] AS BEGIN SET NOCOUNT ON; END'')
GO

/*
*******************************************************************************
Procedure:	InsertPlanSubcontractor
Purpose:	Insert a row into PlanSubcontractor table.
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/1/2010		AECSOFTUSA\Lily		Created
6/9/2017		SCA\PCHEN			Completely mirror the record into [PlanSubcontractorPro]
*******************************************************************************
*/
ALTER PROCEDURE [dbo].[InsertPlanSubcontractor]
	@planId int,
	@type nvarchar(50),
	@contractType nvarchar(50),
	@taxId nvarchar(20),
	@contractNo nvarchar(50),
	@solicitId int,
	@solicitNo nvarchar(20),
	@supplierId int,
	@company nvarchar(100),
	@federalId nvarchar(20),
	@contactName nvarchar(50),
	@contactPhone nvarchar(20),
	@contactEmail nvarchar(50),
	@isSupplierOnly char(1),
	@isInternalSupplier char(1),
	@certName nvarchar(50),
	@certExpirationDate datetime,
	@isReconciled nvarchar(50),
	@sAFOverride nvarchar(50),
	@sAFSubmittedDate datetime,
	@sAFStatusDate datetime,
	@sAFEstimate nvarchar(50),
	@verifiedEstimate nvarchar(50),
	@addressLine1 nvarchar(100),
	@addressLine2 nvarchar(100),
	@city nvarchar(50),
	@state nvarchar(50),
	@zipCode nvarchar(50),
	@country nvarchar(50),
	@phone nvarchar(20),
	@fax nvarchar(20),
	@estValue float,
	@approvedValue float,
	@workDescription ntext,
	@startDate datetime,
	@endDate datetime,
	@isNonMinority char(1),
	@sAFIsNonMinority char(1),
	@supportDescription ntext,
	@isWicks char(1),
	@isUpload char(1),
	@everTBD char(1),
	@tier int,
	@phase int,
	@parentId int,
	@parentCompany nvarchar(100),
	@requestRcvdDate datetime,
	@status int,
	@statusName nvarchar(50),
	@workflowId int,
	@changeUser nvarchar(50),
	@createSupplierId int,
	@sAFId int
as
begin

	Declare 
		@intId int, 
		@isToPro bit = 0,
		@NewID UNIQUEIDENTIFIER = NEWID(),
		@Now DateTime = GETDATE()

	if (CHARINDEX(''~'',@type)>0)
		Begin
			SELECT @type= SUBSTRING ( @type ,1,CHARINDEX(''~'',@type)-1 )
				,  @isToPro = 1
		End	

	insert PlanSubcontractor
		(
			PlanSubContractorId,
			PlanId,
			Type,
			ContractType,
			TaxId,
			ContractNo,
			SolicitId,
			SolicitNo,
			SupplierId,
			Company,
			FederalId,
			ContactName,
			ContactPhone,
			ContactEmail,
			IsSupplierOnly,
			IsInternalSupplier,
			CertName,
			CertExpirationDate,
			IsReconciled,
			SAFOverride,
			SAFSubmittedDate,
			SAFStatusDate,
			SAFEstimate,
			VerifiedEstimate,
			AddressLine1,
			AddressLine2,
			City,
			State,
			ZipCode,
			Country,
			Phone,
			Fax,
			EstValue,
			ApprovedValue,
			WorkDescription,
			StartDate,
			EndDate,
			IsNonMinority,
			SAFIsNonMinority,
			SupportDescription,
			IsWicks,
			IsUpload,
			EverTBD,
			Tier,
			Phase,
			ParentId,
			ParentCompany,
			RequestRcvdDate,
			CreateDate,
			Status,
			StatusName,
			WorkflowId,
			ChangeDate,
			ChangeUser,
			CreateSupplierId,
			SAFId
		)
	values
		(
			@NewID,
			@planId,
			@type,
			@contractType,
			@taxId,
			@contractNo,
			@solicitId,
			@solicitNo,
			@supplierId,
			@company,
			@federalId,
			@contactName,
			@contactPhone,
			@contactEmail,
			@isSupplierOnly,
			@isInternalSupplier,
			@certName,
			@certExpirationDate,
			@isReconciled,
			@sAFOverride,
			@sAFSubmittedDate,
			@sAFStatusDate,
			@sAFEstimate,
			@verifiedEstimate,
			@addressLine1,
			@addressLine2,
			@city,
			@state,
			@zipCode,
			@country,
			@phone,
			@fax,
			@estValue,
			@approvedValue,
			@workDescription,
			@startDate,
			@endDate,
			@isNonMinority,
			@sAFIsNonMinority,
			@supportDescription,
			@isWicks,
			@isUpload,
			@everTBD,
			@tier,
			@phase,
			@parentId,
			@parentCompany,
			@requestRcvdDate,
			@Now,
			@status,
			@statusName,
			@workflowId,
			@Now,
			@changeUser,
			@createSupplierId,
			@sAFId
		)

	Set @intId=@@identity

	if(@isToPro = 1)
		Begin
			--INSERT INTO PlanSubcontractorPro
			--SELECT * FROM PlanSubcontractor
			--WHERE Id = @intId

			insert PlanSubcontractorPro
			(	Id,
				PlanSubContractorId,
				PlanId,
				Type,
				ContractType,
				TaxId,
				ContractNo,
				SolicitId,
				SolicitNo,
				SupplierId,
				Company,
				FederalId,
				ContactName,
				ContactPhone,
				ContactEmail,
				IsSupplierOnly,
				IsInternalSupplier,
				CertName,
				CertExpirationDate,
				IsReconciled,
				SAFOverride,
				SAFSubmittedDate,
				SAFStatusDate,
				SAFEstimate,
				VerifiedEstimate,
				AddressLine1,
				AddressLine2,
				City,
				State,
				ZipCode,
				Country,
				Phone,
				Fax,
				EstValue,
				ApprovedValue,
				WorkDescription,
				StartDate,
				EndDate,
				IsNonMinority,
				SAFIsNonMinority,
				SupportDescription,
				IsWicks,
				IsUpload,
				EverTBD,
				Tier,
				Phase,
				ParentId,
				ParentCompany,
				RequestRcvdDate,
				CreateDate,
				Status,
				StatusName,
				WorkflowId,
				ChangeDate,
				ChangeUser,
				CreateSupplierId,
				SAFId
			)
		values
			(	@intId,
				@NewID,
				@planId,
				@type,
				@contractType,
				@taxId,
				@contractNo,
				@solicitId,
				@solicitNo,
				@supplierId,
				@company,
				@federalId,
				@contactName,
				@contactPhone,
				@contactEmail,
				@isSupplierOnly,
				@isInternalSupplier,
				@certName,
				@certExpirationDate,
				@isReconciled,
				@sAFOverride,
				@sAFSubmittedDate,
				@sAFStatusDate,
				@sAFEstimate,
				@verifiedEstimate,
				@addressLine1,
				@addressLine2,
				@city,
				@state,
				@zipCode,
				@country,
				@phone,
				@fax,
				@estValue,
				@approvedValue,
				@workDescription,
				@startDate,
				@endDate,
				@isNonMinority,
				@sAFIsNonMinority,
				@supportDescription,
				@isWicks,
				@isUpload,
				@everTBD,
				@tier,
				@phase,
				@parentId,
				@parentCompany,
				@requestRcvdDate,
				@Now,
				@status,
				@statusName,
				@workflowId,
				@Now,
				@changeUser,
				@createSupplierId,
				@sAFId
			)
		End

	return @intId-- @@identity
	
end
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = ''P'' AND OBJECT_ID = OBJECT_ID(''[dbo].[ModifyEIN]''))
   EXEC(''CREATE PROCEDURE [dbo].[ModifyEIN] AS BEGIN SET NOCOUNT ON; END'')
GO

/*
*******************************************************************************
Procedure:	ModifyEIN
Purpose:	??
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
6/9/2017		SCA\PCHEN			Comment first added when added update to [PlanSubcontractorPro]
*******************************************************************************
*/
ALTER PROCEDURE [dbo].[ModifyEIN]
	@old nvarchar(50),
	@new nvarchar(50)
as
begin

SET XACT_ABORT ON

begin transaction
 
---FederalID
if exists( select * from Supplier where federalId=@old)
	update Supplier set federalId=@new where federalId=@old 

if exists( select * from Vendor where federalId=@old)
	update Vendor set federalId=@new where federalId=@old 

if exists( select * from Subcontractor where federalId=@old)
	update Subcontractor set federalId=@new where federalId=@old 

if exists( select * from [Plan] where federalId=@old)
	update [Plan] set federalId=@new where federalId=@old 
	
if exists( select * from PlanSubcontractor where federalId=@old)
BEGIN
	update PlanSubcontractor set federalId=@new where federalId=@old 
	update PlanSubcontractorPro set federalId=@new where federalId=@old 
END		
----TaxID
if exists( select * from Subcontractor where TaxId=@old)
	update Subcontractor set TaxId=@new where TaxId=@old 
	
if exists( select * from PlanSubcontractor  where TaxId=@old)
BEGIN
	update PlanSubcontractor  set TaxId=@new where TaxId=@old 	
	update PlanSubcontractorPro  set TaxId=@new where TaxId=@old 	
END		
	
if exists( select * from ScorecardProject  where TaxId=@old)
	update ScorecardProject  set TaxId=@new where TaxId=@old 
		
-----CompanyTaxId	
if exists( select * from SupplierRelatedFirm   where CompanyTaxId =@old)
	update SupplierRelatedFirm  set CompanyTaxId=@new where CompanyTaxId=@old 	
	
commit transaction
		
end
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = ''P'' AND OBJECT_ID = OBJECT_ID(''[dbo].[ModifySolicitNo]''))
   EXEC(''CREATE PROCEDURE [dbo].[ModifySolicitNo] AS BEGIN SET NOCOUNT ON; END'')
GO

/*
*******************************************************************************
Procedure:	ModifySolicitNo
Purpose:	??
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
6/9/2017		SCA\PCHEN			Comment first added when added update to [PlanSubcontractorPro]
*******************************************************************************
*/
ALTER PROCEDURE [dbo].[ModifySolicitNo]
	@old nvarchar(50),
	@new nvarchar(50)
as
begin

SET XACT_ABORT ON

begin transaction
 
if exists( select * from Subcontractor where SolicitNo=@old)
	update Subcontractor set SolicitNo=@new where SolicitNo=@old 

if exists( select * from Rfdproject where SolicitationNo=@old)
	update Rfdproject set SolicitationNo=@new where SolicitationNo=@old 

if exists( select * from Project where SolicitationNo=@old)
	update Project set SolicitationNo=@new where SolicitationNo=@old 

if exists( select * from [Contract] where SolicitationNo=@old)
	update [Contract] set SolicitationNo=@new where SolicitationNo=@old 

if exists( select * from [Bidder] where SolicitationNo=@old)
	update [Bidder] set SolicitationNo=@new where SolicitationNo=@old 	
	
if exists( select * from [Plan] where SolicitNo=@old)
	update [Plan] set SolicitNo=@new where SolicitNo=@old 

if exists( select * from [PlanSubcontractor] where SolicitNo=@old)
BEGIN
	update [PlanSubcontractor] set SolicitNo=@new where SolicitNo=@old 
	update [PlanSubcontractorPro] set SolicitNo=@new where SolicitNo=@old 
END
	
commit transaction
		
end
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = ''P'' AND OBJECT_ID = OBJECT_ID(''[dbo].[UpdatePlanSubcontractor]''))
   EXEC(''CREATE PROCEDURE [dbo].[UpdatePlanSubcontractor] AS BEGIN SET NOCOUNT ON; END'')
GO
/*
*******************************************************************************
Procedure:	UpdatePlanSubcontractor
Purpose:	Update a row in PlanSubcontractor table.
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/1/2010		AECSOFTUSA\Lily		Created
6/9/2017		SCA\PCHEN			Fix update to [PlanSubcontractorpro] for ''TBD''
*******************************************************************************
*/
ALTER PROCEDURE [dbo].[UpdatePlanSubcontractor]
	@id int,
	@planId int = null,
	@type nvarchar(50) = null,
	@contractType nvarchar(50) = null,
	@taxId nvarchar(20) = null,
	@contractNo nvarchar(50) = null,
	@solicitId int = null,
	@solicitNo nvarchar(20) = null,
	@supplierId int = null,
	@company nvarchar(100) = null,
	@federalId nvarchar(20) = null,
	@contactName nvarchar(50) = null,
	@contactPhone nvarchar(20) = null,
	@contactEmail nvarchar(50) = null,
	@isSupplierOnly char(1) = null,
	@isInternalSupplier char(1) = null,
	@certName nvarchar(50) = null,
	@certExpirationDate datetime = null,
	@isReconciled nvarchar(50) = null,
	@sAFOverride nvarchar(50) = null,
	@sAFSubmittedDate datetime = null,
	@sAFStatusDate datetime = null,
	@sAFEstimate nvarchar(50) = null,
	@verifiedEstimate nvarchar(50) = null,
	@addressLine1 nvarchar(100) = null,
	@addressLine2 nvarchar(100) = null,
	@city nvarchar(50) = null,
	@state nvarchar(50) = null,
	@zipCode nvarchar(50) = null,
	@country nvarchar(50) = null,
	@phone nvarchar(20) = null,
	@fax nvarchar(20) = null,
	@estValue float = null,
	@approvedValue float = null,
	@workDescription ntext = null,
	@startDate datetime = null,
	@endDate datetime = null,
	@isNonMinority char(1) = null,
	@sAFIsNonMinority char(1) = null,
	@supportDescription ntext = null,
	@isWicks char(1) = null,
	@isUpload char(1) = null,
	@everTBD char(1) = null,
	@tier int = null,
	@phase int = null,
	@parentId int = null,
	@parentCompany nvarchar(100) = null,
	@requestRcvdDate datetime = null,
	@status int = null,
	@statusName nvarchar(50) = null,
	@workflowId int = null,
	@changeUser nvarchar(50) = null,
	@createSupplierId int = null,
	@sAFId int= null
as

Declare  
	@rowcount INT, 
	@NOW DATETIME = GETDATE(),
	@isToPro BIT = 0
		
	if (CHARINDEX(''~'',@type)>0)
		Begin
			SELECT @type= SUBSTRING ( @type ,1,CHARINDEX(''~'',@type)-1 )
				,  @isToPro = 1
		End	


select
	@planId = isnull( @planId, PlanId ),
	@type = isnull( @type, Type ),
	@contractType = ISNULL(@contractType, ContractType),
	@taxId = isnull( @taxId, TaxId ),
	@contractNo = isnull( @contractNo, ContractNo ),
	@solicitId = isnull( @solicitId, SolicitId ),
	@solicitNo = isnull( @solicitNo, SolicitNo ),
	@supplierId = isnull( @supplierId, SupplierId ),
	@company = isnull( @company, Company ),
	@federalId = isnull( @federalId, FederalId ),
	@contactName = isnull( @contactName, ContactName ),
	@contactPhone = isnull( @contactPhone, ContactPhone ),
	@contactEmail = isnull( @contactEmail, ContactEmail ),
	@isSupplierOnly = isnull( @isSupplierOnly, IsSupplierOnly ),
	@isInternalSupplier = isnull( @isInternalSupplier, IsInternalSupplier ),
	@certName = isnull( @certName, CertName ),
	@certExpirationDate = isnull( @certExpirationDate, CertExpirationDate ),
	@isReconciled = isnull( @isReconciled, IsReconciled ),
	@sAFOverride = isnull( @sAFOverride, SAFOverride ),
	@sAFSubmittedDate = isnull( @sAFSubmittedDate, SAFSubmittedDate ),
	@sAFStatusDate = isnull( @sAFStatusDate, SAFStatusDate ),
	@sAFEstimate = isnull( @sAFEstimate, SAFEstimate ),
	@verifiedEstimate = isnull( @verifiedEstimate, VerifiedEstimate ),
	@addressLine1 = isnull( @addressLine1, AddressLine1 ),
	@addressLine2 = isnull( @addressLine2, AddressLine2 ),
	@city = isnull( @city, City ),
	@state = isnull( @state, State ),
	@zipCode = isnull( @zipCode, ZipCode ),
	@country = isnull( @country, Country ),
	@phone = isnull( @phone, Phone ),
	@fax = isnull( @fax, Fax ),
	@estValue = isnull( @estValue, EstValue ),
	@approvedValue = isnull( @approvedValue, ApprovedValue ),
	@workDescription = isnull( @workDescription, WorkDescription ),
	@startDate = isnull( @startDate, StartDate ),
	@endDate = isnull( @endDate, EndDate ),
	@isNonMinority = isnull( @isNonMinority, IsNonMinority ),
	@sAFIsNonMinority = isnull( @sAFIsNonMinority, SAFIsNonMinority ),
	@supportDescription = isnull( @supportDescription, SupportDescription ),
	@isWicks = isnull( @isWicks, IsWicks ),
	@isUpload = isnull( @isUpload, IsUpload ),
	@everTBD = ISNULL(@everTBD, EverTBD),
	@tier = isnull( @tier, Tier ),
	@phase = isnull( @phase, Phase ),
	@parentId = isnull( @parentId, ParentId ),
	@parentCompany = isnull( @parentCompany, ParentCompany ),
	@requestRcvdDate = isnull( @requestRcvdDate, RequestRcvdDate ),
	@status = isnull( @status, Status ),
	@statusName = isnull( @statusName, StatusName ),
	@workflowId = isnull( @workflowId, WorkflowId ),
	@changeUser = isnull( @changeUser, ChangeUser ),
	@createSupplierId = isnull( @createSupplierId, CreateSupplierId ),
	@sAFId = isnull( @sAFId, SAFId )
from PlanSubcontractor
where Id = @id

if @@RowCount = 0 return 0

update PlanSubcontractor

set
	PlanId = @planId,
	Type = @type,
	ContractType = @contractType,
	TaxId = @taxId,
	ContractNo = @contractNo,
	SolicitId = @solicitId,
	SolicitNo = @solicitNo,
	SupplierId = @supplierId,
	Company = @company,
	FederalId = @federalId,
	ContactName = @contactName,
	ContactPhone = @contactPhone,
	ContactEmail = @contactEmail,
	IsSupplierOnly = @isSupplierOnly,
	IsInternalSupplier = @isInternalSupplier,
	CertName = @certName,
	CertExpirationDate = @certExpirationDate,
	IsReconciled = @isReconciled,
	SAFOverride = @sAFOverride,
	SAFSubmittedDate = @sAFSubmittedDate,
	SAFStatusDate = @sAFStatusDate,
	SAFEstimate = @sAFEstimate,
	VerifiedEstimate = @verifiedEstimate,
	AddressLine1 = @addressLine1,
	AddressLine2 = @addressLine2,
	City = @city,
	State = @state,
	ZipCode = @zipCode,
	Country = @country,
	Phone = @phone,
	Fax = @fax,
	EstValue = @estValue,
	ApprovedValue = @approvedValue,
	WorkDescription = @workDescription,
	StartDate = @startDate,
	EndDate = @endDate,
	IsNonMinority = @isNonMinority,
	SAFIsNonMinority = @sAFIsNonMinority,
	SupportDescription = @supportDescription,
	IsWicks = @isWicks,
	IsUpload = @isUpload,
	EverTBD = @everTBD,
	Tier = @tier,
	Phase = @phase,
	ParentId = @parentId,
	ParentCompany = @parentCompany,
	RequestRcvdDate = @requestRcvdDate,
	Status = @status,
	StatusName = @statusName,
	WorkflowId = @workflowId,
	ChangeDate = @NOW,
	ChangeUser = @changeUser,
	CreateSupplierId = @createSupplierId,
	SAFId = @sAFId
where Id = @id

SELECT @rowcount = @@RowCount

if(@isToPro = 1)
	Begin
	Update a
	set
	a.PlanId = @planId,
	a.Type = @type,
	a.ContractType = @contractType,
	a.TaxId = @taxId,
	a.ContractNo = @contractNo,
	a.SolicitId = @solicitId,
	a.SolicitNo = @solicitNo,
	a.SupplierId = @supplierId,
	a.Company = @company,
	a.FederalId = @federalId,
	a.ContactName = @contactName,
	a.ContactPhone = @contactPhone,
	a.ContactEmail = @contactEmail,
	a.IsSupplierOnly = @isSupplierOnly,
	a.IsInternalSupplier = @isInternalSupplier,
	a.CertName = @certName,
	a.CertExpirationDate = @certExpirationDate,
	a.IsReconciled = @isReconciled,
	a.SAFOverride = @sAFOverride,
	a.SAFSubmittedDate = @sAFSubmittedDate,
	a.SAFStatusDate = @sAFStatusDate,
	a.SAFEstimate = @sAFEstimate,
	a.VerifiedEstimate = @verifiedEstimate,
	a.AddressLine1 = @addressLine1,
	a.AddressLine2 = @addressLine2,
	a.City = @city,
	a.State = @state,
	a.ZipCode = @zipCode,
	a.Country = @country,
	a.Phone = @phone,
	a.Fax = @fax,
	a.EstValue = @estValue,
	a.ApprovedValue = @approvedValue,
	a.WorkDescription = @workDescription,
	a.StartDate = @startDate,
	a.EndDate = @endDate,
	a.IsNonMinority = @isNonMinority,
	a.SAFIsNonMinority = @sAFIsNonMinority,
	a.SupportDescription = @supportDescription,
	a.IsWicks = @isWicks,
	a.IsUpload = @isUpload,
	a.EverTBD = @everTBD,
	a.Tier = @tier,
	a.Phase = @phase,
	a.ParentId = @parentId,
	a.ParentCompany = @parentCompany,
	a.RequestRcvdDate = @requestRcvdDate,
	a.Status = @status,
	a.StatusName = @statusName,
	a.WorkflowId = @workflowId,
	a.ChangeDate = @NOW,
	a.ChangeUser = @changeUser,
	a.CreateSupplierId = @createSupplierId,
	a.SAFId = @sAFId

	from PlanSubcontractorpro a
	--	Inner join PlanSubcontractor b on a.Planid=b.Planid and a.FederalId=b.FederalId and a.TaxId=b.TaxId
		Where a.id= @id	
	End 

return @rowcount

GO', 
		@database_name=N'NYCSCA_VAS_STAGE', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily run', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20170621, 
		@active_end_date=99991231, 
		@active_start_time=70000, 
		@active_end_time=235959, 
		@schedule_uid=N'bc1f8183-6c29-410c-bcdd-25067d60a7a8'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


