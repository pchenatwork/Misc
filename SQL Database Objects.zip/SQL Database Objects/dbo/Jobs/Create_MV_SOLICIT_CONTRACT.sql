/******************************************
	
	Job: Create_MV_SOLICIT_CONTRACT

	To production Apr 24 2019

*******************************************/

DECLARE @cnt INT
SELECT @cnt = CNT FROM OPENQUERY(NYCSCA_ORC, 'SELECT COUNT(*) CNT FROM MV_SOLICIT_CONTRACT')

IF @cnt > 10 -- it should have ~200 records, but unknown how that fluctuates
BEGIN


	if object_id('MV_SOLICIT_CONTRACT') is not null
		drop table MV_SOLICIT_CONTRACT	

	select * into MV_SOLICIT_CONTRACT From 
	OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_SOLICIT_CONTRACT')

	/************************************
		Liberty Mutual New Records
	*************************************/

	insert into MV_SOLICIT_CONTRACT
	select 
	replace(C_CONTRACT,'0','X'),'04-1543470',C_SOLICIT,
	N_SOLICIT_SEQ,
	C_TRANSM_NUMBER,
	VC_DESCRIPTION,
	C_CTYPE_CODE,
	C_STYPE_CODE,
	c_package_code,
	C_OFFICR_CODE,
	C_OFFICR,
	C_SR_PROJ_OFFICR_CODE,
	C_SR_PROJ_OFFICR,
	C_CHIEF_PROJ_OFFICER_CODE,
	C_CHIEF_PROJ_OFFICER,
	C_PROJ_STATION_CODE,
	C_PROJ_ACTIVITY_CODE,
	C_PROJ_STAT,
	SD_ACTUAL_BID_OPEN,
	SD_EXECUTION,
	CONTRACT_AWARD_AMOUNT,
	ME_CONTRACT,
	ME_VENDOR_ID,
	PHASE,
	SOLICIT_CANCEL_DATE,
	CONTRACT_CANCEL_DATE,
	CONTRACT_PRE_EXEC_CANCEL_DATE,
	B_REQUIREMENT,
	C_MULTI_CON,
	C_PLA,
	N_DURATION,
	D_AWARD_INTENT,
	C_PLUMBING,
	M_PLUMBING,
	C_HVAC,
	M_HVAC,
	C_ELECTRICAL,
	M_ELECTRICAL,
	D_CONSTR_FC_BEGIN,
	D_CONSTR_FC_END,
	D_CONSTR_BEGIN,
	D_CONSTR_END,
	C_BORO_CODE,
	PCT_BY_CONTRACT,
	RFP_SVCE_CODE
	From MV_SOLICIT_CONTRACT where C_CONTRACT in ('C000013288','C000013573')

	--safety: remove any records that would conflict with the renamed contracts
	delete MV_SOLICIT_CONTRACT where C_CONTRACT in ('C000014628','C000014629')

	--rename dummy records to their new contract numbers
	update MV_SOLICIT_CONTRACT set C_CONTRACT = 'C000014628' where C_CONTRACT = 'CXXXX13573'
	update MV_SOLICIT_CONTRACT set C_CONTRACT =  'C000014629' where C_CONTRACT = 'CXXXX13288'
	
	/************************************
		Generic New Records
	*************************************/
	insert into MV_SOLICIT_CONTRACT
	select 
	replace(C_CONTRACT,'0','X'),
	C_VENDOR_ID,
	C_SOLICIT,
	N_SOLICIT_SEQ,
	C_TRANSM_NUMBER,
	VC_DESCRIPTION,
	C_CTYPE_CODE,
	C_STYPE_CODE,
	c_package_code,
	C_OFFICR_CODE,
	C_OFFICR,
	C_SR_PROJ_OFFICR_CODE,
	C_SR_PROJ_OFFICR,
	C_CHIEF_PROJ_OFFICER_CODE,
	C_CHIEF_PROJ_OFFICER,
	C_PROJ_STATION_CODE,
	C_PROJ_ACTIVITY_CODE,
	C_PROJ_STAT,
	SD_ACTUAL_BID_OPEN,
	SD_EXECUTION,
	CONTRACT_AWARD_AMOUNT,
	ME_CONTRACT,
	ME_VENDOR_ID,
	PHASE,
	SOLICIT_CANCEL_DATE,
	CONTRACT_CANCEL_DATE,
	CONTRACT_PRE_EXEC_CANCEL_DATE,
	B_REQUIREMENT,
	C_MULTI_CON,
	C_PLA,
	N_DURATION,
	D_AWARD_INTENT,
	C_PLUMBING,
	M_PLUMBING,
	C_HVAC,
	M_HVAC,
	C_ELECTRICAL,
	M_ELECTRICAL,
	D_CONSTR_FC_BEGIN,
	D_CONSTR_FC_END,
	D_CONSTR_BEGIN,
	D_CONSTR_END,
	C_BORO_CODE,
	PCT_BY_CONTRACT,
	RFP_SVCE_CODE
	From MV_SOLICIT_CONTRACT where C_CONTRACT in ('C000011262')

	--safety: remove any records that would conflict with the renamed contracts
	delete MV_SOLICIT_CONTRACT where C_CONTRACT in ('C000015258')
	
	-- Alps Mechanical -> Fidelity and Deposit Co of MD
	update MV_SOLICIT_CONTRACT set C_CONTRACT = 'C000015258', C_VENDOR_ID = '13-3046577' where C_CONTRACT = 'CXXXX11262'

END
GO