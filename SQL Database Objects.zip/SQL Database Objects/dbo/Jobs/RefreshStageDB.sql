USE [msdb]
GO

/****** Object:  Job [RefreshStageDB]    Script Date: 5/31/2019 1:31:25 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 5/31/2019 1:31:25 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'RefreshStageDB', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'SCAVASSQLTEST01\Administrator', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Restore DB]    Script Date: 5/31/2019 1:31:25 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Restore DB', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/ISSERVER "\"\SSISDB\RefreshStageDB\RefreshStageDB\RefreshStageDB.dtsx\"" /SERVER SCAVASSQLTEST01 /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Process Orphan Users]    Script Date: 5/31/2019 1:31:25 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Process Orphan Users', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N''xfaceprod'')
	DROP USER [xfaceprod];
GO

alter user aec with NAME = aec_stage;
go

sp_change_users_login ''update_one'', ''aec_stage'', ''aec_stage'';
GO
sp_change_users_login ''update_one'', ''xfacetest'', ''xfacetest'';
GO
sp_change_users_login ''update_one'', ''xfaceread'', ''xfaceread'';
GO
CREATE USER [cast_read] FOR LOGIN [cast_read] WITH DEFAULT_SCHEMA=[dbo];
GO

/****** Object:  User [SCAVASTESTREAD01]    Script Date: 2/6/2018 1:08:59 PM ******/
CREATE USER [SCAVASTESTREAD01] FOR LOGIN [SCAVASTESTREAD01] WITH DEFAULT_SCHEMA=[dbo]
GO

update vendorcontact set email=''stage@nycsca.org'' where email is not null;
GO
update supplier set email=''stage@nycsca.org'' where email is not null;
GO
update [user] set email=''stage@nycsca.org'' where email is not null;
GO
update aspnet_membership set email=''stage@nycsca.org'', loweredemail=''stage@nycsca.org'' where email is not null;
GO
update supplierproperty set propertytext =''stage@nycsca.org'' where propertyId in (442, 444)
GO
update subcontractorproperty set propertytext =''stage@nycsca.org'' where propertyId in (3, 39)
GO
update [plan] set eeocontactemail =''stage@nycsca.org''
GO
update jobschedule set isactive=''N''
GO
update [EmailMessage] set toEmail=''stage@nycsca.org'' where toemail is not null
GO
 update [EmailMessage] set ccEmail=''stage@nycsca.org'' where (ccEmail is not null and ccemail<>'''')
GO
 update [EmailMessage] set bccEmail=''stage@nycsca.org'' where(bccEmail is not null and bccemail<>'''')
GO
update [PlanSubcontractor] set [ContactEmail] =''stage@nycsca.org'' where [ContactEmail] is not null
GO
update scorecard set email=''stage@nycsca.org'' where email is not null
GO
update supplier set prepareremail=''stage@nycsca.org'' where prepareremail is not null
Go
 update [cms_report_vendor] set c_email=''stage@nycsca.org'' where c_email is not null
Go
 update [cms_report_vendor] set c_email2=''stage@nycsca.org'' where c_email2 is not null
Go
 update [cms_report_vendor] set c_email3=''stage@nycsca.org'' where c_email3 is not null
Go
 update [cms_report_vendor] set secondary_email=''stage@nycsca.org'' where secondary_email is not null
 Go
 update [cms_vendor] set c_email=''stage@nycsca.org'' where c_email is not null
Go
 update [cms_vendor] set c_email2=''stage@nycsca.org'' where c_email2 is not null
Go
 update [cms_vendor] set c_email3=''stage@nycsca.org'' where c_email3 is not null
Go
 update [cms_vendor] set secondary_email=''stage@nycsca.org'' where secondary_email is not null
Go
update [PlanWaiver] set  [AdsContactEmail] =''stage@nycsca.org'' where [AdsContactEmail] is not null
go
update [owner] set email=''stage@nycsca.org'' where email is not null;
go
update [Event] set email=''stage@nycsca.org'' where email is not null;
go
update emailmessage set ToEmail=''$USEREMAIL$'' 
where name in (''USER_PASSWORD_REMINDER'',''NEW_USER_REGISTRATION'',''USER_USERNAME_REMINDER'',''USER_ACCOUNT_LOCK'',''USER_ACCOUNT_UNLOCK'',''USER_PASSWORD_RESET'')
go
EXEC sp_addrolemember ''db_datareader'', ''cast_read'';
go

EXEC sp_addrolemember ''db_datareader'', ''SCAVASTESTREAD01'';
go', 
		@database_name=N'NYCSCA_VAS_STAGE', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Other Scripts]    Script Date: 5/31/2019 1:31:25 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Other Scripts', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [NYCSCA_VAS_STAGE]
GO
/****** Object:  StoredProcedure [dbo].[GetProEstVendorsByRole]    Script Date: 8/1/2017 10:15:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


ALTER Procedure [dbo].[GetProEstVendorsByRole]
(
		@roleName varchar(100)
)

AS

begin
	Select Company, EIN,ContactType,Contact,  [Login], Email, SCARole --, VendorContactID
	from
	(
		select  gc.Company as Company,  gc.FederalId as EIN, --vcg.ID As VendorContactID,
		        Case		
					WHEN LEN(LTRIM(RTRIM(vcg.ContactType))) <= 0 THEN ''CES'' 
					ELSE vcg.ContactType
				End
				As ContactType, vcg.Name as Contact, vcg.UserName as Login,vcg.Email as Email,
				''GC'' as SCARole
		from	subcontractor s,
				vendor gc, 
				vendorcontact vcg,supplierstatus ss
		where s.TaxId=gc.federalid

		and gc.id=vcg.vendorid

		--and vcg.ContactType in (''Primary'',''Secondary'', '''')

		and isnull(vcg.Email,'''') <>''''

		and s.statusname not in (''Subcontractor closed'',''Subcontractor Deny'')

		and s.FederalId<>s.TaxId

		and gc.CurrentSupplierId =ss.SupplierId

		and ss.TypeName=''Supplier Prequalification''

		and ss.status not in (''Disqualified'',''Suspended'',''Ineligible'',''Administratively Closed'',''Deny'',''Expired'')
		
		and Exists(Select * From VendorContactRole Where VendorContactId = vcg.Id And VendorContactRoleId in (1, 2 ,3 ) )


		and gc.Company <>''''

		union

		select  

			   gc.Company as GC_Company,  gc.FederalId as GC_taxid, --vcg.ID As VendorContactID,

			   Case 
					WHEN LEN(LTRIM(RTRIM(vcg.ContactType))) <= 0 THEN ''CES'' 
					ELSE vcg.ContactType
			   End
			   As ContactType, vcg.Name as GC_Contact, vcg.UserName as GC_Login,vcg.Email as GC_Email,

			   ''Subcontractor'' as SCARole



		from   subcontractor s,

					  vendor gc, 

					  vendorcontact vcg,supplierstatus ss

		where s.FederalId=gc.federalid

		and gc.id=vcg.vendorid

		and s.statusname not in (''Subcontractor closed'',''Subcontractor Deny'')

		and s.FederalId<>s.TaxId

		and vcg.ContactType in (''Primary'',''Secondary'', '''')

		and isnull(vcg.Email,'''') <>''''

		and gc.Company <>''''

		and gc.CurrentSupplierId =ss.SupplierId

		and ss.TypeName=''Supplier Prequalification''

		and ss.status not in (''Disqualified'',''Suspended'',''Ineligible'',''Administratively Closed'',''Deny'',''Expired'')
		
		and Exists(Select * From VendorContactRole Where VendorContactId = vcg.Id And VendorContactRoleId in (1, 2 ,3 ) )

		union 

		select 

			   v.Company as GC_Company,  v.FederalId as GC_taxid, --vcg.ID As VendorContactID,

			   Case 
					WHEN LEN(LTRIM(RTRIM(vcg.ContactType))) <= 0 THEN ''CES'' 
					ELSE vcg.ContactType
			   End
			   As SubConsultant_ContactType, vcg.Name as SubConsultant_Contact, vcg.UserName as SubConsultant_Login,vcg.Email as SubConsultant_Email,

			   ''SubConsultant'' as SCARole

		from 

			   --openquery(NYCSCA_CMS,''select * from MENTOR_CONTRACT_MANAGER'') a, openquery(NYCSCA_CMS,''select * from contracts_master'') b,
			   		
			   (			
			   SELECT   DISTINCT SUBCONT.C_SUB_VENDOR_ID			
				FROM openquery(NYCSCA_CMS,''select * from CONTRACT'') CONTRACT, 		
						openquery(NYCSCA_CMS,''select * from PROJECT'') PROJECT, 
						openquery(NYCSCA_CMS,''select * from SUBCONT'') SUBCONT, 
						openquery(NYCSCA_CMS,''select * from VENDOR'') A, 
						openquery(NYCSCA_CMS,''select * from VENDOR'') B
				WHERE ( PROJECT.N_SOLICIT_SEQ = CONTRACT.N_SOLICIT_SEQ ) and		
				( CONTRACT.C_CONTRACT = SUBCONT.C_CONTRACT ) and		
				( A.C_VENDOR_ID = SUBCONT.C_SUB_VENDOR_ID ) and		
				   ( B.C_VENDOR_ID = CONTRACT.C_VENDOR_ID ) and		
				   (project.c_ctype_code) in (''AC'',''AE'',''AL'',''AP'',''AM'',''AV'')		
				   )c,

			   vendor v, 

			   vendorcontact vcg,supplierstatus ss

		where c.C_SUB_VENDOR_ID=v.federalid

		and v.id=vcg.vendorid

		--and vcg.ContactType in (''Primary'',''Secondary'','''')

		and isnull(vcg.Email,'''') <>''''

		and v.CurrentSupplierId =ss.SupplierId

		and ss.TypeName=''Supplier Prequalification''

		and ss.status not in (''Disqualified'',''Suspended'',''Ineligible'',''Administratively Closed'',''Deny'',''Expired'')
		
		and Exists(Select * From VendorContactRole Where VendorContactId = vcg.Id And VendorContactRoleId in (1, 2 ,3 ) )

 ) X 

  where (@roleName is null OR X.SCARole like ''%'' + @roleName + ''%'')

  --and ContactType = ''CES'' --and VendorContactID = 37817

   order by company


end


/*

select 						
	v.Company as GC_Company,  v.FederalId as GC_taxid, --vcg.ID As VendorContactID,					
	Case 					
					WHEN LEN(LTRIM(RTRIM(vcg.ContactType))) <= 0 THEN ''CES'' 	
					ELSE vcg.ContactType	
			   End			
			   As SubConsultant_ContactType, vcg.Name as SubConsultant_Contact, vcg.UserName as SubConsultant_Login,vcg.Email as SubConsultant_Email,			
						
			   ''SubConsultant'' as SCARole			
						
		from 				
						
			   (			
			   SELECT   DISTINCT SUBCONT.C_SUB_VENDOR_ID			
				FROM openquery(NYCSCA_CMS,''select * from CONTRACT'') CONTRACT, 		
						openquery(NYCSCA_CMS,''select * from PROJECT'') PROJECT, 
						openquery(NYCSCA_CMS,''select * from SUBCONT'') SUBCONT, 
						openquery(NYCSCA_CMS,''select * from VENDOR'') A, 
						openquery(NYCSCA_CMS,''select * from VENDOR'') B
				WHERE ( PROJECT.N_SOLICIT_SEQ = CONTRACT.N_SOLICIT_SEQ ) and		
				( CONTRACT.C_CONTRACT = SUBCONT.C_CONTRACT ) and		
				( A.C_VENDOR_ID = SUBCONT.C_SUB_VENDOR_ID ) and		
				   ( B.C_VENDOR_ID = CONTRACT.C_VENDOR_ID ) and		
				   (project.c_ctype_code) in (''AC'',''AE'',''AL'',''AP'',''AM'',''AV'')		
				   )c,		
						
			   vendor v, 			
						
			   vendorcontact vcg,supplierstatus ss			
						
		where c.C_SUB_VENDOR_ID=v.federalid				
						
		and v.id=vcg.vendorid				
						
		--and vcg.ContactType in (''Primary'',''Secondary'','''')				
						
		and isnull(vcg.Email,'''') <>''''				
						
		and v.CurrentSupplierId =ss.SupplierId				
						
		and ss.TypeName=''Supplier Prequalification''				
						
		and ss.status not in (''Disqualified'',''Suspended'',''Ineligible'',''Administratively Closed'',''Deny'',''Expired'')				
						
		and Exists(Select * From VendorContactRole Where VendorContactId = vcg.Id And VendorContactRoleId in (1, 2 ,3 ) )				
		*/

GO

ALTER PROCEDURE [dbo].[EEO_MentorGradMentorSummaryReport]
	@mentorStatus varchar(2),
	@vendorId int
AS
BEGIN
SET NOCOUNT ON;

----**PRINT ''(*) Start Proc '' + CONVERT(VARCHAR(24), GETDATE(), 113)
----** 
-- Attempt of avoiding EF "parameter sniffing"
DECLARE @status VARCHAR(2)= @mentorStatus
DECLARE @vid INT= ISNULL(@vendorID, -1)
----** 
----**PRINT ''(1) @t_supplier''
----**PRINT ''(1) Start: '' + CONVERT(VARCHAR(24), GETDATE(), 113)
DECLARE @t_supplier TABLE (
	Id INT PRIMARY KEY,
	FederalID nvarchar(20),
	SupplierId INT,
    UNIQUE NONCLUSTERED (FederalID, SupplierID)
)
INSERT INTO @t_supplier
SELECT V.Id, V.FederalId, ISNULL(V.QualifiedSupplierId, V.CurrentSupplierId) as SupplierID 
FROM vendor V 
WHERE 
(
    (@status=''A'' AND EXISTS (
        SELECT 1 FROM EEO_MENTOR_GRAD_DETAIL D 
        WHERE D.VENDORID = V.Id ))
    OR 
    (@status in (''MC'', ''GC'') AND EXISTS ( 
        SELECT 1 FROM EEO_VendorAllMentorProgs A 
        WHERE A.id = V.Id
        AND A.prog_status = @status))
) 
AND 
(
	@vid = -1 OR V.Id = @vid
);
----** 
----**PRINT ''(1) End:   '' + CONVERT(VARCHAR(24), GETDATE(), 113)
----** 
----**PRINT ''(2) @t_ContractInfo''
----**PRINT ''(2) Start :'' + CONVERT(VARCHAR(24), GETDATE(), 113)
----** 
DECLARE @t_ContractInfo TABLE(
    Id INT,
    FederalID NVARCHAR(20),
    Contract_Type VARCHAR(2),
    Contract_Count INT,
    Contract_Amt MONEY, 
    Contract_Max MONEY,
    UNIQUE CLUSTERED (Id, FederalID, Contract_Type  ))
INSERT INTO @t_ContractInfo
SELECT V.* FROM EEO_VendorContractInfo V, @t_supplier S
WHERE S.Id = V.ID
---** 
---** SELECT ''@t_ContractInfo'' tbl, * FROM @t_ContractInfo
----**PRINT ''(2) End:   '' + CONVERT(VARCHAR(24), GETDATE(), 113)
----**PRINT ''(3) @t_SubContractInfo''
----**PRINT ''(3) Start: '' + CONVERT(VARCHAR(24), GETDATE(), 113)
---** 
DECLARE @t_SubContractInfo TABLE(
    SUB_VENDOR_ID INT,
    FederalID NVARCHAR(20),
    C_EEO_CODE VARCHAR(2),
    CONTRACT_COUNT INT,
    CPONTRACT_AMT MONEY
    UNIQUE CLUSTERED (FederalID, C_EEO_CODE, SUB_VENDOR_ID))
INSERT INTO @t_SubContractInfo
SELECT V.* FROM EEO_VendorSubContractInfo V, @t_supplier S
WHERE S.FederalID = V.FederalId
---** 
---** SELECT ''@t_SubContractInfo'' tbl, * FROM @t_SubContractInfo
----**PRINT ''(3) End    '' + CONVERT(VARCHAR(24), GETDATE(), 113)
----**PRINT ''(4) @t_VendorBidInfo''
----**PRINT ''(4) Start: '' + CONVERT(VARCHAR(24), GETDATE(), 113)
DECLARE @t_VendorBidInfo TABLE(
    FederalID NVARCHAR(20),
    C_EEO_CODE VARCHAR(2),
    No_of_Bid INT,
    bid_amount MONEY,
    last_bid DATETIME
    UNIQUE CLUSTERED (FederalID, C_EEO_CODE))
INSERT INTO @t_VendorBidInfo
SELECT V.* FROM EEO_VendorBidInfo V, @t_supplier S
WHERE S.FederalID = V.FederalId

---** SELECT ''@t_VendorBidInfo'' tbl, * FROM @t_SubContractInfo
----**PRINT ''(4) End:   '' + CONVERT(VARCHAR(24), GETDATE(), 113)

Declare @onHoldtbl Table  (VENDORID int,C_BID_SUSPENSION bit,SD_START DateTime,SD_TO DateTime)

Insert into @onHoldtbl (VENDORID,C_BID_SUSPENSION,SD_START,SD_TO )
	SELECT b.VENDORID,b.C_BID_SUSPENSION,b.SD_START as SD_START,b.SD_TO As SD_TO 
	FROM DBO.EEO_VENDOR_BID B
	WHERE (B.ID = (	SELECT MAX(ID) 
					FROM EEO_VENDOR_BID B2 
					WHERE B.vendorid = B2.vendorid))
	AND (B.SD_START <  GETDATE()) 
    AND ((SD_TO IS NULL) OR (SD_TO IS NOT NULL AND SD_TO > GETDATE())) 
    AND EXISTS ( SELECT * FROM @t_supplier S WHERE S.Id = B.VENDORID )

SELECT  distinct  
    v.Id, 
    vv.SupplierID as QualifiedSupplierId,
    v.FederalId, 
    v.Company, 
    sa.AddressLine1 AS ''MailingAddressLine1'', 
    sa.AddressLine2 AS ''MailingAddressLine2'', 
    sa.City AS ''MailingCity'', 
    sa.State AS ''MailingState'', 
    sa.ZipCode AS ''MailingZipCode'', 
    sa.Country AS ''MailingCountry'', 
    vc.Name AS ''PCName'', 
    vc.Title AS ''PCTitle'', 
    vc.Phone AS ''PCPhone'', 
    vc.Fax AS ''PCFax'', 
    vc.Email AS ''PCEmail'', 
    certs.LBE_CERT,
    certs.LBE_START, 
    certs.LBE_EXP, 
    certs.MBE_CERT, 
    certs.MBE_START, 
    certs.MBE_EXP,
    certs.WBE_CERT, 
    certs.WBE_START, 
    certs.WBE_EXP, 
    COALESCE (COALESCE (certs.LBE_START, certs.MBE_START), certs.WBE_START) AS ''CertFrom'', 
    COALESCE (COALESCE (certs.LBE_EXP, certs.MBE_EXP), certs.WBE_EXP) AS ''CertTo'',
    (
	    SELECT COUNT(*)
	    FROM EEO_VENDOR_CLASSES
	    WHERE (VENDORID = vv.Id)
    ) AS ''ClassesRegistered'',
    (
	    SELECT COUNT(*)
	    FROM  EEO_VENDOR_CLASSES 
	    WHERE VENDORID = vv.Id AND C_ATTENDED = ''Y''
    ) AS ''ClassesAttended'', 
    emm.SD_START_DATE AS ''MentorStartDate'', 
    ms.Target_grad_date AS ''MentorGradDate'', 
    emg.SD_START_DATE AS ''GradMentorStartDate'', 
    ms.Target_grad_date AS ''GradMentorGradDate'', 
    ssq.V_SD_PREQUAL_TO, 
    ssq.V_M_EXP_RANGE_1, 
    ssq.V_M_EXP_RANGE_2, 
    surety.AggregateCapacity AS ''AGGBond'', 
    surety.SingleCapacity AS ''SingleBond'',
    (SELECT top 1 m_average_sales  AS Expr1
        FROM  eeo_master m WHERE (m.C_VENDOR_ID = v.FederalId)
        ) AS ''AverageSales'', 
    sstatus.Status AS CertificationStatus, 
    v.QualifiedDate, v.QualifiedExpDate, 
    sstatus2.Status AS PreQualStatus,
    '''' AS ''HasApproval'',
	ISNULL(bdm.No_of_Bid, 0) AS ''MentorNoBid'', 
	ISNULL(bdm.bid_amount, 0) AS ''MentorBidAmount'', 
	bdm.last_bid AS ''MentorLastBid'', 
	ISNULL(bdmg.No_of_Bid, 0) AS ''GradMentorNoBid'', 
	ISNULL(bdmg.bid_amount, 0) AS ''GradMentorBidAmount'', 
	bdmg.last_bid AS ''GradMentorLastBid'', 
	ISNULL(bdmo.No_of_Bid, 0) AS ''OtherNoBid'', 
	ISNULL(bdmo.bid_amount, 0) AS ''OtherBidAmount'', 
	bdmo.last_bid AS ''OtherLastBid'',

    CASE WHEN ms.is_grad_mentor = 0 THEN ms.prog_status
        ELSE '''' END AS mentor_status,
    CASE WHEN ms.is_grad_mentor = 0 THEN ms.prog_descript
        ELSE '''' END AS mentor_status_descript,
    CASE WHEN ms.is_grad_mentor = 1 THEN ms.prog_status
        ELSE '''' END AS grad_mentor_status,
    CASE WHEN ms.is_grad_mentor = 1 THEN ms.prog_descript
        ELSE '''' END AS grad_mentor_status_descript,
	    
	vme.contract_count me_contract_count ,
	vme.contract_amt   me_contract_amt  ,
	vme.contract_max   me_contract_max ,
	
	vmg.contract_count mg_contract_count ,
	vmg.contract_amt   mg_contract_amt  ,
	vmg.contract_max   mg_contract_max ,
	
	vox.contract_count ox_contract_count ,
	vox.contract_amt   ox_contract_amt  ,
	vox.contract_max   ox_contract_max ,
	
	scme.contract_count  me_sub_contract_count,
	scme.cpontract_amt  me_sub_contract_amt,
	
	scmg.contract_count  mg_sub_contract_count,
	scmg.cpontract_amt  mg_sub_contract_amt,
	
	scox.contract_count  ox_sub_contract_count,
	scox.cpontract_amt  ox_sub_contract_amt,

	(SELECT   sum(M_APPROVED) AS Expr1
		FROM            EEO_LOAN_DETAIL
		WHERE    C_APPROVAL =''Y'' AND  VENDORID = vv.Id) AS ''ApprovedLoan'',
	(select top 1 ''On Hold (From:''+cast(SD_START as varchar(12))+'' To:''+ isnull(cast(SD_TO as varchar(12)),'''') + '')'' 
		from @onHoldtbl 
		where VENDORID=vv.id) as ''OnHold'',
	( SELECT c.Name + '' | ''
        FROM suppliercategory sc, Category c
        WHERE sc.CategoryId=c.id
        AND sc.SupplierId= vv.SupplierId
        AND sc.IsApproved=''Y''
        ORDER BY c.Name
		For XML PATH ('''')
	) AS TradeCode,    
    
    ----20170720 PC: program_status_descript/program_start_end newly added
    UPPER(ms.prog_descript) AS program_status_description,
    CASE WHEN ms.Start_Date IS NULL then ''''
     ELSE UPPER(REPLACE(CONVERT(CHAR(11), ms.Start_Date, 106),'' '',''-'')) + '' - '' + UPPER(REPLACE(CONVERT(CHAR(11), ms.Target_grad_date, 106),'' '',''-'')) END AS program_start_end

FROM EEO_Vendor ev 
INNER JOIN Vendor v ON v.Id = ev.VendorId 
INNER JOIN @t_supplier vv on v.Id = vv.Id
LEFT JOIN SupplierAddress sa ON sa.SupplierId = vv.SupplierID AND sa.AddressType = ''MAILING'' 
LEFT JOIN VendorContact vc ON vc.VendorId = vv.Id AND vc.ContactType = ''Primary'' 
LEFT JOIN EEO_MENTOR_GRAD_DETAIL AS emm 
    ON emm.ID =
        (SELECT        TOP (1) ID
        FROM            EEO_MENTOR_GRAD_DETAIL
        WHERE        (VENDORID = v.Id) AND (C_MENTOR_TYPE = ''MENTOR'')) 
LEFT JOIN EEO_MENTOR_GRAD_DETAIL AS emg 
    ON emg.ID =
        (SELECT        TOP (1) ID
        FROM            EEO_MENTOR_GRAD_DETAIL
        WHERE        (VENDORID = v.Id) AND (C_MENTOR_TYPE = ''GRAD MENTOR'')) 
LEFT JOIN SupplierStaticQualification AS ssq ON ssq.SupplierId = vv.SupplierID
LEFT JOIN SupplierSurety AS surety ON surety.SupplierId = vv.SupplierID and surety.IsPrimary=''Y''
LEFT JOIN EEO_VendorLMWCertStatus AS certs ON certs.VendorID = v.Id 
LEFT JOIN SupplierStatus AS sstatus ON sstatus.SupplierId = vv.SupplierID AND sstatus.TypeName = ''Supplier Certification'' 
LEFT JOIN SupplierStatus AS sstatus2 ON sstatus2.SupplierId = vv.SupplierID AND sstatus2.TypeName = ''Supplier Prequalification'' 

    ----** This portion caused sql performance hit
/*
LEFT JOIN EEO_VendorBidInfo AS bdm ON bdm.federalid = v.FederalId AND bdm.C_EEO_CODE = ''ME'' 
LEFT JOIN EEO_VendorBidInfo AS bdmg ON bdmg.federalid = v.FederalId AND bdmg.C_EEO_CODE = ''MG'' 
LEFT JOIN EEO_VendorBidInfo AS bdmo ON bdmo.federalid = v.FederalId AND bdmo.C_EEO_CODE = ''OX''

LEFT JOIN EEO_VendorContractInfo AS vme ON vme.federalid = v.FederalId AND vme.Contract_Type = ''ME'' 
LEFT JOIN EEO_VendorContractInfo AS vmg ON vmg.federalid = v.FederalId AND vmg.Contract_Type = ''MG'' 
LEFT JOIN EEO_VendorContractInfo AS vox ON vox.federalid = v.FederalId AND vox.Contract_Type = ''OX''

LEFT JOIN EEO_VendorSubContractInfo AS scme ON scme.federalid = v.FederalId AND scme.C_EEO_CODE = ''ME'' 
LEFT JOIN EEO_VendorSubContractInfo AS scmg ON scmg.federalid = v.FederalId AND scmg.C_EEO_CODE = ''MG''
LEFT JOIN EEO_VendorSubContractInfo AS scox ON scox.federalid = v.FederalId AND scox.C_EEO_CODE = ''OX''
*/
LEFT JOIN @t_VendorBidInfo AS bdm ON bdm.federalid = v.FederalId AND bdm.C_EEO_CODE = ''ME'' 
LEFT JOIN @t_VendorBidInfo AS bdmg ON bdmg.federalid = v.FederalId AND bdmg.C_EEO_CODE = ''MG'' 
LEFT JOIN @t_VendorBidInfo AS bdmo ON bdmo.federalid = v.FederalId AND bdmo.C_EEO_CODE = ''OX''

LEFT JOIN @t_ContractInfo AS vme ON vme.federalid = v.FederalId AND vme.Contract_Type = ''ME'' 
LEFT JOIN @t_ContractInfo AS vmg ON vmg.federalid = v.FederalId AND vmg.Contract_Type = ''MG'' 
LEFT JOIN @t_ContractInfo AS vox ON vox.federalid = v.FederalId AND vox.Contract_Type = ''OX''

LEFT JOIN @t_SubContractInfo AS scme ON scme.federalid = v.FederalId AND scme.C_EEO_CODE = ''ME'' 
LEFT JOIN @t_SubContractInfo AS scmg ON scmg.federalid = v.FederalId AND scmg.C_EEO_CODE = ''MG''
LEFT JOIN @t_SubContractInfo AS scox ON scox.federalid = v.FederalId AND scox.C_EEO_CODE = ''OX''
    ----** 20170719 attempts to fix the performance issue

LEFT JOIN EEO_VendorAllMentorProgs ms ON ms.id = vv.Id

order by v.Company


----**PRINT ''(*) End Proc '' + CONVERT(VARCHAR(24), GETDATE(), 113)
----** 

END
', 
		@database_name=N'NYCSCA_VAS_STAGE', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Weekdays', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=62, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20141125, 
		@active_end_date=99991231, 
		@active_start_time=234500, 
		@active_end_time=235959, 
		@schedule_uid=N'65a509ff-01bf-425e-85ab-d57ab9a147ab'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


