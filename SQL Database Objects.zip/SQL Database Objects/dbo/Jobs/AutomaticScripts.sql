﻿PRINT N'Dropping [dbo].[ExternalSearchSupplierXmlBAK]...';


GO
DROP PROCEDURE [dbo].[ExternalSearchSupplierXmlBAK];


GO
PRINT N'Creating [dbo].[dw_v_project_dates_ntp_subcomp]...';


GO
CREATE TABLE [dbo].[dw_v_project_dates_ntp_subcomp] (
    [PACK_CD]          NVARCHAR (20) NOT NULL,
    [LLW_CD]           NVARCHAR (10) NOT NULL,
    [PHAS_FCST_BGN_DT] DATETIME      NULL,
    [PHAS_FCST_END_DT] DATETIME      NULL,
    [PHAS_ACTL_END_DT] DATETIME      NULL
);


GO
PRINT N'Creating [dbo].[ntp]...';


GO
CREATE TABLE [dbo].[ntp] (
    [PACK_CD]          NVARCHAR (20) NOT NULL,
    [LLW_CD]           NVARCHAR (10) NOT NULL,
    [PHAS_FCST_BGN_DT] DATETIME      NULL,
    [PHAS_FCST_END_DT] DATETIME      NULL,
    [PHAS_ACTL_END_DT] DATETIME      NULL
);


GO
PRINT N'Altering [dbo].[OutlookByUserCount]...';


GO
ALTER FUNCTION [dbo].[OutlookByUserCount]
(
	@userId int,
	@spName nvarchar(50),
	@roleName nvarchar(50)
)
RETURNS int
AS
BEGIN

DECLARE @count int
set @count = 0

declare @userGuid uniqueidentifier
declare @username nvarchar(50)
select @userGuid = u.UserId, @username = au.Username from [User] u, aspnet_users au
	where u.Id = @userId and u.UserId = au.UserId

--#region Other Items
declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime
if(DatePart(Month,getdate()) < 7)
begin
	set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
	set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
end
else
begin
	set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
	set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
end

declare @propertyId_ReviewerId int
set @propertyId_ReviewerId = 10
declare @propertyId_ManagerId int
set @propertyId_ManagerId = 521
declare @propertyId_IOGDecision int
set @propertyId_IOGDecision = 508
declare @propertyId_CertificationAnalyst int
set @propertyId_CertificationAnalyst = 524

-- subcontractor properties
declare @scpropertyId_ReviewerId int
set @scpropertyId_ReviewerId = 1

-- project properties
declare @ppropertyId_CQUReviewer int
set @ppropertyId_CQUReviewer = 45

--#endregion Other Items

--#region Workflow Items
declare @WORKFLOW_QUALIFICATION int
declare @NewPrequalification int
declare @ApplicationSubmitted int
declare @ManagerReviewed int
declare @RequestMoreInfo int
declare @ReferenceReviewed int
declare @FinacialReviewed int
declare @OIGApproved int
declare @Qualified int
declare @PreDeny int
declare @AdministrativelyClosed int
declare @AllReviewed int
declare @RequestMoreInfoPending int
declare @DirectorClosed int
declare @DirectorClosePending int
declare @AdditionalInfoSubmitted int
declare @ReviewerReviewed int
declare @Inactive int
declare @QualifiedPending int
declare @Disqualified int
declare @Withdrawn int
declare @OIGReviewed int
declare @Rescinded int
declare @Suspended int
declare @RequestMoreInfo2 int
declare @AdditionalInfoSubmitted2 int
declare @OIGPending int

declare @WORKFLOW_CERTIFICATION int
declare	@NewCertification int
declare	@CertificationSubmitted int
declare	@CertificationAnalystReviewed int
declare	@RequestMoreCertificationInfoPending int
declare	@RequestMoreCertificationInfo int
declare	@AdditionalCertificationInfoSubmitted int
declare	@MWBEReviewed int
declare	@LBEReviewed int
declare	@CertificationAnalystApproved int
declare	@DirectorApprovalPending int
declare	@Certified int
declare	@CertificationAnalystClosed int
declare	@CertificationClosed int
declare	@DirectorApproved int

Set @WORKFLOW_QUALIFICATION = 1
Set @NewPrequalification = 1
Set @ApplicationSubmitted = 2
Set @ManagerReviewed = 3
Set @RequestMoreInfo = 6
Set @ReferenceReviewed = 7
Set @FinacialReviewed = 29
Set @OIGApproved = 70
Set @Qualified = 71
Set @PreDeny = 72
Set @AdministrativelyClosed = 73
Set @AllReviewed = 74
Set @RequestMoreInfoPending = 80
Set @DirectorClosed = 82
Set @DirectorClosePending = 86
Set @AdditionalInfoSubmitted = 89
Set @ReviewerReviewed = 111
Set @Inactive = 113
Set @QualifiedPending = 124
Set @Disqualified = 244
Set @Withdrawn = 245
Set @OIGReviewed = 246
Set @Rescinded = 257
Set @Suspended = 258
Set @RequestMoreInfo2 = 291
Set @AdditionalInfoSubmitted2 = 292
Set @OIGPending = 488

Set @WORKFLOW_CERTIFICATION = 2
Set @NewCertification =47	 
Set @CertificationSubmitted =48	 
Set @CertificationAnalystReviewed =49	 
Set @RequestMoreCertificationInfoPending =50	 
Set @RequestMoreCertificationInfo =51	 
Set @AdditionalCertificationInfoSubmitted =92	 
Set @MWBEReviewed =93	 
Set @LBEReviewed =94	 
Set @CertificationAnalystApproved =95	 
Set @DirectorApprovalPending = 97	
Set @Certified =98	 
Set @CertificationAnalystClosed =99	 
Set @CertificationClosed = 100	
Set @DirectorApproved =213	
--#endregion Workflow Items

-- Check whether the logged in user is CQU Financial Analyst
	declare @cquFinancialAnalystCount int
	select @cquFinancialAnalystCount=count(u.id) 
	from 
		aspnet_UsersInRoles ar
		inner join [user] u on ar.UserId=u.UserId
		inner join aspnet_Roles a on ar.RoleId=a.RoleId
	where u.id=@userId
	and a.RoleName='CQU Financial Analyst'



------------ CQU Manager ----------

-- (FindItem192) Pending Prequalifications
IF ( @spName = 'FindItem192' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 2 != 2 
	and dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem11) Pending Requalifications
IF ( @spName = 'FindItem11' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 2 = 2 and ss.Status is not null and ss.Status not in (
								'Qualified'
								,'New Qualification'
								,'Administratively Closed'
								,'Inactive'
								,'Withdrawn'
								,'Disqualified'
								,'Rescinded'
								,'Suspended'
								,'Deny'
								,'Expired'
							)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
	
-- (FindItem12) New Assignments (Triage)
IF ( @spName = 'FindItem12' )
BEGIN
	if(dbo.IsUserIdInRole(@userGuid, 'Prequal New Assignment') = 1)
	begin
		Select @count = count(s.Id)
		from Supplier s
			left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
			left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
			left join supplierversion sv on s.Id = sv.SupplierId
		where ss.Status = 'Application Submitted'
		and s.Status & 2 != 2
		and sp.PropertyText is null
		and (sv.status is null or sv.status <> 0)  
		RETURN @count
	end	
	if(dbo.IsUserIdInRole(@userGuid, 'Requal New Assignment') = 1)
	begin
		Select @count = count(s.Id)
		from Supplier s
			left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
			left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
			left join supplierversion sv on s.Id = sv.SupplierId
		where ss.Status = 'Application Submitted'
		and s.Status & 2 = 2
		and sp.PropertyText is null
		and (sv.status is null or sv.status <> 0)  
		RETURN @count
	end
	if(dbo.IsUserIdInRole(@userGuid, 'Small Bus New Assignment') = 1)
	begin
		Select @count = count(s.Id)
		from Supplier s
			left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
			left join SupplierStatus ss1 on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
			left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
			left join supplierversion sv on s.Id = sv.SupplierId
		where ss.Status = 'Application Submitted'
		and ss1.Status = 'Certification Submitted'
		and sp.PropertyText is null
		and (sv.status is null or sv.status <> 0)  
		RETURN @count
	end
	RETURN @count
END

-- (FindItem13) Pending Final Review
IF ( @spName = 'FindItem13' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified Pending'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem14) Files Returned to Reviewer
IF ( @spName = 'FindItem14' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'OIG Reviewed'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem15) Managers Assigned Files
--IF ( @spName = 'FindItem15' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where isnull(ss.Status,'') in ('Application Submitted','OIG Approved')
--	and substring(sp.PropertyText, 1, 50) = @username
--	and (sv.status is null or sv.status <> 0)  
--RETURN @count
--END

-- (FindItem16) Pending Certifications
IF ( @spName = 'FindItem16' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null and ss1.Status not in (
					'Certified'
					,'New Certification'
					,'Admin Closed'
					,'Withdrawn'
					,'Disqualified'
					,'Decertified'
					,'Rescinded'
					,'Suspended'
					,'Deny'
					,'Expired'
					,'Archived'
				)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
------------ End CQU Manager ----------

-------- CQU Reviewer --------------

-- (FindItem17) New Assignments
IF ( @spName = 'FindItem17' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Manager Reviewed'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem18) Total Number of Files Per Reviewer
IF ( @spName = 'FindItem18' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null and ss.Status in ( 'Manager Reviewed'
													,'Reviewer Reviewed'
													,'Request More Info Pending'
													,'Request More Info'
													,'Additional Info Submitted'
													,'Reference Reviewed'
													,'Financial Reviewed'
													,'Reference and Financial Reviewed'
													,'OIG Approved'
													,'Qualified Pending'
													,'OIG Reviewed'
													,'Request More Info 2'
													,'Additional Info Submitted 2'
													)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem19) 30 Day Sent
IF ( @spName = 'FindItem19' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Request More Info'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem20) Unresponsive  to 30 Days
IF ( @spName = 'FindItem20' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Request More Info'
	and s.id in (select supplierid from SupplierStaticQualification where DateDiff(Day,getdate(),V_SD_ADDL_SENT) < -30)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem27) Amended OIG Signoffs
IF ( @spName = 'FindItem27' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s		
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Qualified'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem28) True Requals
IF ( @spName = 'FindItem28' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null and ss.Status in ( 
				'Manager Reviewed'
				,'Reviewer Reviewed'
				,'Request More Info Pending'
				,'Request More Info'
				,'Additional Info Submitted'
				,'Reference Reviewed'
				,'Financial Reviewed'
				,'Reference and Financial Reviewed'
				,'OIG Approved'
				,'Qualified Pending'
				,'OIG Reviewed'
				,'Request More Info 2'
				,'Additional Info Submitted 2'
				)
	and s.Status & 2 = 2
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- !!ONHOLD!!(FindItem29) Priority/Pending Contract
--IF ( @spName = 'FindItem29' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where isnull(ss.Status,'') = 'Qualified'
--	and substring(sp.PropertyText, 1, 50) = @username
--	and (sv.status is null or sv.status <> 0)  
--RETURN @count
--END

-- !!ONHOLD!!(FindItem30) Pending RFC Limited List
--IF ( @spName = 'FindItem30' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where isnull(ss.Status,'') = 'Qualified'
--	and substring(sp.PropertyText, 1, 50) = @username
--	and (sv.status is null or sv.status <> 0)  
--RETURN @count
--END

-- (FindItem31) Pending OIG Signoff
IF ( @spName = 'FindItem31' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') in (
									 'Reference Reviewed'
									,'Financial Reviewed'
									,'Reference and Financial Reviewed'
								   )
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem32) 10 Day Fax
IF ( @spName = 'FindItem32' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Request More Info 2'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem33) Unresponsive to 10 Days
IF ( @spName = 'FindItem33' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Request More Info 2'
	and s.id in (select supplierid from SupplierStaticQualification where DateDiff(Day,getdate(),V_SD_ADDL_SENT2) < -10) -- more than 10 days
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- !!ONHOLD!!(FindItem34) Pending Safety Review
--IF ( @spName = 'FindItem34' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where
--	ubstring(sp.PropertyText, 1, 50) = @username
--	and (sv.status is null or sv.status <> 0)
--RETURN @count
--END

-- (FindItem35) Predenials
IF ( @spName = 'FindItem35' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null and ss.Status = 'PreDeny'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem36) Final Denials
IF ( @spName = 'FindItem36' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Deny'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- !!ONHOLD!!(FindItem37) OIG 15 Day Letters
--IF ( @spName = 'FindItem37' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
--		or 'CQU Director' in (select rolename from @userroles)
--		or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
--	and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
--RETURN @count
--END

-- (FindItem38) OIG Letter of Concern
IF ( @spName = 'FindItem38' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp2 on s.Id = sp2.SupplierId and sp2.PropertyId = @propertyId_IOGDecision
		left join supplierversion sv on s.Id = sv.SupplierId
	where convert(nvarchar(500),sp2.PropertyText) = 'Provide Letter of Concern'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem39) Files with OIG Denials
IF ( @spName = 'FindItem39' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join supplierworkflow sw	on s.id = sw.supplierid and sw.workflowid = @WORKFLOW_CERTIFICATION
		left join workflowhistory wh1	on sw.transactionid = wh1.transactionheaderid 
		left join workflowhistory wh2	on wh1.prevhistoryid = wh2.id
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where wh1.id is not null
	and wh2.id is not null
	and wh1.CurrentNodeId = @DirectorClosePending 
	and wh2.currentnodeid in (@ReferenceReviewed,@FinacialReviewed)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem40) Pending Reference Outreach
IF ( @spName = 'FindItem40' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Reviewer Reviewed'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem41) Pending Financial Review
IF ( @spName = 'FindItem41' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') in ('Reviewer Reviewed','Reference Reviewed')
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- !!ONHOLD!!(FindItem42) Firms Pending SAF References
--IF ( @spName = 'FindItem42' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--				left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
--				left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
--	where ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
--		or 'CQU Director' in (select rolename from @userroles)
--		or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
--	and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
--RETURN @count
--END

-- (FindItem43) Amended Trade Codes
IF ( @spName = 'FindItem43' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem45) Pending Over 1 Million
IF ( @spName = 'FindItem45' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 2 != 2 and ss.Status is not null and ss.Status not in (	
										 'Qualified'
										,'New Qualification'
										,'Administratively Closed'
										,'Inactive'
										,'Withdrawn'
										,'Disqualified'
										,'Rescinded'
										,'Suspended'
										,'Deny'
										,'Expired'							
								  )
	and s.id in(
				select supplierid from suppliercategory sc 
					left join category c on sc.categoryid = c.id
				where 
					((convert(int,c.code) < 31000 or (convert(int,c.code) > 37117 and convert(int,c.code) < 80000) or convert(int,c.code) > 86100) and convert(int,c.code) != 37100)
				and
					isnull(Average,'') = 'over'
			   )
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem46) Firms with Joint Venture
IF ( @spName = 'FindItem46' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where LegalStructure = 'Joi'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem47) Files A/C
IF ( @spName = 'FindItem47' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Administratively Closed'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem48) Files re-opened
IF ( @spName = 'FindItem48' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.id in (select supplierid from SupplierStaticQualification where	V_cd_reopen_date is not null)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- !!ONHOLD!!(FindItem49) Pending Reinstatement
--IF ( @spName = 'FindItem49' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--				left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
--				left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
--	where ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
--		or 'CQU Director' in (select rolename from @userroles)
--		or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
--	and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
--RETURN @count
--END

-- (FindItem50) Amended-Key People
IF ( @spName = 'FindItem50' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Change in Application'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Change In Application Submitted'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem51) Amended-Qual Over 1 Million
IF ( @spName = 'FindItem51' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Over 1MM Application Submitted'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem52) 60 Day notice Letter
IF ( @spName = 'FindItem52' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where	  isnull(ss.Status,'') = 'Qualified'
	and s.id in (select supplierid from SupplierStaticQualification where DateDiff(Day,getdate(),V_SD_NOTICE_LTR) between 0 and 60)-- within 60 days of expiring
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem53) Firms unreponsive-60 day letter
IF ( @spName = 'FindItem53' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where	  isnull(ss.Status,'') = 'Qualified'							
	and s.id in (select supplierid from SupplierStaticQualification where DateDiff(Day,getdate(),V_SD_PREQUAL_TO) < 0)--more than 3 years from qual date
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem54) Total Number of Files
IF ( @spName = 'FindItem54' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where	  ss2.Status in (	
										 'Manager Reviewed'
										,'Reviewer Reviewed'
										,'Request More Info Pending'
										,'Request More Info'
										,'Additional Info Submitted'
										,'Reference Reviewed'
										,'Financial Reviewed'
										,'Reference and Financial Reviewed'
										,'OIG Approved'
										,'Qualified Pending'
										,'OIG Reviewed'
										,'Request More Info 2'
										,'Additional Info Submitted 2'							
								  )
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
-------- End CQU Reviewer

-------- MWLBE CERTIFICATION -----------------

-- (FindItem55) New Applications Received FYTD
IF ( @spName = 'FindItem55' )
BEGIN
	Select @count = count(distinct s.Id)
	from Supplier s
		left join supplierversion sv on s.Id = sv.SupplierId
		, SupplierStaticCertification ssc
	where s.id = ssc.SupplierId and V_SD_APPL_DATE between @firstDayOfYear and @firstDayOfNextYear
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem56) New Applications Assigned to Certification Analysts for Review
IF ( @spName = 'FindItem56' )
BEGIN
	Select @count = count(distinct s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status in ('Certification Submitted', 'Certification Analyst Assigned')
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem57) Certification Applications Awaiting Assignment to Analyst
IF ( @spName = 'FindItem57' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Certification Submitted'
	and substring(isnull(sp.PropertyText, ''), 1, 50) = ''
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem58) Total Number of Certified Firms
IF ( @spName = 'FindItem58' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s 
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Certified'
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem59) Total Number of Firms that are Certified and Prequalified 
IF ( @spName = 'FindItem59' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s 
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss1.Status,'') = 'Certified'
	and	  isnull(ss2.Status,'') = 'Qualified'
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem60) Total Number of Firms Pending Certification
IF ( @spName = 'FindItem60' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s 
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1 
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem61) Total Number of Firms that are Pending Certification and Prequalification
IF ( @spName = 'FindItem61' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 1 = 1 and ss1.Status is not null and ss1.Status not in (
				'Certified'
				,'New Certification'
				,'Admin Closed'
				,'Withdrawn'
				,'Disqualified'
				,'Decertified'
				,'Rescinded'
				,'Suspended'
				,'Deny'
				,'Expired'
				,'Archived'
				)
	and	 s.Status &2 = 2 and ss2.Status is not null and ss2.Status not in (
				 'Qualified'
				,'New Qualification'
				,'Administratively Closed'
				,'Inactive'
				,'Withdrawn'
				,'Disqualified'
				,'Rescinded'
				,'Suspended'
				,'Deny'
				,'Expired'
				)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem62) Total Number of Certified Firms that are Pending Prequalification
IF ( @spName = 'FindItem62' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss1.Status,'') = 'Certified'
	and	 s.Status & 2 != 2 and ss2.Status is not null and ss2.Status not in (
					 'Qualified'
					,'New Qualification'
					,'Administratively Closed'
					,'Inactive'
					,'Withdrawn'
					,'Disqualified'
					,'Rescinded'
					,'Suspended'
					,'Deny'
					,'Expired'
					)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem64) Total Number of Recertification Applications Received
IF ( @spName = 'FindItem64' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss1.Status,'') = 'Certification Submitted'
	and s.Status & 1 = 1
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem65) Total Number of Firms Pending Recertification
IF ( @spName = 'FindItem65' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 1 = 1 and ss1.Status is not null and ss1.Status not in (
				'Certified'
				,'New Certification'
				,'Admin Closed'
				,'Withdrawn'
				,'Disqualified'
				,'Decertified'
				,'Rescinded'
				,'Suspended'
				,'Deny'
				,'Expired'
				,'Archived'																				
			)
	--isnull(ss1.Status,'') = 'Certified'
	--and s.id in (select supplierid from SupplierStaticCertification where DateDiff(Day,getdate(),V_sd_exp_date) between 0 and 60 ) -- within 60 days of expiring
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- !!ON HOLD!!	(FindItem66) Priority Certification
--IF ( @spName = 'FindItem66' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
	
--RETURN @count
--END

-- (FindItem67) Total Number of Firms that Certification will Lapsed within 60 days
IF ( @spName = 'FindItem67' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
		, SupplierStaticCertification ssc
	where isnull(ss.Status,'') = 'Certified'
	and s.id = ssc.SupplierId and DateDiff(Day,getdate(),V_sd_exp_date) between -1 and -60  -- has expired within the last 60 days
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem68) Total Number of Firms that Certification will Lapsed within 30 days
IF ( @spName = 'FindItem68' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
		, SupplierStaticCertification ssc
	where isnull(ss.Status,'') = 'Certified'
	and s.id = ssc.SupplierId and DateDiff(Day,getdate(),V_sd_exp_date) between -1 and -30  -- has expired within the last 30 days
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem69) 30 Day Notices Sent
IF ( @spName = 'FindItem69' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem70) 10 Day Fax
IF ( @spName = 'FindItem70' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info 2'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem71) Predenials - Certification and Prequalification
IF ( @spName = 'FindItem71' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss1.Status is not null and ss2.Status is not null
	and   ss2.Status = 'PreDeny'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem72) Firms with OIG Letters of Concern
IF ( @spName = 'FindItem72' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Id in (select supplierid from supplierdocument where type = 'ConcernLetter')
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem73) Conditional Certifications Awaiting Prequalification
IF ( @spName = 'FindItem73' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss1.Status is not null and ss1.Status = 'Director Approved'
	and	  ss2.Status is not null and ss2.Status  in (
			 'Application Submitted'
			,'Manager Reviewed'
			,'Reviewer Reviewed'
			,'Request More Info Pending'
			,'Request More Info'
			,'Additional Info Submitted'
			,'Reference Reviewed'
			,'Financial Reviewed'
			,'Reference and Financial Reviewed'
			,'OIG Approved'
			,'Qualified Pending'
			,'OIG Reviewed'
			,'Request More Info 2'
			,'Additional Info Submitted 2'
			)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem74) Number of Rejected Firms (Certification/Prequalification)
IF ( @spName = 'FindItem74' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss1.Status is not null and ss1.Status = 'Admin Closed'
	and	  ss2.Status is not null
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem75) # of Prequalified Firms- Pending Certification
--IF ( @spName = 'FindItem75' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--				left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
--				left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
--	where s.Status & 1 != 1 and ss1.Status is not null and ss1.Status not in (
--					 'Certified'
--					,'New Certification'
--					,'Admin Closed'
--					,'Withdrawn'
--					,'Disqualified'
--					,'Decertified'
--					,'Rescinded'
--					,'Suspended'
--					,'Deny'
--					,'Expired'
--					,'Archived'
--					)
--	and	  ss2.Status is not null and ss2.Status = 'Qualified'
--	and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
--RETURN @count
--END

-- !!ON HOLD!!	(FindItem76) Firms with Red Flags - MWLBE Audit flag
--IF ( @spName = 'FindItem76' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-----------------------------------------------

-- !!ON HOLD!!	(FindItem77) Certified Firms Approved SAF
--IF ( @spName = 'FindItem77' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem78) Certified Firms Denied SAF Approval
--IF ( @spName = 'FindItem78' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem79) Certified Firms Pending SAF Approval
--IF ( @spName = 'FindItem79' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- (FindItem120) Certification Information Pending 
IF ( @spName = 'FindItem120' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
				left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
	where isnull(ss.Status,'') in ('Request More Certification Info','Request More Certification Info 2')
	and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
RETURN @count
END

-- !!ONHOLD!!(FindItem121) Certified Firms Pending SAF Approvals
IF ( @spName = 'FindItem121' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- (FindItem123) Firms Pending Recertification 
IF ( @spName = 'FindItem123' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
	where isnull(ss1.Status,'') = 'Certification Submitted'
	and s.Status & 1 = 1
	and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
RETURN @count
END

-- !!ONHOLD!!(FindItem124) MWLBE Firms Awaiting Audit
IF ( @spName = 'FindItem124' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem125) MWLBE Firms that have been audited
IF ( @spName = 'FindItem125' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- (FindItem130) Total # of Files
IF ( @spName = 'FindItem130' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

----------------- End MWBE Certification -------------------


-- !!ON HOLD!!	(FindItem80) Total Mentor Eligible Firms approved for program - awaiting signed agreement
--IF ( @spName = 'FindItem80' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem81) Total Mentor Eligible firms interview scheduled
--IF ( @spName = 'FindItem81' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem82) Total Mentor Eligible firms interviewed - awaiting program entry dates
--IF ( @spName = 'FindItem82' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem83) Total Mentor Eligible firms interviewed - denied program entry
--IF ( @spName = 'FindItem83' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem84) Total Mentor Eligible firms pending mentor program approval
--IF ( @spName = 'FindItem84' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem85) Total Mentor Eligible firms signed that interested in participating in Mentor Program
IF ( @spName = 'FindItem85' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem86) Total number of firms in Mentor Program
IF ( @spName = 'FindItem86' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem87) Graduate Mentor Limited List Awaiting Vetting and Approval
IF ( @spName = 'FindItem87' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem88) Mentor Limited List Assigned to Analyst for Vetting
IF ( @spName = 'FindItem88' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem89) Mentor Limited List Awaiting Vetting and Approval
IF ( @spName = 'FindItem89' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem90) Mentor Limited List Vetted - Approved by Senior Director and Submitted to Director of Mentor Program for Approval
IF ( @spName = 'FindItem90' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem91) Mentor Limited List Vetted - Awaiting Approval by Senior Director
IF ( @spName = 'FindItem91' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem92) # Mentor program participants on active bid lists
IF ( @spName = 'FindItem92' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem93) Certified firms pending SAF (Mentor Program eligible)
IF ( @spName = 'FindItem93' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem94) Certified firms that are pending pre-qualification (Mentor Program eligible only)
IF ( @spName = 'FindItem94' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem95) Conditional certifications awaiting pre-qualification (Mentor Program eligible)
IF ( @spName = 'FindItem95' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem96) Current workload for Graduate Mentor Program participants
IF ( @spName = 'FindItem96' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem97) Current workload for Mentor Program participants
IF ( @spName = 'FindItem97' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem98) Firms pending pre-qualification-not certified (Mentor Program eligible only)
IF ( @spName = 'FindItem98' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem99) Firms whose certification will lapse in 30 days (Mentor Program eligible only)
IF ( @spName = 'FindItem99' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem100) Firms with OIG letters of concern (Mentor Program eligible only)
IF ( @spName = 'FindItem100' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem101) List current participants of the Graduate Program
IF ( @spName = 'FindItem101' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem102) List current participants of the Mentor Program
IF ( @spName = 'FindItem102' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem103) Mentor participants that were taken off bid lists
IF ( @spName = 'FindItem103' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem104) Mentor Program participants current bid lists
IF ( @spName = 'FindItem104' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem105) Mentor Program Participants with Negative Project Evaluations
IF ( @spName = 'FindItem105' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem106) Mentor Program participants with negative vedex information
IF ( @spName = 'FindItem106' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem107) Pending  Graduate Mentor Program bid lists
IF ( @spName = 'FindItem107' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem108) Pending Mentor Program bid lists
IF ( @spName = 'FindItem108' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem109) Predenial - certification and pre-qualification (Mentor Program eligible only)
IF ( @spName = 'FindItem109' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem110) Rejected firms - certification and pre-qualification (Mentor Program eligible)
IF ( @spName = 'FindItem110' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem111) Certified firms pending SAF (Mentor Program eligible)
IF ( @spName = 'FindItem111' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem112) Current workload for Mentor Program participants
IF ( @spName = 'FindItem112' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem113) Firms with OIG letters of concern (Mentor Program eligible only)
IF ( @spName = 'FindItem113' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem114) List new participants of the Mentor Program
IF ( @spName = 'FindItem114' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem115) Mentor Program Firms that Bid on Mentor Jobs
IF ( @spName = 'FindItem115' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem116) Mentor Program Firms with Negative Evaluations
IF ( @spName = 'FindItem116' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem117) Pending Mentor Program bid lists
IF ( @spName = 'FindItem117' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END


-- !!ONHOLD!!(FindItem133) Certified Firms Approved SAF
IF ( @spName = 'FindItem133' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem134) Certified Firms Denied SAF Approval
IF ( @spName = 'FindItem134' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem135) Certified Firms Pending SAF Approval
IF ( @spName = 'FindItem135' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem136) Total Mentor Eligible Firms approved for program - awaiting signed agreement
IF ( @spName = 'FindItem136' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem137) Total Mentor Eligible firms interview scheduled
IF ( @spName = 'FindItem137' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem138) Total Mentor Eligible firms interviewed - awaiting program entry dates
IF ( @spName = 'FindItem138' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem139) Total Mentor Eligible firms interviewed - denied program entry
IF ( @spName = 'FindItem139' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem140) Total Mentor Eligible firms pending mentor program approval
IF ( @spName = 'FindItem140' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem141) Total Mentor Eligible firms signed that interested in participating in Mentor Program
IF ( @spName = 'FindItem141' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem142) Total number of firms in Mentor Program
IF ( @spName = 'FindItem142' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

----------------------- OIG Management ----------------

-- (FindItem146) Total Pending OIG Signoff
IF ( @spName = 'FindItem146' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') in (
									 'Reference Reviewed'
									,'Financial Reviewed'
									,'Reference and Financial Reviewed'
								   )
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem147) Total OIG 15 Day Letters
--IF ( @spName = 'FindItem147' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where isnull(ss.Status,'') in (
--									 'Reference Reviewed'
--									,'Financial Reviewed'
--									,'Reference and Financial Reviewed'
--								   )
--	and (sv.status is null or sv.status <> 0)  
--RETURN @count
--END

-- (FindItem148) Total OIG Letter of Concern
IF ( @spName = 'FindItem148' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp2 on s.Id = sp2.SupplierId and sp2.PropertyId = @propertyId_IOGDecision
		left join supplierversion sv on s.Id = sv.SupplierId
	where convert(nvarchar(500),sp2.PropertyText) = 'Provide Letter of Concern'
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem149) Total Files with OIG Denials
IF ( @spName = 'FindItem149' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join supplierworkflow sw	on s.id = sw.supplierid and sw.workflowid = @WORKFLOW_CERTIFICATION
		left join workflowhistory wh1	on sw.transactionid = wh1.transactionheaderid 
		left join workflowhistory wh2	on wh1.prevhistoryid = wh2.id
		left join supplierversion sv on s.Id = sv.SupplierId
	where wh1.id is not null
	and wh2.id is not null
	and wh1.CurrentNodeId = @DirectorClosePending 
	and wh2.currentnodeid in (@ReferenceReviewed,@FinacialReviewed)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem294) Pending True Requal
IF ( @spName = 'FindItem294' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
		left join SupplierProperty sp2 on s.Id = sp2.SupplierId and sp2.PropertyId = @propertyId_IOGDecision
		left join supplierworkflow sw	on s.id = sw.supplierid and sw.workflowid = @WORKFLOW_QUALIFICATION
		left join workflowhistory wh1	on sw.transactionid = wh1.transactionheaderid 
		left join SupplierStaticQualification sq	on s.id = sq.supplierid 
	where isnull(ss.Status,'') in ( 'OIG Pending', 'Qualified Pending', 'Qualified' )
	and isnull(convert(nvarchar(500), sp2.PropertyText), '') = ''
	and wh1.CurrentNodeId = 488 
	and isnull(sq.V_C_APPR_IG, '') != 'Y'
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem295) Incomplete by OIG
IF ( @spName = 'FindItem295' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'OIG Qualification'
	where isnull(ss.Status,'') in ( 'Incomplete by OIG' )
RETURN @count
END


-- (FindItem296) Resubmission to OIG
IF ( @spName = 'FindItem296' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'OIG Qualification'
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Prequalification' 
	where isnull(ss.Status,'') in ( 'Resubmission to OIG' )
	-- Resubmission to OIG for release 3.0
	and isnull(ss1.Status,'')  not in ('Qualified', 'Deny','Withdrawn','Suspended','Qualification Pending','Disqualified','Rescinded','')
	
RETURN @count
END


-- FindItem297-- Review Amended Key People
IF ( @spName = 'FindItem297' )
BEGIN
	Select	@count = count(distinct s.supplierid)
	from	Supplierpersonnel s
	where	isKeyperson='Y'
	and 	status!=4
	and		OIGReviewed=2
	and		IsVerified='Y'
	
RETURN @count
END


----------------------- End OIG Management ----------------

------------ Qualification Status ----------

-- (FindItem150) Application Submitted
IF ( @spName = 'FindItem150' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Application Submitted'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem151) Manager Reviewed
IF ( @spName = 'FindItem151' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Manager Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem274) Pre Deny
IF ( @spName = 'FindItem274' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'PreDeny'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem152) Request More Info Pending
IF ( @spName = 'FindItem152' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info Pending'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem153) Request More Info
IF ( @spName = 'FindItem153' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem154) Additional Info Submitted
IF ( @spName = 'FindItem154' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Info Submitted'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem155) Request More Info 2
IF ( @spName = 'FindItem155' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info 2'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem156) Additional Info Submitted 2
IF ( @spName = 'FindItem156' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Info Submitted 2'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem157) Reviewer Reviewed
IF ( @spName = 'FindItem157' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reviewer Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
		or @cquFinancialAnalystCount>0) --In case of CQU Financial Analyst show all the Reference Reviewed firms as the Financial Analysis is the next Step
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem158) Reference Reviewed
IF ( @spName = 'FindItem158' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reference Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
		or @cquFinancialAnalystCount>0) -- In case of CQU Financial Analyst show all the Reference Reviewed firms as the Financial Analysis is the next Step
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem159) Financial Reviewed
IF ( @spName = 'FindItem159' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Financial Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
	
-- (FindItem160) Reference and Financial Reviewed
IF ( @spName = 'FindItem160' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reference and Financial Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
	
-- (FindItem161) OIG Approved
IF ( @spName = 'FindItem161' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'OIG Approved'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
	
-- (FindItem162) OIG Reviewed
IF ( @spName = 'FindItem162' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'OIG Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem627) OIG Incomplete
IF ( @spName = 'FindItem627' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'OIG Qualification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Incomplete by OIG'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

	
-- (FindItem163) OIG Pending
IF ( @spName = 'FindItem163' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'OIG Pending'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
	
-- (FindItem164) Qualified Pending
IF ( @spName = 'FindItem164' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified Pending'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
	
-- (FindItem165) Qualified
IF ( @spName = 'FindItem165' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem193) Unsubmitted Applications
IF ( @spName = 'FindItem193' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'New Qualification'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
------------ End Qualification Status ----------

------------ Trade Code Amendments ----------

-- (FindItem628) Amended Trade Code Application Submitted
IF ( @spName = 'FindItem628' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Amended Trade Code Application Submitted'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem629) Manager Reviewed
IF ( @spName = 'FindItem629' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Manager Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem630) Reviewer Reviewed
IF ( @spName = 'FindItem630' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reviewer Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
		Or @cquFinancialAnalystCount>0)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem631) Request More Info
IF ( @spName = 'FindItem631' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem632) Qualified 
IF ( @spName = 'FindItem632' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

------------ End Trade Code Amendments ----------

------------ Over 1MM Amendments ----------

-- (FindItem633) Over 1MM Application Submitted
IF ( @spName = 'FindItem633' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Over 1MM Application Submitted'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem634) Manager Reviewed
IF ( @spName = 'FindItem634' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Manager Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem635) Reference Reviewed
IF ( @spName = 'FindItem635' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reference Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
		Or @cquFinancialAnalystCount>0)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem636) Finacial Reviewed
IF ( @spName = 'FindItem636' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Finacial Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem637) Reference and Finacial Reviewed
IF ( @spName = 'FindItem637' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reference and Finacial Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem638) Reviewer Reviewed
IF ( @spName = 'FindItem638' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reviewer Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
		Or @cquFinancialAnalystCount>0)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem639) Qualified
IF ( @spName = 'FindItem639' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

------------ End Over 1MM Amendments ----------


------------ Certification Status ----------
-- (FindItem166) Certification Submitted
IF ( @spName = 'FindItem166' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certification Submitted'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem167) Certification Analyst Assigned
IF ( @spName = 'FindItem167' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certification Analyst Assigned'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem168) Request More Certification Info Pending
IF ( @spName = 'FindItem168' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info Pending'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem169) Request More Certification Info
IF ( @spName = 'FindItem169' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem170) Additional Certification Info Submitted
IF ( @spName = 'FindItem170' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Certification Info Submitted'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem171) Request More Certification Info 2
IF ( @spName = 'FindItem171' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info 2'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem172) Additional Certification Info Submitted 2
IF ( @spName = 'FindItem172' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Certification Info Submitted 2'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem173) Certification Analyst Reviewed
IF ( @spName = 'FindItem173' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certification Analyst Reviewed'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem174) MWBE Reviewed
IF ( @spName = 'FindItem174' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'MWBE Reviewed'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem175) LBE Reviewed
IF ( @spName = 'FindItem175' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'LBE Reviewed'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem176) Certification Analyst Approved
IF ( @spName = 'FindItem176' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certification Analyst Approved'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem177) Director Approval Pending
IF ( @spName = 'FindItem177' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Director Approval Pending'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem178) Director Approved
IF ( @spName = 'FindItem178' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Director Approved'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem179) Conditionally Certified
IF ( @spName = 'FindItem179' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Conditionally Certified'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem180) Certified
IF ( @spName = 'FindItem180' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certified'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem194) Unsubmitted Applications
IF ( @spName = 'FindItem194' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'New Certification'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

------------ End Certification Status ----------

------------ CQU & BDD Aging ----------
-- (FindItem181) CQU Aging 0 - 3 Months
IF ( @spName = 'FindItem181' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between DateAdd(month, -3, getdate()) and getdate())
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem182) CQU Aging 3 - 6 Months
IF ( @spName = 'FindItem182' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between DateAdd(month, -6, getdate()) and DateAdd(month, -3, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem183) CQU Aging 6 - 9 Months
IF ( @spName = 'FindItem183' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between DateAdd(month, -9, getdate()) and DateAdd(month, -6, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem184) CQU Aging 9 - 12 Months
IF ( @spName = 'FindItem184' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between DateAdd(month, -12, getdate()) and DateAdd(month, -9, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem185) CQU Aging 12 Months and more
IF ( @spName = 'FindItem185' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between '01/01/1901' and DateAdd(month, -12, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem186) BDD Aging 0 - 3 Months
IF ( @spName = 'FindItem186' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between DateAdd(month, -3, getdate()) and getdate())
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem187) BDD Aging 3 - 6 Months
IF ( @spName = 'FindItem187' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between DateAdd(month, -6, getdate()) and DateAdd(month, -3, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem188) BDD Aging 6 - 9 Months
IF ( @spName = 'FindItem188' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between DateAdd(month, -9, getdate()) and DateAdd(month, -6, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem189) BDD Aging 9 - 12 Months
IF ( @spName = 'FindItem189' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between DateAdd(month, -12, getdate()) and DateAdd(month, -9, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem190) BDD Aging 12 Months and more
IF ( @spName = 'FindItem190' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between '01/01/1901' and DateAdd(month, -12, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

IF @spName = 'FindPendingReleaseEvaluation'
BEGIN
	Select @count = count(Id)
	from Scorecard
	Where UserId = @userId and Status = 1

	RETURN @count
END

IF @spName = 'FindToBeEvaluatedEvaluation'
BEGIN
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status in (0, 1, 3)
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.SupervisorType = @roleName

	RETURN @count
END

IF @spName = 'FindPendingEvaluation'
BEGIN
	-- Evaluator
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.UserId = @userId and i.Status in (0, 1, 3)
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.UserType = @roleName

	-- Supervisor (Overdue)
	Select @count = @count + count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status in (8)
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.SupervisorType = @roleName

	-- Supervisor (Declined)
	Select @count = @count + count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status in (2)
	and ((s.Type != 'Mentor A' and datediff(day, s.ReleaseDate, getdate()) <= 14)
		or (s.Type = 'Mentor A' and datediff(day, s.CreateDate, getdate()) <= 14))
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.SupervisorType = @roleName
	
	-- Unassigned HazMat Phase
	Select @count = @count + count(Id)
	from Scorecard
	Where UserId = @userId and Status = 2 and CategoryId = 0 and Type in ('HazMat','Non-Hazmat')

	RETURN @count
END

IF @spName = 'FindOverdueEvaluation'
BEGIN
	-- Evaluator
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.UserId = @userId and i.Status in (8, 9)
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.UserType = @roleName

	-- Supervisor
	Select @count = @count + count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status = 2
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and ((s.Type != 'Mentor A'
		and datediff(day, s.ReleaseDate, getdate()) > 14
		and datediff(day, s.ReleaseDate, getdate()) <= 21)
		or (s.Type = 'Mentor A'
		and datediff(day, s.CreateDate, getdate()) > 14
		and datediff(day, s.CreateDate, getdate()) <= 21))
	and i.SupervisorType = @roleName

	-- Supervisor
	Select @count = @count + count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status = 9
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.SupervisorType = @roleName

	RETURN @count
END

IF @spName = 'FindPendingApprovalEvaluation'
BEGIN
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status = 5
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.SupervisorType = @roleName
	and s.CloseDate > getdate()
	
			
	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Status = 44 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Hazmat')
		and u.UserType in ('IEH Deputy Director')
		and u.UserType = @roleName
		
	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Status = 44 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Non-Hazmat')
		and u.UserType in ('IEH Manager')
		and u.UserType = @roleName

	RETURN @count
END

IF @spName = 'FindRejectedToEvaluation'
BEGIN
	-- Supervisor
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status = 7
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.SupervisorType = @roleName
	and s.CloseDate > getdate()

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status = 37
	and i.UserType = @roleName and i.UserType = 'Design Manager'
	
	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status = 38
	and i.UserType = @roleName and i.UserType = 'Deputy Director'

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status = 39
	and i.UserType = @roleName and i.UserType = 'Director'

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status = 24
	and i.UserType = @roleName and i.UserType in ('Chief Project Officer',
		'Bronx CPO', 'Brooklyn CPO', 'Manhattan CPO', 'Queens CPO', 'Staten Island CPO')

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status = 33
	and i.UserType = @roleName and i.UserType = 'VP for Construction Mgmt'

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status = 43
	and i.UserType = @roleName and i.UserType = 'IEH Hygienist C'

	RETURN @count
END

IF @spName = 'FindRejectedEvaluation'
BEGIN
	-- Evaluator
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.UserId = @userId and i.Status = 7
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.UserType = @roleName
	and s.CloseDate > getdate()

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status in (37, 38, 39)
	and i.UserType = 'Design Project Manager'
	and i.UserType = @roleName

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status in (33)
	and i.UserType in ('Chief Project Officer',
		'Bronx CPO', 'Brooklyn CPO', 'Manhattan CPO', 'Queens CPO', 'Staten Island CPO')
	and i.UserType = @roleName

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status in (29, 33)
	and i.UserType = 'Senior Director of BDD'
	and i.UserType = @roleName

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status in (43)
	and i.UserType = 'IEH Hygienist B'
	and i.UserType = @roleName

	RETURN @count
END

IF @spName = 'FindDeclinedEvaluation'
BEGIN
	-- Evaluator
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.UserId = @userId and i.Status = 2
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.UserType = @roleName
	and ((s.Type != 'Mentor A' and datediff(day, s.ReleaseDate, getdate()) <= 21)
		or (s.Type = 'Mentor A' and datediff(day, s.CreateDate, getdate()) <= 21))

	RETURN @count
END

IF @spName = 'FindPendingReviewEvaluation'
BEGIN
	Select @count = count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 4 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Capacity', 'CIP')
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
		and u.UserType = 'Design Project Manager'
		and u.UserType = @roleName
		
	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity', 'CIP') and s.Status = 4
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
		and u.UserType = 'Design Manager'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity', 'CIP') and s.Status = 5
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
		and u.UserType = 'Design Manager'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity') and s.Status in (4, 5)
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
		and u.UserType = 'Deputy Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity') and s.Status = 7
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
		and u.UserType = 'Deputy Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity') and s.Status in (4, 5, 7, 8)
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 16
		and u.UserType = 'Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity') and s.Status = 8
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 16
		and u.UserType = 'Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity') and s.Status = 12
		and s.Id = u.ScorecardId and u.UserId = @userId
		and u.UserType in ('Director')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('CIP') and s.Status = 12
		and s.Id = u.ScorecardId and u.UserId = @userId
		and u.UserType in ('Deputy Director')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 4 and s.Id = u.ScorecardId
		and s.Type in ('CCFU') and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
		and u.UserType = 'Operations Supervisor'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type = 'CCFU' and s.Status = 4 
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
		and u.UserType in ('Operations Director')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type = 'CCFU' and s.Status = 16 
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
		and u.UserType in ('Operations Director')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 2 and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) <= 4
		and s.Type in ('Mentor A Contract')
		and u.UserType in ('Chief Project Officer',
			'Bronx CPO', 'Brooklyn CPO', 'Manhattan CPO', 'Queens CPO', 'Staten Island CPO')
		and u.UserType = @roleName
		and isnull(u.Status, 0) = 0
		
	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 2 and s.Id = u.ScorecardId and u.UserId = @userId
			and datediff(day, s.CreateDate, getdate()) > 4
			and datediff(day, s.CreateDate, getdate()) <= 8
		and s.Type in ('Mentor A Contract')
		and u.UserType = 'VP for Construction Mgmt'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 22 and s.Id = u.ScorecardId and u.UserId = @userId
			and datediff(day, s.CreateDate, getdate()) <= 8
		and s.Type in ('Mentor A Contract')
		and u.UserType = 'VP for Construction Mgmt'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type = 'Mentor A Contract' and s.Status in (12, 36)
		and s.Id = u.ScorecardId and u.UserId = @userId
		and u.UserType in ('VP for Construction Mgmt')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 4 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Mentor B')
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
		and u.UserType in ('VP for Construction Mgmt')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 25 and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.VPCMApprovalDate, getdate()) <= 4
		and s.Type in ('Mentor B')
		and u.UserType in ('VP of Admin')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 12 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Mentor B')
		and u.UserType in ('VP for Construction Mgmt')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 2 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Project', 'Contract')
		and datediff(day, s.CreateDate, getdate()) <= 4
		and u.UserType = 'Design Project Manager'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status = 2
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) > 4
		and datediff(day, s.CreateDate, getdate()) <= 8
		and u.UserType = 'Design Manager'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status = 5
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) <= 8
		and u.UserType = 'Design Manager'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status in (2, 5)
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) > 8
		and datediff(day, s.CreateDate, getdate()) <= 12
		and u.UserType = 'Deputy Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status = 26
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) <= 12
		and u.UserType = 'Deputy Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status in (2, 5, 26)
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) > 12
		and datediff(day, s.CreateDate, getdate()) <= 16
		and u.UserType = 'Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status = 27
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) <= 16
		and u.UserType = 'Director'
		and u.UserType = @roleName

	Select @count = @count + count(Id)
	from Scorecard
	where Status = 13 and Type in ('Contract') and dbo.IsUserInRole(@userId, 'VP for Construction Mgmt') = 1
		and @roleName = 'VP for Construction Mgmt'

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Status = 14 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Contract')
		and u.UserType in ('Director')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Hazmat', 'Non-Hazmat') and s.Status = 4
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
		and u.UserType = 'IEH Hygienist C'
		and u.UserType = @roleName

	--Select @count = @count + count(s.Id)
	--from Scorecard s, ScorecardUser u
	--where s.Status = 42 and s.Id = u.ScorecardId and u.UserId = @userId
	--	and s.Type in ('Hazmat')
	--	and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
	--	and u.UserType in ('IEH Deputy Director')
	--	and u.UserType = @roleName

	--Select @count = @count + count(s.Id)
	--from Scorecard s, ScorecardUser u
	--where s.Status = 42 and s.Id = u.ScorecardId and u.UserId = @userId
	--	and s.Type in ('Non-Hazmat')
	--	and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
	--	and u.UserType in ('IEH Manager')
	--	and u.UserType = @roleName
		
	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Status = 4 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Hazmat Contract')
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
		and u.UserType in ('IEH Deputy Director')
		and u.UserType = @roleName
		
	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Status = 4 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Non-Hazmat Contract')
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
		and u.UserType in ('IEH Manager')
		and u.UserType = @roleName
	
	RETURN @count
END

IF @spName = 'FindOverdueReviewEvaluation'
BEGIN
	Select @count = count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity', 'CIP') and s.Status = 4
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType = 'Design Project Manager'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Capacity', 'CIP') and s.Status in (4, 5)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
		and u.UserType = 'Design Manager'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Capacity') and s.Status in (4, 5, 7)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
		and u.UserType in ('Deputy Director')
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Capacity') and s.Status in (4, 5, 7, 8)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 16
		and u.UserType in ('Director')
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('CCFU') and s.Status = 4
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType = 'Operations Supervisor'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('CCFU') and s.Status in (4, 16)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
		and u.UserType = 'Operations Director'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Mentor A Contract') and s.Status = 2
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.CreateDate, getdate()) > 4
		and u.UserType in ('Chief Project Officer',
			'Bronx CPO', 'Brooklyn CPO', 'Manhattan CPO', 'Queens CPO', 'Staten Island CPO')
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Mentor A Contract') and s.Status in (2, 22)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.CreateDate, getdate()) > 8
		and u.UserType = 'VP for Construction Mgmt'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Mentor B') and s.Status = 4
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType = 'VP for Construction Mgmt'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Mentor B') and s.Status = 25
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.VPCMApprovalDate, getdate()) > 4
		and u.UserType = 'VP of Admin'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status = 2
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) > 4
		and u.UserType = 'Design Project Manager'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Project', 'Contract') and s.Status in (2, 5)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.CreateDate, getdate()) > 8
		and u.UserType = 'Design Manager'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Project', 'Contract') and s.Status in (2, 5, 26)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.CreateDate, getdate()) > 12
		and u.UserType in ('Deputy Director')
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Project', 'Contract') and s.Status in (2, 5, 26, 27)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.CreateDate, getdate()) > 16
		and u.UserType in ('Director')
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Hazmat', 'Non-Hazmat') and s.Status = 4
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType = 'IEH Hygienist C'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Hazmat') and s.Status = 42
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType = 'IEH Manager'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Non-Hazmat') and s.Status = 42
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType = 'IEH Deputy Director'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Status = 4 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Non-Hazmat Contract', 'Hazmat Contract')
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType in ('IEH Deputy Director')
		and u.UserType = @roleName
	
	RETURN @count
END

IF @spName = 'FindPendingCIPReviewEvaluation'
BEGIN
	Select @count = count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('CIP') and s.Status in (4, 5)
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
		and u.UserType = 'Deputy Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('CIP') and s.Status = 7
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
		and u.UserType = 'Deputy Director'
		and u.UserType = @roleName

	RETURN @count
END

IF @spName = 'FindOverdueCIPReviewEvaluation'
BEGIN
	Select @count = count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('CIP') and s.Status in (4, 5, 7)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
		and u.UserType in ('Deputy Director')
		and u.UserType = @roleName
		and u.Status = 0

	RETURN @count
END

IF @spName = 'FindInProgressEvaluation'
BEGIN
	-- Evaluator
	Select @count = count(t.Id)
	From
	(
		Select s.Id
		from ScorecardInvitee i, Scorecard s
		where i.UserId = @userId and 
		(
			(i.Status in (4, 6) and s.Type != 'Mentor A')
			 or (i.Status = 5)
		)
		and i.ScorecardId = s.Id and s.Status not in (1, 18, 19, 20, 98, 99)
		and i.UserType = @roleName

		union

		-- Supervisor
		Select s.Id
		from ScorecardInvitee i, Scorecard s
		where i.SupervisorId = @userId and 
		(
			(i.Status in (4, 6) and s.Type != 'Mentor A')
			or (i.Status = 5)
		)
		and i.ScorecardId = s.Id and s.Status not in (1, 18, 19, 20, 98, 99)
		and i.SupervisorType = @roleName

		union

		-- Reviewer
		Select s.Id
		from ScorecardUser i, Scorecard s
		where i.UserId = @userId and i.Status = 1
		and i.ScorecardId = s.Id and s.Status not in (1, 2, 3, 18, 19, 20, 98, 99)
		and i.UserType = @roleName
		and s.Type != 'Mentor A Contract'

		union

		-- Reviewer
		Select s.Id
		from ScorecardUser i, Scorecard s
		where i.UserId = @userId and i.Status = 1
		and i.ScorecardId = s.Id and s.Status not in (1, 3, 18, 19, 20, 98, 99)
		and i.UserType = @roleName
		and s.Type = 'Mentor A Contract'
	) t

	RETURN @count
END

IF @spName = 'FindNotNotifiedEvaluation'
BEGIN
	Select @count = count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Status = 19 and s.FinalUserId = @userId
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and u.UserType = @roleName

	RETURN @count
END
------------ Prequal Limited List Status ----------

-- (FindItem265) New List
IF ( @spName = 'FindItem265' )
BEGIN
	Select @count = count(distinct [transm_number])
	from mv_cms_rfc
	where c_appr_cpo = @Username
		and l_mentor = 0 and isnull(m_topackage_amt, 0) > 1000000
		and [transm_number] not in (Select TransNumber From RfdProject Where Status != 98)
RETURN @count
END

-- (FindItem213) New Project
IF ( @spName = 'FindItem213' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 0 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem214) Ready For Review
IF ( @spName = 'FindItem214' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 4 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem215) Pending CPO Approval
IF ( @spName = 'FindItem215' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 1 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem216) Pending VP for Construction Mgmt Approval
IF ( @spName = 'FindItem216' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 2 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem217) Pending VP of Admin Approval
IF ( @spName = 'FindItem217' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 3 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem218) Info Ready
IF ( @spName = 'FindItem218' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 6 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem219) Request More Info
IF ( @spName = 'FindItem219' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 5 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem220) Reviewer Reviewed
IF ( @spName = 'FindItem220' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 7 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem221) Question From Manager
IF ( @spName = 'FindItem221' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 8 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem222) Manager Approved
IF ( @spName = 'FindItem222' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 9 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem223) Question From Director
IF ( @spName = 'FindItem223' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 10 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END


-- (FindItem224) Director Approved
IF ( @spName = 'FindItem224' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 11 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem225) VP of Admin Approved
IF ( @spName = 'FindItem225' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 12 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem226) Chief Project officer Approved
IF ( @spName = 'FindItem226' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 13 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem227) VP for Construction Mgmt Approved
IF ( @spName = 'FindItem227' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 14 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem228) General Counsel Approved
IF ( @spName = 'FindItem228' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 15 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem229)President Approved
IF ( @spName = 'FindItem229' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 16 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem230)Approved
IF ( @spName = 'FindItem230' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 17 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
		and IsFinal = 'Y' and SolicitSeq > 0
RETURN @count
END

-- (FindItem231)Pending Refresh
IF ( @spName = 'FindItem231' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 25 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem232)Refreshed
IF ( @spName = 'FindItem232' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 26 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem233)Cancelled
IF ( @spName = 'FindItem233' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 98 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem234)Inactive
IF ( @spName = 'FindItem234' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 100 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem262)Approved Pending Final RFC
IF ( @spName = 'FindItem262' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 17 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
		and isnull(IsFinal, '') != 'Y' and isnull(SolicitSeq, 0) = 0
RETURN @count
END

-- (FindItem263)RFC Approved
IF ( @spName = 'FindItem263' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where (p.Status = 26 or p.Status = 27) and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

------------ End Prequal Limited List Status ----------

------------ Mentor Limited List Status ----------

-- (FindItem266) New List
IF ( @spName = 'FindItem266' )
BEGIN
	Select @count = count(distinct [transm_number])
	from mv_cms_rfc
	where c_appr_cpo = @Username
		and (l_mentor = 1 or (l_mentor = 0 and isnull(m_topackage_amt, 0) <= 1000000))
		and [transm_number] not in (Select TransNumber From RfdProject Where Status != 98)
RETURN @count
END

-- (FindItem235) New Project
IF ( @spName = 'FindItem235' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 0 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem236) Construction management Selected
IF ( @spName = 'FindItem236' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 18 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END


-- (FindItem237) Info Ready
IF ( @spName = 'FindItem237' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 6 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END


-- (FindItem238) Criteria Pending Approval
IF ( @spName = 'FindItem238' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 20 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem239) Pending Director of Mentor Program Approval
IF ( @spName = 'FindItem239' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 21 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem240) Pending CPO Approval
IF ( @spName = 'FindItem240' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 1 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem241) Pending Vetting
IF ( @spName = 'FindItem241' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 22 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem242) Analyst Reviewed
IF ( @spName = 'FindItem242' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 23 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END


-- (FindItem243) BDD Director Approved
IF ( @spName = 'FindItem243' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 24 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem244) Approved
IF ( @spName = 'FindItem244' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 17 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem245) Closed
IF ( @spName = 'FindItem245' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 99 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem246) Inactive
IF ( @spName = 'FindItem246' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 100 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

------------ End Mentor Limited List Status ----------

------------ SAF Status ----------

-- (FindItem267) New Subcontractor
IF ( @spName = 'FindItem267' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 0
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem268) Subcontractor VAS Prepared
IF ( @spName = 'FindItem268' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 4
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem275) Subcontractor Manager Reviewed
IF ( @spName = 'FindItem275' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 5
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem276) Subcontractor Request More Info
IF ( @spName = 'FindItem276' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 7
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem277) Subcontractor Additional Info Submitted
IF ( @spName = 'FindItem277' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 8
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem269) Subcontractor Reviewer Vetted
IF ( @spName = 'FindItem269' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 6
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem270) Subcontractor CQU Approved
IF ( @spName = 'FindItem270' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 11
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem271) Subcontractor OIG Reviewed
IF ( @spName = 'FindItem271' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 12
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem279) Subcontractor Insurance Pending
IF ( @spName = 'FindItem279' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 23
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem272) Subcontractor Pending
IF ( @spName = 'FindItem272' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 17
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem278) Pending Insurance Certificate
IF ( @spName = 'FindItem278' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status in (17, 13)
	and isnull(IsUpload, '') != 'Y' 
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem273) Subcontractor Approved
IF ( @spName = 'FindItem273' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 13
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem758) Subcontractor OIG Deny
IF ( @spName = 'FindItem758' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 14
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
END

-- (FindItem729) Subcontractor OIG Denied
IF ( @spName = 'FindItem729' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 20
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
END

------------ End SAF Status ----------

------------ Start Mentor SAF ----------

-- (FindItem647) Mentor SAF - New Subcontractor'
IF ( @spName = 'FindItem647' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 0
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
		
		
RETURN @count
END
-- (FindItem648) Mentor SAF - Subcontractor VAS Prepared'
IF ( @spName = 'FindItem648' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 4
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem649) Mentor SAF - Subcontractor Reviewer Vetted'
IF ( @spName = 'FindItem649' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 6
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem650) Mentor SAF - Subcontractor CQU Approved'
IF ( @spName = 'FindItem650' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 11
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem651) Mentor SAF - Subcontractor OIG Reviewed'
IF ( @spName = 'FindItem651' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 12
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem652) Mentor SAF - Subcontractor Pending'
IF ( @spName = 'FindItem652' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 17
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem653) Mentor SAF - Subcontractor Approved'
IF ( @spName = 'FindItem653' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 13
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem654) Mentor SAF - Subcontractor Manager Reviewed'
IF ( @spName = 'FindItem654' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 5
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem655) Mentor SAF - Subcontractor Request More Info'
IF ( @spName = 'FindItem655' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 7
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem656) Mentor SAF - Subcontractor Additional Info Submitted'
IF ( @spName = 'FindItem656' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 8
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem657) Mentor SAF - Pending Insurance Certificate'
IF ( @spName = 'FindItem657' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status in (17, 13)
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem658) Mentor SAF - Subcontractor Insurance Pending'
IF ( @spName = 'FindItem658' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 23
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END

-- (FindItem731) Mentor SAF - Subcontractor OIG Denied'
IF ( @spName = 'FindItem731' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 20
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))

END

------------ End Mentor SAF ----------


------------ Start Prime SAF ----------


-- (FindItem659) Prime SAF - New Subcontractor'
IF ( @spName = 'FindItem659' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 0
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem660) Prime SAF - Subcontractor VAS Prepared'
IF ( @spName = 'FindItem660' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 4
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem661) Prime SAF - Subcontractor Reviewer Vetted'
IF ( @spName = 'FindItem661' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 6
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem662) Prime SAF - Subcontractor CQU Approved'
IF ( @spName = 'FindItem662' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 11
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem663) Prime SAF - Subcontractor OIG Reviewed'
IF ( @spName = 'FindItem663' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 12
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem664) Prime SAF - Subcontractor Pending'
IF ( @spName = 'FindItem664' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 17
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem665) Prime SAF - Subcontractor Approved'
IF ( @spName = 'FindItem665' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 13
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem666) Prime SAF - Subcontractor Manager Reviewed'
IF ( @spName = 'FindItem666' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 5
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem667) Prime SAF - Subcontractor Request More Info'
IF ( @spName = 'FindItem667' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 7
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem668) Prime SAF - Subcontractor Additional Info Submitted'
IF ( @spName = 'FindItem668' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 8
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem669) Prime SAF - Pending Insurance Certificate'
IF ( @spName = 'FindItem669' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status in (17, 13)
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem670) Prime SAF - Subcontractor Insurance Pending'
IF ( @spName = 'FindItem670' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 23
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END

-- (FindItem730) Prime SAF - Subcontractor OIG Denied'
IF ( @spName = 'FindItem730' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 20
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))

END


------------ End Prime SAF ----------


------------ SUP Status ----------

-- (FindItem740) New Plan
IF ( @spName = 'FindItem740' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 0
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem741) Plan Submitted
IF ( @spName = 'FindItem741' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 1
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem742) Pending Plan Waiver Request
IF ( @spName = 'FindItem742' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 3
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem743)Waiver Request More Info
IF ( @spName = 'FindItem743' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 7
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem744)Plan Compliance Analyst Reviewed with Waiver
IF ( @spName = 'FindItem744' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 4
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem745) Plan Rejected
IF ( @spName = 'FindItem745' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 11
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem746)Waiver More Info Submitted
IF ( @spName = 'FindItem746' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 8
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem747)Plan Compliance Analyst Reviewed
IF ( @spName = 'FindItem747' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 2
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem748)Plan Compliance Manager Reviewed with Waiver
IF ( @spName = 'FindItem748' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 5
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem749)Plan Compliance Verified
IF ( @spName = 'FindItem749' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 6
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

---Batch get Percentage Completion 
declare @temp2 table
(
	PlanId int,
	PercentageCompletion float
)
insert into @temp2
(	
	PlanId,
	PercentageCompletion
)
select 
	p.Id,
	v.pct_by_contract
From 
	MV_SOLICIT_CONTRACT v
inner join 
	[plan] p	
on 
	isnull(c_contract, me_contract) = p.ContractNo
	and isnull(v.n_solicit_seq, 0) = isnull(p.solicitSeq, 0)
where 
	p.status in (6)


-- (FindItem750)Plan Phase 1 Completed
IF ( @spName = 'FindItem750' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s, @temp2 t
	where s.Id = t.PlanId 
		and isnull(t.PercentageCompletion, 0)>=35
		and isnull(t.PercentageCompletion, 0)<50
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem751)Plan Phase 2 Completed
IF ( @spName = 'FindItem751' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s, @temp2 t
	where s.Id = t.PlanId 
		and isnull(t.PercentageCompletion, 0)>=50
		and isnull(t.PercentageCompletion, 0)<90
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem752)Plan Phase 3 Completed
IF ( @spName = 'FindItem752' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s, @temp2 t
	where s.Id = t.PlanId 
		and isnull(t.PercentageCompletion, 0)>=90
		and isnull(t.PercentageCompletion, 0)<95
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem753)Plan Pending Analyst Commitment Review
IF ( @spName = 'FindItem753' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 12
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END


-- (FindItem754)Plan Pending Director Commitment Review
IF ( @spName = 'FindItem754' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 13
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem755)Plan Pending Sr Director Commitment Review
IF ( @spName = 'FindItem755' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 14
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem756)Plan Pending VP Commitment Review
IF ( @spName = 'FindItem756' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 15
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem757)Close Out
IF ( @spName = 'FindItem757' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 16
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem758)Waivers Approved
IF ( @spName = 'FindItem758' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where isnull(isWaiver, 'N') ='Y' 
	and status = 6
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem759)Waiver Denied
IF ( @spName = 'FindItem759' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where isnull(isWaiver, 'N') ='Y' 
	and status = 11
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem760)Evaluation Satisfactory
IF ( @spName = 'FindItem760' )
BEGIN
	Select @count = count(distinct s.Id)
	from [Plan] s, (select * From PlanProperty where propertyId in (25, 31) ) pp
	where s.Id = pp.planId 
	and status = 16
	and convert(nvarchar(50), pp.PropertyText) = 'Satisfactory'
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem761)Evaluation Marginal
IF ( @spName = 'FindItem761' )
BEGIN
	Select @count = count(distinct s.Id)
	from [Plan] s, (select * From PlanProperty where propertyId in (25, 31) ) pp
	where s.Id = pp.planId 
	and status = 16
	and convert(nvarchar(50),pp.PropertyText) = 'Marginal'
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem762)Evaluation Unsatisfactory
IF ( @spName = 'FindItem762' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s, (select * From PlanProperty where propertyId in (25, 31) ) pp
	where s.Id = pp.planId 
	and status = 16
	and convert(nvarchar(50),pp.PropertyText) = 'Unsatisfactory'
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

---- (FindItem763)GC's Evaluation of Subs
--IF ( @spName = 'FindItem763' )
--BEGIN
--	Select @count = count(s.Id)
--	from [Plan] s
--	where s.status = 16
--	and (( @userId = 1 and s.type = 'Line')
--		or ( @userId = 2 and s.type = 'CIP')
--		or ( @userId = 3 and s.type = 'Mentor')
--		or ( @userId = 4 and s.type = 'Mentor Grad'))
--END

---- (FindItem764)Subs Evaluation of GC's
--IF ( @spName = 'FindItem764' )
--BEGIN
--	Select @count = count(s.Id)
--	from [Plan] s
--	where s.status = 16
--	and (( @userId = 1 and s.type = 'Line')
--		or ( @userId = 2 and s.type = 'CIP')
--		or ( @userId = 3 and s.type = 'Mentor')
--		or ( @userId = 4 and s.type = 'Mentor Grad'))
--END
------------ End SUP Status ----------

---- Start User Dashboard Status ----
IF @spName = 'FindPendingReleaseEvaluation0'
BEGIN
	Select @count = count(Id)
	from Scorecard
	Where Status = 1
	and (( @userId = 1 and Type = 'Capacity')
		or ( @userId = 2 and Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindToBeEvaluatedEvaluation0'
BEGIN
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.Status in (0, 1, 3)
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and (( @userId = 1 and s.Type = 'Capacity')
		or ( @userId = 2 and s.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindPendingEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		-- Evaluator
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status in (0, 1, 3)
		and i.ScorecardId = s.Id and s.Status in (2, 3)

		union

		-- Supervisor (Declined/Overdue)
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status in (8)
		and i.ScorecardId = s.Id and s.Status in (2, 3)

		union

		-- Supervisor (Declined/Overdue)
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status in (2)
		and ((s.Type != 'Mentor A' and datediff(day, s.ReleaseDate, getdate()) <= 14)
			or (s.Type = 'Mentor A' and datediff(day, s.CreateDate, getdate()) <= 14))
		and i.ScorecardId = s.Id and s.Status in (2, 3)
	) t
	where (( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindOverdueEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		-- Evaluator
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status in (8, 9)
		and i.ScorecardId = s.Id and s.Status in (2, 3)

		union
		
		-- Supervisor
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status = 2
		and i.ScorecardId = s.Id and s.Status in (2, 3)
		and ((s.Type != 'Mentor A' and datediff(day, s.ReleaseDate, getdate()) > 14
			and datediff(day, s.ReleaseDate, getdate()) <= 21)
			or (s.Type = 'Mentor A' and datediff(day, s.CreateDate, getdate()) > 14
			and datediff(day, s.CreateDate, getdate()) <= 21))

		union

		-- Supervisor
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status = 9
		and i.ScorecardId = s.Id and s.Status in (2, 3)
	) t
	where (( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindPendingApprovalEvaluation0'
BEGIN
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.Status = 5
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and s.CloseDate > getdate()
	and (( @userId = 1 and s.Type = 'Capacity')
		or ( @userId = 2 and s.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindRejectedToEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		-- Supervisor
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status = 7
		and i.ScorecardId = s.Id and s.Status in (2, 3)
		and s.CloseDate > getdate()

		union

		-- Reviewer
		Select s.Id, s.Type
		from ScorecardUser i, Scorecard s
		where i.ScorecardId = s.Id and s.Status in (37, 38, 39, 24, 33)
	) t
	where (( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindRejectedEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		-- Evaluator
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status = 7
		and i.ScorecardId = s.Id and s.Status in (2, 3)
		and s.CloseDate > getdate()

		union

		-- Reviewer
		Select s.Id, s.Type
		from ScorecardUser i, Scorecard s
		where i.ScorecardId = s.Id and s.Status in (24, 33, 37, 38, 39)
	) t
	where (( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindDeclinedEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		-- Evaluator
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status = 2
		and i.ScorecardId = s.Id and s.Status in (2, 3)
		and ((s.Type != 'Mentor A' and datediff(day, s.ReleaseDate, getdate()) <= 21)
			or (s.Type = 'Mentor A' and datediff(day, s.CreateDate, getdate()) <= 21))
	) t
	where (( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))
	RETURN @count
END

IF @spName = 'FindPendingReviewEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
			and u.UserType = 'Design Project Manager'
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status = 4 
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
			and u.UserType = 'Design Manager'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status = 5
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
			and u.UserType = 'Design Manager'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status in (4, 5)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
			and u.UserType = 'Deputy Director'
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity') and s.Status = 7
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
			and u.UserType = 'Deputy Director'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity') and s.Status in (4, 5, 7, 8)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 16
			and u.UserType = 'Director'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity') and s.Status = 8
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 16
			and u.UserType = 'Director'
/*
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status in (37, 38, 39)
			and s.Id = u.ScorecardId
			and u.UserType in ('Design Project Manager')
*/

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status = 12
			and s.Id = u.ScorecardId
			and u.UserType = 'Director'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('CCFU') and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
			and u.UserType in ('Operations Supervisor')

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type = 'CCFU' and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
			and u.UserType in ('Operations Director')

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type = 'CCFU' and s.Status = 16 
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
			and u.UserType in ('Operations Director')
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Mentor B') and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
			and u.UserType in ('VP for Construction Mgmt')

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Mentor B') and s.Status = 25
			and s.Id = u.ScorecardId
			and datediff(day, s.VPCMApprovalDate, getdate()) <= 4
			and u.UserType in ('VP of Admin')

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Mentor B') and s.Status = 12
			and s.Id = u.ScorecardId
			and u.UserType in ('VP for Construction Mgmt')

		union
		
		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status = 2
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) <= 4
			and u.UserType = 'Design Project Manager'
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status = 2
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 4
			and datediff(day, s.CreateDate, getdate()) <= 8
			and u.UserType = 'Design Manager'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status = 5
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) <= 8
			and u.UserType = 'Design Manager'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status in (2, 5)
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 8
			and datediff(day, s.CreateDate, getdate()) <= 12
			and u.UserType = 'Deputy Director'
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status = 26
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) <= 12
			and u.UserType = 'Deputy Director'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status in (2, 5, 26)
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 12
			and datediff(day, s.CreateDate, getdate()) <= 16
			and u.UserType = 'Director'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status = 27
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) <= 16
			and u.UserType = 'Director'

		union

		Select Id, Type
		from Scorecard
		where Type in ('Contract') and Status = 13

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Contract') and s.Status = 14
			and s.Id = u.ScorecardId
			and u.UserType in ('Director')

		union
		
		Select Id, Type
		from Scorecard
		where Status = 10

		union

		Select Id, Type
		from Scorecard
		where Status = 25
			and Type = 'Mentor A Contract'

		union

		Select Id, Type
		from Scorecard
		where Status = 11
			and Type in ('Capacity', 'CIP', 'Mentor B', 'Contract', 'Mentor A Contract')			
	) t
	where ( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')
	RETURN @count
END

IF @spName = 'FindOverdueReviewEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
			and u.UserType = 'Design Project Manager'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Capacity', 'CIP') and s.Status in (4, 5)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
			and u.UserType = 'Design Manager'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Capacity') and s.Status in (4, 5, 7)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
			and u.UserType = 'Deputy Director'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Capacity') and s.Status in (4, 5, 7, 8)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 16
			and u.UserType = 'Director'
			and u.Status = 0
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('CCFU') and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
			and u.UserType = 'Operations Supervisor'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('CCFU') and s.Status in (4, 16)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
			and u.UserType in ('Operations Director')
			and u.Status = 0
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Mentor A Contract') and s.Status in (4, 22)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
			and u.UserType in ('Chief Project Officer',
				'Bronx CPO', 'Brooklyn CPO', 'Manhattan CPO', 'Queens CPO', 'Staten Island CPO')
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Mentor A Contract') and s.Status in (4, 22, 23)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
			and u.UserType = 'VP for Construction Mgmt'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Mentor B') and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
			and u.UserType = 'VP for Construction Mgmt'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Mentor B') and s.Status = 25
			and s.Id = u.ScorecardId
			and datediff(day, s.VPCMApprovalDate, getdate()) > 4
			and u.UserType = 'VP of Admin'
			and u.Status = 0
		
		union
			
		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status = 2
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 4
			and u.UserType = 'Design Project Manager'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Project', 'Contract') and s.Status in (2, 5)
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 8
			and u.UserType = 'Design Manager'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Project', 'Contract') and s.Status in (2, 5, 26)
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 12
			and u.UserType = 'Deputy Director'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Project', 'Contract') and s.Status in (2, 5, 26, 27)
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 16
			and u.UserType = 'Director'
			and u.Status = 0
	) t
	where ( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')

	RETURN @count
END

IF @spName = 'FindPendingCIPReviewEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('CIP') and s.Status in (4, 5)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
			and u.UserType = 'Deputy Director'
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('CIP') and s.Status = 7
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
			and u.UserType = 'Deputy Director'
	) t
	where ( @userId = 1 and Type = 'Capacity')
		or ( @userId = 2 and Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')
	RETURN @count
END

IF @spName = 'FindOverdueCIPReviewEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('CIP') and s.Status in (4, 5, 7)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
			and u.UserType = 'Deputy Director'
			and u.Status = 0
	) t
	where ( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')

	RETURN @count
END

IF @spName = 'FindInProgressEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		-- Evaluator
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where 
		(
			(i.Status in (4, 6) and s.Type != 'Mentor A')
			 or (i.Status = 5)
		)
		and i.ScorecardId = s.Id and s.Status not in (1, 18, 19, 20, 98, 99)

		union

		-- Reviewer
		Select s.Id, s.Type
		from ScorecardUser i, Scorecard s
		where i.Status = 1
		and i.ScorecardId = s.Id and s.Status not in (1, 2, 3, 18, 19, 20, 98, 99)
	) t
	where ( @userId = 1 and Type = 'Capacity')
		or ( @userId = 2 and Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')

	RETURN @count
END

IF @spName = 'FindCompleteEvaluation99'
BEGIN
	Select @count = count(Id)
	from Scorecard
	where Status = 20
	and 
	(
		( @userId = 1 and Type = 'Capacity')
		or ( @userId = 2 and Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')
	)

	RETURN @count
END

IF @spName = 'FindNotNotifiedEvaluation99'
BEGIN
	Select @count = count(Id)
	from Scorecard
	where Status = 19
	and 
	(
		( @userId = 1 and Type = 'Capacity')
		or ( @userId = 2 and Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')
	)

	RETURN @count
END
---- End User Dashboard Status ----

---- Bid and Award General Status -----
-- (FindItem1419) RFC Prepared
IF ( @spName = 'FindItem1419' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 1
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END

-- (FindItem1420) Project Assigned
IF ( @spName = 'FindItem1420' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 2
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1421) CS Reviewed
IF ( @spName = 'FindItem1421' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 3
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1422) Pending Mgr Solicitation Review
IF ( @spName = 'FindItem1422' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 4
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1423) Pending CS Revision
IF ( @spName = 'FindItem1423' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 5
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1424) CS Revised
IF ( @spName = 'FindItem1424' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 6
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1425) Pending Dir Solicitation Review
IF ( @spName = 'FindItem1425' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 7
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1426) Pending CS Revision 1
IF ( @spName = 'FindItem1426' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 8
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1427) CS Revised 1
IF ( @spName = 'FindItem1427' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 9
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1428) Pending IFB Issuance
IF ( @spName = 'FindItem1428' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 10
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1429) Pending Reproduction
IF ( @spName = 'FindItem1429' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 11
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1430) Documents Available
IF ( @spName = 'FindItem1430' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 12
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1481) Receipt Log Complete
IF ( @spName = 'FindItem1481' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 31
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1483) Bidding Closed
IF ( @spName = 'FindItem1483' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 32
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1485) Vetting and Bid Breakdown Analysis
IF ( @spName = 'FindItem1485' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 33
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1487) Pending Routing Pkg Creation
IF ( @spName = 'FindItem1487' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 41
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1489) Pending Mgr Routing Pkg Review
IF ( @spName = 'FindItem1489' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 42
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1491) Routing Pkg Pending CS Revision
IF ( @spName = 'FindItem1491' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 43
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1493) Routing Pkg Revised
IF ( @spName = 'FindItem1493' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 44
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1495) Pending Dir Routing Pkg Review
IF ( @spName = 'FindItem1495' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 45
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1497) Routing Pkg Pending CS Revision 1
IF ( @spName = 'FindItem1497' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 46
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1499) Routing Pkg Revised 1
IF ( @spName = 'FindItem1499' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 47
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1501) Routing to Finance and OIG
IF ( @spName = 'FindItem1501' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 48
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1503) Intent to Award Notice Issued
IF ( @spName = 'FindItem1503' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 51
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1505) Pending BDD Review
IF ( @spName = 'FindItem1505' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 52
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1507) Pending Admin Review
IF ( @spName = 'FindItem1507' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 53
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1509) Pending Execution Pkg Creation
IF ( @spName = 'FindItem1509' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 61
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1511) Execution Package On Hold
IF ( @spName = 'FindItem1511' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 62
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1513) Pending Legal Review
IF ( @spName = 'FindItem1513' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 63
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1515) Execution Pkg Pending CS Revision
IF ( @spName = 'FindItem1515' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 64
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1517) Execution Pkg Revised
IF ( @spName = 'FindItem1517' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 65
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1519) Pending President Review
IF ( @spName = 'FindItem1519' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 66
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1521) Pending Notice of Award
IF ( @spName = 'FindItem1521' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 68
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1523) Contract Awarded
IF ( @spName = 'FindItem1523' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 69
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1646) Pending Intent to Award Notice
IF ( @spName = 'FindItem1646' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 70
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1647) Intent to Award On Hold
IF ( @spName = 'FindItem1647' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 71
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1655)Pending President Approval
IF ( @spName = 'FindItem1655' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 67
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1696)Routing To OIG Bidder Review
IF ( @spName = 'FindItem1696' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 72
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END

---- Bid and Award General Status -----
---- Start Bid Breakdown Analysis Status ----- 
-- (FindItem1463)Bid Breakdown Requested
IF ( @spName = 'FindItem1463' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =1
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1464)Bid Breakdown Received
IF ( @spName = 'FindItem1464' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =2
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1465)Pending Estimating Mgr Review
IF ( @spName = 'FindItem1465' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =3
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1466)Bid Analysis Complete
IF ( @spName = 'FindItem1466' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =4
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1467)Bid Analysis Complete
IF ( @spName = 'FindItem1467' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =5
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1468)Analysis Resubmitted
IF ( @spName = 'FindItem1468' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =6
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1469)BAFO Requested
IF ( @spName = 'FindItem1469' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =7
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1470)Pending VP of CM Review
IF ( @spName = 'FindItem1470' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =8
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1471)BAFO Requested 1
IF ( @spName = 'FindItem1471' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =9
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1472)Pending CS Bid Review
IF ( @spName = 'FindItem1472' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =10
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1473)Pending President Decision
IF ( @spName = 'FindItem1473' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =11
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1474)BAFO Requested 2
IF ( @spName = 'FindItem1474' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =12
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1475)Pending Consultation
IF ( @spName = 'FindItem1475' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =13
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1721)Low Bidder Accepted
IF ( @spName = 'FindItem1721' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =14
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END


---- End Bid Breakdown Analysis Status -----
-- (FindItem1565)Award Vetting Requested
IF ( @spName = 'FindItem1565' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =1
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1567)Pending Reviewer Vetting
IF ( @spName = 'FindItem1567' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =2
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1569)Vetting Issues
IF ( @spName = 'FindItem1569' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =3
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1572)Pending Low Bidder Selection
IF ( @spName = 'FindItem1572' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =4
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1574)Vetting Complete
IF ( @spName = 'FindItem1574' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =5
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1576)Trades Verified
IF ( @spName = 'FindItem1576' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =6
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1578)Pending Manager Final Review
IF ( @spName = 'FindItem1578' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =7
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1580)Award Vetting Disapproved
IF ( @spName = 'FindItem1580' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =8
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1582)Award Vetting On Hold
IF ( @spName = 'FindItem1582' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =9
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1584)Award Vetting Approved
IF ( @spName = 'FindItem1584' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =10	
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count

END
-----------Pre-Award Vetting Bond Workflow
-- (FindItem1587)Pending Financial and Bond Review
IF ( @spName = 'FindItem1587' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =1
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1589)Pending Financial Review
IF ( @spName = 'FindItem1589' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =2
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1591)Pending Bid Bond Review
IF ( @spName = 'FindItem1591' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =3
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1593)Pending Low Bidder Selection
IF ( @spName = 'FindItem1593' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =4
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1595)Trades Verified
IF ( @spName = 'FindItem1595' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =5
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1688)Financial Failed
IF ( @spName = 'FindItem1688' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =6
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1690)Bond Issues
IF ( @spName = 'FindItem1690' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =7
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
--------Routing to OIG Workflow
-- (FindItem1680)Pending OIG Bidder Review
IF ( @spName = 'FindItem1680' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 42
	where pw.Status =1
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1681)Pending OIG Bidder Approval
IF ( @spName = 'FindItem1681' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 42
	where pw.Status =2
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1683)OIG Bidder Review Completed
IF ( @spName = 'FindItem1683' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 42
	where pw.Status =3
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1685)OIG Bidder Issues
IF ( @spName = 'FindItem1685' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 42
	where pw.Status =4
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
------------Addendum Workflow
-- (FindItem1530)Pending Mgr Addendum Review
IF ( @spName = 'FindItem1530' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =1
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)	
RETURN @count
END
-- (FindItem1534)Addendum Revised
IF ( @spName = 'FindItem1534' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =3
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1536)Pending Dir Addendum Review
IF ( @spName = 'FindItem1536' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =4
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1538)Addendum Issued
IF ( @spName = 'FindItem1538' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =7
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1618)Addendum Pending CS Revision
IF ( @spName = 'FindItem1618' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =2
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1619)Addendum Pending CS Revision 1
IF ( @spName = 'FindItem1619' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =5
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1620)Addendum Revised 1
IF ( @spName = 'FindItem1620' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =6
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
----------RFI Submission / Processing Status
-- (FindItem1459)RFI Submitted
IF ( @spName = 'FindItem1459' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 33
	where pw.Status =1
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1460)RFI Forwarded
IF ( @spName = 'FindItem1460' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 33
	where pw.Status =2
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1461)Consultant RFI Response
IF ( @spName = 'FindItem1461' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 33
	where pw.Status =3
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END

-------------Inclusion and Rescission
-------Request For Inclusion
if(@spName='FindRfdSupplierBy5')
begin
	select @count=count(1)
	from RfdSupplier
	where status =5
	and workflowid=14
RETURN @count
end
-------Reviewer Reviewed
if(@spName='FindRfdSupplierBy6')
begin
	select @count=count(1)
	from RfdSupplier
	where status =6
	and workflowid=14
RETURN @count
end
-------Question From Manager
if(@spName='FindRfdSupplierBy7')
begin
	select @count=count(1)
	from RfdSupplier
	where status =7
	and workflowid=14
RETURN @count
end
-------Manager Approved
if(@spName='FindRfdSupplierBy8')
begin
	select @count=count(1)
	from RfdSupplier
	where status =8
	and workflowid=14
RETURN @count
end
-------Question From Director
if(@spName='FindRfdSupplierBy9')
begin
	select @count=count(1)
	from RfdSupplier
	where status =9
	and workflowid=14
RETURN @count
end
-------Director Approved
if(@spName='FindRfdSupplierBy10')
begin
	select @count=count(1)
	from RfdSupplier
	where status =10
	and workflowid=14
RETURN @count
end
-------Chief Project Officer Approved
if(@spName='FindRfdSupplierBy11')
begin
	select @count=count(1)
	from RfdSupplier
	where status =11
	and workflowid=14
RETURN @count
end
-------VP for Construction Mgmt Approved
if(@spName='FindRfdSupplierBy12')
begin
	select @count=count(1)
	from RfdSupplier
	where status =12
	and workflowid=14
RETURN @count
end





-------President Approved
if(@spName='FindRfdSupplierBy13')
begin
	select @count=count(1)
	from RfdSupplier
	where status =13
		and WorkflowId =8
		and exists (select * from WorkflowList where id = 8 and Name = 'Supplier Limited List Workflow')
RETURN @count

end
-------Rescind Pending
if(@spName='FindRfdSupplierBy14')
begin
	select @count=count(1)
	from RfdSupplier
	where status =14
		and WorkflowId =8
		and exists (select * from WorkflowList where id = 8 and Name = 'Supplier Limited List Workflow')
RETURN @count

end

------------ Bid and Award General Status ----------

-- (FindItem671) RFC Prepared
IF ( @spName = 'FindItem671' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowType = 'Bid and Award General'
	where pw.Status = 1 --'RFC Prepared'
	and ((@userId = 99991 and isnull(p.ContractSpecialist, '') = '')
		or (p.ContractSpecialist = @username))
RETURN @count
END

-- (FindItem682) Pending Reproduction
IF ( @spName = 'FindItem682' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowType = 'Bid and Award General'
	where pw.Status = 11 --'Pending Reproduction'
	and ((@userId = 99991 and isnull(p.ContractSpecialist, '') = '')
		or (p.ContractSpecialist = @username))
RETURN @count
END

/***********Release 4.0******************/
IF ( @spName = 'FindItem789' )
BEGIN

   select @count=count(planid)
   from
   (
   select p.planid
   from 
         plansubcontractor p
         inner join suppliervetting s on s.contactid=p.supplierid
         Inner join (select * from planProperty where propertyId in (25, 31,15)) B On B.PlanId=p.planId
         Inner join [Plan] pl on pl.id=p.planid
   where --(@userName='' or @userName= isnull(convert(nvarchar(50), B.propertytext), '')) 
   --and 
   s.VettingId =2
   and s.VettingName like '%'+ p.Contractno + '%'
   --and s.contactid=p.supplierid
   and s.status=3
and s.Review =0
and (( @userId = 1 and pl.type = 'Line')
		or ( @userId = 2 and pl.type = 'CIP')
		or ( @userId = 3 and pl.type = 'Mentor')
		or ( @userId = 4 and pl.type = 'Mentor Grad'))
    
   union 
   select p.planid
   from 
         plansubcontractor p
         inner join suppliervetting s on s.contactid=p.supplierid
         Inner join (select * from planProperty where propertyId in (25, 31,15)) B On B.PlanId=p.planId
         Inner join [Plan] pl on pl.id=p.planid
   where --(@userName='' or @userName= isnull(convert(nvarchar(50), B.propertytext), '')) 
   --and
   s.VettingId =1
   and s.VettingName like '%'+ p.Contractno + '%'
   and s.contactid=(select qualifiedsupplierid from vendor where federalid=p.taxid)
   and s.status=3
   and s.Review =0
   and (( @userId = 1 and pl.type = 'Line')
		or ( @userId = 2 and pl.type = 'CIP')
		or ( @userId = 3 and pl.type = 'Mentor')
		or ( @userId = 4 and pl.type = 'Mentor Grad'))
   
   ) v
RETURN @count
END


-- no type found
RETURN @count

END

--------------------
GO
PRINT N'Creating [dbo].[GET_AWARDS]...';


GO
Create FUNCTION [dbo].[GET_AWARDS]
(
	@ARG_TAX varchar(50),
	@datefrom date,
	@dateto date,
	@RangeType varchar(2)
)
RETURNS int
AS
begin

declare @n_ret int

declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime
if(DatePart(Month,getdate()) < 7)
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
	end
else
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
	end

if @datefrom =null or @datefrom ='1/1/1900'
	Begin
		if @RangeType ='F' --Fiscal year
			Begin
				set @datefrom=@firstDayOfYear
				set @dateto=@firstDayOfNextYear
			end
		Else
			Begin
				set @datefrom=DATEADD(Month,-12,GetDate())
				set @dateto=Getdate()
			end

	End
SELECT @n_ret =COUNT (*) 
FROM mv_vas_award
WHERE vendor_id = @ARG_TAX 
AND ((execution_date between @datefrom and  @dateto AND ntp_date IS NULL) 
OR (ntp_date between @datefrom and  @dateto AND execution_date IS NULL)) 

return @n_ret

end
GO
PRINT N'Creating [dbo].[GET_BIDS]...';


GO
create FUNCTION [dbo].[GET_BIDS]
(
	@ARG_TAX varchar(50),
	@datefrom date,
	@dateto date,
	@RangeType varchar(2)
)
RETURNS int
AS
begin

declare @n_ret int

declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime
if(DatePart(Month,getdate()) < 7)
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
	end
else
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
	end

if @datefrom =null or @datefrom ='1/1/1900'
	Begin
		if @RangeType ='F' --Fiscal year
			Begin
				set @datefrom=@firstDayOfYear
				set @dateto=@firstDayOfNextYear
			end
		Else
			Begin
				set @datefrom=DATEADD(Month,-12,GetDate())
				set @dateto=Getdate()
			end

	End
SELECT @n_ret =COUNT (*) 
FROM MV_VAS_BIDDER
WHERE C_VENDOR_ID = @ARG_TAX 
and  SD_ACTUAL_BID_OPEN between @datefrom and @dateto

return @n_ret

end
GO
PRINT N'Creating [dbo].[GET_PICKUPS]...';


GO
Create FUNCTION [dbo].[GET_PICKUPS]
(
	@ARG_TAX varchar(50),
	@datefrom date,
	@dateto date,
	@RangeType varchar(2)
)
RETURNS int
AS
begin

declare @n_ret int

declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime
if(DatePart(Month,getdate()) < 7)
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
	end
else
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
	end

if @datefrom =null or @datefrom ='1/1/1900'
Begin
	if @RangeType ='F' --Fiscal year
		Begin
			set @datefrom=@firstDayOfYear
			set @dateto=@firstDayOfNextYear
		end
	Else
		Begin
			set @datefrom=DATEADD(Month,-12,GetDate())
			set @dateto=Getdate()
		end

End

SELECT @n_ret=COUNT (*) 

FROM (	SELECT COUNT(*) N_PICKUP, C_VENDOR_ID, N_SOLICIT_SEQ 
		FROM 
			MV_VAS_PICKUP 
		WHERE 
			SD_TRANS_DATE between @datefrom and @dateto
			AND SD_TRANS_DATE <= Isnull(SD_ACTUAL_BID_OPEN, '01/01/2099') 
		GROUP BY C_VENDOR_ID, N_SOLICIT_SEQ
) c
WHERE C_VENDOR_ID = @ARG_TAX ;

return @n_ret

end
GO
PRINT N'Creating [dbo].[SBS_WORK_REFERENCE]...';


GO
CREATE VIEW DBO.SBS_WORK_REFERENCE
As
select 	convert(char(20), v.federalId) as [TAX ID],sp.Name,
(
		Select c.Name + ',' AS [text()]
		From Category c
		where c.Id in (select Item from Split(sp.CategoryIds,'^'))
		For XML PATH ('')
) 'Trades',
sp.CategoryIds,
sp.StartDate,
sp.EndDate,
sp.ContractAmount,
sp.Description,
Replace(sp.RepresentativeName,'|',' ') as 'RepresentativeName',
sp.RepresentativeTitle,
sp.RepresentativePhone,
sp.RepresentativeCellPhone,
sp.RepresentativeFax,
sp.RepresentativeEmail,
sp.AddressLine1,
sp.AddressLine2,
sp.State,
sp.City,
sp.Country,
sp.ZipCode
From (select * from vendor where isnull(qualificationstatus, '')!='' or isnull(certificationstatus, '') !='') v
inner join	supplier s on	v.QualifiedSupplierId = s.Id
inner join [dbo].SupplierProject sp on sp.SupplierId=v.CurrentSupplierId
GO
PRINT N'Altering [dbo].[FindSupplierByOutlookXml]...';


GO
/*
*********************************************************************************************************************
Procedure:	FindSupplierByOutlookXml
Purpose:	Search and Get all Supplier that satisfy the criteria return in Xml format.48
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
08/17/2005		Frank Wang			Created
*********************************************************************************************************************
-- exec FindSupplierByOutlookXml @pageSize=20,@pageNumber=0,@orderBy=N'Company',@sequence=N'ASC',@userId=897,@type=N'FindItem296'

--exec FindSupplierByOutlookXml @pageSize=20,@pageNumber=0,@orderBy=N'Company',@sequence=N'ASC',@userId=897,@type=N'FindItem146'

*/
ALTER procedure [dbo].[FindSupplierByOutlookXml]
	@pageSize int,
	@pageNumber int,
	@orderBy nvarchar(50),
	@sequence nvarchar(10),
	@userId int,
	@type nvarchar(50)
AS
set nocount on
declare @beginCount int
declare @endCount int
declare @totalcount int
set @beginCount = @pageNumber * @pageSize + 1
set @endCount = @beginCount + @pageSize - 1
Declare @temp Table
(
	SupplierId int
)

declare @userGuid uniqueidentifier
declare @username nvarchar(50)
select @userGuid = u.UserId, @username = au.Username from [User] u, aspnet_users au
	where u.Id = @userId and u.UserId = au.UserId

--#region Other Items
declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime
if(DatePart(Month,getdate()) < 7)
begin
	set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
	set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
end
else
begin
	set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
	set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
end

declare @propertyId_ReviewerId int
set @propertyId_ReviewerId = 10
declare @propertyId_ManagerId int
set @propertyId_ManagerId = 521
declare @propertyId_IOGDecision int
set @propertyId_IOGDecision = 508
declare @propertyId_CertificationAnalyst int
set @propertyId_CertificationAnalyst = 524
--#endregion Other Items

--#region Workflow Items
declare @WORKFLOW_QUALIFICATION int
declare @NewPrequalification int
declare @ApplicationSubmitted int
declare @ManagerReviewed int
declare @RequestMoreInfo int
declare @ReferenceReviewed int
declare @FinacialReviewed int
declare @OIGApproved int
declare @Qualified int
declare @PreDeny int
declare @AdministrativelyClosed int
declare @AllReviewed int
declare @RequestMoreInfoPending int
declare @DirectorClosed int
declare @DirectorClosePending int
declare @AdditionalInfoSubmitted int
declare @ReviewerReviewed int
declare @Inactive int
declare @QualifiedPending int
declare @Disqualified int
declare @Withdrawn int
declare @OIGReviewed int
declare @Rescinded int
declare @Suspended int
declare @RequestMoreInfo2 int
declare @AdditionalInfoSubmitted2 int

declare @WORKFLOW_CERTIFICATION int
declare	@NewCertification int
declare	@CertificationSubmitted int
declare	@CertificationAnalystReviewed int
declare	@RequestMoreCertificationInfoPending int
declare	@RequestMoreCertificationInfo int
declare	@AdditionalCertificationInfoSubmitted int
declare	@MWBEReviewed int
declare	@LBEReviewed int
declare	@CertificationAnalystApproved int
declare	@DirectorApprovalPending int
declare	@Certified int
declare	@CertificationAnalystClosed int
declare	@CertificationClosed int
declare	@DirectorApproved int

Set @WORKFLOW_QUALIFICATION = 1
Set @NewPrequalification = 1
Set @ApplicationSubmitted = 2
Set @ManagerReviewed = 3
Set @RequestMoreInfo = 6
Set @ReferenceReviewed = 7
Set @FinacialReviewed = 29
Set @OIGApproved = 70
Set @Qualified = 71
Set @PreDeny = 72
Set @AdministrativelyClosed = 73
Set @AllReviewed = 74
Set @RequestMoreInfoPending = 80
Set @DirectorClosed = 82
Set @DirectorClosePending = 86
Set @AdditionalInfoSubmitted = 89
Set @ReviewerReviewed = 111
Set @Inactive = 113
Set @QualifiedPending = 124
Set @Disqualified = 244
Set @Withdrawn = 245
Set @OIGReviewed = 246
Set @Rescinded = 257
Set @Suspended = 258
Set @RequestMoreInfo2 = 291
Set @AdditionalInfoSubmitted2 = 292

Set @WORKFLOW_CERTIFICATION = 2
Set @NewCertification =47	 
Set @CertificationSubmitted =48	 
Set @CertificationAnalystReviewed =49	 
Set @RequestMoreCertificationInfoPending =50	 
Set @RequestMoreCertificationInfo =51	 
Set @AdditionalCertificationInfoSubmitted =92	 
Set @MWBEReviewed =93	 
Set @LBEReviewed =94	 
Set @CertificationAnalystApproved =95	 
Set @DirectorApprovalPending = 97	
Set @Certified =98	 
Set @CertificationAnalystClosed =99	 
Set @CertificationClosed = 100	
Set @DirectorApproved =213	
--#endregion Workflow Items

declare @userroles table(rolename varchar(500))
insert into @userroles
		select r.RoleName
		from [user] u inner join dbo.aspnet_UsersInRoles uir on u.userid = uir.userid
		inner join aspnet_Roles r on uir.roleid = r.roleid
		where u.Id = @userId


declare @cquFinancialAnalystCount int
	select @cquFinancialAnalystCount=count(u.id) 
	from 
		aspnet_UsersInRoles ar
		inner join [user] u on ar.UserId=u.UserId
		inner join aspnet_Roles a on ar.RoleId=a.RoleId
	where u.id=@userId
	and a.RoleName='CQU Financial Analyst'
------------ CQU Manager ----------

-- (FindItem192) Pending Prequalifications
IF ( @type = 'FindItem192' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 2 != 2 
	and dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem11) Pending Requalifications
IF ( @type = 'FindItem11' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 2 = 2 and ss.Status is not null and ss.Status not in (
								'Qualified'
								,'New Qualification'
								,'Administratively Closed'
								,'Inactive'
								,'Withdrawn'
								,'Disqualified'
								,'Rescinded'
								,'Suspended'
								,'Deny'
								,'Expired'
							)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem12) New Assignments ( Triage)
IF ( @type = 'FindItem12' )
BEGIN
	if(dbo.IsUserIdInRole(@userGuid, 'Prequal New Assignment') = 1)
	begin
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
			left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
			left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
			left join supplierversion sv on s.Id = sv.SupplierId
		where ss.Status = 'Application Submitted'
		and s.Status & 2 != 2
		and sp.PropertyText is null
		and (sv.status is null or sv.status <> 0)  
	end	
	if(dbo.IsUserIdInRole(@userGuid, 'Requal New Assignment') = 1)
	begin
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
			left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
			left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
			left join supplierversion sv on s.Id = sv.SupplierId
		where ss.Status = 'Application Submitted'
		and s.Status & 2 = 2
		and sp.PropertyText is null
		and (sv.status is null or sv.status <> 0)  
	end
	if(dbo.IsUserIdInRole(@userGuid, 'Small Bus New Assignment') = 1)
	begin
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
			left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
			left join SupplierStatus ss1 on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
			left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
			left join supplierversion sv on s.Id = sv.SupplierId
		where ss.Status = 'Application Submitted'
		and ss1.Status = 'Certification Submitted'
		and sp.PropertyText is null
		and (sv.status is null or sv.status <> 0)  
	end
END

-- (FindItem13) Pending Final Review
IF ( @type = 'FindItem13' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified Pending'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem14) Files Returned to Reviewer
IF ( @type = 'FindItem14' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'OIG Reviewed'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem15) Managers Assigned Files
--IF ( @type = 'FindItem15' )
--BEGIN
--	Insert Into @temp ( SupplierId )
--	select s.Id
--	from Supplier s
--		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where isnull(ss.Status,'') in ('Application Submitted','OIG Approved')
--	and substring(sp.PropertyText, 1, 50) = @username
--	and (sv.status is null or sv.status <> 0)  
--END

-- (FindItem16) Pending Certifications
IF ( @type = 'FindItem16' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null and ss1.Status not in (
					'Certified'
					,'New Certification'
					,'Admin Closed'
					,'Withdrawn'
					,'Disqualified'
					,'Decertified'
					,'Rescinded'
					,'Suspended'
					,'Deny'
					,'Expired'
					,'Archived'
				)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END

-------- CQU Reviewer --------------
	
-- (FindItem17) New Assignments
IF ( @type = 'FindItem17' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Manager Reviewed'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END
	
		-- (FindItem18) Total Number of Files Per Reviewer
	IF ( @type = 'FindItem18' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
					left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
					left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
					left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
		where ss.Status is not null and ss.Status in (				 'Manager Reviewed'
																	,'Reviewer Reviewed'
																	,'Request More Info Pending'
																	,'Request More Info'
																	,'Additional Info Submitted'
																	,'Reference Reviewed'
																	,'Financial Reviewed'
																	,'Reference and Financial Reviewed'
																	,'OIG Approved'
																	,'Qualified Pending'
																	,'OIG Reviewed'
																	,'Request More Info 2'
																	,'Additional Info Submitted 2'
																	)
		and u.Id = @userId
		and ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
			or 'CQU Director' in (select rolename from @userroles)
			or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
		and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
	END
	
-- (FindItem19) 30 Day Sent
IF ( @type = 'FindItem19' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Request More Info'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem20) Unresponsive  to 30 Days
IF ( @type = 'FindItem20' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Request More Info'
	and s.id in (select supplierid from SupplierStaticQualification where DateDiff(Day,getdate(),V_SD_ADDL_SENT) < -30)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END

	
		-- (FindItem27) Amended OIG Signoffs
	IF ( @type = 'FindItem27' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
from Supplier s					
					left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Change in Application'
					left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
					left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
		where isnull(ss.Status,'') = 'Qualified'
		and ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
			or 'CQU Director' in (select rolename from @userroles)
			or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))

		and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
	END
	
-- (FindItem28) True Requals
IF ( @type = 'FindItem28' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null and ss.Status in ( 
				'Manager Reviewed'
				,'Reviewer Reviewed'
				,'Request More Info Pending'
				,'Request More Info'
				,'Additional Info Submitted'
				,'Reference Reviewed'
				,'Financial Reviewed'
				,'Reference and Financial Reviewed'
				,'OIG Approved'
				,'Qualified Pending'
				,'OIG Reviewed'
				,'Request More Info 2'
				,'Additional Info Submitted 2'
				)
	and s.Status & 2 = 2
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END
	
		-- !!ONHOLD!!(FindItem29) Priority/Pending Contract
	IF ( @type = 'FindItem29' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
from Supplier s
			left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
			left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
where ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
	or 'CQU Director' in (select rolename from @userroles)
	or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
		and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
	END
	
-- !!ONHOLD!!(FindItem30) Pending RFC Limited List
IF ( @type = 'FindItem30' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') in (
									 'Reference Reviewed'
									,'Financial Reviewed'
									,'Reference and Financial Reviewed'
								   )
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem31) Pending OIG Signoff
IF ( @type = 'FindItem31' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') in (
									 'Reference Reviewed'
									,'Financial Reviewed'
									,'Reference and Financial Reviewed'
								   )
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0) 
END

-- (FindItem32) 10 Day Fax
IF ( @type = 'FindItem32' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Request More Info 2'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem33) Unresponsive to 10 Days
IF ( @type = 'FindItem33' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Request More Info 2'
	and s.id in (select supplierid from SupplierStaticQualification where DateDiff(Day,getdate(),V_SD_ADDL_SENT2) < -10) -- more than 10 days
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END
	
		-- (FindItem34) Pending Safety Review
	IF ( @type = 'FindItem34' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
					left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
					left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
		where ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
			or 'CQU Director' in (select rolename from @userroles)
			or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
		and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
	END
	
-- (FindItem35) Predenials
IF ( @type = 'FindItem35' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null and ss.Status = 'PreDeny'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem36) Final Denials
IF ( @type = 'FindItem36' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Deny'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)   
END

-- (FindItem191) OIG Approvals
IF ( @type = 'FindItem191' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'OIG Approved'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END

	
		-- !!ONHOLD!!(FindItem37) OIG 15 Day Letters
	IF ( @type = 'FindItem37' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
from Supplier s
			left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
			left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
where ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
	or 'CQU Director' in (select rolename from @userroles)
	or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
		and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
	END
	
-- (FindItem38) OIG Letter of Concern
IF ( @type = 'FindItem38' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp2 on s.Id = sp2.SupplierId and sp2.PropertyId = @propertyId_IOGDecision
		left join supplierversion sv on s.Id = sv.SupplierId
	where convert(nvarchar(500),sp2.PropertyText) = 'Provide Letter of Concern'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)   
END
	
-- (FindItem39) Files with OIG Denials
IF ( @type = 'FindItem39' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join supplierworkflow sw	on s.id = sw.supplierid and sw.workflowid = @WORKFLOW_CERTIFICATION
		left join workflowhistory wh1	on sw.transactionid = wh1.transactionheaderid 
		left join workflowhistory wh2	on wh1.prevhistoryid = wh2.id
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where wh1.id is not null
	and wh2.id is not null
	and wh1.CurrentNodeId = @DirectorClosePending 
	and wh2.currentnodeid in (@ReferenceReviewed,@FinacialReviewed)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem40) Pending Reference Outreach
IF ( @type = 'FindItem40' )
BEGIN
Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Reviewer Reviewed'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem41) Pending Financial Review
IF ( @type = 'FindItem41' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') in ('Reviewer Reviewed','Reference Reviewed')
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)   
END
	
		-- !!ONHOLD!!(FindItem42) Firms Pending SAF References
	IF ( @type = 'FindItem42' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
					left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
					left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
		where ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
			or 'CQU Director' in (select rolename from @userroles)
			or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
			and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
	END
	
-- (FindItem43) Amended Trade Codes
IF ( @type = 'FindItem43' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0) 
END

-- (FindItem45) Pending Over 1 Million
IF ( @type = 'FindItem45' )
BEGIN
	Insert Into @temp ( SupplierId )
			select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 2 != 2 and ss.Status is not null and ss.Status not in (	
										 'Qualified'
										,'New Qualification'
										,'Administratively Closed'
										,'Inactive'
										,'Withdrawn'
										,'Disqualified'
										,'Rescinded'
										,'Suspended'
										,'Deny'
										,'Expired'							
								  )
	and s.id in(
				select supplierid from suppliercategory sc 
					left join category c on sc.categoryid = c.id
				where 
					((convert(int,c.code) < 31000 or (convert(int,c.code) > 37117 and convert(int,c.code) < 80000) or convert(int,c.code) > 86100) and convert(int,c.code) != 37100)
				and
					isnull(Average,'') = 'over'
			   )
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem46) Firms with Joint Venture
IF ( @type = 'FindItem46' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where LegalStructure = 'Joi'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END
	
		-- (FindItem47) Files A/C
	IF ( @type = 'FindItem47' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
					left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
					left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
					left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
		where isnull(ss.Status,'') = 'Administratively Closed'
		and ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
			or 'CQU Director' in (select rolename from @userroles)
			or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
			and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
	END
	
		-- (FindItem48) Files re-opened
	IF ( @type = 'FindItem48' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
					left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
					left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
			where s.id in (select supplierid from SupplierStaticQualification where	V_cd_reopen_date is not null)
		and ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
			or 'CQU Director' in (select rolename from @userroles)
			or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
		and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0)   
	END
	
		-- !!ONHOLD!!(FindItem49) Pending Reinstatement
	IF ( @type = 'FindItem49' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
					left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
					left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
		where ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
			or 'CQU Director' in (select rolename from @userroles)
			or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
			and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
	END
	
-- (FindItem50) Amended-Key People
IF ( @type = 'FindItem50' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Change in Application'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Change In Application Submitted'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0) 
END
	
-- (FindItem51) Amended-Qual Over 1 Million
IF ( @type = 'FindItem51' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Over 1MM Application Submitted'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)
END
	
		-- (FindItem52) 60 Day notice Letter
	IF ( @type = 'FindItem52' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
					left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
					left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
					left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
		where	  isnull(ss.Status,'') = 'Qualified'
		and s.id in (select supplierid from SupplierStaticQualification where DateDiff(Day,getdate(),V_SD_NOTICE_LTR) between 0 and 60)-- within 60 days of expiring
		and ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
			or 'CQU Director' in (select rolename from @userroles)
			or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
		and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
	END
	
		-- (FindItem53) Firms unreponsive-60 day letter
	IF ( @type = 'FindItem53' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
					left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
					left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
					left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
		where	  isnull(ss.Status,'') = 'Qualified'							
		and s.id in (select supplierid from SupplierStaticQualification where DateDiff(Day,getdate(),V_SD_PREQUAL_TO) < 0)--more than 3 years from qual date
		and ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
			or 'CQU Director' in (select rolename from @userroles)
			or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
		and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0)   
	END
	
-- (FindItem54) Total Number of Files
IF ( @type = 'FindItem54' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
			left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where	  ss2.Status in (	
										 'Manager Reviewed'
										,'Reviewer Reviewed'
										,'Request More Info Pending'
										,'Request More Info'
										,'Additional Info Submitted'
										,'Reference Reviewed'
										,'Financial Reviewed'
										,'Reference and Financial Reviewed'
										,'OIG Approved'
										,'Qualified Pending'
										,'OIG Reviewed'
										,'Request More Info 2'
										,'Additional Info Submitted 2'							
								  )
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem55) Total New Certification Applications Received FYTD
IF ( @type = 'FindItem55' )
BEGIN
	Insert Into @temp ( SupplierId )
	select distinct s.Id
	from Supplier s
		left join supplierversion sv on s.Id = sv.SupplierId
		, SupplierStaticCertification ssc
	where s.id = ssc.SupplierId and V_SD_APPL_DATE between @firstDayOfYear and @firstDayOfNextYear
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem56) New Applications Assigned to Certification Analysts for Review
IF ( @type = 'FindItem56' )
BEGIN
	Insert Into @temp ( SupplierId )
	Select distinct s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status in ('Certification Submitted', 'Certification Analyst Assigned')
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem57) Certification Applications Awaiting Assignment to Analyst
IF ( @type = 'FindItem57' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Certification Submitted'
	and substring(isnull(sp.PropertyText, ''), 1, 50) = ''
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem58) Total Number of Certified Firms
IF ( @type = 'FindItem58' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s 
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Certified'
	and (sv.status is null or sv.status <> 0)   
END

-- (FindItem59) Total Number of Firms that are Certified and Prequalified 
IF ( @type = 'FindItem59' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s 
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss1.Status,'') = 'Certified'
	and	  isnull(ss2.Status,'') = 'Qualified'
	and (sv.status is null or sv.status <> 0)   
END
	
-- (FindItem60) Total Number of Firms Pending Certification
IF ( @type = 'FindItem60' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s 
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1 
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem61) Total Number of Firms that are Pending Certification and Prequalification
IF ( @type = 'FindItem61' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 1 = 1 and ss1.Status is not null and ss1.Status not in (
				'Certified'
				,'New Certification'
				,'Admin Closed'
				,'Withdrawn'
				,'Disqualified'
				,'Decertified'
				,'Rescinded'
				,'Suspended'
				,'Deny'
				,'Expired'
				,'Archived'
				)
	and	 s.Status &2 = 2 and ss2.Status is not null and ss2.Status not in (
				 'Qualified'
				,'New Qualification'
				,'Administratively Closed'
				,'Inactive'
				,'Withdrawn'
				,'Disqualified'
				,'Rescinded'
				,'Suspended'
				,'Deny'
				,'Expired'
				)
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem62) Total Number of Certified Firms that are Pending Prequalification
IF ( @type = 'FindItem62' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss1.Status,'') = 'Certified'
	and	 s.Status & 2 != 2 and ss2.Status is not null and ss2.Status not in (
					 'Qualified'
					,'New Qualification'
					,'Administratively Closed'
					,'Inactive'
					,'Withdrawn'
					,'Disqualified'
					,'Rescinded'
					,'Suspended'
					,'Deny'
					,'Expired'
					)
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem64) Total Number of Recertification Applications Received
IF ( @type = 'FindItem64' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss1.Status,'') = 'Certification Submitted'
	and s.Status & 1 = 1
	and (sv.status is null or sv.status <> 0)   
END
	
-- (FindItem65) Total Number of Firms Pending Recertification
IF ( @type = 'FindItem65' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 1 = 1 and ss1.Status is not null and ss1.Status not in (
				'Certified'
				,'New Certification'
				,'Admin Closed'
				,'Withdrawn'
				,'Disqualified'
				,'Decertified'
				,'Rescinded'
				,'Suspended'
				,'Deny'
				,'Expired'
				,'Archived'																				
			)
	--isnull(ss1.Status,'') = 'Certified'
	--and s.id in (select supplierid from SupplierStaticCertification where DateDiff(Day,getdate(),V_sd_exp_date) between 0 and 60 ) -- within 60 days of expiring
	and (sv.status is null or sv.status <> 0)  
	END
	
		-- !!ON HOLD!!	(FindItem66) Priority Certification
	IF ( @type = 'FindItem66' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	
	END
	
-- (FindItem67) Total Number of Firms that Certification will Lapsed within 60 days
IF ( @type = 'FindItem67' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
		, SupplierStaticCertification ssc
	where isnull(ss.Status,'') = 'Certified'
	and s.id = ssc.SupplierId and DateDiff(Day,getdate(),V_sd_exp_date) between -1 and -60  -- has expired within the last 60 days
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)
END
	
-- (FindItem68) Total Number of Firms that Certification will Lapsed within 30 days
IF ( @type = 'FindItem68' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
		, SupplierStaticCertification ssc
	where isnull(ss.Status,'') = 'Certified'
	and s.id = ssc.SupplierId and DateDiff(Day,getdate(),V_sd_exp_date) between -1 and -30  -- has expired within the last 30 days
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)   
END
	
-- (FindItem69) 30 Day Notices Sent
IF ( @type = 'FindItem69' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)
END
	
-- (FindItem70) 10 Day Fax
IF ( @type = 'FindItem70' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info 2'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem71) Predenials - Certification and Prequalification
IF ( @type = 'FindItem71' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss1.Status is not null and ss2.Status is not null
	and   ss2.Status = 'PreDeny'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0) 
END
	
-- !!ON HOLD!!	(FindItem72) Firms with OIG Letters of Concern
IF ( @type = 'FindItem72' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Id in (select supplierid from supplierdocument where type = 'ConcernLetter')
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)
END
	
-- (FindItem73) Conditional Certifications Awaiting Prequalification
IF ( @type = 'FindItem73' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss1.Status is not null and ss1.Status = 'Director Approved'
	and	  ss2.Status is not null and ss2.Status  in (
			 'Application Submitted'
			,'Manager Reviewed'
			,'Reviewer Reviewed'
			,'Request More Info Pending'
			,'Request More Info'
			,'Additional Info Submitted'
			,'Reference Reviewed'
			,'Financial Reviewed'
			,'Reference and Financial Reviewed'
			,'OIG Approved'
			,'Qualified Pending'
			,'OIG Reviewed'
			,'Request More Info 2'
			,'Additional Info Submitted 2'
			)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)   
END
	
-- (FindItem74) Number of Rejected Firms (Certification/Prequalification)
IF ( @type = 'FindItem74' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss1.Status is not null and ss1.Status = 'Admin Closed'
	and	  ss2.Status is not null
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0) 
END

		-- (FindItem75) # of Prequalified Firms- Pending Certification
	IF ( @type = 'FindItem75' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
					left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
					left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		where s.Status & 1 != 1 and ss1.Status is not null and ss1.Status not in (
															 'Certified'
															,'New Certification'
															,'Admin Closed'
															,'Withdrawn'
															,'Disqualified'
															,'Decertified'
															,'Rescinded'
															,'Suspended'
															,'Deny'
															,'Expired'
															,'Archived'
															)
		and	  ss2.Status is not null and ss2.Status = 'Qualified'
		and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
	END
	
		-- !!ON HOLD!!	(FindItem76) Firms with Red Flags - MWLBE Audit flag
	IF ( @type = 'FindItem76' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- !!ON HOLD!!	(FindItem77) Certified Firms Approved SAF
	IF ( @type = 'FindItem77' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- !!ON HOLD!!	(FindItem78) Certified Firms Denied SAF Approval
	IF ( @type = 'FindItem78' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- !!ON HOLD!!	(FindItem79) Certified Firms Pending SAF Approval
	IF ( @type = 'FindItem79' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (!!ON HOLD!!	FindItem80) Total Mentor Eligible Firms approved for program - awaiting signed agreement
	IF ( @type = 'FindItem80' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- !!ON HOLD!!	(FindItem81) Total Mentor Eligible firms interview scheduled
	IF ( @type = 'FindItem81' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- !!ON HOLD!!	(FindItem82) Total Mentor Eligible firms interviewed - awaiting program entry dates
	IF ( @type = 'FindItem82' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- !!ON HOLD!!	(FindItem83) Total Mentor Eligible firms interviewed - denied program entry
	IF ( @type = 'FindItem83' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- !!ON HOLD!!	(FindItem84) Total Mentor Eligible firms pending mentor program approval
	IF ( @type = 'FindItem84' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem85) Total Mentor Eligible firms signed that interested in participating in Mentor Program
	IF ( @type = 'FindItem85' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem86) Total number of firms in Mentor Program
	IF ( @type = 'FindItem86' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem87) Graduate Mentor Limited List Awaiting Vetting and Approval
	IF ( @type = 'FindItem87' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem88) Mentor Limited List Assigned to Analyst for Vetting
	IF ( @type = 'FindItem88' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem89) Mentor Limited List Awaiting Vetting and Approval
	IF ( @type = 'FindItem89' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem90) Mentor Limited List Vetted - Approved by Senior Director and Submitted to Director of Mentor Program for Approval
	IF ( @type = 'FindItem90' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem91) Mentor Limited List Vetted - Awaiting Approval by Senior Director
	IF ( @type = 'FindItem91' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem92) # Mentor program participants on active bid lists
	IF ( @type = 'FindItem92' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem93) Certified firms pending SAF (Mentor Program eligible)
	IF ( @type = 'FindItem93' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem94) Certified firms that are pending pre-qualification (Mentor Program eligible only)
	IF ( @type = 'FindItem94' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem95) Conditional certifications awaiting pre-qualification (Mentor Program eligible)
	IF ( @type = 'FindItem95' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem96) Current workload for Graduate Mentor Program participants
	IF ( @type = 'FindItem96' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem97) Current workload for Mentor Program participants
	IF ( @type = 'FindItem97' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem98) Firms pending pre-qualification-not certified (Mentor Program eligible only)
	IF ( @type = 'FindItem98' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem99) Firms whose certification will lapse in 30 days (Mentor Program eligible only)
	IF ( @type = 'FindItem99' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem100) Firms with OIG letters of concern (Mentor Program eligible only)
	IF ( @type = 'FindItem100' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem101) List current participants of the Graduate Program
	IF ( @type = 'FindItem101' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem102) List current participants of the Mentor Program
	IF ( @type = 'FindItem102' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem103) Mentor participants that were taken off bid lists
	IF ( @type = 'FindItem103' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem104) Mentor Program participants current bid lists
	IF ( @type = 'FindItem104' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem105) Mentor Program Participants with Negative Project Evaluations
	IF ( @type = 'FindItem105' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem106) Mentor Program participants with negative vedex information
	IF ( @type = 'FindItem106' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem107) Pending  Graduate Mentor Program bid lists
	IF ( @type = 'FindItem107' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem108) Pending Mentor Program bid lists
	IF ( @type = 'FindItem108' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem109) Predenial - certification and pre-qualification (Mentor Program eligible only)
	IF ( @type = 'FindItem109' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem110) Rejected firms - certification and pre-qualification (Mentor Program eligible)
	IF ( @type = 'FindItem110' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem111) Certified firms pending SAF (Mentor Program eligible)
	IF ( @type = 'FindItem111' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem112) Current workload for Mentor Program participants
	IF ( @type = 'FindItem112' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem113) Firms with OIG letters of concern (Mentor Program eligible only)
	IF ( @type = 'FindItem113' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem114) List new participants of the Mentor Program
	IF ( @type = 'FindItem114' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem115) Mentor Program Firms that Bid on Mentor Jobs
	IF ( @type = 'FindItem115' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem116) Mentor Program Firms with Negative Evaluations
	IF ( @type = 'FindItem116' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem117) Pending Mentor Program bid lists
	IF ( @type = 'FindItem117' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem120) Certification Information Pending 
	IF ( @type = 'FindItem120' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
					left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		where isnull(ss.Status,'') in ('Request More Certification Info','Request More Certification Info 2')
			and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
	END
	
		-- !!ONHOLD!!(FindItem121) Certified Firms Pending SAF Approvals
	IF ( @type = 'FindItem121' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem123) Firms Pending Recertification 
	IF ( @type = 'FindItem123' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
			left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		where isnull(ss1.Status,'') = 'Certification Submitted'
		and s.Status & 1 = 1
			and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
	END
	
		-- !!ONHOLD!!(FindItem124) MWLBE Firms Awaiting Audit
	IF ( @type = 'FindItem124' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- !!ONHOLD!!(FindItem125) MWLBE Firms that have been audited
	IF ( @type = 'FindItem125' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
-- (FindItem130) Total # of Files
IF ( @type = 'FindItem130' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0) 
END
	
		-- (FindItem133) Certified Firms Approved SAF
	IF ( @type = 'FindItem133' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem134) Certified Firms Denied SAF Approval
	IF ( @type = 'FindItem134' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem135) Certified Firms Pending SAF Approval
	IF ( @type = 'FindItem135' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem136) Total Mentor Eligible Firms approved for program - awaiting signed agreement
	IF ( @type = 'FindItem136' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem137) Total Mentor Eligible firms interview scheduled
	IF ( @type = 'FindItem137' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem138) Total Mentor Eligible firms interviewed - awaiting program entry dates
	IF ( @type = 'FindItem138' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem139) Total Mentor Eligible firms interviewed - denied program entry
	IF ( @type = 'FindItem139' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem140) Total Mentor Eligible firms pending mentor program approval
	IF ( @type = 'FindItem140' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem141) Total Mentor Eligible firms signed that interested in participating in Mentor Program
	IF ( @type = 'FindItem141' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
		-- (FindItem142) Total number of firms in Mentor Program
	IF ( @type = 'FindItem142' )
	BEGIN
		Insert Into @temp ( SupplierId )
		select s.Id
		from Supplier s
		--where
	END
	
-- (FindItem146) Pending OIG Signoff for OIG
IF ( @type = 'FindItem146' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') in (
									 'Reference Reviewed'
									,'Financial Reviewed'
									,'Reference and Financial Reviewed'
								   )
	and (sv.status is null or sv.status <> 0)  
	
	
	-- TFS Issue #493 FindItem 294
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
		left join SupplierProperty sp2 on s.Id = sp2.SupplierId and sp2.PropertyId = @propertyId_IOGDecision
		left join supplierworkflow sw	on s.id = sw.supplierid and sw.workflowid = @WORKFLOW_QUALIFICATION
		left join workflowhistory wh1	on sw.transactionid = wh1.transactionheaderid 
		left join SupplierStaticQualification sq	on s.id = sq.supplierid 
	where isnull(ss.Status,'') in ( 'OIG Pending', 'Qualified Pending', 'Qualified' )
	and isnull(convert(nvarchar(500), sp2.PropertyText), '') = ''
	and wh1.CurrentNodeId = 488 
	and isnull(sq.V_C_APPR_IG, '') != 'Y'
	and (sv.status is null or sv.status <> 0)  
	
	
	
END
	
-- (FindItem147) Total OIG 15 Day Letters
--IF ( @type = 'FindItem147' )
--BEGIN
	--Insert Into @temp ( SupplierId )
	--select s.Id
--	from Supplier s
--		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where isnull(ss.Status,'') in (
--									 'Reference Reviewed'
--									,'Financial Reviewed'
--									,'Reference and Financial Reviewed'
--								   )
--	and (sv.status is null or sv.status <> 0)  
--RETURN @count
--END

-- (FindItem148) Total OIG Letter of Concern
IF ( @type = 'FindItem148' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp2 on s.Id = sp2.SupplierId and sp2.PropertyId = @propertyId_IOGDecision
		left join supplierversion sv on s.Id = sv.SupplierId
	where convert(nvarchar(500),sp2.PropertyText) = 'Provide Letter of Concern'
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem149) Total Files with OIG Denials
IF ( @type = 'FindItem149' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join supplierworkflow sw	on s.id = sw.supplierid and sw.workflowid = @WORKFLOW_CERTIFICATION
		left join workflowhistory wh1	on sw.transactionid = wh1.transactionheaderid 
		left join workflowhistory wh2	on wh1.prevhistoryid = wh2.id
		left join supplierversion sv on s.Id = sv.SupplierId
	where wh1.id is not null
	and wh2.id is not null
	and wh1.CurrentNodeId = @DirectorClosePending 
	and wh2.currentnodeid in (@ReferenceReviewed,@FinacialReviewed)
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem294) Pending True Requal
IF ( @type = 'FindItem294' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
		left join SupplierProperty sp2 on s.Id = sp2.SupplierId and sp2.PropertyId = @propertyId_IOGDecision
		left join supplierworkflow sw	on s.id = sw.supplierid and sw.workflowid = @WORKFLOW_QUALIFICATION
		left join workflowhistory wh1	on sw.transactionid = wh1.transactionheaderid 
		left join SupplierStaticQualification sq	on s.id = sq.supplierid 
	where isnull(ss.Status,'') in ( 'OIG Pending', 'Qualified Pending', 'Qualified' )
	and isnull(convert(nvarchar(500), sp2.PropertyText), '') = ''
	and wh1.CurrentNodeId = 488 
	and isnull(sq.V_C_APPR_IG, '') != 'Y'
	and (sv.status is null or sv.status <> 0)  
END
	
	
-- (FindItem295) Incomplete by OIG 
IF ( @type = 'FindItem295' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'OIG Qualification'
	where isnull(ss.Status,'') in ( 'Incomplete by OIG' )
END

-- (FindItem296) Resubmission to OIG
IF ( @type = 'FindItem296' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'OIG Qualification'
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Prequalification' 
	where isnull(ss.Status,'') in ( 'Resubmission to OIG' )
	-- Resubmission to OIG for release 3.0
	and isnull(ss1.Status,'')  not in ('Qualified', 'Deny','Withdrawn','Suspended','Qualification Pending','Disqualified','Rescinded','')

END

IF ( @type = 'FindItem297' )
BEGIN
	Insert Into @temp ( SupplierId )
	Select	distinct s.supplierid
	from	Supplierpersonnel s
	where	isKeyperson='Y'
	and 	status!=4
	and		OIGReviewed=2
END


------------ Qualification Status ----------

-- (FindItem150) Application Submitted
IF ( @type = 'FindItem150' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Application Submitted'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem151) Manager Reviewed
IF ( @type = 'FindItem151' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Manager Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem274) Pre Deny
IF ( @type = 'FindItem274' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'PreDeny'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem152) Request More Info Pending
IF ( @type = 'FindItem152' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info Pending'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem153) Request More Info
IF ( @type = 'FindItem153' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem154) Additional Info Submitted
IF ( @type = 'FindItem154' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Info Submitted'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem155) Request More Info 2
IF ( @type = 'FindItem155' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info 2'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem156) Additional Info Submitted 2
IF ( @type = 'FindItem156' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Info Submitted 2'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem157) Reviewer Reviewed
IF ( @type = 'FindItem157' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reviewer Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
		or @cquFinancialAnalystCount>0)
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem158) Reference Reviewed
IF ( @type = 'FindItem158' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reference Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
		or @cquFinancialAnalystCount>0)
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem159) Financial Reviewed
IF ( @type = 'FindItem159' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Financial Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem160) Reference and Financial Reviewed
IF ( @type = 'FindItem160' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reference and Financial Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem161) OIG Approved
IF ( @type = 'FindItem161' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'OIG Approved'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem162) OIG Reviewed
IF ( @type = 'FindItem162' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'OIG Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem627) OIG Incomplete
IF ( @type = 'FindItem627' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'OIG Qualification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Incomplete by OIG'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem163) OIG Pending
IF ( @type = 'FindItem163' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'OIG Pending'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem164) Qualified Pending
IF ( @type = 'FindItem164' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified Pending'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END
	
-- (FindItem165) Qualified
IF ( @type = 'FindItem165' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem193) Unsubmitted Applications
IF ( @type = 'FindItem193' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'New Qualification'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END
------------ End Qualification Status ----------

------------ Trade Code Amendments ----------

-- (FindItem628) Amended Trade Code Application Submitted
IF ( @type = 'FindItem628' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Amended Trade Code Application Submitted'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem629) Manager Reviewed
IF ( @type = 'FindItem629' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Manager Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem630) Reviewer Reviewed
IF ( @type = 'FindItem630' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reviewer Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
		or @cquFinancialAnalystCount>0)
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem631) Request More Info
IF ( @type = 'FindItem631' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem632) Qualified 
IF ( @type = 'FindItem632' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

------------ End Trade Code Amendments ----------

------------ Over 1MM Amendments ----------

-- (FindItem633) Over 1MM Application Submitted
IF ( @type = 'FindItem633' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Over 1MM Application Submitted'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem634) Manager Reviewed
IF ( @type = 'FindItem634' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Manager Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem635) Reference Reviewed
IF ( @type = 'FindItem635' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reference Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
		Or  @cquFinancialAnalystCount>0)
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem636) Finacial Reviewed
IF ( @type = 'FindItem636' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Finacial Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem637) Reference and Finacial Reviewed
IF ( @type = 'FindItem637' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reference and Finacial Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem638) Reviewer Reviewed
IF ( @type = 'FindItem638' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reviewer Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
		or @cquFinancialAnalystCount>0)
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem639) Qualified
IF ( @type = 'FindItem639' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

------------ End Over 1MM Amendments ----------


------------ Certification Status ----------
-- (FindItem166) Certification Submitted
IF ( @type = 'FindItem166' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certification Submitted'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem167) Certification Analyst Assigned
IF ( @type = 'FindItem167' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certification Analyst Assigned'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem168) Request More Certification Info Pending
IF ( @type = 'FindItem168' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info Pending'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem169) Request More Certification Info
IF ( @type = 'FindItem169' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem170) Additional Certification Info Submitted
IF ( @type = 'FindItem170' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Certification Info Submitted'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem171) Request More Certification Info 2
IF ( @type = 'FindItem171' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info 2'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem172) Additional Certification Info Submitted 2
IF ( @type = 'FindItem172' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Certification Info Submitted 2'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem173) Certification Analyst Reviewed
IF ( @type = 'FindItem173' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certification Analyst Reviewed'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem174) MWBE Reviewed
IF ( @type = 'FindItem174' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'MWBE Reviewed'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem175) LBE Reviewed
IF ( @type = 'FindItem175' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'LBE Reviewed'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem176) Certification Analyst Approved
IF ( @type = 'FindItem176' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certification Analyst Approved'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem177) Director Approval Pending
IF ( @type = 'FindItem177' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Director Approval Pending'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem178) Director Approved
IF ( @type = 'FindItem178' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Director Approved'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem179) Conditionally Certified
IF ( @type = 'FindItem179' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Conditionally Certified'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem180) Certified
IF ( @type = 'FindItem180' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certified'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END

-- (FindItem194) Unsubmitted Applications
IF ( @type = 'FindItem194' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'New Certification'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
END
------------ End Certification Status ----------

------------ CQU & BDD Aging ----------
-- (FindItem181) CQU Aging 0 - 3 Months
IF ( @type = 'FindItem181' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between DateAdd(month, -3, getdate()) and getdate())
	and (sv.status is null or sv.status <> 0)   
END

-- (FindItem182) CQU Aging 3 - 6 Months
IF ( @type = 'FindItem182' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between DateAdd(month, -6, getdate()) and DateAdd(month, -3, getdate()))
	and (sv.status is null or sv.status <> 0)   
END

-- (FindItem183) CQU Aging 6 - 9 Months
IF ( @type = 'FindItem183' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between DateAdd(month, -9, getdate()) and DateAdd(month, -6, getdate()))
	and (sv.status is null or sv.status <> 0)   
END

-- (FindItem184) CQU Aging 9 - 12 Months
IF ( @type = 'FindItem184' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between DateAdd(month, -12, getdate()) and DateAdd(month, -9, getdate()))
	and (sv.status is null or sv.status <> 0)   
END

-- (FindItem185) CQU Aging 12 Months and more
IF ( @type = 'FindItem185' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between '01/01/1901' and DateAdd(month, -12, getdate()))
	and (sv.status is null or sv.status <> 0)   
END

-- (FindItem186) BDD Aging 0 - 3 Months
IF ( @type = 'FindItem186' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between DateAdd(month, -3, getdate()) and getdate())
	and (sv.status is null or sv.status <> 0)   
END

-- (FindItem187) BDD Aging 3 - 6 Months
IF ( @type = 'FindItem187' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between DateAdd(month, -6, getdate()) and DateAdd(month, -3, getdate()))
	and (sv.status is null or sv.status <> 0)   
END

-- (FindItem188) BDD Aging 6 - 9 Months
IF ( @type = 'FindItem188' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between DateAdd(month, -9, getdate()) and DateAdd(month, -6, getdate()))
	and (sv.status is null or sv.status <> 0)   
END

-- (FindItem189) BDD Aging 9 - 12 Months
IF ( @type = 'FindItem189' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between DateAdd(month, -12, getdate()) and DateAdd(month, -9, getdate()))
	and (sv.status is null or sv.status <> 0)   
END

-- (FindItem190) BDD Aging 12 Months and more
IF ( @type = 'FindItem190' )
BEGIN
	Insert Into @temp ( SupplierId )
	select s.Id
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between '01/01/1901' and DateAdd(month, -12, getdate()))
	and (sv.status is null or sv.status <> 0)   
END

		
Declare @temp1 Table
(
OrderId int identity (1,1) Primary Key,
SupplierId int
)
Insert Into @temp1(SupplierId)
SELECT s.Id 
From Supplier s, @temp t
where s.Id = t.SupplierId

ORDER BY 
--text asc
CASE @sequence 
WHEN 'ASC' THEN 
CASE @orderBy 
    	WHEN 'Company' THEN s.Company
    	WHEN 'Email' THEN s.Email
		WHEN 'CurrentLocation' THEN s.CurrentLocation
		WHEN 'FederalId' THEN s.FederalId
		WHEN 'InternalVendorId' THEN s.InternalVendorId
		WHEN 'UserName' THEN s.UserName
		WHEN 'ChangeUser' THEN s.ChangeUser
ELSE ''
END
END ASC,
--datetime asc
CASE @sequence 
WHEN 'ASC' THEN 
CASE @orderBy 
    	WHEN 'ApplyDate' THEN s.ApplyDate
    	WHEN 'ChangeDate' THEN s.ChangeDate
ELSE ''
END
END ASC,
--int asc
CASE @sequence 
WHEN 'ASC' THEN 
CASE @orderBy 
    	WHEN 'Status' THEN s.Status
ELSE ''
END
END ASC,
--text desc
CASE @sequence	
WHEN 'DESC' THEN 
CASE @orderBy
    	WHEN 'Company' THEN s.Company
    	WHEN 'Email' THEN Email
		WHEN 'CurrentLocation' THEN s.CurrentLocation
		WHEN 'FederalId' THEN s.FederalId
		WHEN 'InternalVendorId' THEN s.InternalVendorId
		WHEN 'UserName' THEN s.UserName
		WHEN 'ChangeUser' THEN s.ChangeUser
ELSE ''
END 
END DESC,
--int desc
CASE @sequence 
WHEN 'DESC' THEN 
CASE @orderBy 
    	WHEN 'Status' THEN s.Status
ELSE ''
END
END DESC,
--datetime desc
CASE @sequence 
WHEN 'DESC' THEN 
CASE @orderBy 
    	WHEN 'ApplyDate' THEN s.ApplyDate
    	WHEN 'ChangeDate' THEN s.ChangeDate
ELSE ''
END
END DESC


-- output supplier collection in page
select @totalcount = count(*) from @temp1
if @pageSize > 0
Delete from @temp1
Where OrderId < @beginCount or OrderId > @endCount

SELECT
s.Id					AS '@Id'
, s.SupplierType		AS '@SupplierType'
, s.Company				AS '@Company'
, s.TradeNames			AS '@TradeNames'
, s.Phone				AS '@Phone'
, s.Extension			AS '@Extension'
, s.Fax					AS '@Fax'
, s.Email				AS '@Email'
, s.Url					AS '@Url'
, s.BusinessType		AS '@BusinessType'
, s.LegalStructure		AS '@LegalStructure'
, s.FederalId			AS '@FederalId'
, s.YearEstablished		AS '@YearEstablished'
, s.EmployeeTotal		AS '@EmployeeTotal'
, s.InsuranceCarrier	AS '@InsuranceCarrier'
, s.DbNum				AS '@DbNum'
, s.Description			AS '@Description'
, s.Gender				AS '@Gender'
, s.Ethnicity			AS '@Ethnicity'
, s.IsCertified			AS '@IsCertified'
, s.HasOnlineCatalog	AS '@HasOnlineCatalog'
, s.HasOnlineSell		AS '@HasOnlineSell'
, s.HasEdiCapable		AS '@HasEdiCapable'
, s.AcceptCreditCard	AS '@AcceptCreditCard'
, s.CurrentSupplier		AS '@CurrentSupplier'
, s.AnnualSales			AS '@AnnualSales'
, s.CurrentContact		AS '@CurrentContact'
, s.CurrentPhone		AS '@CurrentPhone'
, s.CurrentExtension	AS '@CurrentExtension'
, s.HasSupplierDiversityProgram			AS '@HasSupplierDiversityProgram'
, s.IsPublicTraded			AS '@IsPublicTraded'
, s.ApplyUser			AS '@ApplyUser'
, s.ApplyDate			AS '@ApplyDate'
, s.ChangeUser			AS '@ChangeUser'
, s.ChangeDate			AS '@ChangeDate'
, s.Status				AS '@Status'
, s.Password			AS '@Password'
, s.InternalVendorId	AS '@InternalVendorId'
, s.ParentId			AS '@ParentId'
, s.SalesTaxState		AS '@SalesTaxState'
, s.PaymentTerm			AS '@PaymentTerm'
, s.PaymentMethod		AS '@PaymentMethod'
, s.DiscountTerm		AS '@DiscountTerm'
, s.CurrentLocation		AS '@CurrentLocation'
, s.PrimaryCategoryId	AS '@PrimaryCategoryId'
, s.CcrListed			AS '@CcrListed'
, s.CageCode			AS '@CageCode'
, s.PreparerName		AS '@PreparerName'
, s.PreparerPhone		AS '@PreparerPhone'
, s.PreparerEmail		AS '@PreparerEmail'
, s.StateIncorporation			AS '@StateIncorporation'
, s.StateSalesTaxId			AS '@StateSalesTaxId'
, s.SupplierId			AS '@SupplierId'
, s.UserName			AS '@UserName'
, s.SupplierStatus      AS '@SupplierStatus'
,s.QualifiedDate as '@QualifiedFrom'
,(select top 1 V_SD_PREQUAL_TO from SupplierStaticQualification where supplierid=s.id and V_SD_PREQUAL_TO<>'1900-01-01 00:00:00.000') as '@QualifiedTo'
,s.CertifiedDate as '@CertifiedFrom'
,(select top 1 V_SD_EXP_DATE from SupplierStaticCertification where supplierid=s.id and V_SD_EXP_DATE<>'1900-01-01 00:00:00.000') as '@CertifiedTo'
,[dbo].[GetMWLBEClassifications](s.id) as '@MWLBECertInfo'
,isnull((select top 1 convert(varchar,isnull(FinancialCapacity,0))
				from SupplierFinancial
				where SupplierId = s.Id
				and Type = 'PreQual'
				order by Id desc ),'') 	AS '@Currency'
, isnull((select top 1 filename from supplierdocument 
		where supplierid = s.id 
		and type = '50'	
		and attachment is not null),''
	)   AS		'@Filename'
, @totalcount			AS '@TotalRecordNumber'
,(
		SELECT 
				sc.SupplierId			as '@SupplierId',
				sc.CategoryId 			as '@CategoryId',
				c.Name					as '@CategoryName',
				sc.IsApproved			as '@IsApproved',
				sc.Average				as '@Average',
				sc.ApprovedAverage		as '@ApprovedAverage',
				(
					Select	c.Id	As '@Id',
							c.Name	As '@Name',
							c.Code	As '@Code'
					From Category c
					Where c.Id = sc.CategoryId
					For XML PATH('Category'), TYPE
				)
		FROM SupplierCategory sc, Category c
		where sc.SupplierId = s.id
		and sc.CategoryId = c.Id
		Order By c.Code
         FOR XML PATH('SupplierCategory'), ROOT('ArrayOfSupplierCategory'), TYPE
	),
(
select
	ss.SupplierId		As '@SupplierId',
	ss.TypeName		As '@TypeName',
	ss.Status		As '@Status'
from SupplierStatus ss
where s.Id = ss.SupplierId
FOR XML PATH('SupplierStatus'), ROOT('ArrayOfSupplierStatus'), TYPE
),

(
        SELECT
              sc.SupplierId		AS '@SupplierId'
			, sc.Classification		AS '@Classification'
			, sc.Certified		AS '@Certified'
          FROM SupplierClassification sc
          WHERE sc.SupplierId = s.Id
          FOR XML PATH('SupplierClassification'), ROOT('ArrayOfSupplierClassification'), TYPE
     )

	,(
			SELECT	
				top 1
				vc.Id				as '@Id',
				vc.VendorId			as '@VendorId',
				vc.ContactType		as '@ContactType',
				vc.FromVendor		as '@FromVendor',
				vc.Department		as '@Department',
				vc.Name				as '@Name',
				vc.Title			as '@Title',
				vc.Phone			as '@Phone',
				vc.Extension		as '@Extension',
				vc.Fax				as '@Fax',
				vc.Email			as '@Email',
				vc.UserName			as '@UserName',
				vc.Password			as '@Password',
				vc.Status			as '@Status',
				v.Company			as '@Company',
				vc.FirstName		as '@FirstName',
				vc.LastName			as '@LastName',
				vc.ContactId		as '@ContactId'
			FROM VendorContact vc, Vendor v
			WHERE vc.vendorId = v.id and v.federalId = s.federalid 
			and vc.ContactType='Primary'
			FOR XML PATH('PrimaryContact'), TYPE
		),(
        SELECT
              c.Id					AS '@Id'
            , c.SupplierId			AS '@SupplierId'
			, c.CertifiedAgent		AS '@CertifiedAgent'
			, c.CertificationType	AS '@CertificationType'
			, c.CertificationNo		AS '@CertificationNo'
			, c.ExpirationDate		AS '@ExpirationDate'
			, c.FaxIn				AS '@FaxIn'
			, c.Filename			AS '@Filename'
			, c.Status				AS '@Status'
			, c.Classification		AS '@Classification'
			, c.AutoVerified		AS '@AutoVerified'
          FROM Certification c
          WHERE c.SupplierId = s.Id
          FOR XML PATH('Certification'), ROOT('ArrayOfCertification'), TYPE
     ),
	(
			SELECT	
				vc.Id				as '@Id',
				vc.VendorId			as '@VendorId',
				vc.ContactType		as '@ContactType',
				vc.FromVendor		as '@FromVendor',
				vc.Department		as '@Department',
				vc.Name				as '@Name',
				vc.Title			as '@Title',
				vc.Phone			as '@Phone',
				vc.Extension		as '@Extension',
				vc.Fax				as '@Fax',
				vc.Email			as '@Email',
				vc.UserName			as '@UserName',
				vc.Password			as '@Password',
				vc.Status			as '@Status',
				v.Company			as '@Company',
				vc.FirstName		as '@FirstName',
				vc.LastName			as '@LastName',
				vc.ContactId		as '@ContactId'
			FROM 
				VendorContact vc
				inner join Vendor v on vc.vendorId = v.id
			WHERE vc.vendorId = v.id and v.federalId = s.federalid 
			FOR XML PATH('Contact'), ROOT('ArrayOfContact'), TYPE
		),
(
SELECT	
	pa.Id AS '@Id',
	pa.SupplierId AS '@SupplierId',
	pa.FromSupplier AS '@FromSupplier',
	pa.AddressType AS '@AddressType',
	pa.AddressLine1 AS '@AddressLine1',
	pa.AddressLine2 AS '@AddressLine2',
	pa.City AS '@City',
	pa.State AS '@State',
	pa.ZipCode AS '@ZipCode',
	pa.Country AS '@Country',
	pa.County AS '@County'
FROM SupplierAddress pa
WHERE pa.SupplierId = s.id and pa.AddressType = 'PHYSICAL'
FOR XML PATH('PhysicalAddress'), TYPE
),
(
select
	w.Id		As '@Id',
	w.SupplierId		As '@SupplierId',
	w.WorkflowId		As '@WorkflowId',
	w.TransactionId		As '@TransactionId',
	w.WorkflowType		As '@WorkflowType',
	w.BusinessUnitId		As '@BusinessUnitId'
from SupplierWorkflow w
where s.Id = w.SupplierId
FOR XML PATH('SupplierWorkflow'), ROOT('ArrayOfSupplierWorkflow'), TYPE
),
(
		select
			h.Id					As '@Id',
			h.TransactionHeaderId	As '@TransactionHeaderId',
			h.WorkflowId			As '@WorkflowId',
			h.CurrentNodeId			As '@CurrentNodeId',
			n.Name					As '@CurrentNodeName',
			h.ApprovalUserId		As '@ApprovalUserId',
			h.ApprovalRoleId		As '@ApprovalRoleId',
			h.ApprovalConditionId	As '@ApprovalConditionId',
			h.ApprovalDate			As '@ApprovalDate',
			h.PrevHistoryId			As '@PrevHistoryId',
			h.Status				As '@Status',
			h.IsActive				As '@IsActive',
			h.Comments				As '@Comments',
			h.DateCreated			As '@DateCreated',
			h.CreatedBy				As '@CreatedBy',
			h.CreatedType			As '@CreatedType',
			h.Version				As '@Version',
			Case h.CreatedType
				When 'User' Then isnull(u.FirstName + ' ' + u.LastName, 'System')
				When 'Supplier' Then isnull(c.Name, 'Supplier')
				Else 'System'
			End						As '@Creator',
			Case h.CreatedType
				When 'User' Then isnull(u.Email, 'System')
				When 'Supplier' Then c.Email 
				Else 'System'
			End						
			As '@Email'
		from WorkflowHistory h left join WorkflowNode n on n.Id = h.CurrentNodeId
			left join [User] u on h.CreatedBy = u.Id
			left join VendorContact c on h.CreatedBy = c.Id 
			inner join SupplierWorkflow sw on h.TransactionHeaderId=sw.TransactionId
		where sw.SupplierId=s.id
		and sw.WorkflowType='Supplier Certification'
		FOR XML PATH('WorkflowHistory'), Root('ArrayOfCertWorkflowHistory'),Type
		),
		(
		select 
			vs.VendorId as '@VendorId',
			vs.Certification as '@Certification',
			vs.Status as '@Status',
			vs.CertifiedDate as '@CertifiedDate',
			vs.ExpirationDate as '@ExpirationDate',
			vs.PartnerSource as '@PartnerSource'
		from
			VendorSBSCertification vs
			inner join Vendor v on vs.VendorId=v.id
		where
			v.FederalId=s.federalid
		FOR XML PATH('VendorSBSCertification'), ROOT('ArrayOfVendorSBSCertification'), TYPE
		)
FROM Supplier s, @temp1 t 
where t.supplierId = s.Id
order by t.OrderId
FOR XML PATH('Supplier'), ROOT('ArrayOfSupplier')
GO
PRINT N'Altering [dbo].[GetPlanXml]...';


GO


--GetPlanXml 1084
--GetPlanXml 1083
--GetPlanXml 243
--select * from [plan]
--Plan[ (@IsWaiver = 'Y') ]

/*
*********************************************************************************************************************
Procedure:	GetPlanXml
Purpose:	Get a row from Plan table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/11/2010		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
ALTER procedure [dbo].[GetPlanXml]
	@id int
as

declare @company nvarchar(50)
declare @reviewer nvarchar(50)
declare @duration nvarchar(50)


set @company = (select Company from vendor where FederalId = (select FederalId from [Plan] where ID=@id))
set @reviewer= (select CONVERT(nvarchar(50), propertytext) from PlanProperty where PlanId = @id and PropertyId = 15)


--select
--	@Duration = ISNULL(n_duration, 0)
--from
--	MV_SOLICIT_CONTRACT mv	
--inner join
--	[Plan] p
--on
--	isnull(mv.c_contract, '') = isnull(p.ContractNo, '') 
--	and isnull(mv.me_contract, '') = isnull(p.MeContractNo, '')
--	and isnull(mv.n_solicit_seq, 0) = isnull(p.SolicitSeq, 0)
--where
--	p.Id = @id
		
					
select
	p.Id		As '@Id',
	p.PlanId		As '@PlanId',
	p.Type		As '@Type',
	p.ProjectId		As '@ProjectId',
	p.ContractId		As '@ContractId',
	p.SolicitSeq		As '@SolicitSeq',
	p.SolicitNo       As '@SolicitNo',
	p.ContractNo		As '@ContractNo',
	p.MeContractNo	As '@MeContractNo',
	p.SupplierId		As '@SupplierId',
	p.FederalId		As '@FederalId',
	p.ContractAmount	As '@ContractAmount',
	p.Description		As '@Description',
	p.Comments		As '@Comments',
	p.EEOContactName		As '@EEOContactName',
	p.EEOContactPhone		As '@EEOContactPhone',
	p.EEOContactEmail		As '@EEOContactEmail',
	p.SubcontPercentage		As '@SubcontPercentage',  --Total Proposed %
	p.MWLBEGoal		As '@MWLBEGoal',
	p.RevisedMWLBEGoal		As '@RevisedMWLBEGoal',
	p.WaiverPercentage		As '@WaiverPercentage',
	p.RevisedPercentage		As '@RevisedPercentage',
	p.PlanApprovalDate		As '@PlanApprovalDate',
	p.IsWaiver		As '@IsWaiver',
	p.ProjectDuration  As '@ProjectDuration',
	p.AwardDate As '@AwardDate',
	p.Status		As '@Status',
	p.StatusName		As '@StatusName',
	p.WorkflowId		As '@WorkflowId',
	p.TransactionId		As '@TransactionId',
	dbo.SubmittedAmount(@id)  As '@SubmittedAmount', -- Total Submitted $
	
	--isnull(p.ContractAmount, 0) *  isnull(p.SubcontPercentage, 0)/100 as '@EstimateAmount', --Total Proposed $
	
	/*SUP Calculation Grid changes Release 5.0 */
	isnull((select sum(estvalue) from plansubcontractor where planid=p.id and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))),0) as '@EstimateAmount', 

	dbo.EstimateMWLBESubcontractorAmount(@id) + dbo.EstimateMWLBESupplierAmount(@id) As '@MWLBEEstimateAmount', --Total Proposed MWLBE $
	--CONVERT([decimal](18,2), dbo.Percentage((dbo.EstimateMWLBESubcontractorAmount(@id) + dbo.EstimateMWLBESupplierAmount(@id)), isnull(p.ContractAmount, 0) *  isnull(p.SubcontPercentage, 0)/100)*100, 0) As '@MWLBEEstimatePercentage', --Proposed MWLBE %
	
	/*SUP Calculation Grid changes Release 5.0 */
	CONVERT([decimal](18,2), dbo.Percentage((dbo.EstimateMWLBESubcontractorAmount(@id) + dbo.EstimateMWLBESupplierAmount(@id)), 
					isnull((select sum(estvalue) from plansubcontractor where planid=p.id and  rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))),0)), 0) As '@MWLBEEstimatePercentage',
	case when p.contractamount !=0 then	isnull((select sum(estvalue) from plansubcontractor where planid= p.id)/ p.contractamount,0) *100
	else null end as '@EstimateAmountPercentage',
	
	dbo.ApprovedSubcontractorAmount(@id) + dbo.ApprovedSupplierAmount(@id) As '@ApprovedAmount', --Total Actual $
	dbo.ApprovedMWLBESubcontractorAmount(@id) + dbo.ApprovedMWLBESupplierAmount(@id)  As '@MWLBEApprovedAmount', --Total Actual MWLBE $
	dbo.PerformanceInclusion(@id)  As '@MWLBEApprovedPercentage', -- Actual MWLBE %

	dbo.[PercentageCompletion](@id) As '@PercentageCompletion',
	dbo.[PerformanceInclusion](@id) As '@PerformanceInclusion',
	p.ChangeUser		As '@ChangeUser',
	p.ChangeDate		As '@ChangeDate',
	isnull(@company, '')  As '@Result',

	--TFS# 563 The following email went out when an analyst was closing out a project. 
	--When an analyst close out a project and the evaluation is satisfactory - (in this instance, it was), 
	--there should not be any email sent to the vendor. Can you please stop this email being sent in the future project closeouts?
	isnull((select top 1 propertytext from planproperty 	where propertyid in (31,25) and planid=p.id and cast(propertyText as  varchar(50))='Satisfactory'	),'') as '@Evaluation',
	isnull(convert(nvarchar(50), pp17.propertytext), '') as '@SchoolName',
	isnull(convert(nvarchar(50), pp18.propertytext), '') as '@Property18',
	isnull(convert(nvarchar(50), pp19.propertytext), '') as '@BoroName', 
	(
	select
		i.Id				As '@Id',
		i.PlanId				As '@PlanId',
		i.LLW				As '@LLW',
		i.LLWDesc			As '@LLWDesc',
		i.School			As '@School',
		i.SchoolAddressLine1	As '@SchoolAddressLine1',
		i.SchoolAddressLine2	As '@SchoolAddressLine2',
		i.Boro				As '@Boro',
		i.ZipCode			As '@ZipCode',
		i.ChangeUser		As '@ChangeUser',
		i.ChangeDate		As '@ChangeDate'
	from 
		PlanItem i
	where i.planId = p.Id
	Order By i.LLW
	FOR XML PATH('PlanItem'), ROOT('ArrayOfPlanItem'), TYPE
	)
from 
	[Plan] p
	left outer join
		(select * from planProperty where propertyId = 17) pp17

	on
		p.Id = pp17.PlanId

	left outer join
		(select * from planProperty where propertyId = 18) pp18

	on
		p.Id = pp18.PlanId
	left outer join
		(select * from planProperty where propertyId = 19) pp19

	on
		p.Id = pp19.PlanId
where
	p.Id = @id
FOR XML PATH('Plan')
GO
PRINT N'Altering [dbo].[OutlookByProcessingUnitByUserStatusReport]...';


GO

/*
*********************************************************************************************************************
Procedure:	OutlookByProcessingUnitByUserStatusReport
---------------------------------------------------------------------------------------------------------------------
Date			Developer				Notes
==========		===================		===============================
08/28/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
ALTER procedure [dbo].[OutlookByProcessingUnitByUserStatusReport]
--Declare
	@userId int,
	@processingUnit nvarchar(50),
	@roleName	nvarchar(50),
	@reportType nvarchar(50),
	@baseUrl	nvarchar(200)
as
set nocount on




declare @temp table
(
	OrderId int identity,
	Name	nvarchar(200),
	Timing	nvarchar(50),
	UserName	nvarchar(50),
	OutlookId int,
	UserId	int,
	Ogid	nvarchar(500),
	UserCount	int,
	Sequence	int
)

declare @tempUser table 
( 
	UserId int,
	flag int,
	Name nvarchar(50)
)

-- Contractor Qualification Unit
-- Business Development Division
-- Office of the Inspector General
Declare @user_sup varchar(50)
if @processingUnit = 'Contractor Qualification Unit' 
	or @processingUnit = 'Business Development Division' 
begin
	if @roleName = @reportType
	begin 
		insert into @tempUser (UserId)
		select @userId
	end
	else
	begin
		insert into @tempUser (UserId, flag)
		select distinct ua.UserId, 1 from UserAffiliate ua 
			where ua.AffiliateId = @userId and ua.UserId not in (select UserId from @tempUser)
	end

	if ( @roleName = 'CQU Director' and @reportType = 'CQU Reviewer' )
		or ( @roleName = 'BDD Director' and @reportType = 'BDD Analyst' )
	begin
		insert into @tempUser (UserId)
		select distinct ua.UserId from UserAffiliate ua 
			where ua.AffiliateId in (select UserId from @tempUser) 
				and ua.UserId not in (select UserId from @tempUser)
				and dbo.IsUserInRole(ua.UserId, @reportType) = 1
		delete from @tempUser where flag = 1
	end
	
	delete from @tempUser where dbo.IsUserInRole(UserId, @reportType) != 1

	insert into @temp
	(	
		Name,
		Timing,
		UserName,
		OutlookId,
		UserId,
		Ogid,
		UserCount,
		Sequence
	)
	select distinct o.Name, '', u.FirstName + ' '+ u.LastName, o.Id, u.Id, Replace(o.Url, '~/', @baseUrl) 
		+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=' + convert(nvarchar(50), u.Id), 
		dbo.OutlookByUserCount(u.Id, o.spName, @roleName), o.Sequence
	from Outlook o, OutlookPermission op, aspnet_Roles ar, [User] u, @tempUser m
	where o.Id = op.OutlookId and op.RoleId = ar.RoleId
		and ar.RoleName = @reportType and u.Id = m.UserId
		and (o.type = 'Qualification Status' or o.type = 'Certlification Status')
	order by o.Sequence, u.Id 

	
	if @reportType in ('CQU Manager', 'BDD Analyst') 
		insert into @temp
		(	
			Name,
			Timing,
			UserName,
			OutlookId,
			UserId,
			Ogid,
			UserCount,
			Sequence
		)
		select o.Name, '', 'Unassigned', o.Id, 99991, Replace(o.Url, '~/', @baseUrl) 
			+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=99991', 
			dbo.OutlookByUserCount(99991, o.spName, @roleName), o.Sequence
		from Outlook o, OutlookPermission op, aspnet_Roles ar, [User] u
		where o.Id = op.OutlookId and op.RoleId = ar.RoleId
			and ar.RoleName = @reportType and u.Id = @userId
			and (o.type = 'Qualification Status' or o.type = 'Certlification Status')
		order by o.Sequence, u.Id 

end

ELSE if @processingUnit = 'Trade Code Amendments' 
begin
	if @roleName = @reportType
	begin 
		insert into @tempUser (UserId)
		select @userId
	end
	else
	begin
		insert into @tempUser (UserId, flag)
		select distinct ua.UserId, 1 from UserAffiliate ua 
			where ua.AffiliateId = @userId and ua.UserId not in (select UserId from @tempUser)
	end
	-- Show trade code ammendments for Financial Analyst as well
	if ( (@roleName = 'CQU Director' and @reportType = 'CQU Reviewer') or @reportType='Financial Analyst' Or  @reportType='CQU Financial Analyst')
	begin
		insert into @tempUser (UserId)
		select distinct ua.UserId from UserAffiliate ua 
			where ua.AffiliateId in (select UserId from @tempUser) 
				and ua.UserId not in (select UserId from @tempUser)
				and dbo.IsUserInRole(ua.UserId, @reportType) = 1
		delete from @tempUser where flag = 1
	end
	
	delete from @tempUser where dbo.IsUserInRole(UserId, @reportType) != 1

	insert into @temp
	(	
		Name,
		Timing,
		UserName,
		OutlookId,
		UserId,
		Ogid,
		UserCount,
		Sequence
	)
	select distinct o.Name, '', u.FirstName + ' '+ u.LastName, o.Id, u.Id, Replace(o.Url, '~/', @baseUrl) 
		+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=' + convert(nvarchar(50), u.Id), 
		dbo.OutlookByUserCount(u.Id, o.spName, @roleName), o.Sequence
	from Outlook o, OutlookPermission op, aspnet_Roles ar, [User] u, @tempUser m
	where o.Id = op.OutlookId and op.RoleId = ar.RoleId
		and ar.RoleName = @reportType and u.Id = m.UserId
		and (o.type = 'Trade Code Amendments')
	order by o.Sequence, u.Id 

	if @reportType in ('CQU Manager','CQU Financial Analyst') 
		insert into @temp
		(	
			Name,
			Timing,
			UserName,
			OutlookId,
			UserId,
			Ogid,
			UserCount,
			Sequence
		)
		select o.Name, '', 'Unassigned', o.Id, 99991, Replace(o.Url, '~/', @baseUrl) 
			+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=99991', 
			dbo.OutlookByUserCount(99991, o.spName, @roleName), o.Sequence
		from Outlook o, OutlookPermission op, aspnet_Roles ar, [User] u
		where o.Id = op.OutlookId and op.RoleId = ar.RoleId
			and ar.RoleName = @reportType and u.Id = @userId
			and (o.type = 'Trade Code Amendments')
		order by o.Sequence, u.Id 

end

ELSE if @processingUnit = 'Over 1MM Amendments' 
begin
	if @roleName = @reportType
	begin 
		insert into @tempUser (UserId)
		select @userId
	end
	else
	begin
		insert into @tempUser (UserId, flag)
		select distinct ua.UserId, 1 from UserAffiliate ua 
			where ua.AffiliateId = @userId and ua.UserId not in (select UserId from @tempUser)
	end
	-- Show Over 1MM Ammendments for Financial Analyst As well
	if ( (@roleName = 'CQU Director' and @reportType = 'CQU Reviewer') or @reportType='Financial Analyst' Or  @reportType='CQU Financial Analyst')
	begin
		insert into @tempUser (UserId)
		select distinct ua.UserId from UserAffiliate ua 
			where ua.AffiliateId in (select UserId from @tempUser) 
				and ua.UserId not in (select UserId from @tempUser)
				and dbo.IsUserInRole(ua.UserId, @reportType) = 1
		delete from @tempUser where flag = 1
	end
	
	delete from @tempUser where dbo.IsUserInRole(UserId, @reportType) != 1

	insert into @temp
	(	
		Name,
		Timing,
		UserName,
		OutlookId,
		UserId,
		Ogid,
		UserCount,
		Sequence
	)
	select distinct o.Name, '', u.FirstName + ' '+ u.LastName, o.Id, u.Id, Replace(o.Url, '~/', @baseUrl) 
		+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=' + convert(nvarchar(50), u.Id), 
		dbo.OutlookByUserCount(u.Id, o.spName, @roleName), o.Sequence
	from Outlook o, OutlookPermission op, aspnet_Roles ar, [User] u, @tempUser m
	where o.Id = op.OutlookId and op.RoleId = ar.RoleId
		and ar.RoleName = @reportType and u.Id = m.UserId
		and (o.type = 'Over 1MM Amendments')
	order by o.Sequence, u.Id 

	if @reportType in ('CQU Manager','CQU Financial Analyst') 
		insert into @temp
		(	
			Name,
			Timing,
			UserName,
			OutlookId,
			UserId,
			Ogid,
			UserCount,
			Sequence
		)
		select o.Name, '', 'Unassigned', o.Id, 99991, Replace(o.Url, '~/', @baseUrl) 
			+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=99991', 
			dbo.OutlookByUserCount(99991, o.spName, @roleName), o.Sequence
		from Outlook o, OutlookPermission op, aspnet_Roles ar, [User] u
		where o.Id = op.OutlookId and op.RoleId = ar.RoleId
			and ar.RoleName = @reportType and u.Id = @userId
			and (o.type = 'Over 1MM Amendments')
		order by o.Sequence, u.Id 

end
ELSE if @processingUnit = 'Bid and Award General' 
begin
	if @roleName = @reportType
	begin 
		insert into @tempUser (UserId)
		select @userId
	end
	else
	begin
		insert into @tempUser (UserId, flag)
		select distinct ua.UserId, 1 from UserAffiliate ua 
			where ua.AffiliateId = @userId and ua.UserId not in (select UserId from @tempUser)
	end

	if ( @roleName = 'CAU Manager' and @reportType = 'Contract Specialist' )
	begin
		insert into @tempUser (UserId)
		select distinct ua.UserId from UserAffiliate ua 
			where ua.AffiliateId in (select UserId from @tempUser) 
				and ua.UserId not in (select UserId from @tempUser)
				and dbo.IsUserInRole(ua.UserId, @reportType) = 1
		delete from @tempUser where flag = 1
	end
	
	delete from @tempUser where dbo.IsUserInRole(UserId, @reportType) != 1

	insert into @temp
	(	
		Name,
		Timing,
		UserName,
		OutlookId,
		UserId,
		Ogid,
		UserCount,
		Sequence
	)
	select distinct o.Name, '', u.FirstName + ' '+ u.LastName, o.Id, u.Id, Replace(o.Url, '~/', @baseUrl) 
		+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=' + convert(nvarchar(50), u.Id), 
		dbo.OutlookByUserCount(u.Id, o.spName, @roleName), o.Sequence
	from Outlook o, OutlookPermission op, aspnet_Roles ar, [User] u, @tempUser m
	where o.Id = op.OutlookId and op.RoleId = ar.RoleId
		and ar.RoleName = @reportType and u.Id = m.UserId
		and (o.type = 'Bid and Award General')
	order by o.Sequence, u.Id 

	if @reportType in ('CAU Manager') 
		insert into @temp
		(	
			Name,
			Timing,
			UserName,
			OutlookId,
			UserId,
			Ogid,
			UserCount,
			Sequence
		)
		select o.Name, '', 'Unassigned', o.Id, 99991, Replace(o.Url, '~/', @baseUrl) 
			+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=99991', 
			dbo.OutlookByUserCount(99991, o.spName, @roleName), o.Sequence
		from Outlook o, OutlookPermission op, aspnet_Roles ar, [User] u
		where o.Id = op.OutlookId and op.RoleId = ar.RoleId
			and ar.RoleName = @reportType and u.Id = @userId
			and (o.type = 'Bid and Award General')
		order by o.Sequence, u.Id 

end

ELSE if @processingUnit = 'Prequal Limited List Status' 
	or @processingUnit = 'Mentor Limited List Status' 
	or @processingUnit = 'Inclusion and Rescission' 
begin
	--insert into @tempUser (UserId)
	--select distinct u.Id from [User] u 
	--	where dbo.IsUserInRole(u.Id, @reportType) = 1
		
	insert into @tempUser (UserId)
	select distinct u.Id from [User] u, aspnet_Users au
		where u.UserId = au.UserId 
			--and au.Username in (select ChiefProjectOfficer from RfdProject)
			and dbo.IsUserInRole(u.Id, @reportType) = 1

	insert into @temp
	(	
		Name,
		Timing,
		UserName,
		OutlookId,
		UserId,
		Ogid,
		UserCount,
		Sequence
	)
	select distinct o.Name, '', u.FirstName + ' '+ u.LastName, o.Id, u.Id, Replace(o.Url, '~/', @baseUrl) 
		+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=' + convert(nvarchar(50), u.Id), 
		dbo.OutlookByUserCount(u.Id, o.spName, @roleName), o.Sequence
	from Outlook o, OutlookPermission op, aspnet_Roles ar, [User] u, @tempUser m
	where o.Id = op.OutlookId and op.RoleId = ar.RoleId
		and ar.RoleName = @roleName and u.Id = m.UserId
		and (o.type = 'Prequal Limited List Status' or o.type = 'Mentor Limited List Status'
			or	o.type='Inclusion and Rescission')
	order by o.Sequence, u.Id 
end
 
ELSE if @processingUnit = 'Consultant Evaluation'
begin
	Insert Into @tempUser(UserId)
	Select @userId

	if @reportType in ('Legal', 'VP for Construction Mgmt')
		insert into @tempUser (UserId)
		select distinct u.Id from [User] u, aspnet_Users au
			where u.UserId = au.UserId 
				and dbo.IsUserInRole(u.Id, @reportType) = 1
	else
	begin
		insert into @tempUser (UserId)
		select distinct UserId from ScorecardInvitee
			where UserId = @userId and UserType = @reportType

		insert into @tempUser (UserId)
		select distinct UserId from ScorecardInvitee
			where SupervisorId = @userId and UserType = @reportType
			and UserId not in (Select UserId From @tempUser)

		insert into @tempUser (UserId)
		select distinct SupervisorId from ScorecardInvitee
			where SupervisorId = @userId and UserType = @reportType
			and SupervisorId not in (Select UserId From @tempUser)

		insert into @tempUser (UserId)
		select distinct UserId from ScorecardUser
			where UserId = @userId and UserType = @reportType
			and UserId not in (Select UserId From @tempUser)

		delete from @tempUser where dbo.IsUserInRole(UserId, @reportType) != 1
	end

	insert into @temp
	(	
		Name,
		Timing,
		UserName,
		OutlookId,
		UserId,
		Ogid,
		UserCount,
		Sequence
	)
	select distinct o.Name, '', u.FirstName + ' '+ u.LastName, o.Id, u.Id, Replace(o.Url, '~/', @baseUrl) 
		+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=' + convert(nvarchar(50), u.Id), 
		dbo.OutlookByUserCount(u.Id, o.spName, @roleName), o.Sequence
	from Outlook o, OutlookPermission op, aspnet_Roles ar, [User] u, @tempUser m
	where o.Id = op.OutlookId and op.RoleId = ar.RoleId
		and ar.RoleName = @roleName and u.Id = m.UserId
		and (o.type = 'Consultant Evaluation')
	order by o.Sequence, u.Id 
end

ELSE if @processingUnit = 'SAF Status' 
begin
	
	if @reportType in ('SAF Status') 
	begin
		insert into @tempUser (UserId, Name) values (1, 'Prime Contract')
		insert into @tempUser (UserId, Name) values (2, 'Mentor Contract')
		insert into @tempUser (UserId, Name) values (3, 'RS-1 Prime')
		insert into @tempUser (UserId, Name) values (4, 'RS-1 Mentor')
	end
	else if @reportType in ('Mentor SAF', 'Prime SAF')
		begin
			insert into @tempUser (UserId)
			select distinct u.Id from [User] u, aspnet_Users au
				where u.UserId = au.UserId 
					and dbo.IsUserInRole(u.Id, 'SAF Reviewer') = 1
		end
		
	if @reportType in ('SAF Status') 
	begin
		insert into @temp
		(	
			Name,
			Timing,
			UserName,
			OutlookId,
			UserId,
			Ogid,
			UserCount,
			Sequence
		)
		select distinct o.Name, '', m.Name, o.Id, m.UserId, Replace(o.Url, '~/', @baseUrl) 
			+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=' + convert(nvarchar(50), m.UserId), 
			dbo.OutlookByUserCount(m.UserId, o.spName, @roleName), o.Sequence
		from Outlook o, OutlookPermission op, aspnet_Roles ar, @tempUser m
		where o.Id = op.OutlookId and op.RoleId = ar.RoleId
			and ar.RoleName = @roleName
			and o.type in ('SAF Status')
		order by o.Sequence, m.UserId 
	end
	else if @reportType in ('Mentor SAF', 'Prime SAF') 
	begin
		insert into @temp
		(	
			Name,
			Timing,
			UserName,
			OutlookId,
			UserId,
			Ogid,
			UserCount,
			Sequence
		)
		select distinct o.Name, '', u.FirstName + ' '+ u.LastName, o.Id, m.UserId, Replace(o.Url, '~/', @baseUrl) 
			+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=' + convert(nvarchar(50), m.UserId), 
			dbo.OutlookByUserCount(m.UserId, o.spName, @roleName), o.Sequence
		from Outlook o, OutlookPermission op, aspnet_Roles ar, [User] u, @tempUser m
		where o.Id = op.OutlookId and op.RoleId = ar.RoleId
			and ar.RoleName = @roleName and u.Id = m.UserId
			and o.type in ('Mentor SAF', 'Prime SAF')
		order by o.Sequence, m.UserId 
		
		insert into @temp
		(	
			Name,
			Timing,
			UserName,
			OutlookId,
			UserId,
			Ogid,
			UserCount,
			Sequence
		)
		select o.Name, '', 'Unassigned', o.Id, 99991, Replace(o.Url, '~/', @baseUrl) 
			+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=99991', 
			dbo.OutlookByUserCount(99991, o.spName, @roleName), o.Sequence
		from Outlook o,	OutlookPermission op, aspnet_Roles ar
		where o.Id = op.OutlookId and op.RoleId = ar.RoleId
			and ar.RoleName = @roleName
			and o.type in ('Mentor SAF', 'Prime SAF')
		order by o.Sequence
	end
end

---
ELSE if @processingUnit = 'SUP Status' 
begin
	if @reportType in ('SUP Status') 
	begin
		insert into @tempUser (UserId, Name) values (1, 'Line Contract')
		insert into @tempUser (UserId, Name) values (2, 'CIP Contract')
		insert into @tempUser (UserId, Name) values (3, 'Mentor Contract')
		insert into @tempUser (UserId, Name) values (4, 'MentorGrad Contract')
/*TFS 619 Dashboard*/
		
		select  @user_sup=au.username from [User] u, aspnet_Users au
								where u.UserId = au.UserId
								and  u.Id=@userId 
								and dbo.IsUserInRole(u.Id, @roleName) = 1
			/* Start of Check for User role */

			IF Exists(
					SELECT aspnet_Users.UserName
					From aspnet_Users, [User], aspnet_UsersInRoles, aspnet_Roles
					Where aspnet_Users.UserId = [User].UserId 
					and aspnet_Users.UserId = aspnet_UsersInRoles.UserId
					and aspnet_UsersInRoles.RoleId = aspnet_Roles.RoleId
					and aspnet_Roles.RoleName in ('BDD Director')
					and [User].Id=@userId
					)  
					Set @user_sup=''
			Else
					Set @user_sup=@user_sup			

			/* End of Check for User role */								
								
								
								

		Select a.UserId, Case when @user_sup !='' then a.Name +' ('+b.FirstName + ' '+ b.LastName+')' 
						else a.Name end as 'Name'  
		into ##tempUser  from @tempUser a,
		(select distinct u.Id,u.FirstName,u.LastName from [User] u, aspnet_Users au
								where u.UserId = au.UserId
								and  u.Id=@userId 
								and dbo.IsUserInRole(u.Id, @roleName) = 1)b			
		delete From @tempUser 
		insert into @tempUser (UserId, Name)  select * From ##tempUser
		drop table ##tempUser
		

 
		
/*End of TFS 619 Dashboard*/
	end
		
	if @reportType in ('SUP Status') 
	begin
		insert into @temp
		(	
			Name,
			Timing,
			UserName,
			OutlookId,
			UserId,
			Ogid,
			UserCount,
			Sequence
		)
		select distinct o.Name, '', m.Name, o.Id, m.UserId, Replace(o.Url, '~/', @baseUrl) 
			+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=' + convert(nvarchar(50), m.UserId)+'&uerId_sup='+convert(nvarchar(50),@user_sup)
			,
			Case when @user_sup!='' then
			dbo.OutlookByUserCount_1(m.UserId, o.spName, @roleName,@user_sup)
			Else
			dbo.OutlookByUserCount(m.UserId, o.spName, @roleName)
			End
			,o.Sequence
		from Outlook o, OutlookPermission op, aspnet_Roles ar, @tempUser m
		where o.Id = op.OutlookId and op.RoleId = ar.RoleId 
			and ar.RoleName = @roleName
			and o.type in ('SUP Status')
		order by o.Sequence, m.UserId
	end
end
	
					
--Select * From @temp
--Return

			

--
ELSE if @processingUnit = 'CES Status' 
begin
	
	insert into @tempUser (UserId, Name) values (1, 'Capacity')
	insert into @tempUser (UserId, Name) values (2, 'CIP')
	insert into @tempUser (UserId, Name) values (3, 'Project')
	insert into @tempUser (UserId, Name) values (4, 'Contract')
	insert into @tempUser (UserId, Name) values (5, 'Mentor A')
	insert into @tempUser (UserId, Name) values (6, 'Mentor A Contract')
	insert into @tempUser (UserId, Name) values (7, 'Mentor B')
	insert into @tempUser (UserId, Name) values (8, 'HazMat')
	insert into @tempUser (UserId, Name) values (9, 'HazMat Contract')
	insert into @tempUser (UserId, Name) values (10, 'Non-HazMat')
	insert into @tempUser (UserId, Name) values (11, 'Non-HazMat Contract')

	insert into @temp
	(	
		Name,
		Timing,
		UserName,
		OutlookId,
		UserId,
		Ogid,
		UserCount,
		Sequence
	)
	select n.Name, '', m.Name, n.Id, m.UserId, Replace(o.Url, '~/', @baseUrl) 
		+ '?ogid=' + convert(nvarchar(50), n.Id) + '&type=' + m.Name, 
		count(n.Id), n.UserStepId
	from Outlook o, OutlookPermission op, aspnet_Roles ar, @tempUser m, Scorecard s, WorkflowHistory h, WorkflowNode n
	where o.Id = op.OutlookId and op.RoleId = ar.RoleId
		and ar.RoleName = @roleName
		and o.type = 'CES Status'
		and s.TransactionId = h.TransactionHeaderId
		and h.IsActive = 1 and h.CurrentNodeId = n.Id
		and s.Type = m.Name
		and n.Name <> 'Consultant Not Notified' -- exclude this status
	Group By n.Name, m.Name, n.Id, o.Url, n.UserStepId, m.UserId
	order by n.UserStepId, m.UserId
end
ELSE if @processingUnit = 'User Dashboard Status' 
begin
	
	insert into @tempUser (UserId, Name) values (1, 'Capacity')
	insert into @tempUser (UserId, Name) values (2, 'CIP')
	insert into @tempUser (UserId, Name) values (3, 'Project')
	insert into @tempUser (UserId, Name) values (4, 'Contract')
	insert into @tempUser (UserId, Name) values (5, 'Mentor A')
	insert into @tempUser (UserId, Name) values (6, 'Mentor A Contract')
	insert into @tempUser (UserId, Name) values (7, 'Mentor B')
	
	-- insert into @tempUser (UserId, Name) select Id, Name from SAFType

	insert into @temp
	(	
		Name,
		Timing,
		UserName,
		OutlookId,
		UserId,
		Ogid,
		UserCount,
		Sequence
	)
	select distinct o.Name, '', m.Name, o.Id, m.UserId, Replace(o.Url, '~/', @baseUrl) 
		+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=' + convert(nvarchar(50), m.UserId), 
		dbo.OutlookByUserCount(m.UserId, o.spName, @roleName), o.Sequence
	from Outlook o, OutlookPermission op, aspnet_Roles ar, @tempUser m
	where o.Id = op.OutlookId and op.RoleId = ar.RoleId
		and ar.RoleName = @roleName
		and (o.type = 'User Dashboard Status')
	order by o.Sequence, m.UserId 
end
------------------------------------------
ELSE if (@processingUnit = 'Bid and Award General Status' 
	or   @processingUnit = 'Bid Breakdown Analysis Status' 
	or   @processingUnit = 'Routing to OIG Status'
	or   @processingUnit = 'Addendum Status'
	or   @processingUnit = 'RFI Submission / Processing Status'
)
begin
	insert into @tempUser (UserId)
	select distinct u.Id from [User] u, aspnet_Users au
		where u.UserId = au.UserId 
		and dbo.IsUserInRole(u.Id, @roleName) = 1
		

	insert into @temp
	(	
		Name,
		Timing,
		UserName,
		OutlookId,
		UserId,
		Ogid,
		UserCount,
		Sequence
	)
	select distinct o.Name, '', u.FirstName + ' '+ u.LastName, o.Id, u.Id, Replace(o.Url, '~/', @baseUrl) 
		+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=' + convert(nvarchar(50), u.Id), 
		dbo.OutlookByUserCount(u.Id, o.spName, @roleName), o.Sequence
	from Outlook o, OutlookPermission op, aspnet_Roles ar, [User] u, @tempUser m
	where o.Id = op.OutlookId and op.RoleId = ar.RoleId
		and ar.RoleName = @roleName and u.Id = m.UserId
		and (
				o.type = 'Bid and Award General Workflow' or 
				o.type = 'Bid Breakdown Analysis Workflow' or 
				o.type = 'Routing to OIG Workflow' or 
				o.type = 'Addendum Workflow' or 
				o.type = 'RFI Submission / Processing Workflow'
			)
	order by o.Sequence, u.Id 
	
end
------------------------------------------
ELSE if (@processingUnit = 'Pre-Award Vetting Status' 
	or   @processingUnit = 'Pre-Award Vetting Bond Status'
)
begin
	insert into @tempUser (UserId)
	select distinct u.Id from [User] u, aspnet_Users au
		where u.UserId = au.UserId 
		and dbo.IsUserInRole(u.Id, @roleName) = 1

	insert into @temp
	(	
		Name,
		Timing,
		UserName,
		OutlookId,
		UserId,
		Ogid,
		UserCount,
		Sequence
	)
	select distinct o.Name, '', u.FirstName + ' '+ u.LastName, o.Id, u.Id, Replace(o.Url, '~/', @baseUrl) 
		+ '?ogid=' + convert(nvarchar(50), o.Id) + '&uid=' + convert(nvarchar(50), u.Id), 
		dbo.OutlookByUserCount(u.Id, o.spName, @roleName), o.Sequence
	from Outlook o, OutlookPermission op, aspnet_Roles ar, [User] u, @tempUser m
	where o.Id = op.OutlookId and op.RoleId = ar.RoleId
		and ar.RoleName = @roleName and u.Id = m.UserId
		and (
				o.type = 'Pre-Award Vetting Workflow' or 
				o.type = 'Pre-Award Vetting Bond Workflow'
			)
	order by o.Sequence, u.Id 
end

------- Total -----
insert into @temp
(	
	Name,
	Timing,
	UserName,
	OutlookId,
	UserId,
	Ogid,
	Sequence
)
select distinct Name, '', 'Total', OutlookId, 99999,  '', 99999
from @temp
where @processingUnit != 'Consultant Evaluation'
and @processingUnit != 'User Dashboard Status'

insert into @temp
(	
	Name,
	Timing,
	UserName,
	OutlookId,
	UserId,
	Ogid,
	Sequence
)
select distinct 'Total', '', UserName, 99999, UserId,  '', 99999
from @temp
where @processingUnit != 'Consultant Evaluation'
and @processingUnit != 'User Dashboard Status'

update t1
set t1.UserCount = t2.UserCount
from @temp t1,
(
	select Name, OutlookId, Sum(UserCount) as UserCount
	from @temp 
	where UserId <> 99999
	and	OutlookId <> 99999
	group by Name, OutlookId
) t2
where t1.Name = t2.Name
and t1.OutlookId = t2.OutlookId
and t1.UserId = 99999
and	t1.OutlookId <> 99999

update t1
set t1.UserCount = t2.UserCount
from @temp t1,
(
	select UserName, UserId, Sum(UserCount) as UserCount
	from @temp 
	where OutlookId <> 99999
	group by UserName, UserId
) t2
where t1.UserName = t2.UserName
and t1.UserId = t2.UserId
and	t1.OutlookId = 99999

select * from @temp order by Sequence, OutlookId, OrderId, UserId
GO
PRINT N'Altering [dbo].[OutlookByProcessingUnitStatusReport]...';


GO

/*
*********************************************************************************************************************
Procedure:	OutlookByProcessingUnitStatusReport
---------------------------------------------------------------------------------------------------------------------
Date			Developer				Notes
==========		===================		===============================
08/28/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
*/
ALTER procedure [dbo].[OutlookByProcessingUnitStatusReport]
	@userId int
as
set nocount on

declare @temp table
(
	OrderId int Identity,
	UserId	int,
	ProcessingUnit nvarchar(50),
	UserRole nvarchar(50),
	ReportType nvarchar(50)
)

if (dbo.IsUserInRole(@userId, 'CQU Director') = 1)
begin
	insert into @temp
	select distinct @userId, 'Contractor Qualification Unit', 'CQU Director', 'CQU Manager'   

	insert into @temp
	select distinct @userId, 'Contractor Qualification Unit', 'CQU Director', 'CQU Reviewer'   

		insert into @temp
	select distinct @userId, 'Trade Code Amendments', 'CQU Manager', 'CQU Manager'   

	insert into @temp
	select distinct @userId, 'Trade Code Amendments', 'CQU Manager', 'CQU Reviewer'   

	insert into @temp
	select distinct @userId, 'Over 1MM Amendments', 'CQU Manager', 'CQU Manager'   

	insert into @temp
	select distinct @userId, 'Over 1MM Amendments', 'CQU Manager', 'CQU Reviewer'   
end

if (dbo.IsUserInRole(@userId, 'CQU Manager') = 1)
begin
	insert into @temp
	select distinct @userId, 'Contractor Qualification Unit', 'CQU Manager', 'CQU Manager'   

	insert into @temp
	select distinct @userId, 'Contractor Qualification Unit', 'CQU Manager', 'CQU Reviewer'   

	insert into @temp
	select distinct @userId, 'Trade Code Amendments', 'CQU Manager', 'CQU Manager'   

	insert into @temp
	select distinct @userId, 'Trade Code Amendments', 'CQU Manager', 'CQU Reviewer'   

	insert into @temp
	select distinct @userId, 'Over 1MM Amendments', 'CQU Manager', 'CQU Manager'   

	insert into @temp
	select distinct @userId, 'Over 1MM Amendments', 'CQU Manager', 'CQU Reviewer'   
end

if (dbo.IsUserInRole(@userId, 'CQU Reviewer') = 1)
begin
	insert into @temp
	select distinct @userId, 'Contractor Qualification Unit', 'CQU Reviewer', 'CQU Reviewer'   

	insert into @temp
	select distinct @userId, 'Trade Code Amendments', 'CQU Reviewer', 'CQU Reviewer'   

	insert into @temp
	select distinct @userId, 'Over 1MM Amendments', 'CQU Reviewer', 'CQU Reviewer'   
end

if (dbo.IsUserInRole(@userId, 'CQU Financial Analyst') = 1)
begin
	insert into @temp
	select distinct @userId, 'Contractor Qualification Unit', 'CQU Financial Analyst', 'CQU Financial Analyst'   
	/*
	insert into @temp
	select distinct @userId, 'Trade Code Amendments', 'CQU Financial Analyst', 'CQU Financial Analyst'   
	*/
	insert into @temp
	select distinct @userId, 'Over 1MM Amendments', 'CQU Financial Analyst', 'CQU Financial Analyst'   
end



if (dbo.IsUserInRole(@userId, 'BDD Director') = 1)
begin
	insert into @temp
	select distinct @userId, 'Business Development Division', 'BDD Director', 'BDD Supervisor'   

	insert into @temp
	select distinct @userId, 'Business Development Division', 'BDD Director', 'BDD Analyst'   
end

if (dbo.IsUserInRole(@userId, 'BDD Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Business Development Division', 'BDD Supervisor', 'BDD Supervisor'   

	insert into @temp
	select distinct @userId, 'Business Development Division', 'BDD Supervisor', 'BDD Analyst'   
end

if (dbo.IsUserInRole(@userId, 'BDD Analyst') = 1)
begin
	insert into @temp
	select distinct @userId, 'Business Development Division', 'BDD Analyst', 'BDD Analyst'   
end

if (dbo.IsUserInRole(@userId, 'OIG Admin') = 1 or dbo.IsUserInRole(@userId, 'OIG User') = 1)
begin
	insert into @temp
	select distinct @userId, 'Office of the Inspector General', 'OIG User', 'OIG User'   
end

if (dbo.IsUserInRole(@userId, 'Limited List Mentor Report') = 1)
begin
	insert into @temp
	select distinct @userId, 'Mentor Limited List Status', 'Limited List Mentor Report', 'Chief Project Officer'   
end

if (dbo.IsUserInRole(@userId, 'Limited List Prequal Report') = 1)
begin
	insert into @temp
	select distinct @userId, 'Prequal Limited List Status', 'Limited List Prequal Report', 'Chief Project Officer'   
end

if (dbo.IsUserInRole(@userId, 'Design Project Manager') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Design Project Manager', 'Design Project Manager'
end

if (dbo.IsUserInRole(@userId, 'Design Manager') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Design Project Manager', 'Design Project Manager'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Design Project Manager')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Design Manager', 'Design Manager'
end

if (dbo.IsUserInRole(@userId, 'Deputy Director') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Deputy Director', 'Deputy Director'
end

if (dbo.IsUserInRole(@userId, 'Director') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Director', 'Director'
end

if (dbo.IsUserInRole(@userId, 'Design Reviewer') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Design Reviewer', 'Design Reviewer'
end

if (dbo.IsUserInRole(@userId, 'Design Reviewer Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Design Reviewer', 'Design Reviewer'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Design Reviewer')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Design Reviewer Supervisor', 'Design Reviewer Supervisor'
end

if (dbo.IsUserInRole(@userId, 'Plan Examiner') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Plan Examiner', 'Plan Examiner'
end

if (dbo.IsUserInRole(@userId, 'Plan Examiner Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Plan Examiner', 'Plan Examiner'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Plan Examiner')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Plan Examiner Supervisor', 'Plan Examiner Supervisor'
end

if (dbo.IsUserInRole(@userId, 'Green Manager') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Green Manager', 'Green Manager'
end

if (dbo.IsUserInRole(@userId, 'Green Manager Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Green Manager', 'Green Manager'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Green Manager')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Green Manager Supervisor', 'Green Manager Supervisor'
end

if (dbo.IsUserInRole(@userId, 'Senior Project Officer') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Senior Project Officer', 'Senior Project Officer'
end

if (dbo.IsUserInRole(@userId, 'Chief Project Officer') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Senior Project Officer', 'Senior Project Officer'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Senior Project Officer')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Chief Project Officer', 'Chief Project Officer'
end

if (dbo.IsUserInRole(@userId, 'Bronx CPO') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Bronx CPO', 'Bronx CPO'
end

if (dbo.IsUserInRole(@userId, 'Brooklyn CPO') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Brooklyn CPO', 'Brooklyn CPO'
end

if (dbo.IsUserInRole(@userId, 'Manhattan CPO') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Manhattan CPO', 'Manhattan CPO'
end

if (dbo.IsUserInRole(@userId, 'Queens CPO') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Queens CPO', 'Queens CPO'
end

if (dbo.IsUserInRole(@userId, 'Staten Island CPO') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Staten Island CPO', 'Staten Island CPO'
end

if (dbo.IsUserInRole(@userId, 'Contract Specialist') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Contract Specialist', 'Contract Specialist'
end

if (dbo.IsUserInRole(@userId, 'Contract Specialist Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Contract Specialist', 'Contract Specialist'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Contract Specialist')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Contract Specialist Supervisor', 'Contract Specialist Supervisor'
end

if (dbo.IsUserInRole(@userId, 'Furniture and Equipment Role') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Furniture and Equipment Role', 'Furniture and Equipment Role'
end

if (dbo.IsUserInRole(@userId, 'Furniture and Equipment Role Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Furniture and Equipment Role', 'Furniture and Equipment Role'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Furniture and Equipment Role')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Furniture and Equipment Role Supervisor', 'Furniture and Equipment Role Supervisor'
end

if (dbo.IsUserInRole(@userId, 'Facility Management System Integrator') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Facility Management System Integrator', 'Facility Management System Integrator'
end

if (dbo.IsUserInRole(@userId, 'Facility Management System Integrator Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Facility Management System Integrator', 'Facility Management System Integrator'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Facility Management System Integrator')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Facility Management System Integrator Supervisor', 'Facility Management System Integrator Supervisor'
end

if (dbo.IsUserInRole(@userId, 'Total Building Commissioner') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Total Building Commissioner', 'Total Building Commissioner'
end

if (dbo.IsUserInRole(@userId, 'Total Building Commissioner Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Total Building Commissioner', 'Total Building Commissioner'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Total Building Commissioner')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Total Building Commissioner Supervisor', 'Total Building Commissioner Supervisor'
end

if (dbo.IsUserInRole(@userId, 'Constructability Role') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Constructability Role', 'Constructability Role'
end

if (dbo.IsUserInRole(@userId, 'Constructability Role Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Constructability Role', 'Constructability Role'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Constructability Role')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Constructability Role Supervisor', 'Constructability Role Supervisor'
end

if (dbo.IsUserInRole(@userId, 'Capital Planning') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Capital Planning', 'Capital Planning'
end

if (dbo.IsUserInRole(@userId, 'Capital Planning Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Capital Planning', 'Capital Planning'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Capital Planning')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Capital Planning Supervisor', 'Capital Planning Supervisor'
end

if (dbo.IsUserInRole(@userId, 'Project Support') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Project Support', 'Project Support'
end

if (dbo.IsUserInRole(@userId, 'Project Support Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Project Support', 'Project Support'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Project Support')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Project Support Supervisor', 'Project Support Supervisor'
end

if (dbo.IsUserInRole(@userId, 'Operations Director') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Operations Director', 'Operations Director'
end

if (dbo.IsUserInRole(@userId, 'Operations Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Operations Manager', 'Operations Manager'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Operations Manager')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Operations Supervisor', 'Operations Supervisor'
end

if (dbo.IsUserInRole(@userId, 'Operations Manager') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Operations Manager', 'Operations Manager'
end

if (dbo.IsUserInRole(@userId, 'Director of Mentor Program') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Director of Mentor Program', 'Director of Mentor Program'
end

if (dbo.IsUserInRole(@userId, 'Director of Mentor Program Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Director of Mentor Program', 'Director of Mentor Program'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Director of Mentor Program')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Director of Mentor Program Supervisor', 'Director of Mentor Program Supervisor'
end

if (dbo.IsUserInRole(@userId, 'Senior Director of BDD') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Senior Director of BDD', 'Senior Director of BDD'
end

if (dbo.IsUserInRole(@userId, 'Director of Safety') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Director of Safety', 'Director of Safety'
end

if (dbo.IsUserInRole(@userId, 'Director of Safety Supervisor') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Director of Safety', 'Director of Safety'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'Director of Safety')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Director of Safety Supervisor', 'Director of Safety Supervisor'
end

if (dbo.IsUserInRole(@userId, 'VP of A&E') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'VP of A&E', 'VP of A&E'
end

if (dbo.IsUserInRole(@userId, 'VP for Construction Mgmt') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'VP for Construction Mgmt', 'VP for Construction Mgmt'
end

if (dbo.IsUserInRole(@userId, 'VP of Admin') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'VP of Admin', 'VP of Admin'
end

if (dbo.IsUserInRole(@userId, 'Legal') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'Legal', 'Legal'
end

if (dbo.IsUserInRole(@userId, 'SAF Status Dashboard') = 1)
begin
	insert into @temp
	select distinct @userId, 'SAF Status', 'SAF Status Dashboard', 'SAF Status'
end

if (dbo.IsUserInRole(@userId, 'SAF Mentor Dashboard') = 1)
begin
	insert into @temp
	select distinct @userId, 'SAF Status', 'SAF Mentor Dashboard', 'Mentor SAF'
end

if (dbo.IsUserInRole(@userId, 'SAF Prime Dashboard') = 1)
begin
	insert into @temp
	select distinct @userId, 'SAF Status', 'SAF Prime Dashboard', 'Prime SAF'
end

if (dbo.IsUserInRole(@userId, 'SUP Status Dashboard') = 1)
begin
	insert into @temp
	select distinct @userId, 'SUP Status', 'SUP Status Dashboard', 'SUP Status'
end

if (dbo.IsUserInRole(@userId, 'Global CES Admin') = 1)
begin
	insert into @temp
	select distinct @userId, 'CES Status', 'Global CES Admin', 'CES Status'

	insert into @temp
	select distinct @userId, 'User Dashboard Status', 'Global CES Admin', 'User Dashboard Status'
end

if (dbo.IsUserInRole(@userId, 'Global CES Viewer') = 1)
begin
	insert into @temp
	select distinct @userId, 'CES Status', 'Global CES Viewer', 'CES Status'

	insert into @temp
	select distinct @userId, 'User Dashboard Status', 'Global CES Admin', 'User Dashboard Status'
end

if (dbo.IsUserInRole(@userId, 'Departmental CES Admin') = 1)
begin
	insert into @temp
	select distinct @userId, 'CES Status', 'Departmental CES Admin', 'CES Status'

	insert into @temp
	select distinct @userId, 'User Dashboard Status', 'Global CES Admin', 'User Dashboard Status'
end

if (dbo.IsUserInRole(@userId, 'Bid and Award General Status') = 1)
begin
	insert into @temp
	select distinct @userId, 'Bid and Award General Status', 'Bid and Award General Status', 'Bid and Award General Status'

end
if (dbo.IsUserInRole(@userId, 'Bid Breakdown Analysis Status') = 1)
begin
	insert into @temp
	select distinct @userId, 'Bid Breakdown Analysis Status', 'Bid Breakdown Analysis Status', 'Bid Breakdown Analysis Status'

end
if (dbo.IsUserInRole(@userId, 'Pre-Award Vetting Bond Status') = 1)
begin
	insert into @temp
	select distinct @userId, 'Pre-Award Vetting Bond Status', 'Pre-Award Vetting Bond Status', 'Pre-Award Vetting Bond Status'

end
if (dbo.IsUserInRole(@userId, 'Pre-Award Vetting Status') = 1)
begin
	insert into @temp
	select distinct @userId, 'Pre-Award Vetting Status', 'Pre-Award Vetting Status', 'Pre-Award Vetting Status'

end
if (dbo.IsUserInRole(@userId, 'Routing to OIG Status') = 1)
begin
	insert into @temp
	select distinct @userId, 'Routing to OIG Status', 'Routing to OIG Status', 'Routing to OIG Status'

end
if (dbo.IsUserInRole(@userId, 'Addendum Status') = 1)
begin
	insert into @temp
	select distinct @userId, 'Addendum Status', 'Addendum Status', 'Addendum Status'

end
if (dbo.IsUserInRole(@userId, 'RFI Submission / Processing Status') = 1)
begin
	insert into @temp
	select distinct @userId, 'RFI Submission / Processing Status', 'RFI Submission / Processing Status', 'RFI Submission / Processing Status'

end
if (dbo.IsUserInRole(@userId, 'Inclusion and Rescission') = 1)
begin
	insert into @temp
	select distinct @userId, 'Inclusion and Rescission', 'Inclusion and Rescission', 'Inclusion and Rescission'

end

if (dbo.IsUserInRole(@userId, 'CAU Manager') = 1)
begin	
	insert into @temp
	select distinct @userId, 'Bid and Award General', 'CAU Manager', 'CAU Manager'   

	insert into @temp
	select distinct @userId, 'Bid and Award General', 'CAU Manager', 'Contract Specialist'   
end

if (dbo.IsUserInRole(@userId, 'Contract Specialist') = 1)
begin	
	insert into @temp
	select distinct @userId, 'Bid and Award General', 'Contract Specialist', 'Contract Specialist'   
end

-- IEH Evaluations
if (dbo.IsUserInRole(@userId, 'IEH Hygienist B') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'IEH Hygienist B', 'IEH Hygienist B'
end

if (dbo.IsUserInRole(@userId, 'IEH Hygienist C') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'IEH Hygienist B', 'IEH Hygienist B'
	Where not exists (Select * From @temp Where UserId = @userId and ProcessingUnit = 'Consultant Evaluation'
		and UserRole = 'IEH Hygienist B')

	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'IEH Hygienist C', 'IEH Hygienist C'
end

if (dbo.IsUserInRole(@userId, 'IEH Deputy Director') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'IEH Deputy Director', 'IEH Deputy Director'
end

if (dbo.IsUserInRole(@userId, 'IEH Manager') = 1)
begin
	insert into @temp
	select distinct @userId, 'Consultant Evaluation', 'IEH Manager', 'IEH Manager'
end

select * from @temp order by OrderId
GO
PRINT N'Altering [dbo].[SearchSupplierXml]...';


GO
/*
*********************************************************************************************************************
Procedure:	SearchSupplierXml
Purpose:	Search and Get all Supplier that satisfy the criteria return in Xml format.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
11/22/2004		Lily Xiong			Created
*********************************************************************************************************************
*/
ALTER  procedure [dbo].[SearchSupplierXml]
	@pageSize int,
	@pageNumber int,
	@orderBy nvarchar(50),
	@sequence nvarchar(10),
	@company nvarchar(50),
	@email nvarchar(50),
	@description nvarchar(50),
	@contact nvarchar(50),
	@ethnicity nvarchar(50),
	@supplierType nvarchar(50),
	@status int,
	@naicsCode nvarchar(10),
	@city nvarchar(50),
	@state nvarchar(20),
	@minVolume bigint,
	@maxVolume bigint,
	@beginDate DateTime,
	@endDate DateTime,
	@beginModifyDate DateTime,
	@endModifyDate DateTime,
	@categoryId int,
	@classification nvarchar(500),
	@classificationOperator nvarchar(20),
	@certification nvarchar(20),
	@responses ntext,
	@id int,
	@internalVendorId nvarchar(50),
	@federalId nvarchar(20),
	@extras ntext
AS
set nocount on
declare @beginCount int
declare @endCount int
declare @totalcount int
set @beginCount = @pageNumber * @pageSize + 1
set @endCount = @beginCount + @pageSize - 1
declare @hdoc int
-- Convert Response data from XML to in memory table. 
EXEC sp_xml_preparedocument @hdoc OUTPUT, @extras
declare @extra Table
(
	Name nvarchar(50),
	Value nvarchar(4000)
)
INSERT INTO @extra
(
	Name,
	Value
)
SELECT
	Name,
	Value
FROM OPENXML(@hDoc, '/ArrayOfExtra/Extra', 1)
WITH
(
	Name nvarchar(50),
	Value nvarchar(4000)
)

declare @Address nvarchar(50)
Set @Address = ''
select @Address = Value 
from @extra
where Name = 'Address'

declare @Country nvarchar(10)
Set @Country = ''
select @Country = Value 
from @extra
where Name = 'Country'

declare @LegalStructure nvarchar(50)
Set @LegalStructure = ''
select @LegalStructure = Value 
from @extra
where Name = 'LegalStructure'

declare @Phone nvarchar(50)
Set @Phone = ''
select @Phone = Value
from @extra
where Name = 'Phone'


declare @SCity nvarchar(50)
Set @SCity = ''
select @SCity = Value
from @extra
where Name = 'City'


declare @kpEnable nvarchar(50)
Set @kpEnable = ''
select @kpEnable = Value 
from @extra
where Name = 'kpEnable'

declare @kpName nvarchar(50)
Set @kpName = ''
select @kpName = Value 
from @extra
where Name = 'kpName'

declare @kpSsn nvarchar(50)
Set @kpSsn = ''
select @kpSsn = Value 
from @extra
where Name = 'kpSsn'

declare @kpTitle nvarchar(50)
Set @kpTitle = ''
select @kpTitle = Value 
from @extra
where Name = 'kpTitle'

declare @kpIsOwner nvarchar(1)
Set @kpIsOwner = ''
select @kpIsOwner = Value 
from @extra
where Name = 'kpIsOwner'

declare @kpAddress nvarchar(50)
Set @kpAddress = ''
select @kpAddress = Value 
from @extra
where Name = 'kpAddress'

declare @kpCity nvarchar(50)
Set @kpCity = ''
select @kpCity = Value 
from @extra
where Name = 'kpCity'

declare @kpState nvarchar(50)
Set @kpState = ''
select @kpState = Value 
from @extra
where Name = 'kpState'

declare @kpResume nvarchar(1)
Set @kpResume = ''
select @kpResume = Value 
from @extra
where Name = 'kpResume'

declare @kpEthnicity nvarchar(10)
Set @kpEthnicity = ''
select @kpEthnicity = Value 
from @extra
where Name = 'kpEthnicity'

declare @Categories nvarchar(4000)
Set @Categories = ''
select @Categories = Value 
from @extra
where Name = 'Categories'

declare @LicenseType nvarchar(4000)
Set @LicenseType = ''
select @LicenseType = Value 
from @extra
where Name = 'LicenseTypeListText'

declare @whEnable nvarchar(50)
Set @whEnable = ''
select @whEnable = Value 
from @extra
where Name = 'whEnable'

declare @whMinAmount float
Set @whMinAmount = 0
select @whMinAmount = convert(float,Value) 
from @extra
where Name = 'whMinAmount'

declare @whMaxAmount float
Set @whMaxAmount = 0
select @whMaxAmount = convert(float,Value)  
from @extra
where Name = 'whMaxAmount'

declare @whMinStartDate nvarchar(50)
Set @whMinStartDate = '1/1/1900'
select @whMinStartDate = Value 
from @extra
where Name = 'whMinStartDate'

declare @whMaxStartDate nvarchar(50)
Set @whMaxStartDate = '1/1/1900'
select @whMaxStartDate = Value 
from @extra
where Name = 'whMaxStartDate'

declare @whContractNumber nvarchar(50)
Set @whContractNumber = ''
select @whContractNumber = Value 
from @extra
where Name = 'whContractNumber'

declare @whZipCode nvarchar(50)
Set @whZipCode = ''
select @whZipCode = Value 
from @extra
where Name = 'whZipCode'

declare @whBorough int
Set @whBorough = -1
select @whBorough = convert(int,Value )
from @extra
where Name = 'whBorough'

declare @whMinEndDate nvarchar(50)
Set @whMinEndDate = '1/1/1900'
select @whMinEndDate = Value 
from @extra
where Name = 'whMinEndDate'

declare @whMaxEndDate nvarchar(50)
Set @whMaxEndDate = '1/1/1900'
select @whMaxEndDate = Value 
from @extra
where Name = 'whMaxEndDate'

declare @qualStatus nvarchar(100)
Set @qualStatus = ''
select @qualStatus = Value 
from @extra
where Name = 'QualStatus'

declare @certStatus nvarchar(100)
Set @certStatus = ''
select @certStatus = Value 
from @extra
where Name = 'CertStatus'

declare @mentored nvarchar(1)
Set @mentored = ''
select @mentored = Value 
from @extra
where Name = 'Mentored'

declare @version nvarchar(50)
Set @version = ''
select @version = Value 
from @extra
where Name = 'Version'

declare @bonding float
Set @bonding = 0
select @bonding = Convert(float, Value)
from @extra
where Name = 'Bonding'
and isnumeric(Value) = 1

declare @financialCapacity float
Set @financialCapacity = 0
select @financialCapacity = Convert(float, Value)
from @extra
where Name = 'FinancialCapacity'
and isnumeric(Value) = 1

declare @appType nvarchar(50)
Set @appType = ''
select @appType = Value 
from @extra
where Name = 'AppType'

declare @primeSub char(1)
Set @primeSub = ''
select @primeSub = Value 
from @extra
where Name = 'PrimeSub'

declare @reviewer nvarchar(50)
Set @reviewer = ''
select @reviewer = Value 
from @extra
where Name = 'Reviewer'

declare @projectType nvarchar(50)
Set @projectType = ''
select @projectType = Value 
from @extra
where Name = 'ProjectType'

declare @qualFrom nvarchar(50)
Set @qualFrom = '1/1/1900'
select @qualFrom = Value 
from @extra
where Name = 'QualFrom'

declare @qualTo nvarchar(50)
Set @qualTo = '1/1/1900'
select @qualTo = Value 
from @extra
where Name = 'QualTo'

declare @certFrom nvarchar(50)
Set @certFrom = '1/1/1900'
select @certFrom = Value 
from @extra
where Name = 'CertFrom'

declare @certTo nvarchar(50)
Set @certTo = '1/1/1900'
select @certTo = Value 
from @extra
where Name = 'CertTo'
if(@certTo = '1/1/1900') set @certTo = '12/31/2999'


declare @isPaper char(1)
Set @isPaper = ''
select @isPaper = Value 
from @extra
where Name = 'Paper'

declare @site nvarchar(20)
set @site=''
select @site=value
from @extra
where Name = 'Site'

declare @Over1M nvarchar(20)
set @Over1M=''
select @Over1M=value
from @extra
where Name = 'Over1M'

declare @MWLBECertified char(1)
set @MWLBECertified=''
select @MWLBECertified=value
from @extra
where Name = 'MWLBECertified'

declare @CategoriesOperator varchar(5)
set @CategoriesOperator=''
select @CategoriesOperator=value
from @extra
where Name = 'CategoriesOperator'

declare @Qualified char(1)
set @Qualified=''
select @Qualified=value
from @extra
where Name = 'Qualified'

--PS 1/24/2013
declare @RfdProjectId int
set @RfdProjectId=0
select @RfdProjectId=value
from @extra
where Name = 'ProjectId'

-- PS 12/4/2013
declare @IsWicks char(1)
set @IsWicks='0'
select @IsWicks=value
from @extra
where Name = 'IsWicks'

declare @Wicks varchar(10)
set @Wicks=''
select @Wicks=value
from @extra
where Name = 'Wicks'



declare @ProjectAmount float

if @RfdProjectId >0
begin
	select @ProjectAmount=Amount from RfdProject where id=@RfdProjectId
end

--- End PS 

Declare @tempCategory Table
(	
	CategoryId int,
	ParentId int
)

	if(@Categories != '')
	begin
		insert into @tempCategory( CategoryId,ParentId )
		Select c.Id,c.ParentId From dbo.Split(@Categories, '^') t, Category c
		where t.Item = c.Id or t.Item = c.ParentId
	end
--****************************************************** Site=''*************************************************************************
if(@site='')
begin

	Set @federalId = dbo.fnStripNonnumericChars(@federalId)

	Declare @tempKeyPeople Table
	(
		SupplierId int
	)


	if(@kpEnable = 'Y')
	Insert Into @tempKeyPeople(SupplierId)
		SELECT distinct s.id From Supplier s
			left join SupplierPersonnel kp on s.Id = kp.Supplierid
		Where	( @kpName = '' or kp.Name like  '%' + @kpName + '%' )
		and		( @kpSsn = '' or  kp.SSN like  '%' + @kpSsn + '%' )
		and		( @kpTitle = '' or   kp.Title like  '%' + @kpTitle + '%' )
		and		( @kpIsOwner = '' or  @kpIsOwner = kp.IsOwner)
		and		( @kpAddress = '' or  kp.AddressLine1 like  '%' + @kpAddress + '%'  or  kp.AddressLine2 like  '%' + @kpAddress + '%' )
		and		( @kpCity = '' or   kp.City like  '%' + @kpCity + '%' )
		and		( @kpState = '' or   kp.State like  '%' + @kpState + '%' )
		and		( @kpResume = '' or   @kpResume = 'Y' and kp.Resume is not null)
		and		( @kpEthnicity = '' or kp.Ethnicity = @kpEthnicity)

	Declare @tempWorkHistory Table
	(
		SupplierId int
	)
	if(@whEnable = 'Y')
	Insert Into @tempWorkHistory(SupplierId)
		SELECT distinct s.id From Supplier s
			left join SupplierProject wh on s.id = wh.Supplierid

		Where	( 	(@whMaxAmount = 0 and @whMinAmount = 0)
						or
					(@whMaxAmount = 0 and @whMinAmount <= ContractAmount)
						or
					(@whMinAmount = 0 and @whMaxAmount >= ContractAmount)
						or
					ContractAmount between @whMinAmount and @whMaxAmount	)

		and ( @whContractNumber = '' or @whContractNumber = ContractNumber )
		and ( @whZipCode = '' or @whZipCode = ZipCode )
		and ( @whZipCode = '' or @whZipCode = ZipCode )
		and ( @whBorough = -1 or @whBorough = BoroughId )
		and ( @whMinEndDate = '1/1/1900' or DateDiff(Day, @whMinEndDate, EndDate) >= 0 )
		and ( @whMaxEndDate = '1/1/1900' or DateDiff(Day, @whMaxEndDate, EndDate) <= 0 )
		and ( @whMinStartDate = '1/1/1900' or DateDiff(Day, @whMinStartDate, StartDate) >= 0 )
		and ( @whMaxStartDate = '1/1/1900' or DateDiff(Day, @whMaxStartDate, StartDate) <= 0 )

	declare @mentor Table
	(
		TaxId nvarchar(20),
		StartDate DateTime, -- PS 1/24/2013
		TotalAwards Int  -- PS 1/24/2013
	)

	if @projectType = 'Mentor'
		/*
		Insert Into @mentor(TaxId)
		Select TAX_ID From OPENQUERY(NYCSCA_CES, 'SELECT * FROM mv_Curr_Mentor_BidList')
		*/
		
		Insert Into @mentor(TaxId,StartDate,TotalAwards)
		Select a.TAX_ID,a.[Start_Date],isnull(b.total_awards,0)
		From mv_Curr_Mentor_BidList a --OPENQUERY(NYCSCA_CES, 'SELECT * FROM mv_Curr_Mentor_BidList') a 
			 --left join (Select vendor_id, count(*) as total_awards FROM OPENQUERY(NYCSCA_CES, 'SELECT * FROM MV_VAS_AWARD')group by vendor_id) b  on a.TAX_ID=b.vendor_id
			 left join (Select vendor_id, count(*) as total_awards FROM MV_VAS_AWARD group by vendor_id) b  on a.TAX_ID=b.vendor_id
			 
	if @projectType = 'Graduate Mentor'
		Insert Into @mentor(TaxId)
		Select TAX_ID From mv_Curr_Grad_Mentor_BidList --OPENQUERY(NYCSCA_CES, 'SELECT * FROM mv_Curr_Grad_Mentor_BidList')

	Declare @temp1 Table
	(
		OrderId int identity (1,1) Primary Key,
		SupplierId int,
		FederalId nvarchar(20),
		ReceivedCount int,
		SubmittedCount int,
		AwardedCount int,
		LastBidListDate DateTime,
		TimesCount int,
		InclusionCount int
	)
	Insert Into @temp1(SupplierId, FederalId, ReceivedCount, SubmittedCount,LastBidListDate)
		SELECT Id, FederalId, 0, 0,LastBidlistdate
		From 
			(
			select 
				s.Id,s.SupplierType,s.Company,s.TradeNames,s.Phone,s.Extension,s.Fax,s.Email,s.Url,s.BusinessType,s.LegalStructure,
				s.FederalId,s.StateIncorporation,s.StateSalesTaxId,s.SalesTaxState,s.YearEstablished,s.EmployeeTotal,
				s.InsuranceCarrier,s.DbNum,s.PaymentTerm,s.Description,s.Gender,s.Ethnicity,s.IsCertified,s.HasOnlineCatalog,s.HasOnlineSell,
				s.HasEdiCapable,s.AcceptCreditCard,s.CurrentSupplier,s.AnnualSales,s.CurrentContact,s.CurrentPhone,s.CurrentExtension,s.CurrentLocation,
				s.HasSupplierDiversityProgram,s.IsPublicTraded,s.PrimaryCategoryId,s.CcrListed,s.CageCode,s.PreparerName,s.PreparerPhone,s.PreparerEmail,
				s.ApplyUser,s.ApplyDate,s.ChangeUser,s.ChangeDate,s.Status,s.Password,s.InternalVendorId,s.Logo,s.Picture,s.SupplierId,s.PaymentMethod,s.Currency,
				s.DiscountTerm,s.ParentId,s.UserName,s.ParentDuns,s.SupplierStatus,s.QualSubmittedDate,s.CertSubmittedDate,s.QualifiedDate,s.CertifiedDate,s.Filename,
				s.VASId,s.LimitedListVettingDate,s.TransferredFlag,s.TransferredDate,s.EEOMasterTransferredFlag,s.EEOMasterTransferredDate,s.REVSTATUSTransferredFlag,
				s.REVSTATUSTransferredDate,u10.Lastname as 'ReviewerName',
				u521.Lastname as 'ManagerName',
				u524.Lastname as 'AnalystName',
				isnull(ssq.V_SD_PREQUAL_TO, '1/1/1900') as 'QualifiedTo',
				isnull(CertTo, '1/1/1900') as 'CertifiedTo', 
				ss.Status as 'QualStatus',v.lastbidlistdate
			from supplier s 
				left join supplierstatus ss on s.id = ss.supplierid and typename = 'Supplier Prequalification' 
				left join supplierproperty sp10 on s.id = sp10.supplierid and sp10.propertyid = 10
				left join aspnet_users au10 on au10.username = convert(varchar(256),sp10.propertytext)		
				left join  [user] u10 on u10.userid = au10.userid	
				
				left join supplierproperty sp521 on s.id = sp521.supplierid and sp521.propertyid = 521
				left join aspnet_users au521 on au521.username = convert(varchar(256),sp521.propertytext)		
				left join  [user] u521 on u521.userid = au521.userid
				
				left join supplierproperty sp524 on s.id = sp524.supplierid and sp524.propertyid = 524
				left join aspnet_users au524 on au524.username = convert(varchar(256),sp524.propertytext)		
				left join  [user] u524 on u524.userid = au524.userid
				
				left join supplierstaticqualification ssq on s.id = ssq.supplierid	
				left join (select supplierid, max(V_SD_EXP_DATE) as CertTo from supplierstaticcertification ssc1 where V_SD_EXP_DATE is not null group by supplierid) as ssc on ssc.supplierid = s.id				
				left join Vendor v on s.federalid=v.federalid				
			) as Supplier 
		Where
			( @company = '' or Company like '%' + @company  + '%' or TradeNames like '%' + @company + '%' )
		and ( @email = '' or Email like '%' + @email + '%' 
			or Id in (select v.CurrentSupplierId from VendorContact vc left join Vendor v on vc.Vendorid = v.id  where Email like '%' + @email + '%'))
		and ( @federalId = '' or dbo.fnStripNonnumericChars(FederalId) like '%' + dbo.fnStripNonnumericChars(@federalId)  + '%' )
		and ( @id = 0 or Id = @id )
		and ( @internalVendorId = '' or InternalVendorId like '%' + @internalVendorId  + '%' )
		and ( @Phone = '' or Id in (select v.CurrentSupplierId from VendorContact vc left join Vendor v on vc.Vendorid = v.id  where Phone like '%' + @Phone + '%') )
		and ( @LegalStructure = '' or LegalStructure = @LegalStructure  )
		and ( @supplierType = 'All' or @supplierType = '' or SupplierType = @supplierType )
		-- Keyword Search
		and ( @description = '' or (Description like '%' + @description + '%' 
			or Company like '%' + @description + '%'
			or TradeNames like '%' + @description + '%'
			or Id in (Select s.SupplierId From SupplierCategory s, Category c Where s.CategoryId = c.Id 
				and c.Name like '%' + @description + '%') 
			or InsuranceCarrier like '%' + @description + '%'
			or InsuranceCarrier in (select Code from NaicsCode where [Value] like '%' + @description + '%')
			or Id in (Select s.SupplierId From SupplierNaicsCode s, NaicsCode n Where s.NaicsCode = n.Code 
				and (n.Code like '%' + @description + '%' or n.Value like '%' + @description + '%'))
			or CurrentLocation  like '%' + @description + '%'
			or CurrentLocation in (select Code from SicCode where  [Value] like '%' + @description + '%')
			or Id in (Select s.SupplierId From SupplierSicCode s, SicCode n Where s.SicCode = n.Code 
				and (n.Code like '%' + @description + '%' or n.Value like '%' + @description + '%'))
			or Id in (Select r.ParticipantId From Response r Where r.ResponseText like '%' + @description + '%' ) ) )
		and ( @ethnicity = '' or (@ethnicity='Non-Minority' and Ethnicity = '') or Ethnicity = @ethnicity)
		and ( @status = -1 
			--@status = -2 All mentor status
			or (@status = -2 and Id in (select supplierId from supplierworkflow where workflowId = (select id from workflowlist where name='Mentor Workflow')))
			--@status = -3 All active mentor status
			or (@status = -3 and Id in (select st.supplierid from supplierstatus st, supplierworkflow sw 
											where st.status not in ('Mentor Program Declined','Director Approved') 
											and sw.workflowId = (select id from workflowlist where name='Mentor Workflow')
											and sw.SupplierId = st.SupplierId
											and st.Typename='Mentor Workflow'))
			--@status = -4 All amend trade status
			or (@status = -4 and Id in (select supplierId from supplierworkflow where workflowId = (select id from workflowlist where name='Amended Trade Code')))
			--@status = -5 All active amend trade status
			or (@status = -5 and Id in (select st.supplierid from supplierstatus st, supplierworkflow sw 
											where st.status not in ('Amended Trade Code Closed','Qualified') 
											and sw.workflowId = (select id from workflowlist where name='Amended Trade Code')
											and sw.SupplierId = st.SupplierId
											and st.Typename='Amended Trade Code'))
			--@status = -6 All amend over 1MM  status
			or (@status = -6 and Id in (select supplierId from supplierworkflow where workflowId = (select id from workflowlist where name='Qualification Over 1MM')))
			--@status = -7 All active amend over 1MM status
			or (@status = -7 and Id in (select st.supplierid from supplierstatus st, supplierworkflow sw 
											where st.status not in ('Closed','Qualified') 
											and sw.workflowId = (select id from workflowlist where name='Qualification Over 1MM')
											and sw.SupplierId = st.SupplierId
											and st.Typename='Qualification Over 1MM'))
			--@status = -8 All amend key status
			or (@status = -8 and Id in (select supplierId from supplierworkflow where workflowId = (select id from workflowlist where name='Change in Application')))
			--@status = -9 All active amend key status
			or (@status = -9 and Id in (select st.supplierid from supplierstatus st, supplierworkflow sw 
											where st.status not in ('Closed','Qualified') 
											and sw.workflowId = (select id from workflowlist where name='Change in Application')
											and sw.SupplierId = st.SupplierId
											and st.Typename='Change in Application'))
			or Id in (select supplierid from supplierstatus 
				where Status = (select name from workflownode where id = @status)
				and TypeName=(select wl.Type from Workflowlist wl, workflownode wn where wn.id=@status and wn.WorkflowId=wl.id)

				) )
		and ( @supplierType = 'All' or @supplierType = '' or SupplierType = @supplierType )
		and ( @beginDate = '1/1/1900' or DateDiff(Day, @beginDate, ApplyDate) >= 0 )
		and ( @endDate = '1/1/1900' or DateDiff(Day, @endDate, ApplyDate) <= 0 )
		and ( @beginModifyDate = '1/1/1900' or DateDiff(Day, @beginModifyDate, ChangeDate) >= 0 )
		and ( @endModifyDate = '1/1/1900' or DateDiff(Day, @endModifyDate, ChangeDate) <= 0 )
		and ( @contact = '' or Id in (select v.CurrentSupplierId from VendorContact vc left join Vendor v on vc.Vendorid = v.id  where Name like '%' + @contact + '%') )
		and ( @Address = '' or Id in (Select SupplierId from SupplierAddress where AddressLine1 like '%' + @Address + '%' or AddressLine2 like '%' + @Address + '%') )
		and ( @city = '' or Id in (Select SupplierId from SupplierAddress where City like '%' + @city + '%') )
		and ( @state = '' or Id in (Select SupplierId from SupplierAddress where State like '%' + @state + '%') )
		and ( @Country = '' or Id in (Select SupplierId from SupplierAddress where Country like '%' + @Country + '%') )
		and ( @categoryId = 0 or Id in (select SupplierId from SupplierCategory where CategoryId = @categoryId) )	
		and ( @minVolume = 0 or Id in (select t.SupplierId from 
			(select SupplierId, max(year) as salesyear 
			from suppliersales group by SupplierId) t, suppliersales ss 
			where t.SupplierId = ss.SupplierId and t.salesyear = ss.year and Amount >= @minVolume) )
		and ( @maxVolume = 0 or Id in (select t.SupplierId 
										from 
											(select SupplierId, max(year) as salesyear 
											 from suppliersales group by SupplierId
											) t, suppliersales ss 
										where t.SupplierId = ss.SupplierId and t.salesyear = ss.year and Amount <= @maxVolume) 
			)
		and ( @classification = '' 
			or 
			  (@classificationOperator = 'OR' 
				and 
				Id in (Select sc.SupplierId from SupplierClassification sc, dbo.Split(@classification, ',') t 
						where PATINDEX(t.Item+'%', sc.classification)=1)
				)
			or (@classificationOperator = 'AND' 
				and 
				Id in (Select t1.SupplierId
						From (Select sc.SupplierId, count(*) As RecordCount 
								from SupplierClassification sc, dbo.Split(@classification, ',') t
								where PATINDEX(t.Item+'%', sc.classification)=1
								group by sc.SupplierId) t1, 
							 (Select count(*) As TableCount From dbo.Split(@classification, ',')) t2
						Where t1.RecordCount = t2.TableCount)
				)
			)		 

		-- Categories
		
		and ( @Categories = '' or Id in (Select SupplierId From SupplierCategory 
				where CategoryId in (Select CategoryId From @tempCategory) 
				and (@qualStatus = '' or (@qualStatus = 'Qualified' and IsApproved = 'Y')))
			 --or primaryCategoryId in (Select CategoryId From @tempCategory )
			)
		
		-- LicenseType
		and ( @LicenseType = '' 
				or Id in 
						(
							Select SupplierId 
							From License 
							where LicenseType in (Select Item From dbo.Split(@LicenseType, '^'))
						)
			)
	and	(@qualStatus = '' or Id in (select supplierid from supplierstatus where typename = 'Supplier Prequalification' and status = @qualStatus ))
		and (@certStatus = '' or Id in (select supplierid from supplierstatus where typename = 'Supplier Certification' and status = @certStatus))

		and (@mentored = '' 
				--or (@mentored = 'Y' and Id in (select supplierid from supplierstatus where typename = 'Mentor Workflow'))
				--or (@mentored = 'N' and Id not in (select supplierid from supplierstatus where typename = 'Mentor Workflow'))
				-- this is getting mentor firms list from CMS -- Venkatesh 12/26/2013
				or (@mentored = 'Y' and Id in (Select distinct a.CurrentSupplierId from vendor a inner join mv_Curr_Mentor_BidList b on a.FederalId =b.TAX_ID))
				or (@mentored = 'N' and Id not in (Select distinct a.CurrentSupplierId from vendor a inner join mv_Curr_Mentor_BidList b on a.FederalId =b.TAX_ID))
			)

		and (@financialCapacity = 0
				or Id in (
					select SupplierId
					from SupplierFinancial
					where FinancialCapacity  >= @financialCapacity
					and Type = 'PreQual'
					) 
			)
		-- Bonding Capacity
		--and (@bonding = 0
		--		or Id in (Select SupplierId From SupplierSurety Where SingleCapacity >= @bonding and IsPrimary = 'Y') )
		and ( @version = 'All' or ( @version = '' and id in (select currentsupplierid from vendor)) or ( @version = 'qualified' and id in (select QualifiedSupplierId from vendor)))
		and ( @appType = '' or SupplierType = @appType or convert(nvarchar, status) = @appType)
		and ( @primeSub = 'A' or CcrListed = @primeSub or (@primeSub = '' and CcrListed = 'Y'))
		-- Reviewer
		and ( @reviewer = '' or Id in (select supplierId from SupplierProperty 
				where (propertyId = 10 or propertyId = 524) and substring(PropertyText, 1, 50) = @reviewer ))

		-- Project Type
		
		and ( @projectType = ''
			or (@projectType != '' and FederalId in (Select TaxId From @mentor))
		
		)
		
		-- key people
		and ( @kpEnable != 'Y' or Id in (select SupplierId from @tempKeyPeople ))
		-- Work History
		and ( @whEnable != 'Y' or Id in (select SupplierId from @tempWorkHistory ))
		and ( @whEnable != 'M' or Id in (select SupplierId from SupplierProject where @whMinAmount <= ContractAmount ))	
		-- Qualification Expiration Date
		and ( @qualFrom = '1/1/1900' or Id in (select SupplierId from SupplierStaticQualification where DateDiff(Day, @qualFrom, V_SD_PREQUAL_TO) >= 0 ))
		and ( @qualTo = '1/1/1900' or Id in (select SupplierId from SupplierStaticQualification where DateDiff(Day, @qualTo, V_SD_PREQUAL_TO) <= 0 ))
		and ( (@certFrom = '1/1/1900' and @certTo = '12/31/2999') or Id in (select SupplierId from SupplierStaticCertification 
				where V_SD_EXP_DATE between @certFrom and @certTo and V_SD_EXP_DATE != '1/1/1900' ) )
		--IsPaper
		and (@isPaper = '' 
			or (@isPaper='Y' and supplierType like '%Paper%') 
			or (@isPaper='N' and supplierType in ('Supplier', 'PassThrough', 'OnlineQual', 'OnlineCert', 'OnlineQualCert' )))
		ORDER BY 
		CASE @sequence 
		WHEN 'ASC' THEN 
			CASE @orderBy 
	        		WHEN 'Company' THEN Company
	        		WHEN 'Email' THEN Email
					WHEN 'InternalVendorId' THEN InternalVendorId
					WHEN 'UserName' THEN UserName
					WHEN 'PaymentTerm' THEN PaymentTerm
					WHEN 'Reviewer' THEN ReviewerName
					WHEN 'Manager' THEN ManagerName
					WHEN 'Analyst' THEN AnalystName
					WHEN 'Status' THEN QualStatus
		ELSE ''
			END
		END ASC,
		CASE @sequence 
		WHEN 'ASC' THEN 
			CASE @orderBy 
	        		WHEN 'ApplyDate' THEN ApplyDate
					WHEN 'QualifiedTo' THEN QualifiedTo
					WHEN 'CertifiedTo' THEN CertifiedTo
			ELSE ''
			END
		END ASC,
		CASE @sequence 
		WHEN 'ASC' THEN 
			CASE @orderBy 
					--WHEN 'Status' THEN [Status]
					WHEN 'SupplierStatus' THEN [SupplierStatus]
			ELSE ''
			END
		END ASC,
		CASE @sequence	
		WHEN 'DESC' THEN 
			CASE @orderBy
	        		WHEN 'Company' THEN Company
	        		WHEN 'Email' THEN Email
					WHEN 'InternalVendorId' THEN InternalVendorId
					WHEN 'UserName' THEN UserName
					WHEN 'PaymentTerm' THEN PaymentTerm
					WHEN 'Reviewer' THEN ReviewerName
					WHEN 'Manager' THEN ManagerName
					WHEN 'Analyst' THEN AnalystName
					WHEN 'Status' THEN QualStatus
		ELSE ''
			END 
		END DESC,
		CASE @sequence 
		WHEN 'DESC' THEN 
			CASE @orderBy 
	        		WHEN 'ApplyDate' THEN ApplyDate
					WHEN 'QualifiedTo' THEN QualifiedTo
					WHEN 'CertifiedTo' THEN CertifiedTo
			ELSE ''
			END
		END DESC,
		CASE @sequence 
		WHEN 'DESC' THEN 
			CASE @orderBy 
	        		--WHEN 'Status' THEN [Status]
					WHEN 'SupplierStatus' THEN [SupplierStatus]
			ELSE ''
			END
		END DESC,
		CASE @orderBy 
				WHEN 'Random' THEN newid()
		END
		
		--select * into ##temp1 from @temp1
		
		select @totalcount = count(*) from @temp1
		
		print '@totalcount-'  + cast(@totalcount as varchar)
	
	
	
	if @orderBy='Random'  
	Begin
		
		Declare @tempmentor Table
		(
			OrderId int identity (1,1) Primary Key,
			SupplierId int,
			FederalId nvarchar(20),
			ReceivedCount int,
			SubmittedCount int,
			AwardedCount int,
			LastBidListDate DateTime,
			SortOrder int
		)
		
		declare @mentorCount int
		--If project amount is <500000
		if isnull(@ProjectAmount,500001)<500000
			
			begin
				--insert into DebugTable (spname, message) values('SearchSupplierXML','Stage1.1-' + cast(@financialCapacity as varchar))
				-- Get all Tier 1 firms
				
				insert into @tempmentor
				select 
					t.SupplierId,t.Federalid,t.ReceivedCount,t.submittedcount,t.awardedcount,t.lastBidlistdate,1
				from 
					@mentor m,@temp1 t
				where 
					m.taxid=t.federalid
					and (datediff(day,m.startdate,getdate())<=730 or m.TotalAwards<2)
					and t.supplierid not in (select supplierid from rfdsupplier where rfdprojectid=@RfdProjectId and status in (3,4,15))
					--select * into ##mentor from @mentor
				--select * into ##temp2 from @tempmentor
				select @mentorCount=count(*) from @tempmentor
				print '@mentorCount 1-'  + cast(@mentorCount as varchar)
				--insert into DebugTable (spname, message) values('SearchSupplierXML','Stage1.2-' + cast(@mentorCount as varchar))
				if @mentorcount<15
				begin
					/*		
					insert into @tempmentor
					select 
						top (@pagesize-@mentorcount) t.SupplierId,t.Federalid,t.ReceivedCount,
						t.submittedcount,m.TotalAwards,t.lastBidlistdate,2
					from	
						@mentor  m,@temp1 t
					where 
						m.taxid=t.federalid
						and datediff(day,getdate(),m.startdate)<=730
						and t.SupplierId not in (select SupplierId from @tempmentor)
					select @mentorCount=count(*) from @tempmentor
					insert into DebugTable (spname, message) values('SearchSupplierXML','Stage1.3-' + cast(@mentorCount as varchar))
					
					if @mentorcount<@pagesize
						begin
						*/
							--Get all of the mentor firms both Tier 1 and Tier 2
							
							insert into @tempmentor
							select 
								 t.SupplierId,t.Federalid,t.ReceivedCount,t.submittedcount,m.TotalAwards,t.lastBidlistdate,2
							from	
								@mentor m,@temp1 t
							where 
								m.taxid=t.federalid
								and t.SupplierId not in (select SupplierId from @tempmentor)
								and t.supplierid not in (select supplierid from rfdsupplier where rfdprojectid=@RfdProjectId and status in (3,4,15))
						--end
						select @mentorCount=count(*) from @tempmentor
						print '@mentorCount2-'  + cast(@mentorCount as varchar)
				end
				
			End
			
		else
			--Tier 2
			--insert into DebugTable (spname, message) values('SearchSupplierXML','Stage2')
			--select * into ##tempe1 from @temp1
			--select * into ##mentor from @mentor
			Begin
				
				insert into @tempmentor
				select 
					t.SupplierId,t.Federalid,t.ReceivedCount,t.submittedcount,m.TotalAwards,t.lastBidlistdate,1
				from 
					@mentor m,@temp1 t
				where 
					m.taxid=t.federalid
					and datediff(day,m.startdate,getdate())>730
					and m.TotalAwards>=2
					and t.supplierid not in (select supplierid from rfdsupplier where rfdprojectid=@RfdProjectId and status in (3,4,15))
					
				select @mentorCount=count(*) from @tempmentor
				print '@mentorCount 1-'  + cast(@mentorCount as varchar)
				--insert into DebugTable (spname, message) values('SearchSupplierXML','Stage1.4-' + cast(@mentorCount as varchar))
				if @mentorcount<15
					--Get All Tier 3/4 vendors with less than 2 awards
					Begin
						insert into @tempmentor
						select 
							 t.SupplierId,t.Federalid,t.ReceivedCount,t.submittedcount,m.TotalAwards,t.lastBidlistdate,2
						from	
							@mentor m,@temp1 t
						where 
							m.taxid=t.federalid
							and datediff(day,m.startdate,getdate())>730
							and t.SupplierId not in (select SupplierId from @tempmentor)
							
							
						select @mentorCount=count(*) from @tempmentor
						print '@mentorCount 2-'  + cast(@mentorCount as varchar)
						--insert into DebugTable (spname, message) values('SearchSupplierXML','Stage1.5-' + cast(@mentorCount as varchar))
						if @mentorcount<15
							Begin
								--Get all of the mentor firms both Tier 1 and Tier 2
								insert into @tempmentor
								select 
									t.SupplierId,t.Federalid,t.ReceivedCount,t.submittedcount,m.TotalAwards,t.lastBidlistdate,3
								from	
									@mentor m,@temp1 t
								where 
									m.taxid=t.federalid
									and t.SupplierId not in (select SupplierId from @tempmentor)
									
								select @mentorCount=count(*) from @tempmentor
								print '@mentorCount 3-'  + cast(@mentorCount as varchar)
							end
					End
			End
			--select * into ##tempmentor from @tempmentor
			
			-- In case of regeneration exclude items that are already assinged to the project as Rejected and Deleted
			--			  also retain the firms that are already assigned to the Limited List
			
			if @RfdProjectId is not null and @RfdProjectId>0
			begin
				print @RfdProjectId
				
				
				delete from @tempmentor where supplierid in (select supplierid from rfdsupplier where rfdprojectid=@RfdProjectId and status in (1,2,3,4,15)) -- Rejected/Resend and deleted firms
				 --retain the firms that are already assigned to the Limited List
				
				insert into @tempmentor
				select	
					t.SupplierId,t.Federalid,t.ReceivedCount,t.submittedcount,t.awardedcount,t.lastBidlistdate,0
				from	
					@temp1 t, rfdsupplier rs
				where	
					rs.rfdprojectid=@RfdProjectId
					and	rs.supplierid=t.supplierid
					and	rs.status in (1,2)
					and rs.supplierid not in (select supplierid from @tempmentor)
				
			end
			if exists(select * from @tempmentor)
			begin
				
				select @begincount=count(*) from @temp1
				set @endcount=@begincount+@pagesize
				Delete  from @temp1
				-- SortOrder column makes sure first already assigned items are retained and then t
				
				insert into @temp1 (SupplierId ,FederalId ,ReceivedCount ,SubmittedCount,AwardedCount ,LastBidListDate)
				select 
					SupplierId ,FederalId ,ReceivedCount ,SubmittedCount,AwardedCount ,LastBidListDate 
				from 
					@tempmentor 
				order by 
					SortOrder,LastBidListDate, newid()
					
				
			end
			
	End
	
	--select * from @temp1
	select @totalcount = count(*) from @temp1
	print '@totalcount-'  + cast(@totalcount as varchar)
	
	
	
	--insert into DebugTable (spname, message) values('SearchSupplierXML','@totalcount-'  + cast(@totalcount as varchar))
	--insert into DebugTable (spname, message) values('SearchSupplierXML','@beginCount-'  + cast(@beginCount as varchar))
	--insert into DebugTable (spname, message) values('SearchSupplierXML','@endCount-'  + cast(@endCount as varchar))
	if @pageSize > 0
		Delete from @temp1
		Where OrderId < @beginCount or OrderId > @endCount
		--select distinct supplierid,federalid,receivedcount,submittedcount,awardedcount,lastbidlistdate from @temp1 order by lastbidlistdate
		
	/*
	declare @pickup Table
	(
		C_VENDOR_ID nvarchar(20),
		RecordCount int
	)

	declare @bidder Table
	(
		C_VENDOR_ID nvarchar(20),
		RecordCount int
	)

	Insert Into @pickup
	select t.C_VENDOR_ID, count(t.N_SOLICIT_SEQ)
	From OPENQUERY(NYCSCA_CES, 'SELECT * FROM MV_VAS_PICKUP') t, @temp1 t1
	Where DateDiff(day, t.SD_TRANS_DATE, getdate()) < 365
	and t.C_VENDOR_ID = t1.FederalId
	Group By t.C_VENDOR_ID

	Update t1
	Set t1.ReceivedCount = t.RecordCount
	From @temp1 t1, @pickup t
	where t1.FederalId = t.C_VENDOR_ID

	Insert Into @bidder
	select t.C_VENDOR_ID, count(t.N_SOLICIT_SEQ)
	From OPENQUERY(NYCSCA_CES, 'SELECT * FROM MV_VAS_BIDDER') t, @temp1 t1
	Where DateDiff(day, t.SD_ACTUAL_BID_OPEN, getdate()) < 365
	and t.C_VENDOR_ID = t1.FederalId
	Group By t.C_VENDOR_ID

	Update t1
	Set t1.SubmittedCount = t.RecordCount
	From @temp1 t1, @bidder t
	where t1.FederalId = RTrim(t.C_VENDOR_ID)
	*/

	declare @temp table
	(
		C_VENDOR_ID nvarchar(20),
		TOTAL_PICKUPS int,
		TOTAL_BIDS int,
		TOTAL_AWARDS int
	)

	Insert Into @temp
	Select 
		t.C_VENDOR_ID,	
		t.TOTAL_PICKUPS,
		t.TOTAL_BIDS,
		t.TOTAL_AWARDS
	From @temp1 t1, MV_ZVAS_BIDS_PICKUPS t
	where t1.FederalId = t.C_VENDOR_ID
	
	
	
	
	

	Update t1
	Set 
		t1.ReceivedCount = t.TOTAL_PICKUPS,
		t1.SubmittedCount = t.TOTAL_BIDS,
		t1.AwardedCount = t.TOTAL_AWARDS
	From @temp t, @temp1 t1
	where t.C_VENDOR_ID = t1.FederalId


	/*******************************************/
	
			/*project Times count*/
		Select s.FederalId,Count(distinct RP.rfdprojectid) as rfdProjectidCount
		into #temp2 
		from dbo.rfdsupplier rs 
		Inner join supplier s on rs.supplierid=s.id
		Inner Join rfdproject rp on rs.rfdprojectid=rp.id 
		Inner Join vendor v on v.FederalId=s.FederalId
		Where rp.IsFinal='Y' and rp.ApprovalDate is not null
		and rs.status IN(1,2) 
		--and vetflag=1 
		--And Convert(nvarchar(20),rp.ApprovalDate,101) between convert(nchar(10),@startdate,101 ) and convert(nchar(10),@enddate,101)
		And rp.ApprovalDate >getdate()-366
		Group By s.FederalId
		order by s.FederalId


		Update t1
		Set t1.TimesCount=isnull(t2.rfdProjectidCount,0)
		From @temp1 t1,#temp2 t2
		Where  t1.FederalId = t2.FederalId 
		--and t1.supplierid=t2.supplierid


		/*Inclusion count*/

		select distinct  s.FederalId,
		Count(distinct RP.rfdprojectid) as inclusionCount,
		rs.supplierid
		into #temp3 
		From RfdProject rp
		Inner join rfdsupplier rs on rs.RfdProjectId=rp.id
		Inner join supplier s on rs.supplierid=s.id
		Inner Join WorkflowHistory wf on rs.TransactionId=wf.TransactionHeaderId
		Inner Join WorkflowNode wn on wn.Id=wf.CurrentNodeId
		where wn.[Name] = 'Included'
		and rs.status =16
		AND wf.DateCreated >= getdate()-366
		--And Convert(nvarchar(20),wf.DateCreated,101) between convert(nchar(10),@startdate,101 ) and convert(nchar(10),@enddate,101)

		Group By s.FederalId,rs.supplierid
		order by s.FederalId,rs.supplierid


		Update t1
		Set t1.InclusionCount=t2.inclusionCount
		From @temp1 t1,#temp3 t2
		Where  t1.FederalId = t2.FederalId and t1.supplierid=t2.supplierid

		Drop table #temp2
		Drop table #temp3
	
	/*******************************************/
	
	
	SELECT
		  s.Id					AS '@Id'
		, s.SupplierType		AS '@SupplierType'
		, s.Company				AS '@Company'
		, s.TradeNames			AS '@TradeNames'
		, s.Phone				AS '@Phone'
		, s.Extension			AS '@Extension'
		, s.Fax					AS '@Fax'
		, s.Email				AS '@Email'
		, s.Url					AS '@Url'
		, s.BusinessType		AS '@BusinessType'
		, s.LegalStructure		AS '@LegalStructure'
		, s.FederalId			AS '@FederalId'
		, s.YearEstablished		AS '@YearEstablished'
		, s.EmployeeTotal		AS '@EmployeeTotal'
		, s.InsuranceCarrier	AS '@InsuranceCarrier'
		, s.DbNum				AS '@DbNum'
		, s.Description			AS '@Description'
		, s.Gender				AS '@Gender'
		, s.Ethnicity			AS '@Ethnicity'
		, s.IsCertified			AS '@IsCertified'
		, s.HasOnlineCatalog	AS '@HasOnlineCatalog'
		, s.HasOnlineSell		AS '@HasOnlineSell'
		, s.HasEdiCapable		AS '@HasEdiCapable'
		, s.AcceptCreditCard	AS '@AcceptCreditCard'
		, s.CurrentSupplier		AS '@CurrentSupplier'
		, s.AnnualSales			AS '@AnnualSales'
		, s.CurrentContact		AS '@CurrentContact'
		, s.CurrentPhone		AS '@CurrentPhone'
		, s.CurrentExtension	AS '@CurrentExtension'
		, s.HasSupplierDiversityProgram	AS '@HasSupplierDiversityProgram'
		, s.IsPublicTraded			AS '@IsPublicTraded'
		, s.ApplyUser			AS '@ApplyUser'
		, s.ApplyDate			AS '@ApplyDate'
		, s.ChangeUser			AS '@ChangeUser'
		, s.ChangeDate			AS '@ChangeDate'
		, s.Status				AS '@Status'
		, s.Password			AS '@Password'
		, s.InternalVendorId	AS '@InternalVendorId'
		, s.ParentId			AS '@ParentId'
		, s.SalesTaxState		AS '@SalesTaxState'
		, s.PaymentTerm			AS '@PaymentTerm'
		, s.PaymentMethod		AS '@PaymentMethod'
		, s.DiscountTerm		AS '@DiscountTerm'
		, s.CurrentLocation		AS '@CurrentLocation'
		, s.PrimaryCategoryId	AS '@PrimaryCategoryId'
		, s.CcrListed			AS '@CcrListed'
		, s.CageCode			AS '@CageCode'
		, s.PreparerName		AS '@PreparerName'
		, s.PreparerPhone		AS '@PreparerPhone'
		, s.PreparerEmail		AS '@PreparerEmail'
		, s.StateIncorporation	AS '@StateIncorporation'
		, s.StateSalesTaxId		AS '@StateSalesTaxId'
		, s.SupplierId			AS '@SupplierId'
		, s.UserName			AS '@UserName'
		, s.SupplierStatus      AS '@SupplierStatus'

		,s.QualifiedDate as '@QualifiedFrom'
		,(select top 1 V_SD_PREQUAL_TO from SupplierStaticQualification where supplierid=s.id and V_SD_PREQUAL_TO<>'1900-01-01 00:00:00.000') as '@QualifiedTo'
		,s.CertifiedDate as '@CertifiedFrom'
		,(select top 1 V_SD_EXP_DATE from SupplierStaticCertification where supplierid=s.id and V_SD_EXP_DATE<>'1900-01-01 00:00:00.000') as '@CertifiedTo'
		,[dbo].[GetMWLBEClassifications](s.id) as '@MWLBECertInfo'
		,(select status from rfdsupplier rs where rs.RfdProjectId=@RfdProjectId and rs.supplierid=s.id) as '@RfdSupplierStatus'
		,s.LimitedListVettingDate as '@LimitedListVettingDate'
		,isnull((	select top 1 convert(varchar,isnull(FinancialCapacity,0))
				from SupplierFinancial
				where SupplierId = s.Id
				and Type = 'PreQual'
				order by Id desc ),'') 	AS '@Currency'
		, isnull((select top 1 filename from supplierdocument 
					where supplierid = s.id 
					and type = '50'	
					and attachment is not null),''
				)   AS		'@Filename'
		,convert(nvarchar(10), isnull(t.ReceivedCount,'')) + '|' +
		 convert(nvarchar(10), isnull(t.SubmittedCount,'')) + '|' +
		 convert(nvarchar(10), isnull(t.AwardedCount,'')) + '|' +
		 convert(nvarchar(10), isnull(t.TimesCount,0)) +'|'+
		 convert(nvarchar(10), isnull(t.InclusionCount,0))
		 As '@Result'
		, @totalcount			AS '@TotalRecordNumber'
		,(
			SELECT 
					sc.SupplierId			as '@SupplierId',
					sc.CategoryId 			as '@CategoryId',
					c.Name					as '@CategoryName',
					sc.IsApproved			as '@IsApproved',
					sc.Average				as '@Average',
					sc.ApprovedAverage		as '@ApprovedAverage',
					(
						Select	c.Id	As '@Id',
								c.Name	As '@Name',
								c.Code	As '@Code'
						From Category c
						Where c.Id = sc.CategoryId
						For XML PATH('Category'), TYPE
					)
			FROM SupplierCategory sc, Category c
			where sc.SupplierId = s.id
			and sc.CategoryId = c.Id
			Order By c.Code
			 FOR XML PATH('SupplierCategory'), ROOT('ArrayOfSupplierCategory'), TYPE
		),
		(
			select
				ss.SupplierId		As '@SupplierId',
				ss.TypeName		As '@TypeName',
				ss.Status		As '@Status'
			from SupplierStatus ss
			where s.Id = ss.SupplierId
			FOR XML PATH('SupplierStatus'), ROOT('ArrayOfSupplierStatus'), TYPE
		),
		(
			SELECT	
				pa.Id AS '@Id',
				pa.SupplierId AS '@SupplierId',
				pa.FromSupplier AS '@FromSupplier',
				pa.AddressType AS '@AddressType',
				pa.AddressLine1 AS '@AddressLine1',
				pa.AddressLine2 AS '@AddressLine2',
				pa.City AS '@City',
				pa.State AS '@State',
				pa.ZipCode AS '@ZipCode',
				pa.Country AS '@Country',
				pa.County AS '@County'
			FROM SupplierAddress pa
			WHERE pa.SupplierId = s.id and pa.AddressType = 'PHYSICAL'
			FOR XML PATH('PhysicalAddress'), TYPE
		),
		
		(
			SELECT	
				top 1
				vc.Id				as '@Id',
				vc.VendorId			as '@VendorId',
				vc.ContactType		as '@ContactType',
				vc.FromVendor		as '@FromVendor',
				vc.Department		as '@Department',
				vc.Name				as '@Name',
				vc.Title			as '@Title',
				vc.Phone			as '@Phone',
				vc.Extension		as '@Extension',
				vc.Fax				as '@Fax',
				vc.Email			as '@Email',
				vc.UserName			as '@UserName',
				vc.Password			as '@Password',
				vc.Status			as '@Status',
				v.Company			as '@Company',
				vc.FirstName		as '@FirstName',
				vc.LastName			as '@LastName',
				vc.ContactId		as '@ContactId'
			FROM VendorContact vc, Vendor v
			WHERE vc.vendorId = v.id and v.federalId = s.federalid and vc.ContactType='Primary'
			FOR XML PATH('PrimaryContact'), TYPE
		)
		,
		(
			select
				w.Id		As '@Id',
				w.SupplierId		As '@SupplierId',
				w.WorkflowId		As '@WorkflowId',
				w.TransactionId		As '@TransactionId',
				w.WorkflowType		As '@WorkflowType',
				w.BusinessUnitId		As '@BusinessUnitId'
			from SupplierWorkflow w
			where s.Id = w.SupplierId
			FOR XML PATH('SupplierWorkflow'), ROOT('ArrayOfSupplierWorkflow'), TYPE
		)
	FROM @temp1 t, Supplier s 
	where t.supplierId = s.Id
	order by t.OrderId
	FOR XML PATH('Supplier'), ROOT('ArrayOfSupplier')
end
--************************************************* Site=ExternalDisqualified *************************************************************
else if (@site='ExternalDisqualified')
begin 
	Declare @temp11 Table
	(
			OrderId int identity (1,1) Primary Key,
			SupplierId int
	)
	insert into @temp11(Supplierid)
	select v.currentsupplierid
	from vendor v
	where v.QualificationStatus in ('Disqualified', 'Suspended')
	and (@company='' or v.company like '%'+@company+'%')
	Order by
		CASE @sequence 
		WHEN 'ASC' THEN 
			CASE @orderBy 
	        		WHEN 'Company' THEN Company
			ELSE ''
				END
		END ASC,
		CASE @sequence 
		WHEN 'DESC' THEN 
			CASE @orderBy 
	        		WHEN 'Company' THEN Company
			ELSE ''
				END
		END DESC


	select @totalcount = count(*) from @temp11
		if @pageSize > 0
			Delete from @temp11
			Where OrderId < @beginCount or OrderId > @endCount

	SELECT
			  s.Id					AS '@Id'
			, s.SupplierType		AS '@SupplierType'
			, s.Company				AS '@Company'
			, s.TradeNames			AS '@TradeNames'
			, s.Phone				AS '@Phone'
			, s.Extension			AS '@Extension'
			, s.Fax					AS '@Fax'
			, s.Email				AS '@Email'
			, s.Url					AS '@Url'
			, s.BusinessType		AS '@BusinessType'
			, s.LegalStructure		AS '@LegalStructure'
			, s.FederalId			AS '@FederalId'
			, s.YearEstablished		AS '@YearEstablished'
			, s.EmployeeTotal		AS '@EmployeeTotal'
			, s.InsuranceCarrier	AS '@InsuranceCarrier'
			, s.DbNum				AS '@DbNum'
			, s.Description			AS '@Description'
			, s.Gender				AS '@Gender'
			, s.Ethnicity			AS '@Ethnicity'
			, s.IsCertified			AS '@IsCertified'
			, s.HasOnlineCatalog	AS '@HasOnlineCatalog'
			, s.HasOnlineSell		AS '@HasOnlineSell'
			, s.HasEdiCapable		AS '@HasEdiCapable'
			, s.AcceptCreditCard	AS '@AcceptCreditCard'
			, s.CurrentSupplier		AS '@CurrentSupplier'
			, s.AnnualSales			AS '@AnnualSales'
			, s.CurrentContact		AS '@CurrentContact'
			, s.CurrentPhone		AS '@CurrentPhone'
			, s.CurrentExtension	AS '@CurrentExtension'
			, s.HasSupplierDiversityProgram	AS '@HasSupplierDiversityProgram'
			, s.IsPublicTraded			AS '@IsPublicTraded'
			, s.ApplyUser			AS '@ApplyUser'
			, s.ApplyDate			AS '@ApplyDate'
			, s.ChangeUser			AS '@ChangeUser'
			, s.ChangeDate			AS '@ChangeDate'
			, s.Status				AS '@Status'
			, s.Password			AS '@Password'
			, s.InternalVendorId	AS '@InternalVendorId'
			, s.ParentId			AS '@ParentId'
			, s.SalesTaxState		AS '@SalesTaxState'
			, s.PaymentTerm			AS '@PaymentTerm'
			, s.PaymentMethod		AS '@PaymentMethod'
			, s.Currency			AS '@Currency'
			, s.DiscountTerm		AS '@DiscountTerm'
			, s.CurrentLocation		AS '@CurrentLocation'
			, s.PrimaryCategoryId	AS '@PrimaryCategoryId'
			, s.CcrListed			AS '@CcrListed'
			, s.CageCode			AS '@CageCode'
			, s.PreparerName		AS '@PreparerName'
			, s.PreparerPhone		AS '@PreparerPhone'
			, s.PreparerEmail		AS '@PreparerEmail'
			, s.StateIncorporation	AS '@StateIncorporation'
			, s.StateSalesTaxId		AS '@StateSalesTaxId'
			, s.SupplierId			AS '@SupplierId'
			, s.UserName			AS '@UserName'
			, s.SupplierStatus      AS '@SupplierStatus'
			, @totalcount			AS '@TotalRecordNumber'
			,(
				select
					ss.SupplierId		As '@SupplierId',
					ss.TypeName		As '@TypeName',
					ss.Status		As '@Status'
				from SupplierStatus ss
				where s.Id = ss.SupplierId
				FOR XML PATH('SupplierStatus'), ROOT('ArrayOfSupplierStatus'), TYPE
			),
			(
			SELECT	
				top 1
				vc.Id				as '@Id',
				vc.VendorId			as '@VendorId',
				vc.ContactType		as '@ContactType',
				vc.FromVendor		as '@FromVendor',
				vc.Department		as '@Department',
				vc.Name				as '@Name',
				vc.Title			as '@Title',
				vc.Phone			as '@Phone',
				vc.Extension		as '@Extension',
				vc.Fax				as '@Fax',
				vc.Email			as '@Email',
				vc.UserName			as '@UserName',
				vc.Password			as '@Password',
				vc.Status			as '@Status',
				v.Company			as '@Company',
				vc.FirstName		as '@FirstName',
				vc.LastName			as '@LastName',
				vc.ContactId		as '@ContactId'
			FROM VendorContact vc, Vendor v
			WHERE vc.vendorId = v.id and v.federalId = s.federalid and vc.ContactType='Primary'
			FOR XML PATH('PrimaryContact'), TYPE
		)
		,
			(
				SELECT	
					pa.Id AS '@Id',
					pa.SupplierId AS '@SupplierId',
					pa.FromSupplier AS '@FromSupplier',
					pa.AddressType AS '@AddressType',
					pa.AddressLine1 AS '@AddressLine1',
					pa.AddressLine2 AS '@AddressLine2',
					pa.City AS '@City',
					pa.State AS '@State',
					pa.ZipCode AS '@ZipCode',
					pa.Country AS '@Country',
					pa.County AS '@County'
				FROM SupplierAddress pa
				WHERE pa.SupplierId = s.id and pa.AddressType = 'PHYSICAL'
				FOR XML PATH('PhysicalAddress'), TYPE
			)
		FROM @temp11 t, Supplier s 
		where t.supplierId = s.Id
		order by t.OrderId
		FOR XML PATH('Supplier'), ROOT('ArrayOfSupplier')
end
--************************************************* Site=ExternalQualified *************************************************************
else if (@site in ('ExternalQualified'))
begin

	Declare @tempQual Table
	(
			OrderId int identity (1,1) Primary Key,
			SupplierId int
	)
	insert into @tempQual(Supplierid)
	select v.QualifiedSupplierId
	from vendor v
		left join supplier s on s.Id = v.QualifiedSupplierId
	where v.FederalId in (
					select federalid from supplier
					where id in (select supplierid from supplierstatus where typename = 'Supplier Prequalification' and status = 'qualified'  )
					and id in (select QualifiedSupplierId from vendor)
				)
	and (@company='' or v.company like '%'+@company+'%')
	and (@phone='' or v.QualifiedSupplierId in (select v.QualifiedSupplierId from VendorContact vc left join Vendor v on vc.Vendorid = v.id  where Phone like '%' + @Phone + '%') )
	and (@state='' OR v.QualifiedSupplierId in (select supplierid from supplieraddress where State like '%' + @state + '%') )
	and ( @Categories = '' 
		or 
		  (@CategoriesOperator = 'OR' 
			and 
			v.QualifiedSupplierId in	(Select SupplierId From SupplierCategory where IsApproved = 'Y' and CategoryId in (Select CategoryId From @tempCategory union Select ParentId From @tempCategory)
									 )
			)
		or (@CategoriesOperator = 'AND' 
			and 
			v.QualifiedSupplierId in (Select t1.SupplierId
										From (Select sc.SupplierId, count(*) As RecordCount 
												from SupplierCategory sc, @tempCategory t
												where (sc.CategoryId = t.CategoryId or sc.CategoryId = t.ParentId)
												and sc.IsApproved = 'Y'
												group by sc.SupplierId) t1, 
											 (Select count(*) As TableCount From @tempCategory) t2 Where t1.RecordCount = t2.TableCount)
			)
		)
			
			
	and (@Over1M='' or v.QualifiedSupplierId in (select SupplierId from SupplierCategory where ApprovedAverage = @Over1M and IsApproved='Y') )	
	and (@MWLBECertified='' or (@MWLBECertified='Y' and v.QualifiedSupplierId in (select supplierid from supplierstaticcertification where V_c_dw_code in ('Y', 'R')))
							or (@MWLBECertified='N' and v.QualifiedSupplierId not in (select supplierid from supplierstaticcertification where V_c_dw_code in ('Y', 'R')))
		)
	and (@Qualified=''
			or (@Qualified='Y' and v.QualifiedSupplierId in (select SupplierId from SupplierStatus where status =  'qualified' and typename='Supplier Prequalification'))
			or (@Qualified='N' and v.QualifiedSupplierId not in (select SupplierId from SupplierStatus where status =  'qualified' and typename='Supplier Prequalification') )
		)
	Order by
		CASE @sequence 
		WHEN 'ASC' THEN 
			CASE @orderBy 
	        		WHEN 'Company' THEN s.Company
			ELSE ''
				END
		END ASC,
		CASE @sequence 
		WHEN 'DESC' THEN 
			CASE @orderBy 
	        		WHEN 'Company' THEN s.Company
			ELSE ''
				END
		END DESC

select @totalcount = count(*) from @tempQual
		if @pageSize > 0
			Delete from @tempQual
			Where OrderId < @beginCount or OrderId > @endCount

	SELECT
			  s.Id					AS '@Id'
			, s.SupplierType		AS '@SupplierType'
			, s.Company				AS '@Company'
			, s.TradeNames			AS '@TradeNames'
			, s.Phone				AS '@Phone'
			, s.Extension			AS '@Extension'
			, s.Fax					AS '@Fax'
			, s.Email				AS '@Email'
			, s.Url					AS '@Url'
			, s.BusinessType		AS '@BusinessType'
			, s.LegalStructure		AS '@LegalStructure'
			, s.FederalId			AS '@FederalId'
			, s.YearEstablished		AS '@YearEstablished'
			, s.EmployeeTotal		AS '@EmployeeTotal'
			, s.InsuranceCarrier	AS '@InsuranceCarrier'
			, s.DbNum				AS '@DbNum'
			, s.Description			AS '@Description'
			, s.Gender				AS '@Gender'
			, s.Ethnicity			AS '@Ethnicity'
			, s.IsCertified			AS '@IsCertified'
			, s.HasOnlineCatalog	AS '@HasOnlineCatalog'
			, s.HasOnlineSell		AS '@HasOnlineSell'
			, s.HasEdiCapable		AS '@HasEdiCapable'
			, s.AcceptCreditCard	AS '@AcceptCreditCard'
			, s.CurrentSupplier		AS '@CurrentSupplier'
			, s.AnnualSales			AS '@AnnualSales'
			, s.CurrentContact		AS '@CurrentContact'
			, s.CurrentPhone		AS '@CurrentPhone'
			, s.CurrentExtension	AS '@CurrentExtension'
			, s.HasSupplierDiversityProgram	AS '@HasSupplierDiversityProgram'
			, s.IsPublicTraded			AS '@IsPublicTraded'
			, s.ApplyUser			AS '@ApplyUser'
			, s.ApplyDate			AS '@ApplyDate'
			, s.ChangeUser			AS '@ChangeUser'
			, s.ChangeDate			AS '@ChangeDate'
			, s.Status				AS '@Status'
			, s.Password			AS '@Password'
			, s.InternalVendorId	AS '@InternalVendorId'
			, s.ParentId			AS '@ParentId'
			, s.SalesTaxState		AS '@SalesTaxState'
			, s.PaymentTerm			AS '@PaymentTerm'
			, s.PaymentMethod		AS '@PaymentMethod'
			, s.Currency			AS '@Currency'
			, s.DiscountTerm		AS '@DiscountTerm'
			, s.CurrentLocation		AS '@CurrentLocation'
			, s.PrimaryCategoryId	AS '@PrimaryCategoryId'
			, s.CcrListed			AS '@CcrListed'
			, s.CageCode			AS '@CageCode'
			, s.PreparerName		AS '@PreparerName'
			, s.PreparerPhone		AS '@PreparerPhone'
			, s.PreparerEmail		AS '@PreparerEmail'
			, s.StateIncorporation	AS '@StateIncorporation'
			, s.StateSalesTaxId		AS '@StateSalesTaxId'
			, s.SupplierId			AS '@SupplierId'
			, s.UserName			AS '@UserName'
			, s.SupplierStatus      AS '@SupplierStatus'
			, isnull((select top 1 filename from supplierdocument 
						where supplierid = s.id 
						and type = '50'	
						and attachment is not null),''
					)   AS		'@Filename'
			, @totalcount			AS '@TotalRecordNumber'
			,(
				SELECT 
						sc.SupplierId			as '@SupplierId',
						sc.CategoryId 			as '@CategoryId',
						c.Name					as '@CategoryName',
						sc.IsApproved			as '@IsApproved',
						sc.Average				as '@Average',
						sc.ApprovedAverage		as '@ApprovedAverage',
						(
							Select	c.Id	As '@Id',
									c.Name	As '@Name',
									c.Code	As '@Code'
							From Category c
							Where c.Id = sc.CategoryId
							For XML PATH('Category'), TYPE
						)
				FROM SupplierCategory sc, Category c
				where sc.SupplierId = t.supplierid
				and sc.CategoryId = c.Id
				Order By c.Code
				 FOR XML PATH('SupplierCategory'), ROOT('ArrayOfSupplierCategory'), TYPE
			)
			,(
				select
					ss.SupplierId		As '@SupplierId',
					ss.TypeName		As '@TypeName',
					ss.Status		As '@Status'
				from SupplierStatus ss
				where s.Id = ss.SupplierId
				FOR XML PATH('SupplierStatus'), ROOT('ArrayOfSupplierStatus'), TYPE
			),
			(
				SELECT	
					pa.Id AS '@Id',
					pa.SupplierId AS '@SupplierId',
					pa.FromSupplier AS '@FromSupplier',
					pa.AddressType AS '@AddressType',
					pa.AddressLine1 AS '@AddressLine1',
					pa.AddressLine2 AS '@AddressLine2',
					pa.City AS '@City',
					pa.State AS '@State',
					pa.ZipCode AS '@ZipCode',
					pa.Country AS '@Country',
					pa.County AS '@County'
				FROM SupplierAddress pa
				WHERE pa.SupplierId = s.id and pa.AddressType = 'PHYSICAL'
				FOR XML PATH('PhysicalAddress'), TYPE
			),
			(
				select vt.Id As '@Id',
						v.QualifiedSupplierId as '@SupplierId',
						vt.contactType AS '@ContactType',
						vt.Name as '@Name',
						vt.Phone as '@Phone'
				from vendorcontact vt,vendor v
				where vt.vendorid=v.id and v.QualifiedSupplierId=t.supplierid and contactType='Primary'
				FOR XML PATH('SupplierContact'), ROOT('ArrayOfSupplierContact'), TYPE
			),
			(
				select Id as '@Id',
						Supplierid as '@SupplierId',
						V_c_eeo_type as '@CertificationType',
						V_sd_exp_date as '@ExpirationDate'
				from dbo.SupplierStaticCertification
				where supplierid=t.supplierid 
				FOR XML PATH('Certification'), ROOT('ArrayOfCertification'), TYPE
			),
			(
			SELECT	
				top 1
				vc.Id				as '@Id',
				vc.VendorId			as '@VendorId',
				vc.ContactType		as '@ContactType',
				vc.FromVendor		as '@FromVendor',
				vc.Department		as '@Department',
				vc.Name				as '@Name',
				vc.Title			as '@Title',
				vc.Phone			as '@Phone',
				vc.Extension		as '@Extension',
				vc.Fax				as '@Fax',
				vc.Email			as '@Email',
				vc.UserName			as '@UserName',
				vc.Password			as '@Password',
				vc.Status			as '@Status',
				v.Company			as '@Company',
				vc.FirstName		as '@FirstName',
				vc.LastName			as '@LastName',
				vc.ContactId		as '@ContactId'
			FROM VendorContact vc, Vendor v
			WHERE vc.vendorId = v.id and v.federalId = s.federalid and vc.ContactType='Primary'
			FOR XML PATH('PrimaryContact'), TYPE
		)
		,
			(
				select * from
				(
					select id as '@Id',
							supplierid as '@SupplierId',
							V_SD_PREQUAL_TO	as '@ExpirationDate'
							
					from dbo.SupplierStaticQualification
					where supplierid=t.supplierid
					and @site = 'ExternalQualified'
						union
					select id as '@Id',
							supplierid as '@SupplierId',
							V_sd_exp_date	as '@ExpirationDate'
							
					from dbo.SupplierStaticCertification
					where supplierid=t.supplierid
					and @site = 'ExternalCertified'
				) x
				FOR XML PATH('SupplierQuality'), ROOT('ArrayOfSupplierQuality'), TYPE
			)
		FROM @tempQual t, Supplier s 
		where t.supplierId = s.Id
		order by t.OrderId
		FOR XML PATH('Supplier'), ROOT('ArrayOfSupplier')

end
--************************************************* Site=ExternalQualified *************************************************************
-- PS 12/2/2013. External Vendor Search is changed to combine bothe Qualified and Certified Firms- So modified the below query
else if (@site in ('ExternalCertified'))
begin
	-- Qual companies
	Declare @tempQual1 Table
	(
			OrderId int identity (1,1) Primary Key,
			SupplierId int
	)
	
	insert into @tempQual1(Supplierid)
	select v.QualifiedSupplierId
	from vendor v
		left join supplier s on s.Id = v.QualifiedSupplierId
	where v.FederalId in (
					select federalid from supplier
					where id in (select supplierid from supplierstatus where typename = 'Supplier Prequalification' and status = 'qualified'  )
					and id in (select QualifiedSupplierId from vendor)
				)
	and (@company='' or v.company like '%'+@company+'%')
	--and (@SCity='' or v.QualifiedSupplierId in (select v.QualifiedSupplierId from VendorContact vc left join Vendor v on vc.Vendorid = v.id  where Phone like '%' + @Phone + '%') )
	and (@SCity='' or v.QualifiedSupplierId in (select distinct supplierid from supplieraddress where City like '%' + @scity + '%' and addressType='Physical'))
	and (@state='' OR v.QualifiedSupplierId in (select distinct supplierid from supplieraddress where State like '%' + @state + '%' and addressType='Physical') )
	and (@IsWicks='0' or v.qualifiedSupplierId in (	select 
													distinct sc.supplierId
												from 
													SupplierCategory sc
													inner join Category c on sc.categoryId = c.Id
												where IsApproved = 'Y'
												and 	(
													(@wicks = '' and (c.code like '15%' or c.Code like '16%'))
													 or
													(@wicks = 'Plumbing' and c.Code like '15%') -- PLUMBING get all trade codes 15000 to 16000
													 or
													(@wicks = 'HVAC' and  c.Code like '15%') -- HVAC get all trade codes 15000 to 16000
													 or
													(@wicks = 'Electrical' and c.Code like '16%') -- ELECTRICAL, Exclude lighting
												  )
												  )
												  )
								
	and ( @Categories = '' 
		or 
		  (@CategoriesOperator = 'OR' 
			and 
			v.QualifiedSupplierId in	(Select SupplierId From SupplierCategory where IsApproved = 'Y' and CategoryId in (Select CategoryId From @tempCategory union Select ParentId From @tempCategory)
									 )
			)
		or (@CategoriesOperator = 'AND' 
			and 
			v.QualifiedSupplierId in (Select t1.SupplierId
										From (Select sc.SupplierId, count(*) As RecordCount 
												from SupplierCategory sc, @tempCategory t
												where (sc.CategoryId = t.CategoryId or sc.CategoryId = t.ParentId)
												and sc.IsApproved = 'Y'
												group by sc.SupplierId) t1, 
											 (Select count(*) As TableCount From @tempCategory) t2 Where t1.RecordCount = t2.TableCount)
			)
		)
			
			
	and (@Over1M='' or v.QualifiedSupplierId in (select SupplierId from SupplierCategory where ApprovedAverage = @Over1M and IsApproved='Y') )	
	and (@MWLBECertified='' or (@MWLBECertified='Y' and v.QualifiedSupplierId in (select supplierid from supplierstaticcertification where V_c_dw_code in ('Y', 'R')))
							or (@MWLBECertified='N' and v.QualifiedSupplierId not in (select supplierid from supplierstaticcertification where V_c_dw_code in ('Y', 'R')))
		)
	and (@Qualified=''
			or (@Qualified='Y' and v.QualifiedSupplierId in (select SupplierId from SupplierStatus where status =  'qualified' and typename='Supplier Prequalification'))
			or (@Qualified='N' and v.QualifiedSupplierId not in (select SupplierId from SupplierStatus where status =  'qualified' and typename='Supplier Prequalification') )
		)
	Order by
		CASE @sequence 
		WHEN 'ASC' THEN 
			CASE @orderBy 
	        		WHEN 'Company' THEN s.Company
			ELSE ''
				END
		END ASC,
		CASE @sequence 
		WHEN 'DESC' THEN 
			CASE @orderBy 
	        		WHEN 'Company' THEN s.Company
			ELSE ''
				END
		END DESC
		
	-- *****************************************************************  End of qual vendors
	--******************************************************************* Cert companies
	
	Declare @tempCert Table
	(
			OrderId int identity (1,1) Primary Key,
			SupplierId int
	)
	
	insert into @tempCert(Supplierid)
	select v.CertifiedSupplierId
	from vendor v
		left join supplier s on s.Id = v.CertifiedSupplierId
	where v.FederalId in (
					select federalid from supplier
					where id in (select supplierid from supplierstatus where typename = 'Supplier Certification' and status = 'Certified' )
					--and id not in (select supplierid from supplierstatus where typename = 'Supplier Prequalification')
					and id not in (select supplierid from supplierstaticqualification where V_SD_PREQUAL_TO<>'1900-01-01 00:00:00.000')
					and id not in (select supplierid from supplierstaticcertification where V_sd_exp_date<getdate())
					and id in (select CertifiedSupplierId from vendor)
					
				)
	and (@company='' or v.company like '%'+@company+'%')
	--12/3/2013
	-- Instead of Phone, use City
	--and (@phone='' or v.CertifiedSupplierId in (select v.CertifiedSupplierId from VendorContact vc left join Vendor v on vc.Vendorid = v.id  where Phone like '%' + @Phone + '%') )
	and (@SCity='' or v.CertifiedSupplierId in (select supplierid from supplieraddress where City like '%' + @scity + '%'))
	and (@state='' OR v.CertifiedSupplierId in (select supplierid from supplieraddress where State like '%' + @state + '%'))
	
	and (@IsWicks='0' or v.CertifiedSupplierId in (	select 
													distinct sc.supplierId
												from 
													SupplierCategory sc
													inner join Category c on sc.categoryId = c.Id
												where IsApproved = 'Y'
												and 	(
													(@wicks = '' and (c.code like '15%' or c.Code like '16%'))
													 or
													(@wicks = 'Plumbing' and c.Code like '15%') -- PLUMBING get all trade codes 15000 to 16000
													 or
													(@wicks = 'HVAC' and  c.Code like '15%') -- HVAC get all trade codes 15000 to 16000
													 or
													(@wicks = 'Electrical' and c.Code like '16%') -- ELECTRICAL, Exclude lighting
												  )
												  )
												  
								)
	
	and ( @Categories = '' 
		or 
		  (@CategoriesOperator = 'OR' 
			and v.CertifiedSupplierId in	(Select SupplierId From SupplierCategory where IsApproved = 'Y' and CategoryId in (Select CategoryId From @tempCategory union Select ParentId From @tempCategory))
			)
		or (@CategoriesOperator = 'AND' 
			and 
			v.CertifiedSupplierId in (Select t1.SupplierId
										From (Select sc.SupplierId, count(*) As RecordCount 
												from SupplierCategory sc, @tempCategory t
												where (sc.CategoryId = t.CategoryId or sc.CategoryId = t.ParentId)
												and sc.IsApproved = 'Y'
												group by sc.SupplierId) t1, 
											 (Select count(*) As TableCount From @tempCategory) t2 Where t1.RecordCount = t2.TableCount)
			)
			
		)
			
			
	and (@Over1M='' or v.certifiedSupplierId in (select SupplierId from SupplierCategory where ApprovedAverage = @Over1M and IsApproved='Y')  
						 
		 )	
	and (@MWLBECertified='' or (@MWLBECertified='Y' and v.certifiedSupplierId in (select supplierid from supplierstaticcertification where V_c_dw_code in ('Y', 'R')))
							or (@MWLBECertified='N' and v.certifiedSupplierId not in (select supplierid from supplierstaticcertification where V_c_dw_code in ('Y', 'R')))
		)
	and (@Qualified=''
			or (@Qualified='Y' and v.qualifiedSupplierId in (select SupplierId from SupplierStatus where status =  'qualified' and typename='Supplier Prequalification'))
			or (@Qualified='N' and v.qualifiedSupplierId is null ) -- PS 12/26/2013
		)
	Order by
		CASE @sequence 
		WHEN 'ASC' THEN 
			CASE @orderBy 
	        		WHEN 'Company' THEN s.Company
			ELSE ''
				END
		END ASC,
		CASE @sequence 
		WHEN 'DESC' THEN 
			CASE @orderBy 
	        		WHEN 'Company' THEN s.Company
			ELSE ''
				END
		END DESC


insert into @tempCert select supplierid from @tempQual1

select @totalcount = count(*) from @tempCert
		if @pageSize > 0
			Delete from @tempCert
			Where OrderId < @beginCount or OrderId > @endCount

	SELECT
			  s.Id					AS '@Id'
			, s.SupplierType		AS '@SupplierType'
			, s.Company				AS '@Company'
			, s.TradeNames			AS '@TradeNames'
			, s.Phone				AS '@Phone'
			, s.Extension			AS '@Extension'
			, s.Fax					AS '@Fax'
			, s.Email				AS '@Email'
			, s.Url					AS '@Url'
			, s.BusinessType		AS '@BusinessType'
			, s.LegalStructure		AS '@LegalStructure'
			, s.FederalId			AS '@FederalId'
			, s.YearEstablished		AS '@YearEstablished'
			, s.EmployeeTotal		AS '@EmployeeTotal'
			, s.InsuranceCarrier	AS '@InsuranceCarrier'
			, s.DbNum				AS '@DbNum'
			, s.Description			AS '@Description'
			, s.Gender				AS '@Gender'
			, s.Ethnicity			AS '@Ethnicity'
			, s.IsCertified			AS '@IsCertified'
			, s.HasOnlineCatalog	AS '@HasOnlineCatalog'
			, s.HasOnlineSell		AS '@HasOnlineSell'
			, s.HasEdiCapable		AS '@HasEdiCapable'
			, s.AcceptCreditCard	AS '@AcceptCreditCard'
			, s.CurrentSupplier		AS '@CurrentSupplier'
			, s.AnnualSales			AS '@AnnualSales'
			, s.CurrentContact		AS '@CurrentContact'
			, s.CurrentPhone		AS '@CurrentPhone'
			, s.CurrentExtension	AS '@CurrentExtension'
			, s.HasSupplierDiversityProgram	AS '@HasSupplierDiversityProgram'
			, s.IsPublicTraded			AS '@IsPublicTraded'
			, s.ApplyUser			AS '@ApplyUser'
			, s.ApplyDate			AS '@ApplyDate'
			, s.ChangeUser			AS '@ChangeUser'
			, s.ChangeDate			AS '@ChangeDate'
			, s.Status				AS '@Status'
			, s.Password			AS '@Password'
			, s.InternalVendorId	AS '@InternalVendorId'
			, s.ParentId			AS '@ParentId'
			, s.SalesTaxState		AS '@SalesTaxState'
			, s.PaymentTerm			AS '@PaymentTerm'
			, s.PaymentMethod		AS '@PaymentMethod'
			, s.Currency			AS '@Currency'
			, s.DiscountTerm		AS '@DiscountTerm'
			, s.CurrentLocation		AS '@CurrentLocation'
			, s.PrimaryCategoryId	AS '@PrimaryCategoryId'
			, s.CcrListed			AS '@CcrListed'
			, s.CageCode			AS '@CageCode'
			, s.PreparerName		AS '@PreparerName'
			, s.PreparerPhone		AS '@PreparerPhone'
			, s.PreparerEmail		AS '@PreparerEmail'
			, s.StateIncorporation	AS '@StateIncorporation'
			, s.StateSalesTaxId		AS '@StateSalesTaxId'
			, s.SupplierId			AS '@SupplierId'
			, s.UserName			AS '@UserName'
			, s.SupplierStatus      AS '@SupplierStatus'
			,s.QualifiedDate as '@QualifiedFrom'
			,(select top 1 V_SD_PREQUAL_TO from SupplierStaticQualification where supplierid=s.id and V_SD_PREQUAL_TO<>'1900-01-01 00:00:00.000') as '@QualifiedTo'
			,s.CertifiedDate as '@CertifiedFrom'
			,(select top 1 V_SD_EXP_DATE from SupplierStaticCertification where supplierid=s.id and V_SD_EXP_DATE<>'1900-01-01 00:00:00.000') as '@CertifiedTo'
			,[dbo].[GetMWLBEClassifications](s.id) as '@MWLBECertInfo'
			, isnull((select top 1 filename from supplierdocument 
						where supplierid = s.id 
						and type = '50'	
						and attachment is not null),''
					)   AS		'@Filename'
--			,convert(nvarchar(10), t.ReceivedCount) + '|' +
--			 convert(nvarchar(10), t.SubmittedCount) + '|' +
--			 convert(nvarchar(10), t.AwardedCount) As '@Result'
			, @totalcount			AS '@TotalRecordNumber'
			,(
				SELECT 
						sc.SupplierId			as '@SupplierId',
						sc.CategoryId 			as '@CategoryId',
						c.Name					as '@CategoryName',
						sc.IsApproved			as '@IsApproved',
						sc.Average				as '@Average',
						sc.ApprovedAverage		as '@ApprovedAverage',
						(
							Select	c.Id	As '@Id',
									c.Name	As '@Name',
									c.Code	As '@Code'
							From Category c
							Where c.Id = sc.CategoryId
							For XML PATH('Category'), TYPE
						)
				FROM SupplierCategory sc, Category c
				where sc.SupplierId = t.supplierid
				and sc.CategoryId = c.Id
				Order By c.Code
				 FOR XML PATH('SupplierCategory'), ROOT('ArrayOfSupplierCategory'), TYPE
			)
			,(
				select
					ss.SupplierId		As '@SupplierId',
					ss.TypeName		As '@TypeName',
					ss.Status		As '@Status'
				from SupplierStatus ss
				where s.Id = ss.SupplierId
				FOR XML PATH('SupplierStatus'), ROOT('ArrayOfSupplierStatus'), TYPE
			),
			(
				SELECT	
					pa.Id AS '@Id',
					pa.SupplierId AS '@SupplierId',
					pa.FromSupplier AS '@FromSupplier',
					pa.AddressType AS '@AddressType',
					pa.AddressLine1 AS '@AddressLine1',
					pa.AddressLine2 AS '@AddressLine2',
					pa.City AS '@City',
					pa.State AS '@State',
					pa.ZipCode AS '@ZipCode',
					pa.Country AS '@Country',
					pa.County AS '@County'
				FROM SupplierAddress pa
				WHERE pa.SupplierId = s.id and pa.AddressType = 'PHYSICAL'
				FOR XML PATH('PhysicalAddress'), TYPE
			),
			(
				select vt.Id As '@Id',
						v.currentsupplierid as '@SupplierId',
						vt.contactType AS '@ContactType',
						vt.Name as '@Name',
						vt.Phone as '@Phone'
				from vendorcontact vt,vendor v
				where vt.vendorid=v.id and v.qualifiedsupplierid=t.supplierid and contactType='Primary'
				FOR XML PATH('SupplierContact'), ROOT('ArrayOfSupplierContact'), TYPE
			),
			(
				select Id as '@Id',
						Supplierid as '@SupplierId',
						V_c_eeo_type as '@CertificationType',
						V_sd_exp_date as '@ExpirationDate'
				from dbo.SupplierStaticCertification
				where supplierid=t.supplierid 
				FOR XML PATH('Certification'), ROOT('ArrayOfCertification'), TYPE
			),
			(
			SELECT	
				top 1
				vc.Id				as '@Id',
				vc.VendorId			as '@VendorId',
				vc.ContactType		as '@ContactType',
				vc.FromVendor		as '@FromVendor',
				vc.Department		as '@Department',
				vc.Name				as '@Name',
				vc.Title			as '@Title',
				vc.Phone			as '@Phone',
				vc.Extension		as '@Extension',
				vc.Fax				as '@Fax',
				vc.Email			as '@Email',
				vc.UserName			as '@UserName',
				vc.Password			as '@Password',
				vc.Status			as '@Status',
				v.Company			as '@Company',
				vc.FirstName		as '@FirstName',
				vc.LastName			as '@LastName',
				vc.ContactId		as '@ContactId'
			FROM VendorContact vc, Vendor v
			WHERE vc.vendorId = v.id and v.federalId = s.federalid 
			and vc.ContactType='Primary'
			FOR XML PATH('PrimaryContact'), TYPE
		)
		,
			(
				select * from
				(
					select id as '@Id',
							supplierid as '@SupplierId',
							V_SD_PREQUAL_TO	as '@ExpirationDate',
							'Qual' as '@QualityType'
							
					from dbo.SupplierStaticQualification
					where supplierid=t.supplierid
					--and @site = 'ExternalQualified'
						union all
					select id as '@Id',
							supplierid as '@SupplierId',
							V_sd_exp_date	as '@ExpirationDate',
							'Cert' as '@QualityType'
					from dbo.SupplierStaticCertification
					where supplierid=t.supplierid
					--and @site = 'ExternalCertified'
				) x
				FOR XML PATH('SupplierQuality'), ROOT('ArrayOfSupplierQuality'), TYPE
			)
			,
			(
				select 
					sap.ID as '@Id',
					sap.Supplierid as '@SupplierId',
					sap.Type as '@Type',
					sap.ProgramName as '@ProgramName',
					sap.Number as '@Number',
					sap.Trade as '@Trade',
					sap.ApprovedTrade as '@ApprovedTrade',
					sap.Approved as '@Approved',
					sap.ApprovedNumber as '@ApprovedNumber',
					sap.NumberOfYears as '@NumberOfYears',
					sap.VerifyName as '@VerifyName',
					sap.StartDate as '@StartDate',
					sap.EndDate as '@EndDate',
					sap.Comments as '@Comments',
					sap.Present as '@Present'
				
				from 
					supplierapprenticeshipprogram sap
					
				where sap.supplierid=s.id
				
				FOR XML PATH('SupplierApprenticeshipProgram'), ROOT('ArrayOfSupplierApprenticeshipProgram'), TYPE
			)
			
		FROM @tempCert t, Supplier s 
		where t.supplierId = s.Id
		order by t.OrderId
		FOR XML PATH('Supplier'), ROOT('ArrayOfSupplier')

end
GO
PRINT N'Altering [dbo].[SupplierAwardReport]...';


GO

/*
*********************************************************************************************************************
Procedure:	SupplierAwardReport
Purpose:	Supplier Award Report.
---------------------------------------------------------------------------------------------------------------------
Date			Developer				Notes
==========		===================		===============================
06/11/2009		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
exec SupplierAwardReport @supplierId=32984
*/
ALTER procedure [dbo].[SupplierAwardReport]
	@supplierId int,
	@datefrom datetime = null,
	@dateto datetime  = null,
	@RangeType varchar(2)  ='N'
as
set nocount on


declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime

if(DatePart(Month,getdate()) < 7)
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
	end
else
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
	end

if @datefrom is NUll  or @datefrom ='1900-01-01 00:00:00'   Or @dateto is NUll  or @dateto ='1900-01-01 00:00:00' 
Begin
	if @RangeType ='F' --Fiscal year
		Begin
			print 'F'
			if @datefrom is NUll  or @datefrom ='1900-01-01 00:00:00'
				set @datefrom=@firstDayOfYear

			if @dateto is NUll  or @dateto ='1900-01-01 00:00:00'
				set @dateto=@firstDayOfNextYear
			
		end
	Else
		Begin
			print 'N'
			if @datefrom is NUll  or @datefrom ='1900-01-01 00:00:00'
				set @datefrom=DATEADD(Month,-12,GetDate())

			if @dateto is NUll  or @dateto ='1900-01-01 00:00:00'
				set @dateto=Getdate()
		end

End








print convert(varchar(30),@datefrom,101)
print convert(varchar(30),@dateto,101)
print convert(varchar(30),@firstDayOfNextYear,101)

declare @federalId nvarchar(20)
select @federalId = FederalId From Supplier
Where Id = @supplierId
print @federalId
Select CONTRACT, MENTOR_CONTRACT, SOLICIT_NO, SOLICIT_DESCRIPTION, AWARD_AMOUNT, EXECUTION_DATE, NTP_DATE
FROM MV_VAS_AWARD
Where VENDOR_ID = @federalId
--AND ((EXECUTION_DATE >= DateAdd(M,-12,getdate()) and  NTP_DATE is null)
--OR  (ntp_date >= DateAdd(M,-12,getdate()) and EXECUTION_DATE is null ))

AND ((EXECUTION_DATE  between @datefrom and @dateto  and  NTP_DATE is null)
OR  (ntp_date  between @datefrom and @dateto  and EXECUTION_DATE is null ))

Order By EXECUTION_DATE desc



----[SupplierBidderReport]---------------------------------------------------------------------------------------------------------------
GO
PRINT N'Altering [dbo].[SupplierBidderReport]...';


GO



/*
*********************************************************************************************************************
Procedure:	SupplierBidderReport
Purpose:	Supplier Bidder Report.
---------------------------------------------------------------------------------------------------------------------
Date			Developer				Notes
==========		===================		===============================
08/28/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
exec SupplierBidderReport @supplierId=32984
*/
ALTER procedure [dbo].[SupplierBidderReport]
	@supplierId int,
	@datefrom date = null,
	@dateto date  = null,
	@RangeType varchar(2)  ='N'
as
set nocount on


declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime
if(DatePart(Month,getdate()) < 7)
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
	end
else
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
	end

if @datefrom is NUll  or @datefrom ='01/01/1900'   Or @dateto is NUll  or @dateto ='01/01/1900' 
Begin
	if @RangeType ='F' --Fiscal year
		Begin
			print 'F'
			if @datefrom is NUll  or @datefrom ='01/01/1900'
				set @datefrom=@firstDayOfYear

			if @dateto is NUll  or @dateto ='01/01/1900'
				set @dateto=@firstDayOfNextYear
			
		end
	Else
		Begin
			print 'N'
			if @datefrom is NUll  or @datefrom ='01-Jan-0001'
				set @datefrom=DATEADD(Month,-12,GetDate())

			if @dateto is NUll  or @dateto ='01-Jan-0001'
				set @dateto=Getdate()
		end

End
declare @federalId nvarchar(20)

select @federalId = FederalId From Supplier
Where Id = @supplierId

Select C_SOLICIT, VC_DESCRIPTION, SD_ACTUAL_BID_OPEN
FROM MV_VAS_BIDDER
Where C_VENDOR_ID = @federalId
--AND SD_ACTUAL_BID_OPEN >= DateAdd(M,-12,getdate())
AND SD_ACTUAL_BID_OPEN between @datefrom and @dateto
Order By SD_ACTUAL_BID_OPEN desc
----SupplierInclusion-------------------------------------------------------------------------------------------------------------------
GO
PRINT N'Altering [dbo].[SupplierPickupReport]...';


GO
/*
*********************************************************************************************************************
Procedure:	SupplierPickupReport
Purpose:	Supplier Pickup Report.
---------------------------------------------------------------------------------------------------------------------
Date			Developer				Notes
==========		===================		===============================
08/28/2008		AECSOFTUSA\Lily			Created
*********************************************************************************************************************
exec SupplierPickupReport @supplierId=32984
*/
ALTER procedure [dbo].[SupplierPickupReport]
	@supplierId int,
	@datefrom date = null,
	@dateto date  = null,
	@RangeType varchar(2)  ='N'
as
set nocount on


declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime
if(DatePart(Month,getdate()) < 7)
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
	end
else
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
	end

if @datefrom is NUll  or @datefrom ='01/01/1900'   Or @dateto is NUll  or @dateto ='01/01/1900' 
Begin
	if @RangeType ='F' --Fiscal year
		Begin
			print 'F'
			if @datefrom is NUll  or @datefrom ='01/01/1900'
				set @datefrom=@firstDayOfYear

			if @dateto is NUll  or @dateto ='01/01/1900'
				set @dateto=@firstDayOfNextYear
			
		end
	Else
		Begin
			print 'N'
			if @datefrom is NUll  or @datefrom ='01-Jan-0001'
				set @datefrom=DATEADD(Month,-12,GetDate())

			if @dateto is NUll  or @dateto ='01-Jan-0001'
				set @dateto=Getdate()
		end

End
declare @federalId nvarchar(20)
select @federalId = FederalId From Supplier
Where Id = @supplierId

Select C_SOLICIT, VC_DESCRIPTION, SD_TRANS_DATE
FROM MV_VAS_PICKUP
Where C_VENDOR_ID = @federalId
--and SD_TRANS_DATE >= DateAdd(M,-12,getdate()) 
and SD_TRANS_DATE between @datefrom and @dateto
and SD_TRANS_DATE <= ISNULL(SD_ACTUAL_BID_OPEN,'01/01/2099') 

Order By SD_TRANS_DATE Desc

----[UpdateLastBidListDate]-----------------------------------------------------------------------------------------------------------------
GO
PRINT N'Altering [dbo].[SupplierTimeReport]...';


GO

/*
*********************************************************************************************************************
Procedure:	SupplierTimeReport
Purpose:	Update a row in vendor table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
01/18/2013		SCA\TMPVJ1			Created
*********************************************************************************************************************
SupplierTimeReport 31172
*/
ALTER Proc [dbo].[SupplierTimeReport]
@supplierId int,
	@datefrom date = null,
	@dateto date  = null,
	@RangeType varchar(2)  ='N'
as
set nocount on


declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime
if(DatePart(Month,getdate()) < 7)
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
	end
else
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
	end

if @datefrom is NUll  or @datefrom ='01/01/1900'   Or @dateto is NUll  or @dateto ='01/01/1900' 
Begin
	if @RangeType ='F' --Fiscal year
		Begin
			print 'F'
			if @datefrom is NUll  or @datefrom ='01/01/1900'
				set @datefrom=@firstDayOfYear

			if @dateto is NUll  or @dateto ='01/01/1900'
				set @dateto=@firstDayOfNextYear
			
		end
	Else
		Begin
			print 'N'
			if @datefrom is NUll  or @datefrom ='01-Jan-0001'
				set @datefrom=DATEADD(Month,-12,GetDate())

			if @dateto is NUll  or @dateto ='01-Jan-0001'
				set @dateto=Getdate()
		end

End
Select rp.SolicitationNo,rp.Description,Convert(nvarchar(20),rp.ApprovalDate,101) As ApprovalDate
from dbo.RfdSupplier rs 
Inner Join rfdproject rp on rs.rfdprojectid=rp.id
Inner join supplier s on rs.supplierid=s.id
Inner Join vendor v on v.FederalId=s.FederalId
where 
rs.status IN(1,2) 
AND rp.IsFinal='Y'
AND rp.ApprovalDate is not null

--ANd rp.ApprovalDate >= getdate()-366
and rp.ApprovalDate between @datefrom and @dateto

and s.federalid =(select federalid from supplier where id=@supplierId)

--from dbo.rfdsupplier rs 
--Inner join supplier s on rs.supplierid=s.id
--Inner Join rfdproject rp on rs.rfdprojectid=rp.id 
--Inner Join vendor v on v.FederalId=s.FederalId
--Where rp.IsFinal='Y' 
--and rp.ApprovalDate is not null
--and rs.status IN(1,2) 
--And rp.ApprovalDate >getdate()-366
--Group By s.FederalId
--order by s.FederalId
GO
PRINT N'Altering [dbo].[UpdateScheduleHistory]...';


GO

/*
*********************************************************************************************************************
Procedure:	UpdateScheduleHistory
Purpose:	Update a row in ScheduleHistory table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
2/25/2005		AECSOFT\lily			Created
*********************************************************************************************************************
*/
ALTER procedure [dbo].[UpdateScheduleHistory]
	@id int,
	@jobId int= null,
	@userId int = null,
	@status int = null
as
select
	@jobId = isnull( @jobId, JobId ),
	@userId = isnull( @userId, UserId ),
	@status = isnull( @status, Status )
from ScheduleHistory
where Id = @id
if @@RowCount = 0 return 0



if @jobId >= 25 and @jobId <= 39
Begin
	update ScheduleHistory
	set EndDate = getdate()
	where Id != @id and JobId =@jobId and EndDate is null 
End

update ScheduleHistory
set
	JobId = @jobId,
	UserId = @userId,
	EndDate = getdate(),
	Status = @status
where Id = @id


return  @@RowCount
GO
PRINT N'Altering [dbo].[UpdateSubcontractor]...';


GO

/*
*********************************************************************************************************************
Procedure:	UpdateSubcontractor
Purpose:	Update a row in Subcontractor table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
10/3/2008		AECSOFTUSA\lily			Created
*********************************************************************************************************************
*/
ALTER procedure [dbo].[UpdateSubcontractor]
	@id int,
	@type nvarchar(10) = null,
	@isMentor char(1) = null,
	@taxId nvarchar(20) = null,
	@contractNo nvarchar(50) = null,
	@solicitId int = null,
	@solicitNo nvarchar(20) = null,
	@scaProjectOfficer nvarchar(50) = null,
	@projectOfficer nvarchar(50) = null,
	@supplierId int = null,
	@company nvarchar(100) = null,
	@federalId nvarchar(20) = null,
	@addressLine1 nvarchar(100) = null,
	@addressLine2 nvarchar(100) = null,
	@city nvarchar(50) = null,
	@state nvarchar(50) = null,
	@zipCode nvarchar(50) = null,
	@country nvarchar(50) = null,
	@phone nvarchar(20) = null,
	@fax nvarchar(20) = null,
	@estValue float = null,
	@description ntext = null,
	@workDescription ntext = null,
	@startDate datetime = null,
	@endDate datetime = null,
	@mbe nvarchar(50) = null,
	@wbe nvarchar(50) = null,
	@lbe nvarchar(50) = null,
	@sBSMbe nvarchar(50) = null,
	@sBSWbe nvarchar(50) = null,
	@sBSLbe nvarchar(50) = null,
	@supportDescription ntext = null,
	@isWicks char(1) = null,
	@status int = null,
	@isUpload char(1) = null,
	@tier int = null,
	@parentId int = null,
	@parentCompany nvarchar(100) = null,
	@requestRcvdDate datetime = null,
	@createSupplierId int = null,
	@changeUser nvarchar(50) = null
as

select
	@type = isnull( @type, Type ),
	@isMentor = isnull( @isMentor, IsMentor ),
	@taxId = isnull( @taxId, TaxId ),
	@contractNo = isnull( @contractNo, ContractNo ),
	@solicitId = isnull( @solicitId, SolicitId ),
	@solicitNo = isnull( @solicitNo, SolicitNo ),
	@scaProjectOfficer = isnull( @scaProjectOfficer, ScaProjectOfficer ),
	@projectOfficer = isnull( @projectOfficer, ProjectOfficer ),
	@supplierId = isnull( @supplierId, SupplierId ),
	@company = isnull( @company, Company ),
	@federalId = isnull( @federalId, FederalId ),
	@addressLine1 = isnull( @addressLine1, AddressLine1 ),
	@addressLine2 = isnull( @addressLine2, AddressLine2 ),
	@city = isnull( @city, City ),
	@state = isnull( @state, State ),
	@zipCode = isnull( @zipCode, ZipCode ),
	@country = isnull( @country, Country ),
	@phone = isnull( @phone, Phone ),
	@fax = isnull( @fax, Fax ),
	@estValue = isnull( @estValue, EstValue ),
	@description = isnull(@description, Description),
	@workDescription = isnull( @workDescription, WorkDescription ),
	@startDate = isnull( @startDate, StartDate ),
	@endDate = isnull( @endDate, EndDate ),
	@mbe = isnull( @mbe, Mbe ),
	@wbe = isnull( @wbe, Wbe ),
	@lbe = isnull( @lbe, Lbe ),
	@sBSMbe = isnull( @sBSMbe, SBSMbe ),
	@sBSWbe = isnull( @sBSWbe, SBSWbe),
	@sBSLbe = isnull( @sBSLbe, SBSLbe ),
	@supportDescription = isnull( @supportDescription, SupportDescription ),
	@isWicks = isnull( @isWicks, IsWicks ),
	@status = isnull( @status, Status ),
	@isUpload = isnull( @isUpload, IsUpload ),
	@tier = isnull( @tier, Tier ),
	@parentId = isnull( @parentId, ParentId ),
	@parentCompany = isnull(@parentCompany, ParentCompany),
	@requestRcvdDate = isnull( @requestRcvdDate, RequestRcvdDate ),
	@createSupplierId = isnull(@createSupplierId, CreateSupplierId),
	@changeUser = isnull( @changeUser, ChangeUser )
from Subcontractor
where Id = @id

if @@RowCount = 0 return 0

update Subcontractor
set
	Type = @type,
	IsMentor = @isMentor,
	TaxId = @taxId,
	ContractNo = @contractNo,
	SolicitId = @solicitId,
	SolicitNo = @solicitNo,
	ScaProjectOfficer = @scaProjectOfficer,
	ProjectOfficer = @projectOfficer,
	SupplierId = @supplierId,
	Company = @company,
	FederalId = @federalId,
	AddressLine1 = @addressLine1,
	AddressLine2 = @addressLine2,
	City = @city,
	State = @state,
	ZipCode = @zipCode,
	Country = @country,
	Phone = @phone,
	Fax = @fax,
	EstValue = @estValue,
	Description = @description,
	WorkDescription = @workDescription,
	StartDate = @startDate,
	EndDate = @endDate,
	Mbe = @mbe,
	Wbe = @wbe,
	Lbe = @lbe,
	SBSMbe = @sBSMbe,
	SBSWbe = @sBSWbe,
	SBSLbe = @sBSLbe,
	SupportDescription = @supportDescription,
	IsWicks = @isWicks,
	Status = @status,
	IsUpload = @isUpload,
	Tier = @tier,
	ParentId = @parentId,
	ParentCompany = @parentCompany,
	/*The Request Received date should be updated with current date when the status changes to “Subcontractor VAS Prepared”*/
	RequestRcvdDate = case when @status =4 then getdate() else  @requestRcvdDate end,
	CreateSupplierId = @createSupplierId,
	ChangeDate = getdate(),
	ChangeUser = @changeUser
where Id = @id

return  @@RowCount
GO
PRINT N'Creating [dbo].[GetMentorBidActivityReportXml]...';
GO
-- =============================================
-- Author:		PS
-- Create date: 8/1/2014
-- Description:	The procedure is to get all Mentor Firms and their Limited List and Bidding activity
--				If Date Range is not supplied always run it fot the current Fiscal year
--				Trade codes displayed are for the current supplier version
--				The numbers displayed for the bids, pickups, awards, invitations, Rejections etc. are overall numbers always
-- =============================================
CREATE PROCEDURE [dbo].[GetMentorBidActivityReportXml]
	-- Add the parameters for the stored procedure here
	@pageSize int,
	@pageNumber int,
	@VendorId varchar(30),
	@MentorType Varchar(10),
	@YearsInProgram int,
	@FromDate DateTime,
	@ToDate DateTime,
	@TradeCodes Varchar(300)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @Month int
	declare @Year int
	declare @beginCount int
	declare @endCount int
	declare @totalcount int

	set @beginCount = @pageNumber * @pageSize + 1
	set @endCount = @beginCount + @pageSize - 1

	declare @firstDayOfYear datetime
	declare @firstDayOfNextYear datetime

	Declare @tempCategory Table
	(	
		CategoryId int,
		ParentId int
	)

	if(@TradeCodes != '')
	begin
		insert into @tempCategory( CategoryId,ParentId )
		Select c.Id,c.ParentId From dbo.Split(@TradeCodes, '^') t, Category c
		where t.Item = c.Id or t.Item = c.ParentId
	end

	if(DatePart(Month,getdate()) < 7)
		begin
			set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
			set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
		end
	else
		begin
			set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
			set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
		end

	if @FromDate is NUll  or @FromDate ='1900-01-01 00:00:00'   Or @ToDate is NUll  or @ToDate ='1900-01-01 00:00:00' 
		Begin
			if @FromDate is NUll  or @FromDate ='1900-01-01 00:00:00'
				set @FromDate=@firstDayOfYear

			if @ToDate is NUll  or @ToDate ='1900-01-01 00:00:00'
				set @ToDate=@firstDayOfNextYear
			
		end
	


		print cast(@FromDate as varchar(13))
		print cast(@ToDate as varchar(13))
	declare @temp table(
		OrderId int identity (1,1) Primary Key,
		SupplierId int,
    	Vendor Varchar(200),
		VendorId Varchar(50),
		YearProgram int,
		BidInvitations int,
		Bids int,
		Pickups int,
		Awards Int,
		Deletions int,
		Rejections int,
		ProgramType varchar(50),
		Trades varchar(500)
    )

	
	
    -- Insert statements for procedure here
	insert into @temp
	select  
		v.CurrentSupplierId as Id,
		v.Company as Vendor, 
		v.FederalId as VendorId ,
		DATEDIFF(year,mgm.start_date,Getdate()) as YearProgram,
		(
		Select Count(distinct RP.rfdprojectid) 
		from dbo.rfdsupplier rs 
		Inner join supplier s on rs.supplierid=s.id
		Inner Join rfdproject rp on rs.rfdprojectid=rp.id 
		Where rp.IsFinal='Y' and rp.ApprovalDate is not null
		and rs.status IN(1,2) 
		And rp.ApprovalDate between @FromDate and @Todate
		and s.FederalId=v.FederalId
		Group By s.FederalId
		) as Bidinvitations,

		(Select count(*)
		FROM MV_VAS_BIDDER
		Where C_VENDOR_ID = v.FederalId
		AND SD_ACTUAL_BID_OPEN between  @FromDate and @Todate
		) as Bids,
		(Select count(*)
		FROM MV_VAS_PICKUP
		Where C_VENDOR_ID = v.FederalId
		and SD_TRANS_DATE between @FromDate and @Todate
		and SD_TRANS_DATE <= ISNULL(SD_ACTUAL_BID_OPEN,'01/01/2099') 
		) as pickups,

		(Select count(*)
		FROM MV_VAS_AWARD
		Where VENDOR_ID = v.FederalId
		AND ((EXECUTION_DATE  between  @FromDate and @Todate  and  NTP_DATE is null)
		OR  (ntp_date  between  @FromDate and @Todate  and EXECUTION_DATE is null ))
		) as awards,
		(
		select	
			count(distinct wf.DateCreated)
		From 
			RfdProject rp
			Inner join rfdsupplier rs on rs.RfdProjectId=rp.id
			Inner Join WorkflowHistory wf on rs.TransactionId=wf.TransactionHeaderId
			Inner Join WorkflowNode wn on wn.Id=wf.CurrentNodeId
			inner join supplier s on s.id=rs.SupplierId
		where wn.[Name] = 'Deleted'
			And s.FederalId=v.FederalId
			and rp.IsFinal='Y' and rp.ApprovalDate is not null
			and rs.status=4
			AND wf.DateCreated between  @FromDate and @Todate
		) as Deletions,
		(
		select	
			count(distinct wf.DateCreated)
		From 
			RfdProject rp
			Inner join rfdsupplier rs on rs.RfdProjectId=rp.id
			Inner Join WorkflowHistory wf on rs.TransactionId=wf.TransactionHeaderId
			Inner Join WorkflowNode wn on wn.Id=wf.CurrentNodeId
			inner join supplier s on s.id=rs.SupplierId
		where wn.[Name] = 'Rejected'
			And s.FederalId=v.FederalId
			and rp.IsFinal='Y' and rp.ApprovalDate is not null
			and rs.status=3
			AND wf.DateCreated between  @FromDate and @Todate
		) as Rejections,
		mgm.program_type as ProgamType, 
		(
		Select c.Name + ',' AS [text()]
		From suppliercategory sc, Category c
		Where sc.CategoryId=c.id
		and sc.SupplierId= v.QualifiedSupplierId
		and sc.IsApproved='Y'        
		For XML PATH ('')
		) as Trades

from 
	(select * from mv_Curr_Mentor_BidList
	union
	select * from mv_Curr_Grad_Mentor_BidList
	) mgm
	inner join Vendor v on mgm.TAX_ID=v.FederalId
where	(@TradeCodes='' or exists(
			select * 
			from 
				rfdsupplier rs
				inner join supplier s on rs.supplierid=s.id
				inner join suppliercategory sc on s.id=sc.supplierid 
			where  s.FederalId=mgm.TAX_ID
				and sc.CategoryId in (select CategoryId from @tempCategory)
				and sc.IsApproved='Y'
				
			)
		)
and		exists(select * from rfdsupplier rs, rfdproject rd, supplier s
			where rs.SupplierId=s.id
			and s.FederalId=mgm.TAX_ID
			and rs.RfdProjectId=rd.id
			and rd.ApprovalDate between @FromDate and @ToDate 
		)
and		(@VendorId ='' Or (v.FederalId like '%' + @VendorId + '%'))
and		(@MentorType ='' Or (mgm.PROGRAM_TYPE like  @MentorType + '%'))
and		(@YearsInProgram = 0 Or (DATEDIFF(year,mgm.start_date,Getdate())= @YearsInProgram))

select @totalcount = count(*) from @temp
	
	
	--if @pageSize > 0
	--	Delete from @temp
	--	Where OrderId < @beginCount or OrderId > @endCount

select 
	supplierid as '@SupplierId',
	vendor as '@Vendor',
	VendorId as '@VendorId',
	YearProgram as '@YearProgram',
	Bidinvitations as '@BidInvitations',
	Bids as '@Bids',
	Pickups as '@Pickups',
	Awards as '@Awards',
	Deletions as '@Deletions',
	Rejections as '@Rejections',
	ProgramType as '@ProgramType',
	Trades as '@Trades',
	@totalcount as '@TotalRecordNumber'
from @temp
FOR XML PATH('MentorBidActivity'), ROOT('ArrayOfMentorBidActivity')



END
GO
PRINT N'Creating [dbo].[GetSupMonthelyReport]...';


GO

--GetPlanXml 1084
--GetPlanXml 1083
--GetPlanXml 243
--select * from [plan]
--Plan[ (@IsWaiver = 'Y') ]
/*

exec GetSupMonthelyReport @pageSize=20,@pageNumber=0,@orderBy=N'ContractNo',@sequence=N'ASC',@userId=0,@status=-1,@extraXml=N'<?xml version="1.0"?>
<ArrayOfExtra xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <Extra Name="Status" Value="-1" />
  <Extra Name="contract" Value="" />
  <Extra Name="prime" Value="" />
  <Extra Name="PrimeVendorId" Value="" />
  <Extra Name="ContractType" Value="All" />
  <Extra Name="PresentageCompletefrom" Value="90" />
  <Extra Name="PresentageCompleteto" Value="95" />
  <Extra Name="FromDate" Value="1/1/1900" />
  <Extra Name="ToDate" Value="1/1/1900" />
  <Extra Name="NTPFromDate" Value="1/1/1900" />
  <Extra Name="NTToDate" Value="1/1/1900" />
</ArrayOfExtra>'


select *From MV_Solicit_contract c_package_code mvs on 

mvs.C_CONTRACT=p.ContractNo
mvs.C_VENDOR_ID=p.FederalId
mvs.C_SOLICIT=p.SolicitNo

(select * from openquery(NYCSCA_DW,'select * from dwstar.v_project_dates_ntp_subcomp')) ntp
On ntp.PACK_ID=mvs.c_package_code

*/
/*
*********************************************************************************************************************
Procedure:	GetPlanXml
Purpose:	Get a row from Plan table.
---------------------------------------------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
8/11/2010		AECSOFTUSA\Angel			Created
*********************************************************************************************************************
*/
CREATE procedure [dbo].[GetSupMonthelyReport]
	@pageSize int,
	@pageNumber int,
	@orderBy nvarchar(50),
	@sequence nvarchar(10),
	@userId int,
	@status int,
	@extraXml ntext
as
begin
declare @hdoc int
-- Convert Response data from XML to in memory table. 
EXEC sp_xml_preparedocument @hdoc OUTPUT, @extraXml

declare @extra Table
(
	Name nvarchar(50),
	Value nvarchar(2000)
)
INSERT INTO @extra
(
	Name,
	Value
)
SELECT
	Name,
	Value
FROM OPENXML(@hDoc, '/ArrayOfExtra/Extra', 1)
WITH
(
	Name nvarchar(50),
	Value nvarchar(2000)
)

declare @contractNo nvarchar(50)
declare @contractType nvarchar(50)
declare @vendor nvarchar(50)
declare @federalId nvarchar(50)
declare @analyst nvarchar(50)
declare @borough nvarchar(50)
--declare @presentageComplete nvarchar(50)
declare @presentageCompletefrom float
declare @presentageCompleteto float

declare @mentorGrad nvarchar(50)

declare @fromApprovedMWLBE nvarchar(50)
declare @toApprovedMWLBE nvarchar(50)

declare @fromAwardDate nvarchar(50)
declare @toAwardDate nvarchar(50)

declare @beginCount int
declare @endCount int
declare @totalcount int

declare  @fromNTPDate	nvarchar(50)
declare  @toNTPDate		nvarchar(50)



set @contractNo=''
set @contractType=''
set @vendor=''
set @federalId=''
set @analyst=''
set @borough=''
set @presentageCompletefrom =0
set @presentageCompleteto =0
set @mentorGrad=''

set @fromApprovedMWLBE = ''
set @toApprovedMWLBE  = ''

set @fromAwardDate = '1/1/1900'
set @toAwardDate = '1/1/1900'


set @beginCount = @pageNumber * @pageSize + 1
set @endCount = @beginCount + @pageSize - 1



select @contractNo=Value
from @extra
where Name='Contract'

select @contractType=Value
from @extra
where Name='ContractType'

declare  @CIPVALGT varchar(50)
declare  @CIPVALLT varchar(50)
set @CIPVALGT=''
set @CIPVALLT=''

if( @contractType = 'CIPGT7M')
	begin
	set @CIPVALGT='GT'
	set @contractType='CIP'
	end
else if(@contractType = 'CIPLT7M')
	begin
	set @CIPVALLT='LT'
	set @contractType='CIP'
	end

	

--select @vendor=Value
--from @extra
--where Name='PrimeVendor'
select @vendor=Value
from @extra
where Name='Prime'

--select @federalId=Value
--from @extra
--where Name='PrimeFederalId'

select @federalId=Value
from @extra
where Name='PrimeVendorId'


select @analyst=Value
from @extra
where Name='Analyst'

select @presentageCompletefrom =Value
from @extra
where Name='PresentageCompletefrom'

select @presentageCompleteto =Value
from @extra
where Name='PresentageCompleteto'

--select @presentageCompletefrom as '@presentageCompletefrom' ,@presentageCompleteto as '@presentageCompleteto'
--return


select @borough=Value
from @extra
where Name='Borough'

select @mentorGrad=Value
from @extra
where Name='MentorGrad'

select @fromApprovedMWLBE=Value
from @extra
where Name='FromApprovedMWLBE'

select @toApprovedMWLBE=Value
from @extra
where Name='ToApprovedMWLBE'

select @fromAwardDate=Value
from @extra
where Name='FromDate'

select @toAwardDate=Value
from @extra
where Name='ToDate'


select @fromNTPDate=Value
from @extra
where Name='NTPFromDate'

select @toNTPDate=Value
from @extra
where Name='NTToDate'





EXEC sp_xml_removedocument @hdoc


select DISTINCT mvs.C_CONTRACT,mvs.C_VENDOR_ID,mvs.C_SOLICIT,NTP.PACK_CD,
				(	select DISTINCT LLW_CD + ',' AS [text()]
					from dw_v_project_dates_ntp_subcomp C
					WHERE PACK_CD= NTP.PACK_CD
					FOR XML PATH('')
					) AS LLW_CD
				,
				PHAS_FCST_BGN_DT,PHAS_FCST_END_DT
into #NTP_STG
From 
MV_Solicit_contract mvs  
Inner join
(select  PACK_CD,PHAS_FCST_BGN_DT,PHAS_FCST_END_DT from dw_v_project_dates_ntp_subcomp) ntp
On ntp.PACK_CD=mvs.c_package_code where mvs.C_CONTRACT is not null


Declare @temp1 Table
(
	OrderId int identity (1,1) Primary Key,
	PlanId int,
	Company nvarchar(100),
	FederalId nvarchar(20),
	Reviewer nvarchar(50),
	SchoolName nvarchar(50),
	BoroName nvarchar(50),
	ProjectOfficer nvarchar(50),
	NTPDate	nvarchar(50),
	SubstantialCompleteDate nvarchar(50),
	LLWNO nvarchar(250)
)
--SELECT * INTO #ntp from openquery(NYCSCA_DW,'select * from dwstar.v_project_dates_ntp_subcomp')
--SELECT * INTO dw_v_project_dates_ntp_subcomp from openquery(NYCSCA_DW,'select * from dwstar.v_project_dates_ntp_subcomp')
Insert Into @temp1
	(PlanId, 
	Company,
	FederalId,
	Reviewer,
	SchoolName,
	BoroName,
	ProjectOfficer,
	NTPDate,
	SubstantialCompleteDate,
	LLWNO)
select 
	t.Id,
	t.Company,
	t.FederalId,
	t.Reviewer,
	t.SchoolName,
	t.BoroName,
	t.ProjectOfficer,
	t.PHAS_FCST_BGN_DT,
	t.PHAS_FCST_END_DT,
	t.LLW_CD
from
	(SELECT 
		p.Id,
		p.Type,
		p.ContractNo,
		p.Description,
		p.Status,
		v.Company,
		v.FederalId, 
		isnull(convert(nvarchar(50), pp.propertytext), '') as Reviewer,
		isnull(convert(nvarchar(50), pp17.propertytext), '') as SchoolName,
		isnull(convert(nvarchar(50), pp19.propertytext), '') as BoroName,
		isnull(convert(nvarchar(50), pp20.propertytext), '') as ProjectOfficer ,
		mvsntp.PHAS_FCST_BGN_DT,
		mvsntp.PHAS_FCST_END_DT,
		mvsntp.LLW_CD
	From 
		[Plan] p
	left join 
		Vendor v
	on
		p.FederalId = v.federalId
	left join
		(select * from planProperty where propertyId = 15) pp

	on
		p.Id = pp.PlanId

	left outer join
		(select * from planProperty where propertyId = 17) pp17

	on
		p.Id = pp17.PlanId

	left outer join
		(select * from planProperty where propertyId = 19) pp19

	on
		p.Id = pp19.PlanId
	left outer join
		(select * from planProperty where propertyId = 20) pp20

	on
		p.Id = pp20.PlanId

	left outer join
		#NTP_STG mvsntp
		on
			mvsntp.C_CONTRACT	=p.ContractNo and
			mvsntp.C_VENDOR_ID	=p.FederalId and
			mvsntp.C_SOLICIT	=p.SolicitNo
	where 
		(@contractNo='' or isnull(p.ContractNo, p.mecontractNo) like '%' + @contractNo + '%') 
		and (@federalId='' or ltrim(rtrim(@federalId)) = ltrim(rtrim(p.FederalId)))
		and (@vendor='' or  v.Company like '%' + @vendor + '%')
		and (@contractType='' or @contractType='All' or @contractType = p.Type)

		and  (@CIPVALGT='' or (@CIPVALGT ='GT'  and p.ContractAmount >7000000)) 	
		and  (@CIPVALLT='' or (@CIPVALLT='LT'  and p.ContractAmount <=7000000)) 	
		
		and dbo.[PercentageCompletion](p.Id)>= case when @presentageCompletefrom !=0 then @presentageCompletefrom else dbo.[PercentageCompletion](p.Id) end
		and dbo.[PercentageCompletion](p.Id)<= case when @presentageCompleteto !=0 then @presentageCompleteto else dbo.[PercentageCompletion](p.Id) end
			
		and (@analyst='' or @analyst= isnull(convert(nvarchar(50), pp.propertytext), '')) 
		and (@borough='' or @borough=(select convert(nvarchar(50), propertytext) from planProperty pp where propertyId = 18 and pp.planId = p.Id))
		--and (@schoolName='' or @schoolName=(select convert(nvarchar(50), propertytext) from planProperty pp where propertyId = 17 and pp.planId = p.Id))		
		and (@mentorGrad='' or (@mentorGrad='N' and p.Type!='Mentor Grad'))
		--and ((@status = -1 and p.status<>16) or p.status = @status )
		and ((@status = -1 and p.status not in(16,17))  or (p.status = @status and @status<>-1))
		and (@fromApprovedMWLBE='' or dbo.[PerformanceInclusion](p.Id) >= CONVERT(float, @fromApprovedMWLBE))
		and (@toApprovedMWLBE='' or dbo.[PerformanceInclusion](p.Id) <= CONVERT(float, @toApprovedMWLBE))
		--and (@fromAwardDate='1/1/1900' or p.AwardDate >= @fromAwardDate)
		--and (@toAwardDate='1/1/1900' or p.AwardDate <= @toAwardDate)

		and (@fromAwardDate='1/1/1900' or mvsntp.PHAS_FCST_END_DT >= @fromAwardDate)
		and (@toAwardDate='1/1/1900' or mvsntp.PHAS_FCST_END_DT <= @toAwardDate)

		and (@fromNTPDate = '1/1/1900' or mvsntp.PHAS_FCST_BGN_DT>=@fromNTPDate)
		and (@toNTPDate = '1/1/1900' or mvsntp.PHAS_FCST_BGN_DT<=@toNTPDate)

				


		-- TFS Work item #617 Move all "closed out" projects from the search grid
		--and (Case @status when -1 then p.status else @status end <> Case @status When -1 then  16 else -2 End)

	) t
	
	
ORDER BY 
	CASE @sequence 
	WHEN 'ASC' THEN 
		CASE @orderBy 
	        	WHEN 'ContractNo' THEN t.ContractNo
	        	WHEN 'Type' THEN t.Type
	        	WHEN 'VendorName' THEN t.Company
	        	WHEN 'VendorID' THEN t.FederalId
	        	WHEN 'Reviewer' THEN t.Reviewer
		ELSE ''
		END
	END ASC,
	CASE @sequence 
	WHEN 'ASC' THEN 
		CASE @orderBy 
				WHEN 'Status' THEN t.Status
		ELSE ''
		END
	END ASC,
	CASE @sequence	
	WHEN 'DESC' THEN 
		CASE @orderBy 
	        	WHEN 'ContractNo' THEN t.ContractNo
	        	WHEN 'Type' THEN t.Type
	        	WHEN 'VendorName' THEN t.Company
	        	WHEN 'VendorID' THEN t.FederalId
	        	WHEN 'Reviewer' THEN t.Reviewer
		ELSE ''
		END
	END DESC,
	CASE @sequence 
	WHEN 'DESC' THEN 
		CASE @orderBy 
				WHEN 'Status' THEN t.Status
		ELSE ''
		END
	END DESC
	
select @totalcount = count(*) from @temp1
if @pageSize > 0
	--Delete from @temp1 Where OrderId < @beginCount or OrderId > @endCount
	 
select
	--Id		As '@Id',
	--p.PlanId		As '@PlanId',
	--Type		As '@Type',
	--ProjectId		As '@ProjectId',
	--ContractId		As '@ContractId',
	--SolicitSeq		As '@SolicitSeq',
	--SolicitNo        As '@Solicit',

	ContractNo		As '@ContractNo',
	ContractAmount	As '@ContractAmount',
	Description		As '@Description',
	dbo.[PercentageCompletion](p.Id) As '@PercentageCompletion',
	dbo.ApprovedMWLBESubcontractorAmount(p.Id) + dbo.ApprovedMWLBESupplierAmount(p.Id)  As '@MWLBEApprovedAmount', --Total Actual MWLBE $
	t.Company As '@Company',--General Contractor 
	dbo.PerformanceInclusion(p.Id)  As '@MWLBEApprovedPercentage', -- Actual MWLBE %
	isnull((select sum(estvalue) from plansubcontractor where planid=p.id and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))),0) as '@EstimateAmount', 
	cast(t.NTPDATE as datetime) As '@NTPDate',
	cast(t.SubstantialCompleteDate as datetime) As '@SubstaintialCompletionDate',
	t.LLWNO As '@LLWNO',
	p.federalid		as '@FederalId',
	--MeContractNo	As '@MeContractNo',
	
	--Comments		As '@Comments',
	--EEOContactName		As '@EEOContactName',
	--EEOContactPhone		As '@EEOContactPhone',
	--EEOContactEmail		As '@EEOContactEmail',
	--SubcontPercentage		As '@SubcontPercentage',   --Total Proposed %
	--MWLBEGoal		As '@MWLBEGoal',
	--RevisedMWLBEGoal		As '@RevisedMWLBEGoal',
	--WaiverPercentage		As '@WaiverPercentage',
	--RevisedPercentage		As '@RevisedPercentage',
	--PlanApprovalDate		As '@PlanApprovalDate',
	--IsWaiver		As '@IsWaiver',
	--ProjectDuration As'@ProjectDuration',
	--AwardDate As '@AwardDate',
	--Status		As '@Status',
	--StatusName		As '@StatusName',
	--WorkflowId		As '@WorkflowId',
	--TransactionId		As '@TransactionId',
	--dbo.SubmittedAmount(p.Id)  As '@SubmittedAmount', --Total Submitted $
	----isnull(p.ContractAmount, 0) *  isnull(p.SubcontPercentage, 0)/100 as '@EstimateAmount', --Total Proposed $
	dbo.EstimateMWLBESubcontractorAmount(p.Id) + dbo.EstimateMWLBESupplierAmount(p.Id) As '@MWLBEEstimateAmount', --Total Proposed MWLBE $
	--CONVERT([decimal](18,2), dbo.Percentage((dbo.EstimateMWLBESubcontractorAmount(p.Id) + dbo.EstimateMWLBESupplierAmount(p.Id)), isnull(p.ContractAmount, 0) *  isnull(p.SubcontPercentage, 0)/100)*100, 0) As '@MWLBEEstimatePercentage', --Proposed MWLBE %
	
	--dbo.ApprovedSubcontractorAmount(p.Id) + dbo.ApprovedSupplierAmount(p.Id) As '@ApprovedAmount', --Total Actual $
	
	
	(select isnull(SUM(isnull(EstValue, 0)), 0) from PlanSubcontractor where PlanId  = p.Id and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))) As '@SubmittedAmount',
	
	--dbo.[PerformanceInclusion](p.Id) As '@PerformanceInclusion',
	--ChangeUser		As '@ChangeUser',
	--ChangeDate		As '@ChangeDate',
	t.Company	As '@Result'
	--@totalcount		as '@TotalRecordNumber',
	--t.reviewer as '@Analyst',
	--(
	--	select concat(u.FirstName,' ',u.LastName) as Name
	--	from [User] u
	--	inner join aspnet_Users au
	--	on au.UserName = t.reviewer and au.UserId = u.UserId
	--) as '@AnalystFullName',
	--t.SchoolName as '@SchoolName',
	--t.BoroName as '@BoroName',
	--t.ProjectOfficer as '@ProjectOfficer',
	--(
	--select
	--	i.Id				As '@Id',
	--	i.PlanId				As '@PlanId',
	--	i.LLW				As '@LLW',
	--	i.LLWDesc			As '@LLWDesc',
	--	i.School			As '@School',
	--	i.SchoolAddressLine1	As '@SchoolAddressLine1',
	--	i.SchoolAddressLine2	As '@SchoolAddressLine2',
	--	i.Boro				As '@Boro',
	--	i.ZipCode			As '@ZipCode',
	--	i.ChangeUser		As '@ChangeUser',
	--	i.ChangeDate		As '@ChangeDate'
	--from 
	--	PlanItem i
	--where i.planId = p.Id
	--Order By i.LLW
	--FOR XML PATH('PlanItem'), ROOT('ArrayOfPlanItem'), TYPE
	--),
	--(
	--select 
	--	vs.VendorId as '@VendorId',
	--	vs.Certification as '@Certification',
	--	vs.Status as '@Status',
	--	vs.CertifiedDate as '@CertifiedDate',
	--	vs.ExpirationDate as '@ExpirationDate',
	--	vs.PartnerSource as '@PartnerSource'
	--from
	--	VendorSBSCertification vs
	--	inner join vendor v on vs.vendorid=v.id
	--where
	--	v.federalid=p.federalid
	--	and p.awarddate between vs.certifieddate and isnull(vs.expirationdate,Getdate())
	--FOR XML PATH('VendorSBSCertification'), ROOT('ArrayOfVendorSBSCertification'), TYPE
	--)
			
	
from 
	@temp1 t 
	inner join [Plan] p on	t.PlanId = p.Id	
--where 
--		1=1 and (@presentageCompletefrom=0 or (@presentageCompletefrom!=0 and @presentageCompletefrom >=dbo.[PercentageCompletion](p.Id) )) 
--		and (@presentageCompleteto=0 or (@presentageCompleteto!=0 and @presentageCompleteto <=dbo.[PercentageCompletion](p.Id) ))

	
Order By t.OrderId
FOR XML PATH('Plan'), ROOT('ArrayOfPlan')

drop table #NTP_STG


end
GO
PRINT N'Creating [dbo].[inserts_script]...';


GO
Create PROC [dbo].[inserts_script]
(
 @table_name varchar(776),    -- The table/view for which the INSERT statements will be generated using the existing data
 @target_table varchar(776) = NULL,  -- Use this parameter to specify a different table name into which the data will be inserted
 @include_column_list bit = 1,  -- Use this parameter to include/ommit column list in the generated INSERT statement
 @from varchar(800) = NULL,   -- Use this parameter to filter the rows based on a filter condition (using WHERE)
 @include_timestamp bit = 0,   -- Specify 1 for this parameter, if you want to include the TIMESTAMP/ROWVERSION column's data in the INSERT statement
 @debug_mode bit = 0,   -- If @debug_mode is set to 1, the SQL statements constructed by this procedure will be printed for later examination
 @owner varchar(64) = NULL,  -- Use this parameter if you are not the owner of the table
 @ommit_images bit = 0,   -- Use this parameter to generate INSERT statements by omitting the 'image' columns
 @ommit_identity bit = 0,  -- Use this parameter to ommit the identity columns
 @top int = NULL,   -- Use this parameter to generate INSERT statements only for the TOP n rows
 @cols_to_include varchar(8000) = NULL, -- List of columns to be included in the INSERT statement
 @cols_to_exclude varchar(8000) = NULL, -- List of columns to be excluded from the INSERT statement
 @disable_constraints bit = 0,  -- When 1, disables foreign key constraints and enables them after the INSERT statements
 @ommit_computed_cols bit = 0  -- When 1, computed columns will not be included in the INSERT statement
 
)
AS
BEGIN

SET NOCOUNT ON
--Making sure user only uses either @cols_to_include or @cols_to_exclude
IF ((@cols_to_include IS NOT NULL) AND (@cols_to_exclude IS NOT NULL))
 BEGIN
  RAISERROR('Use either @cols_to_include or @cols_to_exclude. Do not use both the parameters at once',16,1)
  RETURN -1 --Failure. Reason: Both @cols_to_include and @cols_to_exclude parameters are specified
 END
--Making sure the @cols_to_include and @cols_to_exclude parameters are receiving values in proper format
IF ((@cols_to_include IS NOT NULL) AND (PATINDEX('''%''',@cols_to_include) = 0))
 BEGIN
  RAISERROR('Invalid use of @cols_to_include property',16,1)
  PRINT 'Specify column names surrounded by single quotes and separated by commas'
  PRINT 'Eg: EXEC sp_generate_inserts titles, @cols_to_include = "''title_id'',''title''"'
  RETURN -1 --Failure. Reason: Invalid use of @cols_to_include property
 END
IF ((@cols_to_exclude IS NOT NULL) AND (PATINDEX('''%''',@cols_to_exclude) = 0))
 BEGIN
  RAISERROR('Invalid use of @cols_to_exclude property',16,1)
  PRINT 'Specify column names surrounded by single quotes and separated by commas'
  PRINT 'Eg: EXEC sp_generate_inserts titles, @cols_to_exclude = "''title_id'',''title''"'
  RETURN -1 --Failure. Reason: Invalid use of @cols_to_exclude property
 END

--Checking to see if the database name is specified along wih the table name
--Your database context should be local to the table for which you want to generate INSERT statements
--specifying the database name is not allowed
IF (PARSENAME(@table_name,3)) IS NOT NULL
 BEGIN
  RAISERROR('Do not specify the database name. Be in the required database and just specify the table name.',16,1)
  RETURN -1 --Failure. Reason: Database name is specified along with the table name, which is not allowed
 END
--Checking for the existence of 'user table' or 'view'
--This procedure is not written to work on system tables
--To script the data in system tables, just create a view on the system tables and script the view instead
IF @owner IS NULL
 BEGIN
  IF ((OBJECT_ID(@table_name,'U') IS NULL) AND (OBJECT_ID(@table_name,'V') IS NULL)) 
   BEGIN
    RAISERROR('User table or view not found.',16,1)
    PRINT 'You may see this error, if you are not the owner of this table or view. In that case use @owner parameter to specify the owner name.'
    PRINT 'Make sure you have SELECT permission on that table or view.'
    RETURN -1 --Failure. Reason: There is no user table or view with this name
   END
 END
ELSE
 BEGIN
  IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @table_name AND (TABLE_TYPE = 'BASE TABLE' OR TABLE_TYPE = 'VIEW') AND TABLE_SCHEMA = @owner)
   BEGIN
    RAISERROR('User table or view not found.',16,1)
    PRINT 'You may see this error, if you are not the owner of this table. In that case use @owner parameter to specify the owner name.'
    PRINT 'Make sure you have SELECT permission on that table or view.'
    RETURN -1 --Failure. Reason: There is no user table or view with this name  
   END
 END
--Variable declarations
DECLARE  @Column_ID int,   
  @Column_List varchar(8000), 
  @Column_Name varchar(128), 
  @Start_Insert varchar(786), 
  @Data_Type varchar(128), 
  @Actual_Values varchar(8000), --This is the string that will be finally executed to generate INSERT statements
  @IDN varchar(128)  --Will contain the IDENTITY column's name in the table
--Variable Initialization
SET @IDN = ''
SET @Column_ID = 0
SET @Column_Name = ''
SET @Column_List = ''
SET @Actual_Values = ''
IF @owner IS NULL 
 BEGIN
  SET @Start_Insert = 'INSERT INTO ' + '[' + RTRIM(COALESCE(@target_table,@table_name)) + ']' 
 END
ELSE
 BEGIN
  SET @Start_Insert = 'INSERT ' + '[' + LTRIM(RTRIM(@owner)) + '].' + '[' + RTRIM(COALESCE(@target_table,@table_name)) + ']'   
 END

--To get the first column's ID
SELECT @Column_ID = MIN(ORDINAL_POSITION)  
FROM INFORMATION_SCHEMA.COLUMNS (NOLOCK) 
WHERE  TABLE_NAME = @table_name AND
(@owner IS NULL OR TABLE_SCHEMA = @owner)
 
--Loop through all the columns of the table, to get the column names and their data types
WHILE @Column_ID IS NOT NULL
 BEGIN
  SELECT  @Column_Name = QUOTENAME(COLUMN_NAME), 
  @Data_Type = DATA_TYPE 
  FROM  INFORMATION_SCHEMA.COLUMNS (NOLOCK) 
  WHERE  ORDINAL_POSITION = @Column_ID AND 
  TABLE_NAME = @table_name AND
  (@owner IS NULL OR TABLE_SCHEMA = @owner)
 
  IF @cols_to_include IS NOT NULL --Selecting only user specified columns
  BEGIN
   IF CHARINDEX( '''' + SUBSTRING(@Column_Name,2,LEN(@Column_Name)-2) + '''',@cols_to_include) = 0 
   BEGIN
    GOTO SKIP_LOOP
   END
  END
  IF @cols_to_exclude IS NOT NULL --Selecting only user specified columns
  BEGIN
   IF CHARINDEX( '''' + SUBSTRING(@Column_Name,2,LEN(@Column_Name)-2) + '''',@cols_to_exclude) <> 0 
   BEGIN
    GOTO SKIP_LOOP
   END
  END
  --Making sure to output SET IDENTITY_INSERT ON/OFF in case the table has an IDENTITY column
  IF (SELECT COLUMNPROPERTY( OBJECT_ID(QUOTENAME(COALESCE(@owner,USER_NAME())) + '.' + @table_name),SUBSTRING(@Column_Name,2,LEN(@Column_Name) - 2),'IsIdentity')) = 1 
  BEGIN
   IF @ommit_identity = 0 --Determing whether to include or exclude the IDENTITY column
    SET @IDN = @Column_Name
   ELSE
    GOTO SKIP_LOOP   
  END
  
  --Making sure whether to output computed columns or not
  IF @ommit_computed_cols = 1
  BEGIN
   IF (SELECT COLUMNPROPERTY( OBJECT_ID(QUOTENAME(COALESCE(@owner,USER_NAME())) + '.' + @table_name),SUBSTRING(@Column_Name,2,LEN(@Column_Name) - 2),'IsComputed')) = 1 
   BEGIN
    GOTO SKIP_LOOP     
   END
  END
  
  --Tables with columns of IMAGE data type are not supported for obvious reasons
  IF(@Data_Type in ('image'))
   BEGIN
    IF (@ommit_images = 0)
     BEGIN
      RAISERROR('Tables with image columns are not supported.',16,1)
      PRINT 'Use @ommit_images = 1 parameter to generate INSERTs for the rest of the columns.'
      PRINT 'DO NOT ommit Column List in the INSERT statements. If you ommit column list using @include_column_list=0, the generated INSERTs will fail.'
      RETURN -1 --Failure. Reason: There is a column with image data type
     END
    ELSE
     BEGIN
     GOTO SKIP_LOOP
     END
   END
  --Determining the data type of the column and depending on the data type, the VALUES part of
  --the INSERT statement is generated. Care is taken to handle columns with NULL values. Also
  --making sure, not to lose any data from flot, real, money, smallmomey, datetime columns
  SET @Actual_Values = @Actual_Values  +
  CASE 
   WHEN @Data_Type IN ('char','varchar','nchar','nvarchar') 
    THEN 
     'COALESCE('''''''' + REPLACE(RTRIM(' + @Column_Name + '),'''''''','''''''''''')+'''''''',''NULL'')'
   WHEN @Data_Type IN ('datetime','smalldatetime') 
    THEN 
     'COALESCE('''''''' + RTRIM(CONVERT(char,' + @Column_Name + ',109))+'''''''',''NULL'')'
   WHEN @Data_Type IN ('uniqueidentifier') 
    THEN  
     'COALESCE('''''''' + REPLACE(CONVERT(char(255),RTRIM(' + @Column_Name + ')),'''''''','''''''''''')+'''''''',''NULL'')'
   WHEN @Data_Type IN ('text','ntext') 
    THEN  
     'COALESCE('''''''' + REPLACE(CONVERT(char(8000),' + @Column_Name + '),'''''''','''''''''''')+'''''''',''NULL'')'     
   WHEN @Data_Type IN ('binary','varbinary') 
    THEN  
     'COALESCE(RTRIM(CONVERT(char,' + 'CONVERT(int,' + @Column_Name + '))),''NULL'')'  
   WHEN @Data_Type IN ('timestamp','rowversion') 
    THEN  
     CASE 
      WHEN @include_timestamp = 0 
       THEN 
        '''DEFAULT''' 
       ELSE 
        'COALESCE(RTRIM(CONVERT(char,' + 'CONVERT(int,' + @Column_Name + '))),''NULL'')'  
     END
   WHEN @Data_Type IN ('float','real','money','smallmoney')
    THEN
     'COALESCE(LTRIM(RTRIM(' + 'CONVERT(char, ' +  @Column_Name  + ',2)' + ')),''NULL'')' 
   ELSE 
    'COALESCE(LTRIM(RTRIM(' + 'CONVERT(char, ' +  @Column_Name  + ')' + ')),''NULL'')' 
  END   + '+' +  ''',''' + ' + '
  
  --Generating the column list for the INSERT statement
  SET @Column_List = @Column_List +  @Column_Name + ',' 
  SKIP_LOOP: --The label used in GOTO
  SELECT  @Column_ID = MIN(ORDINAL_POSITION) 
  FROM  INFORMATION_SCHEMA.COLUMNS (NOLOCK) 
  WHERE  TABLE_NAME = @table_name AND 
  ORDINAL_POSITION > @Column_ID AND
  (@owner IS NULL OR TABLE_SCHEMA = @owner)

 --Loop ends here!
 END
--To get rid of the extra characters that got concatenated during the last run through the loop
SET @Column_List = LEFT(@Column_List,len(@Column_List) - 1)
SET @Actual_Values = LEFT(@Actual_Values,len(@Actual_Values) - 6)
IF LTRIM(@Column_List) = '' 
 BEGIN
  RAISERROR('No columns to select. There should at least be one column to generate the output',16,1)
  RETURN -1 --Failure. Reason: Looks like all the columns are ommitted using the @cols_to_exclude parameter
 END
--Forming the final string that will be executed, to output the INSERT statements
IF (@include_column_list <> 0)
 BEGIN
  SET @Actual_Values = 
   'SELECT ' +  
   CASE WHEN @top IS NULL OR @top < 0 THEN '' ELSE ' TOP ' + LTRIM(STR(@top)) + ' ' END + 
   '''' + RTRIM(@Start_Insert) + 
   ' ''+' + '''(' + RTRIM(@Column_List) +  '''+' + ''')''' + 
   ' +''VALUES(''+ ' +  @Actual_Values  + '+'')''' + ' ' + 
   COALESCE(@from,' FROM ' + CASE WHEN @owner IS NULL THEN '' ELSE '[' + LTRIM(RTRIM(@owner)) + '].' END + '[' + rtrim(@table_name) + ']' + '(NOLOCK)')
 END
ELSE IF (@include_column_list = 0)
 BEGIN
  SET @Actual_Values = 
   'SELECT ' + 
   CASE WHEN @top IS NULL OR @top < 0 THEN '' ELSE ' TOP ' + LTRIM(STR(@top)) + ' ' END + 
   '''' + RTRIM(@Start_Insert) + 
   ' '' +''VALUES(''+ ' +  @Actual_Values + '+'')''' + ' ' + 
   COALESCE(@from,' FROM ' + CASE WHEN @owner IS NULL THEN '' ELSE '[' + LTRIM(RTRIM(@owner)) + '].' END + '[' + rtrim(@table_name) + ']' + '(NOLOCK)')
 END 
--Determining whether to ouput any debug information
IF @debug_mode =1
 BEGIN
  PRINT '/*****START OF DEBUG INFORMATION*****'
  PRINT 'Beginning of the INSERT statement:'
  PRINT @Start_Insert
  PRINT ''
  PRINT 'The column list:'
  PRINT @Column_List
  PRINT ''
  PRINT 'The SELECT statement executed to generate the INSERTs'
  PRINT @Actual_Values
  PRINT ''
  PRINT '*****END OF DEBUG INFORMATION*****/'
  PRINT ''
 END
  
-- PRINT '--INSERTs generated by ''sp_generate_inserts'' stored procedure written by Vyas'
-- PRINT '--Build number: 22'
-- PRINT '--Problems/Suggestions? Contact Vyas @ vyaskn@hotmail.com'
-- PRINT '--http://vyaskn.tripod.com'
-- PRINT ''
-- PRINT 'SET NOCOUNT ON'
-- PRINT ''

--Determining whether to print IDENTITY_INSERT or not
IF (@IDN <> '')
 BEGIN
  PRINT 'SET IDENTITY_INSERT ' + QUOTENAME(COALESCE(@owner,USER_NAME())) + '.' + QUOTENAME(@table_name) + ' ON'
  PRINT 'GO'
  PRINT ''
 END

IF @disable_constraints = 1 AND (OBJECT_ID(QUOTENAME(COALESCE(@owner,USER_NAME())) + '.' + @table_name, 'U') IS NOT NULL)
 BEGIN
  IF @owner IS NULL
   BEGIN
    SELECT  'ALTER TABLE ' + QUOTENAME(COALESCE(@target_table, @table_name)) + ' NOCHECK CONSTRAINT ALL' AS '--Code to disable constraints temporarily'
   END
  ELSE
   BEGIN
    SELECT  'ALTER TABLE ' + QUOTENAME(@owner) + '.' + QUOTENAME(COALESCE(@target_table, @table_name)) + ' NOCHECK CONSTRAINT ALL' AS '--Code to disable constraints temporarily'
   END
  PRINT 'GO'
 END
PRINT ''
PRINT 'PRINT ''Inserting values into ' + '[' + RTRIM(COALESCE(@target_table,@table_name)) + ']' + ''''

--All the hard work pays off here!!! You'll get your INSERT statements, when the next line executes!
EXEC (@Actual_Values)
PRINT 'PRINT ''Done'''
PRINT ''

IF @disable_constraints = 1 AND (OBJECT_ID(QUOTENAME(COALESCE(@owner,USER_NAME())) + '.' + @table_name, 'U') IS NOT NULL)
 BEGIN
  IF @owner IS NULL
   BEGIN
    SELECT  'ALTER TABLE ' + QUOTENAME(COALESCE(@target_table, @table_name)) + ' CHECK CONSTRAINT ALL'  AS '--Code to enable the previously disabled constraints'
   END
  ELSE
   BEGIN
    SELECT  'ALTER TABLE ' + QUOTENAME(@owner) + '.' + QUOTENAME(COALESCE(@target_table, @table_name)) + ' CHECK CONSTRAINT ALL' AS '--Code to enable the previously disabled constraints'
   END
  PRINT 'GO'
 END
PRINT ''
IF (@IDN <> '')
 BEGIN
  PRINT 'SET IDENTITY_INSERT ' + QUOTENAME(COALESCE(@owner,USER_NAME())) + '.' + QUOTENAME(@table_name) + ' OFF'
  PRINT 'GO'
 END
PRINT 'SET NOCOUNT OFF'

SET NOCOUNT OFF
RETURN 0 --Success. We are done!
END
GO
PRINT N'Creating [dbo].[SupplierDeletionsReport]...';


GO

/*
*********************************************************************************************************************
Procedure:	SupplierInclusionReport
Purpose:	Supplier Inclusion Report.
---------------------------------------------------------------------------------------------------------------------
Date			Developer				Notes
==========		===================		===============================
02/11/2013		SCA\TMPVJ1				Created
*********************************************************************************************************************
14037
37549
713
SupplierInclusionReport 2630
SupplierTimeReport

*/
CREATE procedure [dbo].[SupplierDeletionsReport]
	@supplierId int,
	@datefrom datetime = null,
	@dateto datetime  = null,
	@RangeType varchar(2)  ='N'
as
set nocount on


declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime

if(DatePart(Month,getdate()) < 7)
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
	end
else
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
	end

if @datefrom is NUll  or @datefrom ='1900-01-01 00:00:00'   Or @dateto is NUll  or @dateto ='1900-01-01 00:00:00' 
Begin
	if @RangeType ='F' --Fiscal year
		Begin
			print 'F'
			if @datefrom is NUll  or @datefrom ='1900-01-01 00:00:00'
				set @datefrom=@firstDayOfYear

			if @dateto is NUll  or @dateto ='1900-01-01 00:00:00'
				set @dateto=@firstDayOfNextYear
			
		end
	Else
		Begin
			print 'N'
			if @datefrom is NUll  or @datefrom ='1900-01-01 00:00:00'
				set @datefrom=DATEADD(Month,-12,GetDate())

			if @dateto is NUll  or @dateto ='1900-01-01 00:00:00'
				set @dateto=Getdate()
		end

End


declare @federalId nvarchar(20)
select @federalId = FederalId From Supplier
Where Id = @supplierId

select	distinct rp.SolicitationNo as 'C_SOLICIT', 
		Convert(nvarchar(max),rp.[Description]) as 'VC_DESCRIPTION',
		Convert(nvarchar(20),wf.DateCreated,100) as Rejection_date,
		Convert(nvarchar(2000),wf.Comments) as Rejection_Comments
From RfdProject rp
Inner join rfdsupplier rs on rs.RfdProjectId=rp.id
Inner Join WorkflowHistory wf on rs.TransactionId=wf.TransactionHeaderId
Inner Join WorkflowNode wn on wn.Id=wf.CurrentNodeId
inner join supplier s on s.id=rs.SupplierId
where wn.[Name] = 'Deleted'
And s.FederalId=@federalId
and rp.IsFinal='Y' and rp.ApprovalDate is not null
and rs.Status=4
AND wf.DateCreated between @datefrom and @dateto
GO
PRINT N'Creating [dbo].[SupplierRejectionsReport]...';


GO

/*
*********************************************************************************************************************
Procedure:	SupplierInclusionReport
Purpose:	Supplier Inclusion Report.
---------------------------------------------------------------------------------------------------------------------
Date			Developer				Notes
==========		===================		===============================
02/11/2013		SCA\TMPVJ1				Created
*********************************************************************************************************************
14037
37549
713
SupplierInclusionReport 2630
SupplierTimeReport

*/
CREATE procedure [dbo].[SupplierRejectionsReport]
	@supplierId int,
	@datefrom date = null,
	@dateto date  = null,
	@RangeType varchar(2)  ='N'
	
as
set nocount on


declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime
if(DatePart(Month,getdate()) < 7)
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
	end
else
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
	end

if @datefrom is NUll  or @datefrom ='1900-01-01 00:00:00'   Or @dateto is NUll  or @dateto ='1900-01-01 00:00:00' 
Begin
	if @RangeType ='F' --Fiscal year
		Begin
			print 'F'
			if @datefrom is NUll  or @datefrom ='1900-01-01 00:00:00'
				set @datefrom=@firstDayOfYear

			if @dateto is NUll  or @dateto ='1900-01-01 00:00:00'
				set @dateto=@firstDayOfNextYear
			
		end
	Else
		Begin
			print 'N'
			if @datefrom is NUll  or @datefrom ='1900-01-01 00:00:00'
				set @datefrom=DATEADD(Month,-12,GetDate())

			if @dateto is NUll  or @dateto ='1900-01-01 00:00:00'
				set @dateto=Getdate()
		end

End

declare @federalId nvarchar(20)
select @federalId = FederalId From Supplier
Where Id = @supplierId

select	distinct rp.SolicitationNo as 'C_SOLICIT', 
		Convert(nvarchar(max),rp.[Description]) as 'VC_DESCRIPTION',
		Convert(nvarchar(20),wf.DateCreated,100) as Rejection_date,
		Convert(nvarchar(2000),wf.Comments) as Rejection_Comments
From RfdProject rp
Inner join rfdsupplier rs on rs.RfdProjectId=rp.id
Inner Join WorkflowHistory wf on rs.TransactionId=wf.TransactionHeaderId
Inner Join WorkflowNode wn on wn.Id=wf.CurrentNodeId
inner join supplier s on s.id=rs.SupplierId
where wn.[Name] = 'Rejected'
And s.FederalId=@federalId
and rp.IsFinal='Y' and rp.ApprovalDate is not null
and rs.status=3
AND wf.DateCreated between @datefrom and @dateto
GO
PRINT N'Creating [dbo].[usp_MentorBidActivityReport]...';


GO
PRINT N'Refreshing [dbo].[GetPlanByContractXml]...';


GO
SET QUOTED_IDENTIFIER ON;

SET ANSI_NULLS OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[GetPlanByContractXml]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Refreshing [dbo].[GetPlanByIdXml]...';


GO
SET ANSI_NULLS ON;

SET QUOTED_IDENTIFIER OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[GetPlanByIdXml]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Refreshing [dbo].[GetPlanByProjectXml]...';


GO
SET QUOTED_IDENTIFIER ON;

SET ANSI_NULLS OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[GetPlanByProjectXml]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Refreshing [dbo].[FindOutlookByUserXml]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[FindOutlookByUserXml]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Refreshing [dbo].[OutlookByProcessingUnitByUserAllAgingReport]...';


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[OutlookByProcessingUnitByUserAllAgingReport]';


GO
PRINT N'Refreshing [dbo].[OutlookByProcessingUnitByUserReport]...';


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[OutlookByProcessingUnitByUserReport]';


GO
PRINT N'Update complete.';


GO
Insert into dw_v_project_dates_ntp_subcomp
SELECT *  from openquery(NYCSCA_DW,'select * from dwstar.v_project_dates_ntp_subcomp')

