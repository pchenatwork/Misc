USE [msdb]
GO

/****** Object:  Job [Refresh In Progress OIG Views]    Script Date: 5/31/2019 1:25:43 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 5/31/2019 1:25:43 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Refresh In Progress OIG Views', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'aec', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OIG_Banking_1]    Script Date: 5/31/2019 1:25:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OIG_Banking_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [NYCSCA_VAS_STAGE]
GO
/****** Object:  View [dbo].[OIG_Banking_1]    Script Date: 8/21/2017 10:06:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER VIEW [dbo].[OIG_Banking_1]
AS
SELECT        
v.federalId AS TaxId, 
sa.Type AS Source, 
'''' AS Amt, 
'''' AS Balance, 
'''' AS TerminDte, 
sa.BankName AS BankCaption, 
'''' AS BorrowerCounty, 
sa.Type AS accttypcourt, 
'''' AS Terms, 
'''' AS Guarantor, 
sa.PersonnelIds AS Sigs, 
'''' AS OffFName, 
'''' AS OffLName, 
'''' AS OffPhone, 
sa.Id AS AddSeq, 
STUFF
((SELECT        '', '' + sp.name + ''|'' + CONVERT(varchar, id)
    FROM            supplierpersonnel sp INNER JOIN
                            dbo.split(sa.PersonnelIds, ''|'') l ON l.item = sp.id FOR XML PATH(''''), TYPE ).value(''.'', ''nvarchar(max)''), 1, 2, '' '') AS UserSigs,
STUFF
((SELECT        '', '' + replace(sp.name,''|'','' '')
    FROM            supplierpersonnel sp INNER JOIN
                            dbo.split(sa.PersonnelIds, ''|'') l ON l.item = sp.id FOR XML PATH(''''), TYPE ).value(''.'', ''nvarchar(max)''), 1, 2, '' '') AS UserSigsParsed



FROM            (SELECT        v.currentsupplierid AS supplierId, v.Id, v.federalId, wh.datecreated
                          FROM            vendor v INNER JOIN
                                                        (SELECT        *
                                                          FROM            supplierworkflow
                                                          WHERE        workflowtype = ''Supplier Prequalification'') sw ON v.currentsupplierId = sw.supplierid INNER JOIN
                                                        (SELECT        *
                                                          FROM            workflowhistory
                                                          WHERE        currentnodeid = 111 AND isnull(datecreated, ''1900/1/1'') <> ''1900/1/1'') wh ON sw.transactionid = wh.transactionheaderId LEFT JOIN
                                                    tempvendor t ON v.currentsupplierId = t .supplierId
                          WHERE        t .supplierId IS NULL) v LEFT JOIN
                         SupplierAccount sa ON v.supplierId = sa.supplierId
UNION ALL
SELECT        v.federalId AS TaxId, case when sc.IsRevolving = ''y'' then ''Revolving Credit'' else ''Credit'' end AS Source, sc.CreditAmount AS Amt, sc.OwnedAmount AS Balance, sc.EndDate AS TerminDte, sc.InstitutionName AS BankCaption, '''' AS BorrowerCounty, '''' AS accttypcourt, '''' AS Terms, '''' AS Guarantor, 
                         '''' AS Sigs, sc.officername AS OffFName, '''' AS OffLName, sc.Phone + sc.Extension AS OffPhone, '''' AS AddSeq, '''' AS UserSigs, '''' AS UserSigsParsed
FROM            (SELECT        v.currentsupplierid AS supplierId, v.Id, v.federalId, wh.datecreated
                          FROM            vendor v INNER JOIN
                                                        (SELECT        *
                                                          FROM            supplierworkflow
                                                          WHERE        workflowtype = ''Supplier Prequalification'') sw ON v.currentsupplierId = sw.supplierid INNER JOIN
                                                        (SELECT        *
                                                          FROM            workflowhistory
                                                          WHERE        currentnodeid = 111 AND isnull(datecreated, ''1900/1/1'') <> ''1900/1/1'') wh ON sw.transactionid = wh.transactionheaderId LEFT JOIN
                                                    tempvendor t ON v.currentsupplierId = t .supplierId
                          WHERE        t .supplierId IS NULL) v LEFT JOIN
                         SupplierCredit sc ON v.supplierId = sc.supplierId
UNION ALL
SELECT        v.federalId AS TaxId, sd.type AS source, sd.LoanedAmount AS Amt, sd.OwnedAmount AS Balance, '''' AS TerminDte, 
                         sd.Creditor AS BankCaption, sd.Borrower AS BorrowerCounty, sd.Type AS accttypcourt, sd.Terms AS Terms, sd.GuarantorName AS Guarantor, '''' AS Sigs, '''' AS OffFName, '''' AS OffLName, '''' AS OffPhone, '''' AS AddSeq, 
                         '''' AS UserSigs, '''' AS UserSigsParsed
FROM            (SELECT        v.currentsupplierid AS supplierId, v.Id, v.federalId, wh.datecreated
                          FROM            vendor v INNER JOIN
                                                        (SELECT        *
                                                          FROM            supplierworkflow
                                                          WHERE        workflowtype = ''Supplier Prequalification'') sw ON v.currentsupplierId = sw.supplierid INNER JOIN
                                                        (SELECT        *
                                                          FROM            workflowhistory
                                                          WHERE        currentnodeid = 111 AND isnull(datecreated, ''1900/1/1'') <> ''1900/1/1'') wh ON sw.transactionid = wh.transactionheaderId LEFT JOIN
                                                    tempvendor t ON v.currentsupplierId = t .supplierId
                          WHERE        t .supplierId IS NULL) v LEFT JOIN
                         SupplierDebt sd ON v.supplierId = sd.supplierId

GO

/****** 
SELECT [TaxId]
      ,[Source]
      ,[Amt]
      ,[Balance]
      ,[TerminDte]
      ,[BankCaption]
      ,[BorrowerCounty]
      ,[accttypcourt]
      ,[Terms]
      ,[Guarantor]
      ,[Sigs]
      ,[OffFName]
      ,[OffLName]
      ,[OffPhone]
      ,[AddSeq]
      ,[UserSigs]
	  ,[UserSigsParsed]
  FROM [NYCSCA_VAS_STAGE].[dbo].[OIG_Banking_1]
where taxid = ''11-3469852''
******/

', 
		@database_name=N'NYCSCA_VAS_STAGE', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OIG_Prequal]    Script Date: 5/31/2019 1:25:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OIG_Prequal', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [NYCSCA_VAS_STAGE]
GO

/****** Object:  View [dbo].[OIG_Prequal]    Script Date: 9/27/2017 7:52:41 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 
ALTER view [dbo].[OIG_Prequal]
as
   SELECT top(5000)
  v.FederalId AS TaxId, 
  CONVERT(VARCHAR(10), 
  v.DateCreated, 101) AS [Reviewer Reviewed Date], 
  s.Company, 
  CASE s.legalstructure WHEN ''sol'' THEN ''Propietorship'' 
				        WHEN ''Cor'' THEN ''Corporation'' 
					    WHEN ''Llc'' THEN ''LLC'' 
					    WHEN ''Gen'' THEN ''Partnership'' 
					    WHEN ''Oth'' THEN ''Other'' END AS OrgType, 
  s.StateIncorporation AS IncState,
  sp2.propertydate AS DteForm, 
  sp2.DateAsText TxtFrom, 
  sp8.PropertyDate AS IncDte, 
  sp6.PropertyText AS IncShareAuth, 
  sp7.PropertyText AS IncShareIssue, 
  CASE sp9.propertyvalue WHEN ''-1'' THEN '''' ELSE sp9.propertyvalue END AS LLCNum, 
  sp11.PropertyText AS PrtnrCnty, 
  sp12.PropertyText AS OtherExplain, 
  sp82.PropertyText AS Share, 
  srf.CompanyName AS ShrCompany1, 
  srf.CompanyTaxId AS ShrTIN1, 
  srf.CompanyDescription AS ShrNature1, 
  sp43.PropertyText AS PurchFrom, 
  sp44.PropertyText AS PaidInFull, 
  sp45.PropertyDate AS PurchDte, 
  sp57.PropertyValue AS EmpNo, 
  sp58.PropertyValue AS SafeHrsWorked, 
  sp59.PropertyText AS SafeWritPrgm, 
  sp60.PropertyText AS SafeRankEmp, 
  sp61.PropertyText AS SafeRankEmpTitle, 
  sp62.PropertyText AS SafeEMR, 
  sp63.PropertyValue AS SafeOSHAIncidents, 
  sp64.PropertyValue AS SafeLost, 
  sp65.PropertyValue AS SafeFatal, 
  sp66.PropertyText AS SafePaidFine, 
  sp67.PropertyText AS SafePaidFineExpl, 
  dbo.GetCertType(v.supplierId) as MWLBE,
  vcp.Name as PrimaryContactName,
  vcp.Title as PrimaryContactTitle,
  vcp.Phone as PrimaryContactPhone,
  vcp.Extension as PrimaryContactExtension,
  vcp.Fax as PrimaryContactFax,
  vcp.Email as PrimaryContactEmail,
  vcs.Name as SecondaryContactName,
  vcs.Title as SecondaryContactTitle,
  vcs.Phone as SecondaryContactPhone,
  vcs.Extension as SecondaryContactExtension,
  vcs.Fax as SecondaryContactFax,
  vcs.Email as SecondaryContactEmail
FROM            (SELECT        v.CurrentSupplierId AS supplierId, v.Id, v.FederalId, wh.DateCreated
                          FROM            dbo.Vendor AS v INNER JOIN
                                                        (SELECT        s.Id, s.FederalId
                                                          FROM            dbo.Supplier AS s INNER JOIN
                                                                                    dbo.Vendor AS v1 ON s.FederalId = v1.FederalId LEFT OUTER JOIN
                                                                                    dbo.SupplierStatus AS ss ON s.Id = ss.SupplierId AND ss.TypeName = ''Supplier Prequalification'' LEFT OUTER JOIN
                                                                                    dbo.SupplierVersion AS sv ON s.Id = sv.SupplierId LEFT OUTER JOIN
                                                                                    dbo.SupplierProperty AS sp2 ON s.Id = sp2.SupplierId AND sp2.PropertyId = 508 LEFT OUTER JOIN
                                                                                    dbo.SupplierWorkflow AS sw ON s.Id = sw.SupplierId AND sw.WorkflowId = 1 LEFT OUTER JOIN
                                                                                    dbo.WorkflowHistory AS wh1 ON sw.TransactionId = wh1.TransactionHeaderId LEFT OUTER JOIN
                                                                                    dbo.SupplierStaticQualification AS sq ON s.Id = sq.SupplierId
                                                          WHERE        (ISNULL(ss.Status, N'''') IN (''OIG Pending'', ''Qualified Pending'', ''Qualified'')) AND (ISNULL(CONVERT(nvarchar(500), sp2.PropertyText), N'''') 
                                                                                    = '''') AND (wh1.CurrentNodeId = 488) AND (ISNULL(sq.V_C_APPR_IG, '''') <> ''Y'') AND (sv.Status IS NULL OR
                                                                              sv.Status <> 0)
                                                          UNION
                                                          SELECT        s.Id, s.FederalId
                                                          FROM            dbo.Supplier AS s LEFT OUTER JOIN
                                                                                   dbo.SupplierStatus AS ss ON s.Id = ss.SupplierId AND ss.TypeName = ''Supplier Prequalification'' LEFT OUTER JOIN
                                                                                   dbo.SupplierVersion AS sv ON s.Id = sv.SupplierId
                                                          WHERE        (ISNULL(ss.Status, N'''') IN (''Reference Reviewed'', ''Financial Reviewed'', ''Reference and Financial Reviewed'')) AND (sv.Status IS NULL OR
                                                                                   sv.Status <> 0)) AS c ON c.FederalId = v.FederalId INNER JOIN
                                                        (SELECT        Id, SupplierId, WorkflowId, TransactionId, WorkflowType, BusinessUnitId, TransferredFlag
                                                          FROM            dbo.SupplierWorkflow
                                                          WHERE        (WorkflowType = ''Supplier Prequalification'')) AS sw ON v.CurrentSupplierId = sw.SupplierId INNER JOIN
                                                        (SELECT        Id, TransactionHeaderId, WorkflowId, CurrentNodeId, ApprovalUserId, ApprovalRoleId, ApprovalConditionId, ApprovalDate, PrevHistoryId, 
                                                                                    Status, IsActive, Comments, DateCreated, CreatedBy, Version, CreatedType, DelegatorId
                                                          FROM            dbo.WorkflowHistory
                                                          WHERE        (CurrentNodeId = 111) AND (ISNULL(DateCreated, ''1900/1/1'') <> ''1900/1/1'')) AS wh ON 
                                                    sw.TransactionId = wh.TransactionHeaderId LEFT OUTER JOIN
                                                    dbo.TempVendor AS t ON v.CurrentSupplierId = t.SupplierId
                          WHERE        (t.SupplierId IS NULL)) AS v LEFT OUTER JOIN
                         dbo.Supplier AS s ON v.supplierId = s.Id LEFT OUTER JOIN
							--Property02 is Formed Date, VAS stores in the text column and not the property date column
                             (SELECT        
								Id, 
								SupplierId, 
								ParentId, 
								PropertyId, 
								PropertyValue,
								PropertyDate, 
								PropertyText, 
								Selected, 
								AttachmentId, 
								AttachmentName, 
								ChangeDate, 
                                ChangeUser, 
								case when propertydate  = CONVERT(DATE,''1900-01-01'') then PropertyText else FORMAT(propertydate, ''MM/yyyy'') end as DateAsText
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 2)) AS sp2 ON v.supplierId = sp2.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 5)) AS sp5 ON v.supplierId = sp5.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 6)) AS sp6 ON v.supplierId = sp6.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 7)) AS sp7 ON v.supplierId = sp7.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 9)) AS sp9 ON v.supplierId = sp9.SupplierId LEFT OUTER JOIN
							   (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 8)) AS sp8 ON v.supplierId = sp8.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 11)) AS sp11 ON v.supplierId = sp11.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 12)) AS sp12 ON v.supplierId = sp12.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 82)) AS sp82 ON v.supplierId = sp82.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, Type, ChangeType, LocationType, HolderName, StartDate, EndDate, FirmId, QuestionIds, PersonnelIds, DocumentIds, Present, 
                                                         ChangeUser, ChangeDate
                               FROM            dbo.SupplierBusinessMixedInfo
                               WHERE        (Type = ''AddShared'')) AS sbm ON v.supplierId = sbm.SupplierId LEFT OUTER JOIN
                         dbo.SupplierRelatedFirm AS srf ON sbm.FirmId = srf.Id LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 43)) AS sp43 ON v.supplierId = sp43.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 44)) AS sp44 ON v.supplierId = sp44.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 45)) AS sp45 ON v.supplierId = sp45.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 57)) AS sp57 ON v.supplierId = sp57.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 58)) AS sp58 ON v.supplierId = sp58.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 59)) AS sp59 ON v.supplierId = sp59.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 60)) AS sp60 ON v.supplierId = sp60.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 61)) AS sp61 ON v.supplierId = sp61.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 62)) AS sp62 ON v.supplierId = sp62.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 63)) AS sp63 ON v.supplierId = sp63.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 64)) AS sp64 ON v.supplierId = sp64.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 65)) AS sp65 ON v.supplierId = sp65.SupplierId LEFT OUTER JOIN
                    (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 66)) AS sp66 ON v.supplierId = sp66.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 67)) AS sp67 ON v.supplierId = sp67.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 69)) AS sp69 ON v.supplierId = sp69.SupplierId

left outer join VendorContact vcp
on vcp.VendorId = v.Id and vcp.ContactType = ''primary'' 
left outer join VendorContact vcs
on vcs.VendorId = v.Id and vcs.ContactType = ''secondary'' 
ORDER BY v.DateCreated


GO


', 
		@database_name=N'NYCSCA_VAS_STAGE', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OIG_Employee]    Script Date: 5/31/2019 1:25:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OIG_Employee', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [NYCSCA_VAS_STAGE]
GO

/****** Object:  View [dbo].[OIG_Employee]    Script Date: 12/29/2017 9:25:08 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER VIEW [dbo].[OIG_Employee]
AS
SELECT        

v.federalId AS TaxId, 
''Contact'' AS source, 
vc.FName AS FName, 
vc.LName AS LName, 
vc.NameSuffix,
'''' AS DOB, 
'''' AS SSN, 
vc.title AS Title, '''' AS AlienNo, '''' AS PctOwn, '''' AS Shares, '''' AS HowAcq, '''' AS Alias, '''' AS FromDte, '''' AS ToDte, 
                         '''' AS FiledOfExp, '''' AS YrsExp, '''' AS LicNo, '''' AS LicExp, '''' AS AddrSeq
FROM            (SELECT        v.currentsupplierid AS supplierId, v.Id, v.federalId, wh.datecreated
                          FROM            vendor v INNER JOIN
                                                        (SELECT        *
                                                          FROM            supplierworkflow
                                                          WHERE        workflowtype = ''Supplier Prequalification'') sw ON v.currentsupplierId = sw.supplierid INNER JOIN
                                                        (SELECT        *
                                                          FROM            workflowhistory
                                                          WHERE        currentnodeid = 111 AND isnull(datecreated, ''1900/1/1'') <> ''1900/1/1'') wh ON sw.transactionid = wh.transactionheaderId LEFT JOIN
                                                    tempvendor t ON v.currentsupplierId = t .supplierId
                          WHERE        t .supplierId IS NULL) v /*	(select * from vendorcontact where contacttype=''Primary'' or  contacttype=''Secondary'') vc*/ LEFT JOIN
                             (SELECT        dbo.GetItemFromSplitedList(name, ''|'', 2) AS FName, dbo.GetItemFromSplitedList(name, ''|'', 4) AS LName,  dbo.GetItemFromSplitedList(name, ''|'',5) AS NameSuffix, supplierid, CASE WHEN Title = ''PRT'' THEN ''Partner'' ELSE Title END Title
                               FROM            [SupplierPersonnel]) vc ON v.supplierId = vc.supplierid
UNION ALL
SELECT        
	v.federalId AS TaxId, 
	CASE WHEN l.Id IS NOT NULL THEN ''License'' 
		 WHEN dbo.DecryptField(sp.SSN, DEFAULT) != '''' THEN ''Key Person''
		 WHEN dbo.DecryptField(sp.SSN, DEFAULT) = '''' THEN ''Personnel'' 		
		 ELSE '''' END source, 
    dbo.GetItemFromSplitedList(sp.name, ''|'', 2) AS FName, /*sp.name as FName,*/ 
	dbo.GetItemFromSplitedList(sp.name, ''|'', 4) AS LName, 
	dbo.GetItemFromSplitedList(sp.name, ''|'', 5) AS NameSuffix, 

	CASE WHEN sp.DOB IS NOT NULL THEN format(dbo.decryptdateField(sp.DOB,DEFAULT),''M/d/yy'')
		 ELSE NULL END DOB,
	
 
	CASE WHEN l.Id IS NOT NULL THEN '''' 
	     WHEN dbo.DecryptField(sp.SSN, DEFAULT) = replace(v.federalId,''-'','''') THEN v.federalId 
		 ELSE dbo.DecryptField(sp.SSN, DEFAULT) END SSN, /*sp.SSN,*/ 
   CASE WHEN sp.Title = ''PRT'' THEN ''Partner'' ELSE sp.Title END Title, /*sp.Title,*/ dbo.DecryptField(sp.RegistrationNumber, DEFAULT) AS AlienNo, sp.OwnedPercentage AS PctOwn, 
                         sp.OwnedShares AS Shares, sp.HowSharesAcquired AS HowAcq, dbo.DecryptField(sp.comment, DEFAULT) AS Alias, sp.EmploymentStartDate AS FromDte, sp.EmploymentEndDate AS ToDte, spm.ExpertiseField AS FiledOfExp, 
                         spm.Totalyears AS YrsExp, l.LicenseNo AS LicNo, l.ExpirationDate AS LicExp, sp.Id AS AddrSeq
FROM            (SELECT        v.currentsupplierid AS supplierId, v.Id, v.federalId, wh.datecreated
                          FROM            vendor v INNER JOIN
                                                        (SELECT        *
                                                          FROM            supplierworkflow
                                                          WHERE        workflowtype = ''Supplier Prequalification'') sw ON v.currentsupplierId = sw.supplierid INNER JOIN
                                                        (SELECT        *
                                                          FROM            workflowhistory
                                                          WHERE        currentnodeid = 111 AND isnull(datecreated, ''1900/1/1'') <> ''1900/1/1'') wh ON sw.transactionid = wh.transactionheaderId LEFT JOIN
                                                    tempvendor t ON v.currentsupplierId = t .supplierId
                          WHERE        t .supplierId IS NULL) v LEFT JOIN
                         supplierpersonnel sp ON v.supplierId = sp.supplierId LEFT JOIN
                             (SELECT        *
                               FROM            supplierpersonnelMixedInfo
                               WHERE        type = ''AddExpert'') spm ON spm.personnelId = sp.Id LEFT JOIN
                         License L ON l.personnelId = sp.Id


GO


', 
		@database_name=N'NYCSCA_VAS_STAGE', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OIG_Address_]    Script Date: 5/31/2019 1:25:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OIG_Address_', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [NYCSCA_VAS_STAGE]
GO

/****** Object:  View [dbo].[OIG_Address_]    Script Date: 9/13/2017 11:56:59 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER view [dbo].[OIG_Address_]
as
SELECT        
v.FederalId AS TaxId, 
srf.Id AS AddrSeq, 
'''' AS source, 
'''' AS StNo, 
srf.AddressLine1 AS StName, 
srf.City, srf.State, 
srf.ZipCode, 
sup.Phone, 
sup.Fax,
sbm.SupplierId,
s.url,
s.email,
(
	select top 1 propertytext from supplierproperty where propertyid = 1 and supplierid = sbm.SupplierId
) as BusAdrType,
case when sbm.LocationType = ''Other'' then sbm.CHangeType else sbm.LocationType end ''LocationType''
FROM            
(SELECT        v.CurrentSupplierId AS supplierId, v.Id, v.FederalId, wh.DateCreated
FROM            dbo.Vendor AS v 
INNER JOIN
(SELECT        Id, SupplierId, WorkflowId, TransactionId, WorkflowType, BusinessUnitId, TransferredFlag
    FROM            dbo.SupplierWorkflow
    WHERE        (WorkflowType = ''Supplier Prequalification'')) AS sw 
ON v.CurrentSupplierId = sw.SupplierId 
INNER JOIN
(SELECT        Id, TransactionHeaderId, WorkflowId, CurrentNodeId, ApprovalUserId, ApprovalRoleId, ApprovalConditionId, ApprovalDate, PrevHistoryId, 
                            Status, IsActive, Comments, DateCreated, CreatedBy, Version, CreatedType, DelegatorId
    FROM            dbo.WorkflowHistory
    WHERE        (CurrentNodeId = 111) AND (ISNULL(DateCreated, ''1900/1/1'') <> ''1900/1/1'')) AS wh 
ON sw.TransactionId = wh.TransactionHeaderId 
LEFT OUTER JOIN dbo.TempVendor AS t
 ON v.CurrentSupplierId = t.SupplierId
WHERE        (t.SupplierId IS NULL)) 
AS v 
LEFT OUTER JOIN
(SELECT        Id, SupplierId, Type, ChangeType, LocationType, HolderName, StartDate, EndDate, FirmId, QuestionIds, PersonnelIds, DocumentIds, Present, 
                            ChangeUser, ChangeDate
FROM            dbo.SupplierBusinessMixedInfo
WHERE        (Type = ''AddPremise'')) AS sbm 
ON v.supplierId = sbm.SupplierId 
LEFT OUTER JOIN dbo.SupplierRelatedFirm AS srf ON sbm.FirmId = srf.Id
inner join dbo.supplier s on v.supplierid = s.id
left outer join supplier sup on sup.id = v.supplierid






GO


', 
		@database_name=N'NYCSCA_VAS_STAGE', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OIG_Affiliat]    Script Date: 5/31/2019 1:25:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OIG_Affiliat', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [NYCSCA_VAS_STAGE]
GO

/****** Object:  View [dbo].[OIG_Affiliat]    Script Date: 9/27/2017 9:04:24 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--OIG_Affiliat
ALTER view [dbo].[OIG_Affiliat]
as
select
	v.federalid as TaxId,
	replace(
	replace(
	replace(
	replace(
	replace( 
	replace(sbm.QuestionIds, 
			''84'',''Applicant been a subsidiary''), 
			''85'',''Applicant a partner''),
			''86'',''Applicant been a subsidiary''),
			''87'',''Joint Venture''),
			''88'',''Had a subsidiary''),
			''89'',''Applicant owns > 5% of another'') 
	as source,
	srf.companyname as Firm,
	srf.companyTaxId as TIN,
	srf.Relationship as Relation,
	srf.Percentage as PctOwnedByAnoth,
	'''' as RmndrBy,
	CAST(sbm.StartDate AS DATE) as FromDte,
	CAST(sbm.EndDate AS DATE) as ToDte,
	srf.RepresentativeName as Rep,
	srf.RepresentativeTitle as RepTitle,
	'''' as KPFName,
	'''' as KPLName,
	'''' as SCARel, 
	'''' as memo,
	srf.Id as AddrSeq
from
	(select
		v.currentsupplierid as supplierId, v.Id, v.federalId, wh.datecreated
	from 
		vendor v
	inner join
		(select * From supplierworkflow where workflowtype=''Supplier Prequalification'') sw
	on
		v.currentsupplierId = sw.supplierid
	inner join
		(select * From workflowhistory where currentnodeid = 111 and isnull(datecreated , ''1900/1/1'')<>''1900/1/1'') wh
	on
		sw.transactionid = wh.transactionheaderId
	left join
		tempvendor t
	on
		v.currentsupplierId = t.supplierId
	where
		t.supplierId is null) v
left join
	(select * from SupplierBusinessMixedInfo where type in (''AddFirm1'', ''AddFirm2'')) sbm
on
	v.supplierId = sbm.supplierId
left join
	supplierrelatedfirm srf
on
	sbm.firmId = srf.Id 


union all

select
	v.federalId as TaxId,
	replace(spm.QuestionIds, 
			''91'',''KP owns > 5% of another'')
	as source,
	srf.companyname as Firm,
	srf.companyTaxId as TIN,
	'''' as Relation,
	srf.Percentage as PctOwnedByAnoth,
	srf.RepresentativeName as RmndrBy,
	CAST(spm.StartDate AS DATE) as FromDte,
	CAST(spm.EndDate AS DATE) as ToDte,
	'''' as Rep,
	'''' as RepTitle,
	dbo.GetItemFromSplitedList(sp.name, ''|'', 1)  as KPFName,
	dbo.GetItemFromSplitedList(sp.name, ''|'', 3)  as KPLName,
	spm.employeeName as SCARel, 
	spm.Relationship as memo,
	srf.Id as AddrSeq
from
	(select
		v.currentsupplierid as supplierId, v.Id, v.federalId, wh.datecreated
	from 
		vendor v
	inner join
		(select * From supplierworkflow where workflowtype=''Supplier Prequalification'') sw
	on
		v.currentsupplierId = sw.supplierid
	inner join
		(select * From workflowhistory where currentnodeid = 111 and isnull(datecreated , ''1900/1/1'')<>''1900/1/1'') wh
	on
		sw.transactionid = wh.transactionheaderId
	left join
		tempvendor t
	on
		v.currentsupplierId = t.supplierId
	where
		t.supplierId is null) v
left join
	(select * from SupplierPersonnelMixedInfo where type in (''AddOwnOtherFirm'')) spm
on
	v.supplierId= spm.supplierId
left join
	supplierrelatedfirm srf
on
	spm.firmId = srf.Id 
left join
	supplierpersonnel sp
on
	spm.personnelId = sp.Id

union all

select
	v.federalId as TaxId,
	replace(
	replace( 
	replace(spm.QuestionIds, 
			''92'',''SCA employee''), 
			''93'',''SCA relative''),
			''94'',''SCA relative'')
	as source,
	'''' as Firm,
	'''' as TIN,
	'''' as Relation,
	'''' as PctOwnedByAnoth,
	'''' as RmndrBy,
	'''' as FromDte,
	'''' as ToDte,
	'''' as Rep,
	'''' as RepTitle,
	dbo.GetItemFromSplitedList(sp.name, ''|'', 1)  as KPFName,
	dbo.GetItemFromSplitedList(sp.name, ''|'', 3)  as KPLName,
	spm.employeeName as SCARel, 
	spm.Relationship as memo,
	'''' as AddrSeq
from
	(select
		v.currentsupplierid as supplierId, v.Id, v.federalId, wh.datecreated
	from 
		vendor v
	inner join
		(select * From supplierworkflow where workflowtype=''Supplier Prequalification'') sw
	on
		v.currentsupplierId = sw.supplierid
	inner join
		(select * From workflowhistory where currentnodeid = 111 and isnull(datecreated , ''1900/1/1'')<>''1900/1/1'') wh
	on
		sw.transactionid = wh.transactionheaderId
	left join
		tempvendor t
	on
		v.currentsupplierId = t.supplierId
	where
		t.supplierId is null) v
left join
	(select * from SupplierPersonnelMixedInfo where type in (''AddRelationship'')) spm
on
	v.supplierId = spm.supplierId
left join
	supplierpersonnel sp
on
	spm.personnelId = sp.Id



GO


', 
		@database_name=N'NYCSCA_VAS_STAGE', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OIG_Perfrmnc]    Script Date: 5/31/2019 1:25:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OIG_Perfrmnc', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [NYCSCA_VAS_STAGE]
GO

/****** Object:  View [dbo].[OIG_Perfrmnc]    Script Date: 9/27/2017 9:02:00 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--OIG_Perfrmnc
ALTER view [dbo].[OIG_Perfrmnc]
as
select
	v.federalId as TaxId,
	sp.agency as Owner,
	sp.Name as ProjName,
	sp.ContractNumber as CntrctNo,
	sp.Description as Describe,
	sp.ContractAmount as CntrctAmt,
	sp.startDate as DteBeg,
	sp.EndDate as DteEnd,
	replace(sp.RepresentativeName,''|'','' '') as SupervisorContact,
	sp.RepresentativePhone + sp.RepresentativeExtension as phone,
	sp.Id as AddrSeq
from
	(select
		v.currentsupplierid as supplierId, v.Id, v.federalId, wh.datecreated
	from 
		vendor v
	inner join
		(select * From supplierworkflow where workflowtype=''Supplier Prequalification'') sw
	on
		v.currentsupplierId = sw.supplierid
	inner join
		(select * From workflowhistory where currentnodeid = 111 and isnull(datecreated , ''1900/1/1'')<>''1900/1/1'') wh
	on
		sw.transactionid = wh.transactionheaderId
	left join
		tempvendor t
	on
		v.currentsupplierId = t.supplierId
	where
		t.supplierId is null) v
left join
	SupplierProject sp
on
	v.supplierId = sp.supplierId



GO


', 
		@database_name=N'NYCSCA_VAS_STAGE', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OIG_SUpplierPersonnel]    Script Date: 5/31/2019 1:25:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OIG_SUpplierPersonnel', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [NYCSCA_VAS_STAGE]
GO

/****** Object:  View [dbo].[OIG_SupplierPersonnel]    Script Date: 1/31/2018 10:25:30 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[OIG_SupplierPersonnel]
AS

select
	v.federalId AS TaxId, 
	s.id ''PersonnelId'',
                dbo.GetItemFromSplitedList(s.name, ''|'', 2) AS FName, /*sp.name as FName,*/ 
	dbo.GetItemFromSplitedList(s.name, ''|'', 4) AS LName, 
	CASE WHEN s.DOB IS NOT NULL THEN format(dbo.decryptdateField(s.DOB,DEFAULT),''M/d/yy'')
		 ELSE NULL END DOB,
	--dbo.decryptdateField(s.DOB,DEFAULT) as DOB, 
	CASE WHEN l.Id IS NOT NULL THEN '''' 
	     WHEN dbo.DecryptField(s.SSN, DEFAULT) = replace(v.federalId,''-'','''') THEN v.federalId 
		 ELSE dbo.DecryptField(s.SSN, DEFAULT) END SSN, /*sp.SSN,*/ 
   CASE WHEN s.Title = ''PRT'' THEN ''Partner'' ELSE s.Title END Title, /*sp.Title,*/ 
   dbo.DecryptField(s.RegistrationNumber, DEFAULT) AS AlienNo, 
   s.OwnedPercentage AS PctOwn, 
   s.OwnedShares AS Shares, 
   s.HowSharesAcquired AS HowAcq, 
   dbo.DecryptField(s.comment, DEFAULT) AS Alias, 
   format(s.EmploymentStartDate,''M/d/yy'') AS FromDte, 
   format(s.EmploymentEndDate,''M/d/yy'') AS ToDte, 
   l.LicenseNo AS LicNo, 
   l.ExpirationDate AS LicExp, 
   s.Id AS AddrSeq,
    s.IsOwner              As ''IsOwner'',
    s.IsKeyPerson          As ''IsKeyPerson'',

    iif(s.CertificationId>0,s.CertificationId,iif([Certification] is not null,1,0))              As ''CertificationId'',
    s.OIGReviewed          As ''OIGReviewed''


from SupplierPersonnel s
inner join vendor v
on v.CurrentSupplierId = s.SupplierId
LEFT JOIN License L ON l.personnelId = s.Id   



', 
		@database_name=N'NYCSCA_VAS_STAGE', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OIG_SupplierMixedInfo]    Script Date: 5/31/2019 1:25:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OIG_SupplierMixedInfo', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [NYCSCA_VAS_STAGE]
GO

/****** Object:  View [dbo].[OIG_SupplierMixedInfo]    Script Date: 1/31/2018 10:28:29 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[OIG_SupplierMixedInfo]
AS
SELECT        v.FederalId AS ''TaxId'', spm.PersonnelId, spm.ExpertiseField, spm.TotalYears, spm.YearsInSupplier
FROM            dbo.SupplierPersonnelMixedInfo AS spm INNER JOIN
                         dbo.Vendor AS v ON v.CurrentSupplierId = spm.SupplierId
WHERE        (spm.Type = ''AddExpert'')


', 
		@database_name=N'NYCSCA_VAS_STAGE', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OIG_Prequal_Hist]    Script Date: 5/31/2019 1:25:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OIG_Prequal_Hist', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
CREATE view [dbo].[OIG_Prequal_Hist]
as
SELECT top(5000)
  v.FederalId AS TaxId, 
  CONVERT(VARCHAR(10), 
  v.DateCreated, 101) AS [Reviewer Reviewed Date], 
  s.Company, 
  CASE s.legalstructure WHEN ''sol'' THEN ''Propietorship'' 
				        WHEN ''Cor'' THEN ''Corporation'' 
					    WHEN ''Llc'' THEN ''LLC'' 
					    WHEN ''Gen'' THEN ''Partnership'' 
					    WHEN ''Oth'' THEN ''Other'' END AS OrgType, 
  s.StateIncorporation AS IncState,
  sp2.propertydate AS DteForm, 
  sp2.DateAsText TxtFrom, 
  sp8.PropertyDate AS IncDte, 
  sp6.PropertyText AS IncShareAuth, 
  sp7.PropertyText AS IncShareIssue, 
  CASE sp9.propertyvalue WHEN ''-1'' THEN '''' ELSE sp9.propertyvalue END AS LLCNum, 
  sp11.PropertyText AS PrtnrCnty, 
  sp12.PropertyText AS OtherExplain, 
  sp82.PropertyText AS Share, 
  srf.CompanyName AS ShrCompany1, 
  srf.CompanyTaxId AS ShrTIN1, 
  srf.CompanyDescription AS ShrNature1, 
  sp43.PropertyText AS PurchFrom, 
  sp44.PropertyText AS PaidInFull, 
  sp45.PropertyDate AS PurchDte, 
  sp57.PropertyValue AS EmpNo, 
  sp58.PropertyValue AS SafeHrsWorked, 
  sp59.PropertyText AS SafeWritPrgm, 
  sp60.PropertyText AS SafeRankEmp, 
  sp61.PropertyText AS SafeRankEmpTitle, 
  sp62.PropertyText AS SafeEMR, 
  sp63.PropertyValue AS SafeOSHAIncidents, 
  sp64.PropertyValue AS SafeLost, 
  sp65.PropertyValue AS SafeFatal, 
  sp66.PropertyText AS SafePaidFine, 
  sp67.PropertyText AS SafePaidFineExpl, 
  dbo.GetCertType(v.supplierId) as MWLBE,
  vcp.Name as PrimaryContactName,
  vcp.Title as PrimaryContactTitle,
  vcp.Phone as PrimaryContactPhone,
  vcp.Extension as PrimaryContactExtension,
  vcp.Fax as PrimaryContactFax,
  vcp.Email as PrimaryContactEmail,
  vcs.Name as SecondaryContactName,
  vcs.Title as SecondaryContactTitle,
  vcs.Phone as SecondaryContactPhone,
  vcs.Extension as SecondaryContactExtension,
  vcs.Fax as SecondaryContactFax,
  vcs.Email as SecondaryContactEmail
FROM            (SELECT        v.CurrentSupplierId AS supplierId, v.Id, v.FederalId, wh.DateCreated
                          FROM            dbo.Vendor AS v INNER JOIN
                                                        (SELECT        s.Id, s.FederalId
                                                          FROM            dbo.Supplier AS s INNER JOIN
                                                                                    dbo.Vendor AS v1 ON s.FederalId = v1.FederalId LEFT OUTER JOIN
                                                                                    dbo.SupplierStatus AS ss ON s.Id = ss.SupplierId AND ss.TypeName = ''Supplier Prequalification'' LEFT OUTER JOIN
                                                                                    dbo.SupplierVersion AS sv ON s.Id = sv.SupplierId LEFT OUTER JOIN
                                                                                    dbo.SupplierProperty AS sp2 ON s.Id = sp2.SupplierId AND sp2.PropertyId = 508 LEFT OUTER JOIN
                                                                                    dbo.SupplierWorkflow AS sw ON s.Id = sw.SupplierId AND sw.WorkflowId = 1 LEFT OUTER JOIN
                                                                                    dbo.WorkflowHistory AS wh1 ON sw.TransactionId = wh1.TransactionHeaderId LEFT OUTER JOIN
                                                                                    dbo.SupplierStaticQualification AS sq ON s.Id = sq.SupplierId
                                                          --WHERE        (ISNULL(ss.Status, N'''') IN (''OIG Pending'', ''Qualified Pending'', ''Qualified'')) AND (ISNULL(CONVERT(nvarchar(500), sp2.PropertyText), N'''') 
														  WHERE        (ISNULL(CONVERT(nvarchar(500), sp2.PropertyText), N'''') 
                                                                                    = '''') AND (wh1.CurrentNodeId = 488) AND (ISNULL(sq.V_C_APPR_IG, '''') <> ''Y'') AND (sv.Status IS NULL OR
                                                                              sv.Status <> 0)
                                                          UNION
                                                          SELECT        s.Id, s.FederalId
                                                          FROM            dbo.Supplier AS s LEFT OUTER JOIN
                                                                                   dbo.SupplierStatus AS ss ON s.Id = ss.SupplierId AND ss.TypeName = ''Supplier Prequalification'' LEFT OUTER JOIN
                                                                                   dbo.SupplierVersion AS sv ON s.Id = sv.SupplierId
                                                          --WHERE        (ISNULL(ss.Status, N'''') IN (''Reference Reviewed'', ''Financial Reviewed'', ''Reference and Financial Reviewed'')) AND (sv.Status IS NULL OR
                                                          --                         sv.Status <> 0)) AS c ON c.FederalId = v.FederalId INNER JOIN

														  WHERE        (sv.Status IS NULL OR
                                                                                   sv.Status <> 0)) AS c ON c.FederalId = v.FederalId INNER JOIN
                                                        (SELECT        Id, SupplierId, WorkflowId, TransactionId, WorkflowType, BusinessUnitId, TransferredFlag
                                                          FROM            dbo.SupplierWorkflow
                                                          WHERE        (WorkflowType = ''Supplier Prequalification'')) AS sw ON v.CurrentSupplierId = sw.SupplierId INNER JOIN
                                                        (SELECT        Id, TransactionHeaderId, WorkflowId, CurrentNodeId, ApprovalUserId, ApprovalRoleId, ApprovalConditionId, ApprovalDate, PrevHistoryId, 
                                                                                    Status, IsActive, Comments, DateCreated, CreatedBy, Version, CreatedType, DelegatorId
                                                          FROM            dbo.WorkflowHistory
                                                          WHERE        (CurrentNodeId = 111) AND (ISNULL(DateCreated, ''1900/1/1'') <> ''1900/1/1'')) AS wh ON 
                                                    sw.TransactionId = wh.TransactionHeaderId LEFT OUTER JOIN
                                                    dbo.TempVendor AS t ON v.CurrentSupplierId = t.SupplierId
                          WHERE        (t.SupplierId IS NULL)) AS v LEFT OUTER JOIN
                         dbo.Supplier AS s ON v.supplierId = s.Id LEFT OUTER JOIN
							--Property02 is Formed Date, VAS stores in the text column and not the property date column
                             (SELECT        
								Id, 
								SupplierId, 
								ParentId, 
								PropertyId, 
								PropertyValue,
								PropertyDate, 
								PropertyText, 
								Selected, 
								AttachmentId, 
								AttachmentName, 
								ChangeDate, 
                                ChangeUser, 
								case when propertydate  = CONVERT(DATE,''1900-01-01'') then PropertyText else FORMAT(propertydate, ''MM/yyyy'') end as DateAsText
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 2)) AS sp2 ON v.supplierId = sp2.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 5)) AS sp5 ON v.supplierId = sp5.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 6)) AS sp6 ON v.supplierId = sp6.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 7)) AS sp7 ON v.supplierId = sp7.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 9)) AS sp9 ON v.supplierId = sp9.SupplierId LEFT OUTER JOIN
							   (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 8)) AS sp8 ON v.supplierId = sp8.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 11)) AS sp11 ON v.supplierId = sp11.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 12)) AS sp12 ON v.supplierId = sp12.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 82)) AS sp82 ON v.supplierId = sp82.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, Type, ChangeType, LocationType, HolderName, StartDate, EndDate, FirmId, QuestionIds, PersonnelIds, DocumentIds, Present, 
                                                         ChangeUser, ChangeDate
                               FROM            dbo.SupplierBusinessMixedInfo
                               WHERE        (Type = ''AddShared'')) AS sbm ON v.supplierId = sbm.SupplierId LEFT OUTER JOIN
                         dbo.SupplierRelatedFirm AS srf ON sbm.FirmId = srf.Id LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 43)) AS sp43 ON v.supplierId = sp43.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 44)) AS sp44 ON v.supplierId = sp44.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 45)) AS sp45 ON v.supplierId = sp45.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 57)) AS sp57 ON v.supplierId = sp57.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 58)) AS sp58 ON v.supplierId = sp58.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 59)) AS sp59 ON v.supplierId = sp59.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 60)) AS sp60 ON v.supplierId = sp60.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 61)) AS sp61 ON v.supplierId = sp61.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, Attachmentid, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 62)) AS sp62 ON v.supplierId = sp62.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 63)) AS sp63 ON v.supplierId = sp63.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 64)) AS sp64 ON v.supplierId = sp64.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 65)) AS sp65 ON v.supplierId = sp65.SupplierId LEFT OUTER JOIN
                    (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 66)) AS sp66 ON v.supplierId = sp66.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 67)) AS sp67 ON v.supplierId = sp67.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, 
                                                         ChangeUser
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 69)) AS sp69 ON v.supplierId = sp69.SupplierId

left outer join VendorContact vcp
on vcp.VendorId = v.Id and vcp.ContactType = ''primary'' 
left outer join VendorContact vcs
on vcs.VendorId = v.Id and vcs.ContactType = ''secondary'' 
where v.FederalId in
(
''11-3164892'',
''54-1756965'',
''11-2900403'',
''22-3341410'',
''13-4029935'',
''56-2608793'',
''11-3437849'',
''46-3609234'',
''45-5285508'',
''45-3825311'',
''22-2281888'',
''11-2217107'',
''13-3608930'',
''22-3631912'',
''11-3378927'',
''22-2997301'',
''26-0768973'',
''11-3706771'',
''30-0512988'',
''13-1669034'',
''11-3211834'',
''13-3987385'',
''13-3989706'',
''11-2602995'',
''06-1581962'',
''11-3061755'',
''13-1955561'',
''11-3052524'',
''13-3925675'',
''11-1747794'',
''13-3872249'',
''11-3419637'',
''20-2326280'',
''32-0282524'',
''26-3670645'',
''11-3443826'',
''45-4974471'',
''95-4528779'',
''22-2005196'',
''13-3662129'',
''34-2046659'',
''11-2841186'',
''13-3558266'',
''11-3635282'',
''11-2317757'',
''20-2742991'',
''26-3638307'',
''20-2205753'',
''13-3170538'',
''20-8855565'',
''46-4716582'',
''36-3527342'',
''46-1637841'',
''27-1155071'',
''20-2725001'',
''11-3491958'',
''13-4168484'',
''13-3895362'',
''26-2439949'',
''45-0576904'',
''11-3620963'',
''11-3311759'',
''06-1149260'',
''45-2632826'',
''33-1062075'',
''36-4676432'',
''13-3535009'',
''20-2240180'',
''13-3241242'',
''13-3920768'',
''22-2846616'',
''13-3106229'',
''22-3728909'',
''35-2247168'',
''22-2275060'',
''13-3965869'',
''27-3167155'',
''13-3917891'',
''11-3409813'',
''11-3301040'',
''11-3013325'',
''11-2497640'',
''20-2932897'',
''11-3464565'',
''11-2877119'',
''20-1452774'',
''26-3761869'',
''11-3631448'',
''22-1126840'',
''20-1015307'',
''45-2437923'',
''45-3238178'',
''13-3967731'',
''46-4075941'',
''13-4050635'',
''11-2434454'',
''13-3220004'',
''46-1134493'',
''47-3207609'',
''11-3567764'',
''45-4407367'',
''22-2665688'',
''11-3172875'',
''13-3837961'',
''11-3714784'',
''20-4641589'',
''11-3240880'',
''11-3410186'',
''27-1380637'',
''13-3696991'',
''11-3021746'',
''22-3488170'',
''43-1008168'',
''46-3424016'',
''13-1976160'',
''13-2944469'',
''98-0202186'',
''11-3177736'',
''22-2479681'',
''13-5667093'',
''23-2933918'',
''13-3936713'',
''26-2112493'',
''13-2671278'',
''22-3121671'',
''11-2468857'',
''04-3740323'',
''20-3837968'',
''13-4139631'',
''13-3497226'',
''56-2378240'',
''46-3453645'',
''13-2649349'',
''13-3791334'',
''23-1915977'',
''13-3982346'',
''13-4106879'',
''37-1471725'',
''11-3323114'',
''26-1944111'',
''22-2651610'',
''11-3139145'',
''11-3424407'',
''11-2157085'',
''26-1416282'',
''27-5443430'',
''26-4070550'',
''47-1138924'',
''27-3193717'',
''47-4523254'',
''16-1546924'',
''13-3244557'',
''26-3065914'',
''26-2883842'',
''54-1668744'',
''11-2558331'',
''13-4138753'',
''75-2996758'',
''65-1310233'',
''11-3637663'',
''11-3490955'',
''13-2849354'',
''56-2469955'',
''26-4307137'',
''20-1404654'',
''11-3351954'',
''14-1969215'',
''80-0186311'',
''11-1531569'',
''11-3240475'',
''13-1813318'',
''22-2916049'',
''22-1944267'',
''11-3208388'',
''06-0916937'',
''20-5321840'',
''13-2546221'',
''11-3639723'',
''01-0741838'',
''04-3608440'',
''11-3309143'',
''13-4194938'',
''47-1042759'',
''20-3747356'',
''47-4554066'',
''27-0294897'',
''36-4502776'',
''45-4533595'',
''38-3986329'',
''13-2882578'',
''11-2802623'',
''36-1785381'',
''47-0860457'',
''11-3637659'',
''20-3774251'',
''13-2817020'',
''11-3340702'',
''22-3782942'',
''27-1534387'',
''90-0453168'',
''26-0683013'',
''47-2752058'',
''59-2059235'',
''26-0749848'',
''11-2814029'',
''13-3864700'',
''11-3420369'',
''11-3551992'',
''27-3830398'',
''22-1779848'',
''13-3538654'',
''26-0493792'',
''80-0581535'',
''06-1579357'',
''77-0666248'',
''11-2588746'',
''11-3243439'',
''13-3460676'',
''20-1584254'',
''11-6487653'',
''13-2625361'',
''13-3748017'',
''95-2965905'',
''11-3475322'',
''11-3575645'',
''47-4550727'',
''13-3617169'',
''27-1621356'',
''11-3548248'',
''26-1545189'',
''46-4210735'',
''27-3915957'',
''26-0005032'',
''13-5444820'',
''13-2760917'',
''23-1674739'',
''01-0798707'',
''11-2533234'',
''80-0270094'',
''33-1078398'',
''11-2958700'',
''11-2783307'',
''11-2661913'',
''13-2877775'',
''34-2003695'',
''27-0972810'',
''45-4047974'',
''06-1305071'',
''20-0534569'',
''46-0828509'',
''11-3245210'',
''26-2837496'',
''11-2590354'',
''52-1437280'',
''11-3691035'',
''11-2520829'',
''11-3155684'',
''32-0113412'',
''54-2063138'',
''47-5460875'',
''27-3237690'',
''47-5511181'',
''22-3493517'',
''13-3521774'',
''11-3215744'',
''26-4201726'',
''20-3251156'',
''26-3826539'',
''06-1184898'',
''11-2332373'',
''13-3629038'',
''13-2840890'',
''13-1955617'',
''11-2887460'',
''01-0697251'',
''33-1087947'',
''06-1614323'',
''26-1553932'',
''13-3802153'',
''13-2624753'',
''20-4066556'',
''01-0657232'',
''13-3136179'',
''11-3473300'',
''13-2762991'',
''11-3355726'',
''20-0660662'',
''46-2670930'',
''76-0715145'',
''46-3739792'',
''21-0731636'',
''46-2783471'',
''06-1439497'',
''27-1752942'',
''45-2160403'',
''11-3604534'',
''07-1583688'',
''27-4192940'',
''11-3502322'',
''27-2101955'',
''13-3196772'',
''13-3089494'',
''11-3022860'',
''11-2692795'',
''20-5062999'',
''80-0715923'',
''26-4729302'',
''51-0627640'',
''65-1174009'',
''13-3792250'',
''20-0561013'',
''45-4622820'',
''30-0533578'',
''11-3672696'',
''13-4249670'',
''14-1675257'',
''27-3387568'',
''11-3424548'',
''11-3674907'',
''11-2286880'',
''20-2119958'',
''20-5890295'',
''46-4246267'',
''81-2225593'',
''26-3979040'',
''13-4110973'',
''27-4268398'',
''26-0783133'',
''20-2327868'',
''20-8704323'',
''45-0515680'',
''26-0404426'',
''20-4565069'',
''13-5636084'',
''45-0490787'',
''11-3572763'',
''11-1801285'',
''27-1264727'',
''46-4924682'',
''25-1375815'',
''47-4648632'',
''11-2871781'',
''54-1978935'',
''20-2816899'',
''11-3446053'',
''81-0553441'',
''11-2687935'',
''11-2377382'',
''11-3101193'',
''45-5488758'',
''22-1639059'',
''13-3800292'',
''13-4131489'',
''11-3840644'',
''20-2755369'',
''46-0597830'',
''11-3294424'',
''58-2509055'',
''52-2177861'',
''22-3755131'',
''11-3068255'',
''11-3106466'',
''13-4147638'',
''22-3397530'',
''26-4649341'',
''47-2171313'',
''22-3072397'',
''13-4036155'',
''13-3103744'',
''20-8314248'',
''11-2106870'',
''23-2831501'',
''01-0604408'',
''20-2794503'',
''27-0191835'',
''11-2157530'',
''74-3157314'',
''20-1949154'',
''22-2822073'',
''20-4035546'',
''20-5848506'',
''45-2482534'',
''26-3088485'',
''13-3119887'',
''04-3654183'',
''20-2238028'',
''20-1070871'',
''46-2145449'',
''22-3624045'',
''20-4001949'',
''11-3435212'',
''20-3767676'',
''11-2679631'',
''11-3037455'',
''13-4120430'',
''11-3247693'',
''06-1227336'',
''20-0432135'',
''11-3072481'',
''75-2983177'',
''13-3861438'',
''01-0623841'',
''26-3498825'',
''20-3655082'',
''27-1640748'',
''11-2779231'',
''27-1596721'',
''13-2747664'',
''11-3107911'',
''13-3558282'',
''11-1581269'',
''11-2310992'',
''20-4240036'',
''47-2023715'',
''22-3670387'',
''13-4037954'',
''20-8564025'',
''26-3506008'',
''45-3586595'',
''47-3547955'',
''81-1432056'',
''13-3692834'',
''22-3319319'',
''11-3054861'',
''45-3545890'',
''26-1301044'',
''45-3324633'',
''13-2940139'',
''04-3624322'',
''13-3640063'',
''11-3497895'',
''11-3091960'',
''06-1750239'',
''66-0571416'',
''20-2865116'',
''22-2721977'',
''46-0399408'',
''11-2676368'',
''11-2515459'',
''11-3101823'',
''13-3984071'',
''20-1145537'',
''20-0972677'',
''11-2816565'',
''20-4295362'',
''20-1771143'',
''45-4284773'',
''22-3439246'',
''46-5277515'',
''46-2922569'',
''13-4098908'',
''20-8697458'',
''46-4764066'',
''20-1841566'',
''27-0756461'',
''22-2679402'',
''11-3140842'',
''11-1853430'',
''35-2386004'',
''26-2877581'',
''46-2042853'',
''20-2048960'',
''47-3752797'',
''46-0889510'',
''47-2942680'',
''14-1277239'',
''47-3519636'',
''26-2759913'',
''46-3451566'',
''14-1941856'',
''46-2509691'',
''13-3591284'',
''47-5169841'',
''26-2390266'',
''11-2776535'',
''22-2111028'',
''11-2613296'',
''11-3152800'',
''22-3972838'',
''11-1529032'',
''32-0224043'',
''13-3330702'',
''80-0803700'',
''13-3577959'',
''11-3057044'',
''11-3047319'',
''11-3301357'',
''20-3800158'',
''11-3602702'',
''22-3486363'',
''26-4636504'',
''45-4149302'',
''46-4094315'',
''45-4838098'',
''95-4334176'',
''47-5250806'',
''26-4337593'',
''11-3593267'',
''11-3135309'',
''06-1698298'',
''27-0664717'',
''13-2599516'',
''11-2983104'',
''11-3566425'',
''13-3777060'',
''27-0711558'',
''54-1291305'',
''27-3640481'',
''27-3029110'',
''20-0043496'',
''26-4254106'',
''26-3570393'',
''45-3600823'',
''13-2656877'',
''13-3595619'',
''11-2910472'',
''80-0659175'',
''27-2051727'',
''46-5483975'',
''46-4524990'',
''45-5626330'',
''27-0277241'',
''11-3038047'',
''47-1894596'',
''36-4600472'',
''45-4549673'',
''46-2893167'',
''27-4932215'',
''13-2928168'',
''45-5392062'',
''26-2790121'',
''27-2513673'',
''13-4146033'',
''13-3436223'',
''20-0918486'',
''45-3841928'',
''80-0829515'',
''45-5491068'',
''46-4111963'',
''11-2443580'',
''22-3163429'',
''02-0275498'',
''11-3162897'',
''13-3786648'',
''26-3110894'',
''36-4527367'',
''41-2047522'',
''22-3117125'',
''13-3375308'',
''22-2901819'',
''11-3512788'',
''16-1550919'',
''11-3455253'',
''14-1562182'',
''20-0499856'',
''13-3937358'',
''73-1722897'',
''06-1791143'',
''11-2488342'',
''46-1353419'',
''27-3137458'',
''13-3091117'',
''20-3333597'',
''27-3380859'',
''46-4755321'',
''11-3589984'',
''11-3493933'',
''11-3135667'',
''11-3307589'',
''13-2657320'',
''11-3073330'',
''20-8172675'',
''45-4232525'',
''45-3139738'',
''46-3597638'',
''13-1892598'',
''34-6565596'',
''13-3031033'',
''22-2869761'',
''11-3231714'',
''11-3188000'',
''27-0120580'',
''11-2537502'',
''11-1748417'',
''11-2778195'',
''22-3416826'',
''11-2454653'',
''23-2827092'',
''26-4299480'',
''13-2781308'',
''13-2598184'',
''11-2040130'',
''56-2505616'',
''22-3520570'',
''23-2707237'',
''34-2040467'',
''20-3460023'',
''11-2118710'',
''11-3114292'',
''13-3599450'',
''11-3105805'',
''27-0208423'',
''27-3754871'',
''27-3792570'',
''13-4073844'',
''26-0502645'',
''46-0586624'',
''11-3205660'',
''11-2953960'',
''22-2875850'',
''11-2495211'',
''11-3552655'',
''54-2077290'',
''26-3029692'',
''11-3113133'',
''11-3486091'',
''26-4406182'',
''11-3424390'',
''81-1428423'',
''04-2985433'',
''13-3330775'',
''20-3174953'',
''13-2663790'',
''47-4907434'',
''54-2106515'',
''11-2588525'',
''26-1315190'',
''46-0605829'',
''46-3968780'',
''47-2106077'',
''46-2728216'',
''46-1328287'',
''47-3061386'',
''11-2869540'',
''13-2771793'',
''47-0854848'',
''13-4173219'',
''82-0553022'',
''46-4927116'',
''13-1974950'',
''11-3241599'',
''45-4398534'',
''20-3184562'',
''11-3054455'',
''27-3338841'',
''26-3735259'',
''11-2242996'',
''20-5865530'',
''45-4068622'',
''26-0601975'',
''45-4507301'',
''54-1963889'',
''57-1214216'',
''11-3363153'',
''14-1814203'',
''36-3353196'',
''11-3368874'',
''36-4287998'',
''22-1623253'',
''11-2325811'',
''87-0786962'',
''22-3812539'',
''11-3587841'',
''13-3452409'',
''74-3067669'',
''27-2807076'',
''57-1200796'',
''11-2660268'',
''11-3297885'',
''11-3250839'',
''13-3404548'',
''20-1150097'',
''34-0725601'',
''11-3366695'',
''90-0712122'',
''46-4941960'',
''11-3440666'',
''20-3246569'',
''20-5181731'',
''20-1480887'',
''45-2430103'',
''11-2508787'',
''81-0643539'',
''11-3456141'',
''20-4824171'',
''26-4671108'',
''41-1740667'',
''13-3675756'',
''11-3116820'',
''30-0184529'',
''11-3511921'',
''11-2926888'',
''23-2755689'',
''11-3210275'',
''11-3399839'',
''16-1448024'',
''13-0727420'',
''46-4576572'',
''11-3385473'',
''11-3136557'',
''11-2478099'',
''11-2953343'',
''11-3079545'',
''13-2610617'',
''11-2832120'',
''27-3203119'',
''13-4048623'',
''14-1707677'',
''26-0520478'',
''11-3242624'',
''11-2472336'',
''27-0159093'',
''13-2962674'',
''13-4012937'',
''13-3689779'',
''11-3176454'',
''06-1676195'',
''22-3523411'',
''11-2351704'',
''13-3750269'',
''20-1462602'',
''13-3209244'',
''22-3540738'',
''13-3998102'',
''11-3557848'',
''45-1583835'',
''20-0953973'',
''11-2525113'',
''11-3313855'',
''45-0515088'',
''13-3083558'',
''27-1380451'',
''16-1683626'',
''11-3451015'',
''22-2543935'',
''20-1878687'',
''81-2451026'',
''27-4358936'',
''11-3203308'',
''34-1725366'',
''26-4737225'',
''11-3019285'',
''13-3558990'',
''11-3406191'',
''13-4223858'',
''20-8672349'',
''11-3538632'',
''11-2957458'',
''22-2420480'',
''11-2945779'',
''11-2871175'',
''13-1076880'',
''13-3950902'',
''22-3603962'',
''30-0325579'',
''25-1496552'',
''81-3206407'',
''45-4790303'',
''51-0420258'',
''26-0184304'',
''11-2000369'',
''20-5358806'',
''13-1933011'',
''20-2766207'',
''30-0155923'',
''11-3502818'',
''20-4474610'',
''13-3084821'',
''20-4029013'',
''46-2986061'',
''27-2100597'',
''04-3624714'',
''20-0685371'',
''11-2858605'',
''11-3141810'',
''56-2361008'',
''11-2221967'',
''47-2424139'',
''84-1623160'',
''80-0476221'',
''90-0753037'',
''11-1738946'',
''22-2865241'',
''22-2232883'',
''22-3494842'',
''34-1479495'',
''13-4058864'',
''11-3492382'',
''20-3899537'',
''11-3010156'',
''11-3294068'',
''11-2944679'',
''13-3524651'',
''20-5933314'',
''36-4741729'',
''22-3551012'',
''27-3075249'',
''74-1466429'',
''27-4286044'',
''04-3585695'',
''22-3409613'',
''22-2562727'',
''20-1807496'',
''26-1236699'',
''65-1226782'',
''11-3124518'',
''20-8385512'',
''27-1987846'',
''81-3547849'',
''25-1757452'',
''20-3025314'',
''37-1714616'',
''22-2563223'',
''25-1343589'',
''04-2630300'',
''11-3310582'',
''05-0555277'',
''20-8766593'',
''11-2532629'',
''13-3888105'',
''11-2105522'',
''13-3079582'',
''26-3556603'',
''45-4431752'',
''11-2130383'',
''13-3151773'',
''26-0246510'',
''03-0306764'',
''20-3231464'',
''11-2129896'',
''22-2351924'',
''22-3656248'',
''27-2182262'',
''45-3267708'',
''47-5380755'',
''58-2240471'',
''20-1635328'',
''27-1921637'',
''75-3095717'',
''36-3429769'',
''47-5181629'',
''47-4314889'',
''11-3559982'',
''22-1970889'',
''20-5327544'',
''65-1164777'',
''13-3432791'',
''27-0676907'',
''13-3240000'',
''20-8308071'',
''20-3662454'',
''13-3618200'',
''42-1628916'',
''26-1767287'',
''13-2616700'',
''11-3535296'',
''06-1169644'',
''22-3718024'',
''26-4741177'',
''26-3927700'',
''35-2208032'',
''27-2213564'',
''27-3239829'',
''11-2022749'',
''13-3798126'',
''58-2443119'',
''13-4021445'',
''27-1424268'',
''11-2668612'',
''13-2804089'',
''22-3416051'',
''46-0640855'',
''11-3184420'',
''22-2993022'',
''06-1670816'',
''26-2111936'',
''27-2070312'',
''13-1576976'',
''11-2939703'',
''26-1689573'',
''22-2501664'',
''81-2678815'',
''20-2516707'',
''46-3497349'',
''26-3207120'',
''46-3605151'',
''11-2540337'',
''26-2093610'',
''11-2626018'',
''22-3536803'',
''20-2075867'',
''06-1442136'',
''20-4100528'',
''26-0152290'',
''47-5219586'',
''35-2415881'',
''20-1688919'',
''26-2139663'',
''13-4250005'',
''13-3355885'',
''11-3101815'',
''20-2628511'',
''46-2735287'',
''13-3844952'',
''11-2542399'',
''98-0668194'',
''11-3551488'',
''11-1165760'',
''11-1554704'',
''11-2135768'',
''11-2798149'',
''22-3233476'',
''22-2706064'',
''74-3059134'',
''11-3469852'',
''11-3332715'',
''13-2873389'',
''11-3448952'',
''02-0595039'',
''13-3744637'',
''27-2921221'',
''26-0433211'',
''90-0438459'',
''13-3695218'',
''11-3353215'',
''32-0297591'',
''22-1971127'',
''13-4069542'',
''06-1497247'',
''45-3764514'',
''11-2235604'',
''11-2972844'',
''20-5533182'',
''47-2749406'',
''20-5949144'',
''46-2324131'',
''11-3130986'',
''45-5317500'',
''11-2698476'',
''11-2963986'',
''27-1219767'',
''11-3369536'',
''11-3588833'',
''26-1162691'',
''27-4567568'',
''13-4147836'',
''11-2128967'',
''38-3665918'',
''11-3577918'',
''11-3570797'',
''20-2869678'',
''45-2823382'',
''45-5526705'',
''45-4134333'',
''46-1270732'',
''46-5170899'',
''11-2311860'',
''13-3113971'',
''13-3731431'',
''11-3353811'',
''11-3353811'',
''46-1230559'',
''11-2468065'',
''13-4069848'',
''11-3048691'',
''11-3123093'',
''26-0657045'',
''23-1528668'',
''11-3558283'',
''26-0316938'',
''26-3464096'',
''20-3190668'',
''03-0541243'',
''11-3614882'',
''47-3375884'',
''22-1738363'',
''11-3245485'',
''47-1528293'',
''20-2998573'',
''11-2475482'',
''13-3575106'',
''47-1397476'',
''47-3806607'',
''11-0626838'',
''22-3786931'',
''26-0463481'',
''22-3367209'',
''11-3479657'',
''11-3034172'',
''13-3491326'',
''13-3936764'',
''38-3677545'',
''20-0990341'',
''47-3111765'',
''46-3043115'',
''13-3495171'',
''26-3500623'',
''26-1735743'',
''11-2770483'',
''81-1467342'',
''46-2925092'',
''11-2393559'',
''13-4162660'',
''22-3080051'',
''36-4533646'',
''11-3289992'',
''36-3945019'',
''45-2835401'',
''46-5211066'',
''47-3539627'',
''11-3267994'',
''13-3182114'',
''11-3689162'',
''26-0349635'',
''22-2226346'',
''13-4024854'',
''22-1631925'',
''11-3438941'',
''26-1510523'',
''22-3141658'',
''22-3640463'',
''11-3121519'',
''11-2337040'',
''14-1691128'',
''20-0874885'',
''27-5427867'',
''90-0667244'',
''13-3476611'',
''46-2315847'',
''52-1440080'',
''11-3502736'',
''58-2671223'',
''11-2473030'',
''13-3982620'',
''06-1139161'',
''13-3275464'',
''11-3491120'',
''11-2916935'',
''26-1699603'',
''47-5272799'',
''11-3371684'',
''81-3109918'',
''11-2894781'',
''26-0149267'',
''45-2633900'',
''33-1208516'',
''11-1074715'',
''83-0451557'',
''26-3990335'',
''11-2551039'',
''11-3548203'',
''87-0786546'',
''47-4441706'',
''11-2786038'',
''02-0626799'',
''11-3613855'',
''20-0690367'',
''13-4123235'',
''13-5331530'',
''13-4149597'',
''06-1634412'',
''45-1646412'',
''13-3131804'',
''76-0758024'',
''11-2628655'',
''22-2788822'',
''46-0863926'',
''27-0675631'',
''82-1552535'',
''13-2942763'',
''81-0602693'',
''11-2490666'',
''11-3110888'',
''11-2603357'',
''22-1830828'',
''47-4427119'',
''13-3460545'',
''13-3398594'',
''84-1639774'',
''81-1343649'',
''20-5910717'',
''59-3790313'',
''13-3350685'',
''20-3819396'',
''20-3937029'',
''11-3164486'',
''13-2821402'',
''13-3902996'',
''26-2582540'',
''20-1007710'',
''45-3460999'',
''26-2193518'',
''90-0987149'',
''13-3555187'',
''11-3631062''
)
ORDER BY v.DateCreated, v.FederalId
', 
		@database_name=N'NYCSCA_VAS_STAGE', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OIG_Prequal_Hist_2]    Script Date: 5/31/2019 1:25:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OIG_Prequal_Hist_2', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [NYCSCA_VAS_STAGE]
GO

/****** Object:  View [dbo].[OIG_Prequal_Hist_2]    Script Date: 5/15/2018 1:44:44 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[OIG_Prequal_Hist_2]
AS
SELECT        TOP (5000) v_1.FederalId AS TaxId, CONVERT(VARCHAR(10), v_1.DateCreated, 101) AS [Reviewer Reviewed Date], s.Company, 
                         CASE s.legalstructure WHEN ''sol'' THEN ''Propietorship'' WHEN ''Cor'' THEN ''Corporation'' WHEN ''Llc'' THEN ''LLC'' WHEN ''Gen'' THEN ''Partnership'' WHEN ''Oth'' THEN ''Other'' END AS OrgType, s.StateIncorporation AS IncState, 
                         sp2_1.PropertyDate AS DteForm, sp2_1.DateAsText AS TxtFrom, sp8.PropertyDate AS IncDte, sp6.PropertyText AS IncShareAuth, sp7.PropertyText AS IncShareIssue, 
                         CASE sp9.propertyvalue WHEN ''-1'' THEN '''' ELSE sp9.propertyvalue END AS LLCNum, sp11.PropertyText AS PrtnrCnty, sp12.PropertyText AS OtherExplain, sp82.PropertyText AS Share, srf.CompanyName AS ShrCompany1, 
                         srf.CompanyTaxId AS ShrTIN1, srf.CompanyDescription AS ShrNature1, sp43.PropertyText AS PurchFrom, sp44.PropertyText AS PaidInFull, sp45.PropertyDate AS PurchDte, sp57.PropertyValue AS EmpNo, 
                         sp58.PropertyValue AS SafeHrsWorked, sp59.PropertyText AS SafeWritPrgm, sp60.PropertyText AS SafeRankEmp, sp61.PropertyText AS SafeRankEmpTitle, sp62.PropertyText AS SafeEMR, 
                         sp63.PropertyValue AS SafeOSHAIncidents, sp64.PropertyValue AS SafeLost, sp65.PropertyValue AS SafeFatal, sp66.PropertyText AS SafePaidFine, sp67.PropertyText AS SafePaidFineExpl, dbo.GetCertType(v_1.supplierId) 
                         AS MWLBE, vcp.Name AS PrimaryContactName, vcp.Title AS PrimaryContactTitle, vcp.Phone AS PrimaryContactPhone, vcp.Extension AS PrimaryContactExtension, vcp.Fax AS PrimaryContactFax, 
                         vcp.Email AS PrimaryContactEmail, vcs.Name AS SecondaryContactName, vcs.Title AS SecondaryContactTitle, vcs.Phone AS SecondaryContactPhone, vcs.Extension AS SecondaryContactExtension, 
                         vcs.Fax AS SecondaryContactFax, vcs.Email AS SecondaryContactEmail
FROM            (SELECT        v.CurrentSupplierId AS supplierId, v.Id, v.FederalId, wh.DateCreated
                          FROM            dbo.Vendor AS v INNER JOIN
                                                        (SELECT        s.Id, s.FederalId
                                                          FROM            dbo.Supplier AS s INNER JOIN
                                                                                    dbo.Vendor AS v1 ON s.FederalId = v1.FederalId LEFT OUTER JOIN
                                                                                    dbo.SupplierStatus AS ss ON s.Id = ss.SupplierId AND ss.TypeName = ''Supplier Prequalification'' LEFT OUTER JOIN
                                                                                    dbo.SupplierVersion AS sv ON s.Id = sv.SupplierId LEFT OUTER JOIN
                                                                                    dbo.SupplierProperty AS sp2 ON s.Id = sp2.SupplierId AND sp2.PropertyId = 508 LEFT OUTER JOIN
                                                                                    dbo.SupplierWorkflow AS sw ON s.Id = sw.SupplierId AND sw.WorkflowId = 1 LEFT OUTER JOIN
                                                                                    dbo.WorkflowHistory AS wh1 ON sw.TransactionId = wh1.TransactionHeaderId LEFT OUTER JOIN
                                                                                    dbo.SupplierStaticQualification AS sq ON s.Id = sq.SupplierId
                                                          WHERE        (ISNULL(CONVERT(nvarchar(500), sp2.PropertyText), N'''') = '''') AND (wh1.CurrentNodeId = 488) AND (ISNULL(sq.V_C_APPR_IG, '''') <> ''Y'') AND (sv.Status IS NULL OR
                                                                                    sv.Status <> 0)
                                                          UNION
                                                          SELECT        s.Id, s.FederalId
                                                          FROM            dbo.Supplier AS s LEFT OUTER JOIN
                                                                                   dbo.SupplierStatus AS ss ON s.Id = ss.SupplierId AND ss.TypeName = ''Supplier Prequalification'' LEFT OUTER JOIN
                                                                                   dbo.SupplierVersion AS sv ON s.Id = sv.SupplierId
                                                          WHERE        (sv.Status IS NULL) OR
                                                                                   (sv.Status <> 0)) AS c ON c.FederalId = v.FederalId INNER JOIN
                                                        (SELECT        Id, SupplierId, WorkflowId, TransactionId, WorkflowType, BusinessUnitId, TransferredFlag
                                                          FROM            dbo.SupplierWorkflow
                                                          WHERE        (WorkflowType = ''Supplier Prequalification'')) AS sw ON v.CurrentSupplierId = sw.SupplierId INNER JOIN
                                                        (SELECT        Id, TransactionHeaderId, WorkflowId, CurrentNodeId, ApprovalUserId, ApprovalRoleId, ApprovalConditionId, ApprovalDate, PrevHistoryId, Status, IsActive, Comments, DateCreated, CreatedBy, Version, 
                                                                                    CreatedType, DelegatorId
                                                          FROM            dbo.WorkflowHistory
                                                          WHERE        (CurrentNodeId = 111) AND (ISNULL(DateCreated, ''1900/1/1'') <> ''1900/1/1'')) AS wh ON sw.TransactionId = wh.TransactionHeaderId LEFT OUTER JOIN
                                                    dbo.TempVendor AS t ON v.CurrentSupplierId = t.SupplierId
                          WHERE        (t.SupplierId IS NULL)) AS v_1 LEFT OUTER JOIN
                         dbo.Supplier AS s ON v_1.supplierId = s.Id LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser, CASE WHEN propertydate = CONVERT(DATE, ''1900-01-01'') 
                                                         THEN PropertyText ELSE FORMAT(propertydate, ''MM/yyyy'') END AS DateAsText
                               FROM            dbo.SupplierProperty
                               WHERE        (PropertyId = 2)) AS sp2_1 ON v_1.supplierId = sp2_1.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_23
                               WHERE        (PropertyId = 5)) AS sp5 ON v_1.supplierId = sp5.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_22
                               WHERE        (PropertyId = 6)) AS sp6 ON v_1.supplierId = sp6.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_21
                               WHERE        (PropertyId = 7)) AS sp7 ON v_1.supplierId = sp7.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_20
                               WHERE        (PropertyId = 9)) AS sp9 ON v_1.supplierId = sp9.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_19
                               WHERE        (PropertyId = 8)) AS sp8 ON v_1.supplierId = sp8.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_18
                               WHERE        (PropertyId = 11)) AS sp11 ON v_1.supplierId = sp11.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_17
                               WHERE        (PropertyId = 12)) AS sp12 ON v_1.supplierId = sp12.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_16
                               WHERE        (PropertyId = 82)) AS sp82 ON v_1.supplierId = sp82.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, Type, ChangeType, LocationType, HolderName, StartDate, EndDate, FirmId, QuestionIds, PersonnelIds, DocumentIds, Present, ChangeUser, ChangeDate
                               FROM            dbo.SupplierBusinessMixedInfo
                               WHERE        (Type = ''AddShared'')) AS sbm ON v_1.supplierId = sbm.SupplierId LEFT OUTER JOIN
                         dbo.SupplierRelatedFirm AS srf ON sbm.FirmId = srf.Id LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_15
                               WHERE        (PropertyId = 43)) AS sp43 ON v_1.supplierId = sp43.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_14
                               WHERE        (PropertyId = 44)) AS sp44 ON v_1.supplierId = sp44.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_13
                               WHERE        (PropertyId = 45)) AS sp45 ON v_1.supplierId = sp45.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_12
                               WHERE        (PropertyId = 57)) AS sp57 ON v_1.supplierId = sp57.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_11
                               WHERE        (PropertyId = 58)) AS sp58 ON v_1.supplierId = sp58.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_10
                               WHERE        (PropertyId = 59)) AS sp59 ON v_1.supplierId = sp59.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_9
                               WHERE        (PropertyId = 60)) AS sp60 ON v_1.supplierId = sp60.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_8
                               WHERE        (PropertyId = 61)) AS sp61 ON v_1.supplierId = sp61.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_7
                               WHERE        (PropertyId = 62)) AS sp62 ON v_1.supplierId = sp62.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_6
                               WHERE        (PropertyId = 63)) AS sp63 ON v_1.supplierId = sp63.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_5
                               WHERE        (PropertyId = 64)) AS sp64 ON v_1.supplierId = sp64.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_4
                               WHERE        (PropertyId = 65)) AS sp65 ON v_1.supplierId = sp65.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_3
                               WHERE        (PropertyId = 66)) AS sp66 ON v_1.supplierId = sp66.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_2
                               WHERE        (PropertyId = 67)) AS sp67 ON v_1.supplierId = sp67.SupplierId LEFT OUTER JOIN
                             (SELECT        Id, SupplierId, ParentId, PropertyId, PropertyValue, PropertyDate, PropertyText, Selected, AttachmentId, AttachmentName, ChangeDate, ChangeUser
                               FROM            dbo.SupplierProperty AS SupplierProperty_1
                               WHERE        (PropertyId = 69)) AS sp69 ON v_1.supplierId = sp69.SupplierId LEFT OUTER JOIN
                         dbo.VendorContact AS vcp ON vcp.VendorId = v_1.Id AND vcp.ContactType = ''primary'' LEFT OUTER JOIN
                         dbo.VendorContact AS vcs ON vcs.VendorId = v_1.Id AND vcs.ContactType = ''secondary''
WHERE        (v_1.FederalId IN (''46-0586624'', ''20-3184562'', ''45-4507301'', ''11-2660268'', '''', ''41-1740667'', ''11-2472336'', ''13-3618200'', '''', ''22-3233476'', ''27-1219767'', ''45-2823382'', ''23-1528668'', ''13-3275464'', ''47-2464497'', ''20-5828543'', 
                         ''03-0417785'', ''22-2330816'', ''36-4786251'', ''13-3039254'', ''20-1292492'', ''13-3993908'', ''20-3294574'', ''11-3579543'', ''20-3154484'', ''11-1837614'', ''13-2726262'', ''27-0138259'', ''06-1332045'', ''26-4289918'', ''20-5133565'', ''23-1999985'', 
                         ''13-2617332'', ''11-2738567'', ''11-3265272'', ''46-4316511'', ''11-3338722'', ''22-2287053'', ''26-1726166'', ''27-3009107'', ''04-2438400'', ''20-1226101'', ''11-2945683'', ''27-1526885'', ''58-1900371'', ''26-0404252'', ''11-3426532'', ''47-5431204'', 
                         ''13-3460163'', ''20-0743829'', ''13-3534490'', ''46-2354111'', ''11-3008290'', ''11-3586187'', ''13-3807038'', ''13-3622704'', ''22-3025445'', ''47-4437161'', ''11-2098433'', ''11-2803327'', ''20-1463538'', ''20-8845562'', ''13-3644075'', ''34-1640248'', 
                         ''36-3337777'', ''36-4649497'', ''05-0589142'', ''11-2966657'', ''26-2090778'', ''13-3107003'', ''22-1494634'', ''22-3861256'', ''26-0272542'', ''45-5334558'', ''47-2499993'', ''47-1290193'', ''13-3726267'', ''11-2697465'', ''13-3440588'', ''11-3598113'', 
                         ''11-3415294'', ''13-2670780'', ''11-2675211'', ''16-1245609'', ''11-3565182'', ''13-3890390'', ''26-4255478'', ''11-2690324'', ''11-3567283'', ''13-2766629'', ''13-3779703'', ''20-5809818'', ''27-3576266'', ''11-2211917'', ''04-3776128'', ''27-1514850'', 
                         ''11-2227154'', ''11-3668377'', ''27-0414228'', ''11-3435601'', ''80-0571400'', ''01-0567831'', ''13-2777056'', ''81-2730462'', ''11-3301457'', ''33-0888748'', ''13-3210662'', ''03-0392515'', ''03-0382252'', ''11-3181881'', ''98-0461242'', ''20-2480422'', 
                         ''11-2042871'', ''11-2887020'', ''11-3512104'', ''04-3331299'', ''46-0733578'', ''47-2810092'', ''81-3081778'', ''11-3208750'', ''13-3619461'', ''11-2365121'', ''11-3430481'', ''31-1796631'', ''41-2070149'', ''13-3059757'', ''13-3479584'', ''46-0861515'', 
                         ''11-2120751'', ''46-5046902'', ''22-3592751'', ''11-2339722'', ''04-3683358'', ''13-3682299'', ''47-5042559'', ''26-1316888'', ''11-2972125'', ''06-0737747'', ''23-2498750'', ''27-0677221'', ''13-5672226'', ''20-1097581'', ''22-2992536'', ''11-2968897'', 
                         ''13-3366892'', ''13-1716319'', ''22-2954823'', ''11-2779104'', ''47-2211877'', ''11-3519451'', ''36-4029481'', ''46-4010807'', ''27-2911285'', ''11-1067410'', ''16-1465687'', ''11-3578305'', ''13-3330199'', ''90-0107612'', ''11-2739660'', ''47-1154351'', 
                         ''06-1351722'', ''22-3625706'', ''11-3161335'', ''27-3032965'', ''13-4224315'', ''20-8535111'', ''11-2250515'', ''11-2926914'', ''31-1804124'', ''86-1165471'', ''57-1155659'', ''46-2167017'', ''33-1150759'', ''90-0712122'', ''32-0011193'', ''11-3211486'', 
                         ''13-3849595'', ''81-3373649'', ''81-2662306'', ''13-3173785'', ''13-4074320'', ''81-1574451'', ''13-2793192'', ''26-2993497'', ''11-2906723'', ''11-2814769'', ''47-2789448'', ''41-2098678'', ''20-2499056'', ''13-3197331'', ''13-3913023'', ''11-2729546'', 
                         ''11-2155426'', ''45-4084007'', ''26-1201758'', ''11-3362538'', ''11-2743259'', ''13-3903944'', ''20-8775560'', ''80-0934515'', ''55-0843014'', ''82-0548596'', ''22-3047084'', ''22-3606232'', ''20-4051130'', ''01-0839595'', ''11-2838435'', ''11-3314120'', 
                         ''05-2680442'', ''46-2971745'', ''11-1616879'', ''46-4537473'', ''20-3513957'', ''46-0574655'', ''11-3592779'', ''94-3296803'', ''11-2133104'', ''20-8704323'', ''11-2651264'', ''35-2232005'', ''04-3758900'', ''01-0949090'', ''37-1793768'', ''13-2537744'', 
                         ''20-4208851'', ''22-2021237'', ''11-2624494'', ''13-1986759'', ''13-4123990'', ''26-2644307'', ''13-1924743'', ''11-3003874'', ''11-3465831'', ''11-3149290'', ''22-3462873'', ''20-4939404'', ''26-2686253'', ''13-3891517'', ''14-1940322'', ''13-2700266'', 
                         ''55-0808814'', ''20-8927030'', ''45-4386484'', ''47-4993901'', ''22-3220409'', ''74-6036592'', ''74-3027509'', ''46-1396023'', ''16-1723994'', ''11-3055332'', ''11-2854394'', ''11-3263291'', ''46-3362143'', ''11-2167170'', ''26-4738162'', ''45-2823382'', 
                         ''46-1644502'', ''90-0642098'', ''27-1905997'', ''11-3476551'', ''13-1730785'', ''26-1391026'', ''22-3782585'', ''26-1451745'', ''11-3113455'', ''20-5610514'', ''11-3483867'', ''20-1866777'', ''23-2935505'', ''13-4209750'', ''45-4573025'', ''26-1585893'', 
                         ''65-1219678'', ''74-3154324'', ''11-2455116'', ''16-1514494'', ''11-3374704'', ''43-0634668'', ''13-3691797'', ''11-3459989'', ''45-3140575'', ''46-4385442'', ''47-2394491'', ''45-5535622'', ''03-0536606'', ''20-8825952'', ''01-0665504'', ''20-5340203'', 
                         ''45-4315203'', ''11-3151811'', ''13-1965229'', ''14-1837264'', ''55-0892530'', ''11-2752796'', ''22-3413656'', ''11-2858802'', ''22-3716832'', ''91-0819688'', ''20-2746398'', ''13-1401980'', ''11-2986907'', ''84-1696065'', ''46-5536939'', ''13-3950418'', 
                         ''27-1893813'', ''45-4855479''))
ORDER BY v_1.DateCreated, TaxId

GO

EXEC sys.sp_addextendedproperty @name=N''MS_DiagramPane1'', @value=N''[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4[30] 2[40] 3) )"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2[66] 3) )"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 5
   End
   Begin DiagramPane = 
      PaneHidden = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "v_1"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 136
               Right = 208
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "s"
            Begin Extent = 
               Top = 6
               Left = 246
               Bottom = 136
               Right = 489
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp2_1"
            Begin Extent = 
               Top = 6
               Left = 527
               Bottom = 136
               Right = 711
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sbm"
            Begin Extent = 
               Top = 270
               Left = 482
               Bottom = 400
               Right = 652
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "srf"
            Begin Extent = 
               Top = 270
               Left = 690
               Bottom = 400
               Right = 891
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "vcp"
            Begin Extent = 
               Top = 666
               Left = 926
               Bottom = 796
               Right = 1096
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "vcs"
            Begin Extent = 
               Top = 798
               Left = 38
               Bottom = 928
               Right = 208
            End
            DisplayFlags = 280
       '' , @level0type=N''SCHEMA'',@level0name=N''dbo'', @level1type=N''VIEW'',@level1name=N''OIG_Prequal_Hist_2''
GO

EXEC sys.sp_addextendedproperty @name=N''MS_DiagramPane2'', @value=N''     TopColumn = 0
         End
         Begin Table = "sp5"
            Begin Extent = 
               Top = 6
               Left = 749
               Bottom = 136
               Right = 933
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp6"
            Begin Extent = 
               Top = 138
               Left = 38
               Bottom = 268
               Right = 222
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp7"
            Begin Extent = 
               Top = 138
               Left = 260
               Bottom = 268
               Right = 444
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp9"
            Begin Extent = 
               Top = 138
               Left = 482
               Bottom = 268
               Right = 666
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp8"
            Begin Extent = 
               Top = 138
               Left = 704
               Bottom = 268
               Right = 888
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp11"
            Begin Extent = 
               Top = 138
               Left = 926
               Bottom = 268
               Right = 1110
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp12"
            Begin Extent = 
               Top = 270
               Left = 38
               Bottom = 400
               Right = 222
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp82"
            Begin Extent = 
               Top = 270
               Left = 260
               Bottom = 400
               Right = 444
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp43"
            Begin Extent = 
               Top = 270
               Left = 929
               Bottom = 400
               Right = 1113
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp44"
            Begin Extent = 
               Top = 402
               Left = 38
               Bottom = 532
               Right = 222
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp45"
            Begin Extent = 
               Top = 402
               Left = 260
               Bottom = 532
               Right = 444
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp57"
            Begin Extent = 
               Top = 402
               Left = 482
               Bottom = 532
               Right = 666
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp58"
            Begin Extent = 
               Top = 402
               Left = 704
               Bottom = 532
               Right = 888
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp59"
            Begin Extent = 
               Top = 402
               Left = 926
               Bottom = 532
               Right = 1110
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp60"
            Begin Extent = 
               Top = 5'' , @level0type=N''SCHEMA'',@level0name=N''dbo'', @level1type=N''VIEW'',@level1name=N''OIG_Prequal_Hist_2''
GO

EXEC sys.sp_addextendedproperty @name=N''MS_DiagramPane3'', @value=N''34
               Left = 38
               Bottom = 664
               Right = 222
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp61"
            Begin Extent = 
               Top = 534
               Left = 260
               Bottom = 664
               Right = 444
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp62"
            Begin Extent = 
               Top = 534
               Left = 482
               Bottom = 664
               Right = 666
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp63"
            Begin Extent = 
               Top = 534
               Left = 704
               Bottom = 664
               Right = 888
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp64"
            Begin Extent = 
               Top = 534
               Left = 926
               Bottom = 664
               Right = 1110
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp65"
            Begin Extent = 
               Top = 666
               Left = 38
               Bottom = 796
               Right = 222
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp66"
            Begin Extent = 
               Top = 666
               Left = 260
               Bottom = 796
               Right = 444
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp67"
            Begin Extent = 
               Top = 666
               Left = 482
               Bottom = 796
               Right = 666
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "sp69"
            Begin Extent = 
               Top = 666
               Left = 704
               Bottom = 796
               Right = 888
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 45
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      PaneHidden = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy ='' , @level0type=N''SCHEMA'',@level0name=N''dbo'', @level1type=N''VIEW'',@level1name=N''OIG_Prequal_Hist_2''
GO

EXEC sys.sp_addextendedproperty @name=N''MS_DiagramPane4'', @value=N'' 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
'' , @level0type=N''SCHEMA'',@level0name=N''dbo'', @level1type=N''VIEW'',@level1name=N''OIG_Prequal_Hist_2''
GO

EXEC sys.sp_addextendedproperty @name=N''MS_DiagramPaneCount'', @value=4 , @level0type=N''SCHEMA'',@level0name=N''dbo'', @level1type=N''VIEW'',@level1name=N''OIG_Prequal_Hist_2''
GO


', 
		@database_name=N'NYCSCA_VAS_STAGE', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'OIG Refresh Shcedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=63, 
		@freq_subday_type=8, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170824, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'da68306b-ba8f-423e-b7d4-17c8c2c2da1c'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


