USE [msdb]
GO

/****** Object:  Job [QA Reset Email]    Script Date: 5/31/2019 1:26:53 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 5/31/2019 1:26:53 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'QA Reset Email', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'SCAVASSQLTEST01\Administrator', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Reset Email]    Script Date: 5/31/2019 1:26:53 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Reset Email', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N''xfaceprod'')
	DROP USER [xfaceprod];
GO


sp_change_users_login ''update_one'', ''xfacetest'', ''xfacetest'';
GO
sp_change_users_login ''update_one'', ''xfaceread'', ''xfaceread'';
GO

update vendorcontact set email=''test@nycsca.org'' where email is not null;
GO
update supplier set email=''test@nycsca.org'' where email is not null;
GO
update [user] set email=''test@nycsca.org'' where email is not null;
GO
update aspnet_membership set email=''test@nycsca.org'', loweredemail=''test@nycsca.org'' where email is not null;
GO
update supplierproperty set propertytext =''test@nycsca.org'' where propertyId in (442, 444)
GO
update subcontractorproperty set propertytext =''test@nycsca.org'' where propertyId in (3, 39)
GO
update [plan] set eeocontactemail =''test@nycsca.org''
GO
update jobschedule set isactive=''N''
GO
update [EmailMessage] set toEmail=''test@nycsca.org'' where toemail is not null
GO
 update [EmailMessage] set ccEmail=''test@nycsca.org'' where (ccEmail is not null and ccemail<>'''')
GO
 update [EmailMessage] set bccEmail=''test@nycsca.org'' where(bccEmail is not null and bccemail<>'''')
GO
update [PlanSubcontractor] set [ContactEmail] =''test@nycsca.org'' where [ContactEmail] is not null
GO
update scorecard set email=''test@nycsca.org'' where email is not null
GO
update supplier set prepareremail=''test@nycsca.org'' where prepareremail is not null
Go
 update [cms_report_vendor] set c_email=''test@nycsca.org'' where c_email is not null
Go
 update [cms_report_vendor] set c_email2=''test@nycsca.org'' where c_email2 is not null
Go
 update [cms_report_vendor] set c_email3=''test@nycsca.org'' where c_email3 is not null
Go
 update [cms_report_vendor] set secondary_email=''test@nycsca.org'' where secondary_email is not null
 Go
 update [cms_vendor] set c_email=''test@nycsca.org'' where c_email is not null
Go
 update [cms_vendor] set c_email2=''test@nycsca.org'' where c_email2 is not null
Go
 update [cms_vendor] set c_email3=''test@nycsca.org'' where c_email3 is not null
Go
 update [cms_vendor] set secondary_email=''test@nycsca.org'' where secondary_email is not null
Go
update [PlanWaiver] set  [AdsContactEmail] =''test@nycsca.org'' where [AdsContactEmail] is not null
go
update [owner] set email=''test@nycsca.org'' where email is not null;
go
update [Event] set email=''test@nycsca.org'' where email is not null;
go
update emailmessage set ToEmail=''$USEREMAIL$'' 
where name in (''USER_PASSWORD_REMINDER'',''NEW_USER_REGISTRATION'',''USER_USERNAME_REMINDER'',''USER_ACCOUNT_LOCK'',''USER_ACCOUNT_UNLOCK'',''USER_PASSWORD_RESET'')
go', 
		@database_name=N'EEOQA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


