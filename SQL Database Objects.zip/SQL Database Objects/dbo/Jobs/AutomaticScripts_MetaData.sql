﻿/*
This script was created by Visual Studio on 8/25/2014 at 2:39 PM.
Run this script on SCAVASSQLTEST01.NYCSCA_VAS (aec) to make it the same as 10.211.5.81.NYCSCA_VAS (aec).
This script performs its actions in the following order:
1. Disable foreign-key constraints.
2. Perform DELETE commands. 
3. Perform UPDATE commands.
4. Perform INSERT commands.
5. Re-enable foreign-key constraints.
Please back up your target database before running this script.
*/
SET NUMERIC_ROUNDABORT OFF
GO
SET XACT_ABORT, ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
/*Pointer used for text / image updates. This might not be needed, but is declared here just in case*/
DECLARE @pv binary(16)
BEGIN TRANSACTION
ALTER TABLE [dbo].[WorkflowCondition] DROP CONSTRAINT [FK_WorkflowCondition_WorkflowNode]
ALTER TABLE [dbo].[WorkflowPermission] DROP CONSTRAINT [FK_WorkflowPermission_WorkflowNode]
ALTER TABLE [dbo].[OutlookPermission] DROP CONSTRAINT [FK_OutlookPermission_aspnet_Roles]
ALTER TABLE [dbo].[OutlookPermission] DROP CONSTRAINT [FK_OutlookPermission_Outlook]
ALTER TABLE [dbo].[WorkflowNodeUser] DROP CONSTRAINT [FK_WorkflowNodeUser_aspnet_Roles]
ALTER TABLE [dbo].[WorkflowNodeUser] DROP CONSTRAINT [FK_WorkflowNodeUser_WorkflowNode]
ALTER TABLE [dbo].[WorkflowAction] DROP CONSTRAINT [FK_WorkflowAction_WorkflowNode]
ALTER TABLE [dbo].[WorkflowNode] DROP CONSTRAINT [FK_WorkflowNode_NodeCondition]
ALTER TABLE [dbo].[WorkflowNode] DROP CONSTRAINT [FK_WorkflowNode_NodeType]
ALTER TABLE [dbo].[WorkflowNode] DROP CONSTRAINT [FK_WorkflowNode_Workflow]
ALTER TABLE [dbo].[PermissionDetail] DROP CONSTRAINT [FK_PermissionDetail_Menu]
ALTER TABLE [dbo].[PermissionDetail] DROP CONSTRAINT [FK_PermissionDetail_Permission]
ALTER TABLE [dbo].[Menu] DROP CONSTRAINT [FK_Menu_Menu]
DELETE FROM [dbo].[OutlookPermission] WHERE [Id]=3543
DELETE FROM [dbo].[OutlookPermission] WHERE [Id]=3544
DELETE FROM [dbo].[OutlookPermission] WHERE [Id]=3684
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4944
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4945
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4946
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4947
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4948
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4950
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4952
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4955
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4956
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4957
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4959
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4960
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4961
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4962
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4963
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4965
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4966
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4967
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4968
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4969
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4970
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4971
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4972
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4973
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4974
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4975
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4976
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4977
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4979
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4980
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4981
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4982
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4983
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4984
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4985
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4986
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4987
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4988
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4989
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4990
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4991
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4992
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4993
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4994
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4995
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4996
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4997
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4998
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=4999
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5000
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5002
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5003
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5004
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5006
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5007
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5008
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5009
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5010
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5011
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5012
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5013
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5030
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5517
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5597
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5603
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5648
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5650
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5740
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5744
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5772
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5778
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5842
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=5854
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=6290
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=6974
DELETE FROM [dbo].[PermissionDetail] WHERE [Id]=7018
UPDATE [dbo].[EmailMessage] SET [BccEmail]=N'', [Body]=N'
		<font face="Arial" size="2">$DATE$<br /><br />This is a notification that the list for $RFCPACKAGENUMBER$ - $RFDPROJECTDESCRIPTION$ has been <strong><font color="#008000">approved</font></strong>.<br /><br />You may <a href="$INTERNALSITEURL$Rfd/Project_Info.aspx?Id=$RFDPROJECTID$">click here</a> to view the final list.<br /><br /><br />Thanks,<br />$COMPANY$ VAS Administrator</font>
' WHERE [Id]=146
UPDATE [dbo].[EmailMessage] SET [ToEmail]=N'$BDDANALYSTEMAIL$' WHERE [Id]=305
UPDATE [dbo].[Outlook] SET [Url]=N'~/Supplier/Supplier_Amend_1MM_Results.aspx' WHERE [Id]=633
UPDATE [dbo].[Outlook] SET [Url]=N'~/Supplier/Supplier_Amend_1MM_Results.aspx' WHERE [Id]=634
UPDATE [dbo].[Outlook] SET [Url]=N'~/Supplier/Supplier_Amend_1MM_Results.aspx' WHERE [Id]=635
UPDATE [dbo].[Outlook] SET [Url]=N'~/Supplier/Supplier_Amend_1MM_Results.aspx' WHERE [Id]=636
UPDATE [dbo].[Outlook] SET [Url]=N'~/Supplier/Supplier_Amend_1MM_Results.aspx' WHERE [Id]=637
UPDATE [dbo].[Outlook] SET [Url]=N'~/Supplier/Supplier_Amend_1MM_Results.aspx' WHERE [Id]=638
UPDATE [dbo].[Outlook] SET [Url]=N'~/Supplier/Supplier_Amend_1MM_Results.aspx' WHERE [Id]=639
UPDATE [dbo].[Menu] SET [Display]=N'N' WHERE [Id]=80
SET IDENTITY_INSERT [dbo].[Menu] ON
INSERT INTO [dbo].[Menu] ([Id], [Text], [ToolTip], [ImgLeft], [ImgRight], [Url], [DisplayOrder], [ParentId], [ApplicationId], [Display], [Content], [Help], [Type]) VALUES (29959, N'Mentor Bid Activity Report', N'Mentor Bid Activity Report', N'', N'', N'~/Report/MentorBidActivityReport.aspx', 7, 3143, N'6716fdd2-9448-4c7b-b89d-70f09c901448', N'Y', NULL, NULL, N'System')
INSERT INTO [dbo].[Menu] ([Id], [Text], [ToolTip], [ImgLeft], [ImgRight], [Url], [DisplayOrder], [ParentId], [ApplicationId], [Display], [Content], [Help], [Type]) VALUES (29960, N'SUP Monthly Report', N'SUP Monthly Report', N'', N'', N'~/Report/SUP_Monthly_Report.aspx ', 8, 3143, N'6716fdd2-9448-4c7b-b89d-70f09c901448', N'Y', NULL, NULL, N'System')
SET IDENTITY_INSERT [dbo].[Menu] OFF
SET IDENTITY_INSERT [dbo].[PermissionDetail] ON
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7276, 348, 29959, N'Menu', N'', 15, N'', 0)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7277, 348, 29960, N'Menu', N'', 15, N'', 0)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7278, 111, 3140, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7279, 111, 3159, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7280, 111, 3241, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7281, 111, 2, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7282, 111, 3, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7283, 111, 6, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7284, 111, 1282, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7285, 111, 1285, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7286, 111, 1434, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7287, 111, 2146, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7288, 111, 2585, N'Control', N'supplierGrid:::qualHistoryButton', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7289, 111, 2585, N'Control', N'supplierGrid:::certHistoryButton', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7290, 111, 2585, N'Control', N'supplierGrid:::WorkflowLink', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7291, 111, 2585, N'Control', N'supplierGrid:::AppendixAButton', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7292, 111, 2585, N'Control', N'supplierGrid:::QualStepLink', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7293, 111, 2585, N'Control', N'supplierGrid:::CertStepLink', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7294, 111, 2585, N'Control', N'supplierGrid:::VersionButton', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7295, 111, 2615, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7296, 111, 2670, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7297, 111, 2671, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7298, 111, 2673, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7299, 111, 2674, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7300, 111, 2675, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7301, 111, 2676, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7302, 111, 2677, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7303, 111, 2679, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7304, 111, 2680, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7305, 111, 2681, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7306, 111, 2682, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7307, 111, 2683, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7308, 111, 2684, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7309, 111, 2685, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7310, 111, 2689, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7311, 111, 2690, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7312, 111, 2702, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7313, 111, 2704, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7314, 111, 2720, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7315, 111, 2721, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7316, 111, 2729, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7317, 111, 2730, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7318, 111, 2731, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7319, 111, 2732, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7320, 111, 2733, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7321, 111, 2734, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7322, 111, 2737, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7323, 111, 2738, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7324, 111, 2746, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7325, 111, 2747, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7326, 111, 2748, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7327, 111, 2751, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7328, 111, 2752, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7329, 111, 2754, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7330, 111, 2888, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7331, 111, 2914, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7332, 111, 2915, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7333, 111, 2916, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7334, 111, 2917, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7335, 111, 2920, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7336, 111, 2921, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7337, 111, 2923, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7338, 111, 2926, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7339, 111, 2941, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7340, 111, 2969, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7341, 111, 2970, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7342, 111, 3003, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7343, 111, 3024, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7344, 111, 3117, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7345, 111, 3123, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7346, 111, 3127, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7347, 111, 3141, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7348, 111, 3157, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7349, 111, 3187, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7350, 111, 3256, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7351, 111, 28930, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7352, 111, 28945, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7353, 111, 28954, N'Menu', N'', 15, N'', NULL)
INSERT INTO [dbo].[PermissionDetail] ([Id], [PermissionId], [MenuId], [Type], [ControlName], [PermissionValue], [Description], [Status]) VALUES (7354, 111, 29960, N'Menu', N'', 15, N'', NULL)
SET IDENTITY_INSERT [dbo].[PermissionDetail] OFF
SET IDENTITY_INSERT [dbo].[OutlookPermission] ON
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5983, 635, N'2fef17fb-ea30-4b36-af8f-99934f83b0c4', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5984, 157, N'2fef17fb-ea30-4b36-af8f-99934f83b0c4', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5985, 158, N'2fef17fb-ea30-4b36-af8f-99934f83b0c4', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5986, 633, N'6f9044b3-8f97-4a34-a699-3ae573f1a043', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5987, 634, N'6f9044b3-8f97-4a34-a699-3ae573f1a043', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5988, 635, N'6f9044b3-8f97-4a34-a699-3ae573f1a043', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5989, 636, N'6f9044b3-8f97-4a34-a699-3ae573f1a043', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5990, 637, N'6f9044b3-8f97-4a34-a699-3ae573f1a043', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5991, 638, N'6f9044b3-8f97-4a34-a699-3ae573f1a043', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5992, 639, N'6f9044b3-8f97-4a34-a699-3ae573f1a043', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5993, 627, N'6f9044b3-8f97-4a34-a699-3ae573f1a043', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5994, 628, N'6f9044b3-8f97-4a34-a699-3ae573f1a043', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5995, 629, N'6f9044b3-8f97-4a34-a699-3ae573f1a043', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5996, 630, N'6f9044b3-8f97-4a34-a699-3ae573f1a043', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5997, 631, N'6f9044b3-8f97-4a34-a699-3ae573f1a043', 15, 0, NULL)
INSERT INTO [dbo].[OutlookPermission] ([Id], [OutlookId], [RoleId], [PermissionId], [Status], [UserId]) VALUES (5998, 632, N'6f9044b3-8f97-4a34-a699-3ae573f1a043', 15, 0, NULL)
SET IDENTITY_INSERT [dbo].[OutlookPermission] OFF


INSERT INTO [SupplierPropertyDesc] ([Id],[Desc],[Page],[Internal])VALUES
(542,'Certification interview Comment','Workflow_Cert_Interview.aspx','internal')
go
INSERT INTO [SupplierPropertyDesc] ([Id],[Desc],[Page],[Internal])VALUES
(543,'Certification interview Validation','Workflow_Cert_Interview.aspx','internal')
go


ALTER TABLE [dbo].[WorkflowCondition]
    WITH NOCHECK ADD CONSTRAINT [FK_WorkflowCondition_WorkflowNode] FOREIGN KEY ([WorkflowNodeId]) REFERENCES [dbo].[WorkflowNode] ([Id])
ALTER TABLE [dbo].[WorkflowPermission]
    WITH NOCHECK ADD CONSTRAINT [FK_WorkflowPermission_WorkflowNode] FOREIGN KEY ([WorkflowNodeId]) REFERENCES [dbo].[WorkflowNode] ([Id])
ALTER TABLE [dbo].[OutlookPermission]
    ADD CONSTRAINT [FK_OutlookPermission_aspnet_Roles] FOREIGN KEY ([RoleId]) REFERENCES [dbo].[aspnet_Roles] ([RoleId])
ALTER TABLE [dbo].[OutlookPermission]
    WITH NOCHECK ADD CONSTRAINT [FK_OutlookPermission_Outlook] FOREIGN KEY ([OutlookId]) REFERENCES [dbo].[Outlook] ([Id])
ALTER TABLE [dbo].[WorkflowNodeUser]
    ADD CONSTRAINT [FK_WorkflowNodeUser_aspnet_Roles] FOREIGN KEY ([RoleId]) REFERENCES [dbo].[aspnet_Roles] ([RoleId])
ALTER TABLE [dbo].[WorkflowNodeUser]
    ADD CONSTRAINT [FK_WorkflowNodeUser_WorkflowNode] FOREIGN KEY ([WorkflowNodeId]) REFERENCES [dbo].[WorkflowNode] ([Id])
ALTER TABLE [dbo].[WorkflowAction]
    ADD CONSTRAINT [FK_WorkflowAction_WorkflowNode] FOREIGN KEY ([WorkflowNodeId]) REFERENCES [dbo].[WorkflowNode] ([Id])
ALTER TABLE [dbo].[WorkflowNode]
    ADD CONSTRAINT [FK_WorkflowNode_NodeCondition] FOREIGN KEY ([ConditionId]) REFERENCES [dbo].[NodeCondition] ([Id])
ALTER TABLE [dbo].[WorkflowNode]
    ADD CONSTRAINT [FK_WorkflowNode_NodeType] FOREIGN KEY ([Type]) REFERENCES [dbo].[NodeType] ([Id])
ALTER TABLE [dbo].[WorkflowNode]
    WITH NOCHECK ADD CONSTRAINT [FK_WorkflowNode_Workflow] FOREIGN KEY ([WorkflowId]) REFERENCES [dbo].[WorkflowList] ([Id])
ALTER TABLE [dbo].[PermissionDetail]
    WITH NOCHECK ADD CONSTRAINT [FK_PermissionDetail_Menu] FOREIGN KEY ([MenuId]) REFERENCES [dbo].[Menu] ([Id])
ALTER TABLE [dbo].[PermissionDetail]
    WITH NOCHECK ADD CONSTRAINT [FK_PermissionDetail_Permission] FOREIGN KEY ([PermissionId]) REFERENCES [dbo].[Permission] ([Id])
ALTER TABLE [dbo].[Menu]
    WITH NOCHECK ADD CONSTRAINT [FK_Menu_Menu] FOREIGN KEY ([ParentId]) REFERENCES [dbo].[Menu] ([Id])
COMMIT TRANSACTION
