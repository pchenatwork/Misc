﻿/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	 This job is all CMS, so is to be replaced by new
	   migrated cms import job -jw
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

-- ***************************************************** EEO Related tabled used in Subaward report
 

--EEO_DETAIL
Begin transaction
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'dbo' 
                 AND  TABLE_NAME = 'cms_eeo_detail'))
	begin
		select * into cms_eeo_detail from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM eeo_detail ') where 1=2
	end 
	 
	truncate table cms_eeo_detail
	insert into cms_eeo_detail
	select * from openquery(nycsca_cms,'select * from eeo_detail') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go
--PROJECT
Begin transaction
      truncate table CMS_PROJECT    
	  
      insert into CMS_PROJECT 
      select * From 
      OPENQUERY(NYCSCA_CMS, 'SELECT * FROM PROJECT')
	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end 
Commit Transaction
go
--BIDDER
Begin transaction
	 --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'dbo' 
                 AND  TABLE_NAME = 'cms_bidder'))
	begin
		select * into cms_bidder from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM bidder ') where 1=2
	end 
	 
	truncate table cms_bidder
	insert into cms_bidder
	select * from openquery(nycsca_cms,'select * from bidder') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go

--BIDDER_REJECT
Begin transaction
	 --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'dbo' 
                 AND  TABLE_NAME = 'cms_bidder_reject'))
	begin
		select * into cms_bidder_reject from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM bidder_reject ') where 1=2
	end 
	 
	truncate table cms_bidder_reject
	insert into cms_bidder_reject
	select * from openquery(nycsca_cms,'select * from bidder_reject') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go
--VENDOR
Begin transaction
	 --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'dbo' 
                 AND  TABLE_NAME = 'cms_vendor'))
	begin
		select * into cms_vendor from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM vendor ') where 1=2
	end 
	 
	truncate table cms_vendor
	insert into cms_vendor
	select * from openquery(nycsca_cms,'select * from vendor') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go
--LLW
Begin transaction
	 --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'dbo' 
                 AND  TABLE_NAME = 'cms_LLW'))
	begin
		select * into cms_LLW from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM LLW ') where 1=2
	end 
	 
	truncate table cms_LLW
	insert into cms_LLW
	select * from openquery(nycsca_cms,'select * from LLW') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go
--SCHOOL
Begin transaction
	 --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'dbo' 
                 AND  TABLE_NAME = 'cms_SCHOOL'))
	begin
		select * into cms_SCHOOL from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM school ') where 1=2
	end 
	 
	truncate table cms_SCHOOL
	insert into cms_SCHOOL
	select * from openquery(nycsca_cms,'select * from school') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go
--PROJ_LLW
Begin transaction
	 --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'dbo' 
                 AND  TABLE_NAME = 'cms_PROJ_LLW'))
	begin
		select * into cms_PROJ_LLW from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM proj_llw ') where 1=2
	end 
	 
	truncate table cms_PROJ_LLW
	insert into cms_PROJ_LLW
	select * from openquery(nycsca_cms,'select * from proj_llw') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go
--PROJ_CTYPE
Begin transaction
	 --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'dbo' 
                 AND  TABLE_NAME = 'cms_proj_ctype'))
	begin
		select * into cms_proj_ctype from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM proj_ctype ') where 1=2
	end 
	 
	truncate table cms_proj_ctype
	insert into cms_proj_ctype
	select * from openquery(nycsca_cms,'select * from proj_ctype') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go
--contract
Begin transaction
	  --Select * into cms_Contract from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Contract') 
	  truncate table cms_Contract
	  insert into cms_Contract 
	  select * From 
	  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Contract')  
	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
			
		end
commit transaction
Go
--subcont
Begin transaction
	  --Select * into cms_SUBCONT  from OPENQUERY(NYCSCA_CMS, 'SELECT * FROM SUBCONT ')
	  
	  truncate table cms_SUBCONT
	  insert into cms_SUBCONT 
	  select * From 
	  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM SUBCONT')  
	  
	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
			
		end
commit transaction
Go
--bidder_wicks
Begin transaction
	  --select * into cms_Bidder_Wicks from openquery(Nycsca_ces, 'select * from Bidder_Wicks') -- view does not exist
	  truncate table cms_Bidder_Wicks
	  insert into cms_Bidder_Wicks 
	  select * From 
	  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Bidder_Wicks')  
	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
			
		end
commit transaction
Go
--Project_bid
Begin transaction
	  --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	  truncate table cms_Project_bid
	  insert into cms_Project_bid 
	  select * From 
	  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid')  
	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
			
		end
commit transaction
Go
--EEO_CERT_STATUS
 Begin transaction
	 --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'dbo' 
                 AND  TABLE_NAME = 'cms_EEO_CERT_STATUS'))
	begin
		select * into cms_EEO_CERT_STATUS from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM EEO_CERT_STATUS') where 1=2
	end 
	 
	truncate table cms_EEO_CERT_STATUS
	insert into cms_EEO_CERT_STATUS
	select * from openquery(nycsca_cms,'select * from EEO_CERT_STATUS ') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go
--VAS_COND_CERT_DATA
 Begin transaction
	 --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA ='dbo' 
                 AND  TABLE_NAME = 'cms_VAS_COND_CERT_DATA'))
	begin
		select * into cms_VAS_COND_CERT_DATA from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM VAS_COND_CERT_DATA') where 1=2
	end 
	 
	truncate table cms_VAS_COND_CERT_DATA
	insert into cms_VAS_COND_CERT_DATA
	select * from openquery(nycsca_cms,'select * from VAS_COND_CERT_DATA ') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go

 
--EEO_MASTER
 Begin transaction
	 --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'dbo' 
                 AND  TABLE_NAME = 'cms_EEO_MASTER'))
	begin
		select * into cms_EEO_MASTER from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM EEO_MASTER') where 1=2
	end 
	 
	truncate table cms_EEO_MASTER
	insert into cms_EEO_MASTER
	select * from openquery(nycsca_cms,'select * from EEO_MASTER ') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go
--DA_VENDOR_DUMP
 Begin transaction
	 --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'dbo' 
                 AND  TABLE_NAME = 'cms_DA_VENDOR_DUMP'))
	begin
		select * into cms_DA_VENDOR_DUMP from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM DA_VENDOR_DUMP') where 1=2
	end 
	 
	truncate table cms_DA_VENDOR_DUMP
	insert into cms_DA_VENDOR_DUMP
	select * from openquery(nycsca_cms,'select * from DA_VENDOR_DUMP ') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go
--VENDOR_TRADE_UNI
 Begin transaction
	 --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'dbo' 
                 AND  TABLE_NAME = 'cms_VENDOR_TRADE_UNI'))
	begin
		select * into cms_VENDOR_TRADE_UNI from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM VENDOR_TRADE_UNI') where 1=2
	end 
	 
	truncate table cms_VENDOR_TRADE_UNI
	insert into cms_VENDOR_TRADE_UNI
	select * from openquery(nycsca_cms,'select * from VENDOR_TRADE_UNI ') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go
--MENTOR_CONTRACT_VIEW
 Begin transaction
	 --select * into cms_Project_bid from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM Project_bid ')
	 IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'dbo' 
                 AND  TABLE_NAME = 'cms_MENTOR_CONTRACT_VIEW'))
	begin
		select * into cms_MENTOR_CONTRACT_VIEW from  OPENQUERY(NYCSCA_CMS, 'SELECT * FROM MENTOR_CONTRACT_VIEW') where 1=2
	end 
	 
	truncate table cms_MENTOR_CONTRACT_VIEW
	insert into cms_MENTOR_CONTRACT_VIEW
	select * from openquery(nycsca_cms,'select * from MENTOR_CONTRACT_VIEW ') 

	  if @@error <> 0
		begin
			ROLLBACK TRANSACTION
		end
commit transaction
go


 


 
-- ***************************************************** EEO Related tabled used in Subaward report **********************************************************************