﻿/** CMS Refresh Items **/
--    imported from production 1/21/2021

declare @reslt nvarchar(1000)

exec ImportFromCMS 'ADHOC_PREQUAL_HIST', 1000, @reslt out
print @reslt

exec ImportFromCMS 'APPRENT_PROG', 50, @reslt out
print @reslt

exec ImportFromCMS 'BIDDER', 1000, @reslt out							-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'BIDDER_REJECT', 1000, @reslt out					-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'BIDDER_WICKS', 1000, @reslt out						-- From Populate CES-CMS Views, From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'BIDPART_INVENTORY', 1000, @reslt out				-- From Populate CES-CMS Views
print @reslt

exec ImportFromCMS 'BIDTRAN_VENDOR_SUMMARY', 100, @reslt out			-- From Populate CES-CMS Views
print @reslt

exec ImportFromCMS 'CONTRACT', 1000, @reslt out							-- From Populate CES-CMS Views, From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'CONTRACT_EVAL', 1000, @reslt out					-- From Populate CES-CMS Views
print @reslt

exec ImportFromCMS 'DA_VENDOR_DUMP', 1000, @reslt out					-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'EEO_ASSESSMENT_PERIOD', 2, @reslt out
print @reslt

exec ImportFromCMS 'EEO_CERT_STATUS', 1000, @reslt out					-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'EEO_DETAIL', 1000, @reslt out						-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'EEO_DETAIL_RECERT', 200, @reslt out
print @reslt

exec ImportFromCMS 'EEO_MASTER', 1000, @reslt out						-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'EEO_MATRIX', 100, @reslt out
print @reslt

exec ImportFromCMS 'EEO_MENTOR_DETAIL', 200, @reslt out					-- From Populate CES-CMS Views
print @reslt

exec ImportFromCMS 'EEO_MENTOR_GRAD_DETAIL', 100, @reslt out			-- From Populate CES-CMS Views
print @reslt

exec ImportFromCMS 'EEO_MENTOR_PPM_RATING', 100, @reslt out
print @reslt

exec ImportFromCMS 'EEO_VASDATALOAD', 1000, @reslt out
print @reslt

exec ImportFromCMS 'ENTITY_LIST', 5, @reslt out
print @reslt

exec ImportFromCMS 'EVAL_STAGE', 7, @reslt out							-- From Populate CES-CMS Views
print @reslt

exec ImportFromCMS 'LLW', 10000, @reslt out								-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'MENTOR_CONTRACT_VIEW', 500, @reslt out				-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'PREQUAL_HIST', 5000, @reslt out
print @reslt

exec ImportFromCMS 'PRIME_APPRENT', 1000, @reslt out
print @reslt

exec ImportFromCMS 'PROJ_CTYPE', 10, @reslt out							-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'PROJ_LLW', 1000, @reslt out							-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'PROJECT', 1000, @reslt out							-- From Populate CES-CMS Views	-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'PROJECT_BID', 1000, @reslt out						-- From Populate CES-CMS Views	-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'PROJECT_RFP', 1000, @reslt out						-- Added by Paul 20.14
print @reslt

exec ImportFromCMS 'REV_STATUS_VENDOR', 10, @reslt out
print @reslt

exec ImportFromCMS 'RFP_SVCE_TYPE', 100, @reslt out						-- Added by Paul 20.14
print @reslt

exec ImportFromCMS 'SCHOOL', 1000, @reslt out							-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'SUB_TRADE', 10000, @reslt out						-- From Populate CES-CMS Views
print @reslt

exec ImportFromCMS 'SUBCONT', 20000, @reslt out							-- From Populate CES-CMS Views	-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'SUPP_AGREEMENT', 500, @reslt out					-- added 1/21 for RFP JM
print @reslt

exec ImportFromCMS 'TITLES', 10, @reslt out
print @reslt

exec ImportFromCMS 'TRADE_LIST', 100, @reslt out
print @reslt

exec ImportFromCMS 'VAS_COND_CERT_DATA', 200, @reslt out				-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'VENDOR', 1000, @reslt out							-- From Populate CES-CMS Views, From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'VENDOR_DETAIL', 1000, @reslt out
print @reslt

exec ImportFromCMS 'VENDOR_DISQUAL', 100, @reslt out
print @reslt

exec ImportFromCMS 'VENDOR_SOLICITATION', 1000, @reslt out
print @reslt

exec ImportFromCMS 'VENDOR_STATUS', 1000, @reslt out
print @reslt

exec ImportFromCMS 'VENDOR_TRADE', 1000, @reslt out						-- From Populate CES-CMS Views
print @reslt

exec ImportFromCMS 'VENDOR_TRADE_UNI', 200, @reslt out					-- From Populate SubAward Report Tables
print @reslt

exec ImportFromCMS 'VENDOR_VERIFICATION', 500, @reslt out
print @reslt

exec ImportFromCMS 'YEARLY_SALES', 1000, @reslt out
print @reslt

/*****************************************************

	POST PROCESSING

******************************************************/

/* TRUNCATE C_WHOEDIT FIELD DATA FROM CMS */

-- truncate data in the newly enlarged C_WHOEDIT fields to max length of 6 characters
declare @TablesWithWhoedit table (TableName varchar(100), ColumnName varchar(100))

-- get list of all cms_ tables with C_WHOEDIT
insert into @TablesWithWhoedit
	select TABLE_NAME as TableName, COLUMN_NAME as ColumnName from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME like 'cms_%' and COLUMN_NAME = 'C_WHOEDIT'

-- set up cursor to iterate the list of tables
declare @thistable varchar(100), @thiscolumn varchar(100)
declare @cursor as cursor
set @cursor = cursor for 
	select TableName, ColumnName from @TablesWithWhoedit

-- for each cms_ table with a C_WHOEDIT
open @cursor
fetch next from @cursor into @thistable, @thiscolumn
while @@FETCH_STATUS = 0
begin
	print 'truncating ' + @thiscolumn + ' column data in ' + @thistable
	-- wherever the data in the C_WHOEDIT field is longer than 6, truncate it to 6 characters
	declare @sql nvarchar(1000) = N'update ' + @thistable + ' set ' + @thiscolumn + ' = left(' + @thiscolumn + ',6) where len(' + @thiscolumn + ') > 6'
	exec sp_executesql @sql

	fetch next from @cursor into @thistable, @thiscolumn

end

/* TRUNCATE C_SCHOOL_NAME IN CMS_SCHOOL */

update cms_SCHOOL set c_school_name = left(c_school_name,30) where len(c_school_name) > 30


/*****************************************************

	BUILD DERIVED TABLES

******************************************************/

-- From Populate CES-CMS Views
Begin transaction 
truncate table MV_CURR_Grad_MENTOR_LIST  
insert into MV_CURR_Grad_MENTOR_LIST
SELECT	V.VASID AS VENDOR_VASID, 
		D.C_VENDOR_ID AS TAX_ID, 
		'GRAD MENTOR' AS PROGRAM_TYPE, 
		D.SD_START_DATE AS START_DATE, 
		ISNULL(D.SD_EXT_GRAD_DATE, D.SD_GRAD_DATE) AS TARGET_GRAD_DATE,
		SD_ACTUAL_GRAD_DT AS ACTUAL_GRAD_DATE,
		SD_END AS TERMINATION_DATE

FROM	cms_VENDOR v, cms_EEO_MENTOR_GRAD_DETAIL d
WHERE	v.c_vendor_id = d.c_vendor_id
AND		d.i_upd_seq = (SELECT MAX(i_upd_seq)
                    FROM cms_EEO_MENTOR_GRAD_DETAIL d2
                    WHERE d2.C_VENDOR_ID = d.c_vendor_id )
AND (SD_END IS NULL OR (SD_END IS NOT NULL AND SD_END > CONVERT(datetime, (CONVERT(CHAR(12), GETDATE()))) ))
AND (SD_ACTUAL_GRAD_DT IS NULL OR (SD_ACTUAL_GRAD_DT IS NOT NULL AND SD_ACTUAL_GRAD_DT > CONVERT(datetime, (CONVERT(CHAR(12), GETDATE()))) ))
AND (( d.sd_ext_grad_date IS NULL
                AND CONVERT(datetime, (CONVERT(CHAR(12), GETDATE())))
                        BETWEEN sd_start_date AND sd_grad_date)
    OR ( sd_ext_grad_date IS NOT NULL
                AND CONVERT(datetime, (CONVERT(CHAR(12), GETDATE())))
                                    BETWEEN sd_start_date AND sd_ext_grad_date))

if @@error <> 0
	ROLLBACK TRANSACTION
else
	COMMIT TRANSACTION

-- From Populate CES-CMS Views
Begin transaction
	truncate table MV_CURR_MENTOR_LIST  
	insert into MV_CURR_MENTOR_LIST
	SELECT	V.VASID AS VENDOR_VASID, 
			D.C_VENDOR_ID AS TAX_ID, 
			'MENTOR' AS PROGRAM_TYPE, 
			D.SD_START_DATE AS START_DATE, 
			ISNULL(D.SD_EXT_GRAD_DATE, D.SD_GRAD_DATE) AS TARGET_GRAD_DATE,
			SD_ACTUAL_GRAD_DT AS ACTUAL_GRAD_DATE,
			SD_END AS TERMINATION_DATE
	FROM	cms_VENDOR v, cms_EEO_MENTOR_DETAIL d
	WHERE	v.c_vendor_id = d.c_vendor_id
	AND		d.i_upd_seq = (SELECT MAX(i_upd_seq)
                    FROM cms_EEO_MENTOR_DETAIL d2
                    WHERE d2.C_VENDOR_ID = d.c_vendor_id )
	AND (SD_END IS NULL OR (SD_END IS NOT NULL AND SD_END > CONVERT(datetime, (CONVERT(CHAR(12), GETDATE()))) ))
	AND (SD_ACTUAL_GRAD_DT IS NULL OR (SD_ACTUAL_GRAD_DT IS NOT NULL AND SD_ACTUAL_GRAD_DT > CONVERT(datetime, (CONVERT(CHAR(12), GETDATE()))) ))
	AND (( d.sd_ext_grad_date IS NULL
                AND CONVERT(datetime, (CONVERT(CHAR(12), GETDATE())))
                        BETWEEN sd_start_date AND sd_grad_date)
    OR ( sd_ext_grad_date IS NOT NULL
                AND CONVERT(datetime, (CONVERT(CHAR(12), GETDATE())))
                                    BETWEEN sd_start_date AND sd_ext_grad_date))
if @@error <> 0
	ROLLBACK TRANSACTION
else
	COMMIT TRANSACTION

