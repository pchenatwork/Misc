﻿-- from production 05/28/2020 -JW

Begin transaction
      truncate table mv_cms_rfc  
         insert into mv_cms_rfc 
      select * From 
      OPENQUERY(NYCSCA_ORC, 'SELECT * FROM mv_cms_rfc')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go


Begin transaction
      truncate table mv_Curr_Mentor_BidList  
         insert into mv_Curr_Mentor_BidList 
      select * From 
      FUN_VAS_CURR_MENTOR_BIDLIST()
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go


Begin transaction
      truncate table mv_Curr_Grad_Mentor_BidList  
         insert into mv_Curr_Grad_Mentor_BidList 
      select * From 
      OPENQUERY(NYCSCA_ORC, 'SELECT * FROM mv_Curr_Grad_Mentor_BidList')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go


Begin transaction

       --select * into mv_ves_mentor from openquery(NYCSCA_ORC, 'select * from mv_ves_mentor') -- Done
      truncate table mv_ves_mentor
      insert into mv_ves_mentor 
      select * From 
      OPENQUERY(NYCSCA_ORC, 'SELECT * FROM mv_ves_mentor')  
commit transaction
Go


Begin transaction

       --select * into mv_vas_capacity from openquery(NYCSCA_ORC, 'select * from mv_vas_capacity') -- Done
      truncate table mv_vas_capacity
      insert into mv_vas_capacity 
      select * From 
      OPENQUERY(NYCSCA_ORC, 'SELECT * FROM mv_vas_capacity')  
commit transaction
Go


Begin transaction
              --select * into mv_bc from openquery(NYCSCA_ORC, 'select * from mv_bc') -- view does not exist
      truncate table mv_bc
      insert into mv_bc 
      select * From 
      OPENQUERY(NYCSCA_ORC, 'SELECT * FROM mv_bc')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go

Begin transaction
              --select * into mv_br from openquery(NYCSCA_ORC, 'select * from mv_br') -- view does not exist
      truncate table mv_br
      insert into mv_br 
      select * From 
      OPENQUERY(NYCSCA_ORC, 'SELECT * FROM mv_br')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go
Begin transaction
              --select * into mv_lb from openquery(NYCSCA_ORC, 'select * from mv_lb') -- view does not exist
      truncate table mv_lb
      insert into mv_lb 
      select * From 
      OPENQUERY(NYCSCA_ORC, 'SELECT * FROM mv_lb')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go

Begin transaction
              --select * into MV_VES_CAPACITY from openquery(NYCSCA_ORC, 'select * from MV_VES_CAPACITY') -- view does not exist
      truncate table MV_VES_CAPACITY
      insert into MV_VES_CAPACITY 
      select * From 
      OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_VES_CAPACITY')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go

Begin transaction
         --select * into ces_mentor_employee from openquery(NYCSCA_ORC, 'select * from mentor_employee') -- view does not exist
      truncate table ces_mentor_employee
      insert into ces_mentor_employee 
      select * From 
      OPENQUERY(NYCSCA_ORC, 'SELECT * FROM mentor_employee')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go

Begin transaction
      truncate table dw_v_project_dates_ntp_subcomp  
insert into dw_v_project_dates_ntp_subcomp
SELECT * from openquery(NYCSCA_DW,'select * from dwstar.v_project_dates_ntp_subcomp')
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
GO

Begin transaction
         --select * into MV_VES_CIP_MAIN from 
          --DROP TABLE MV_VES_CIP_MAIN
         truncate table MV_VES_CIP_MAIN
      insert into MV_VES_CIP_MAIN 
      select *  from OPENQUERY(NYCSCA_ORC, 'SELECT 
       C_CONTRACT_ID,C_DESIGN_CODE,C_STATION_CODE,C_ACTIVITY_CODE,C_STAT_CODE,N_ISC,C_DESIGN_MGR,C_ARCH_CODE,C_SR_PROJ_OFFICR,C_STUDIO_DIRECTOR,C_SD_BACKUP,
       C_SUPPORT_MNGR,C_VENDOR_ID,L_RESOA,I_CONST_DUR,C_DESIGN_DESC,SUM_CONST_EST,D_SCOPE_BEGIN,D_SCOPE_END,D_SCOPE_FC_BEGIN,D_SCOPE_FC_END,D_DESIGN_BEGIN,
       D_DESIGN_END,D_DESIGN_FC_BEGIN,D_DESIGN_FC_END,D_RFC_BEGIN,D_RFC_END,D_BID_AWARD_BEGIN,D_BID_AWARD_END,D_BID_AWARD_FC_BEGIN,D_BID_AWARD_FC_END,D_CONSTR_BEGIN,
       D_CONSTR_END,BORO,BUILDING_NAME,SCHOOL,DM_SUPERVISOR,ARCH_SUPERVISOR,SPO_SUPERVISOR,DD_SUPERVISOR,SD_SUPERVISOR,SM_SUPERVISOR,PLAN_EXAM_ID,PLAN_EXAM_SUPER_ID,
       C_CONTR_SPECIALIST,SP_CONTR_SPECIALIST,OPS_MGR,SP_OPS_MGR,PCT_BY_CONTRACT,VIEW_UPDATE_DATE,TO_CHAR(FID_RECEIVED_DATE,''YYYY-MM-DD HH:MI:SS'') as FID_RECEIVED_DATE,C_FE_CODE  FROM MV_VES_CIP_MAIN v ')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go

--select * into MV_VAS_CONT_SCH_FAC from openquery(NYCSCA_ORC, 'select * from MV_VAS_CONT_SCH_FAC') -- view does not exist
         
DECLARE @cnt INT
SELECT @cnt = CNT FROM OPENQUERY(NYCSCA_ORC, 'SELECT COUNT(1) CNT FROM MV_VAS_CONT_SCH_FAC')  

IF @cnt > 5000 -- it should have 40k+ records, set the min record count to 5000
BEGIN

       truncate table MV_VAS_CONT_SCH_FAC
       insert into MV_VAS_CONT_SCH_FAC 
       SELECT vascont.*, sch.C_ORG FROM [NYCSCA_ORC]..[OCMS].MV_VAS_CONT_SCH_FAC vascont left join [NYCSCA_ORC]..[OCMS].[MV_SCH] sch on vascont.c_school_code = sch.c_school_code

         
       /************************************
              Contract substitutions
       *************************************/

       --  Set up dummy records, replaced below with the new contract numbers
       insert into MV_VAS_CONT_SCH_FAC
       select replace(C_CONTRACT,'0','X'),
       C_CONTRACT_TYPE,
       C_SOLICIT,
       N_SOLICIT_SEQ,
       SUB_SOLICIT,
       SUB_SOLICIT_SEQ,
       PO_NO,
       C_SCHOOL_CODE,
       C_SCHOOL_NAME,
       C_FACILITY_CODE,
       C_ADDR_1,
       C_ADDR_2,
       C_CITY,
       C_STATE,
       C_ZIP,
       C_ORG
       from MV_VAS_CONT_SCH_FAC 
       where C_CONTRACT in( 'C000013288','C000013573', 'C000011262')
                     
       --safety: remove any records that would conflict with the renamed contracts
       delete MV_VAS_CONT_SCH_FAC where C_CONTRACT in ('C000014628','C000014629','C000015258')
       
       --rename dummy records to their new contract numbers
       update MV_VAS_CONT_SCH_FAC set C_CONTRACT = 'C000014628' where C_CONTRACT = 'CXXXX13573'
       update MV_VAS_CONT_SCH_FAC set C_CONTRACT =  'C000014629' where C_CONTRACT = 'CXXXX13288'
       update MV_VAS_CONT_SCH_FAC set C_CONTRACT = 'C000015258' where C_CONTRACT = 'CXXXX11262' --Alps Mechanical

END -- if at least 5000 records
Go

Begin transaction
         --select * into MV_VES_B_CAPACITY_STAGE1 from openquery(NYCSCA_ORC, 'select * from MV_VES_B_CAPACITY_STAGE1') -- view does not exist
         truncate table MV_VES_B_CAPACITY_STAGE1
         insert into MV_VES_B_CAPACITY_STAGE1 
         select * From 
         OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_VES_B_CAPACITY_STAGE1')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go

Begin transaction
         --select * into MV_VAS_RFC_ALL from openquery(NYCSCA_ORC, 'select * from MV_VAS_RFC_ALL') -- view does not exist
         truncate table MV_VAS_RFC_ALL
         insert into MV_VAS_RFC_ALL 
         select * From 
         OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_VAS_RFC_ALL')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go

Begin transaction
         truncate table MV_VAS_BIDDER
         insert into MV_VAS_BIDDER 
         select * From 
         OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_VAS_BIDDER')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go


Begin transaction
         truncate table MV_VAS_PICKUP
         insert into MV_VAS_PICKUP 
         select * From 
         OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_VAS_PICKUP')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go

Begin transaction
         --select * into MV_ZVAS_BIDS_PICKUPS from openquery(NYCSCA_ORC, 'select * from MV_ZVAS_BIDS_PICKUPS') -- view does not exist
         truncate table MV_ZVAS_BIDS_PICKUPS
         insert into MV_ZVAS_BIDS_PICKUPS 
         select * From 
         OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_ZVAS_BIDS_PICKUPS')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go

Begin transaction
         truncate table MV_SOLICIT_ORA_AWARD
         insert into MV_SOLICIT_ORA_AWARD 
         select * From 
         OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_SOLICIT_ORA_AWARD')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go

Begin transaction
         truncate table MV_NTP_EEO_MWLBE
         insert into MV_NTP_EEO_MWLBE 
         select * From 
         OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_NTP_EEO_MWLBE')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go

Begin transaction
         truncate table MV_SUP_CES_RPT
         insert into MV_SUP_CES_RPT 
         select * From 
         OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_SUP_CES_RPT')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go
Begin transaction
         truncate table MV_SUP_CIS_RPT
         insert into MV_SUP_CIS_RPT 
         select * From 
         OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_SUP_CIS_RPT')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go
Begin transaction
         truncate table MV_SUP_CIS_SUB_RPT
         insert into MV_SUP_CIS_SUB_RPT 
         select * From 
         OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_SUP_CIS_SUB_RPT')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go

Begin transaction
         truncate table MV_ENFO_VES
         insert into MV_ENFO_VES 
         select * From 
         OPENQUERY(IEH_VES, 'SELECT * FROM IEHIS.ENFO_VES_VW')  
         if @@error <> 0
              begin
                     ROLLBACK TRANSACTION
                     
              end
commit transaction
Go

/* MV_VAS_AWARD*/
-----------------------------------
-- *** Refresh [MV_VAS_AWARD] ***
-----------------------------------
DECLARE @err INT = 0, @OldCnt INT = 0;    
SELECT @OldCnt = COUNT(1) FROM MV_VAS_AWARD;

DECLARE @MV_VAS_AWARD_RAW TABLE(
       VENDOR_ID varchar(20),
       CONTRACT varchar(20),
       MENTOR_CONTRACT varchar(20),
       SOLICIT_NO char(11),
       SOLICIT_DESCRIPTION varchar(55),
       AWARD_AMOUNT nvarchar(384),
       EXECUTION_DATE datetime,
       NTP_DATE datetime
    UNIQUE CLUSTERED (VENDOR_ID,CONTRACT,MENTOR_CONTRACT, SOLICIT_NO)
)
INSERT INTO @MV_VAS_AWARD_RAW
SELECT DISTINCT * FROM 
    OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_VAS_AWARD');

DECLARE @MV_VAS_AWARD TABLE(
       VENDOR_ID varchar(20),
       CONTRACT varchar(20),
       MENTOR_CONTRACT varchar(20),
       SOLICIT_NO char(11),
       SOLICIT_DESCRIPTION varchar(55),
       AWARD_AMOUNT nvarchar(384),
       EXECUTION_DATE datetime,
       NTP_DATE datetime
);
WITH tBASE AS ( -- All Mentor Contract
    SELECT DISTINCT CONTRACT, MENTOR_CONTRACT
    FROM @MV_VAS_AWARD_RAW
    WHERE LEN(LTRIM(RTRIM(ISNULL(MENTOR_CONTRACT, ''))))>0
    )
, tMC AS ( -- Mentor Contract to be excluded
    SELECT CONTRACT FROM tBASE A 
    WHERE CONTRACT = MENTOR_CONTRACT
    AND EXISTS (
    SELECT 1 FROM tBASE B 
    WHERE B.CONTRACT <> B.MENTOR_CONTRACT
    AND B.MENTOR_CONTRACT = A.CONTRACT
    ))
INSERT INTO @MV_VAS_AWARD
SELECT DISTINCT 
    VENDOR_ID,
    CONTRACT ,
    MENTOR_CONTRACT,
    SOLICIT_NO,
    SOLICIT_DESCRIPTION,
    AWARD_AMOUNT,
    EXECUTION_DATE,
    NTP_DATE
FROM @MV_VAS_AWARD_RAW A
WHERE NOT EXISTS (SELECT 1 FROM tMC B WHERE A.CONTRACT = B.CONTRACT)

IF @@ROWCOUNT > 10 -- @OldCnt, Assume new MV re-fresh has at least 10000 records
BEGIN
    Begin transaction
    
    TRUNCATE TABLE MV_VAS_AWARD;
    IF @@ERROR <>0 SELECT @err = @err+1;

    INSERT INTO MV_VAS_AWARD
    SELECT * FROM @MV_VAS_AWARD
    IF @@ERROR <>0 SELECT @err = @err+1;
    
    IF @err = 0
        commit transaction
    ELSE
        ROLLBACK TRANSACTION
END
Go

-----------------------------------
-- *** Refresh [MV_ZVAS_BIDS_PICKUPS] ***
-----------------------------------
-- Note: This step needs to be run after [MV_VAS_AWARD]
-----------------------------------
DECLARE @err INT = 0;    

DECLARE @MV_ZVAS_BIDS_PICKUPS TABLE(
       C_VENDOR_ID varchar(20),
       TOTAL_BIDS INT,
       TOTAL_PICKUPS INT,
       TOTAL_AWARDS INT
)
INSERT INTO @MV_ZVAS_BIDS_PICKUPS
select * From 
    OPENQUERY(NYCSCA_ORC, 'SELECT * FROM MV_ZVAS_BIDS_PICKUPS');
    
-- Assume failure if record is less than 10
IF (@@ROWCOUNT < 10) SELECT @err = @err+1

UPDATE A SET 
    TOTAL_AWARDS = ISNULL(B.CNT,0)
FROM  @MV_ZVAS_BIDS_PICKUPS A
LEFT JOIN (
    SELECT VENDOR_ID, COUNT(1) AS CNT FROM MV_VAS_AWARD
    WHERE (DATEDIFF(day, EXECUTION_DATE, GETDATE()) < 366
     OR    DATEDIFF(day, NTP_DATE, GETDATE()) < 366)
    GROUP BY VENDOR_ID
) B ON A.C_VENDOR_ID = B.VENDOR_ID 
IF @@ERROR <>0 SELECT @err = @err+1

IF (@err = 0)
BEGIN
    Begin transaction

    truncate table MV_ZVAS_BIDS_PICKUPS;
    IF @@ERROR <>0 SELECT @err = @err+1;

    insert into MV_ZVAS_BIDS_PICKUPS 
    select * From @MV_ZVAS_BIDS_PICKUPS
    IF @@ERROR <>0 SELECT @err = @err+1;

    IF @err = 0
        commit transaction
    ELSE
        ROLLBACK TRANSACTION
END

GO

-----------------------------------
-- more ORC imports
-----------------------------------
/* 202005 PCHEN, To import ORCMS data for MWBE Service Contract Compliance Monitoring*/
DECLARE @cnt INT
SELECT @cnt= count(1) from openquery(NYCSCA_ORC, 'SELECT * FROM OCMS.VW_ATP_HEADER')
IF @CNT > 100
BEGIN
IF OBJECT_ID('dbo.ORCMS_VW_ATP_HEADER', 'U') IS NOT NULL DROP TABLE dbo.ORCMS_VW_ATP_HEADER; 
select *, getdate() as LastRefreshed INTO ORCMS_VW_ATP_HEADER from openquery(NYCSCA_ORC, 'SELECT * FROM OCMS.VW_ATP_HEADER')
END
SELECT @cnt= count(1) from openquery(NYCSCA_ORC, 'SELECT * FROM OCMS.VW_ACPT_TRANS_DIST')
IF @CNT > 100
BEGIN
IF OBJECT_ID('dbo.ORCMS_VW_ACPT_TRANS_DIST', 'U') IS NOT NULL DROP TABLE dbo.ORCMS_VW_ACPT_TRANS_DIST; 
select *, getdate() as LastRefreshed INTO ORCMS_VW_ACPT_TRANS_DIST from openquery(NYCSCA_ORC, 'SELECT * FROM OCMS.VW_ACPT_TRANS_DIST')
END
select @cnt = count(1) from openquery(NYCSCA_ORC, 'SELECT * FROM OCMS.MV_SUPAGR')
IF @CNT > 100
BEGIN
IF OBJECT_ID('dbo.ORCMS_MV_SUPAGR', 'U') IS NOT NULL DROP TABLE dbo.ORCMS_MV_SUPAGR; 
select *, getdate() as LastRefreshed INTO ORCMS_MV_SUPAGR from openquery(NYCSCA_ORC, 'SELECT * FROM OCMS.MV_SUPAGR')
END
GO
