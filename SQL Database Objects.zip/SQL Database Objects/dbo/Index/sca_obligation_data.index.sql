﻿/*-----------------------
 * Created: 5/31/2017 PC
 * Introduced to speed up SP EEO_MentorGradMentorSummaryReport
 * Table Name: [sca_obligation_data]
 * Index Name: IX1_SCA_OBLIGATION_DATA
 * Index Name: IX2_SCA_OBLIGATION_DATA
 *-----------------------*/
IF EXISTS(SELECT * FROM sys.indexes WHERE object_id = object_id('[dbo].[sca_obligation_data]') AND NAME ='IX1_SCA_OBLIGATION_DATA')
    DROP INDEX IX1_SCA_OBLIGATION_DATA ON [dbo].[sca_obligation_data];
GO
--CREATE NONCLUSTERED INDEX IX1_SCA_OBLIGATION_DATA ON [dbo].[sca_obligation_data]
--(
--    [NUM_1099],[ORCL_CMS_CONTRACT]
--)
--GO
IF EXISTS(SELECT * FROM sys.indexes WHERE object_id = object_id('[dbo].[sca_obligation_data]') AND NAME ='IX2_SCA_OBLIGATION_DATA')
    DROP INDEX IX2_SCA_OBLIGATION_DATA ON [dbo].[sca_obligation_data];
GO
CREATE NONCLUSTERED INDEX IX2_SCA_OBLIGATION_DATA ON [dbo].[sca_obligation_data]
(
    [ORIG_FLAG],[ORCL_CMS_CONTRACT],[NUM_1099],[GROUPING],[CMS_CONTRACT_CODE]
)
INCLUDE ([CO_AMOUNT],[NTP_SOLICIT])
GO
IF EXISTS(SELECT * FROM sys.indexes WHERE object_id = object_id('[dbo].[sca_obligation_data]') AND NAME ='IX3_SCA_OBLIGATION_DATA')
    DROP INDEX IX3_SCA_OBLIGATION_DATA ON [dbo].[sca_obligation_data];
GO
CREATE NONCLUSTERED INDEX IX3_SCA_OBLIGATION_DATA ON [dbo].[sca_obligation_data]
(
    [NTP_FLAG],[NTP_SOLICIT],[NTP_SUB_ID],[ORCL_CMS_CONTRACT],[NUM_1099]
)
GO