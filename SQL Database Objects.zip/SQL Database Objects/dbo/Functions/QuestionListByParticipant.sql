﻿CREATE FUNCTION [dbo].[QuestionListByParticipant](@questionId int, @participantId int)
RETURNS XML
WITH RETURNS NULL ON NULL INPUT 
BEGIN RETURN 
  (SELECT 
	q.Id				As '@Id',
	q.SectionId			As '@SectionId',
	q.ParentId			As '@ParentId',
	q.QuestionTypeId	As '@QuestionTypeId',
	t.Type				As '@QuestionType',
	q.QuestionText		As '@QuestionText',
	q.Sequence			As '@Sequence',
	q.IsRequired		As '@IsRequired',
	q.RowNumber			As '@RowNumber',
	q.ColumnNumber		As '@ColumnNumber',
	q.MaxLength			As '@MaxLength',
	q.AnswerFormat		As '@AnswerFormat',
	q.MaxValue			As '@MaxValue',
	q.MinValue			As '@MinValue',
	q.DefaultValue		As '@DefaultValue',
	q.RepeatDirection	As '@RepeatDirection',
	q.Score				As '@Score',
	q.Searchable		As '@Searchable',
	CASE WHEN q.ParentId = @questionId
		THEN dbo.QuestionListByParticipant(q.Id, @participantId)
	END,
	(
		select
			a.Id			As '@Id',
			a.QuestionId	As '@QuestionId',
			a.AnswerText	As '@AnswerText',
			a.AnswerValue	As '@AnswerValue',
			a.Sequence		As '@Sequence',
			a.AnswerType	As '@AnswerType',
			a.Score			As '@Score'
		from Answer a
		where a.QuestionId = q.Id
		Order By a.Sequence
		FOR XML PATH('Answer'), ROOT('ArrayOfAnswer'), TYPE
	),
	(
		select
			r.Id				As '@Id',
			r.SectionId			As '@SectionId',
			r.ParticipantId		As '@ParticipantId',
			r.QuestionId		As '@QuestionId',
			r.AnswerId			As '@AnswerId',
			r.Selected			As '@Selected',
			r.ResponseText		As '@ResponseText',
			r.AttachmentName	As '@AttachmentName',
			r.ChangeDate		As '@ChangeDate'
		from Response r
		where r.QuestionId = q.Id and r.ParticipantId = @participantId
		FOR XML PATH('Response'), ROOT('ArrayOfResponse'), TYPE
	)
   FROM Question q, QuestionType t
   WHERE q.ParentId = @questionId
	and q.QuestionTypeId = t.Id
	Order BY q.Sequence
   FOR XML PATH('Question'), ROOT('ArrayOfQuestion'), TYPE)
END
