﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[IsMentorEligible] 
(
	-- Add the parameters for the function here
	@vendorId int
)
RETURNS bit
AS
BEGIN
	-- Declare the return variable here
	declare @c_vendor_id char(12)
    declare @max_seq numeric
    declare @sd_start smalldatetime,
            @sd_end smalldatetime,
            @cur_dt smalldatetime

  
	select @cur_dt = convert(smalldatetime,convert(char(12), getdate()))
    -- Insert statements for procedure here
	declare @flag bit
	declare @count int
	set @count=0
	select  @count=count(*)
    from	EEO_MASTER t1, vendor v, supplierstatus c,supplierstatus p
    where	isnull(t1.m_average_sales, 0) <= 2100000   -- Avg Sale 
      and	t1.c_vendor_id = v.FederalId
	  and	v.CertifiedSupplierId=c.supplierid
	  and	c.TypeName='Supplier Certification'
	  and	c.status='Certified'
	  and	v.QualifiedSupplierId=p.supplierid
	  and	p.TypeName='Supplier Prequalification'
	  and	p.status='Qualified'
	  and	v.id=@vendorId
	  -- Check whether any owner is part of any other Mentor firm exclude him
	  
	   and	not exists(		select v1.federalid 
						from 
							supplierpersonnel sp , supplierpersonnel sp1, Vendor v1,EEO_MENTOR_GRAD_DETAIL e
						where	
							sp.supplierid=v.QualifiedSupplierId
							and sp.IsOwner='Y'
							and sp.status<>4 --active
							and sp.IsKeyPerson='Y'
							and sp.SSN=sp1.SSN
							and	sp1.IsOwner='Y'
							and sp1.status<>4
							and sp1.IsKeyPerson='Y'
							and sp1.supplierid=v1.QualifiedSupplierId
							and v1.FederalId<>v.FederalId
							and v.id=e.VENDORID
							and sp.SSN not in ('wwwwwwwww','%%%%%%%%%','zzzzzzzzz')
							)
	  and	exists (select * 
					from 
						suppliercategory sc, EEO_MENTOR_ILGBL_TRADES e
					where 
						sc.supplierid=v.CertifiedSupplierId 
						and sc.CategoryId=e.CategoryId
					)
					
	  and not exists(select 'x' -- Prime bond not exceeding 1000000
					from SupplierSurety
					where supplierid=v.QualifiedSupplierId
					--and IsPrimary='Y'
					and SingleCapacity>1000000
			)
    
	and not exists (select * from EEO_MENTOR_EXCEPTION
					where vendorid=v.id
					and @cur_dt between sd_start and isnull(sd_end,'1/1/9999')
					)
				
	/*and not exists (select * from EEO_MENTOR_GRAD_DETAIL
					where vendorid=v.id)
					*/
	
	set @flag=0
	if @count>0
		set @flag=1


	RETURN @flag

END
