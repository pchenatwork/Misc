﻿

CREATE FUNCTION [dbo].[IsCESViewer]
(@userId int)
RETURNS int

AS

begin

declare @Admin int
set @Admin = 0

if exists (select id from [User] u, aspnet_UsersInRoles ur, aspnet_Roles r
	where r.RoleName in ('Administrator', 'Global CES Admin', 'Global CES Viewer', 'Departmental CES Admin') and r.RoleId = ur.RoleId and ur.UserId = u.UserId
		and u.Id = @userId)
	set @Admin = 1

return @Admin

end

