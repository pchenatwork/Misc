﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION EEO_GetRequiredClassesRSVPD
(	-- Add the parameters for the stored procedure here
	@vendorId int
	)
RETURNS int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	--SET NOCOUNT ON;

    -- Insert statements for procedure here
	declare @currentStatus varchar(50)
	declare @classType varchar(1)
	declare @count int
	select @currentStatus=status from eeo_vendor where vendorid=@vendorId


	if @currentStatus='Preliminary_Email_Sent' 
		begin
			set @classType=1
		end
	
	select @count=count(*) 
	from	eeo_classes ec, EEO_VENDOR_CLASSES vc
	where	c_class_Type='1'
	and		vc.VENDORID=@vendorId
	and		vc.C_CLASS_ID=ec.C_CLASS_ID
	and		vc.C_RSVPD='N'

	return @count
END
