﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
create FUNCTION [dbo].[Variance]
(
	@num1 float,
	@num2 float
)
RETURNS float
AS
BEGIN
	declare @results float
	if @num1 = 0 and @num2 = 0 
		set @results = 0
	else if @num2 = 0 
		set @results = 1
	else
		set @results = round((@num1 - @num2)/@num2, 2)

	return @results
		
END


