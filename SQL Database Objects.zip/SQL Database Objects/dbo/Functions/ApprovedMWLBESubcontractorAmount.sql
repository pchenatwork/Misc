﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[ApprovedMWLBESubcontractorAmount]
(
	@id int
)
RETURNS float
AS
BEGIN
	declare @approvedMWLBESubcontractorAmount float
	
	set @approvedMWLBESubcontractorAmount = 
		(select 
			isnull(SUM(isnull(approvedvalue, 0)), 0) 
		from 
			PlanSubcontractor 
		where 
			PlanId  = @id
			and ISNULL(IsSupplierOnly,'N')!='Y'
			and isnull(IsNonMinority, 'N')!='Y'
			and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))
		)
	
	return @approvedMWLBESubcontractorAmount
		
END


