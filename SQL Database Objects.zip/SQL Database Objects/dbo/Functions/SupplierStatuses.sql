/*
*******************************************************************************
FUNCTION:	SupplierStatuses
Purpose:	Return Set of extended properties of Supplier
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
05/25/2018      PCHEN               Comment section first created
    1. Sync with Production
    2. Added 'IsAEApproved' and 'IsProfServiceApproved' property
	3. SQL tuning to cut the query cost into 30%
*******************************************************************************
*/
ALTER FUNCTION [dbo].[SupplierStatuses]
(
	@supplierId int
)
RETURNS @supplierstatus table(TypeName nvarchar(100),Status nvarchar(100) )

AS
BEGIN

declare @suppliercategories table ( CategoryId int, IsApproved char(1)) 

insert into @suppliercategories (CategoryId, IsApproved)
select S.CategoryId, S.IsApproved
from SupplierCategory S 
where SupplierId = @supplierId

declare 
    @categorycount int
   ,@shortformcodecount int
   ,@installerlongformcodecount int
   ,@nosecuritycount int
   ,@noapprentcount int
   ,@AsbestosAbatementCnt INT
   ,@AsbestosConsultantCnt INT
   ,@LabTestingCnt INT
   ,@AECnt INT, @AEApprovedCnt INT
   ,@ProfServiceCnt INT, @ProfServiceApprovedCnt INT
   ,@MentorTradesCnt INT
   ,@ApprenticeshipCnt INT
   ,@FinancialSection1Cnt INT
   ,@FinancialSection2Cnt INT
   ,@FinancialSection3Cnt INT

SELECT @categorycount = COUNT(1),
     @shortformcodecount = SUM(CASE WHEN C.IsShortFormCode = 'Y' THEN 1 ELSE 0 END),
     @installerlongformcodecount = SUM(CASE WHEN C.IsInstallerLongFormCode = 'Y' THEN 1 ELSE 0 END),
     @nosecuritycount = SUM(CASE WHEN C.IsSafetyExclude = 'Y' THEN 1 ELSE 0 END),
     @AsbestosAbatementCnt = SUM(CASE WHEN C.IsAsbestosAbatement = 'Y' THEN 1 ELSE 0 END),
     @AsbestosConsultantCnt = SUM(CASE WHEN C.IsAsbestosConsultant = 'Y' THEN 1 ELSE 0 END),
     @LabTestingCnt = SUM(CASE WHEN C.IsLabTesting = 'Y' THEN 1 ELSE 0 END),
     @AECnt = SUM(CASE WHEN C.IsAE = 'Y' THEN 1 ELSE 0 END),
     @AEApprovedCnt = SUM(CASE WHEN C.IsAE = 'Y' AND S.IsApproved='Y' THEN 1 ELSE 0 END),
     @ProfServiceCnt = SUM(CASE WHEN C.IsProfService = 'Y' THEN 1 ELSE 0 END),
     @ProfServiceApprovedCnt = SUM(CASE WHEN C.IsProfService = 'Y' AND S.IsApproved='Y' THEN 1 ELSE 0 END),
     @MentorTradesCnt = SUM(CASE WHEN C.IsMentorCode='Y' THEN 1 ELSE 0 END),
     @ApprenticeshipCnt = SUM(CASE WHEN C.Apprenticeship='Y' THEN 1 ELSE 0 END),
     @FinancialSection1Cnt = SUM(CASE WHEN C.FinancialSection1='Y' THEN 1 ELSE 0 END),
     @FinancialSection2Cnt = SUM(CASE WHEN C.FinancialSection2='Y' THEN 1 ELSE 0 END),
     @FinancialSection3Cnt = SUM(CASE WHEN C.FinancialSection3='Y' THEN 1 ELSE 0 END)
FROM @suppliercategories S JOIN Category C on S.CategoryId = C.Id

insert into @supplierstatus(TypeName,Status)
	select 'HasAsbestosAbatement','Y' where @AsbestosAbatementCnt>0
    UNION
	select 'HasAsbestosConsultant','Y' where @AsbestosConsultantCnt>0
    UNION
	select 'HasLabTesting','Y' where @LabTestingCnt>0
    UNION
	select 'IsAE','Y' where @AECnt>0
    UNION
	select 'IsAEApproved','Y' where @AEApprovedCnt>0
    UNION
	select 'IsProfService','Y' where @ProfServiceCnt>0
    UNION
	select 'IsProfServiceApproved','Y' where @ProfServiceApprovedCnt>0
    UNION
	select 'IsShortForm','Y' where @categorycount > 0 and @categorycount = @shortformcodecount
    UNION
	select 'HasMentorTrades','Y' where @MentorTradesCnt>0
    UNION 
    select 'NoSafety','Y' where @categorycount > 0 and @categorycount = @nosecuritycount
    UNION
	select 'HasApprenticeship','Y' where @ApprenticeshipCnt>0
    UNION
	select 'HasFinancialSection1','Y' where @FinancialSection1Cnt>0
    UNION
	select 'HasFinancialSection2','Y' where @FinancialSection2Cnt>0
    UNION
	select 'HasFinancialSection3','Y' where @FinancialSection3Cnt>0

DECLARE @issupplierinstaller char(1)
select @issupplierinstaller = 'Y'
from Supplier
where Id = @supplierId and CurrentSupplier = 'I'

if(@installerlongformcodecount = @categorycount and @issupplierinstaller = 'Y')
	delete from @supplierstatus where typename = 'IsShortForm'
    
DECLARE @isPaper bit,
    @isPaperQual bit,
    @isPaperCert bit

SELECT 
    @isPaper = CASE WHEN SupplierType LIKE '%paper%' THEN 1 ELSE 0 END,
    @isPaperQual = CASE WHEN SupplierType LIKE '%PaperQual%' THEN 1 ELSE 0 END,
    @isPaperCert = CASE WHEN SupplierType LIKE '%PaperCert%' THEN 1 ELSE 0 END
	from Supplier
	where Id = @supplierId

insert into @supplierstatus(TypeName,Status)
	select 'IsPaper','Y' where @isPaper = 1
    UNION
	select 'IsPaperQual','Y' where @isPaperQual = 1
    UNION
	select 'IsPaperCert','Y' where @isPaperCert = 1
    
insert into @supplierstatus(TypeName,Status)
	select 'IsQual','Y'
    WHERE EXISTS(SELECT 1 FROM SupplierStatus 
        where SupplierId=@supplierId 
        AND typename = 'Supplier Prequalification'
	    )
	
insert into @supplierstatus(TypeName,Status)
	select 'IsCert','Y'    
    WHERE EXISTS(SELECT 1 FROM SupplierStatus 
        where SupplierId=@supplierId 
        AND typename = 'Supplier Certification'
        )
	
insert into @supplierstatus(TypeName,Status)
	select 'IsNonAppplicant','Y'   
    WHERE NOT EXISTS(SELECT 1 FROM SupplierStatus 
        where SupplierId=@supplierId 
        AND typename in ( 'Supplier Certification' , 'Supplier Prequalification' )
        )
	
insert into @supplierstatus(TypeName,Status)
	select 'IsMBE','Y'
    WHERE EXISTS (SELECT 1 FROM SupplierClassification 
        where SupplierId = @supplierId 
        AND Classification = 'MBE'
        )
	
insert into @supplierstatus(TypeName,Status)
	select 'IsWBE','Y'
    WHERE EXISTS (SELECT 1 FROM SupplierClassification 
        where SupplierId = @supplierId 
        AND Classification = 'WBE'
        )
	
insert into @supplierstatus(TypeName,Status)
	select 'IsLBE','Y'
    WHERE EXISTS (SELECT 1 FROM SupplierClassification 
        where SupplierId = @supplierId 
        AND Classification = 'LBE'
        )

insert into @supplierstatus(TypeName,Status)
	select 'IsMBEApproveByDirector','Y'
    WHERE EXISTS (
    	select 1 from SupplierStaticCertification s 
        where V_c_eeo_type = 'M' AND SupplierId = @supplierId
        and (IsRecommendedByDirector = 'Y' or (V_c_dw_code='P' and exists(select * from supplierproperty where supplierid=s.SupplierId and propertyid=519 and cast(PropertyText as varchar(100))='Not Eligible')))
    )
	
insert into @supplierstatus(TypeName,Status)
	select 'IsWBEApproveByDirector','Y'
    WHERE EXISTS (        
		select 1 from SupplierStaticCertification s 
        where V_c_eeo_type = 'W'  AND SupplierId = @supplierId
        and (IsRecommendedByDirector = 'Y' or (V_c_dw_code='P' and exists(select * from supplierproperty where supplierid=s.SupplierId and propertyid=519 and cast(PropertyText as varchar(100))='Not Eligible')))
    )
	
insert into @supplierstatus(TypeName,Status)
	select 'IsLBEApproveByDirector','Y'
    WHERE EXISTS(
    		select 1 from SupplierStaticCertification s 
            where V_c_eeo_type = 'L' AND SupplierId = @supplierId
            and (IsRecommendedByDirector = 'Y' Or (V_c_dw_code='P' and exists(select * from supplierproperty where supplierid=s.SupplierId and propertyid=519 and cast(PropertyText as varchar(100))='Not Eligible')))
    )
    
declare @property2004 nvarchar(50)
select @property2004 = PropertyText 
from SupplierProperty
where SupplierId = @supplierId
and PropertyId = 2004
insert into @supplierstatus(TypeName,Status)
	select 'IsLbeArea','Y'
	where @property2004 = 'area'	
insert into @supplierstatus(TypeName,Status)
	select 'IsLbeEmployee','Y'
	where @property2004 = 'employees'


insert into @supplierstatus(TypeName,Status)
SELECT ss.TypeName, ss.Status
			FROM SupplierStatus ss
			WHERE ss.SupplierId = @supplierId

RETURN 
END



GO


