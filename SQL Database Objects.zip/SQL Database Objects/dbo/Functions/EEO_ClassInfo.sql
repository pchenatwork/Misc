﻿IF OBJECT_ID(N'dbo.EEO_ClassInfo') IS NOT NULL
	DROP FUNCTION [dbo].[EEO_ClassInfo]
GO
/*
*******************************************************************************
FUNCTION:	EEO_ClassInfo
Purpose:	Return comma delimited ClassInfo string for Vender
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
07/21/2017      PCHEN               Comment section first created
    1. limited the class to attended only
    2. Append ClassType to classinfo
*******************************************************************************
*/
CREATE function [dbo].[EEO_ClassInfo]
	(
		@VendorId int
	)
RETURNS varchar(4000)
As
Begin
	Declare @classInfoString varchar(4000)
	Set @classInfoString=''
	select 	 @classInfoString=@classInfoString +
	    Coalesce(c.c_class_name + 
			CASE C_CLASS_TYPE 
                WHEN 1 THEN ' (Preliminary)' -- Preliminary
                WHEN 2 THEN ' (Orientation)' -- Orientation
                WHEN 3 THEN ' (Regular)' -- Regular
                WHEN 4 THEN ' (Advanced)' -- Advanced
                WHEN 5 THEN ' (GradMentor)' -- GradMentor
                WHEN 6 THEN ' (Module)' -- Module
                WHEN 7 THEN ' (In_House)' -- In_House
			ELSE '' END			
		+ ',','')
	FROM eeo_vendor_classes ec
	inner join eeo_classes c
	on c.c_class_id = ec.c_class_id
	where ec.vendorid = @VendorId 
    AND ISNULL(ec.C_ATTENDED,'x') = 'Y'
    ORDER BY C_CLASS_TYPE, SD_SCHED

	RETURN @classInfoString
End
GO

/*
SELECT dbo.EEO_ClassInfo(8769)
    */