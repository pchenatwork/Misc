﻿


CREATE FUNCTION [dbo].[GetProjectBidPartsLocations] 
	(	
		@projectId int
	)
RETURNS nvarchar(max)
AS BEGIN

declare @str nvarchar(max)
set @str = ''


select @str = @str  + ', ' + substring(Location,0,charindex('|',Location)) 
from ProjectBidPartLocation 
where ProjectId = @projectId
and isnull(Location,'') not in ('','|')


if(len(@str) > 0)
	select @str = substring(@str,2,10000)
	
RETURN @str

END
