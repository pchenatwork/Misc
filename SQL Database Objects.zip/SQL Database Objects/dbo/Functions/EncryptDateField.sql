﻿
--ALTER FUNCTION [dbo].[EncryptDateField]
--(
--    @mDate DateTime  
--)
--RETURNS DateTime
--AS
--BEGIN
--DECLARE @rDate DateTime

--if (@mDate = null)
--	return null

--set @rDate = dateadd(month, 1, @mDate)
--set @rDate = dateadd(day, - datepart(day, @rDate), @rDate)

--set @mDate = dateadd(year, 4, @mDate)
--set @mDate = dateadd(day, datepart(day, @rDate) + 1 - datepart(day, @mDate) * 2, @mDate)

--return @mDate
--END



CREATE FUNCTION [dbo].[EncryptDateField]
(
    @inputdate datetime,
    @key nvarchar(500)='2WorldWin8'
)
RETURNS datetime
AS
BEGIN

declare @year int
declare @month int
declare @day int
declare @a int
declare @b int
declare @c int
declare @d int
declare @e int
declare @f int
declare @x int
declare @w int
declare @z decimal(38, 1)

declare @jddate decimal(38, 1)
declare @jdstring1 nvarchar(500)
declare @jdstring2 nvarchar(500)
declare @inputdatelength int
declare @keylength int
declare @finalkey nvarchar(500)
set @finalkey=''
declare @str_check  int
declare @key_check  int
declare @count int
declare @i int
declare @flag INT
declare @returnstring nvarchar(500)
set @returnstring = '' 


set @year = DATEPART(YEAR, @inputdate)
set @month = DATEPART(MONTH, @inputdate)
set @day = DATEPART(DAY, @inputdate)

if @month <=2
	begin
		set @year = @year - 1
		set @month = @month + 12
	end
	
set @a = @year/100
set @b = @a/4
set @c = 2 -@a + @b
set @e = 365.25 * (@year + 4716)
set @f = 30.6001 * (@month + 1)
set @jddate = @c + @day + @e + @f - 1524.5

if LEN(convert(nvarchar(500), @jddate)) > 7
	begin
		set @inputdatelength = LEN(SUBSTRING((convert(nvarchar(500), @jddate)), 1, 7))
		set @jdstring1 = SUBSTRING((convert(nvarchar(500), @jddate)), 1, 7)
		set @jdstring2 = SUBSTRING((convert(nvarchar(500), @jddate)), 8, 2)
	end	
else
	begin
		set @inputdatelength = LEN(convert(nvarchar(500), @jddate))
		set @jdstring1 = convert(nvarchar(500), @jddate)
		set @jdstring2 = ''
	end


set @keylength=len(@key)
set @finalkey = @key

set @keylength = @keylength - @keylength%@inputdatelength
set @finalkey = substring(@finalkey, 1, @keylength)

set @count = @keylength/@inputdatelength
set @flag = 1
WHILE (@flag <= @inputdatelength)
	BEGIN
		set @key_check = 0
		set @i=1
		while ( @i <=@count)
			begin
				set @key_check = @key_check + ASCII(substring(@finalkey, (@flag + (@i *@inputdatelength -@inputdatelength)), 1))
				set @i = @i + 1
			end

		if (@flag <4)
			begin
				set @str_check = convert(int, substring(@jdstring1, @flag, 1))
			end
		else
			begin 
				set @str_check = @key_check + convert(int, substring(@jdstring1, @flag, 1))
			end
		if (@str_check >9)
			begin
				set @str_check = @str_check%10
			end
		
		set @returnstring  = @returnstring + convert(nvarchar(500), @str_check)
		SET @flag = @flag + 1
	END
	
set @returnstring = @returnstring + @jdstring2


set @z = CONVERT(decimal(38, 1), @returnstring) + 0.5
set @w = CONVERT(int, ((@z - 1867216.25)/36524.25))
set @x = CONVERT(int, (@w/4))
set @a = CONVERT(int, (@z + 1 + @w -@x))
set @b = CONVERT(int, (@a+ 1524))
set @c = CONVERT(int, ((@b - 122.1)/365.25))
set @d = CONVERT(int, (365.25 * @c))
set @e = CONVERT(int, ((@b - @d)/30.6001))
set @f = CONVERT(int, (30.6001 * @e))


set @day = CONVERT(int, (@b-@d-@f))
if (@e<14) 
	begin
		set @month = convert(int, (@e-1))
	end
else
	begin
		set @month = convert(int, (@e-13))
	end
if  (@month < 3)
	begin
		set @year  = CONVERT(int, (@c-4715))		
	end
else
	begin
		set @year  = CONVERT(int, (@c-4716))
	end


set @returnstring = CONVERT(nvarchar(2), @month) +'/' + CONVERT(nvarchar(2), @day)+'/' + CONVERT(nvarchar(4), @year)

return convert(datetime, @returnstring)

END