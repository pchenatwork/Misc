﻿create FUNCTION [dbo].[GET_BIDS]
(
	@ARG_TAX varchar(50),
	@datefrom date,
	@dateto date,
	@RangeType varchar(2)
)
RETURNS int
AS
begin

declare @n_ret int

declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime
if(DatePart(Month,getdate()) < 7)
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
	end
else
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
	end

if @datefrom =null or @datefrom ='1/1/1900'
	Begin
		if @RangeType ='F' --Fiscal year
			Begin
				set @datefrom=@firstDayOfYear
				set @dateto=@firstDayOfNextYear
			end
		Else
			Begin
				set @datefrom=DATEADD(Month,-12,GetDate())
				set @dateto=Getdate()
			end

	End
SELECT @n_ret =COUNT (*) 
FROM MV_VAS_BIDDER
WHERE C_VENDOR_ID = @ARG_TAX 
and  SD_ACTUAL_BID_OPEN between @datefrom and @dateto

return @n_ret

end
