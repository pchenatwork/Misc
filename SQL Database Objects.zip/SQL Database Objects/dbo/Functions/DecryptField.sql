﻿




CREATE FUNCTION [dbo].[DecryptField]
(
	@inputstring nvarchar(500),
	@key nvarchar(500)='2WorldWin8'
	
)
RETURNS nvarchar(500)
AS
BEGIN
-- Declare the return variable here
declare @inputstringlength int
declare @asc nvarchar(500)
set @asc= ''
declare @org_asc nvarchar(500)
set @org_asc= ''
declare @test_asc nvarchar(500)
set @test_asc= ''
declare @holdchar nvarchar(500)
set @holdchar=''
declare @flag int
declare @returnstring nvarchar(500)
set @returnstring = '' 
declare @decryptcursor cursor

if @inputstring=' '
	set @inputstringlength=1
else
	set @inputstringlength=len(@inputstring+'_') -1
	
if @inputstringlength < 1
	return ''

set @flag = 1
WHILE (@flag <= @inputstringlength)
	BEGIN
		set @asc = ascii( dbo.EncryptFieldFunction(SUBSTRING(@inputstring, @flag, 1), default))
	
		set @decryptcursor = cursor for (select ascii_val, crypt_map from encryption_map where crypt_map = @asc)
		open @decryptcursor
		fetch next from @decryptcursor into @org_asc, @test_asc
		while @@fetch_status = 0
			begin
				if (@test_asc = @asc)
					begin
						set @holdchar = char(@org_asc)
						break
					end
				fetch next from @decryptcursor into @org_asc, @test_asc

			end
		close @decryptcursor
				
		set @returnstring  = @returnstring + @holdchar
		SET @flag = @flag + 1

	END

	
return @returnstring

END




