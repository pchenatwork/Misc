﻿CREATE FUNCTION [dbo].[CompanyBranchList](@companyBranchId int)
RETURNS XML
WITH RETURNS NULL ON NULL INPUT 
BEGIN RETURN 
  (SELECT 
	Id			As '@Id',
	Name		As '@Name',
	Value		As '@Value',
	City		As '@City',
	State		As '@State',
	ParentId	As '@ParentId',
	CASE WHEN ParentId = @companyBranchId
		THEN dbo.CompanyBranchList(Id)
	END
   FROM CompanyBranch
   WHERE ParentId = @companyBranchId
	Order By Name
   FOR XML PATH('CompanyBranch'), ROOT('ArrayOfCompanyBranch'), TYPE)
END
