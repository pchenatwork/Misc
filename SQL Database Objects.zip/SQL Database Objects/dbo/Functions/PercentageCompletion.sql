﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[PercentageCompletion]
(
	@id int
)
RETURNS float
AS
BEGIN

	declare @result float
	
	set @result = (select v.pct_by_contract
					From 
						MV_SOLICIT_CONTRACT v
					inner join 
						[plan] p	
					on isnull(c_contract, me_contract) = p.ContractNo
						and isnull(v.n_solicit_seq, 0) = isnull(p.solicitSeq, 0)
					where 
						p.Id = @id)
	
	return @result
END


