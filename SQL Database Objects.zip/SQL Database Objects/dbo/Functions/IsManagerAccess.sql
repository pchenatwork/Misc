﻿
CREATE FUNCTION [dbo].[IsManagerAccess]
(
	@userId int,
	@roleName nvarchar(256)
)
RETURNS int

AS

begin

declare @Manager int
set @Manager = 0

if exists (select id from [User] u, aspnet_UsersInRoles ur, aspnet_Roles r
	where r.RoleName = @roleName and r.RoleId = ur.RoleId and ur.UserId = u.UserId
		and u.Id = @userId)
	set @Manager = 1

return @Manager

end









