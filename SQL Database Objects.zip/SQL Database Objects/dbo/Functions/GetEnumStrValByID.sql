﻿
if object_id('GetEnumStrValByID') is not NULL
   DROP FUNCTION dbo.GetEnumStrValByID
GO
CREATE FUNCTION dbo.GetEnumStrValByID
(
	@Domain VARCHAR(50),
	@Entity VARCHAR(50),
	@PropertyName VARCHAR(50),
	@intval int
)
RETURNS varchar(255)
AS
/* ================================
 * Sept 2020 PCHEN Created
 * Get StrVal from [Enums] table
 * ================================ */
BEGIN
	declare @tmp varchar(255)
	SELECT @tmp = StrVal FROM Enums WHERE Domain=@Domain AND Entity=@Entity AND PropertyName = @PropertyName and IntVal = @intval
	RETURN ISNULL(@tmp, 'N/A');
END
GO
/** Test **
SELECT dbo.GetEnumStrValByID('RFP', 'JM', 'Sec8', 2)
**/