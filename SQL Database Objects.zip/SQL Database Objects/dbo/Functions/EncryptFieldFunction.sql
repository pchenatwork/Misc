﻿

--ALTER FUNCTION [dbo].[EncryptField]
--(
--    @mstring nvarchar(500)  
--)
--RETURNS nvarchar(500)
--AS
--BEGIN
---- Declare the return variable here
--DECLARE @xstring nvarchar(500)
--SET @xstring = '' 

--DECLARE @li_check  int
--DECLARE @Flag INT
--	SET @Flag = 1

--declare @length int
--if @mstring=' '
--	set @length=1
--else
--	set @length=len(@mstring)
--WHILE (@Flag <= @length)
--	BEGIN
--		set @li_check = ASCII(SUBSTRING(@mstring, @Flag, 1)) + @Flag
--		if ( @li_check > 127 )
--			set @li_check = @li_check - 127
--		set @xstring = char(@li_check) + @xstring
--		SET @Flag = @Flag + 1
--	END

--return @xstring
--END
-------





CREATE FUNCTION [dbo].[EncryptFieldFunction]
(
    @inputstring nvarchar(500),
    @key nvarchar(500)='2WorldWin8'
)
RETURNS nvarchar(500)
AS
BEGIN
-- Declare the return variable here
declare @inputstringlength int
declare @keylength int
declare @finalkey nvarchar(500)
set @finalkey=''
declare @str_check  int
declare @key_check  int
declare @str_asc nvarchar(500)
set @str_asc= ''
declare @count int
declare @i int
declare @flag INT
declare @returnstring nvarchar(500)
set @returnstring = '' 

if @inputstring=' '
	set @inputstringlength=1
else
	set @inputstringlength=len(@inputstring+'_') -1

if @inputstringlength < 1
	return ''
	
if @key=' '
	set @keylength=1
else
	set @keylength=len(@key+'_') -1

if @keylength < 1
	return ''
	
if (@keylength <@inputstringlength)
	begin
		set @count = ceiling(convert(float, @inputstringlength)/@keylength)
		set @keylength = @keylength * @count
		set @i=1
		while (@i<=@count)
			begin
				set @finalkey = @finalkey + @key
				set @i = @i + 1
			end
			
	end
else
	set @finalkey = @key


set @keylength = @keylength - @keylength%@inputstringlength
set @finalkey = substring(@finalkey, 1, @keylength)

/************************/
--set @count = @keylength/@inputstringlength
--set @flag = 1
--WHILE (@flag <= @inputstringlength)
--	BEGIN
--		set @key_check = 0
--		set @i=1
--		while ( @i <=@count)
--			begin
--				set @key_check = @key_check + ASCII(substring(@finalkey, (@flag + (@i *@inputstringlength -@inputstringlength)), 1))
--				set @i = @i + 1
--			end
--		set @str_check = @key_check + ASCII(SUBSTRING(@inputstring, @flag, 1))
--		while ( @str_check > 127 )
--			set @str_check = @str_check - 127
--		set @returnstring  = @returnstring + char(@str_check)
--		SET @flag = @flag + 1
--	END
/************************/


/************************/
set @count = @keylength/@inputstringlength
set @flag = 1
WHILE (@flag <= @inputstringlength)
	BEGIN
		set @key_check = 0
		set @i=1
		while ( @i <=@count)
			begin
				--if @keylength = @inputstringlength
				--	set @key_check = @key_check + ASCII(substring(@finalkey, (@flag + (@i *@inputstringlength -@inputstringlength)), 1))
				--else
				--	set @key_check = @key_check + ASCII(substring(@finalkey, @i, 1))
				
				set @key_check = @key_check + ASCII(substring(@finalkey, (@flag + (@i *@inputstringlength -@inputstringlength)), 1))					
				set @i = @i + 1
			end
			
		--set @str_asc = ASCII(SUBSTRING(@inputstring, @flag, 1))
		--if @str_asc = 32 
		--	set @str_check = 32
		--else
		--	set @str_check = @key_check + @str_asc
		
		--if @str_check%127 = 0 
		--	set @str_check = ASCII(SUBSTRING(@inputstring, @flag, 1)) 
			
		--while(@str_check>=127)
		--	begin
		--		set @key_check = 32
		--		set @str_check = @key_check + @str_check%127
		--		if @str_check >=127 
		--			begin
		--				if @str_check%127 = 0 
		--					set @str_check = ASCII(SUBSTRING(@inputstring, @flag, 1))
		--				else
		--					begin
		--						set @key_check = 32
		--						set @str_check = @key_check + @str_check%127
		--						if @str_check%127 = 32 or @str_check%127 = 0 
		--							set @str_check = ASCII(SUBSTRING(@inputstring, @flag, 1))
		--					end
		--			end
		--	end


		set @str_check = @key_check + ASCII(SUBSTRING(@inputstring, @flag, 1))
		if ( @str_check > 127 )
			begin 
				set @str_check = @str_check % 127
			end

		if ( @str_check =0)
			begin
				set @str_check = 130
			end
		
		
		--if (ASCII(SUBSTRING(@inputstring, @flag, 1))=140)
		--	begin
		--		set @str_check = (@key_check + 32)%127
		--	end
			
		set @returnstring  = @returnstring + char(@str_check)
		SET @flag = @flag + 1
	END
/************************/


return @returnstring

END



