﻿create function [dbo].[EEO_ApprentInfo]
	(
		@supplierId int
	)
RETURNS varchar(4000)
As
Begin
	Declare @ret varchar(4000)
	Set @ret=''

	SELECT @ret=@ret + Coalesce(sap.[ProgramName] + ' ' + p.VC_APRN_PROGRAM + ',','')
	  FROM [SupplierApprenticeshipProgram] sap
	  inner join CMS_Apprent_Prog p
	  on p.c_aprn_code = sap.programname
	  where sap.supplierid = @supplierId

	RETURN @ret
End
