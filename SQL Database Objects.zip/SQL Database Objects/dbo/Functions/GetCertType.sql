﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetCertType]
(
	-- Add the parameters for the function here
	@supplierid int
)
RETURNS Varchar(100)
AS
 
 Begin               
	declare @CertType   varchar(100) 
	declare @WomenPercentage int
	declare @MinorityPercentage int
	declare @lbetotal int
	declare @property51 int
	
	declare @property2004 varchar(100) 
	declare @percentage int
	declare @count int
	--declare @supplierid int
	--set @supplierid =33252
	
	select	
		@WomenPercentage=sum(OwnedPercentage) 
	from	
		supplierpersonnel 
	where	
		isKeyperson='Y' 
		and isOwner='Y' 
		and supplierid=@supplierid
		and Gender='F'
	
	select	
		@MinorityPercentage=sum(OwnedPercentage) 
	from	
		supplierpersonnel 
	where	
		isKeyperson='Y' 
		and isOwner='Y' 
		and (Ethnicity is not null and Ethnicity<>'05')
		and supplierid=@supplierid
		
	if @WomenPercentage>50 
		select @count=count(*) from supplierclassification where supplierid=@supplierid	 and classification='WBE'
		if @count>0
			set @CertType='WBE '
	
	if @MinorityPercentage>50
	Begin
		set @count=0
		select @count=count(*) from supplierclassification where supplierid=@supplierid	 and classification='MBE'
		if @count>0
			set @CertType=isnull(@CertType,' ') + 'MBE '
		
	end
	
	select 
			@property2004=propertytext 
		from 
			supplierproperty 
		where 
			supplierid=@supplierid
			and propertyid=2004
	
	
	if @property2004='area'
	Begin
		select
			@lbetotal=sum(cast(sr.ContractAmount as int))
		from
			supplierproperty sp, supplierproject sr
		where 
			sp.supplierid=@supplierid
			and sp.supplierid=sr.supplierid
			and sp.propertyid=2004
			and cast(sp.propertytext as varchar)='area'
			and sr.type='AddLbeProject'
			
			
		if @lbetotal>0 
		
		Begin
			select 
				@property51=convert(int, cast(propertytext as varchar)) 
 
			from 
				supplierproperty 
			where 
				supplierid=@supplierid
				and propertyid=51
			
			if @property51>0 
			Begin
				set @percentage=(@lbeTotal*100)/@property51
				if @percentage>25
					set @count=0
					select @count=count(*) from supplierclassification where supplierid=@supplierid	 and classification='LBE' 
					if @count>0
						set @CertType=isnull(@CertType,' ') + 'LBE '
				
			End
			else
				set @count=0
				select @count=count(*) from supplierclassification where supplierid=@supplierid	 and classification='LBE' 
				if @count>0
					set @CertType=isnull(@CertType,' ') + 'LBE '
			
		end
	end
	
	return @CertType
End


