﻿

CREATE FUNCTION [dbo].[GetProjectAwardSelections](@llwCode varchar(50),@solicitationNumber varchar(50))
returns nvarchar(max)
AS
begin

	DECLARE @awards nvarchar(max)
	set @awards=''
	
	SELECT @awards = @awards + AWARD_NUMBER + '|'
    from MV_SOLICIT_ORA_AWARD
    where LLW_CODE = @llwCode
	and SOLICITATION = @solicitationNumber

return @awards
end
