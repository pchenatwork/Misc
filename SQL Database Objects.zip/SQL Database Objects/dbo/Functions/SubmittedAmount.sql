﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[SubmittedAmount]
(
	@id int
)
RETURNS float
AS
BEGIN
	declare @submittedAmount float
	
	set @submittedAmount = 
		(select 
			isnull(SUM(isnull(estvalue, 0)), 0) 
		from 
			PlanSubcontractor 
		where 
			PlanId  = @id
			and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, ''))))
	
	return @submittedAmount
		
END


