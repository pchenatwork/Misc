﻿CREATE FUNCTION fnStripNonnumericChars 
	(@OrigString nvarchar(255))
RETURNS nvarchar(255)
AS
BEGIN
/*
32 is a space 
48 to 57 are our numbers 0-9 
65 to 90 are the capital letters A-Z 
97 to 122 are the lowercase letters a-z 

-- usage: fnStripNonnumericChars('12345 MB')
*/

declare @NewString nvarchar(255)


Declare @Len int, @Ctr As int, @Ctr2 As int, @Char As nvarchar(1)

select @Len = Len(@OrigString)
select @NewString=''

select @Ctr2 = 1, @Ctr=1

while @Ctr <= @Len
Begin
    Select @Char = substring(@OrigString, @Ctr, 1)
    If ASCII(@Char) between 48 and 57 
    begin 	
	Select @NewString=@NewString+@Char
        Select @Ctr2 = @Ctr2 + 1
    end
    select @Ctr=@Ctr+1
CONTINUE
end
If @Ctr2 = 1 
    Select @NewString = ''


RETURN @NewString

END











