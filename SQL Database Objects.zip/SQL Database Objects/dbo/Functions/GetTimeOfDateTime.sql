﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
create FUNCTION [dbo].GetTimeOfDateTime
(
	@dateTimeStr nvarchar(50)
)
RETURNS nvarchar(8)
AS
BEGIN
	declare @hour int
	declare @hourStr nvarchar(2)
	declare @APM nvarchar(2)

	select @hour = Convert(int, Substring(@datetimeStr, 12, 2))

	if @hour<12
		begin
			set @hourStr = Substring(@datetimeStr, 12, 2)
			set @APM= 'AM'
		end
	if @hour=12
		begin
			set @hourStr = Substring(@datetimeStr, 12, 2)
			set @APM='PM'
		end
	if @hour>12 and @hour<22
		begin
			set @hourStr = '0' + convert(nvarchar, @hour-12)
			set @APM='PM'
		end
	if @hour>=22
		begin
			set @hourStr = convert(nvarchar, @hour-12)
			set @APM='PM'
		end

	return @hourStr + Substring(@datetimeStr, 14, 3) + ' ' + @APM

END


