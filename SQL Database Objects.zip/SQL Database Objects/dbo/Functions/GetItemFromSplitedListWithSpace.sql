﻿



create FUNCTION [dbo].[GetItemFromSplitedListWithSpace](@string nvarchar(100), @delim char(1), @index int)
RETURNS nvarchar(50)
AS
BEGIN
	-- Declare the return variable here
	Declare @temp Table
	(	
		id int identity(1, 1),
		item nvarchar(50)
	)	
	Declare  @item nvarchar(50)
	
	insert into @temp select item from dbo.SplitWithSpace(@string, @delim)
	set @item = (select item from @temp where id = @index)
	return isnull(@item, '')

END
