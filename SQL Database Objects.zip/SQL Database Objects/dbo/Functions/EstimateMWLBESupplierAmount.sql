﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[EstimateMWLBESupplierAmount]
(
	@id int
)
RETURNS float
AS
BEGIN
	declare @estimateMWLBESupplierAmount float
	declare @maxMWLBESupplierAmount float
	
if exists(select * from PlanSubcontractorpro where PlanId  = @id)
	set @estimateMWLBESupplierAmount = 
		(select 
			isnull(SUM(isnull(estvalue, 0)), 0) 
		from 
			PlanSubcontractorPro 
		where 
			PlanId  = @id
			and ISNULL(IsSupplierOnly,'N')='Y'
			and isnull(IsNonMinority, 'N')!='Y'
			and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))
		)

Else
	set @estimateMWLBESupplierAmount = 
		(select 
			isnull(SUM(isnull(estvalue, 0)), 0) 
		from 
			PlanSubcontractor 
		where 
			PlanId  = @id
			and ISNULL(IsSupplierOnly,'N')='Y'
			and isnull(IsNonMinority, 'N')!='Y'
			and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))
		)



	
	
	set @maxMWLBESupplierAmount = 
		(select 
			case 
				when [type]='Line'and isnull(IsWaiver, 'N')!= 'Y' then isnull(MWLBEGoal, 0) * 0.25
				when [type]='Line'and isnull(IsWaiver, 'N') = 'Y' then isnull(RevisedMWLBEGoal, 0) * 0.25
				when [type]='CIP'and isnull(IsWaiver, 'N')!= 'Y' then isnull(MWLBEGoal, 0) * 0.2
				when [type]='CIP'and isnull(IsWaiver, 'N') = 'Y' then isnull(RevisedMWLBEGoal, 0) * 0.2
				else null
			end
		 from
			[plan]
		 where 
			id = @id
	)
	
	if (@maxMWLBESupplierAmount is not null and @estimateMWLBESupplierAmount > @maxMWLBESupplierAmount)
		set @estimateMWLBESupplierAmount = @maxMWLBESupplierAmount
			
	return @estimateMWLBESupplierAmount
		
END
