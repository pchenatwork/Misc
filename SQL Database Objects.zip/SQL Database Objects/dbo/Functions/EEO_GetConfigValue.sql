﻿--------------------------
CREATE FUNCTION [dbo].[EEO_GetConfigValue](@Key varchar(100))
RETURNS varchar(150) 
AS 
-- Returns the stock level for the product.
BEGIN
    DECLARE @ret varchar(150) ;
    SELECT @ret = c.[Value] 
    FROM dbo.EEO_CONFIG c 
    WHERE c.[Key] = @Key 
         
     IF (@ret IS NULL) 
        SET @ret = '';
    RETURN @ret;
END;
