﻿

CREATE FUNCTION [dbo].[IsUserInRole]
(
    @userId int,  
    @roleName nvarchar(4000)  
)
RETURNS bit
AS
BEGIN
-- Declare the return variable here
DECLARE @flag bit
SET @flag = 0 

if exists (select * from [User] u, dbo.aspnet_Roles ar, dbo.aspnet_UsersInRoles aur
	where u.Id = @userId and u.UserId = aur.UserId and aur.RoleId = ar.RoleId 
		and ar.RoleName in (select item from dbo.Split(@roleName,'|'))
		)
	set @flag = 1

return @flag
END



