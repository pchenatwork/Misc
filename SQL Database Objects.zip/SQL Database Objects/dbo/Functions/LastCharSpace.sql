﻿


create FUNCTION [dbo].[LastCharSpace]
(
    @inputstring nvarchar(500)
)
RETURNS nvarchar(500)
AS
BEGIN
	if Right(@inputstring, 1)=' ' 
		begin
			set @inputstring = @inputstring + '`'
		end
	return @inputstring
END
