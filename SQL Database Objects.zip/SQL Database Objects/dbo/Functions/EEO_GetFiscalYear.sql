﻿CREATE FUNCTION dbo.EEO_GetFiscalYear(
	@indate	DATETIME
)
RETURNS INT
AS
BEGIN

	DECLARE @fiscalYear INT

	IF ( MONTH(@indate) >= 6 )
		SET @fiscalYear = YEAR(@indate) + 1
	ELSE
		SET @fiscalYear = YEAR(@indate)


	RETURN @fiscalYear

END
