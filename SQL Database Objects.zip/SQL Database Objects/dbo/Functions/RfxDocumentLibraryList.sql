﻿CREATE FUNCTION [dbo].[RfxDocumentLibraryList](@parentId int)
RETURNS XML
WITH RETURNS NULL ON NULL INPUT 
BEGIN RETURN 
  (SELECT 
	Id				As '@Id',
	ProjectId		As '@ProjectId',
	ParentId		As '@ParentId',
	Name			As '@Name',
	Description		As '@Description',
	Status			As '@Status',
	UserId			As '@UserId',
	CreateDate		As '@CreateDate',
	ChangeUser		As '@ChangeUser',
	ChangeDate		As '@ChangeDate',
	CASE WHEN ParentId = @parentId
		THEN dbo.RfxDocumentLibraryList(Id)
	END
   FROM RfxDocumentLibrary
   WHERE ParentId = @parentId
	Order BY Name
   FOR XML PATH('RfxDocumentLibrary'), ROOT('ArrayOfRfxDocumentLibrary'), TYPE)
END