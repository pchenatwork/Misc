﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[EstimateMWLBESubcontractorAmountBakVas5_4]
(
	@id int
)
RETURNS float
AS
BEGIN
	declare @estimateMWLBESubcontractorAmount float
	
	set @estimateMWLBESubcontractorAmount = 
		(select 
			isnull(SUM(isnull(estvalue, 0)), 0) 
		from 
			PlanSubcontractor 
		where 
			PlanId  = @id
			and ISNULL(IsSupplierOnly,'N')!='Y'
			and isnull(IsNonMinority, 'N')!='Y'
			and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))
		)
	
	return @estimateMWLBESubcontractorAmount
		
END


