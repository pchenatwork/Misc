﻿CREATE FUNCTION [dbo].[CertificationTypeList](@certificationTypeId int)
RETURNS XML
WITH RETURNS NULL ON NULL INPUT 
BEGIN RETURN 
  (SELECT 
	Id				As '@Id',
	Name			As '@Name',
	Value			As '@Value',
	ParentId		As '@ParentId',
	IsActive		As '@IsActive',
	Classification	As '@Classification',
	CASE WHEN ParentId = @certificationTypeId
		THEN dbo.CertificationTypeList(Id)
	END
   FROM CertificationType
   WHERE ParentId = @certificationTypeId
	Order By Id
   FOR XML PATH('CertificationType'), ROOT('ArrayOfCertificationType'), TYPE)
END


