﻿CREATE FUNCTION [dbo].[FormatPhoneNumber]
(@phone nvarchar(20))
RETURNS nvarchar(20)

AS

begin

If (Len(@phone) <> 10)
     return @phone

return Left(@phone, 3) + '-' + SubString(@phone, 4, 3) + '-' + SubString(@phone, 7, 4)

end
