﻿
CREATE FUNCTION [dbo].[OutlookByUserAgingCount]
(
	@userId int,
	@spName nvarchar(50),
	@fromDate datetime,
	@toDate datetime
)
RETURNS int
AS
BEGIN

DECLARE @count int
set @count = 0

declare @userGuid uniqueidentifier
declare @username nvarchar(50)
select @userGuid = u.UserId, @username = au.Username from [User] u, aspnet_users au
	where u.Id = @userId and u.UserId = au.UserId

--#region Other Items
declare @propertyId_ReviewerId int
set @propertyId_ReviewerId = 10
declare @propertyId_ManagerId int
set @propertyId_ManagerId = 521
declare @propertyId_IOGDecision int
set @propertyId_IOGDecision = 508
declare @propertyId_CertificationAnalyst int
set @propertyId_CertificationAnalyst = 521
--#endregion Other Items

------------ Qualification Status ----------

-- (FindItem150) Application Submitted
IF ( @spName = 'FindItem150' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Application Submitted'
	and ss.ChangeDate between @fromDate and @toDate
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem151) Manager Reviewed
IF ( @spName = 'FindItem151' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Manager Reviewed'
	and ss.ChangeDate between @fromDate and @toDate
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem152) Request More Info Pending
IF ( @spName = 'FindItem152' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info Pending'
	and ss.ChangeDate between @fromDate and @toDate
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem153) Request More Info
IF ( @spName = 'FindItem153' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info'
	and ss.ChangeDate between @fromDate and @toDate
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem154) Additional Info Submitted
IF ( @spName = 'FindItem154' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Info Submitted'
	and ss.ChangeDate between @fromDate and @toDate
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem155) Request More Info 2
IF ( @spName = 'FindItem155' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info 2'
	and ss.ChangeDate between @fromDate and @toDate
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem156) Additional Info Submitted 2
IF ( @spName = 'FindItem156' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Info Submitted 2'
	and ss.ChangeDate between @fromDate and @toDate
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem157) Reviewer Reviewed
IF ( @spName = 'FindItem157' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reviewer Reviewed'
	and ss.ChangeDate between @fromDate and @toDate
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem158) Reference Reviewed
IF ( @spName = 'FindItem158' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reference Reviewed'
	and ss.ChangeDate between @fromDate and @toDate
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem159) Financial Reviewed
IF ( @spName = 'FindItem159' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Financial Reviewed'
	and ss.ChangeDate between @fromDate and @toDate
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
	
------------ End Qualification Status ----------

-- no type found
RETURN @count

END
