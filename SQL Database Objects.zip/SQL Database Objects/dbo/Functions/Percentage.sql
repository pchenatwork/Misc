﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[Percentage]
(
	@num1 float,
	@num2 float
)
RETURNS float
AS
BEGIN
	declare @results float
	if @num1=0 and @num2 = 0 
		set @results = 0
	else if @num2 = 0
		set @results = 0
	else
		set @results = @num1/@num2

	return @results
		
END


