﻿CREATE FUNCTION V_EEO_CERT_FUNC( @RECERT_FLAG   char(1))
RETURNS @eeoDetail TABLE
    (
			[vendorid] [int] NULL,
			[supplierid] [int] NULL,
			[ssc_id] [int] NULL,
			[c_vendor_id] [char](11) NOT NULL,
			[c_eeo_type] [char](1) NOT NULL,
			[sd_exp_date] [smalldatetime] NULL,
			[sd_cert_date] [smalldatetime] NULL,
			[sd_recert_date] [smalldatetime] NULL,
			[b_city_cert] [bit] NOT NULL,
			[b_state_cert] [bit] NOT NULL,
			[b_port_cert] [bit] NOT NULL,
			[c_dw_code] [char](1) NULL,
			[sd_dw_date] [smalldatetime] NULL,
			[vc_dw_note] [varchar](1000) NULL,
			[sd_appl_date] [smalldatetime] NULL,
			[sd_pending] [smalldatetime] NULL,
			[sd_pend_date] [smalldatetime] NULL,
			[c_eeo_status] [char](1) NULL,
			[sd_notice_date] [smalldatetime] NULL,
			[c_whoedit] [nvarchar](100) NULL,
			[sd_update] [smalldatetime] NULL,
			[SD_RECERT_NOTICE_SEND] [smalldatetime] NULL,
			[SD_INFO_LETTER_SENT_1] [smalldatetime] NULL,
			[SD_INFO_LETTER_SENT_2] [smalldatetime] NULL,
			[SD_INFO_LETTER_RECEIVED_1] [smalldatetime] NULL,
			[SD_INFO_LETTER_RECEIVED_2] [smalldatetime] NULL,
			[SD_ARCH_LETTER_SENT] [smalldatetime] NULL,
			[SD_RESPONSE_TO_ARCHIVE] [smalldatetime] NULL,
			[SD_APP_ARCHIVED] [smalldatetime] NULL,
			[C_COMPLETED] [char](1) NOT NULL,
			[I_SEQ_NO] [numeric](9, 0)  NOT NULL,
			[VASID] [numeric](18, 0) NULL,
			[N_APP_SEQ] [numeric](9, 0)  NOT NULL,
			[c_processed] [char](50)   NULL
    )
AS



BEGIN
		Declare @id int
		Declare @supplierId int
		Declare @contentDate datetime
		Declare @actionTime datetime
		Declare @content nvarchar(500)
		Declare @expirationDate datetime
		Declare	@status nvarchar(50) = null
		Declare @mycursor cursor


	if @RECERT_FLAG = '1' 
	begin

		INSERT @eeoDetail 
			 SELECT
				v.Id as    VENDORID, 
				v.CurrentSupplierId,
				ssc.id,
				v.FederalId as   C_VENDOR_ID,
				V_C_EEO_TYPE as C_EEO_TYPE,
				V_sd_exp_date as SD_EXP_DATE,
				V_sd_cert_date as SD_CERT_DATE,
				V_sd_recert_date as SD_RECERT_DATE,
				0 B_CITY_CERT,
				0 B_STATE_CERT,
				0 B_PORT_CERT,
				V_c_dw_code as C_DW_CODE,
				V_sd_dw_date as SD_DW_DATE,
				LEFT(V_vc_dw_note, 1000)  as VC_DW_NOTE,
				V_SD_APPL_DATE as SD_APPL_DATE,
				NULL SD_PENDING,
				NULL SD_PEND_DATE,
				'' as C_EEO_STATUS,
				V_sd_recert_notice_send as SD_NOTICE_DATE,
				ChangeUser as C_WHOEDIT,
				ChangeDate as SD_UPDATE,
				V_sd_recert_notice_send as SD_RECERT_NOTICE_SEND,
				V_sd_info_letter_sent_1 as SD_INFO_LETTER_SENT_1,
				V_sd_info_letter_sent_2 as SD_INFO_LETTER_SENT_2,
				V_sd_info_letter_received_1 as SD_INFO_LETTER_RECEIVED_1,
				V_sd_info_letter_received_2 as SD_INFO_LETTER_RECEIVED_2,
				NULL SD_ARCH_LETTER_SENT,
				NULL  SD_RESPONSE_TO_ARCHIVE,
				NULL   SD_APP_ARCHIVED,
				'N'  C_COMPLETED,
				0 I_SEQ_NO,
				0 VASID,
				0 as N_APP_SEQ,
				null as c_processed
		 FROM SupplierStaticCertification ssc ,  vendor v 
		  WHERE ssc.SupplierId = v.CurrentSupplierId and IsApplied='Y' and  recertTransferredFlag = '1';
	end

	else if  @RECERT_FLAG != '1' 
	begin			
		INSERT @eeoDetail 
			 SELECT
				v.Id as    VENDORID, 
				v.CurrentSupplierId,
				ssc.id,
				v.FederalId as   C_VENDOR_ID,
				V_C_EEO_TYPE as C_EEO_TYPE,
				V_sd_exp_date as SD_EXP_DATE,
				V_sd_cert_date as SD_CERT_DATE,
				V_sd_recert_date as SD_RECERT_DATE,
				0 B_CITY_CERT,
				0 B_STATE_CERT,
				0 B_PORT_CERT,
				V_c_dw_code as C_DW_CODE,
				V_sd_dw_date as SD_DW_DATE,
				LEFT(V_vc_dw_note, 1000)  as VC_DW_NOTE,
				V_SD_APPL_DATE as SD_APPL_DATE,
				NULL SD_PENDING,
				NULL SD_PEND_DATE,
				'' as C_EEO_STATUS,
				V_sd_recert_notice_send as SD_NOTICE_DATE,
				ChangeUser as C_WHOEDIT,
				ChangeDate as SD_UPDATE,
				V_sd_recert_notice_send as SD_RECERT_NOTICE_SEND,
				V_sd_info_letter_sent_1 as SD_INFO_LETTER_SENT_1,
				V_sd_info_letter_sent_2 as SD_INFO_LETTER_SENT_2,
				V_sd_info_letter_received_1 as SD_INFO_LETTER_RECEIVED_1,
				V_sd_info_letter_received_2 as SD_INFO_LETTER_RECEIVED_2,
				NULL SD_ARCH_LETTER_SENT,
				NULL  SD_RESPONSE_TO_ARCHIVE,
				NULL   SD_APP_ARCHIVED,
				'N'  C_COMPLETED,
				0 I_SEQ_NO,
				0 VASID,
				0 as N_APP_SEQ,
				null as c_processed
		 FROM SupplierStaticCertification ssc ,  vendor v 
		  WHERE ssc.SupplierId = v.CurrentSupplierId and IsApplied='Y' and  (recertTransferredFlag != '1' or recertTransferredFlag is null);
	end
	/*
			UPDATE ed
				SET ed.C_COMPLETED = 'N'
				FROM @eeoDetail ed inner join SupplierStatus ss on ed.supplierid = ss.SupplierId 
						inner join Vendor v  on ss.SupplierId = v.CurrentSupplierId

						where   ss.TypeName = 'Supplier Certification' 
						and ss.Status in (
						'Appendix A Pending' ,
						'Request More Certification Info' ,
						'Additional Certification Info Submitted' ,
						'Request More Certification Info 2' 
			) 
			 
				
				UPDATE ed
				SET ed.C_COMPLETED = 'Y'
				FROM	@eeoDetail ed inner join SupplierStatus ss on ed.supplierid = ss.SupplierId 
									  inner join Vendor v  on ss.SupplierId = v.CurrentSupplierId
						where   ss.TypeName = 'Supplier Certification' 
						and ss.Status in (
								'Suspended'  ,
								'Withdrawn' ,
								'Certification Admin Closed' ,
								'Decertified',
								'Rescinded',
								'Expired',
								'Conditionally Certified',
			 					'Certified'
		     	) 

				*/
 
			RETURN 

		END
