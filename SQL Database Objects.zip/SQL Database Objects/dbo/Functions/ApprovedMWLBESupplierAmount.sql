﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[ApprovedMWLBESupplierAmount]
(
	@id int
)
RETURNS float
AS
BEGIN
	declare @approvedMWLBESupplierAmount float
	declare @maxMWLBESupplierAmount float
	
	set @approvedMWLBESupplierAmount = 
		(select 
			isnull(SUM(isnull(approvedvalue, 0)), 0) 
		from 
			PlanSubcontractor 
		where 
			PlanId  = @id
			and ISNULL(IsSupplierOnly,'N')='Y'
			and isnull(IsNonMinority, 'N')!='Y'
			and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))
			--and (rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, ''))) or (TaxId='' and FederalId=''))
		)
	
	
	set @maxMWLBESupplierAmount = 
		(select 
			case 
				when [type]='Line'and isnull(IsWaiver, 'N')!= 'Y' then isnull(MWLBEGoal, 0) * 0.25
				when [type]='Line'and isnull(IsWaiver, 'N') = 'Y' then isnull(RevisedMWLBEGoal, 0) * 0.25
				when [type]='CIP'and isnull(IsWaiver, 'N')!= 'Y' then isnull(MWLBEGoal, 0) * 0.2
				when [type]='CIP'and isnull(IsWaiver, 'N') = 'Y' then isnull(RevisedMWLBEGoal, 0) * 0.2
				else null
			end
		 from
			[plan]
		 where 
			id = @id
	)
	
	if (@maxMWLBESupplierAmount is not null and @approvedMWLBESupplierAmount > @maxMWLBESupplierAmount)
		set @approvedMWLBESupplierAmount = @maxMWLBESupplierAmount
			
	return @approvedMWLBESupplierAmount
		
END
