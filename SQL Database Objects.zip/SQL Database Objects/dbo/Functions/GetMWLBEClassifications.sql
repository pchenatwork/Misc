﻿IF OBJECT_ID(N'dbo.GetMWLBEClassifications') IS NOT NULL
	DROP FUNCTION [dbo].[GetMWLBEClassifications]
GO
/*
*******************************************************************************
FUNCTION:	GetMWLBEClassifications
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
08/01/2017      PCHEN               Comment section first created
    1. fix @value == null bug
*******************************************************************************
*/
CREATE FUNCTION [dbo].[GetMWLBEClassifications] 
(
	-- Add the parameters for the function here
	@supplierid integer
)
RETURNS varchar(100)
AS
BEGIN
	
	declare @transactionid integer
	declare @hasapproval char(1)
	declare @count integer
	DECLARE @classArrayValues TABLE(ID INTEGER, VALUE VARCHAR(100));
	INSERT INTO @classArrayValues
	VALUES(1,'N'),(2,'N'),(3,'N'),(4,'N')
	
	set @hasapproval=0
	
	-- Get the transactionid of certification
	select @transactionid=TransactionId from supplierworkflow where workflowid=2 and supplierid=@supplierid
	If @transactionid =0
		return 'sdsd'
	
	-- Check whether the certification is approved by Director
	select 
		@count=count(*) 
	from 
		workflowhistory wh
		inner join workflownode wn on wh.currentnodeid=wn.id
	where 
		wh.transactionheaderid=@transactionid 
		and wn.Description='Director Approved'
	
	if @count>0
		set @hasapproval=1

	-- debug stmt
	
    declare @pException char(1)
    declare @SupplierCertStatus varchar(100)
    set @pException =0
    
    select @SupplierCertStatus=[Status] from supplierstatus where typeName='Supplier Certification' and supplierid=@supplierid
   
    ---- 20170801 *bugfix* -- if @SupplierCertStatus != null
    if @SupplierCertStatus IS NOT NULL
    
        if @SupplierCertStatus = 'Certified'
            set @hasApproval = 1
        if @SupplierCertStatus= 'Certification Analyst Closed' Or
            @SupplierCertStatus= 'Certification Closed' Or
            @SupplierCertStatus= 'Deny' Or
            @SupplierCertStatus= 'Decertified' Or
            @SupplierCertStatus= 'Disqualified' Or
            @SupplierCertStatus= 'Withdrawn' Or
            @SupplierCertStatus= 'Rescinded' Or
            @SupplierCertStatus= 'Expired' Or
            @SupplierCertStatus= 'Certification Admin Closed'
            set @pException = 1
    
	declare @Property varchar(20)
	declare @Value varchar(20)
	declare @type varchar(20)
	declare @approvalString varchar(100)	
	
    DECLARE cert_cursor CURSOR FOR 
	select 
		'IsApplied' as property,IsApplied as value, V_c_eeo_type as type 
	from 
		SupplierStaticCertification 
	where 
		supplierid=@supplierid
	union
	select 
		'V_c_dw_code' as property,V_c_dw_code as value, V_c_eeo_type as type 
	from 
		SupplierStaticCertification 
	where 
		supplierid=@supplierid

    OPEN cert_cursor
    FETCH NEXT FROM cert_cursor INTO @Property,@Value,@type

    WHILE @@FETCH_STATUS = 0
    BEGIN
		If @Property='IsApplied' 
		Begin
            if @Value = 'Y' and @pException=0
            begin
				If @type='M'
				Begin
					if not exists(select * from @classArrayValues where VALUE='Y' and Id=1)
						Update @classArrayValues set VALUE='P' where id=1
				End
				Else if @type='W' 
				Begin
					if not exists(select * from @classArrayValues where VALUE='Y' and Id=2)
						Update @classArrayValues set VALUE='P' where id=2
				End
                Else if @type='L' 
				Begin
					if not exists(select * from @classArrayValues where VALUE='Y' and Id=3)
						Update @classArrayValues set VALUE='P' where id=3
				End										
             end       
        end

        If @property='V_c_dw_code'
        Begin
			if @hasApproval=1
			Begin
				If @VALUE='Y' or @Value='R'
					set @approvalString ='Y'
				else
					set @approvalString ='N'                

				--return @approvalString
                If @type='M' 
					Update @classArrayValues set VALUE=@approvalString where id=1
				Else if @type='W' 
					Update @classArrayValues set VALUE=@approvalString where id=2
				Else if @type='L' 
					Update @classArrayValues set VALUE=@approvalString where id=3
                        
             end           
        End      
        FETCH NEXT FROM cert_cursor INTO @Property,@Value,@type
	END

    CLOSE cert_cursor
    DEALLOCATE cert_cursor
	
	/*
    if @hasApproval=1
		update @classArrayValues set Value='Y' where id=4
	else
		update @classArrayValues set Value='N' where id=4
    
    */
    declare @ID integer
    declare @arrval varchar(10)
    declare cur_mwlbe cursor for
    select * from @classArrayValues

    declare @classifications varchar(100)
	set @classifications=''
    declare @certVal varchar(5)
	declare  @certRecommendation varchar(70)

	select @certRecommendation =cast(PropertyText as varchar(20)) from SupplierProperty where PropertyId=501 and supplierid=@supplierid;

	if(@certRecommendation ='Not Eligible' And @hasApproval<>1 )
			set @classifications = '<font color=''Red''><b>' + @certRecommendation + '</b></font>';
	else
	Begin
		open cur_mwlbe
		Fetch next from cur_mwlbe into @ID,@arrval
		WHILE @@FETCH_STATUS = 0
		Begin
		
			if (@hasApproval=1 and @arrval = 'P')
				continue
			else
			begin

				if @ID=1
					set @certVal='MBE'
				else if @id=2
						set @certVal='WBE'
				else if @id=3
						set @certVal='LBE'				 
			
				if (@arrval != 'N')
				BEgin	
					set @classifications += @certVal				
				
					if (@arrval= 'P')
						set @classifications = @classifications + '<font color=''#1C3764''><b>(P)</b></font>'
					
					set @classifications = @classifications + ', '
				End
			end

    		Fetch next from cur_mwlbe into @ID,@arrval
		end
		close cur_mwlbe
		deallocate cur_mwlbe
	End

	return @classifications

END
GO

/* 
select dbo.GetMWLBEClassifications(42255),
  dbo.GetMWLBEClassifications(37475)
*/
