﻿CREATE FUNCTION [dbo].[IsUserIdInRole]
(
    @userId uniqueidentifier,  
    @roleName nvarchar(4000)  
)
RETURNS bit
AS
BEGIN
-- Declare the return variable here
DECLARE @flag bit
SET @flag = 0 

if exists (select * from dbo.aspnet_Roles ar, dbo.aspnet_UsersInRoles aur
	where @userId = aur.UserId and aur.RoleId = ar.RoleId 
		and ar.RoleName in (select item from dbo.Split(@roleName,'|'))
		)
	set @flag = 1

return @flag
END
