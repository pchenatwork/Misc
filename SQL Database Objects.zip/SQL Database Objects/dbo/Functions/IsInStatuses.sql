﻿  
alter FUNCTION [dbo].[IsInStatuses]  
(  
    @status nvarchar(50),    
    @type nvarchar(50)    
)  
RETURNS bit  
AS  
BEGIN  
-- Declare the return variable here  
DECLARE @flag bit  
SET @flag = 0   
  
if(@type = 'Qual Pending')  
begin  
 select @flag = 1  
 where @status in (  
  'Application Submitted'  
  --, 'New Qualification'  
  ,'Manager Reviewed'  
  ,'Reviewer Reviewed'  
  ,'Request More Info Pending'  
  ,'Request More Info'  
  ,'Request More Info 2'  
  ,'Additional Info Submitted 2'  
  ,'Additional Info Submitted'  
  ,'Reference Reviewed'  
  ,'Financial Reviewed'  
  ,'Reference and Financial Reviewed'  
  ,'OIG Approved'  
  ,'Qualified Pending'  
  ,'OIG Reviewed'  
  ,'OIG Pending'  
  ,'Director Close Pending'  
  ,'PreDeny'  
  )  
end  
  
if(@type = 'Cert Pending')  
begin  
 select @flag = 1  
 where @status in (  
  'Certification Submitted'  
  --,'New Certification'  
  ,'Certification Analyst Assigned'  
  ,'Certification Analyst Reviewed'  
  ,'Request More Certification Info Pending'  
  ,'Request More Certification Info'  
  ,'Additional Certification Info Submitted'  
  ,'MWBE Reviewed'  
  ,'LBE Reviewed'  
  ,'Certification Analyst Recommended'  
  ,'Director Review Pending'  
  ,'Director Reviewed'  
  ,'Request More Certification Info 2'  
  ,'Additional Certification Info Submitted 2'  
  --,'Conditionally Certified'  
  )  
end  
  
if(@type = 'Qual All')  
begin  
 select @flag = 1  
 where @status in (  
  'New Qualification'  
  ,'Application Submitted'  
  ,'Manager Reviewed'  
  ,'Reviewer Reviewed'  
  ,'Request More Info Pending'  
  ,'Request More Info'  
  ,'Additional Info Submitted'  
  ,'Request More Info 2'  
  ,'Additional Info Submitted 2'  
  ,'Reference Reviewed'  
  ,'Financial Reviewed'  
  ,'Reference and Financial Reviewed'  
  ,'OIG Approved'  
  ,'OIG Reviewed'  
  ,'OIG Pending'  
  ,'Qualified Pending'  
  ,'Qualified'  
  ,'PreDeny'  
  ,'Director Close Pending'  
  ,'Director Closed'  
  ,'Inactive'  
  ,'Administratively Closed'  
  ,'Withdrawn'  
  ,'Disqualified'  
  ,'Rescinded'  
  ,'Suspended'  
  ,'Deny'  
  ,'Expired'  
  )  
end  
  
if(@type = 'Cert All')  
begin  
 select @flag = 1  
 where @status in (  
  'New Certification'  
  ,'Certification Submitted'  
  ,'Certification Analyst Assigned'  
  ,'Certification Analyst Reviewed'  
  ,'Request More Certification Info Pending'  
  ,'Request More Certification Info'  
  ,'Additional Certification Info Submitted'  
  ,'MWBE Reviewed'  
  ,'LBE Reviewed'  
  ,'Certification Analyst Recommended'  
  ,'Director Review Pending'  
  ,'Director Reviewed' 
  ,'Certified'  
  ,'Certification Analyst Closed'  
  ,'Certification Closed'  
  ,'Deny'  
  ,'Disqualified'  
  ,'Certification Admin Closed'  
  ,'Withdrawn'  
  ,'Rescinded'  
  ,'Suspended'  
  ,'Decertified'  
  ,'Request More Certification Info 2'  
  ,'Additional Certification Info Submitted 2'  
  ,'Expired'  
  ,'Archived'  
  ,'Conditionally Certified'  
  )  
end  
  
return @flag  
END  
  
  
  
  