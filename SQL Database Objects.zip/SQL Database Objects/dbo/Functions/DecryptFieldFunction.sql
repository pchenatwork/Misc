﻿
--ALTER FUNCTION [dbo].[DecryptField]
--(
--    @xstring nvarchar(500)  
--)
--RETURNS nvarchar(500)
--AS
--BEGIN
---- Declare the return variable here
--DECLARE @mstring nvarchar(500)
--SET @mstring = '' 

--DECLARE @li_check  int
--DECLARE @Flag INT
--	SET @Flag = 1
--WHILE (@Flag <= len(@xstring))
--	BEGIN
--		set @li_check = ASCII(SUBSTRING(@xstring, @Flag, 1)) + @Flag - len(@xstring) - 1
--		if ( @li_check < 0 )
--			set @li_check = @li_check + 127
--		set @mstring = char(@li_check) + @mstring
--		SET @Flag = @Flag + 1
--	END

--return @mstring
--END




CREATE FUNCTION [dbo].[DecryptFieldFunction]
(
	@inputstring nvarchar(500),
    @key nvarchar(500)='2WorldWin8'
)
RETURNS nvarchar(500)
AS
BEGIN
-- Declare the return variable here
declare @inputstringlength int
declare @keylength int
declare @finalkey nvarchar(500)
set @finalkey=''
declare @str_check  int
declare @key_check  int
declare @str_asc nvarchar(500)
set @str_asc= ''
declare @str_test nvarchar(500)
set @str_test = ''
declare @count int
declare @i int
declare @flag INT
declare @returnstring nvarchar(500)
set @returnstring = '' 

if @inputstring=' '
	set @inputstringlength=1
else
	set @inputstringlength=len(@inputstring+'_') -1

if @inputstringlength < 1
	return ''
	
if @key=' '
	set @keylength=1
else
	set @keylength=len(@key+'_') -1

if @keylength < 1
	return ''
	
if (@keylength <@inputstringlength)
	begin
		set @count = ceiling(convert(float, @inputstringlength)/@keylength)
		set @keylength = @keylength * @count
		set @i=1
		while (@i<=@count)
			begin
				set @finalkey = @finalkey + @key
				set @i = @i + 1
			end
			
	end
else
	set @finalkey = @key


set @keylength = @keylength - @keylength%@inputstringlength
set @finalkey = substring(@finalkey, 1, @keylength)


/************************/
--set @count = @keylength/@inputstringlength
--set @flag = 1
--WHILE (@flag <= @inputstringlength)
--	BEGIN
--		set @key_check = 0
--		set @i=1
--		while ( @i <=@count)
--			begin
--				set @key_check = @key_check + ASCII(substring(@finalkey, (@flag + (@i *@inputstringlength -@inputstringlength)), 1))
--				set @i = @i + 1
--			end
			
--		set @str_check =  ASCII(SUBSTRING(@inputstring, @flag, 1)) - @key_check
--		if ( @str_check < 0)
--			begin
--				set @str_check = ASCII(SUBSTRING(@inputstring, @flag, 1)) - @key_check%127
--				if @str_check<0
--					set @str_check = @str_check + 127
--			end
--		set @returnstring  = @returnstring + char(@str_check)
--		SET @flag = @flag + 1
--	END
/************************/



/************************/
set @count = @keylength
set @flag = 1
WHILE (@flag <= @inputstringlength)
	BEGIN
		set @key_check = 0
		set @i=1
		while ( @i <=@count)
			begin
				--if @keylength = @inputstringlength
				--	set @key_check = @key_check + ASCII(substring(@finalkey, (@flag + (@i *@inputstringlength -@inputstringlength)), 1))
				--else
				--	set @key_check = @key_check + ASCII(substring(@finalkey, @i, 1))
									
				set @key_check = @key_check + ASCII(substring(@finalkey, (@flag + (@i *@inputstringlength -@inputstringlength)), 1))					
				set @i = @i + 1
			end
			
		--set @str_asc = ASCII(SUBSTRING(@inputstring, @flag, 1))
		--if @str_asc = 48 
		--	set @str_test = @key_check + @str_asc
		--else
		--	set @str_test = @str_asc
		
		----1
		--if @str_test%127 = 0 
		--	set @str_check = ASCII(SUBSTRING(@inputstring, @flag, 1)) 
		--else				
		--	begin
		--		set @str_check = ASCII(SUBSTRING(@inputstring, @flag, 1)) 
		--		--2
		--		if @str_check = 32 
		--			set @str_check = 32
		--		else
		--			begin
		--				set @str_check = (@key_check - @str_check)
		--				--3
		--				if @str_check % 127=0
		--					set @str_check = ASCII(SUBSTRING(@inputstring, @flag, 1)) 							
		--				else 
		--					begin
		--						--4
		--						if @str_check > 0 
		--							begin 
		--								set @str_check = 127 - 32 - @str_check % 127 
		--								if @str_check < 0  
		--									begin 
		--										set @str_check = 127 + @str_check
		--										if @str_check > 127
		--											set @str_check = @str_check - 32
		--										if (@str_asc > 32 and @str_asc < 58)
		--											set @str_check = @str_check - 32
		--									end
		--								if (@str_check > 0 and @str_check < 32)
		--									set @str_check = 127 - 32 + @str_check
										
		--								if (@str_check > 91 and @str_check < 97)
		--									set @str_check = @str_check + (@str_test- @str_check) 
										
		--							end 
		--						else
		--							begin
		--								set @str_check = ASCII(SUBSTRING(@inputstring, @flag, 1)) - @key_check
		--								if @str_check < 32 
		--									set @str_check = (@str_asc - 32) + (127 - @key_check)
		--							end
		--					end
		--			end 				
		--	end
		
		
		set @str_asc = ASCII(SUBSTRING(@inputstring, @flag, 1))
		if ASCII(SUBSTRING(@inputstring, @flag, 1)) = 130 
			set @str_check = 0 - @key_check
		else
			set @str_check = ASCII(SUBSTRING(@inputstring, @flag, 1)) - @key_check
		
		if (@str_check < 0)
			begin
				if (@str_asc = 130) 
					set @str_check = 0 - @key_check %127
				else
					set @str_check = ASCII(SUBSTRING(@inputstring, @flag, 1))- @key_check %127
				
				if (@str_check < 0 )
					set @str_check = @str_check + 127
					
				--if (@str_check =32 )
				--	set @str_check = 140
					
			end
		
		
		set @returnstring  = @returnstring + char(@str_check)
		SET @flag = @flag + 1
	END
/************************/	
	
return @returnstring

END



