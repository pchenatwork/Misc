﻿CREATE FUNCTION [dbo].[FormatUserName]
(@firstName nvarchar(20), @lastName nvarchar(20))
RETURNS nvarchar(50)

AS

begin

return @lastName + ', ' + @firstName

end






