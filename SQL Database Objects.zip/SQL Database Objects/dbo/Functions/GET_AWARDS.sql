﻿Create FUNCTION [dbo].[GET_AWARDS]
(
	@ARG_TAX varchar(50),
	@datefrom date,
	@dateto date,
	@RangeType varchar(2)
)
RETURNS int
AS
begin

declare @n_ret int

declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime
if(DatePart(Month,getdate()) < 7)
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
	end
else
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
	end

if @datefrom =null or @datefrom ='1/1/1900'
	Begin
		if @RangeType ='F' --Fiscal year
			Begin
				set @datefrom=@firstDayOfYear
				set @dateto=@firstDayOfNextYear
			end
		Else
			Begin
				set @datefrom=DATEADD(Month,-12,GetDate())
				set @dateto=Getdate()
			end

	End
SELECT @n_ret =COUNT (*) 
FROM mv_vas_award
WHERE vendor_id = @ARG_TAX 
AND ((execution_date between @datefrom and  @dateto AND ntp_date IS NULL) 
OR (ntp_date between @datefrom and  @dateto AND execution_date IS NULL)) 

return @n_ret

end
