﻿CREATE FUNCTION [dbo].[OutlookByUserCountBAK20141014]
(
	@userId int,
	@spName nvarchar(50),
	@roleName nvarchar(50)
)
RETURNS int
AS
BEGIN

DECLARE @count int
set @count = 0

declare @userGuid uniqueidentifier
declare @username nvarchar(50)
select @userGuid = u.UserId, @username = au.Username from [User] u, aspnet_users au
	where u.Id = @userId and u.UserId = au.UserId

--#region Other Items
declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime
if(DatePart(Month,getdate()) < 7)
begin
	set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
	set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
end
else
begin
	set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
	set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
end

declare @propertyId_ReviewerId int
set @propertyId_ReviewerId = 10
declare @propertyId_ManagerId int
set @propertyId_ManagerId = 521
declare @propertyId_IOGDecision int
set @propertyId_IOGDecision = 508
declare @propertyId_CertificationAnalyst int
set @propertyId_CertificationAnalyst = 524

-- subcontractor properties
declare @scpropertyId_ReviewerId int
set @scpropertyId_ReviewerId = 1

-- project properties
declare @ppropertyId_CQUReviewer int
set @ppropertyId_CQUReviewer = 45

--#endregion Other Items

--#region Workflow Items
declare @WORKFLOW_QUALIFICATION int
declare @NewPrequalification int
declare @ApplicationSubmitted int
declare @ManagerReviewed int
declare @RequestMoreInfo int
declare @ReferenceReviewed int
declare @FinacialReviewed int
declare @OIGApproved int
declare @Qualified int
declare @PreDeny int
declare @AdministrativelyClosed int
declare @AllReviewed int
declare @RequestMoreInfoPending int
declare @DirectorClosed int
declare @DirectorClosePending int
declare @AdditionalInfoSubmitted int
declare @ReviewerReviewed int
declare @Inactive int
declare @QualifiedPending int
declare @Disqualified int
declare @Withdrawn int
declare @OIGReviewed int
declare @Rescinded int
declare @Suspended int
declare @RequestMoreInfo2 int
declare @AdditionalInfoSubmitted2 int
declare @OIGPending int

declare @WORKFLOW_CERTIFICATION int
declare	@NewCertification int
declare	@CertificationSubmitted int
declare	@CertificationAnalystReviewed int
declare	@RequestMoreCertificationInfoPending int
declare	@RequestMoreCertificationInfo int
declare	@AdditionalCertificationInfoSubmitted int
declare	@MWBEReviewed int
declare	@LBEReviewed int
declare	@CertificationAnalystApproved int
declare	@DirectorApprovalPending int
declare	@Certified int
declare	@CertificationAnalystClosed int
declare	@CertificationClosed int
declare	@DirectorApproved int

Set @WORKFLOW_QUALIFICATION = 1
Set @NewPrequalification = 1
Set @ApplicationSubmitted = 2
Set @ManagerReviewed = 3
Set @RequestMoreInfo = 6
Set @ReferenceReviewed = 7
Set @FinacialReviewed = 29
Set @OIGApproved = 70
Set @Qualified = 71
Set @PreDeny = 72
Set @AdministrativelyClosed = 73
Set @AllReviewed = 74
Set @RequestMoreInfoPending = 80
Set @DirectorClosed = 82
Set @DirectorClosePending = 86
Set @AdditionalInfoSubmitted = 89
Set @ReviewerReviewed = 111
Set @Inactive = 113
Set @QualifiedPending = 124
Set @Disqualified = 244
Set @Withdrawn = 245
Set @OIGReviewed = 246
Set @Rescinded = 257
Set @Suspended = 258
Set @RequestMoreInfo2 = 291
Set @AdditionalInfoSubmitted2 = 292
Set @OIGPending = 488

Set @WORKFLOW_CERTIFICATION = 2
Set @NewCertification =47	 
Set @CertificationSubmitted =48	 
Set @CertificationAnalystReviewed =49	 
Set @RequestMoreCertificationInfoPending =50	 
Set @RequestMoreCertificationInfo =51	 
Set @AdditionalCertificationInfoSubmitted =92	 
Set @MWBEReviewed =93	 
Set @LBEReviewed =94	 
Set @CertificationAnalystApproved =95	 
Set @DirectorApprovalPending = 97	
Set @Certified =98	 
Set @CertificationAnalystClosed =99	 
Set @CertificationClosed = 100	
Set @DirectorApproved =213	
--#endregion Workflow Items

------------ CQU Manager ----------
declare @cquFinancialAnalystCount int
	select @cquFinancialAnalystCount=count(u.id) 
	from 
		aspnet_UsersInRoles ar
		inner join [user] u on ar.UserId=u.UserId
		inner join aspnet_Roles a on ar.RoleId=a.RoleId
	where u.id=@userId
	and a.RoleName='CQU Financial Analyst'


-- (FindItem192) Pending Prequalifications
IF ( @spName = 'FindItem192' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 2 != 2 
	and dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem11) Pending Requalifications
IF ( @spName = 'FindItem11' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 2 = 2 and ss.Status is not null and ss.Status not in (
								'Qualified'
								,'New Qualification'
								,'Administratively Closed'
								,'Inactive'
								,'Withdrawn'
								,'Disqualified'
								,'Rescinded'
								,'Suspended'
								,'Deny'
								,'Expired'
							)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
	
-- (FindItem12) New Assignments (Triage)
IF ( @spName = 'FindItem12' )
BEGIN
	if(dbo.IsUserIdInRole(@userGuid, 'Prequal New Assignment') = 1)
	begin
		Select @count = count(s.Id)
		from Supplier s
			left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
			left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
			left join supplierversion sv on s.Id = sv.SupplierId
		where ss.Status = 'Application Submitted'
		and s.Status & 2 != 2
		and sp.PropertyText is null
		and (sv.status is null or sv.status <> 0)  
		RETURN @count
	end	
	if(dbo.IsUserIdInRole(@userGuid, 'Requal New Assignment') = 1)
	begin
		Select @count = count(s.Id)
		from Supplier s
			left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
			left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
			left join supplierversion sv on s.Id = sv.SupplierId
		where ss.Status = 'Application Submitted'
		and s.Status & 2 = 2
		and sp.PropertyText is null
		and (sv.status is null or sv.status <> 0)  
		RETURN @count
	end
	if(dbo.IsUserIdInRole(@userGuid, 'Small Bus New Assignment') = 1)
	begin
		Select @count = count(s.Id)
		from Supplier s
			left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
			left join SupplierStatus ss1 on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
			left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
			left join supplierversion sv on s.Id = sv.SupplierId
		where ss.Status = 'Application Submitted'
		and ss1.Status = 'Certification Submitted'
		and sp.PropertyText is null
		and (sv.status is null or sv.status <> 0)  
		RETURN @count
	end
	RETURN @count
END

-- (FindItem13) Pending Final Review
IF ( @spName = 'FindItem13' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified Pending'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem14) Files Returned to Reviewer
IF ( @spName = 'FindItem14' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'OIG Reviewed'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem15) Managers Assigned Files
--IF ( @spName = 'FindItem15' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where isnull(ss.Status,'') in ('Application Submitted','OIG Approved')
--	and substring(sp.PropertyText, 1, 50) = @username
--	and (sv.status is null or sv.status <> 0)  
--RETURN @count
--END

-- (FindItem16) Pending Certifications
IF ( @spName = 'FindItem16' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null and ss1.Status not in (
					'Certified'
					,'New Certification'
					,'Admin Closed'
					,'Withdrawn'
					,'Disqualified'
					,'Decertified'
					,'Rescinded'
					,'Suspended'
					,'Deny'
					,'Expired'
					,'Archived'
				)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
------------ End CQU Manager ----------

-------- CQU Reviewer --------------

-- (FindItem17) New Assignments
IF ( @spName = 'FindItem17' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Manager Reviewed'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem18) Total Number of Files Per Reviewer
IF ( @spName = 'FindItem18' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null and ss.Status in ( 'Manager Reviewed'
													,'Reviewer Reviewed'
													,'Request More Info Pending'
													,'Request More Info'
													,'Additional Info Submitted'
													,'Reference Reviewed'
													,'Financial Reviewed'
													,'Reference and Financial Reviewed'
													,'OIG Approved'
													,'Qualified Pending'
													,'OIG Reviewed'
													,'Request More Info 2'
													,'Additional Info Submitted 2'
													)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem19) 30 Day Sent
IF ( @spName = 'FindItem19' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Request More Info'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem20) Unresponsive  to 30 Days
IF ( @spName = 'FindItem20' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Request More Info'
	and s.id in (select supplierid from SupplierStaticQualification where DateDiff(Day,getdate(),V_SD_ADDL_SENT) < -30)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem27) Amended OIG Signoffs
IF ( @spName = 'FindItem27' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s		
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Qualified'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem28) True Requals
IF ( @spName = 'FindItem28' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null and ss.Status in ( 
				'Manager Reviewed'
				,'Reviewer Reviewed'
				,'Request More Info Pending'
				,'Request More Info'
				,'Additional Info Submitted'
				,'Reference Reviewed'
				,'Financial Reviewed'
				,'Reference and Financial Reviewed'
				,'OIG Approved'
				,'Qualified Pending'
				,'OIG Reviewed'
				,'Request More Info 2'
				,'Additional Info Submitted 2'
				)
	and s.Status & 2 = 2
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- !!ONHOLD!!(FindItem29) Priority/Pending Contract
--IF ( @spName = 'FindItem29' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where isnull(ss.Status,'') = 'Qualified'
--	and substring(sp.PropertyText, 1, 50) = @username
--	and (sv.status is null or sv.status <> 0)  
--RETURN @count
--END

-- !!ONHOLD!!(FindItem30) Pending RFC Limited List
--IF ( @spName = 'FindItem30' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where isnull(ss.Status,'') = 'Qualified'
--	and substring(sp.PropertyText, 1, 50) = @username
--	and (sv.status is null or sv.status <> 0)  
--RETURN @count
--END

-- (FindItem31) Pending OIG Signoff
IF ( @spName = 'FindItem31' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') in (
									 'Reference Reviewed'
									,'Financial Reviewed'
									,'Reference and Financial Reviewed'
								   )
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem32) 10 Day Fax
IF ( @spName = 'FindItem32' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Request More Info 2'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem33) Unresponsive to 10 Days
IF ( @spName = 'FindItem33' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Request More Info 2'
	and s.id in (select supplierid from SupplierStaticQualification where DateDiff(Day,getdate(),V_SD_ADDL_SENT2) < -10) -- more than 10 days
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- !!ONHOLD!!(FindItem34) Pending Safety Review
--IF ( @spName = 'FindItem34' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where
--	ubstring(sp.PropertyText, 1, 50) = @username
--	and (sv.status is null or sv.status <> 0)
--RETURN @count
--END

-- (FindItem35) Predenials
IF ( @spName = 'FindItem35' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null and ss.Status = 'PreDeny'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem36) Final Denials
IF ( @spName = 'FindItem36' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Deny'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- !!ONHOLD!!(FindItem37) OIG 15 Day Letters
--IF ( @spName = 'FindItem37' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
--		or 'CQU Director' in (select rolename from @userroles)
--		or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
--	and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
--RETURN @count
--END

-- (FindItem38) OIG Letter of Concern
IF ( @spName = 'FindItem38' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp2 on s.Id = sp2.SupplierId and sp2.PropertyId = @propertyId_IOGDecision
		left join supplierversion sv on s.Id = sv.SupplierId
	where convert(nvarchar(500),sp2.PropertyText) = 'Provide Letter of Concern'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem39) Files with OIG Denials
IF ( @spName = 'FindItem39' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join supplierworkflow sw	on s.id = sw.supplierid and sw.workflowid = @WORKFLOW_CERTIFICATION
		left join workflowhistory wh1	on sw.transactionid = wh1.transactionheaderid 
		left join workflowhistory wh2	on wh1.prevhistoryid = wh2.id
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where wh1.id is not null
	and wh2.id is not null
	and wh1.CurrentNodeId = @DirectorClosePending 
	and wh2.currentnodeid in (@ReferenceReviewed,@FinacialReviewed)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem40) Pending Reference Outreach
IF ( @spName = 'FindItem40' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Reviewer Reviewed'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem41) Pending Financial Review
IF ( @spName = 'FindItem41' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') in ('Reviewer Reviewed','Reference Reviewed')
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- !!ONHOLD!!(FindItem42) Firms Pending SAF References
--IF ( @spName = 'FindItem42' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--				left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
--				left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
--	where ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
--		or 'CQU Director' in (select rolename from @userroles)
--		or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
--	and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
--RETURN @count
--END

-- (FindItem43) Amended Trade Codes
IF ( @spName = 'FindItem43' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem45) Pending Over 1 Million
IF ( @spName = 'FindItem45' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 2 != 2 and ss.Status is not null and ss.Status not in (	
										 'Qualified'
										,'New Qualification'
										,'Administratively Closed'
										,'Inactive'
										,'Withdrawn'
										,'Disqualified'
										,'Rescinded'
										,'Suspended'
										,'Deny'
										,'Expired'							
								  )
	and s.id in(
				select supplierid from suppliercategory sc 
					left join category c on sc.categoryid = c.id
				where 
					((convert(int,c.code) < 31000 or (convert(int,c.code) > 37117 and convert(int,c.code) < 80000) or convert(int,c.code) > 86100) and convert(int,c.code) != 37100)
				and
					isnull(Average,'') = 'over'
			   )
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem46) Firms with Joint Venture
IF ( @spName = 'FindItem46' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where LegalStructure = 'Joi'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem47) Files A/C
IF ( @spName = 'FindItem47' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Administratively Closed'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem48) Files re-opened
IF ( @spName = 'FindItem48' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.id in (select supplierid from SupplierStaticQualification where	V_cd_reopen_date is not null)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- !!ONHOLD!!(FindItem49) Pending Reinstatement
--IF ( @spName = 'FindItem49' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--				left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
--				left join aspnet_users au on convert(varchar(50),sp.PropertyText) = au.username left join [User] u on u.userid = au.userid
--	where ((u.Id = @userId and 'CQU Reviewer' in (select rolename from @userroles))
--		or 'CQU Director' in (select rolename from @userroles)
--		or 'CQU Manager' in (select rolename from @userroles) or 'CQU Financial Analyst' in (select rolename from @userroles))
--	and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
--RETURN @count
--END

-- (FindItem50) Amended-Key People
IF ( @spName = 'FindItem50' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Change in Application'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Change In Application Submitted'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem51) Amended-Qual Over 1 Million
IF ( @spName = 'FindItem51' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Over 1MM Application Submitted'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem52) 60 Day notice Letter
IF ( @spName = 'FindItem52' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where	  isnull(ss.Status,'') = 'Qualified'
	and s.id in (select supplierid from SupplierStaticQualification where DateDiff(Day,getdate(),V_SD_NOTICE_LTR) between 0 and 60)-- within 60 days of expiring
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem53) Firms unreponsive-60 day letter
IF ( @spName = 'FindItem53' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where	  isnull(ss.Status,'') = 'Qualified'							
	and s.id in (select supplierid from SupplierStaticQualification where DateDiff(Day,getdate(),V_SD_PREQUAL_TO) < 0)--more than 3 years from qual date
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem54) Total Number of Files
IF ( @spName = 'FindItem54' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where	  ss2.Status in (	
										 'Manager Reviewed'
										,'Reviewer Reviewed'
										,'Request More Info Pending'
										,'Request More Info'
										,'Additional Info Submitted'
										,'Reference Reviewed'
										,'Financial Reviewed'
										,'Reference and Financial Reviewed'
										,'OIG Approved'
										,'Qualified Pending'
										,'OIG Reviewed'
										,'Request More Info 2'
										,'Additional Info Submitted 2'							
								  )
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
-------- End CQU Reviewer

-------- MWLBE CERTIFICATION -----------------

-- (FindItem55) New Applications Received FYTD
IF ( @spName = 'FindItem55' )
BEGIN
	Select @count = count(distinct s.Id)
	from Supplier s
		left join supplierversion sv on s.Id = sv.SupplierId
		, SupplierStaticCertification ssc
	where s.id = ssc.SupplierId and V_SD_APPL_DATE between @firstDayOfYear and @firstDayOfNextYear
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem56) New Applications Assigned to Certification Analysts for Review
IF ( @spName = 'FindItem56' )
BEGIN
	Select @count = count(distinct s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status in ('Certification Submitted', 'Certification Analyst Assigned')
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem57) Certification Applications Awaiting Assignment to Analyst
IF ( @spName = 'FindItem57' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Certification Submitted'
	and substring(isnull(sp.PropertyText, ''), 1, 50) = ''
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem58) Total Number of Certified Firms
IF ( @spName = 'FindItem58' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s 
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') = 'Certified'
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem59) Total Number of Firms that are Certified and Prequalified 
IF ( @spName = 'FindItem59' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s 
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss1.Status,'') = 'Certified'
	and	  isnull(ss2.Status,'') = 'Qualified'
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem60) Total Number of Firms Pending Certification
IF ( @spName = 'FindItem60' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s 
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1 
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem61) Total Number of Firms that are Pending Certification and Prequalification
IF ( @spName = 'FindItem61' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 1 = 1 and ss1.Status is not null and ss1.Status not in (
				'Certified'
				,'New Certification'
				,'Admin Closed'
				,'Withdrawn'
				,'Disqualified'
				,'Decertified'
				,'Rescinded'
				,'Suspended'
				,'Deny'
				,'Expired'
				,'Archived'
				)
	and	 s.Status &2 = 2 and ss2.Status is not null and ss2.Status not in (
				 'Qualified'
				,'New Qualification'
				,'Administratively Closed'
				,'Inactive'
				,'Withdrawn'
				,'Disqualified'
				,'Rescinded'
				,'Suspended'
				,'Deny'
				,'Expired'
				)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem62) Total Number of Certified Firms that are Pending Prequalification
IF ( @spName = 'FindItem62' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss1.Status,'') = 'Certified'
	and	 s.Status & 2 != 2 and ss2.Status is not null and ss2.Status not in (
					 'Qualified'
					,'New Qualification'
					,'Administratively Closed'
					,'Inactive'
					,'Withdrawn'
					,'Disqualified'
					,'Rescinded'
					,'Suspended'
					,'Deny'
					,'Expired'
					)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem64) Total Number of Recertification Applications Received
IF ( @spName = 'FindItem64' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss1.Status,'') = 'Certification Submitted'
	and s.Status & 1 = 1
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem65) Total Number of Firms Pending Recertification
IF ( @spName = 'FindItem65' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Status & 1 = 1 and ss1.Status is not null and ss1.Status not in (
				'Certified'
				,'New Certification'
				,'Admin Closed'
				,'Withdrawn'
				,'Disqualified'
				,'Decertified'
				,'Rescinded'
				,'Suspended'
				,'Deny'
				,'Expired'
				,'Archived'																				
			)
	--isnull(ss1.Status,'') = 'Certified'
	--and s.id in (select supplierid from SupplierStaticCertification where DateDiff(Day,getdate(),V_sd_exp_date) between 0 and 60 ) -- within 60 days of expiring
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- !!ON HOLD!!	(FindItem66) Priority Certification
--IF ( @spName = 'FindItem66' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
	
--RETURN @count
--END

-- (FindItem67) Total Number of Firms that Certification will Lapsed within 60 days
IF ( @spName = 'FindItem67' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
		, SupplierStaticCertification ssc
	where isnull(ss.Status,'') = 'Certified'
	and s.id = ssc.SupplierId and DateDiff(Day,getdate(),V_sd_exp_date) between -1 and -60  -- has expired within the last 60 days
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem68) Total Number of Firms that Certification will Lapsed within 30 days
IF ( @spName = 'FindItem68' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
		, SupplierStaticCertification ssc
	where isnull(ss.Status,'') = 'Certified'
	and s.id = ssc.SupplierId and DateDiff(Day,getdate(),V_sd_exp_date) between -1 and -30  -- has expired within the last 30 days
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem69) 30 Day Notices Sent
IF ( @spName = 'FindItem69' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem70) 10 Day Fax
IF ( @spName = 'FindItem70' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info 2'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem71) Predenials - Certification and Prequalification
IF ( @spName = 'FindItem71' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss1.Status is not null and ss2.Status is not null
	and   ss2.Status = 'PreDeny'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem72) Firms with OIG Letters of Concern
IF ( @spName = 'FindItem72' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where s.Id in (select supplierid from supplierdocument where type = 'ConcernLetter')
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem73) Conditional Certifications Awaiting Prequalification
IF ( @spName = 'FindItem73' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss1.Status is not null and ss1.Status = 'Director Approved'
	and	  ss2.Status is not null and ss2.Status  in (
			 'Application Submitted'
			,'Manager Reviewed'
			,'Reviewer Reviewed'
			,'Request More Info Pending'
			,'Request More Info'
			,'Additional Info Submitted'
			,'Reference Reviewed'
			,'Financial Reviewed'
			,'Reference and Financial Reviewed'
			,'OIG Approved'
			,'Qualified Pending'
			,'OIG Reviewed'
			,'Request More Info 2'
			,'Additional Info Submitted 2'
			)
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem74) Number of Rejected Firms (Certification/Prequalification)
IF ( @spName = 'FindItem74' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
		left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss1.Status is not null and ss1.Status = 'Admin Closed'
	and	  ss2.Status is not null
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem75) # of Prequalified Firms- Pending Certification
--IF ( @spName = 'FindItem75' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--				left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
--				left join SupplierStatus ss2	on s.Id = ss2.SupplierId and ss2.Typename = 'Supplier Prequalification'
--	where s.Status & 1 != 1 and ss1.Status is not null and ss1.Status not in (
--					 'Certified'
--					,'New Certification'
--					,'Admin Closed'
--					,'Withdrawn'
--					,'Disqualified'
--					,'Decertified'
--					,'Rescinded'
--					,'Suspended'
--					,'Deny'
--					,'Expired'
--					,'Archived'
--					)
--	and	  ss2.Status is not null and ss2.Status = 'Qualified'
--	and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
--RETURN @count
--END

-- !!ON HOLD!!	(FindItem76) Firms with Red Flags - MWLBE Audit flag
--IF ( @spName = 'FindItem76' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-----------------------------------------------

-- !!ON HOLD!!	(FindItem77) Certified Firms Approved SAF
--IF ( @spName = 'FindItem77' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem78) Certified Firms Denied SAF Approval
--IF ( @spName = 'FindItem78' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem79) Certified Firms Pending SAF Approval
--IF ( @spName = 'FindItem79' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- (FindItem120) Certification Information Pending 
IF ( @spName = 'FindItem120' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
				left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
	where isnull(ss.Status,'') in ('Request More Certification Info','Request More Certification Info 2')
	and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
RETURN @count
END

-- !!ONHOLD!!(FindItem121) Certified Firms Pending SAF Approvals
IF ( @spName = 'FindItem121' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- (FindItem123) Firms Pending Recertification 
IF ( @spName = 'FindItem123' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Certification'
	where isnull(ss1.Status,'') = 'Certification Submitted'
	and s.Status & 1 = 1
	and (s.id in (select supplierid from supplierversion where status <> 0) or (select count(1) from supplierversion where supplierid = s.id) = 0) 
RETURN @count
END

-- !!ONHOLD!!(FindItem124) MWLBE Firms Awaiting Audit
IF ( @spName = 'FindItem124' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem125) MWLBE Firms that have been audited
IF ( @spName = 'FindItem125' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- (FindItem130) Total # of Files
IF ( @spName = 'FindItem130' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status is not null
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

----------------- End MWBE Certification -------------------


-- !!ON HOLD!!	(FindItem80) Total Mentor Eligible Firms approved for program - awaiting signed agreement
--IF ( @spName = 'FindItem80' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem81) Total Mentor Eligible firms interview scheduled
--IF ( @spName = 'FindItem81' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem82) Total Mentor Eligible firms interviewed - awaiting program entry dates
--IF ( @spName = 'FindItem82' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem83) Total Mentor Eligible firms interviewed - denied program entry
--IF ( @spName = 'FindItem83' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem84) Total Mentor Eligible firms pending mentor program approval
--IF ( @spName = 'FindItem84' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--	--where
--	RETURN @count
--END

-- !!ON HOLD!!	(FindItem85) Total Mentor Eligible firms signed that interested in participating in Mentor Program
IF ( @spName = 'FindItem85' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem86) Total number of firms in Mentor Program
IF ( @spName = 'FindItem86' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem87) Graduate Mentor Limited List Awaiting Vetting and Approval
IF ( @spName = 'FindItem87' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem88) Mentor Limited List Assigned to Analyst for Vetting
IF ( @spName = 'FindItem88' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem89) Mentor Limited List Awaiting Vetting and Approval
IF ( @spName = 'FindItem89' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem90) Mentor Limited List Vetted - Approved by Senior Director and Submitted to Director of Mentor Program for Approval
IF ( @spName = 'FindItem90' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem91) Mentor Limited List Vetted - Awaiting Approval by Senior Director
IF ( @spName = 'FindItem91' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem92) # Mentor program participants on active bid lists
IF ( @spName = 'FindItem92' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem93) Certified firms pending SAF (Mentor Program eligible)
IF ( @spName = 'FindItem93' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem94) Certified firms that are pending pre-qualification (Mentor Program eligible only)
IF ( @spName = 'FindItem94' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem95) Conditional certifications awaiting pre-qualification (Mentor Program eligible)
IF ( @spName = 'FindItem95' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem96) Current workload for Graduate Mentor Program participants
IF ( @spName = 'FindItem96' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem97) Current workload for Mentor Program participants
IF ( @spName = 'FindItem97' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem98) Firms pending pre-qualification-not certified (Mentor Program eligible only)
IF ( @spName = 'FindItem98' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem99) Firms whose certification will lapse in 30 days (Mentor Program eligible only)
IF ( @spName = 'FindItem99' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem100) Firms with OIG letters of concern (Mentor Program eligible only)
IF ( @spName = 'FindItem100' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem101) List current participants of the Graduate Program
IF ( @spName = 'FindItem101' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem102) List current participants of the Mentor Program
IF ( @spName = 'FindItem102' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem103) Mentor participants that were taken off bid lists
IF ( @spName = 'FindItem103' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem104) Mentor Program participants current bid lists
IF ( @spName = 'FindItem104' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem105) Mentor Program Participants with Negative Project Evaluations
IF ( @spName = 'FindItem105' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem106) Mentor Program participants with negative vedex information
IF ( @spName = 'FindItem106' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem107) Pending  Graduate Mentor Program bid lists
IF ( @spName = 'FindItem107' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem108) Pending Mentor Program bid lists
IF ( @spName = 'FindItem108' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem109) Predenial - certification and pre-qualification (Mentor Program eligible only)
IF ( @spName = 'FindItem109' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem110) Rejected firms - certification and pre-qualification (Mentor Program eligible)
IF ( @spName = 'FindItem110' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem111) Certified firms pending SAF (Mentor Program eligible)
IF ( @spName = 'FindItem111' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem112) Current workload for Mentor Program participants
IF ( @spName = 'FindItem112' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem113) Firms with OIG letters of concern (Mentor Program eligible only)
IF ( @spName = 'FindItem113' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem114) List new participants of the Mentor Program
IF ( @spName = 'FindItem114' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem115) Mentor Program Firms that Bid on Mentor Jobs
IF ( @spName = 'FindItem115' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem116) Mentor Program Firms with Negative Evaluations
IF ( @spName = 'FindItem116' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ON HOLD!!	(FindItem117) Pending Mentor Program bid lists
IF ( @spName = 'FindItem117' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END


-- !!ONHOLD!!(FindItem133) Certified Firms Approved SAF
IF ( @spName = 'FindItem133' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem134) Certified Firms Denied SAF Approval
IF ( @spName = 'FindItem134' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem135) Certified Firms Pending SAF Approval
IF ( @spName = 'FindItem135' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem136) Total Mentor Eligible Firms approved for program - awaiting signed agreement
IF ( @spName = 'FindItem136' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem137) Total Mentor Eligible firms interview scheduled
IF ( @spName = 'FindItem137' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem138) Total Mentor Eligible firms interviewed - awaiting program entry dates
IF ( @spName = 'FindItem138' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem139) Total Mentor Eligible firms interviewed - denied program entry
IF ( @spName = 'FindItem139' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem140) Total Mentor Eligible firms pending mentor program approval
IF ( @spName = 'FindItem140' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem141) Total Mentor Eligible firms signed that interested in participating in Mentor Program
IF ( @spName = 'FindItem141' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

-- !!ONHOLD!!(FindItem142) Total number of firms in Mentor Program
IF ( @spName = 'FindItem142' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
	--where
	RETURN @count
END

----------------------- OIG Management ----------------

-- (FindItem146) Total Pending OIG Signoff
IF ( @spName = 'FindItem146' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
	where isnull(ss.Status,'') in (
									 'Reference Reviewed'
									,'Financial Reviewed'
									,'Reference and Financial Reviewed'
								   )
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem147) Total OIG 15 Day Letters
--IF ( @spName = 'FindItem147' )
--BEGIN
--	Select @count = count(s.Id)
--	from Supplier s
--		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
--		left join supplierversion sv on s.Id = sv.SupplierId
--	where isnull(ss.Status,'') in (
--									 'Reference Reviewed'
--									,'Financial Reviewed'
--									,'Reference and Financial Reviewed'
--								   )
--	and (sv.status is null or sv.status <> 0)  
--RETURN @count
--END

-- (FindItem148) Total OIG Letter of Concern
IF ( @spName = 'FindItem148' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp2 on s.Id = sp2.SupplierId and sp2.PropertyId = @propertyId_IOGDecision
		left join supplierversion sv on s.Id = sv.SupplierId
	where convert(nvarchar(500),sp2.PropertyText) = 'Provide Letter of Concern'
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem149) Total Files with OIG Denials
IF ( @spName = 'FindItem149' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join supplierworkflow sw	on s.id = sw.supplierid and sw.workflowid = @WORKFLOW_CERTIFICATION
		left join workflowhistory wh1	on sw.transactionid = wh1.transactionheaderid 
		left join workflowhistory wh2	on wh1.prevhistoryid = wh2.id
		left join supplierversion sv on s.Id = sv.SupplierId
	where wh1.id is not null
	and wh2.id is not null
	and wh1.CurrentNodeId = @DirectorClosePending 
	and wh2.currentnodeid in (@ReferenceReviewed,@FinacialReviewed)
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem294) Pending True Requal
IF ( @spName = 'FindItem294' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join supplierversion sv on s.Id = sv.SupplierId
		left join SupplierProperty sp2 on s.Id = sp2.SupplierId and sp2.PropertyId = @propertyId_IOGDecision
		left join supplierworkflow sw	on s.id = sw.supplierid and sw.workflowid = @WORKFLOW_QUALIFICATION
		left join workflowhistory wh1	on sw.transactionid = wh1.transactionheaderid 
		left join SupplierStaticQualification sq	on s.id = sq.supplierid 
	where isnull(ss.Status,'') in ( 'OIG Pending', 'Qualified Pending', 'Qualified' )
	and isnull(convert(nvarchar(500), sp2.PropertyText), '') = ''
	and wh1.CurrentNodeId = 488 
	and isnull(sq.V_C_APPR_IG, '') != 'Y'
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem295) Incomplete by OIG
IF ( @spName = 'FindItem295' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'OIG Qualification'
	where isnull(ss.Status,'') in ( 'Incomplete by OIG' )
RETURN @count
END


-- (FindItem296) Resubmission to OIG
IF ( @spName = 'FindItem296' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss		on s.Id = ss.SupplierId and ss.Typename = 'OIG Qualification'
		left join SupplierStatus ss1	on s.Id = ss1.SupplierId and ss1.Typename = 'Supplier Prequalification' 
	where isnull(ss.Status,'') in ( 'Resubmission to OIG' )
	-- Resubmission to OIG for release 3.0
	and isnull(ss1.Status,'')  not in ('Qualified', 'Deny','Withdrawn','Suspended','Qualification Pending','Disqualified','Rescinded','')
	
RETURN @count
END


-- FindItem297-- Review Amended Key People
IF ( @spName = 'FindItem297' )
BEGIN
	Select	@count = count(distinct s.supplierid)
	from	Supplierpersonnel s
	where	isKeyperson='Y'
	--and 	status not in (4,0)
	and status=2
	and		OIGReviewed=2
	
RETURN @count
END


----------------------- End OIG Management ----------------

------------ Qualification Status ----------

-- (FindItem150) Application Submitted
IF ( @spName = 'FindItem150' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Application Submitted'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem151) Manager Reviewed
IF ( @spName = 'FindItem151' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Manager Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem274) Pre Deny
IF ( @spName = 'FindItem274' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'PreDeny'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem152) Request More Info Pending
IF ( @spName = 'FindItem152' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info Pending'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem153) Request More Info
IF ( @spName = 'FindItem153' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem154) Additional Info Submitted
IF ( @spName = 'FindItem154' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Info Submitted'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem155) Request More Info 2
IF ( @spName = 'FindItem155' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info 2'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem156) Additional Info Submitted 2
IF ( @spName = 'FindItem156' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Info Submitted 2'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem157) Reviewer Reviewed
IF ( @spName = 'FindItem157' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join Supplierproperty sp2 on s.id=sp2.supplierid and sp2.propertyid=505
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reviewer Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
		or (@cquFinancialAnalystCount>0 and (exists(select * from suppliercategory sc where sc.supplierid=s.id and sc.Average='over') or substring(sp2.propertytext,1,50)='True') )) --In case of CQU Financial Analyst show all the Reference Reviewed firms as the Financial Analysis is the next Step
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem158) Reference Reviewed
IF ( @spName = 'FindItem158' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reference Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem159) Financial Reviewed
IF ( @spName = 'FindItem159' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Financial Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
	
-- (FindItem160) Reference and Financial Reviewed
IF ( @spName = 'FindItem160' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reference and Financial Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
	
-- (FindItem161) OIG Approved
IF ( @spName = 'FindItem161' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'OIG Approved'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
	
-- (FindItem162) OIG Reviewed
IF ( @spName = 'FindItem162' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'OIG Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem627) OIG Incomplete
IF ( @spName = 'FindItem627' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'OIG Qualification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Incomplete by OIG'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

	
-- (FindItem163) OIG Pending
IF ( @spName = 'FindItem163' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'OIG Pending'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
	
-- (FindItem164) Qualified Pending
IF ( @spName = 'FindItem164' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified Pending'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
	
-- (FindItem165) Qualified
IF ( @spName = 'FindItem165' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem193) Unsubmitted Applications
IF ( @spName = 'FindItem193' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'New Qualification'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END
------------ End Qualification Status ----------

------------ Trade Code Amendments ----------

-- (FindItem628) Amended Trade Code Application Submitted
IF ( @spName = 'FindItem628' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Amended Trade Code Application Submitted'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem629) Manager Reviewed
IF ( @spName = 'FindItem629' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Manager Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem630) Reviewer Reviewed
IF ( @spName = 'FindItem630' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reviewer Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem631) Request More Info
IF ( @spName = 'FindItem631' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Info'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem632) Qualified 
IF ( @spName = 'FindItem632' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Amended Trade Code'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

------------ End Trade Code Amendments ----------

------------ Over 1MM Amendments ----------

-- (FindItem633) Over 1MM Application Submitted
IF ( @spName = 'FindItem633' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Over 1MM Application Submitted'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem634) Manager Reviewed
IF ( @spName = 'FindItem634' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Manager Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem635) Reference Reviewed
IF ( @spName = 'FindItem635' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reference Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem636) Finacial Reviewed
IF ( @spName = 'FindItem636' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Finacial Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem637) Reference and Finacial Reviewed
IF ( @spName = 'FindItem637' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reference and Finacial Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem638) Reviewer Reviewed
IF ( @spName = 'FindItem638' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Reviewer Reviewed'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem639) Qualified
IF ( @spName = 'FindItem639' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Qualification Over 1MM'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ReviewerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ManagerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Qualified'
	and ((@userId = 99991 and substring(isnull(sp1.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

------------ End Over 1MM Amendments ----------


------------ Certification Status ----------
-- (FindItem166) Certification Submitted
IF ( @spName = 'FindItem166' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certification Submitted'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem167) Certification Analyst Assigned
IF ( @spName = 'FindItem167' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certification Analyst Assigned'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem168) Request More Certification Info Pending
IF ( @spName = 'FindItem168' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info Pending'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem169) Request More Certification Info
IF ( @spName = 'FindItem169' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem170) Additional Certification Info Submitted
IF ( @spName = 'FindItem170' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Certification Info Submitted'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem171) Request More Certification Info 2
IF ( @spName = 'FindItem171' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Request More Certification Info 2'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem172) Additional Certification Info Submitted 2
IF ( @spName = 'FindItem172' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Additional Certification Info Submitted 2'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem173) Certification Analyst Reviewed
IF ( @spName = 'FindItem173' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certification Analyst Reviewed'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem174) MWBE Reviewed
IF ( @spName = 'FindItem174' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'MWBE Reviewed'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem175) LBE Reviewed
IF ( @spName = 'FindItem175' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'LBE Reviewed'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem176) Certification Analyst Approved
IF ( @spName = 'FindItem176' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certification Analyst Approved'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem177) Director Approval Pending
IF ( @spName = 'FindItem177' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Director Approval Pending'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem178) Director Approved
IF ( @spName = 'FindItem178' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Director Approved'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem179) Conditionally Certified
IF ( @spName = 'FindItem179' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Conditionally Certified'
	and substring(sp.PropertyText, 1, 50) = @username
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem180) Certified
IF ( @spName = 'FindItem180' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'Certified'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

-- (FindItem194) Unsubmitted Applications
IF ( @spName = 'FindItem194' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where ss.Status = 'New Certification'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '')
		or (substring(sp.PropertyText, 1, 50) = @username or substring(sp.PropertyText, 1, 50) = @username))
	and (sv.status is null or sv.status <> 0)  
RETURN @count
END

------------ End Certification Status ----------

------------ CQU & BDD Aging ----------
-- (FindItem181) CQU Aging 0 - 3 Months
IF ( @spName = 'FindItem181' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between DateAdd(month, -3, getdate()) and getdate())
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem182) CQU Aging 3 - 6 Months
IF ( @spName = 'FindItem182' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between DateAdd(month, -6, getdate()) and DateAdd(month, -3, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem183) CQU Aging 6 - 9 Months
IF ( @spName = 'FindItem183' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between DateAdd(month, -9, getdate()) and DateAdd(month, -6, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem184) CQU Aging 9 - 12 Months
IF ( @spName = 'FindItem184' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between DateAdd(month, -12, getdate()) and DateAdd(month, -9, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem185) CQU Aging 12 Months and more
IF ( @spName = 'FindItem185' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Prequalification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_ManagerId
		left join SupplierProperty sp1 on s.Id = sp1.SupplierId and sp1.PropertyId = @propertyId_ReviewerId
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Qual Pending') = 1
	and (substring(sp.PropertyText, 1, 50) = @username or substring(sp1.PropertyText, 1, 50) = @username)
	and s.id in (select supplierid from SupplierStaticQualification where V_SD_PREQ_RCVD 
		between '01/01/1901' and DateAdd(month, -12, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem186) BDD Aging 0 - 3 Months
IF ( @spName = 'FindItem186' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between DateAdd(month, -3, getdate()) and getdate())
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem187) BDD Aging 3 - 6 Months
IF ( @spName = 'FindItem187' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between DateAdd(month, -6, getdate()) and DateAdd(month, -3, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem188) BDD Aging 6 - 9 Months
IF ( @spName = 'FindItem188' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between DateAdd(month, -9, getdate()) and DateAdd(month, -6, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem189) BDD Aging 9 - 12 Months
IF ( @spName = 'FindItem189' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between DateAdd(month, -12, getdate()) and DateAdd(month, -9, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

-- (FindItem190) BDD Aging 12 Months and more
IF ( @spName = 'FindItem190' )
BEGIN
	Select @count = count(s.Id)
	from Supplier s
		left join SupplierStatus ss	on s.Id = ss.SupplierId and ss.Typename = 'Supplier Certification'
		left join SupplierProperty sp on s.Id = sp.SupplierId and sp.PropertyId = @propertyId_CertificationAnalyst
		left join supplierversion sv on s.Id = sv.SupplierId
	where dbo.IsInStatuses(ss.Status, 'Cert Pending') = 1
	and substring(sp.PropertyText, 1, 50) = @username
	and s.id in (select supplierid from SupplierStaticCertification where V_SD_APPL_DATE 
		between '01/01/1901' and DateAdd(month, -12, getdate()))
	and (sv.status is null or sv.status <> 0)   
RETURN @count
END

IF @spName = 'FindPendingReleaseEvaluation'
BEGIN
	Select @count = count(Id)
	from Scorecard
	Where UserId = @userId and Status = 1

	RETURN @count
END

IF @spName = 'FindToBeEvaluatedEvaluation'
BEGIN
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status in (0, 1, 3)
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.SupervisorType = @roleName

	RETURN @count
END

IF @spName = 'FindPendingEvaluation'
BEGIN
	-- Evaluator
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.UserId = @userId and i.Status in (0, 1, 3)
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.UserType = @roleName

	-- Supervisor (Overdue)
	Select @count = @count + count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status in (8)
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.SupervisorType = @roleName

	-- Supervisor (Declined)
	Select @count = @count + count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status in (2)
	and ((s.Type != 'Mentor A' and datediff(day, s.ReleaseDate, getdate()) <= 14)
		or (s.Type = 'Mentor A' and datediff(day, s.CreateDate, getdate()) <= 14))
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.SupervisorType = @roleName
	
	-- Unassigned HazMat Phase
	Select @count = @count + count(Id)
	from Scorecard
	Where UserId = @userId and Status = 2 and CategoryId = 0 and Type in ('HazMat','Non-Hazmat')

	RETURN @count
END

IF @spName = 'FindOverdueEvaluation'
BEGIN
	-- Evaluator
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.UserId = @userId and i.Status in (8, 9)
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.UserType = @roleName

	-- Supervisor
	Select @count = @count + count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status = 2
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and ((s.Type != 'Mentor A'
		and datediff(day, s.ReleaseDate, getdate()) > 14
		and datediff(day, s.ReleaseDate, getdate()) <= 21)
		or (s.Type = 'Mentor A'
		and datediff(day, s.CreateDate, getdate()) > 14
		and datediff(day, s.CreateDate, getdate()) <= 21))
	and i.SupervisorType = @roleName

	-- Supervisor
	Select @count = @count + count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status = 9
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.SupervisorType = @roleName

	RETURN @count
END

IF @spName = 'FindPendingApprovalEvaluation'
BEGIN
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status = 5
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.SupervisorType = @roleName
	and s.CloseDate > getdate()
	
			
	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Status = 44 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Hazmat')
		and u.UserType in ('IEH Deputy Director')
		and u.UserType = @roleName
		
	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Status = 44 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Non-Hazmat')
		and u.UserType in ('IEH Manager')
		and u.UserType = @roleName

	RETURN @count
END

IF @spName = 'FindRejectedToEvaluation'
BEGIN
	-- Supervisor
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.SupervisorId = @userId and i.Status = 7
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.SupervisorType = @roleName
	and s.CloseDate > getdate()

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status = 37
	and i.UserType = @roleName and i.UserType = 'Design Manager'
	
	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status = 38
	and i.UserType = @roleName and i.UserType = 'Deputy Director'

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status = 39
	and i.UserType = @roleName and i.UserType = 'Director'

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status = 24
	and i.UserType = @roleName and i.UserType in ('Chief Project Officer',
		'Bronx CPO', 'Brooklyn CPO', 'Manhattan CPO', 'Queens CPO', 'Staten Island CPO')

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status = 33
	and i.UserType = @roleName and i.UserType = 'VP for Construction Mgmt'

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status = 43
	and i.UserType = @roleName and i.UserType = 'IEH Hygienist C'

	RETURN @count
END

IF @spName = 'FindRejectedEvaluation'
BEGIN
	-- Evaluator
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.UserId = @userId and i.Status = 7
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.UserType = @roleName
	and s.CloseDate > getdate()

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status in (37, 38, 39)
	and i.UserType = 'Design Project Manager'
	and i.UserType = @roleName

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardUser i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status in (33)
	and i.UserType in ('Chief Project Officer',
		'Bronx CPO', 'Brooklyn CPO', 'Manhattan CPO', 'Queens CPO', 'Staten Island CPO')
	and i.UserType = @roleName

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status in (29, 33)
	and i.UserType = 'Senior Director of BDD'
	and i.UserType = @roleName

	-- Reviewer
	Select @count = @count + count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.UserId = @userId
	and i.ScorecardId = s.Id and s.Status in (43)
	and i.UserType = 'IEH Hygienist B'
	and i.UserType = @roleName

	RETURN @count
END

IF @spName = 'FindDeclinedEvaluation'
BEGIN
	-- Evaluator
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.UserId = @userId and i.Status = 2
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and i.UserType = @roleName
	and ((s.Type != 'Mentor A' and datediff(day, s.ReleaseDate, getdate()) <= 21)
		or (s.Type = 'Mentor A' and datediff(day, s.CreateDate, getdate()) <= 21))

	RETURN @count
END

IF @spName = 'FindPendingReviewEvaluation'
BEGIN
	Select @count = count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 4 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Capacity', 'CIP')
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
		and u.UserType = 'Design Project Manager'
		and u.UserType = @roleName
		
	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity', 'CIP') and s.Status = 4
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
		and u.UserType = 'Design Manager'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity', 'CIP') and s.Status = 5
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
		and u.UserType = 'Design Manager'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity') and s.Status in (4, 5)
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
		and u.UserType = 'Deputy Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity') and s.Status = 7
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
		and u.UserType = 'Deputy Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity') and s.Status in (4, 5, 7, 8)
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 16
		and u.UserType = 'Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity') and s.Status = 8
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 16
		and u.UserType = 'Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity') and s.Status = 12
		and s.Id = u.ScorecardId and u.UserId = @userId
		and u.UserType in ('Director')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('CIP') and s.Status = 12
		and s.Id = u.ScorecardId and u.UserId = @userId
		and u.UserType in ('Deputy Director')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 4 and s.Id = u.ScorecardId
		and s.Type in ('CCFU') and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
		and u.UserType = 'Operations Supervisor'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type = 'CCFU' and s.Status = 4 
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
		and u.UserType in ('Operations Director')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type = 'CCFU' and s.Status = 16 
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
		and u.UserType in ('Operations Director')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 2 and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) <= 4
		and s.Type in ('Mentor A Contract')
		and u.UserType in ('Chief Project Officer',
			'Bronx CPO', 'Brooklyn CPO', 'Manhattan CPO', 'Queens CPO', 'Staten Island CPO')
		and u.UserType = @roleName
		and isnull(u.Status, 0) = 0
		
	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 2 and s.Id = u.ScorecardId and u.UserId = @userId
			and datediff(day, s.CreateDate, getdate()) > 4
			and datediff(day, s.CreateDate, getdate()) <= 8
		and s.Type in ('Mentor A Contract')
		and u.UserType = 'VP for Construction Mgmt'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 22 and s.Id = u.ScorecardId and u.UserId = @userId
			and datediff(day, s.CreateDate, getdate()) <= 8
		and s.Type in ('Mentor A Contract')
		and u.UserType = 'VP for Construction Mgmt'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type = 'Mentor A Contract' and s.Status in (12, 36)
		and s.Id = u.ScorecardId and u.UserId = @userId
		and u.UserType in ('VP for Construction Mgmt')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 4 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Mentor B')
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
		and u.UserType in ('VP for Construction Mgmt')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 25 and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.VPCMApprovalDate, getdate()) <= 4
		and s.Type in ('Mentor B')
		and u.UserType in ('VP of Admin')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 12 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Mentor B')
		and u.UserType in ('VP for Construction Mgmt')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	Where s.Status = 2 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Project', 'Contract')
		and datediff(day, s.CreateDate, getdate()) <= 4
		and u.UserType = 'Design Project Manager'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status = 2
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) > 4
		and datediff(day, s.CreateDate, getdate()) <= 8
		and u.UserType = 'Design Manager'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status = 5
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) <= 8
		and u.UserType = 'Design Manager'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status in (2, 5)
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) > 8
		and datediff(day, s.CreateDate, getdate()) <= 12
		and u.UserType = 'Deputy Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status = 26
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) <= 12
		and u.UserType = 'Deputy Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status in (2, 5, 26)
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) > 12
		and datediff(day, s.CreateDate, getdate()) <= 16
		and u.UserType = 'Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status = 27
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) <= 16
		and u.UserType = 'Director'
		and u.UserType = @roleName

	Select @count = @count + count(Id)
	from Scorecard
	where Status = 13 and Type in ('Contract') and dbo.IsUserInRole(@userId, 'VP for Construction Mgmt') = 1
		and @roleName = 'VP for Construction Mgmt'

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Status = 14 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Contract')
		and u.UserType in ('Director')
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Hazmat', 'Non-Hazmat') and s.Status = 4
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
		and u.UserType = 'IEH Hygienist C'
		and u.UserType = @roleName

	--Select @count = @count + count(s.Id)
	--from Scorecard s, ScorecardUser u
	--where s.Status = 42 and s.Id = u.ScorecardId and u.UserId = @userId
	--	and s.Type in ('Hazmat')
	--	and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
	--	and u.UserType in ('IEH Deputy Director')
	--	and u.UserType = @roleName

	--Select @count = @count + count(s.Id)
	--from Scorecard s, ScorecardUser u
	--where s.Status = 42 and s.Id = u.ScorecardId and u.UserId = @userId
	--	and s.Type in ('Non-Hazmat')
	--	and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
	--	and u.UserType in ('IEH Manager')
	--	and u.UserType = @roleName
		
	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Status = 4 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Hazmat Contract')
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
		and u.UserType in ('IEH Deputy Director')
		and u.UserType = @roleName
		
	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Status = 4 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Non-Hazmat Contract')
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
		and u.UserType in ('IEH Manager')
		and u.UserType = @roleName
	
	RETURN @count
END

IF @spName = 'FindOverdueReviewEvaluation'
BEGIN
	Select @count = count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Capacity', 'CIP') and s.Status = 4
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType = 'Design Project Manager'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Capacity', 'CIP') and s.Status in (4, 5)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
		and u.UserType = 'Design Manager'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Capacity') and s.Status in (4, 5, 7)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
		and u.UserType in ('Deputy Director')
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Capacity') and s.Status in (4, 5, 7, 8)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 16
		and u.UserType in ('Director')
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('CCFU') and s.Status = 4
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType = 'Operations Supervisor'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('CCFU') and s.Status in (4, 16)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
		and u.UserType = 'Operations Director'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Mentor A Contract') and s.Status = 2
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.CreateDate, getdate()) > 4
		and u.UserType in ('Chief Project Officer',
			'Bronx CPO', 'Brooklyn CPO', 'Manhattan CPO', 'Queens CPO', 'Staten Island CPO')
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Mentor A Contract') and s.Status in (2, 22)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.CreateDate, getdate()) > 8
		and u.UserType = 'VP for Construction Mgmt'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Mentor B') and s.Status = 4
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType = 'VP for Construction Mgmt'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Mentor B') and s.Status = 25
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.VPCMApprovalDate, getdate()) > 4
		and u.UserType = 'VP of Admin'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Project', 'Contract') and s.Status = 2
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.CreateDate, getdate()) > 4
		and u.UserType = 'Design Project Manager'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Project', 'Contract') and s.Status in (2, 5)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.CreateDate, getdate()) > 8
		and u.UserType = 'Design Manager'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Project', 'Contract') and s.Status in (2, 5, 26)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.CreateDate, getdate()) > 12
		and u.UserType in ('Deputy Director')
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('Project', 'Contract') and s.Status in (2, 5, 26, 27)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.CreateDate, getdate()) > 16
		and u.UserType in ('Director')
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Hazmat', 'Non-Hazmat') and s.Status = 4
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType = 'IEH Hygienist C'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Hazmat') and s.Status = 42
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType = 'IEH Manager'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('Non-Hazmat') and s.Status = 42
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType = 'IEH Deputy Director'
		and u.UserType = @roleName
		and u.Status = 0

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Status = 4 and s.Id = u.ScorecardId and u.UserId = @userId
		and s.Type in ('Non-Hazmat Contract', 'Hazmat Contract')
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
		and u.UserType in ('IEH Deputy Director')
		and u.UserType = @roleName
	
	RETURN @count
END

IF @spName = 'FindPendingCIPReviewEvaluation'
BEGIN
	Select @count = count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('CIP') and s.Status in (4, 5)
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
		and u.UserType = 'Deputy Director'
		and u.UserType = @roleName

	Select @count = @count + count(s.Id)
	from Scorecard s, ScorecardUser u
	where s.Type in ('CIP') and s.Status = 7
		and s.Id = u.ScorecardId and u.UserId = @userId
		and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
		and u.UserType = 'Deputy Director'
		and u.UserType = @roleName

	RETURN @count
END

IF @spName = 'FindOverdueCIPReviewEvaluation'
BEGIN
	Select @count = count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Type in ('CIP') and s.Status in (4, 5, 7)
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
		and u.UserType in ('Deputy Director')
		and u.UserType = @roleName
		and u.Status = 0

	RETURN @count
END

IF @spName = 'FindInProgressEvaluation'
BEGIN
	-- Evaluator
	Select @count = count(t.Id)
	From
	(
		Select s.Id
		from ScorecardInvitee i, Scorecard s
		where i.UserId = @userId and 
		(
			(i.Status in (4, 6) and s.Type != 'Mentor A')
			 or (i.Status = 5)
		)
		and i.ScorecardId = s.Id and s.Status not in (1, 18, 19, 20, 98, 99)
		and i.UserType = @roleName

		union

		-- Supervisor
		Select s.Id
		from ScorecardInvitee i, Scorecard s
		where i.SupervisorId = @userId and 
		(
			(i.Status in (4, 6) and s.Type != 'Mentor A')
			or (i.Status = 5)
		)
		and i.ScorecardId = s.Id and s.Status not in (1, 18, 19, 20, 98, 99)
		and i.SupervisorType = @roleName

		union

		-- Reviewer
		Select s.Id
		from ScorecardUser i, Scorecard s
		where i.UserId = @userId and i.Status = 1
		and i.ScorecardId = s.Id and s.Status not in (1, 2, 3, 18, 19, 20, 98, 99)
		and i.UserType = @roleName
		and s.Type != 'Mentor A Contract'

		union

		-- Reviewer
		Select s.Id
		from ScorecardUser i, Scorecard s
		where i.UserId = @userId and i.Status = 1
		and i.ScorecardId = s.Id and s.Status not in (1, 3, 18, 19, 20, 98, 99)
		and i.UserType = @roleName
		and s.Type = 'Mentor A Contract'
	) t

	RETURN @count
END

IF @spName = 'FindNotNotifiedEvaluation'
BEGIN
	Select @count = count(s.Id)
	from Scorecard s, ScorecardUser u 
	where s.Status = 19 and s.FinalUserId = @userId
		and s.Id = u.ScorecardId and u.UserId = @userId 
		and u.UserType = @roleName

	RETURN @count
END
------------ Prequal Limited List Status ----------

-- (FindItem265) New List
IF ( @spName = 'FindItem265' )
BEGIN
	Select @count = count(distinct [transm_number])
	from mv_cms_rfc
	where c_appr_cpo = @Username
		and l_mentor = 0 and isnull(m_topackage_amt, 0) > 1000000
		and [transm_number] not in (Select TransNumber From RfdProject Where Status != 98)
RETURN @count
END

-- (FindItem213) New Project
IF ( @spName = 'FindItem213' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 0 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem214) Ready For Review
IF ( @spName = 'FindItem214' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 4 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem215) Pending CPO Approval
IF ( @spName = 'FindItem215' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 1 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem216) Pending VP for Construction Mgmt Approval
IF ( @spName = 'FindItem216' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 2 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem217) Pending VP of Admin Approval
IF ( @spName = 'FindItem217' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 3 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem218) Info Ready
IF ( @spName = 'FindItem218' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 6 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem219) Request More Info
IF ( @spName = 'FindItem219' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 5 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem220) Reviewer Reviewed
IF ( @spName = 'FindItem220' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 7 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem221) Question From Manager
IF ( @spName = 'FindItem221' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 8 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem222) Manager Approved
IF ( @spName = 'FindItem222' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 9 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem223) Question From Director
IF ( @spName = 'FindItem223' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 10 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END


-- (FindItem224) Director Approved
IF ( @spName = 'FindItem224' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 11 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem225) VP of Admin Approved
IF ( @spName = 'FindItem225' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 12 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem226) Chief Project officer Approved
IF ( @spName = 'FindItem226' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 13 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem227) VP for Construction Mgmt Approved
IF ( @spName = 'FindItem227' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 14 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem228) General Counsel Approved
IF ( @spName = 'FindItem228' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 15 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem229)President Approved
IF ( @spName = 'FindItem229' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 16 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem230)Approved
IF ( @spName = 'FindItem230' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 17 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
		and IsFinal = 'Y' and SolicitSeq > 0
RETURN @count
END

-- (FindItem231)Pending Refresh
IF ( @spName = 'FindItem231' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 25 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem232)Refreshed
IF ( @spName = 'FindItem232' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 26 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem233)Cancelled
IF ( @spName = 'FindItem233' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 98 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem234)Inactive
IF ( @spName = 'FindItem234' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 100 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem262)Approved Pending Final RFC
IF ( @spName = 'FindItem262' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 17 and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
		and isnull(IsFinal, '') != 'Y' and isnull(SolicitSeq, 0) = 0
RETURN @count
END

-- (FindItem263)RFC Approved
IF ( @spName = 'FindItem263' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where (p.Status = 26 or p.Status = 27) and ProjectType = 'Prequal'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

------------ End Prequal Limited List Status ----------

------------ Mentor Limited List Status ----------

-- (FindItem266) New List
IF ( @spName = 'FindItem266' )
BEGIN
	Select @count = count(distinct [transm_number])
	from mv_cms_rfc
	where c_appr_cpo = @Username
		and (l_mentor = 1 or (l_mentor = 0 and isnull(m_topackage_amt, 0) <= 1000000))
		and [transm_number] not in (Select TransNumber From RfdProject Where Status != 98)
RETURN @count
END

-- (FindItem235) New Project
IF ( @spName = 'FindItem235' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 0 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem236) Construction management Selected
IF ( @spName = 'FindItem236' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 18 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END


-- (FindItem237) Info Ready
IF ( @spName = 'FindItem237' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 6 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END


-- (FindItem238) Criteria Pending Approval
IF ( @spName = 'FindItem238' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 20 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem239) Pending Director of Mentor Program Approval
IF ( @spName = 'FindItem239' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 21 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem240) Pending CPO Approval
IF ( @spName = 'FindItem240' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 1 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem241) Pending Vetting
IF ( @spName = 'FindItem241' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 22 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem242) Analyst Reviewed
IF ( @spName = 'FindItem242' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 23 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END


-- (FindItem243) BDD Director Approved
IF ( @spName = 'FindItem243' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 24 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem244) Approved
IF ( @spName = 'FindItem244' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 17 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem245) Closed
IF ( @spName = 'FindItem245' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 99 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

-- (FindItem246) Inactive
IF ( @spName = 'FindItem246' )
BEGIN
	Select @count = count(p.Id)
	from RfdProject p
	where p.Status = 100 and ProjectType like '%Mentor%'
		and p.ChiefProjectOfficer = @Username
RETURN @count
END

------------ End Mentor Limited List Status ----------

------------ SAF Status ----------

-- (FindItem267) New Subcontractor
IF ( @spName = 'FindItem267' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 0
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem268) Subcontractor VAS Prepared
IF ( @spName = 'FindItem268' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 4
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem275) Subcontractor Manager Reviewed
IF ( @spName = 'FindItem275' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 5
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem276) Subcontractor Request More Info
IF ( @spName = 'FindItem276' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 7
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem277) Subcontractor Additional Info Submitted
IF ( @spName = 'FindItem277' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 8
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem269) Subcontractor Reviewer Vetted
IF ( @spName = 'FindItem269' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 6
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem270) Subcontractor CQU Approved
IF ( @spName = 'FindItem270' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 11
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem271) Subcontractor OIG Reviewed
IF ( @spName = 'FindItem271' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 12
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem279) Subcontractor Insurance Pending
IF ( @spName = 'FindItem279' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 23
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem272) Subcontractor Pending
IF ( @spName = 'FindItem272' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 17
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem278) Pending Insurance Certificate
IF ( @spName = 'FindItem278' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status in (17, 13)
	and isnull(IsUpload, '') != 'Y' 
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem273) Subcontractor Approved
IF ( @spName = 'FindItem273' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 13
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
RETURN @count
END

-- (FindItem758) Subcontractor OIG Deny
IF ( @spName = 'FindItem758' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 14
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
END

-- (FindItem729) Subcontractor OIG Denied
IF ( @spName = 'FindItem729' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
	where s.status = 20
	and (( @userId = 1 and s.type = '' and s.IsMentor = 'N')
		or ( @userId = 2 and s.type = '' and s.IsMentor = 'Y')
		or ( @userId = 3 and s.type = 'RS-1' and s.IsMentor = 'N')
		or ( @userId = 4 and s.type = 'RS-1' and s.IsMentor = 'Y'))
END

------------ End SAF Status ----------

------------ Start Mentor SAF ----------

-- (FindItem647) Mentor SAF - New Subcontractor'
IF ( @spName = 'FindItem647' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 0
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
		
		
RETURN @count
END
-- (FindItem648) Mentor SAF - Subcontractor VAS Prepared'
IF ( @spName = 'FindItem648' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 4
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem649) Mentor SAF - Subcontractor Reviewer Vetted'
IF ( @spName = 'FindItem649' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 6
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem650) Mentor SAF - Subcontractor CQU Approved'
IF ( @spName = 'FindItem650' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 11
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem651) Mentor SAF - Subcontractor OIG Reviewed'
IF ( @spName = 'FindItem651' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 12
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem652) Mentor SAF - Subcontractor Pending'
IF ( @spName = 'FindItem652' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 17
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem653) Mentor SAF - Subcontractor Approved'
IF ( @spName = 'FindItem653' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 13
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem654) Mentor SAF - Subcontractor Manager Reviewed'
IF ( @spName = 'FindItem654' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 5
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem655) Mentor SAF - Subcontractor Request More Info'
IF ( @spName = 'FindItem655' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 7
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem656) Mentor SAF - Subcontractor Additional Info Submitted'
IF ( @spName = 'FindItem656' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 8
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem657) Mentor SAF - Pending Insurance Certificate'
IF ( @spName = 'FindItem657' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status in (17, 13)
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem658) Mentor SAF - Subcontractor Insurance Pending'
IF ( @spName = 'FindItem658' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 23
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END

-- (FindItem731) Mentor SAF - Subcontractor OIG Denied'
IF ( @spName = 'FindItem731' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 20
	and s.IsMentor = 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))

END

------------ End Mentor SAF ----------


------------ Start Prime SAF ----------


-- (FindItem659) Prime SAF - New Subcontractor'
IF ( @spName = 'FindItem659' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 0
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem660) Prime SAF - Subcontractor VAS Prepared'
IF ( @spName = 'FindItem660' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 4
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem661) Prime SAF - Subcontractor Reviewer Vetted'
IF ( @spName = 'FindItem661' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 6
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem662) Prime SAF - Subcontractor CQU Approved'
IF ( @spName = 'FindItem662' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 11
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem663) Prime SAF - Subcontractor OIG Reviewed'
IF ( @spName = 'FindItem663' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 12
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem664) Prime SAF - Subcontractor Pending'
IF ( @spName = 'FindItem664' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 17
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem665) Prime SAF - Subcontractor Approved'
IF ( @spName = 'FindItem665' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 13
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem666) Prime SAF - Subcontractor Manager Reviewed'
IF ( @spName = 'FindItem666' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 5
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem667) Prime SAF - Subcontractor Request More Info'
IF ( @spName = 'FindItem667' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 7
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem668) Prime SAF - Subcontractor Additional Info Submitted'
IF ( @spName = 'FindItem668' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 8
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem669) Prime SAF - Pending Insurance Certificate'
IF ( @spName = 'FindItem669' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status in (17, 13)
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END
-- (FindItem670) Prime SAF - Subcontractor Insurance Pending'
IF ( @spName = 'FindItem670' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 23
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))
RETURN @count
END

-- (FindItem730) Prime SAF - Subcontractor OIG Denied'
IF ( @spName = 'FindItem730' )
BEGIN
	Select @count = count(s.Id)
	from Subcontractor s
		left join SubcontractorProperty sp on s.Id = sp.SubcontractorId and PropertyId = @scpropertyId_ReviewerId
	where s.status = 20
	and s.IsMentor != 'Y'
	and ((@userId = 99991 and substring(isnull(sp.PropertyText, ''), 1, 50) = '') or (substring(sp.PropertyText, 1, 50) = @username))

END


------------ End Prime SAF ----------


------------ SUP Status ----------

-- (FindItem740) New Plan
IF ( @spName = 'FindItem740' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 0
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem741) Plan Submitted
IF ( @spName = 'FindItem741' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 1
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem742) Pending Plan Waiver Request
IF ( @spName = 'FindItem742' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 3
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem743)Waiver Request More Info
IF ( @spName = 'FindItem743' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 7
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem744)Plan Compliance Analyst Reviewed with Waiver
IF ( @spName = 'FindItem744' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 4
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem745) Plan Rejected
IF ( @spName = 'FindItem745' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 11
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem746)Waiver More Info Submitted
IF ( @spName = 'FindItem746' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 8
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem747)Plan Compliance Analyst Reviewed
IF ( @spName = 'FindItem747' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 2
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem748)Plan Compliance Manager Reviewed with Waiver
IF ( @spName = 'FindItem748' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 5
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem749)Plan Compliance Verified
IF ( @spName = 'FindItem749' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 6
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

---Batch get Percentage Completion 
declare @temp2 table
(
	PlanId int,
	PercentageCompletion float
)
insert into @temp2
(	
	PlanId,
	PercentageCompletion
)
select 
	p.Id,
	v.pct_by_contract
From 
	MV_SOLICIT_CONTRACT v
inner join 
	[plan] p	
on 
	isnull(c_contract, me_contract) = p.ContractNo
	and isnull(v.n_solicit_seq, 0) = isnull(p.solicitSeq, 0)
where 
	p.status in (6)


-- (FindItem750)Plan Phase 1 Completed
IF ( @spName = 'FindItem750' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s, @temp2 t
	where s.Id = t.PlanId 
		and isnull(t.PercentageCompletion, 0)>=35
		and isnull(t.PercentageCompletion, 0)<50
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem751)Plan Phase 2 Completed
IF ( @spName = 'FindItem751' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s, @temp2 t
	where s.Id = t.PlanId 
		and isnull(t.PercentageCompletion, 0)>=50
		and isnull(t.PercentageCompletion, 0)<90
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
RETURN @count
END

-- (FindItem752)Plan Phase 3 Completed
IF ( @spName = 'FindItem752' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s, @temp2 t
	where s.Id = t.PlanId 
		and isnull(t.PercentageCompletion, 0)>=90
		and isnull(t.PercentageCompletion, 0)<95
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem753)Plan Pending Analyst Commitment Review
IF ( @spName = 'FindItem753' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 12
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END


-- (FindItem754)Plan Pending Director Commitment Review
IF ( @spName = 'FindItem754' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 13
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem755)Plan Pending Sr Director Commitment Review
IF ( @spName = 'FindItem755' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 14
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem756)Plan Pending VP Commitment Review
IF ( @spName = 'FindItem756' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 15
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem757)Close Out
IF ( @spName = 'FindItem757' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where s.status = 16
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem758)Waivers Approved
IF ( @spName = 'FindItem758' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where isnull(isWaiver, 'N') ='Y' 
	and status = 6
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem759)Waiver Denied
IF ( @spName = 'FindItem759' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s
	where isnull(isWaiver, 'N') ='Y' 
	and status = 11
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem760)Evaluation Satisfactory
IF ( @spName = 'FindItem760' )
BEGIN
	Select @count = count(distinct s.Id)
	from [Plan] s, (select * From PlanProperty where propertyId in (25, 31) ) pp
	where s.Id = pp.planId 
	and status = 16
	and convert(nvarchar(50), pp.PropertyText) = 'Satisfactory'
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem761)Evaluation Marginal
IF ( @spName = 'FindItem761' )
BEGIN
	Select @count = count(distinct s.Id)
	from [Plan] s, (select * From PlanProperty where propertyId in (25, 31) ) pp
	where s.Id = pp.planId 
	and status = 16
	and convert(nvarchar(50),pp.PropertyText) = 'Marginal'
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

-- (FindItem762)Evaluation Unsatisfactory
IF ( @spName = 'FindItem762' )
BEGIN
	Select @count = count(s.Id)
	from [Plan] s, (select * From PlanProperty where propertyId in (25, 31) ) pp
	where s.Id = pp.planId 
	and status = 16
	and convert(nvarchar(50),pp.PropertyText) = 'Unsatisfactory'
	and (( @userId = 1 and s.type = 'Line')
		or ( @userId = 2 and s.type = 'CIP')
		or ( @userId = 3 and s.type = 'Mentor')
		or ( @userId = 4 and s.type = 'Mentor Grad'))
END

---- (FindItem763)GC's Evaluation of Subs
--IF ( @spName = 'FindItem763' )
--BEGIN
--	Select @count = count(s.Id)
--	from [Plan] s
--	where s.status = 16
--	and (( @userId = 1 and s.type = 'Line')
--		or ( @userId = 2 and s.type = 'CIP')
--		or ( @userId = 3 and s.type = 'Mentor')
--		or ( @userId = 4 and s.type = 'Mentor Grad'))
--END

---- (FindItem764)Subs Evaluation of GC's
--IF ( @spName = 'FindItem764' )
--BEGIN
--	Select @count = count(s.Id)
--	from [Plan] s
--	where s.status = 16
--	and (( @userId = 1 and s.type = 'Line')
--		or ( @userId = 2 and s.type = 'CIP')
--		or ( @userId = 3 and s.type = 'Mentor')
--		or ( @userId = 4 and s.type = 'Mentor Grad'))
--END
------------ End SUP Status ----------

---- Start User Dashboard Status ----
IF @spName = 'FindPendingReleaseEvaluation0'
BEGIN
	Select @count = count(Id)
	from Scorecard
	Where Status = 1
	and (( @userId = 1 and Type = 'Capacity')
		or ( @userId = 2 and Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindToBeEvaluatedEvaluation0'
BEGIN
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.Status in (0, 1, 3)
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and (( @userId = 1 and s.Type = 'Capacity')
		or ( @userId = 2 and s.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindPendingEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		-- Evaluator
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status in (0, 1, 3)
		and i.ScorecardId = s.Id and s.Status in (2, 3)

		union

		-- Supervisor (Declined/Overdue)
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status in (8)
		and i.ScorecardId = s.Id and s.Status in (2, 3)

		union

		-- Supervisor (Declined/Overdue)
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status in (2)
		and ((s.Type != 'Mentor A' and datediff(day, s.ReleaseDate, getdate()) <= 14)
			or (s.Type = 'Mentor A' and datediff(day, s.CreateDate, getdate()) <= 14))
		and i.ScorecardId = s.Id and s.Status in (2, 3)
	) t
	where (( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindOverdueEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		-- Evaluator
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status in (8, 9)
		and i.ScorecardId = s.Id and s.Status in (2, 3)

		union
		
		-- Supervisor
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status = 2
		and i.ScorecardId = s.Id and s.Status in (2, 3)
		and ((s.Type != 'Mentor A' and datediff(day, s.ReleaseDate, getdate()) > 14
			and datediff(day, s.ReleaseDate, getdate()) <= 21)
			or (s.Type = 'Mentor A' and datediff(day, s.CreateDate, getdate()) > 14
			and datediff(day, s.CreateDate, getdate()) <= 21))

		union

		-- Supervisor
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status = 9
		and i.ScorecardId = s.Id and s.Status in (2, 3)
	) t
	where (( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindPendingApprovalEvaluation0'
BEGIN
	Select @count = count(s.Id)
	from ScorecardInvitee i, Scorecard s
	where i.Status = 5
	and i.ScorecardId = s.Id and s.Status in (2, 3)
	and s.CloseDate > getdate()
	and (( @userId = 1 and s.Type = 'Capacity')
		or ( @userId = 2 and s.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindRejectedToEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		-- Supervisor
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status = 7
		and i.ScorecardId = s.Id and s.Status in (2, 3)
		and s.CloseDate > getdate()

		union

		-- Reviewer
		Select s.Id, s.Type
		from ScorecardUser i, Scorecard s
		where i.ScorecardId = s.Id and s.Status in (37, 38, 39, 24, 33)
	) t
	where (( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindRejectedEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		-- Evaluator
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status = 7
		and i.ScorecardId = s.Id and s.Status in (2, 3)
		and s.CloseDate > getdate()

		union

		-- Reviewer
		Select s.Id, s.Type
		from ScorecardUser i, Scorecard s
		where i.ScorecardId = s.Id and s.Status in (24, 33, 37, 38, 39)
	) t
	where (( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))

	RETURN @count
END

IF @spName = 'FindDeclinedEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		-- Evaluator
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where i.Status = 2
		and i.ScorecardId = s.Id and s.Status in (2, 3)
		and ((s.Type != 'Mentor A' and datediff(day, s.ReleaseDate, getdate()) <= 21)
			or (s.Type = 'Mentor A' and datediff(day, s.CreateDate, getdate()) <= 21))
	) t
	where (( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B'))
	RETURN @count
END

IF @spName = 'FindPendingReviewEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
			and u.UserType = 'Design Project Manager'
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status = 4 
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
			and u.UserType = 'Design Manager'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status = 5
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
			and u.UserType = 'Design Manager'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status in (4, 5)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
			and u.UserType = 'Deputy Director'
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity') and s.Status = 7
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
			and u.UserType = 'Deputy Director'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity') and s.Status in (4, 5, 7, 8)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 16
			and u.UserType = 'Director'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity') and s.Status = 8
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 16
			and u.UserType = 'Director'
/*
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status in (37, 38, 39)
			and s.Id = u.ScorecardId
			and u.UserType in ('Design Project Manager')
*/

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status = 12
			and s.Id = u.ScorecardId
			and u.UserType = 'Director'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('CCFU') and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
			and u.UserType in ('Operations Supervisor')

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type = 'CCFU' and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
			and u.UserType in ('Operations Director')

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type = 'CCFU' and s.Status = 16 
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 8
			and u.UserType in ('Operations Director')
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Mentor B') and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 4
			and u.UserType in ('VP for Construction Mgmt')

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Mentor B') and s.Status = 25
			and s.Id = u.ScorecardId
			and datediff(day, s.VPCMApprovalDate, getdate()) <= 4
			and u.UserType in ('VP of Admin')

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Mentor B') and s.Status = 12
			and s.Id = u.ScorecardId
			and u.UserType in ('VP for Construction Mgmt')

		union
		
		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status = 2
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) <= 4
			and u.UserType = 'Design Project Manager'
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status = 2
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 4
			and datediff(day, s.CreateDate, getdate()) <= 8
			and u.UserType = 'Design Manager'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status = 5
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) <= 8
			and u.UserType = 'Design Manager'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status in (2, 5)
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 8
			and datediff(day, s.CreateDate, getdate()) <= 12
			and u.UserType = 'Deputy Director'
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status = 26
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) <= 12
			and u.UserType = 'Deputy Director'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status in (2, 5, 26)
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 12
			and datediff(day, s.CreateDate, getdate()) <= 16
			and u.UserType = 'Director'

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status = 27
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) <= 16
			and u.UserType = 'Director'

		union

		Select Id, Type
		from Scorecard
		where Type in ('Contract') and Status = 13

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Contract') and s.Status = 14
			and s.Id = u.ScorecardId
			and u.UserType in ('Director')

		union
		
		Select Id, Type
		from Scorecard
		where Status = 10

		union

		Select Id, Type
		from Scorecard
		where Status = 25
			and Type = 'Mentor A Contract'

		union

		Select Id, Type
		from Scorecard
		where Status = 11
			and Type in ('Capacity', 'CIP', 'Mentor B', 'Contract', 'Mentor A Contract')			
	) t
	where ( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')
	RETURN @count
END

IF @spName = 'FindOverdueReviewEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Capacity', 'CIP') and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
			and u.UserType = 'Design Project Manager'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Capacity', 'CIP') and s.Status in (4, 5)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
			and u.UserType = 'Design Manager'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Capacity') and s.Status in (4, 5, 7)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
			and u.UserType = 'Deputy Director'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Capacity') and s.Status in (4, 5, 7, 8)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 16
			and u.UserType = 'Director'
			and u.Status = 0
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('CCFU') and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
			and u.UserType = 'Operations Supervisor'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('CCFU') and s.Status in (4, 16)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
			and u.UserType in ('Operations Director')
			and u.Status = 0
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Mentor A Contract') and s.Status in (4, 22)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
			and u.UserType in ('Chief Project Officer',
				'Bronx CPO', 'Brooklyn CPO', 'Manhattan CPO', 'Queens CPO', 'Staten Island CPO')
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Mentor A Contract') and s.Status in (4, 22, 23)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
			and u.UserType = 'VP for Construction Mgmt'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Mentor B') and s.Status = 4
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 4
			and u.UserType = 'VP for Construction Mgmt'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Mentor B') and s.Status = 25
			and s.Id = u.ScorecardId
			and datediff(day, s.VPCMApprovalDate, getdate()) > 4
			and u.UserType = 'VP of Admin'
			and u.Status = 0
		
		union
			
		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('Project', 'Contract') and s.Status = 2
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 4
			and u.UserType = 'Design Project Manager'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Project', 'Contract') and s.Status in (2, 5)
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 8
			and u.UserType = 'Design Manager'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Project', 'Contract') and s.Status in (2, 5, 26)
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 12
			and u.UserType = 'Deputy Director'
			and u.Status = 0

		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('Project', 'Contract') and s.Status in (2, 5, 26, 27)
			and s.Id = u.ScorecardId
			and datediff(day, s.CreateDate, getdate()) > 16
			and u.UserType = 'Director'
			and u.Status = 0
	) t
	where ( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')

	RETURN @count
END

IF @spName = 'FindPendingCIPReviewEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('CIP') and s.Status in (4, 5)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 8
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
			and u.UserType = 'Deputy Director'
		
		union

		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u
		where s.Type in ('CIP') and s.Status = 7
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) <= 12
			and u.UserType = 'Deputy Director'
	) t
	where ( @userId = 1 and Type = 'Capacity')
		or ( @userId = 2 and Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')
	RETURN @count
END

IF @spName = 'FindOverdueCIPReviewEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		Select s.Id, s.Type
		from Scorecard s, ScorecardUser u 
		where s.Type in ('CIP') and s.Status in (4, 5, 7)
			and s.Id = u.ScorecardId
			and datediff(day, s.EvaluationCompleteDate, getdate()) > 12
			and u.UserType = 'Deputy Director'
			and u.Status = 0
	) t
	where ( @userId = 1 and t.Type = 'Capacity')
		or ( @userId = 2 and t.Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')

	RETURN @count
END

IF @spName = 'FindInProgressEvaluation0'
BEGIN
	Select @count = count(t.Id)
	From
	(
		-- Evaluator
		Select s.Id, s.Type
		from ScorecardInvitee i, Scorecard s
		where 
		(
			(i.Status in (4, 6) and s.Type != 'Mentor A')
			 or (i.Status = 5)
		)
		and i.ScorecardId = s.Id and s.Status not in (1, 18, 19, 20, 98, 99)

		union

		-- Reviewer
		Select s.Id, s.Type
		from ScorecardUser i, Scorecard s
		where i.Status = 1
		and i.ScorecardId = s.Id and s.Status not in (1, 2, 3, 18, 19, 20, 98, 99)
	) t
	where ( @userId = 1 and Type = 'Capacity')
		or ( @userId = 2 and Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')

	RETURN @count
END

IF @spName = 'FindCompleteEvaluation99'
BEGIN
	Select @count = count(Id)
	from Scorecard
	where Status = 20
	and 
	(
		( @userId = 1 and Type = 'Capacity')
		or ( @userId = 2 and Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')
	)

	RETURN @count
END

IF @spName = 'FindNotNotifiedEvaluation99'
BEGIN
	Select @count = count(Id)
	from Scorecard
	where Status = 19
	and 
	(
		( @userId = 1 and Type = 'Capacity')
		or ( @userId = 2 and Type = 'CIP')
		or ( @userId = 3 and Type = 'Project')
		or ( @userId = 4 and Type = 'Contract')
		or ( @userId = 5 and Type = 'Mentor A')
		or ( @userId = 6 and Type = 'Mentor A Contract')
		or ( @userId = 7 and Type = 'Mentor B')
	)

	RETURN @count
END
---- End User Dashboard Status ----

---- Bid and Award General Status -----
-- (FindItem1419) RFC Prepared
IF ( @spName = 'FindItem1419' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 1
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END

-- (FindItem1420) Project Assigned
IF ( @spName = 'FindItem1420' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 2
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1421) CS Reviewed
IF ( @spName = 'FindItem1421' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 3
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1422) Pending Mgr Solicitation Review
IF ( @spName = 'FindItem1422' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 4
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1423) Pending CS Revision
IF ( @spName = 'FindItem1423' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 5
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1424) CS Revised
IF ( @spName = 'FindItem1424' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 6
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1425) Pending Dir Solicitation Review
IF ( @spName = 'FindItem1425' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 7
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1426) Pending CS Revision 1
IF ( @spName = 'FindItem1426' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 8
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1427) CS Revised 1
IF ( @spName = 'FindItem1427' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 9
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1428) Pending IFB Issuance
IF ( @spName = 'FindItem1428' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 10
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1429) Pending Reproduction
IF ( @spName = 'FindItem1429' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 11
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1430) Documents Available
IF ( @spName = 'FindItem1430' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 12
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1481) Receipt Log Complete
IF ( @spName = 'FindItem1481' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 31
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1483) Bidding Closed
IF ( @spName = 'FindItem1483' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 32
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1485) Vetting and Bid Breakdown Analysis
IF ( @spName = 'FindItem1485' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 33
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1487) Pending Routing Pkg Creation
IF ( @spName = 'FindItem1487' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 41
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1489) Pending Mgr Routing Pkg Review
IF ( @spName = 'FindItem1489' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 42
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1491) Routing Pkg Pending CS Revision
IF ( @spName = 'FindItem1491' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 43
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1493) Routing Pkg Revised
IF ( @spName = 'FindItem1493' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 44
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1495) Pending Dir Routing Pkg Review
IF ( @spName = 'FindItem1495' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 45
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1497) Routing Pkg Pending CS Revision 1
IF ( @spName = 'FindItem1497' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 46
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1499) Routing Pkg Revised 1
IF ( @spName = 'FindItem1499' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 47
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1501) Routing to Finance and OIG
IF ( @spName = 'FindItem1501' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 48
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1503) Intent to Award Notice Issued
IF ( @spName = 'FindItem1503' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 51
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1505) Pending BDD Review
IF ( @spName = 'FindItem1505' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 52
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1507) Pending Admin Review
IF ( @spName = 'FindItem1507' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 53
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1509) Pending Execution Pkg Creation
IF ( @spName = 'FindItem1509' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 61
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1511) Execution Package On Hold
IF ( @spName = 'FindItem1511' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 62
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1513) Pending Legal Review
IF ( @spName = 'FindItem1513' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 63
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1515) Execution Pkg Pending CS Revision
IF ( @spName = 'FindItem1515' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 64
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1517) Execution Pkg Revised
IF ( @spName = 'FindItem1517' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 65
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1519) Pending President Review
IF ( @spName = 'FindItem1519' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 66
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1521) Pending Notice of Award
IF ( @spName = 'FindItem1521' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 68
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1523) Contract Awarded
IF ( @spName = 'FindItem1523' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 69
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1646) Pending Intent to Award Notice
IF ( @spName = 'FindItem1646' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 70
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1647) Intent to Award On Hold
IF ( @spName = 'FindItem1647' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 71
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1655)Pending President Approval
IF ( @spName = 'FindItem1655' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 67
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1696)Routing To OIG Bidder Review
IF ( @spName = 'FindItem1696' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 28
	where pw.Status = 72
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END

---- Bid and Award General Status -----
---- Start Bid Breakdown Analysis Status ----- 
-- (FindItem1463)Bid Breakdown Requested
IF ( @spName = 'FindItem1463' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =1
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1464)Bid Breakdown Received
IF ( @spName = 'FindItem1464' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =2
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1465)Pending Estimating Mgr Review
IF ( @spName = 'FindItem1465' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =3
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1466)Bid Analysis Complete
IF ( @spName = 'FindItem1466' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =4
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1467)Bid Analysis Complete
IF ( @spName = 'FindItem1467' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =5
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1468)Analysis Resubmitted
IF ( @spName = 'FindItem1468' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =6
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1469)BAFO Requested
IF ( @spName = 'FindItem1469' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =7
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1470)Pending VP of CM Review
IF ( @spName = 'FindItem1470' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =8
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1471)BAFO Requested 1
IF ( @spName = 'FindItem1471' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =9
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1472)Pending CS Bid Review
IF ( @spName = 'FindItem1472' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =10
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1473)Pending President Decision
IF ( @spName = 'FindItem1473' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =11
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1474)BAFO Requested 2
IF ( @spName = 'FindItem1474' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =12
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1475)Pending Consultation
IF ( @spName = 'FindItem1475' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =13
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1721)Low Bidder Accepted
IF ( @spName = 'FindItem1721' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 38
	where pw.Status =14
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END


---- End Bid Breakdown Analysis Status -----
-- (FindItem1565)Award Vetting Requested
IF ( @spName = 'FindItem1565' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =1
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1567)Pending Reviewer Vetting
IF ( @spName = 'FindItem1567' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =2
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1569)Vetting Issues
IF ( @spName = 'FindItem1569' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =3
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1572)Pending Low Bidder Selection
IF ( @spName = 'FindItem1572' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =4
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1574)Vetting Complete
IF ( @spName = 'FindItem1574' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =5
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1576)Trades Verified
IF ( @spName = 'FindItem1576' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =6
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1578)Pending Manager Final Review
IF ( @spName = 'FindItem1578' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =7
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1580)Award Vetting Disapproved
IF ( @spName = 'FindItem1580' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =8
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1582)Award Vetting On Hold
IF ( @spName = 'FindItem1582' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =9
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1584)Award Vetting Approved
IF ( @spName = 'FindItem1584' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 36
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =10	
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count

END
-----------Pre-Award Vetting Bond Workflow
-- (FindItem1587)Pending Financial and Bond Review
IF ( @spName = 'FindItem1587' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =1
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1589)Pending Financial Review
IF ( @spName = 'FindItem1589' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =2
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1591)Pending Bid Bond Review
IF ( @spName = 'FindItem1591' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =3
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1593)Pending Low Bidder Selection
IF ( @spName = 'FindItem1593' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =4
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1595)Trades Verified
IF ( @spName = 'FindItem1595' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =5
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1688)Financial Failed
IF ( @spName = 'FindItem1688' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =6
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
-- (FindItem1690)Bond Issues
IF ( @spName = 'FindItem1690' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 37
		left join ProjectProperty pp on p.Id = pp.ProjectId and pp.PropertyId = @ppropertyId_CQUReviewer
	where pw.Status =7
	and ((@userId = 99991 and substring(isnull(pp.PropertyText, ''), 1, 50) = '') or substring(pp.PropertyText, 1, 50) = @username)
RETURN @count
END
--------Routing to OIG Workflow
-- (FindItem1680)Pending OIG Bidder Review
IF ( @spName = 'FindItem1680' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 42
	where pw.Status =1
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1681)Pending OIG Bidder Approval
IF ( @spName = 'FindItem1681' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 42
	where pw.Status =2
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1683)OIG Bidder Review Completed
IF ( @spName = 'FindItem1683' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 42
	where pw.Status =3
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1685)OIG Bidder Issues
IF ( @spName = 'FindItem1685' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 42
	where pw.Status =4
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
------------Addendum Workflow
-- (FindItem1530)Pending Mgr Addendum Review
IF ( @spName = 'FindItem1530' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =1
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)	
RETURN @count
END
-- (FindItem1534)Addendum Revised
IF ( @spName = 'FindItem1534' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =3
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1536)Pending Dir Addendum Review
IF ( @spName = 'FindItem1536' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =4
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1538)Addendum Issued
IF ( @spName = 'FindItem1538' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =7
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1618)Addendum Pending CS Revision
IF ( @spName = 'FindItem1618' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =2
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1619)Addendum Pending CS Revision 1
IF ( @spName = 'FindItem1619' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =5
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1620)Addendum Revised 1
IF ( @spName = 'FindItem1620' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 34
	where pw.Status =6
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
----------RFI Submission / Processing Status
-- (FindItem1459)RFI Submitted
IF ( @spName = 'FindItem1459' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 33
	where pw.Status =1
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1460)RFI Forwarded
IF ( @spName = 'FindItem1460' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 33
	where pw.Status =2
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END
-- (FindItem1461)Consultant RFI Response
IF ( @spName = 'FindItem1461' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowId = 33
	where pw.Status =3
	and ((@userId = 99991 and isnull(p.ContractSpecialist,'') = '') or p.ContractSpecialist = @username)
RETURN @count
END

-------------Inclusion and Rescission
-------Request For Inclusion
if(@spName='FindRfdSupplierBy5')
begin
	select @count=count(1)
	from RfdSupplier
	where status =5
	and workflowid=14
RETURN @count
end
-------Reviewer Reviewed
if(@spName='FindRfdSupplierBy6')
begin
	select @count=count(1)
	from RfdSupplier
	where status =6
	and workflowid=14
RETURN @count
end
-------Question From Manager
if(@spName='FindRfdSupplierBy7')
begin
	select @count=count(1)
	from RfdSupplier
	where status =7
	and workflowid=14
RETURN @count
end
-------Manager Approved
if(@spName='FindRfdSupplierBy8')
begin
	select @count=count(1)
	from RfdSupplier
	where status =8
	and workflowid=14
RETURN @count
end
-------Question From Director
if(@spName='FindRfdSupplierBy9')
begin
	select @count=count(1)
	from RfdSupplier
	where status =9
	and workflowid=14
RETURN @count
end
-------Director Approved
if(@spName='FindRfdSupplierBy10')
begin
	select @count=count(1)
	from RfdSupplier
	where status =10
	and workflowid=14
RETURN @count
end
-------Chief Project Officer Approved
if(@spName='FindRfdSupplierBy11')
begin
	select @count=count(1)
	from RfdSupplier
	where status =11
	and workflowid=14
RETURN @count
end
-------VP for Construction Mgmt Approved
if(@spName='FindRfdSupplierBy12')
begin
	select @count=count(1)
	from RfdSupplier
	where status =12
	and workflowid=14
RETURN @count
end





-------President Approved
if(@spName='FindRfdSupplierBy13')
begin
	select @count=count(1)
	from RfdSupplier
	where status =13
		and WorkflowId =8
		and exists (select * from WorkflowList where id = 8 and Name = 'Supplier Limited List Workflow')
RETURN @count

end
-------Rescind Pending
if(@spName='FindRfdSupplierBy14')
begin
	select @count=count(1)
	from RfdSupplier
	where status =14
		and WorkflowId =8
		and exists (select * from WorkflowList where id = 8 and Name = 'Supplier Limited List Workflow')
RETURN @count

end

------------ Bid and Award General Status ----------

-- (FindItem671) RFC Prepared
IF ( @spName = 'FindItem671' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowType = 'Bid and Award General'
	where pw.Status = 1 --'RFC Prepared'
	and ((@userId = 99991 and isnull(p.ContractSpecialist, '') = '')
		or (p.ContractSpecialist = @username))
RETURN @count
END

-- (FindItem682) Pending Reproduction
IF ( @spName = 'FindItem682' )
BEGIN
	Select @count = count(p.Id)
	from Project p
		left join ProjectWorkflow pw on p.Id = pw.ProjectId and pw.WorkflowType = 'Bid and Award General'
	where pw.Status = 11 --'Pending Reproduction'
	and ((@userId = 99991 and isnull(p.ContractSpecialist, '') = '')
		or (p.ContractSpecialist = @username))
RETURN @count
END

/***********Release 4.0******************/
IF ( @spName = 'FindItem789' )
BEGIN

   select @count=count(planid)
   from
   (
   select p.planid
   from 
         plansubcontractor p
         inner join suppliervetting s on s.contactid=p.supplierid
         Inner join (select * from planProperty where propertyId in (25, 31,15)) B On B.PlanId=p.planId
         Inner join [Plan] pl on pl.id=p.planid
   where --(@userName='' or @userName= isnull(convert(nvarchar(50), B.propertytext), '')) 
   --and 
   s.VettingId =2
   and s.VettingName like '%'+ p.Contractno + '%'
   --and s.contactid=p.supplierid
   and s.status=3
and s.Review =0
and (( @userId = 1 and pl.type = 'Line')
		or ( @userId = 2 and pl.type = 'CIP')
		or ( @userId = 3 and pl.type = 'Mentor')
		or ( @userId = 4 and pl.type = 'Mentor Grad'))
    
   union 
   select p.planid
   from 
         plansubcontractor p
         inner join suppliervetting s on s.contactid=p.supplierid
         Inner join (select * from planProperty where propertyId in (25, 31,15)) B On B.PlanId=p.planId
         Inner join [Plan] pl on pl.id=p.planid
   where --(@userName='' or @userName= isnull(convert(nvarchar(50), B.propertytext), '')) 
   --and
   s.VettingId =1
   and s.VettingName like '%'+ p.Contractno + '%'
   and s.contactid=(select qualifiedsupplierid from vendor where federalid=p.taxid)
   and s.status=3
   and s.Review =0
   and (( @userId = 1 and pl.type = 'Line')
		or ( @userId = 2 and pl.type = 'CIP')
		or ( @userId = 3 and pl.type = 'Mentor')
		or ( @userId = 4 and pl.type = 'Mentor Grad'))
   
   ) v
RETURN @count
END


-- no type found
RETURN @count

END

--------------------
