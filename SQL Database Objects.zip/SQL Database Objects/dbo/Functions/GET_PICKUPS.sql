﻿Create FUNCTION [dbo].[GET_PICKUPS]
(
	@ARG_TAX varchar(50),
	@datefrom date,
	@dateto date,
	@RangeType varchar(2)
)
RETURNS int
AS
begin

declare @n_ret int

declare @firstDayOfYear datetime
declare @firstDayOfNextYear datetime
if(DatePart(Month,getdate()) < 7)
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate()) - 1))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()))))
	end
else
	begin
		set @firstDayOfYear = Convert(Datetime,'7/1/' + Str(DatePart(Year,getdate())))
		set @firstDayOfNextYear = DATEADD(YEAR,1,Convert(Datetime,'6/30/' + Str(DatePart(Year,getdate()) + 1)))
	end

if @datefrom =null or @datefrom ='1/1/1900'
Begin
	if @RangeType ='F' --Fiscal year
		Begin
			set @datefrom=@firstDayOfYear
			set @dateto=@firstDayOfNextYear
		end
	Else
		Begin
			set @datefrom=DATEADD(Month,-12,GetDate())
			set @dateto=Getdate()
		end

End

SELECT @n_ret=COUNT (*) 

FROM (	SELECT COUNT(*) N_PICKUP, C_VENDOR_ID, N_SOLICIT_SEQ 
		FROM 
			MV_VAS_PICKUP 
		WHERE 
			SD_TRANS_DATE between @datefrom and @dateto
			AND SD_TRANS_DATE <= Isnull(SD_ACTUAL_BID_OPEN, '01/01/2099') 
		GROUP BY C_VENDOR_ID, N_SOLICIT_SEQ
) c
WHERE C_VENDOR_ID = @ARG_TAX ;

return @n_ret

end
