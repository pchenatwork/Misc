﻿CREATE FUNCTION [dbo].[QuestionList](@questionId int)
RETURNS XML
WITH RETURNS NULL ON NULL INPUT 
BEGIN RETURN 
  (SELECT 
	q.Id				As '@Id',
	q.SectionId			As '@SectionId',
	q.ParentId			As '@ParentId',
	q.QuestionTypeId	As '@QuestionTypeId',
	t.Type				As '@QuestionType',
	q.QuestionText		As '@QuestionText',
	q.Sequence			As '@Sequence',
	q.IsRequired		As '@IsRequired',
	q.RowNumber			As '@RowNumber',
	q.ColumnNumber		As '@ColumnNumber',
	q.MaxLength			As '@MaxLength',
	q.AnswerFormat		As '@AnswerFormat',
	q.MaxValue			As '@MaxValue',
	q.MinValue			As '@MinValue',
	q.DefaultValue		As '@DefaultValue',
	q.RepeatDirection	As '@RepeatDirection',
	q.Score				As '@Score',
	q.Searchable		As '@Searchable',
	CASE WHEN q.ParentId = @questionId
		THEN dbo.QuestionList(q.Id)
	END,
	(
		select
			c.QuestionId	As '@QuestionId',
			c.CategoryId	As '@CategoryId',
			cc.Name			As '@CategoryName'
		from QuestionCategory c, Category cc
		where c.QuestionId = q.Id
		and c.CategoryId = cc.Id
		Order By cc.Name
		FOR XML PATH('QuestionCategory'), ROOT('ArrayOfQuestionCategory'), TYPE
	),
	(
		select
			a.Id			As '@Id',
			a.QuestionId	As '@QuestionId',
			a.AnswerText	As '@AnswerText',
			a.AnswerValue	As '@AnswerValue',
			a.Sequence		As '@Sequence',
			a.AnswerType	As '@AnswerType',
			a.Score			As '@Score'
		from Answer a
		where a.QuestionId = q.Id
		Order By a.Sequence
		FOR XML PATH('Answer'), ROOT('ArrayOfAnswer'), TYPE
	)
   FROM Question q, QuestionType t
   WHERE q.ParentId = @questionId
	and q.QuestionTypeId = t.Id
	Order BY q.Sequence
   FOR XML PATH('Question'), ROOT('ArrayOfQuestion'), TYPE)
END
