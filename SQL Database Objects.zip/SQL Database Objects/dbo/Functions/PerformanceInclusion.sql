﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[PerformanceInclusion]
(
	@id int
)
RETURNS float
AS
BEGIN
	
	if ((dbo.ApprovedSubcontractorAmount(@id)+ dbo.ApprovedMWLBESupplierAmount(@id))!=0)
		return convert(decimal(18, 2), (dbo.ApprovedMWLBESubcontractorAmount(@id)+ dbo.ApprovedMWLBESupplierAmount(@id))/(dbo.ApprovedSubcontractorAmount(@id)+ dbo.ApprovedMWLBESupplierAmount(@id))* 100, 0)
		
	return 0
	
END


