﻿CREATE FUNCTION [dbo].[GetAutoNumber]
(
	@id bigint,
	@digit int
)
RETURNS nvarchar(20)

AS

begin

declare @idno nvarchar(20)

if LEN(CAST(@id as varchar)) > @digit
	Set @digit = LEN(CAST(@id as varchar))

if @digit = 0
	select @idno = convert(nvarchar(20), @id)
else
	select @idno = Right('000000000' + convert(nvarchar(20), @id), @digit)

return @idno

end
