﻿
CREATE FUNCTION [dbo].[SupplierStatusList](@supplierId int)
RETURNS XML
WITH RETURNS NULL ON NULL INPUT 
BEGIN 

RETURN 
  (	        SELECT
            @supplierId			AS '@SupplierId'
           ,0					AS '@TypeId'
           ,ss.TypeName			AS '@TypeName'
           ,ss.Status			AS '@Status'
    FROM dbo.SupplierStatuses(@supplierId) ss
	FOR XML PATH('SupplierStatus'), ROOT('ArrayOfSupplierStatus'), TYPE)
END

