﻿CREATE FUNCTION [dbo].[CheckExistingKeyPerson]
(@name nvarchar(100), @title nvarchar(50), @supplierId int, @currentVersion char(1))

RETURNS int
AS

begin

declare @id int
set @id = 0

if @currentVersion='Y'
	begin
		set @id = (
					select 
						id 
					from 
						supplierpersonnel 
					where 
						supplierId = @supplierId
						and dbo.GetItemFromSplitedList([name], '|', 2) = dbo.GetItemFromSplitedList(rtrim(ltrim(@name)), '|', 2)
						and dbo.GetItemFromSplitedList([name], '|', 4) = dbo.GetItemFromSplitedList(rtrim(ltrim(@name)), '|', 4)
						and title = rtrim(ltrim(@title))
					)
					
		return @id
	end
else if @currentVersion='N'
	begin

		if exists(select 
						top 1 id 
					from 
						supplierpersonnel 
					where 
						supplierId != @supplierId
						and supplierId in (select Id from supplier where vasid = (select vasid from supplier where id= @supplierId)))

						set @id = (
									select 
										top 1 id 
									from 
										supplierpersonnel 
									where 
										supplierId != @supplierId
										and supplierId in (select Id from supplier where vasid = (select vasid from supplier where id= @supplierId))
										--and dbo.GetItemFromSplitedList([name], '|', 2) = dbo.GetItemFromSplitedList(rtrim(ltrim(@name)), '|', 2)
										--and dbo.GetItemFromSplitedList([name], '|', 4) = dbo.GetItemFromSplitedList(rtrim(ltrim(@name)), '|', 4)
										and	[name] like '%'+dbo.GetItemFromSplitedList(rtrim(ltrim(@name)), '|', 2)+'%' 
										and [name] like '%'+dbo.GetItemFromSplitedList(rtrim(ltrim(@name)), '|', 4)+'%'
										and title = rtrim(ltrim(@title))
									order by ID desc
									)

					
		return @id
	end

return 0
	
end