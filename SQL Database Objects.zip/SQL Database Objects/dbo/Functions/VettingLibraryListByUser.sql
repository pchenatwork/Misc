﻿CREATE FUNCTION [dbo].[VettingLibraryListByUser](@parentId int, @userId int)
RETURNS XML
WITH RETURNS NULL ON NULL INPUT 
BEGIN RETURN 
  (SELECT 
	Id				As '@Id',
	ProjectId		As '@ProjectId',
	ParentId		As '@ParentId',
	Name			As '@Name',
	Description		As '@Description',
	Status			As '@Status',
	UserId			As '@UserId',
	CreateDate		As '@CreateDate',
	ChangeUser		As '@ChangeUser',
	ChangeDate		As '@ChangeDate',
	CASE WHEN ParentId = @parentId
		THEN dbo.VettingLibraryListByUser(Id, @userId)
	END
   FROM VettingLibrary
   WHERE ParentId = @parentId 
	and Id in (Select Id From dbo.VettingLibraryByUser(@parentId, @userId))
	Order BY Name
   FOR XML PATH('VettingLibrary'), ROOT('ArrayOfVettingLibrary'), TYPE)
END