﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[ApprovedSubcontractorAmount]
(
	@id int
)
RETURNS float
AS
BEGIN
	declare @approvedSubcontractorAmount float
	
	set @approvedSubcontractorAmount = 
		(select 
			isnull(SUM(isnull(approvedvalue, 0)), 0) 
		from 
			PlanSubcontractor 
		where 
			PlanId  = @id
			and ISNULL(IsSupplierOnly,'N')!='Y'
			and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))
		)
	
	return @approvedSubcontractorAmount
		
END


