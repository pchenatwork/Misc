﻿CREATE FUNCTION [dbo].[VettingLibraryByUser]
(
	@libraryId int,
	@userId int
)
RETURNS @libraries table
(
	ParentId	int,
	Id			int
)
AS
begin

Insert Into @libraries( Id, ParentId ) 
select l.Id, l.ParentId
from VettingList v, VettingLibrary l
Where v.Status = 0
and v.LibraryId = @libraryId
and l.Id = @libraryId
and v.Id in (Select vg.VettingId From VettingInGroup vg, VettingGroup g, RfxProjectUser ru
		Where vg.VettingGroupId = g.Id and isnull(g.ProjectId, 0) = isnull(ru.ProjectId, 0)
			and ru.UserId = @userId)

While ( @@rowcount > 0 )
Begin
	Insert Into @libraries( Id, ParentId ) 
	Select l.Id, l.ParentId
	from VettingLibrary l, @libraries t
	where l.Id = t.ParentId
	  And t.Id Not In ( Select Id From @libraries )
	  And t.ParentId In ( Select Id From @libraries )
End

return

end


