﻿IF OBJECT_ID(N'dbo.FUN_VAS_CURR_MENTOR_BIDLIST') IS NOT NULL
	DROP FUNCTION [dbo].[FUN_VAS_CURR_MENTOR_BIDLIST]
GO
/*
*******************************************************************************
FUNCTION:	FUN_VAS_CURR_MENTOR_BIDLIST
Purpose:	This is to populate [mv_Curr_Mentor_BidList] by SQL Job
	defined in "Populate CES-ORC Data.sql" script
	[mv_Curr_Mentor_BidList] is referenced by multiple SP, eg EEO_NewSearchVendor/FindSupplierByPostXml
-------------------------------------------------------------------------------
Date			Developer			Notes
==========		===================	===============================
20191223        PCHEN               This func not exists in source control, First created from Production
	Revised Suspended/OnHold logic. Instead of look at the latest [EEO_VENDOR_BID] record, looking at complete history
*******************************************************************************
*/
CREATE FUNCTION [dbo].[FUN_VAS_CURR_MENTOR_BIDLIST]()
RETURNS @table1 TABLE 
(
	[VENDOR_VASID] [numeric](18, 0) NULL,
	[TAX_ID] [char](11) NOT NULL,
	[PROGRAM_TYPE] [varchar](6) NOT NULL,
	[START_DATE] [datetime] NOT NULL,
	[TARGET_GRAD_DATE] [datetime] NULL,
	[ACTUAL_GRAD_DATE] [datetime] NULL,
	[TERMINATION_DATE] [datetime] NULL
)
AS
BEGIN

declare @V_EEO_MENTOR_GRAD_DETAIL TABLE
(
	VENDORID int,
	SD_START_DATE DATETIME,
	SD_GRAD_DATE	datetime,
	SD_EXT_GRAD_DATE	datetime,
	SD_ACTUAL_GRAD_DT	datetime,
	SD_END	datetime,
	SD_UPDATE	datetime
)
INsert into @V_EEO_MENTOR_GRAD_DETAIL
select v.VendorId,SD_START_DATE,SD_GRAD_DATE,SD_EXT_GRAD_DATE,SD_ACTUAL_GRAD_DT,SD_END,SD_UPDATE from EEO_Vendor v
cross apply(
select top 1 * from EEO_MENTOR_GRAD_DETAIL e
where v.VendorId = e.VENDORID
order by SD_UPDATE desc 
) ss

INSERT INTO @table1

SELECT 	1,
        v.FederalId AS TAX_ID, 
        'MENTOR' AS PROGRAM_TYPE, 
        D.SD_START_DATE AS START_DATE, 
        ISNULL(D.SD_EXT_GRAD_DATE, D.SD_GRAD_DATE) AS TARGET_GRAD_DATE,
        SD_ACTUAL_GRAD_DT AS ACTUAL_GRAD_DATE,
        SD_END AS TERMINATION_DATE
FROM @V_EEO_MENTOR_GRAD_DETAIL D, EEO_MASTER M, VENDOR V,EEO_Vendor ev
WHERE 	D.VENDORID = V.Id
and v.id = ev.VendorId
and ev.MentorFlag = 6
AND     v.FederalId = M.C_VENDOR_ID

--AND 	D.ID = (SELECT MAX(ID) FROM EEO_MENTOR_GRAD_DETAIL D2
--                WHERE D2.VENDORID = D.VENDORID )
--AND 	(D.SD_END IS NULL OR (D.SD_END IS NOT NULL AND D.SD_END > CONVERT(DATETIME, CONVERT(CHAR(12), GETDATE()))))
--AND 	(D.SD_ACTUAL_GRAD_DT IS NULL OR (D.SD_ACTUAL_GRAD_DT IS NULL 
--                AND D.SD_ACTUAL_GRAD_DT > CONVERT(DATETIME, CONVERT(CHAR(12), GETDATE()))))
--AND 	(( D.SD_EXT_GRAD_DATE IS NULL AND CONVERT(DATETIME,(CONVERT(CHAR(12),GETDATE())))
--                BETWEEN SD_START_DATE AND SD_GRAD_DATE)
--OR ( SD_EXT_GRAD_DATE IS NOT NULL AND CONVERT(DATETIME,(CONVERT(CHAR(12),GETDATE())))
--                BETWEEN SD_START_DATE AND SD_EXT_GRAD_DATE))
			
--NOT SUSPENDED 202001 PCHEN Revised, check all C_BID_SUSPENSION = 1 
AND NOT EXISTS(select 1 from EEO_VENDOR_BID b where b.VENDORID = v.id AND C_BID_SUSPENSION = 1
				AND SD_START < GETDATE() AND (SD_TO is null or SD_TO > GETDATE()) 
)

---- SCA CRETIFIED and Certification not ending in 42 days
--and (v.CertificationStatus = 'Certified' and (v.CertifiedExpDate>DATEADD(DD,42, CONVERT(DATETIME, CONVERT(CHAR(12), GETDATE())))))

---- PRE-QUAL ends in 6 months
--and (v.QualifiedExpDate>DATEADD(DD,180, CONVERT(DATETIME, CONVERT(CHAR(12), GETDATE()))))

----Bonding less than 1 million
--AND ( NOT EXISTS (SELECT 'X' from supplier s, SupplierSurety ss
--	where s.FederalId = v.FederalId 
--	and s.id = ss.SupplierId
--	and ss.SingleCapacity >1000000))

----AVG SALE less than 2100000
--AND ( ISNULL(M.M_AVERAGE_SALES, 0) <= 2100000 )-- AVG SALE 

--Mentor Trade Code only
--AND (EXISTS (SELECT 'x' FROM supplier s, Category c, SupplierCategory sc
--where v.FederalId = s.FederalId
--and s.id= sc.SupplierId
--and c.id = sc.CategoryId
--and c.IsMentor='Y'))

return
end
GO