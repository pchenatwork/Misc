﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
Create FUNCTION [dbo].[ApprovedSupplierAmount]
(
	@id int
)
RETURNS float
AS
BEGIN
	declare @approvedSupplierAmount float
	
	set @approvedSupplierAmount = 
		(select 
			isnull(SUM(isnull(approvedvalue, 0)), 0) 
		from 
			PlanSubcontractor 
		where 
			PlanId  = @id
			and ISNULL(IsSupplierOnly,'N')='Y'
			and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))
		)
	
	return @approvedSupplierAmount
		
END


