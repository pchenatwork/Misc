﻿
Create function EEO_SBSCertification
	(
		@FedId varchar(50)
	)
RETURNS varchar(250)
As
Begin
	Declare @FederalId varchar(50)
	Set @FederalId=''
	select --distinct vs.Certification , vs.Status ,vs.PartnerSource 

	@FederalId=@FederalId + Coalesce(vs.Certification+ ', ','')

	from VendorSBSCertification vs
	inner join Vendor v on vs.VendorId=v.id 	
	where v.FederalId=@FedId
	RETURN @FederalId
End
