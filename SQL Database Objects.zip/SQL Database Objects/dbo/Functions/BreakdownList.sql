﻿
CREATE FUNCTION [dbo].[BreakdownList](@breakdownId int, @projectType nvarchar(50))
RETURNS XML
WITH RETURNS NULL ON NULL INPUT 
BEGIN RETURN 
  (	SELECT 
		Id		As '@Id',
		ProjectType		As '@ProjectType',
		Name		As '@Name',
		ParentId		As '@ParentId',
		Comments		As '@Comments',
		IsActive		As '@IsActive',
		CASE WHEN ParentId = @breakdownId
			THEN dbo.[BreakdownList](Id, @projectType)
		END
	FROM Breakdown
	WHERE ParentId = @breakdownId
		  and((@projectType like '%Mentor%' and ProjectType like '%M%')
			or (@projectType like '%CIP%' and ProjectType like '%CIP%')
			or (@projectType like '%Line%' and ProjectType like '%L%'))
	Order BY Name
	FOR XML PATH('Breakdown'), ROOT('ArrayOfBreakdown'), TYPE)
END

