﻿CREATE FUNCTION [dbo].[SupplierCategoryList]
(
	@categoryId int
)
RETURNS XML
WITH RETURNS NULL ON NULL INPUT 
BEGIN

RETURN
(
	SELECT 
		c.Id			As '@Id',
		c.Name			As '@Name',
		c.Code			As '@Code',
		c.ParentId		As '@ParentId',
		c.IsActive		As '@IsActive',
		t.CategoryCount	As '@Count',
		CASE WHEN c.ParentId = @categoryId
			THEN dbo.SupplierCategoryList(c.Id)
		END
	from Category c left join (Select s.ParentId, count(distinct SupplierId) As CategoryCount 
			From Categories s, SupplierCategory sc 
			where s.Id = sc.CategoryId Group By s.ParentId) t
	on c.Id = t.ParentId
	WHERE c.ParentId = @categoryId
	Order BY c.Name
	FOR XML PATH('Category'), ROOT('ArrayOfCategory'), TYPE
)

END


