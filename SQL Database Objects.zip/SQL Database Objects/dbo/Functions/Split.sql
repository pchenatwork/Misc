﻿ALTER FUNCTION [dbo].[Split]
 (@List nvarchar(MAX),
 @Delim varchar(10))
RETURNS @Results table
 (Item nvarchar(4000))
AS
/* Sept2020 PCHEN changed @Delim from CHAR(1) to VARCHAR(10) */
begin
 declare @dLen INT = DATALENGTH(@Delim) -- Avoid varchar(10)='' as delimiter
 if @dLen=0
 BEGIN
    INSERT INTO @Results SELECT LEFT(@List, 4000)
    RETURN
 END

 declare @IndexStart int
 declare @IndexEnd int
 declare @Length  int
 declare @Word nvarchar(4000)
 declare @Kill  int 

 --SET @List = LTRIM(RTRIM( REPLACE(REPLACE(REPLACE(@List, CHAR(9),''),CHAR(10),''), CHAR(13),'') )) ;
 
 set @IndexStart = 1 
 set @IndexEnd = 0
 set @Length = len(@List) 
 set @Kill = 0
 
 while @IndexStart <= @Length
      begin
	  set @Kill = @Kill + 1
	  if @Kill >= 9999 return -- hard limiter just in case
	  
	  set @IndexEnd = charindex(@Delim, @List, @IndexStart)
      	  
	  if @IndexEnd = 0
	   set @IndexEnd = @Length + 1
	  
	  set @Word = LTrim(substring(@List, @IndexStart, @IndexEnd - @IndexStart))
      	  
	  set @IndexStart = @IndexEnd + @dLen
	  
	  INSERT INTO @Results
	   SELECT @Word
      end
 
 return
end
/* ** Testing ****

DECLARE @s VARCHAR(MAX) = '1234^ 2345:: 3456 :: 3456354'
DECLARE @d varchar(2) = '^'
--DECLARE @d VARCHAR(10) = ':: '
SELECT * from dbo.Split(@s,@d)
****************** */