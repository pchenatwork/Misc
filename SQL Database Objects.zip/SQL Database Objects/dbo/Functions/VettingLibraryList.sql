﻿CREATE FUNCTION [dbo].[VettingLibraryList](@parentId int)
RETURNS XML
WITH RETURNS NULL ON NULL INPUT 
BEGIN RETURN 
  (SELECT 
	Id				As '@Id',
	ProjectId		As '@ProjectId',
	ParentId		As '@ParentId',
	Name			As '@Name',
	Description		As '@Description',
	Status			As '@Status',
	UserId			As '@UserId',
	CreateDate		As '@CreateDate',
	ChangeUser		As '@ChangeUser',
	ChangeDate		As '@ChangeDate',
	CASE WHEN ParentId = @parentId
		THEN dbo.VettingLibraryList(Id)
	END
   FROM VettingLibrary
   WHERE ParentId = @parentId
	Order BY Name
   FOR XML PATH('VettingLibrary'), ROOT('ArrayOfVettingLibrary'), TYPE)
END