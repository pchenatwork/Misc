﻿CREATE FUNCTION [dbo].[CategoryList](@categoryId int)
RETURNS XML
WITH RETURNS NULL ON NULL INPUT 
BEGIN RETURN 
  (	SELECT 
		Id			As '@Id',
		Name			As '@Name',
		Code			As '@Code',
		ParentId		As '@ParentId',
		IsActive		As '@IsActive',
		CASE WHEN ParentId = @categoryId
			THEN dbo.CategoryList(Id)
		END
	FROM Category
	WHERE ParentId = @categoryId
	Order BY Name
	FOR XML PATH('Category'), ROOT('ArrayOfCategory'), TYPE)
END
