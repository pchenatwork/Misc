﻿

CREATE FUNCTION [dbo].[EncryptField]
(
    @inputstring nvarchar(500),
    @key nvarchar(500)='2WorldWin8'
)
RETURNS nvarchar(500)
AS
BEGIN
-- Declare the return variable here
declare @inputstringlength int
declare @asc nvarchar(500)
set @asc= ''
declare @map_asc nvarchar(500)
set @map_asc= ''
declare @holdchar nvarchar(500)
set @holdchar=''
declare @flag int
declare @returnstring nvarchar(500)
set @returnstring = '' 


if @inputstring=' '
	set @inputstringlength=1
else
	set @inputstringlength=len(@inputstring+'_') -1

if @inputstringlength < 1
	return ''
	
set @flag = 1
WHILE (@flag <= @inputstringlength)
	BEGIN
		set @asc = ASCII(SUBSTRING(@inputstring, @flag, 1))
		set @map_asc = (select crypt_map from encryption_map where ascii_val = @asc)
		set @holdchar = dbo.DecryptFieldFunction(char(@map_asc), default)
		
		set @returnstring  = @returnstring + @holdchar
		SET @flag = @flag + 1
	END

	
return @returnstring

END



