﻿CREATE FUNCTION [dbo].[ScorecardTemplateCategoryList](@categoryId int)
RETURNS XML
WITH RETURNS NULL ON NULL INPUT 
BEGIN RETURN 
  (	
	SELECT 
		c.Id			As '@Id',
		c.TemplateId	As '@TemplateId',
		c.Name			As '@Name',
		c.Type			As '@Type',
		c.Description	As '@Description',
		c.Sequence		As '@Sequence',
		c.Weight		As '@Weight',
		c.ParentId		As '@ParentId',
		(
			select
				m.Id			As '@Id',
				m.TemplateId	As '@TemplateId',
				m.CategoryId	As '@CategoryId',
				m.Name			As '@Name',
				m.Source		As '@Source',
				m.Rationale		As '@Rationale',
				m.IsRequired	As '@IsRequired',
				m.Sequence		As '@Sequence'
			from ScorecardTemplateMetric m
			where m.CategoryId = c.Id
			Order by convert(nvarchar(50), m.Name)
			FOR XML PATH('ScorecardTemplateMetric'), ROOT('ArrayOfScorecardTemplateMetric'), TYPE
		),
		(
			select
				q.Id			As '@Id',
				q.TemplateId	As '@TemplateId',
				q.CategoryId	As '@CategoryId',
				q.LibraryId		As '@LibraryId',
				q.Name			As '@Name',
				q.Description	As '@Description',
				q.Sequence		As '@Sequence',
				q.Weight		As '@Weight',
				q.Score			As '@Score',
				q.IsRequired	As '@IsRequired',
				q.ScoreMethod	As '@ScoreMethod',
			(
				select
					a.Id			As '@Id',
					a.QuestionId	As '@QuestionId',
					a.Name			As '@Name',
					a.Value			As '@Value',
					a.Description	As '@Description',
					a.Sequence		As '@Sequence',
					a.Score			As '@Score'
				from ScorecardTemplateAnswer a
				where a.QuestionId = q.Id
				order by a.Sequence
				FOR XML PATH('ScorecardTemplateAnswer'), ROOT('ArrayOfScorecardTemplateAnswer'), TYPE
			)
			from ScorecardTemplateQuestion q
			where q.CategoryId = c.Id
			order by q.Sequence
			FOR XML PATH('ScorecardTemplateQuestion'), ROOT('ArrayOfScorecardTemplateQuestion'), TYPE
		),
		CASE WHEN c.ParentId = @categoryId
			THEN dbo.ScorecardTemplateCategoryList(c.Id)
		END
	FROM ScorecardTemplateCategory c
	WHERE c.ParentId = @categoryId
	Order BY c.Name
	FOR XML PATH('ScorecardTemplateCategory'), ROOT('ArrayOfScorecardTemplateCategory'), TYPE)
END
