﻿
create FUNCTION [dbo].[SplitSpace]
 (@List nvarchar(4000),
 @Delim char(1))
RETURNS @Results table
 (Item nvarchar(4000))
AS
begin
 declare @IndexStart int
 declare @IndexEnd int
 declare @Length  int
 declare @Word nvarchar(4000)
 declare @Kill  int 
 set @IndexStart = 1 
 set @IndexEnd = 0
 set @Length = len(@List) 
 set @Kill = 0
 
 while @IndexStart <= @Length
      begin
	  set @Kill = @Kill + 1
	  if @Kill >= 999 return -- hard limiter just in case
	  
	  set @IndexEnd = charindex(@Delim, @List, @IndexStart)
	  
	  if @IndexEnd = 0
	   set @IndexEnd = @Length + 1
	  
	  set @Word = substring(@List, @IndexStart, @IndexEnd - @IndexStart)
	  
	  set @IndexStart = @IndexEnd + 1
	  
	  INSERT INTO @Results
	   SELECT @Word
      end
 
 return
end