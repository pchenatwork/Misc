﻿

CREATE FUNCTION [dbo].[EEO_GetMissedCount](
    @VENDORID INT ,
    @CLASS_TYPE as varchar(20),
    @ModuleId as int 
) RETURNS int 
BEGIN
    DECLARE @ret int;
    
 
			select @ret = count(*) 
	from EEO_VENDOR_CLASSES vc, eeo_classes c1
	where	vc.VENDORID = @VENDORID
	and vc.C_CLASS_ID=c1.C_CLASS_ID
 		AND ( vc.C_REASON_EXCUSED is null or vc.C_REASON_EXCUSED ='' )
		AND ((@CLASS_TYPE=4 AND C1.ModuleId =@ModuleId) OR (@CLASS_TYPE<>4 AND C1.C_CLASS_TYPE=@CLASS_TYPE))
		and vc.C_ATTENDED='N'
		and not exists (select * from EEO_Vendor_classes where vendorid=vc.vendorid and rtrim(C_CLASS_ID)=rtrim(vc.C_CLASS_ID) and isnull(C_ATTENDED,'N')='Y'  )
 


     IF (@ret IS NULL) 
        SET @ret = 0;
    RETURN @ret;
END;
