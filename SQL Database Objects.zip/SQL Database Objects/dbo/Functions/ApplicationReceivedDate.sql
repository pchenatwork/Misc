﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[ApplicationReceivedDate]
(
	@supplierId int
)
RETURNS datetime
AS
BEGIN
	declare @receiveDate datetime
	if exists(select * from supplierproperty where supplierId = @supplierId and propertyId = 530 and isnull(propertydate, '1900/1/1')!='1900/1/1')
		set @receiveDate = (select propertydate from supplierproperty where supplierId = @supplierId and propertyId = 530)
	else if exists(select * from supplier where Id = @supplierId and  isnull(qualsubmitteddate, '1900/1/1')!='1900/1/1')
		set @receiveDate = (select qualsubmitteddate from supplier where Id = @supplierId)
	else
		set @receiveDate = getdate()
		
	return @receiveDate
END


