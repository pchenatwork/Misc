﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[ProjectPhase]
(
	@ContractAwardDate datetime,
	@ProjectDuration int,
	@SubStartDate datetime
)
RETURNS int
AS
BEGIN
	declare @span int
	set @span = convert(int, ceiling(convert(float, @ProjectDuration)/3))
	declare @phase int
	
	if(@ProjectDuration %3=1)
		begin
			if (@SubStartDate <= dateadd(day, @span, @ContractAwardDate ))
				set @phase = 1
			else if (@SubStartDate > dateadd(day, @span, @ContractAwardDate )and @SubStartDate <= dateadd(day, (@span*2 -1), @ContractAwardDate ))
				set @phase = 2
			else
				set @phase = 3
		end
	else
		begin
			if (@SubStartDate <= dateadd(day, @span, @ContractAwardDate ))
				set @phase = 1
			else if (@SubStartDate > dateadd(day, @span, @ContractAwardDate )and @SubStartDate <= dateadd(day, (@span*2), @ContractAwardDate ))
				set @phase = 2
			else
				set @phase = 3
		end
	
	return @phase
END





