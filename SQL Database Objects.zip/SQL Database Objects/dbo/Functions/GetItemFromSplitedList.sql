﻿　
　
　
CREATE FUNCTION [dbo].[GetItemFromSplitedList](@string nvarchar(4000), @delim char(1), @index int)
RETURNS nvarchar(200)
AS
BEGIN
-- Declare the return variable here
Declare @temp Table
( 
id int identity(1, 1),
item nvarchar(200)
) 
Declare @item nvarchar(200)
insert into @temp select item from dbo.Split(@string, @delim)
set @item = (select item from @temp where id = @index)
return isnull(@item, '')
END