﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[EstimateMWLBESubcontractorAmount]
(
	@id int
)
RETURNS float
AS
BEGIN
	declare @estimateMWLBESubcontractorAmount float
	
	if exists(select * from PlanSubcontractorpro where PlanId  = @id)

		set @estimateMWLBESubcontractorAmount = 
			(select 
				isnull(SUM(isnull(estvalue, 0)), 0) 
			from 
				PlanSubcontractorpro 
			where 
				PlanId  = @id
				and ISNULL(IsSupplierOnly,'N')!='Y'
				and isnull(IsNonMinority, 'N')!='Y'
				and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))
			)

	else
		set @estimateMWLBESubcontractorAmount = 
			(select 
				isnull(SUM(isnull(estvalue, 0)), 0) 
			from 
				PlanSubcontractor 
			where 
				PlanId  = @id
				and ISNULL(IsSupplierOnly,'N')!='Y'
				and isnull(IsNonMinority, 'N')!='Y'
				and rtrim(ltrim(isnull(TaxId, ''))) != rtrim(ltrim(isnull(FederalId, '')))
			)
		
	return @estimateMWLBESubcontractorAmount
		
END
