﻿using EVO.TimesheetPortal.BusinessLogic;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using Xunit;

namespace EVO.TimesheetPortal.xUnit
{
    public class Dino
    {

        [Fact]
        public void Timesheet_Outlook_Tester()
        {// Note PCHEN 10/19/2021 Full set of team Create Update Delete Get test. WORKS
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var mgr = (TimesheetManager)ManagerFactory<Timesheet>.Instance.GetManager(session);
               var ts = mgr.GetOutlookByTeamProject(9, 1, "xxDUMMYXX", 1);

                Assert.True(ts.Details.Count > 0);
            }
        }


        [Fact]
        public void Team_CRUD_Tester()
        {// Note PCHEN 10/19/2021 Full set of team Create Update Delete Get test. WORKS
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {                
                var mgr = ManagerFactory<Team>.Instance.GetManager(session);
                Team t1 = new Team();
                t1.Name = "Paul team test long name from create";
                t1.ShortName = "pchen short team";
                t1.DeptCode = "724";
                t1.ManagerId = 169;
                t1.OwnerId = 171;
                t1.UpdateBy = "paul.xunit.creater";

                // Insert test
                var newId = mgr.Create(t1);
                Assert.True(newId > 0);
                var t2 = mgr.Get(newId);
                Assert.True(t2.Name == t1.Name);

                // Update test
                t2.Name = "Paul team test long name from update";
                t2.UpdateBy = "paul.xniit.updater";
                mgr.Update(t2);
                t1 = mgr.Get(t2.Id);
                Assert.True(t2.Name == t1.Name);

                // Delete test
                mgr.Delete(t1.Id, "paul.xunit.deleter");
                t2 = mgr.Get(t1.Id);
                Assert.True(t2.IsActive == false);
            }
        }


        [Fact]
        public void ProjectManager_FindListTest()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var ProjectMgr = (ProjectManager)ManagerFactory<Project>.Instance.GetManager(session);
                var jj = ProjectMgr.JsonTest();
                var L1 = ProjectMgr.FindAllByAccounting();
                var L2 = ProjectMgr.FindAllByITExecutive();
                var L3 = ProjectMgr.FindAllByProjectAdmin();

                Assert.True(1 == 1);
            }
        }
        [Fact]
        public void ProjectManager_UpdateTest()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var ProjectMgr = (ProjectManager)ManagerFactory<Project>.Instance.GetManager(session);
                var proj = ProjectMgr.Get(1); // Get Paul's dummy project
                proj.Name = proj.Name +  " - XXX";

                var yy = ProjectMgr.JsonTest();
                ProjectMgr.Update(proj);

                proj = ProjectMgr.Get(1); // Pull the same project again

                Assert.Contains("XXX", proj.Name);
            }
        }
        [Fact]
        public void ProjectManager_UpdateStatusTest()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var ProjectMgr = (ProjectManager)ManagerFactory<Project>.Instance.GetManager(session);
                var proj = ProjectMgr.Get(1); // Get Paul's dummy project

                ProjectMgr.UpdateWorkflowStatus(proj.Id, ProjectStatusEnum.Closed.Id, "ahad", "Ahad ahad close ...");

                proj = ProjectMgr.Get(1); // Pull the same project again

                Assert.True(proj.StatusId == ProjectStatusEnum.Approved.Id);
            }
        }

        [Fact]
        public void ProjectManager_UpSertTest()
        {
            Project p = ValueObjectFactory<Project>.Instance.Create();
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var ProjectMgr = ManagerFactory<Project>.Instance.GetManager(session);

                p.Name = "Paul's dummy project 2 for Canada with Team";
                p.Description = "blar blar ... Proj Desc ... blar blar";
                p.TypeId = 6; // Other
                p.EstHrs = 11.11m;
                p.CountryCode = "CAN";
                p.UpdateBy = "paul.xunit";
                p.Teams = new System.Collections.ObjectModel.Collection<Team>();
                p.Teams.Add(new Team() { Id = 4 });
                p.Teams.Add(new Team() { Id = 5 });

                var newid = ProjectMgr.Create(p);

                Assert.True(newid > 0);
            }
        }

        [Fact]
        public void ProjectManager_Get()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var ProjectMgr = ManagerFactory<Project>.Instance.GetManager(session);
                var proj = ProjectMgr.Get(3);
                var list = ProjectMgr.FindByEntity(new Project());

                Assert.True(proj.Name == "Paul's Dummy Project 1 Name");
            }
        }
        [Fact]
        public void EmployeeActivity_Create()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var mgr = (EmployeeActivityMapManager)ManagerFactory<EmployeeActivityMap>.Instance.GetManager(session);
                var x1 = mgr.Create(new EmployeeActivityMap
                {
                    CreateBy = "Dino",
                    UpdateBy = "Dino1",
                    Project = new Project { Id = 1 },
                    Employee = new Employee { Id = 1 },
                    Activity = new Setting { Id = 1 },
                    IsActive = true
                });
                var x2 = mgr.Get(2);
                Assert.True(x1 == -2);
            }
        }

        [Fact]
        public void Setting_Get()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var mgr = (SettingManager)ManagerFactory<Setting>.Instance.GetManager(session);
                // Custom methos testing
                var x = mgr.Get(1);
                IEnumerable<Setting> x1 = mgr.FindByEntity( new Setting() { Name= "ProjectTypeId" });
                Assert.True(x.Id.Equals(1));
                //Assert.True(x1.GetEnumerator(). > 1);
            }
        }

        //[Fact]
        //public void TeamManager_GetTeam()
        //{
        //    using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
        //    {
        //        var mgr = (TeamManager)ManagerFactory<Team>.Instance.GetManager(session);
        //        // Custom methos testing
        //        var x = mgr.Get(1);
        //        IEnumerable<Team> x1 = mgr.FindByCriteria("SPU_Team_Find", new object[] { });
        //        Assert.True(x.Id.Equals(1));
        //        //Assert.True(x1.GetEnumerator(). > 1);


        //    }
        //}

        [Fact]
        public void Team_Create()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var mgr = (TeamManager)ManagerFactory<Team>.Instance.GetManager(session);
                var x1 = mgr.Create(new Team
                {
                    Name = "Dino.Test",
                    DeptCode = "724",
                    CreateBy = "Dino",
                    UpdateBy = "Dino1",
                    Owner = new Employee { Id = 4 },
                    Manager = new Employee { Id = 4}

                });
                Assert.True(x1 == -2);
            }
        }

        [Fact]
        public void Team_Update()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var mgr = (TeamManager)ManagerFactory<Team>.Instance.GetManager(session);
                var x1 = mgr.Update(new Team
                {
                    Id = 13,
                    Name = "Dino.Test",
                    DeptCode = "724",
                    CreateBy = "Dino",
                    UpdateBy = "Dino1",
                    Owner = new Employee { Id = 4 },
                    Manager = new Employee { Id = 4 }

                });
                Assert.True(x1);
            }
        }
    }
}
