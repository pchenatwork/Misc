﻿ #region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
#endregion

namespace EVO.TimesheetPortal.Entity
{
    /// <summary>
    /// Represent Employee's timesheet activity, mapped to [Timesheet] table
    /// </summary>
    [Serializable]
    public class TimesheetActivity : ValueObjectBase
    {
        #region	Private Members
        private DateTime _activityDate = new DateTime(1900, 1, 1);
        #endregion
        #region Public Propertied
        [XmlAttribute]
        public int EmployeeId { get; set; }
        [XmlAttribute]
        public string EmployeeName { get; set; }
        [XmlAttribute]
        public string ManagerName { get; set; }
        [XmlAttribute]
        public int ProjectId { get; set; }
        [XmlAttribute]
        public string ProjectName { get; set; }
        [XmlAttribute]
        public int ActivityId { get; set; }
        [XmlAttribute]
        public string ActivityName { get; set; }
        [XmlAttribute]
        public DateTime ActivityDate
        {
            get
            {
                return this._activityDate;
            }
            set
            {
                this._activityDate = value;
            }
        }
        [XmlAttribute]
        public decimal Hours { get; set; }
        [XmlAttribute]
        public string Description { get; set; }
        [XmlAttribute]
        public int SourceId { get; set; }
        [XmlAttribute]
        public int SubmissionId { get; set; }
        [XmlAttribute]
        public int IsTimeSheet { get; set; }

        [XmlElement()]
        public Project Project { get; set; }

        #endregion
    }
}
