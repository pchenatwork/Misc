﻿using FrameworkBase.ValueObject;
using System;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Entity
{
    public class TimesheetPeriod : ValueObjectBase
    {
       
        
        public string PeriodCode { get; set; }

        
        public DateTime FromDate { get; set; }
        
        
        public DateTime ToDate { get; set; }
      

        
        public int  StatusId { get; set; }
    }
}