﻿using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Entity
{
    [Serializable]
    public class ApplicationLog : ValueObjectBase
    {
        [XmlAttribute()]
        public int ApplicationLogID { get; set; }

        [XmlAttribute()]
        public string Message { get; set; }

        [XmlAttribute()]
        public string StackTrace { get; set; }

        [XmlAttribute()]
        public string UserName { get; set; }

        [XmlAttribute()]
        public DateTime Date { get; set; }

        [XmlAttribute()]
        public string OperatingSystem { get; set; }

        [XmlAttribute()]
        public string Browser { get; set; }

        [XmlAttribute()]
        public string MachineName { get; set; }
    }
}
