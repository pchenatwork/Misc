﻿using FrameworkBase.ValueObject;
using System;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Entity
{
    public class WorkflowHistory : ValueObjectBase
    {
        /// <summary>
        /// 1: Project Workflow;  2: TimesheetSubmission Workflow
        /// </summary>
        [XmlAttribute()]
        public int WorkflowId { get; set; }
        /// <summary>
        /// ProjectId or TimesheetSubmissionId based on WorkflowId
        /// </summary>
        [XmlAttribute()]
        public int EntityId { get; set; }
        [XmlAttribute()]
        public int StatusId { get; set; }
        /// <summary>
        /// StatusName value is coming from Project/Timesheet StatusEnum
        /// </summary>
        public string StatusName
        {
            get
            {
                return
                    EntityId == 1 ? ProjectStatusEnum.GetById(StatusId).Name : (
                    EntityId == 2 ? TimesheetStatusEnum.GetById(StatusId).Name : string.Empty
                    );
            }
        }
        [XmlAttribute()]
        public string StatusBy { get; set; }
        [XmlElement()]
        public DateTime StatusDate { get; set; } = new DateTime(1900, 1, 1);
        [XmlAttribute()]
        public string Comment { get; set; }
        [XmlAttribute()]
        public int PrevHistoryId { get; set; }
        [XmlAttribute()]
        public bool IsCurrent { get; set; }
    }
}