﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021       Dino    Created
* 10/19/2021    PCHEN   Add ShortName and IsActive
*=======================================================================*/

using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Xml.Serialization;
#endregion


namespace EVO.TimesheetPortal.Entity
{
    [Serializable]
    public class Team : ValueObjectBase
    {
        [XmlAttribute()]
        public string Name { get; set; }
        [XmlAttribute()]
        public string ShortName { get; set; }
        [XmlAttribute()]
        public string DeptCode { get; set; }
        [XmlAttribute()]
        public int ManagerId { get; set; }
        [XmlElement()]
        public Employee Manager { get; set; }
        [XmlAttribute()]
        public int OwnerId { get; set; }
        [XmlElement()]
        public Employee Owner { get; set; }
        [XmlAttribute()]
        public int ParentId { get; set; }
        [XmlAttribute()]
        public bool IsActive { get; set; } = true;
        [XmlArray("ArrayOfEmployee")]
        public Collection<Employee> Employees { get; set; }
    }
}
