﻿using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Entity
{
    /// <summary>
    /// PCHEN NOTE 10/19/2021 Since entity 'Team' has ManagerId and OwnerId now, This Entity is probably redundent
    /// to be "xxxxxxx"
    /// </summary>
    [Serializable]
    public class TeamCriteria 
    {
        public int Id { get; set; }
        public string Name { get; set; }
       
        public string DeptCode { get; set; }
       
        public int? ManagerId { get; set; }
        
        public int? OwnerId { get; set; }

        public bool IsAdmin { get; set; }

        public int? ParentId { get; set; }
       
      
    }
}
