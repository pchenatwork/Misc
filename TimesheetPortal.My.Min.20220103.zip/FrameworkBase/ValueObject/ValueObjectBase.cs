﻿using System;
using System.Xml.Serialization;

/* ============================================================================
 * PCHEN 202110 Introduced
 * Inspired by
   http://grabbagoft.blogspot.com/2007/06/generic-value-object-equality.html
   https://enterprisecraftsmanship.com/2015/01/03/value-objects-explained/
 * ============================================================================ */

namespace FrameworkBase.ValueObject
{
    [Serializable]
    public abstract class ValueObjectBase : IValueObject
    {
        #region	Private Members
        protected DateTime _createDate = new DateTime(1900, 1, 1);
        protected DateTime _updateDate = new DateTime(1900, 1, 1);
        #endregion

        #region constructor
        protected ValueObjectBase() { }

        #endregion constructor

        #region Properties

        [XmlAttribute()]
        public int Id { get; set; }

        [XmlAttribute()]
        public string CreateBy { get; set; }

        [XmlAttribute()]
        public virtual DateTime CreateDate
        {
            get
            {
                return this._createDate;
            }
            set
            {
                this._createDate = value;
            }
        }

        [XmlAttribute()]
        public string UpdateBy { get; set; }

        [XmlAttribute()]
        public DateTime UpdateDate
        {
            get
            {
                return this._updateDate;
            }
            set
            {
                this._updateDate = value;
            }
        }

        /// <summary>
        /// Reserved to additional info to the ValueObject Entity
        /// </summary>
        [XmlAttribute()]        
        public string Extra { get; set; }

        #endregion Properties
    }
}