﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using FrameworkBase.Common;
using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

#endregion

namespace FrameworkBase.ValueObject
{
    public class ValueObjectFactory<T> : FactoryBase<ValueObjectFactory<T>> where T : IValueObject, new()
    {
        public T Create()
        {
            return new T();
        }
    }
}
