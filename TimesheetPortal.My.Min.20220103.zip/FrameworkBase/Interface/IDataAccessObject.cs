﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using System.Collections.Generic;
#endregion

namespace FrameworkBase.Interface
{
    /// <summary>
    /// Define Repository Pattern
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IDataAccessObject<T> where T : IValueObject
    {
        int Create(IDbSession dbSession, T entity);

        bool Update(IDbSession dbSession, T entity);

        bool Delete(IDbSession dbSession, dynamic Id, string By = null);

        T Get(IDbSession dbSession, dynamic id);

        IEnumerable<T> GetAll(IDbSession dbSession);

        IEnumerable<T> FindByCriteria(IDbSession dbSession, string finderType, params object[] criteria);

        /// <summary>
        /// Generic function to invoke any function in the DAO.
        /// ** IDbSession must be the first parameter of parameters array **
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        dynamic InvokeByMethodName(string methodName, params object[] parameters);
    }
}