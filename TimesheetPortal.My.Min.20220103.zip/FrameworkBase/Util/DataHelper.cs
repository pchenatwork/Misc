﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FrameworkBase.Util
{
    /// <summary>
    /// Static Data helper class
    /// </summary>
    public static class DataHelper
    {
        /// <summary>
        /// DateTime value of "1/1/1900" will be treated as NULL
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static bool IsNull(DateTime? dt)
        {
            if (!dt.HasValue)
            {
                return true;
            }
            else
            if (dt.Value == new DateTime(1900, 1, 1) || dt.Value == DateTime.MinValue)
            {
                return true;
            }
            return false;
        }

        public static bool IsNull(string dt)
        {
            return !string.IsNullOrEmpty(dt) && dt != DateTime.MinValue.ToString();
        }
    }
}
