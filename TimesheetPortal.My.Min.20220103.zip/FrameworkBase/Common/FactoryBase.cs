﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using System;

#endregion

namespace FrameworkBase.Common
{
    /// <summary>
    /// Generic Singlton base class for Factory Method
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class FactoryBase<T> where T : class
    {
        private static readonly Lazy<T> instance = new Lazy<T>(() => Activator.CreateInstance(typeof(T), true) as T);
        public static T Instance => instance.Value;
    }
}