﻿#region Header Info

using FrameworkBase.DataAccess;
using FrameworkBase.ValueObject;
using FrameworkBase.BusinessLogic;
using System;
using System.Collections.Generic;
using System.Text;


/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

#endregion

namespace FrameworkBase.BusinessLogic
{
    public class ManagerBase<T> : IManager<T> where T : IValueObject
    {
        #region Private Variables
        private IDbSession _dbSession;
        private IDataAccessObject<T> _dao;
        #endregion

        #region Constructors
        protected ManagerBase(IDbSession dbSession, IDataAccessObject<T> dao)
        {
            _dbSession = dbSession;
            _dao = dao;
        }
        protected ManagerBase() { }
        #endregion

        #region Properties
        public IDbSession dbSession => this._dbSession;
        public IDataAccessObject<T> dao => this._dao;
        #endregion

        #region IManager Implementation

        public int Create(T newObject)
        {
            return _dao.Create(_dbSession, newObject);
        }
        public bool Delete(dynamic id, dynamic by=null)
        {
            return _dao.Delete(_dbSession, id, by);
        }
        public bool Update(T existingObject)
        {
            return _dao.Update(_dbSession, existingObject);
        }
        public T Get(dynamic id)
        {
            return _dao.Get(_dbSession, id);
        }
        public IEnumerable<T> GetAll()
        {
            return _dao.GetAll(_dbSession);
        }
        //public IEnumerable<T> FindByCriteria(string finderType, object[] criteria)
        //{
        //    return _dao.FindByCriteria(_dbSession, finderType, criteria);
        //}

        public IEnumerable<T> FindByEntity(IValueObject criteria)
        {
            var result = _dao.FindByEntity(_dbSession, criteria);
            if (result == null)
            {
                result = new List<T>();
            }
            return result;
        }

        #endregion
    }
}
