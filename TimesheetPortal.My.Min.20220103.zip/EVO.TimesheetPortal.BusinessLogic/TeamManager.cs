﻿#region Header Info

using EVO.TimesheetPortal.Entity;
using FrameworkBase.BusinessLogic;
using FrameworkBase.DataAccess;
using System.Collections.Generic;

/*=======================================================================
* Modification History:
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/
#endregion Header Info

namespace EVO.TimesheetPortal.BusinessLogic
{
    public class TeamManager : ManagerBase<Team>
    {
        #region	Constructors

        private TeamManager(IDbSession dbSession, IDataAccessObject<Team> dao) : base(dbSession, dao)
        {
        }

        static TeamManager()
        {
            //_logger can go here
        }

        #endregion constructors

        #region Custom menthods can't handle by IManager

        public IList<Team> FindByEntity(TeamCriteria criteria)
        {
            return dao.InvokeByMethodName("FindByEntity", new object[] { dbSession, criteria });
        }
        #endregion
    }
}