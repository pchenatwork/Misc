﻿#region Header Info
using EVO.TimesheetPortal.Entity;
using FrameworkBase.BusinessLogic;
using FrameworkBase.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/
#endregion

namespace EVO.TimesheetPortal.BusinessLogic
{
    public class TimesheetActivityManager : ManagerBase<TimesheetActivity>
    { 
        #region	Constructors
        private TimesheetActivityManager(IDbSession dbSession, IDataAccessObject<TimesheetActivity> dao)
            : base(dbSession, dao)
        {
        }

        static TimesheetActivityManager()
        {
            //_logger can go here
        }
        #endregion constructors

        #region Custom menthods outside of IManager
        public IList<TimesheetActivity> FindByDate(int EmployeeId, DateTime ActivityDate)
        {
            var jsonTokens = new { EmployeeId = EmployeeId, ActivityDate = ActivityDate };
            return dao.InvokeByMethodName("FindDailyData", new object[] { this.dbSession, JsonSerializer.Serialize(jsonTokens) });
        }
        public List<TimesheetActivity> FindByDate(int EmployeeId, DateTime SDate, DateTime EDate,int IsMonth=0)
        {
            var jsonTokens = new { employeeid = EmployeeId, fromdate = SDate, todate = EDate, IsMonth=IsMonth };
            return this.dao.Find(this.dbSession, JsonSerializer.Serialize(jsonTokens))?.ToList();
        }
        public IEnumerable<TimesheetActivity> FindAccountData(TimesheetCriteria searchEntity)
        {
            var jsonTokens = new { PeriodCode = searchEntity.PeriodCode };
            return dao.InvokeByMethodName("FindAccountData", new object[] { this.dbSession, JsonSerializer.Serialize(jsonTokens) });
        }
        

        public TimesheetActivity GetByCriteria(TimesheetActivity e)
        {
            return dao.InvokeByMethodName("GetByCriteria", new object[] { this.dbSession, e });
        }

        public List<TimesheetActivity> InsertBatch(List<TimesheetActivity> activityList, string createBy)
        {
            var faildList = new List<TimesheetActivity>();
            try
            {
                dbSession.BeginTrans();
                //delete DeleteImport
                dao.InvokeByMethodName("DeleteImport", new object[] { this.dbSession, createBy });
                foreach (var activity in activityList)
                {
                    var result = ImportData(activity,createBy);
                    if (result <= 0)
                    {
                        faildList.Add(activity);
                    }
                }
                dbSession.Commit();
                return faildList;
            }
            catch (Exception ex)
            {
                dbSession.Rollback();
                return activityList;
            }
        }
        public int ImportData(TimesheetActivity e,string createBy)
        {
            return dao.InvokeByMethodName("ImportData", new object[] { this.dbSession, e, createBy });
        }
        
        #endregion

    }
}
