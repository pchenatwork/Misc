﻿#region Header Info
using EVO.TimesheetPortal.DataAccess;
using FrameworkBase.BusinessLogic;
using FrameworkBase.Common;
using FrameworkBase.DataAccess;
using FrameworkBase.ValueObject;
using System;
using System.Linq;
using System.Reflection;



/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/
#endregion

namespace EVO.TimesheetPortal.BusinessLogic
{
    public class ManagerFactory<T> : FactoryBase<ManagerFactory<T>> where T : IValueObject
    {
        /// <summary>
        /// Make sure "{{ValueObjectName}}Manager" clase exists in the Assembly
        /// </summary>
        /// <param name="session"></param>
        /// <returns></returns>
        public IManager<T> GetManager(IDbSession session)
        {
            try
            {
                // ClassName should be in convention of "{{ValueObjectName}}Manager"
                string sClassName = typeof(T).Name.ToLower() + "manager";
                // Search type in current assembly
                Type type = (from t in Assembly.GetExecutingAssembly().GetTypes()
                             where t.IsClass && t.Name.ToLower().Equals(sClassName)
                             select t).Single();

                var dao = DaoFactory<T>.Instance.GetDao();
                object[] args = { session, dao };

                return Activator.CreateInstance(type,
                    BindingFlags.NonPublic | BindingFlags.Instance, null,
                    args, null) as IManager<T>;
            }
            catch
            {
                //throw new SystemException(e.InnerException.Message, e.InnerException);
                return null;
            }
        }
    }
}
