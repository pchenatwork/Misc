﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class EEORedirect : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Request.Params["eeourl"] != null)
        {
            var eeoUrl = Request.Params["eeourl"].ToString();
            var eeoBaseUrl = ConfigurationManager.AppSettings["EEOUrl"];
            form1.Method = "POST";
            form1.Action = eeoBaseUrl + eeoUrl;
            Url.Value = eeoBaseUrl + eeoUrl;
            UserId.Value = HttpContext.Current.User.Identity.Name;
            //TODO:Add one more control for Page
            //      Add encryption of userid
            Page.ClientScript.RegisterStartupScript(this.GetType(), "submit", "document.forms[0].submit();", true);
        }
       

    }
}