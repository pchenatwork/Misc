using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Template.Utilities;
using SCA.VAS.ValueObjects.Template;

public partial class Master_Global : GlobalVettingLibrary
{
	#region Public Property
	override public int ParentId
	{
		get
		{
			return ConvertUtility.ConvertInt(ViewState["ParentId"].ToString());
		}
		set
		{
			ViewState["ParentId"] = value;
		}
	}
	#endregion

	protected void Page_Load(object sender, EventArgs e)
	{
		sidebarToggleImg.Style["cursor"] = "hand";
		sidebarToggleImg.Attributes.Add("onmouseover", "btnImgSwap(this,'rollover');");
		sidebarToggleImg.Attributes.Add("onmouseout", "btnImgSwap(this,'rollup');");
		sidebarToggleImg.Attributes.Add("onmousedown", "btnImgSwap(this,'rolldown');");
		sidebarToggleImg.Attributes.Add("onmouseup", "btnImgSwap(this,'rollup');");
		sidebarToggleImg.Attributes.Add("onclick", "sidebarToggle(this,'" + sidebarToggleImg.ClientID + "');");

		pageTitle.Text = ConfigurationManager.AppSettings["SiteTitle"];

        //Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
        //Response.Cache.SetCacheability(HttpCacheability.NoCache);
        //Response.Cache.SetNoStore();
    }

	#region Public Method
    override public void SetInitialValue(string type, int parentId)
	{
		ViewState["ParentId"] = parentId;

        menu.SetInitialValue(false);
        //SetPagePermission();
        
        explorer.SetInitialValue(type, parentId);
		CommonUtility.CreateUserLog(((PageBase)Page).UserId, ((PageBase)Page).PageUrl, "Global", parentId,
             Request.UserHostAddress);
	}

    override public void SetControlPermission()
    {
        int menuId = ((PageBase)Page).MenuId;
        if (menuId == 0) return;

        //CommonUtility.SetControlPermission(Page.Form.FindControl("content"), menuId,
        //    ((PageBase)Page).UserId);
    }

    override public void RebuildExplorer(string type, int parentId)
    {
        ViewState["ParentId"] = parentId;

        explorer.SetInitialValue(type, parentId);
    }
	#endregion Public Method

}
