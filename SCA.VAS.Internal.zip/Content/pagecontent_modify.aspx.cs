#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Content;
using SCA.VAS.Common.Sessions;

#endregion

public partial class PageContent_Modify : PageBase
{
    #region Web Control Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    protected void submit_Click(object sender, System.EventArgs e)
    {
        if (ModifyPage() > 0)
        {
            Response.Redirect("PageContent_List.aspx");
        }
        else
        {
            errmsg.Text = "Modify Content Failed";
            errmsg.Visible = true;
        }
    }
    #endregion

    #region Private Method
    /// <summary>
    /// SetInitialValue import all news's information into the form
    /// </summary>
    private void SetInitialValue()
    {
        ViewState["Id"] = Request.QueryString["Id"];
        if (ViewState["Id"] == null)
            Response.Redirect("~/Content/PageContent_List.aspx");
        int pageId = ConvertUtility.ConvertInt(ViewState["Id"].ToString());
        SCA.VAS.ValueObjects.Content.Page page = PageUtility.Get(ConstantUtility.CONTENT_DATASOURCE_NAME, pageId);
        if (page != null)
        {
            name.Text = page.Name;
            title.Text = page.Title;
            ftbBody.Text = page.Content;
        }
    }

    private int ModifyPage()
    {
        var userinfo = SessionManager.Get<UserSession>(SessionVars.UserInfo);
        int pageId = ConvertUtility.ConvertInt(ViewState["Id"].ToString());
        SCA.VAS.ValueObjects.Content.Page page = PageUtility.Get(ConstantUtility.CONTENT_DATASOURCE_NAME, pageId);
        if (page != null)
        {
            page.Name = name.Text;
            page.Title = title.Text;
            page.Content = ftbBody.Text;
            page.UserId = UserId;

            PageUtility.Update(ConstantUtility.CONTENT_DATASOURCE_NAME, page);
        }
        else
        {
            page = PageUtility.CreateObject();
            page.Name = name.Text;
            page.Title = title.Text;
            page.Type = "External";
            page.Content = ftbBody.Text;
            page.UserId = userinfo.UserId;

            PageUtility.Create(ConstantUtility.CONTENT_DATASOURCE_NAME, page);
        }

        return page.Id;
    }

    #endregion
}
