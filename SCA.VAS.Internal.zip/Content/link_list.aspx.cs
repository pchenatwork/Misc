#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.BusinessLogic.Content;
using SCA.VAS.ValueObjects.Content;
#endregion Reference

public partial class Link_List : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        // Put link code to initialize the page here
        if (!IsPostBack)
        {
            BindGrid();
        }
    }

    protected void LinkDelete(object sender, DataGridCommandEventArgs e)
    {
        int linkId = Convert.ToInt32(internalGrid.DataKeys[e.Item.ItemIndex]);
        LinkUtility.Delete(ConstantUtility.CONTENT_DATASOURCE_NAME, linkId);
        BindGrid();
    }
    protected void GridPageChange(Object sender, DataGridPageChangedEventArgs e)
    {
        internalGrid.CurrentPageIndex = e.NewPageIndex;
        BindGrid();
    }
    #endregion Web Event Handler

    #region Private Method
    private void BindGrid()
    {
        LinkCollection linkCollection = LinkUtility.FindByCriteria(
            ConstantUtility.CONTENT_DATASOURCE_NAME,
            LinkManager.SEARCH_LINK,
            new object[] { "INTERNAL" });
        if (linkCollection != null && linkCollection.Count > internalGrid.PageSize)
            internalGrid.AllowPaging = true;
        else
            internalGrid.AllowPaging = false;
        if (linkCollection.Count > 0)
        {
            internalGrid.Visible = true;
            internalGrid.DataSource = linkCollection;
            internalGrid.DataBind();
        }
        else
        {
            internalGrid.Visible = false;
        }
    }
    protected void BindItem(object o, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ImageButton tempDelete = (ImageButton)e.Item.FindControl("deleteButton");
            tempDelete.Attributes.Add("onclick", "javascript: return confirm('Are you sure you want to delete this link?');");
        }
    }

    #endregion Private Method

    protected void addButton_Click(object sender, System.EventArgs e)
    {
        Response.Redirect("Link_Add.aspx");
    }
}
