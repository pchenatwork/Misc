#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;
#endregion Reference 

public partial class News_Add : PageBase
{
    #region Web Control News Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
        }
    }

    protected void Submit_Click(object sender, System.EventArgs e)
    {
        try
        {
            if (SaveNews())
            {
                Response.Redirect("News_List.aspx");
            }
            else
            {
                errmsg.Text = "Add News Failed";
                errmsg.Visible = true;
            }
        }
        catch (Exception ex)
        {
            errmsg.Text = "Add News failed because of: " + ex.Message;
            errmsg.Visible = true;
        }
    }

    #endregion Web Control News Handler
    #region Private Method
    /// <summary>
    /// save news information into database
    /// </summary>
    /// <returns>News</returns>
    private bool SaveNews()
    {
        News news = NewsUtility.CreateObject();
        news.TypeId = 0;
        news.Title = ntitle.Text;
        news.Content = description.Text;
        news.ReleaseDate = (releaseDate.SelectedDate == DateTime.MinValue) ?
            new DateTime(1900, 1, 1) : releaseDate.SelectedDate;
        news.ExpireDate = (expireDate.SelectedDate == DateTime.MinValue) ?
            new DateTime(1900, 1, 1) : expireDate.SelectedDate;
        news.Status = 1;
        news.UserId = UserId;

        return NewsUtility.Create(ConstantUtility.CONTENT_DATASOURCE_NAME, news);
    }

    #endregion Private Method
}