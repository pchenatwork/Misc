#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.BusinessLogic.Content;
using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class PageContent_List : PageBase
{
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }

    #region Private Method

    private void BindGrid()
    {
        PageCollection pages = new PageCollection();
        //IntranetPage page;

        pages = PageUtility.FindByCriteria(ConstantUtility.CONTENT_DATASOURCE_NAME, PageManager.SEARCH_PAGE, new object[] { "", "" });
        pageGrid.DataSource = pages;
        pageGrid.DataBind();

        if (pages.Count > pageGrid.PageSize)
        {
            pageGrid.AllowPaging = true;
        }
        else
        {
            pageGrid.AllowPaging = false;
        }
        pageGrid.DataSource = pages;
        pageGrid.DataBind();
        if (pages.Count > 0)
        {
            pageGrid.Visible = true;
        }
        else
        {
            pageGrid.Visible = false;
        }
    }

    protected void BindItem(object o, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            HyperLink contentLink = (HyperLink)e.Item.FindControl("contentLink");
            if (ConvertUtility.ConvertInt(pageGrid.DataKeys[e.Item.ItemIndex].ToString()) == 0)
            {
                contentLink.Visible = false;
            }
            else
            {
                contentLink.Visible = true;
                contentLink.NavigateUrl = "javascript:popup('Content.aspx?id=" + pageGrid.DataKeys[e.Item.ItemIndex].ToString() + "', 500, 500);";
            }
        }
    }

    #endregion Private Method
    protected void PageChange(object source, DataGridPageChangedEventArgs e)
    {
        pageGrid.CurrentPageIndex = e.NewPageIndex;
        BindGrid();
    }
}
