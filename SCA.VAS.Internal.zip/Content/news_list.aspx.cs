#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.BusinessLogic.Content;
using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class News_List : PageBase
{
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }

    #region Private Method

    private void BindGrid()
    {
        NewsCollection newsCollection = NewsUtility.FindByCriteria(
            ConstantUtility.CONTENT_DATASOURCE_NAME,
            NewsManager.SEARCH_NEWS,
            new object[] { keyword.Text, 0 });
        if (newsCollection != null && newsCollection.Count > newsGrid.PageSize)
            newsGrid.AllowPaging = true;
        else
            newsGrid.AllowPaging = false;
        newsGrid.DataSource = newsCollection;
        newsGrid.DataBind();
        if (newsCollection.Count > 0)
            newsGrid.Visible = true;
        else
            newsGrid.Visible = false;
    }

    protected void BindItem(object o, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ImageButton tempDelete = (ImageButton)e.Item.FindControl("deleteButton");
            tempDelete.Attributes.Add("onclick", "javascript: return confirm('Are you sure you want to delete this news flash?');");
            HyperLink contentLink = (HyperLink)e.Item.FindControl("contentLink");
            contentLink.NavigateUrl = "javascript:popup('newsdetail.aspx?id=" + newsGrid.DataKeys[e.Item.ItemIndex].ToString() + "', 500, 500);";
        }
    }

    #endregion Private Method

    protected void addButton_Click(object sender, System.EventArgs e)
    {
        Response.Redirect("News_Add.aspx");
    }
    protected void PageChange(object source, DataGridPageChangedEventArgs e)
    {
        newsGrid.CurrentPageIndex = e.NewPageIndex;
        BindGrid();
    }
    protected void DeleteItem(object source, DataGridCommandEventArgs e)
    {
        int newsId = (int)newsGrid.DataKeys[e.Item.ItemIndex];
        NewsUtility.Delete(ConstantUtility.CONTENT_DATASOURCE_NAME, newsId);
        BindGrid();
    }
    protected void searchButton_Click(object sender, EventArgs e)
    {
        BindGrid();
    }
}
