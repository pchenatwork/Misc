#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;
#endregion

public partial class Link_Modify : PageBase
{
    #region Web Control Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    protected void submit_Click(object sender, System.EventArgs e)
    {
        UpdateLink();
        Response.Redirect("Link_List.aspx");
    }
    #endregion

    #region Private Method

    /// <summary>
    /// SetInitialValue import all link's information into the form
    /// </summary>
    private void SetInitialValue()
    {
        int linkId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        Link link = LinkUtility.Get(ConstantUtility.CONTENT_DATASOURCE_NAME, linkId);

        ltitle.Text = link.Title;
        url.Text = link.Url;
        sequence.Text = link.Sequence.ToString();
    }

    private int UpdateLink()
    {
        int linkId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        Link link = LinkUtility.Get(ConstantUtility.CONTENT_DATASOURCE_NAME, linkId);

        link.Title = ltitle.Text;
        link.Url = url.Text;
        link.Sequence = Convert.ToInt32(sequence.Text);
        link.UserId = UserId;

        LinkUtility.Update(ConstantUtility.CONTENT_DATASOURCE_NAME, link);

        return link.Id;
    }

    #endregion
}
