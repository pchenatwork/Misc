using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.ValueObjects.Content;

public partial class newsdetail : PageBase
{
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int id = Convert.ToInt32(Request.QueryString["id"]);
            News news = NewsUtility.Get(ConstantUtility.CONTENT_DATASOURCE_NAME, id);
            if (news != null)
            {
                NewsTitle.Text = news.Title;
                NewsBody.Text = news.Content;
            }
        }
    }
}
