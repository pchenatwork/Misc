#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.BusinessLogic.Content;
using SCA.VAS.ValueObjects.Content;
#endregion Reference

public partial class Event_List : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }

    protected void searchButton_Click(object sender, System.EventArgs e)
    {
        BindGrid();
    }

    protected void EventDelete(object sender, DataGridCommandEventArgs e)
    {
        int eventId = Convert.ToInt32(eventGrid.DataKeys[e.Item.ItemIndex]);
        EventUtility.Delete(ConstantUtility.CONTENT_DATASOURCE_NAME, eventId);
        BindGrid();
    }
    protected void GridPageChange(Object sender, DataGridPageChangedEventArgs e)
    {
        eventGrid.CurrentPageIndex = e.NewPageIndex;
        BindGrid();
    }
    #endregion Web Event Handler

    #region Private Method
    private void BindGrid()
    {
        DateTime eventStartDate = (startDate.SelectedDate == DateTime.MinValue) ?
            new DateTime(1900, 1, 1) : startDate.SelectedDate;
        DateTime eventEndDate = (endDate.SelectedDate == DateTime.MinValue) ?
            new DateTime(2999, 12, 31) : endDate.SelectedDate;
        EventCollection eventCollection = EventUtility.FindByCriteria(
            ConstantUtility.CONTENT_DATASOURCE_NAME,
            EventManager.SEARCH_EVENT,
            new object[] { eventStartDate, eventEndDate });
        if (eventCollection != null && eventCollection.Count > eventGrid.PageSize)
            eventGrid.AllowPaging = true;
        else
            eventGrid.AllowPaging = false;
        eventGrid.DataSource = eventCollection;
        eventGrid.DataBind();
        if (eventCollection.Count > 0)
            eventGrid.Visible = true;
        else
            eventGrid.Visible = false;
    }
    protected void BindItem(object o, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ImageButton tempDelete = (ImageButton)e.Item.FindControl("deleteButton");
            tempDelete.Attributes.Add("onclick", "javascript: return confirm('Are you sure you want to delete this admin?');");
        }
    }

    #endregion Private Method

    protected void addButton_Click(object sender, System.EventArgs e)
    {
        Response.Redirect("Event_Add.aspx");
    }
}
