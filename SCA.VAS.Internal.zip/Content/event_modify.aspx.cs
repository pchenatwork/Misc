#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.ValueObjects.Content;
#endregion

public partial class Event_Modify : PageBase
{
    #region Web Control Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    protected void submit_Click(object sender, System.EventArgs e)
    {
        UpdateEvent();
        Response.Redirect("Event_List.aspx");
    }

    #endregion

    #region Private Method

    /// <summary>
    /// SetInitialValue import all evt's information into the form
    /// </summary>
    private void SetInitialValue()
    {
        int evtId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        Event evt = EventUtility.Get(ConstantUtility.CONTENT_DATASOURCE_NAME, evtId);

        name.Text = evt.Name;
        description.Text = evt.Description;
        eventDate.SelectedDate = evt.EventDate;
        eventTime.Text = evt.EventTime;
        contact.Text = evt.Contact;
        email.Text = evt.Email;
        location.Text = evt.Location;
        phone.Text = evt.Phone;
        address.Text = evt.Address;
        url.Text = evt.Url;
        releaseDate.SelectedDate = evt.ReleaseDate;
        expireDate.SelectedDate = evt.ExpireDate;
    }

    private int UpdateEvent()
    {
        int evtId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        Event evt = EventUtility.Get(ConstantUtility.CONTENT_DATASOURCE_NAME, evtId);

        evt.Name = name.Text;
        evt.Description = description.Text;
        evt.EventDate = (eventDate.SelectedDate == DateTime.MinValue) ?
            new DateTime(1900, 1, 1) : eventDate.SelectedDate;
        evt.EventTime = eventTime.Text;
        evt.Contact = contact.Text;
        evt.Email = email.Text;
        evt.Location = location.Text;
        evt.Phone = phone.Text;
        evt.Address = address.Text;
        evt.Url = url.Text;
        evt.ReleaseDate = (releaseDate.SelectedDate == DateTime.MinValue) ?
            new DateTime(1900, 1, 1) : releaseDate.SelectedDate;
        evt.ExpireDate = (expireDate.SelectedDate == DateTime.MinValue) ?
            new DateTime(1900, 1, 1) : expireDate.SelectedDate;
        evt.UserId = UserId;

        EventUtility.Update(ConstantUtility.CONTENT_DATASOURCE_NAME, evt);

        return evt.Id;
    }

    #endregion
}
