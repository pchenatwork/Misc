using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;

public partial class Content : PageBase
{
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int id = 0;
            if (Request.QueryString["id"] != null)
                id = ConvertUtility.ConvertInt(Request.QueryString["id"].ToString());
            SCA.VAS.ValueObjects.Content.Page page = PageUtility.Get(ConstantUtility.CONTENT_DATASOURCE_NAME, id);
            if (page != null)
                body.Text = page.Content;
        }
    }
}
