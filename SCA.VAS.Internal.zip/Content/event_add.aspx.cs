#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.ValueObjects.Content;
#endregion Reference 

public partial class Event_Add : PageBase
{
    #region Web Control Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    protected void Submit_Click(object sender, System.EventArgs e)
    {
        try
        {
            if (SaveEvent())
            {
                Response.Redirect("Event_List.aspx");
            }
            else
            {
                errmsg.Text = "Add Event Failed";
                errmsg.Visible = true;
            }
        }
        catch (Exception ex)
        {
            errmsg.Text = "Add Event failed because of: " + ex.Message;
            errmsg.Visible = true;
        }
    }

    #endregion Web Control Event Handler
    #region Private Method
    /// <summary>
    /// save evt information into database
    /// it won't save certification information
    /// it will get address and mailing address information from viewstate
    /// </summary>
    /// <returns>Event</returns>
    private bool SaveEvent()
    {
        Event evt = EventUtility.CreateObject();
        evt.Name = name.Text;
        evt.Description = description.Text;
        evt.EventDate = (eventDate.SelectedDate == DateTime.MinValue) ?
            new DateTime(1900, 1, 1) : eventDate.SelectedDate;
        evt.EventTime = eventTime.Text;
        evt.Contact = contact.Text;
        evt.Email = email.Text;
        evt.Location = location.Text;
        evt.Phone = phone.Text;
        evt.Address = address.Text;
        evt.Url = url.Text;
        evt.ReleaseDate = (releaseDate.SelectedDate == DateTime.MinValue) ?
            new DateTime(1900, 1, 1) : releaseDate.SelectedDate;
        evt.ExpireDate = (expireDate.SelectedDate == DateTime.MinValue) ?
            new DateTime(1900, 1, 1) : expireDate.SelectedDate;
        evt.Status = 1;
        evt.UserId = UserId;

        return EventUtility.Create(ConstantUtility.CONTENT_DATASOURCE_NAME, evt);
    }

    #endregion Private Method
}
