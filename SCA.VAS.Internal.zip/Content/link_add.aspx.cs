#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;
#endregion Reference 

public partial class Link_Add : PageBase
{
    #region Web Control Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    protected void Submit_Click(object sender, System.EventArgs e)
    {
        try
        {
            if (SaveLink())
            {
                Response.Redirect("Link_List.aspx");
            }
            else
            {
                errmsg.Text = "Add Link failed";
                errmsg.Visible = true;
            }
        }
        catch (Exception ex)
        {
            errmsg.Text = "Add Link failed because of: " + ex.Message;
            errmsg.Visible = true;
        }
    }
    #endregion Web Control Event Handler
    #region Private Method

    /// <summary>
    /// save link information into database
    /// it won't save certification information
    /// it will get address and mailing address information from viewstate
    /// </summary>
    /// <returns>Link</returns>
    private bool SaveLink()
    {
        Link link = LinkUtility.CreateObject();
        link.Title = ltitle.Text;
        link.Url = url.Text;
        link.Type = "INTERNAL";
        link.Sequence = Convert.ToInt32(sequence.Text);
        link.UserId = UserId;

        return LinkUtility.Create(ConstantUtility.CONTENT_DATASOURCE_NAME, link);
    }

    #endregion Private Method
}
