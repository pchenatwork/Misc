#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;
#endregion

public partial class News_Modify : PageBase
{
    #region Web Control Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    protected void submit_Click(object sender, System.EventArgs e)
    {
        UpdateNews();
        Response.Redirect("News_List.aspx");
    }
    #endregion

    #region Private Method
    /// <summary>
    /// SetInitialValue import all news's information into the form
    /// </summary>
    private void SetInitialValue()
    {
        int newsId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        News news = NewsUtility.Get(ConstantUtility.CONTENT_DATASOURCE_NAME, newsId);

        ntitle.Text = news.Title;
        description.Text = news.Content;
        releaseDate.SelectedDate = news.ReleaseDate;
        expireDate.SelectedDate = news.ExpireDate;
    }

    private int UpdateNews()
    {
        int newsId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        News news = NewsUtility.Get(ConstantUtility.CONTENT_DATASOURCE_NAME, newsId);

        news.Title = ntitle.Text;
        news.Content = description.Text;
        news.ReleaseDate = (releaseDate.SelectedDate == DateTime.MinValue) ?
            new DateTime(1900, 1, 1) : releaseDate.SelectedDate;
        news.ExpireDate = (expireDate.SelectedDate == DateTime.MinValue) ?
            new DateTime(1900, 1, 1) : expireDate.SelectedDate;
        news.UserId = UserId;

        NewsUtility.Update(ConstantUtility.CONTENT_DATASOURCE_NAME, news);

        return news.Id;
    }

    #endregion
}
