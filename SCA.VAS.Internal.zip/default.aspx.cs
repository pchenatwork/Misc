using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Configuration;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.Common.Utilities;
public partial class _Default : PageBase
{
    private OutlookCollection outlooks;
    private int total_count = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            outlooks = OutlookUtility.FindByCriteria(ConstantUtility.USER_DATASOURCE_NAME,
                OutlookManager.FIND_OUTLOOK_BY_USER,
                new object[] { UserId, Membership.ApplicationName });

            if (outlooks == null || outlooks.Count == 0)
                return;

            string outlookTypeStr = "";
            foreach (Outlook o in outlooks)
            {
                if (outlookTypeStr.IndexOf(o.Type) < 0)
                    outlookTypeStr += (o.Type + "|");
            }
            if (outlookTypeStr.Length > 0)
                outlookTypeStr = outlookTypeStr.Substring(0, outlookTypeStr.Length - 1);

            outlookType.DataSource = outlookTypeStr.Split('|');
            outlookType.DataBind();
            
            SetInitialValue();
        }
    }
    protected void BindItem(object sender, DataListItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            DataList localOutlookList = (DataList)e.Item.FindControl("outlookList");
            Label localType = (Label)e.Item.FindControl("type");
            OutlookCollection outlookList = new OutlookCollection();

            if (outlooks != null)
            {
                foreach (Outlook o in outlooks)
                {
                    //int knt = 0;
                    if (string.Compare(o.Type, localType.Text, true) == 0)
                    {
                        //if (o.SPName.Length > 0)
                        //{
                        //    knt = OutlookUtility.CountByCriteria(ConstantUtility.USER_DATASOURCE_NAME,
                        //        OutlookManager.FIND_OUTLOOK_BY_USER,
                        //        new object[] { o.SPName, UserId });
                        //}

                        //if (knt == 0 && o.Display == "N") continue;
                        //o.Count = knt;
                        if (o.Count == 0 && o.Display == "N") continue;
                        outlookList.Add(o);
                    }
                }
            }
            if (outlookList.Count == 0)
            {
                e.Item.CssClass = "invisible";
            }
            else
            {
                localOutlookList.DataSource = outlookList;
                localOutlookList.DataBind();
            }
        }
    }

    protected void BindOutlookItem(object o, DataListItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            LinkButton localCounter = (LinkButton)e.Item.FindControl("lblCount");
            //HyperLink localIconLink = (HyperLink)e.Item.FindControl("iconLink");
            Label localName = (Label)e.Item.FindControl("name");
            Outlook outlook = (Outlook)e.Item.DataItem;

            localCounter.Text = "( " + outlook.Count.ToString() + " )";

            if (outlook.Count > 0)
            {
                localName.CssClass = "Bold";
                localCounter.CssClass = outlook.Color;
                //localCounter.NavigateUrl = outlook.Url + "?Id=" + outlook.Id.ToString();
                //localIconLink.NavigateUrl = outlook.Url + "?Id=" + outlook.Id.ToString();
            }
        }
    }
    protected void outlookType_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            if (e.CommandName == "OutlookSearch")
            {
                LinkButton lblCount = (LinkButton)e.Item.FindControl("lblCount");
                int id = ConvertUtility.ConvertInt(e.CommandArgument.ToString());
                Outlook outlook = OutlookUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, id);
                if (String.Compare(outlook.Url, "~/Supplier/Supplier_Search_Results.aspx", true) == 0)
                {
                    SearchSupplier search = new SearchSupplier();
                    search.SearchType = SearchSupplier.OUTLOOK_SEARCH;
                    search.OutlookId = ConvertUtility.ConvertInt(lblCount.CommandArgument);
                    Session["Search"] = search;
                    Response.Redirect("~/Supplier/Supplier_Search_Results.aspx");
                }
                else
                    Response.Redirect("~/Scorecard/Scorecard_Outlook.aspx?ogid=" + e.CommandArgument.ToString()
                        + "&uid=" + UserId);
            }
        }
    }

    private void SetInitialValue()
    {
        EmailHistoryCollection emailHistories = EmailHistoryUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            EmailHistoryManager.FIND_EMAILHISTORY_BY_DATERANGE,
            new object[] 
			    { 
				    0,0,"CreateDate","DESC",
				    new DateTime(1900,1,1), 
				    new DateTime(1900,1,1),
				    "",
                    "",
                    "iFax",
                    "",
                    0,
                    "",
                    0,
                    "",
                    ""
			    });
            if (emailHistories != null && emailHistories.Count > 0)
                setFaxTransmissions.Visible = true;
            else
                setFaxTransmissions.Visible = false;
    }
}
