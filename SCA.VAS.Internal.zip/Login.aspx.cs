using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Security.Policy;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;
using LoginProxy;
using SCA.VAS.Common.Sessions;

public partial class Login : PageBase
{
    
	protected void Page_Load(object sender, System.EventArgs e)
	{
        Response.Cookies.Clear();
    }

	protected void BtnLogin_Click(object sender, System.EventArgs e)
	{
        #region old code

        //if (Membership.ValidateUser(username.Text, password.Text))
        //{
        //	User user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, username.Text);

        //          MembershipUser memberUser = Membership.GetUser(username.Text);

        //          FormsAuthentication.SetAuthCookie(user.Id.ToString() + "|" + user.UserName, false);
        //          if (user.Status == 0 || memberUser.LastPasswordChangedDate.AddMonths(6) < DateTime.Now)
        //	{
        //		Response.Redirect("Admin/User_Change_Password.aspx");
        //	}

        //	// Redirect browser back to originating page 
        //          FormsAuthentication.RedirectFromLoginPage(user.Id.ToString() + "|" + user.UserName, false);
        //      }
        //else
        //{
        //	Message.Text = "<" + "br" + ">Login Failed!" + "<" + "br" + ">";
        //}
        #endregion
        
        if (ConfigurationManager.AppSettings["AllowByPassSwitchUser"].ToString() == "N") //by pass entering user password, set Y TEST environment 
        {
            string loginname = username.Text.Trim() + ConfigurationManager.AppSettings["UserNMSuffix"].ToString();
            
            AuthenticationWebServiceSoap obj = new AuthenticationWebServiceSoap();
            UserDetails userDet = obj.ValidateCredentials(loginname, password.Text);

            if (userDet.Authenticated)
            {
                User user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, username.Text);
                if (user != null)
                {
                    //put userId and UserName in cookies for VAS usage - in pagebase
                    SessionManager.Set(SessionVars.UserInfo, new UserSession { UserId = user.Id, UserName = user.UserName });

                    //put userId and UserName in cookies for EEO usage
                    HttpCookie myCookie = new HttpCookie("EEOUserId") { Value = user.Id + "|" + user.UserName };
                    Response.Cookies.Add(myCookie);
                    Response.Redirect("home.aspx");
                }
                
                else
                {
                    Response.Redirect("PermissionDenied.aspx", true);
                }
            }
            else
            {
                Message.Text = "<" + "br" + ">Login Failed!" + "<" + "br" + ">";
            }
        }
        else
        {
            User user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, username.Text);
            if (user != null)
            {
                SessionManager.Set(SessionVars.UserInfo, new UserSession {UserId = user.Id, UserName = user.UserName});

                HttpCookie myCookie = new HttpCookie("EEOUserId") {Value = user.Id + "|" + user.UserName};
                Response.Cookies.Add(myCookie);

                Response.Redirect("home.aspx");
            }
            else
                Response.Redirect("PermissionDenied.aspx", true);
        }
	}
}
