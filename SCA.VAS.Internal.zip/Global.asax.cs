using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;
using System.Timers;
using System.Configuration;
using System.Security.Principal;
using System.Threading;
//using SCA.VAS.Internal.ScheduledJobs;
using System.Web.Security;

using log4net;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.Common.Sessions;
using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.User;


public class Global : System.Web.HttpApplication
{
    private System.ComponentModel.IContainer components = null;
    private static ILog _logger = LoggingUtility.GetLogger(typeof(Global).FullName);

    public Global()
    {
        InitializeComponent();
        
    }

    protected void Application_Start(Object sender, EventArgs e)
    {
        _logger.Info("Application Started");

        // Create a new Timer with Interval set to 60 seconds. 
        int interval = ConvertUtility.ConvertInt(ConfigurationManager.AppSettings["ScheduleInterval"]);
        if (interval == 0)
            interval = 60000;
        System.Timers.Timer aTimer = new System.Timers.Timer(interval);
        aTimer.Elapsed += new ElapsedEventHandler(OnTimedEvent);

        // Only raise the event the first time Interval elapses. 
        aTimer.AutoReset = true;
        aTimer.Enabled = true;
        WorkflowSchedule.SetInitialValue();
    }

    protected void Session_Start(Object sender, EventArgs e)
    {
            IPrincipal curretUser = HttpContext.Current.User;
            string name = curretUser.Identity.Name;
            if (name.Split('\\')[0] == "NYCSCA" && curretUser.Identity.IsAuthenticated) // check SCA network
            {

                string username = name.Split('\\')[1];
                User user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, username);

                if (user != null)
                {
                    //HttpContext.Current.Session["UserId"] = user.Id;
                    //HttpContext.Current.Session["UserName"] = user.UserName;
                    SessionManager.Set(SessionVars.UserInfo, new UserSession { UserId = user.Id, UserName = user.UserName });
                    HttpCookie myCookie = new HttpCookie("EEOUserId") {Value = user.Id + "|" + user.UserName };
                    Response.Cookies.Add(myCookie);
                   
                }
                else //User is not  a valid VAS User.
                {
                    //Redirect to message page where it will ask user to contact Admin to create VAS User
                    _logger.Info("User VAS authentication failed");
                    Response.Redirect("PermissionDenied.aspx", true);
                }

            }
            else
            {
                Response.Redirect("PermissionDenied.aspx");
            }
        
       

    }

    protected void Application_BeginRequest(Object sender, EventArgs e)
    {

    }

    protected void Application_EndRequest(Object sender, EventArgs e)
    {

    }

    protected void Application_AuthenticateRequest(Object sender, EventArgs e)
    {

    }
    protected void Application_AuthorizeRequest(object sender, EventArgs e)
    {


        //var userinfo = SessionManager.Get<UserSession>(SessionVars.UserInfo);
        //if (Session["UserName"] != null)
        //{
        //    IPrincipal principal = new GenericPrincipal(new GenericIdentity(Session["UserId"] + "|" + Session["UserName"]), null);
        //    Thread.CurrentPrincipal = principal;
        //    HttpContext.Current.User = principal;
        //}
    }

    protected void Application_Error(Object sender, EventArgs e)
    {

    }

    protected void Session_End(Object sender, EventArgs e)
    {

    }

    protected void Application_End(Object sender, EventArgs e)
    {

    }

    protected void OnTimedEvent(object source, ElapsedEventArgs e)
    {
        WorkflowSchedule.AutoSchedule();
    }

    #region Web Form Designer generated code
    private void InitializeComponent()
    {
        this.components = new System.ComponentModel.Container();
    }
    #endregion
}

