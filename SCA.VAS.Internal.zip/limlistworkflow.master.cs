using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Common.Utilities;
using SCA.VAS.Workflow;

public partial class limlistworkflow_master : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        pageTitle.Text = ConfigurationManager.AppSettings["SiteTitle"];
        if (!IsPostBack)
        {
            menu.SetInitialValue(true);
            CommonUtility.CreateUserLog(((PageBase)Page).UserId, ((PageBase)Page).PageUrl, "Supplier",
                ConvertUtility.ConvertInt(Request.QueryString["id"]), Request.UserHostAddress);
        }
    }

    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);
        if (menu.ReadOnlyPermission == "Y")
            CommonUtility.SetControlReadOnlyPermission(this.content);
    }
}
