using System;
using System.Web;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web.Services;
using System.Web.Services.Protocols;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.BusinessLogic.Rfd;
using SCA.VAS.ValueObjects.Rfd;

/// <summary>
/// Summary description for LlwAutoComplete
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[System.Web.Script.Services.ScriptService]
public class LlwAutoComplete : System.Web.Services.WebService
{
    public LlwAutoComplete()
    {
    }

    [WebMethod]
    [System.Web.Script.Services.ScriptMethod]
    public string[] GetCompletionList(string prefixText, int count)
    {        
        List<string> suggestions = new List<string>();
        LlwCodeCollection llwCodes = LlwCodeUtility.FindByCriteria(
            ConstantUtility.RFD_DATASOURCE_NAME,
            LlwCodeManager.SEARCH_LLWCODE,
            new object[] 
            {
                prefixText
            });
        if (llwCodes != null)
        {
            foreach (LlwCode llwCode in llwCodes)
            {
                suggestions.Add("\"" + llwCode.Code + "\"");
            }
        }
        return suggestions.ToArray();
    }
}
