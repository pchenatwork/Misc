#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template;
using SCA.VAS.ValueObjects.Scorecard.Template;
#endregion Reference

public partial class Template_Rating : PageBase_Initial
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            ScorecardTemplateQuestion scorecardTemplateQuestion = ScorecardTemplateQuestionUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, id);

            questionLink.Text = scorecardTemplateQuestion.Name;
            questionLink.NavigateUrl = "Template_Question.aspx?Id=" + scorecardTemplateQuestion.TemplateId.ToString();

            if (scorecardTemplateQuestion != null && scorecardTemplateQuestion.UserTypes != null)
            {
                userTypeList.DataSource = scorecardTemplateQuestion.UserTypes;
                userTypeList.DataBind();
            }
        }
    }

    protected void BindItem(object o, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ScorecardTemplateQuestionUserType templateUserType = (ScorecardTemplateQuestionUserType)e.Item.DataItem;

            int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            Repeater answerList = (Repeater)e.Item.FindControl("answerList");
            answerList.DataSource = ScorecardTemplateAnswerUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardTemplateAnswerManager.FIND_BY_TYPE,
                new object[] { id, templateUserType.UserType });
            answerList.DataBind();
        }
    }

    protected void ItemCommand(object o, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "Answer")
        {
            int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            answerinfo.SetInitialValue(id, e.CommandArgument.ToString());
        }
    }
    #endregion Web Event Handler


    public override void SetInitialValue()
    {
        int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        ScorecardTemplateQuestion scorecardTemplateQuestion = ScorecardTemplateQuestionUtility.Get(
            ConstantUtility.SCORECARD_DATASOURCE_NAME, id);

        if (scorecardTemplateQuestion != null && scorecardTemplateQuestion.UserTypes != null)
        {
            userTypeList.DataSource = scorecardTemplateQuestion.UserTypes;
            userTypeList.DataBind();
        }
    }
}