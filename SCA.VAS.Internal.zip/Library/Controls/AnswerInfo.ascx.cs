﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template;
using SCA.VAS.ValueObjects.Scorecard.Template;

public partial class Library_Controls_AnswerInfo : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            btnCancel.Attributes.Add("onclick", "return confirm('Are you sure you want to cancel?');");
        }
    }

    public void SetInitialValue(int questionId, string userType)
    {
        ScorecardTemplateQuestion templateQuestion = ScorecardTemplateQuestionUtility.Get(
            ConstantUtility.SCORECARD_DATASOURCE_NAME, questionId);
        if (templateQuestion != null)
            questionName.Text = templateQuestion.Name;

        UserType.Value = userType;
        QuestionId.Value = questionId.ToString();

        panelTitle.Text = "Rating Description for " + userType;

        answerGrid.DataSource = ScorecardTemplateAnswerUtility.FindByCriteria(
            ConstantUtility.SCORECARD_DATASOURCE_NAME,
            ScorecardTemplateAnswerManager.FIND_BY_TYPE,
            new object[] { questionId, userType });
        answerGrid.DataBind();

        ModalPopup_answer.Show();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int questionId = ConvertUtility.ConvertInt(QuestionId.Value);
        ScorecardTemplateAnswerCollection answers = new ScorecardTemplateAnswerCollection();

        foreach (DataGridItem item in answerGrid.Items)
        {
            if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
            {
                int id = (int)answerGrid.DataKeys[item.ItemIndex];
                Label name = (Label)item.FindControl("name");
                HiddenField sequence = (HiddenField)item.FindControl("sequence");
                HiddenField score = (HiddenField)item.FindControl("score");
                TextBox description = (TextBox)item.FindControl("description");

                ScorecardTemplateAnswer answer = ScorecardTemplateAnswerUtility.CreateObject();
                answer.Id = id;
                answer.Name = name.Text;
                answer.Value = name.Text;
                answer.Description = description.Text;
                answer.Sequence = ConvertUtility.ConvertInt(sequence.Value);
                answer.Score = ConvertUtility.ConvertDouble(score.Value);
                answer.UserType = UserType.Value;
                answers.Add(answer);
            }
        }

        ScorecardTemplateAnswerUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
            questionId, answers);

        PageBase_Initial pagelist = (PageBase_Initial)this.Page;
        pagelist.SetInitialValue();
    }
}
