using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.ValueObjects.Workflow;
using SCA.VAS.ValueObjects.Template.Vetting;

public partial class Global_Controls_VettingInfo : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int vId = ConvertUtility.ConvertInt(vettingId.Value);

        VettingList vetting;
        if (vId > 0)
            vetting = VettingListUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
                vId);
        else
            vetting = VettingListUtility.CreateObject();
        
        vetting.Name = name.Text;
        vetting.Description = description.Text;
        vetting.InternalUse = internalUse.Checked ? "Y" : "N";
        vetting.WorkflowId = ConvertUtility.ConvertInt(workflowList.SelectedValue);
        vetting.LibraryId = ((GlobalVettingLibrary)Page.Master).ParentId;

        if (vId > 0)
            VettingListUtility.Update(ConstantUtility.TEMPLATE_DATASOURCE_NAME, vetting);
        else
            VettingListUtility.Create(ConstantUtility.TEMPLATE_DATASOURCE_NAME, vetting);

        ControlBase_Initial vettinglist = (ControlBase_Initial)this.Parent;
        vettinglist.SetInitialValue();
    }

    public void SetFolderValue(VettingLibrary vettingLibrary)
    {
        if (vettingLibrary != null)
        {
            folderPanelTitle.Text = "Edit Folder";
            libraryId.Value = vettingLibrary.Id.ToString();
            folderName.Text = vettingLibrary.Name;
            folderDescription.Text = vettingLibrary.Description;
        }
        else
        {
            folderPanelTitle.Text = "Add Subfolder";
            libraryId.Value = "0";
            folderName.Text = "";
            folderDescription.Text = "";
        }
        createDetailModalPopup.Show();
    }

    public void SetMoveValue(VettingList vetting)
    {
        if (vetting != null)
        {
            hiddenId.Value = vetting.Id.ToString();
            vettingname.Text = vetting.Name;
            explorer1.SetInitialValue(vetting.LibraryId, "1");
            btnMove.Enabled = false;
            moveModalPopup.Show();
        }
    }

    public void BindControl()
    {
        int parentId = ((GlobalVettingLibrary)Page.Master).ParentId;
        explorer.SetInitialValue(parentId, "0");
        btnMoveFolder.Enabled = false;

    }

    public void SetInitialValue(VettingList vetting)
    {
        workflowList.DataSource = WorkflowListUtility.FindByCriteria(
            ConstantUtility.WORKFLOW_DATASOURCE_NAME,
            WorkflowListManager.FIND_WORKFLOWLIST_BY_TYPE,
            new object[] { ConstantUtility.VETTING_WORKFLOW });
        workflowList.DataBind();
        if (vetting != null)
        {
            panelTitle.Text = "Edit Vetting";
            vettingId.Value = vetting.Id.ToString();
            name.Text = vetting.Name;
            description.Text = vetting.Description;
            internalUse.Checked = (vetting.InternalUse == "Y");
            workflowList.SelectedIndex = workflowList.Items.IndexOf(
                workflowList.Items.FindByValue(vetting.WorkflowId.ToString()));
        }
        else
        {
            panelTitle.Text = "Add Vetting";
            vettingId.Value = "0";
            name.Text = "";
            description.Text = "";
            internalUse.Checked = false;
            workflowList.SelectedIndex = 0;
        }
        vettingModalPopup.Show();
    }

    protected void btnCreate_Click(object sender, EventArgs e)
    {
        int lId = ConvertUtility.ConvertInt(libraryId.Value);
        int parentId = ConvertUtility.ConvertInt(Request.QueryString["parentId"]);

        VettingLibrary vettingLibrary;
        if (lId > 0)
            vettingLibrary = VettingLibraryUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
                lId);
        else
        {
            vettingLibrary = VettingLibraryUtility.CreateObject();
            vettingLibrary.ParentId = parentId;
            vettingLibrary.UserId = ((PageBase)Page).UserId;
        }

        vettingLibrary.Name = folderName.Text.Trim();
        vettingLibrary.Description = folderDescription.Text.Trim();
        vettingLibrary.ChangeUser = ((PageBase)Page).UserName;

        if (lId > 0)
            VettingLibraryUtility.Update(ConstantUtility.TEMPLATE_DATASOURCE_NAME, vettingLibrary);
        else
            VettingLibraryUtility.Create(ConstantUtility.TEMPLATE_DATASOURCE_NAME, vettingLibrary);

        Response.Redirect("Vetting_Explorer.aspx?parentId=" + vettingLibrary.Id.ToString());
    }

    protected void btnMoveFolder_Click(object sender, EventArgs e)
    {
        int parentId = ConvertUtility.ConvertInt(Request.QueryString["parentId"]);

        VettingLibraryUtility.Move(ConstantUtility.TEMPLATE_DATASOURCE_NAME, parentId, 0,
            explorer.ParentId);
        Response.Redirect("Vetting_Explorer.aspx?parentId=" + explorer.ParentId);
    }

    protected void btnMove_Click(object sender, EventArgs e)
    {
        int id = ConvertUtility.ConvertInt(hiddenId.Value);

        VettingListUtility.Move(ConstantUtility.TEMPLATE_DATASOURCE_NAME, id, 0,
            explorer1.ParentId);
        Response.Redirect("Vetting_Explorer.aspx?parentId=" + explorer1.ParentId);
    }
}
