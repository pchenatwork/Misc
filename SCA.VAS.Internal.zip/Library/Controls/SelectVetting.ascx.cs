using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting;
using SCA.VAS.ValueObjects.Template.Vetting;

public partial class Library_Controls_SelectVetting : System.Web.UI.UserControl
{
    VettingGroup vettingGroup;
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    #region Public Method
    public void SetInitialValue()
    {
        ViewState["ParentId"] = 0;

        TreeView2.Nodes.Clear();
        BuildLibraryTree();

        BindGrid();
    }
    #endregion Public Method

    protected void addButton_Click(object sender, EventArgs e)
    {
        int groupId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);

        VettingInGroupCollection vettingInGroups = new VettingInGroupCollection();
        foreach (DataGridItem dataItem in vettingList.Items)
        {
            if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
            {
                CheckBox localVetting = (CheckBox)dataItem.FindControl("selectBox");
                if (localVetting.Checked)
                {
                    VettingInGroup vettingInGroup = VettingInGroupUtility.CreateObject();
                    vettingInGroup.VettingId = (int)vettingList.DataKeys[dataItem.ItemIndex];
                    vettingInGroups.Add(vettingInGroup);
                }
            }
        }
        VettingInGroupUtility.UpdateCollection(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
            groupId, vettingInGroups);

        vettingGroup = VettingGroupUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME, groupId);
        
        BindGrid();

        PageBase_Initial VettingList = (PageBase_Initial)this.Page;
        VettingList.SetInitialValue();

        vetting_ModalPopupExtender.Show();
    }

    protected void ChangeLibraryPage(object source, DataGridPageChangedEventArgs e)
    {
        vettingList.CurrentPageIndex = e.NewPageIndex;
        BindGrid();
        vetting_ModalPopupExtender.Show();
    }

    private void BuildLibraryTree()
    {
        // Create a root node
        TreeNode root = new TreeNode("Global Library", "0");
        root.Selected = true;

        // Add children to the root node
        VettingLibraryCollection libraries = VettingLibraryUtility.FindByCriteria(
            ConstantUtility.TEMPLATE_DATASOURCE_NAME,
            VettingLibraryManager.FIND_VETTINGLIBRARY,
            new object[] { 0 });
        BuildLibraryVettingTree(libraries, root, 0);

        // Add root node to TreeView
        TreeView2.Nodes.Add(root);
        CommonUtility.ExpandAll(TreeView2.SelectedNode);
    }

    private void BuildLibraryVettingTree(VettingLibraryCollection libraries, TreeNode node, int parentId)
    {
        if (libraries == null) return;

        foreach (VettingLibrary vetting in libraries)
        {
            TreeNode n1 = new TreeNode(vetting.Name, vetting.Id.ToString());
            node.ChildNodes.Add(n1);
            if (vetting.Id == parentId)
            {
                n1.Selected = true;
            }
            if (vetting.SubLibraries != null)
            {
                BuildLibraryVettingTree(vetting.SubLibraries, n1, parentId);
            }
        }
    }

    protected void LibraryNodeChange(object sender, System.EventArgs e)
    {
        ViewState["ParentId"] = ConvertUtility.ConvertInt(TreeView2.SelectedNode.Value);

        BindGrid();
        vetting_ModalPopupExtender.Show();
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        vettingList.CurrentPageIndex = 0;
        BindGrid();
        vetting_ModalPopupExtender.Show();
    }

    private void BindGrid()
    {
        VettingListCollection vettings = VettingListUtility.FindByCriteria(
            ConstantUtility.TEMPLATE_DATASOURCE_NAME,
            VettingListManager.SEARCH_VETTINGLIST,
            new object[]
            {
                string.Empty,
                string.Empty,
                keyword.Text.Trim(),
                0,
                0,
                (int)ViewState["ParentId"]
            });

        if (vettings != null && vettings.Count > 0)
        {
            vettingList.AllowPaging = (vettings.Count > vettingList.PageSize);
            vettingList.Visible = true;
            vettingList.DataSource = vettings;
            vettingList.DataBind();
            btnAdd.Visible = true;
        }
        else
        {
            vettingList.Visible = false;
            btnAdd.Visible = false;
        }
    }

    protected void BindItem(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            e.Item.Attributes.Add("onmouseover", "this.className='datagridSelectedItem'");
            if (e.Item.ItemType == ListItemType.Item)
                e.Item.Attributes.Add("onmouseout", "this.className='datagridItem'");
            else
                e.Item.Attributes.Add("onmouseout", "this.className='datagridAlternateItem'");

            VettingList vetting = (VettingList)e.Item.DataItem;

            CheckBox selectBox = (CheckBox)e.Item.FindControl("selectBox");
            selectBox.Enabled = true;
            if (vettingGroup.Vettings != null)
            {
                bool isUsed = false;
                foreach (VettingInGroup v in vettingGroup.Vettings)
                {
                    if (v.VettingId == vetting.Id)
                    {
                        isUsed = true;
                        break;
                    }
                }
                if (isUsed)
                {
                    selectBox.Enabled = false;
                    selectBox.Text = "In Group";
                }
            }
        }
    }

    override protected void OnInit(EventArgs e)
    {
        int groupId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        vettingGroup = VettingGroupUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME, groupId);

        base.OnInit(e);
    }
}
