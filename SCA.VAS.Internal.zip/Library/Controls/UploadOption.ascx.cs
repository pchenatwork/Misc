#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.ValueObjects.Template.Vetting;
#endregion

public partial class Global_Controls_UploadOption : System.Web.UI.UserControl
{
    #region Public Property
    public string FileExtensions
    {
        get
        {
            string fileExtension = string.Empty;
            foreach (ListItem li in extensionCheck.Items)
            {
                if (li.Selected)
                {
                    fileExtension += li.Value + "|";
                }
            }
            return fileExtension.Trim(new char[] { '|' });
        }
    }
    #endregion

    #region Public Method
    public void SetInitialValue(VettingQuestion question)
    {
        extensionCheck.DataSource = CommonUtility.GetSettings("FileType.xml");
        extensionCheck.DataBind();
        if (question != null)
        {
            string[] types = question.DefaultValue.Split(new char[] { '|' });
            for (int i = 0; i < types.Length; i++)
            {
                ListItem li = extensionCheck.Items.FindByValue(types[i]);
                if (li != null)
                {
                    li.Selected = true;
                }
            }
        }
    }
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }
    #endregion
}