#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.ValueObjects.Template.Vetting;
using SCA.VAS.Common.Utilities;
#endregion

public partial class Global_Controls_TextOption : System.Web.UI.UserControl
{
    #region Public Property
    public int QuestionTypeId
    {
        get
        {
            return ConvertUtility.ConvertInt(typeList.SelectedValue);
        }
    }

    public string SelectedQuestionType
    {
        get
        {
            return typeList.SelectedItem.Text;
        }
    }
    #endregion

    #region Public Method
    public void SetInitialValue(VettingQuestion question)
    {
        typeList.Items.Clear();
        QuestionTypeCollection typeCollection = QuestionTypeUtility.FindByCriteria(
            ConstantUtility.COMMON_DATASOURCE_NAME,
            QuestionTypeManager.FIND_QUESTIONTYPE_BY_CATEGORY,
            new object[] { QuestionType.VETTING, QuestionType.TOP_LEVEL_QUESTION });
        for (int i = 0; i < typeCollection.Count; i++)
        {
            if (typeCollection[i].Type == QuestionType.SINGLE_LINE_QUESTION ||
                typeCollection[i].Type == QuestionType.MULTI_LINE_QUESTION)
            {
                typeList.Items.Add(new ListItem(typeCollection[i].Type, typeCollection[i].Id.ToString()));
            }
        }

        if (question != null)
        {
            typeList.SelectedIndex = typeList.Items.IndexOf(typeList.Items.FindByText(question.QuestionType));
        }
    }
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    protected void typeList_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        Global_Controls_SingleOption single = (Global_Controls_SingleOption)this.Parent.FindControl("single");
        Global_Controls_MultiOption multi = (Global_Controls_MultiOption)this.Parent.FindControl("multi");

        switch (typeList.SelectedItem.Text)
        {
            case QuestionType.SINGLE_LINE_QUESTION:
                single.Visible = true;
                multi.Visible = false;
                break;
            case QuestionType.MULTI_LINE_QUESTION:
                single.Visible = false;
                multi.Visible = true;
                break;
        }
    }
    #endregion
}