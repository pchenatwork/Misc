#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Template.Vetting;
#endregion

public partial class Global_Controls_MultiOption : System.Web.UI.UserControl
{
    #region Public Property
    public string DefaultValue
    {
        get { return defaultTxt.Text; }
    }
    #endregion

    #region Public Method
    public void SetInitialValue(VettingQuestion question)
    {
        if (question != null)
        {
            defaultTxt.Text = question.DefaultValue;
        }
        else
        {
            defaultTxt.Text = "";
        }
    }
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }
    #endregion
}
