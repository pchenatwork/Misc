#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.ValueObjects.Template.Vetting;
using SCA.VAS.Common.Utilities;
#endregion

public partial class Global_Controls_SingleOption : System.Web.UI.UserControl
{
    #region Public Property
    public string MaxValue
    {
        get { return maxTxt.Text; }
    }

    public string MinValue
    {
        get { return minTxt.Text; }
    }

    public string DefaultValue
    {
        get { return defaultTxt.Text; }
    }

    public string AnswerFormat
    {
        get
        {
            return answerFormatList.SelectedValue;
        }
    }
    #endregion

    #region Public Method
    public void SetInitialValue(VettingQuestion question)
    {
        AnswerFormatCollection formats = AnswerFormatUtility.FindByCriteria(
            ConstantUtility.COMMON_DATASOURCE_NAME,
            AnswerFormatManager.FIND_ANSWERFORMAT_BY_APPLICATION,
            new object[] { QuestionType.VETTING });
        answerFormatList.DataSource = formats;
        answerFormatList.DataBind();

        if (question != null)
        {
            maxTxt.Text = question.MaxValue;
            minTxt.Text = question.MinValue;
            defaultTxt.Text = question.DefaultValue;
            answerFormatList.SelectedIndex = answerFormatList.Items.IndexOf(answerFormatList.Items.FindByValue(question.AnswerFormat));
        }
        else
        {
            maxTxt.Text = "";
            minTxt.Text = "";
            defaultTxt.Text = "";
        }
    }
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }
    #endregion
}