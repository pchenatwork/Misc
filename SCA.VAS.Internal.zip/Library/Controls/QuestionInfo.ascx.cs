﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.ValueObjects.Scorecard.Template;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

public partial class Library_Controls_QuestionInfo : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            btnCancel.Attributes.Add("onclick", "return confirm('Are you sure you want to cancel?');");
        }
    }

    public void SetInitialValue(ScorecardTemplateCategory category, ScorecardTemplateQuestion templateQuestion)
    {
        Roles.ApplicationName = Membership.ApplicationName;
        string[] roles = Roles.GetAllRoles();
        typeList.DataSource = roles;
        typeList.DataBind();

        projectTypeList.DataSource = SettingUtility.FindByCriteria(
            ConstantUtility.COMMON_DATASOURCE_NAME,
            SettingManager.FIND_SETTING_BY_TYPE,
            new object[] { "CIPProjectType" });
        projectTypeList.DataBind();

        categoryId.Value = category.Id.ToString();
        if (templateQuestion == null)
        {
            panelTitle.Text = "Add Question for " + category.Name;

            questionId.Value = "0";
            question.Text = "";
            questionSequence.Text = "";

            foreach (ListItem item in typeList.Items)
            {
                item.Selected = false;
            }
        }
        else
        {
            panelTitle.Text = "Edit Question for " + category.Name;

            questionId.Value = templateQuestion.Id.ToString();
            question.Text = templateQuestion.Name;
            questionSequence.Text = templateQuestion.Sequence.ToString();

            if (templateQuestion.UserTypes != null)
            {
                foreach (ListItem li in typeList.Items)
                {
                    foreach (ScorecardTemplateQuestionUserType userType in templateQuestion.UserTypes)
                    {
                        if (userType.UserType == li.Value)
                        {
                            li.Selected = true;
                            if (li.Value == ConstantUtility.ROLE_CAPITAL_PLANNING)
                                projectTypeList.SelectedIndex = projectTypeList.Items.IndexOf(projectTypeList.Items.FindByValue(
                                    userType.Type));
                            break;
                        }
                    }
                }
            }
        }

        ModalPopup_question.Show();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (!Page.IsValid)
        {
            ModalPopup_question.Show();
            return;
        }

        ScorecardTemplateQuestion templateQuestion = null;

        int qId = ConvertUtility.ConvertInt(questionId.Value);
        if (qId > 0)
        {
            templateQuestion = ScorecardTemplateQuestionUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                qId);
        }
        else
        {
            int id = ConvertUtility.ConvertInt(categoryId.Value);
            ScorecardTemplateCategory category = ScorecardTemplateCategoryUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, id);

            templateQuestion = ScorecardTemplateQuestionUtility.CreateObject();
            templateQuestion.TemplateId = category.TemplateId;
            templateQuestion.CategoryId = id;
        }

        templateQuestion.Name = question.Text;
        templateQuestion.Sequence = ConvertUtility.ConvertInt(questionSequence.Text);

        if (qId > 0)
            ScorecardTemplateQuestionUtility.Update(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                templateQuestion);
        else
            ScorecardTemplateQuestionUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                templateQuestion);

        ScorecardTemplateQuestionUserTypeCollection userTypes = new ScorecardTemplateQuestionUserTypeCollection();

        foreach (ListItem li in typeList.Items)
        {
            if (li.Selected)
            {
                ScorecardTemplateQuestionUserType userType = ScorecardTemplateQuestionUserTypeUtility.CreateObject();
                userType.UserType = li.Value;
                if (li.Value == ConstantUtility.ROLE_CAPITAL_PLANNING)
                    userType.Type = projectTypeList.SelectedValue;
                userTypes.Add(userType);
            }
        }

        ScorecardTemplateQuestionUserTypeUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
            templateQuestion.Id, userTypes);

        question.Text = "";
        questionSequence.Text = "";
        questionId.Value = "0";
        categoryId.Value = "0";
        foreach (ListItem item in typeList.Items)
        {
            item.Selected = false;
        }

        PageBase_Initial pagelist = (PageBase_Initial)this.Page;
        pagelist.SetInitialValue();
    }
}
