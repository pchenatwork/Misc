﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Template.Vetting;
using SCA.VAS.ValueObjects.Common;

public partial class Library_Controls_VettingQuestionInfo : System.Web.UI.UserControl
{
    private QuestionTypeCollection questionTypes;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            createPanel.Visible = false;
            btnPreview.Attributes.Add("onclick", "javascript:popup('" + Page.ResolveUrl("~/Library/PreviewQuestion.aspx") + "?Id=" + Request.QueryString["Id"] + "', 600, 500);return false;");
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        createPanel.Visible = true;

        questionId.Value = "0";
        switch (questionTypeList.SelectedItem.Text)
        {
            case QuestionType.SINGLE_LINE_QUESTION:
                header.Visible = false;
                comment.Visible = false;
                common.Visible = true;
                text.Visible = false;
                choice.Visible = false;
                item.Visible = false;
                multi.Visible = false;
                single.Visible = true;
                upload.Visible = false;
                common.SetInitialValue(null);
                text.SetInitialValue(null);
                single.SetInitialValue(null);
                multi.SetInitialValue(null);
                break;
            case QuestionType.MULTI_LINE_QUESTION:
                header.Visible = false;
                comment.Visible = false;
                common.Visible = true;
                text.Visible = false;
                choice.Visible = false;
                item.Visible = false;
                single.Visible = false;
                multi.Visible = true;
                upload.Visible = false;
                common.SetInitialValue(null);
                text.SetInitialValue(null);
                single.SetInitialValue(null);
                multi.SetInitialValue(null);
                break;
            case QuestionType.UPLOAD:
                header.Visible = false;
                comment.Visible = false;
                common.Visible = true;
                text.Visible = false;
                choice.Visible = false;
                item.Visible = false;
                single.Visible = false;
                multi.Visible = false;
                upload.Visible = true;
                common.SetInitialValue(null);
                upload.SetInitialValue(null);
                break;
            case QuestionType.RADIOBUTTON_QUESTION:
            case QuestionType.CHECKBOX_QUESTION:
            case QuestionType.DROPDOWN_MENU:
                header.Visible = false;
                comment.Visible = false;
                common.Visible = true;
                text.Visible = false;
                choice.Visible = false;
                single.Visible = false;
                upload.Visible = false;
                item.Visible = true;
                multi.Visible = false;
                common.SetInitialValue(null);
                choice.SetInitialValue(null);
                VettingAnswerCollection answers = new VettingAnswerCollection();
                for (int i = 1; i <= 5; i++)
                {
                    VettingAnswer answer = VettingAnswerUtility.CreateObject();
                    answer.Sequence = i;
                    answers.Add(answer);
                }
                item.SetInitialValue(answers);
                break;
            case QuestionType.HEADER:
                header.Visible = true;
                comment.Visible = false;
                common.Visible = false;
                text.Visible = false;
                choice.Visible = false;
                single.Visible = false;
                multi.Visible = false;
                upload.Visible = false;
                item.Visible = false;
                header.SetInitialValue(null);
                break;
            case QuestionType.INTERNAL_COMMENT:
                header.Visible = false;
                comment.Visible = true;
                common.Visible = false;
                text.Visible = false;
                choice.Visible = false;
                single.Visible = false;
                multi.Visible = false;
                upload.Visible = false;
                item.Visible = false;
                comment.SetInitialValue(null);
                break;
        }
    }

    protected void updateBtn_Click(object sender, EventArgs e)
    {
        VettingQuestionCollection vettingQuestions = new VettingQuestionCollection();
        foreach (DataGridItem di in questionGrid.Items)
        {
            if (di.ItemType == ListItemType.Item ||
                di.ItemType == ListItemType.AlternatingItem)
            {
                int vettingQuestionId = (int)questionGrid.DataKeys[di.ItemIndex];

                TextBox vettingQuestionSequence = (TextBox)di.FindControl("questionSequenceTxt");
                HiddenField vettingQuestionParentId = (HiddenField)di.FindControl("parentId");
                VettingQuestion vettingQuestion = VettingQuestionUtility.CreateObject();
                vettingQuestion.Id = vettingQuestionId;
                vettingQuestion.Sequence = Convert.ToInt32(vettingQuestionSequence.Text);
                vettingQuestion.ParentId = Convert.ToInt32(vettingQuestionParentId.Value);
                vettingQuestions.Add(vettingQuestion);
            }
        }

        // Update Questions' Sequence
        VettingQuestion interQuestion = VettingQuestionUtility.CreateObject();
        for (int i = 0; i < vettingQuestions.Count - 1; i++)
        {
            for (int j = vettingQuestions.Count - 1; j > i; j--)
            {
                if (vettingQuestions[j].Sequence < vettingQuestions[j - 1].Sequence)
                {
                    interQuestion = vettingQuestions[j];
                    vettingQuestions[j] = vettingQuestions[j - 1];
                    vettingQuestions[j - 1] = interQuestion;
                }
            }
        }

        for (int i = 0; i < vettingQuestions.Count; i++)
        {
            vettingQuestions[i].Sequence = i + 1;
        }

        VettingQuestionUtility.UpdateSequence(ConstantUtility.TEMPLATE_DATASOURCE_NAME, vettingQuestions);

        SetInitialValue();
    }

    protected void DeleteItem(object source, DataGridCommandEventArgs e)
    {
        int id = (int)questionGrid.DataKeys[e.Item.ItemIndex];

        VettingQuestionUtility.Delete(ConstantUtility.TEMPLATE_DATASOURCE_NAME, id);

        createPanel.Visible = false;

        SetInitialValue();
    }

    protected void ItemCommand(object source, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Copy")
        {
            int id = (int)questionGrid.DataKeys[e.Item.ItemIndex];

            VettingQuestionUtility.Copy(ConstantUtility.TEMPLATE_DATASOURCE_NAME, id);

            SetInitialValue();
        }
    }

    protected void BindItem(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            e.Item.Attributes.Add("onmouseover", "this.className='datagridSelectedItem'");
            e.Item.Attributes.Add("onmouseout", "if(this.rowIndex % 2 == 1)this.className='datagridItem';else this.className='datagridAlternateItem';");

            HtmlGenericControl actionsSet = (HtmlGenericControl)e.Item.FindControl("actionsSet");
            HtmlGenericControl actionsMenuSet = (HtmlGenericControl)e.Item.FindControl("actionsMenuSet");
            actionsSet.Attributes.Add("onmouseover", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');getElement('" + actionsMenuSet.ClientID + "').style.width=(this.offsetWidth-2)+'px';this.className='actionsSet_Over';");
            actionsSet.Attributes.Add("onmouseout", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');this.className='actionsSet_Up';");

            TextBox localSequence = (TextBox)e.Item.FindControl("questionSequenceTxt");
            localSequence.Attributes.Add("onfocus", "toggleFieldStyle(this);");
            localSequence.Attributes.Add("onblur", "toggleFieldStyle(this);");
            localSequence.Attributes.Add("onchange", "moveQuestionRow(this);");

            LinkButton copyButton = (LinkButton)e.Item.FindControl("copyQuestionBtn");
            copyButton.Attributes.Add("onclick", "return confirm('Are you sure you want to copy this question?');");
            LinkButton deleteButton = (LinkButton)e.Item.FindControl("deleteLink");
            deleteButton.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this question?');");
        }
    }

    public void SetInitialValue()
    {
        questionTypeList.DataSource = questionTypes;
        questionTypeList.DataBind();

        int vettingId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        VettingList vetting = VettingListUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
            vettingId);

        if (vetting.Questions != null && vetting.Questions.Count > 0)
        {
            questionGrid.Visible = true;
            questionGrid.DataSource = vetting.Questions;
            questionGrid.DataBind();
        }
        else
        {
            questionGrid.Visible = false;
        }
    }

    protected void UpdateItem(object source, DataGridCommandEventArgs e)
    {
        createPanel.Visible = true;

        int id = (int)questionGrid.DataKeys[e.Item.ItemIndex];

        VettingQuestion question = VettingQuestionUtility.Get(
            ConstantUtility.TEMPLATE_DATASOURCE_NAME, id);

        switch (question.QuestionType)
        {
            case QuestionType.SINGLE_LINE_QUESTION:
                header.Visible = false;
                comment.Visible = false;
                common.Visible = true;
                text.Visible = true;
                choice.Visible = false;
                item.Visible = false;
                multi.Visible = false;
                single.Visible = true;
                upload.Visible = false;
                common.SetInitialValue(question);
                text.SetInitialValue(question);
                single.SetInitialValue(question);
                multi.SetInitialValue(question);
                break;
            case QuestionType.MULTI_LINE_QUESTION:
                header.Visible = false;
                comment.Visible = false;
                common.Visible = true;
                text.Visible = true;
                choice.Visible = false;
                item.Visible = false;
                single.Visible = false;
                multi.Visible = true;
                upload.Visible = false;
                common.SetInitialValue(question);
                text.SetInitialValue(question);
                single.SetInitialValue(question);
                multi.SetInitialValue(question);
                break;
            case QuestionType.UPLOAD:
                header.Visible = false;
                comment.Visible = false;
                common.Visible = true;
                text.Visible = false;
                choice.Visible = false;
                item.Visible = false;
                single.Visible = false;
                multi.Visible = false;
                upload.Visible = true;
                common.SetInitialValue(question);
                upload.SetInitialValue(question);
                break;
            case QuestionType.RADIOBUTTON_QUESTION:
            case QuestionType.CHECKBOX_QUESTION:
            case QuestionType.DROPDOWN_MENU:
                header.Visible = false;
                comment.Visible = false;
                common.Visible = true;
                text.Visible = false;
                choice.Visible = true;
                single.Visible = false;
                upload.Visible = false;
                item.Visible = true;
                multi.Visible = false;
                common.SetInitialValue(question);
                choice.SetInitialValue(question);
                item.SetInitialValue(question.Answers);
                break;
            case QuestionType.HEADER:
                header.Visible = true;
                comment.Visible = false;
                common.Visible = false;
                text.Visible = false;
                choice.Visible = false;
                single.Visible = false;
                multi.Visible = false;
                upload.Visible = false;
                item.Visible = false;
                header.SetInitialValue(question);
                break;
            case QuestionType.INTERNAL_COMMENT:
                header.Visible = false;
                comment.Visible = true;
                common.Visible = false;
                text.Visible = false;
                choice.Visible = false;
                single.Visible = false;
                multi.Visible = false;
                upload.Visible = false;
                item.Visible = false;
                comment.SetInitialValue(question);
                break;
        }
        questionId.Value = id.ToString();
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        int vettingId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);

        int id = ConvertUtility.ConvertInt(questionId.Value);
        if (id > 0)
        {
            VettingQuestion vettingQuestion = VettingQuestionUtility.Get(
                ConstantUtility.TEMPLATE_DATASOURCE_NAME, id);

            switch (vettingQuestion.QuestionType)
            {
                case QuestionType.SINGLE_LINE_QUESTION:
                    vettingQuestion.QuestionTypeId = text.QuestionTypeId;
                    vettingQuestion.QuestionText = common.QuestionText;
                    vettingQuestion.QuestionName = common.QuestionName;
                    vettingQuestion.IsActive = common.IsActive;
                    vettingQuestion.IsRequired = common.IsRequired;
                    vettingQuestion.AnswerFormat = single.AnswerFormat;
                    vettingQuestion.DefaultValue = single.DefaultValue;
                    vettingQuestion.MaxValue = single.MaxValue;
                    vettingQuestion.MinValue = single.MinValue;
                    vettingQuestion.Attachments = common.Attachments;
                    break;
                case QuestionType.MULTI_LINE_QUESTION:
                    vettingQuestion.QuestionTypeId = text.QuestionTypeId;
                    vettingQuestion.QuestionText = common.QuestionText;
                    vettingQuestion.QuestionName = common.QuestionName;
                    vettingQuestion.IsRequired = common.IsRequired;
                    vettingQuestion.IsActive = common.IsActive;
                    vettingQuestion.DefaultValue = multi.DefaultValue;
                    vettingQuestion.Attachments = common.Attachments;
                    break;
                case QuestionType.UPLOAD:
                    vettingQuestion.QuestionText = common.QuestionText;
                    vettingQuestion.QuestionName = common.QuestionName;
                    vettingQuestion.IsRequired = common.IsRequired;
                    vettingQuestion.IsActive = common.IsActive;
                    vettingQuestion.DefaultValue = upload.FileExtensions;
                    vettingQuestion.Attachments = common.Attachments;
                    break;
                case QuestionType.RADIOBUTTON_QUESTION:
                case QuestionType.CHECKBOX_QUESTION:
                case QuestionType.DROPDOWN_MENU:
                    vettingQuestion.QuestionTypeId = choice.QuestionTypeId;
                    vettingQuestion.QuestionName = common.QuestionName;
                    vettingQuestion.QuestionText = common.QuestionText;
                    vettingQuestion.IsActive = common.IsActive;
                    vettingQuestion.IsRequired = common.IsRequired;
                    vettingQuestion.Answers = item.Answers;
                    vettingQuestion.Attachments = common.Attachments;
                    break;
                case QuestionType.HEADER:
                    vettingQuestion.QuestionText = header.QuestionText;
                    vettingQuestion.IsActive = header.IsActive;
                    vettingQuestion.Attachments = header.Attachments;
                    break;
                case QuestionType.INTERNAL_COMMENT:
                    vettingQuestion.QuestionText = comment.QuestionText;
                    vettingQuestion.IsActive = comment.IsActive;
                    vettingQuestion.Attachments = comment.Attachments;
                    break;
            }

            VettingQuestionUtility.UpdateVettingQuestion(ConstantUtility.TEMPLATE_DATASOURCE_NAME, vettingQuestion);
        }
        else
        {
            VettingList vetting = VettingListUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
                vettingId);

            VettingQuestion vettingQuestion = VettingQuestionUtility.CreateObject();

            vettingQuestion.VettingId = vettingId;
            if (vetting.Questions == null)
                vettingQuestion.Sequence = 1;
            else
                vettingQuestion.Sequence = vetting.Questions.Count + 1;
            vettingQuestion.QuestionTypeId = ConvertUtility.ConvertInt(questionTypeList.SelectedValue);

            switch (questionTypeList.SelectedItem.Text)
            {
                case QuestionType.SINGLE_LINE_QUESTION:
                    vettingQuestion.QuestionText = common.QuestionText;
                    vettingQuestion.QuestionName = common.QuestionName;
                    vettingQuestion.IsRequired = common.IsRequired;
                    vettingQuestion.IsActive = common.IsActive;
                    vettingQuestion.AnswerFormat = single.AnswerFormat;
                    vettingQuestion.DefaultValue = single.DefaultValue;
                    vettingQuestion.MaxValue = single.MaxValue;
                    vettingQuestion.MinValue = single.MinValue;
                    vettingQuestion.Attachments = common.Attachments;
                    break;
                case QuestionType.MULTI_LINE_QUESTION:
                    vettingQuestion.QuestionText = common.QuestionText;
                    vettingQuestion.QuestionName = common.QuestionName;
                    vettingQuestion.IsRequired = common.IsRequired;
                    vettingQuestion.IsActive = common.IsActive;
                    vettingQuestion.DefaultValue = multi.DefaultValue;
                    vettingQuestion.Attachments = common.Attachments;
                    break;
                case QuestionType.UPLOAD:
                    vettingQuestion.QuestionText = common.QuestionText;
                    vettingQuestion.QuestionName = common.QuestionName;
                    vettingQuestion.IsRequired = common.IsRequired;
                    vettingQuestion.IsActive = common.IsActive;
                    vettingQuestion.DefaultValue = upload.FileExtensions;
                    vettingQuestion.Attachments = common.Attachments;
                    break;
                case QuestionType.RADIOBUTTON_QUESTION:
                case QuestionType.CHECKBOX_QUESTION:
                case QuestionType.DROPDOWN_MENU:
                    vettingQuestion.QuestionText = common.QuestionText;
                    vettingQuestion.QuestionName = common.QuestionName;
                    vettingQuestion.IsRequired = common.IsRequired;
                    vettingQuestion.IsActive = common.IsActive;
                    vettingQuestion.Answers = item.Answers;
                    vettingQuestion.Attachments = common.Attachments;
                    break;
                case QuestionType.HEADER:
                    vettingQuestion.QuestionText = header.QuestionText;
                    vettingQuestion.IsActive = header.IsActive;
                    vettingQuestion.Attachments = header.Attachments;
                    break;
                case QuestionType.INTERNAL_COMMENT:
                    vettingQuestion.QuestionText = comment.QuestionText;
                    vettingQuestion.IsActive = comment.IsActive;
                    vettingQuestion.Attachments = comment.Attachments;
                    break;
            }

            VettingQuestionUtility.CreateVettingQuestion(ConstantUtility.TEMPLATE_DATASOURCE_NAME, vettingQuestion);
        }

        createPanel.Visible = false;
        SetInitialValue();
    }

    protected void btnCancelUpdate_Click(object sender, EventArgs e)
    {
        createPanel.Visible = false;
    }

    override protected void OnInit(EventArgs e)
    {
        questionTypes = QuestionTypeUtility.FindByCriteria(
            ConstantUtility.COMMON_DATASOURCE_NAME,
            QuestionTypeManager.FIND_QUESTIONTYPE_BY_CATEGORY,
            new object[] { QuestionType.VETTING, QuestionType.TOP_LEVEL_QUESTION });
        base.OnInit(e);
    }
}