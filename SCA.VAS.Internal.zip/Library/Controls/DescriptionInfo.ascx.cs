﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template;
using SCA.VAS.ValueObjects.Scorecard.Template;

public partial class Library_Controls_DescriptionInfo : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //btnCancel.Attributes.Add("onclick", "return confirm('Are you sure you want to cancel?');");
        }
    }

    public void SetInitialValue(int categoryId)
    {
        ScorecardTemplateCategory templateCategory = ScorecardTemplateCategoryUtility.Get(
            ConstantUtility.SCORECARD_DATASOURCE_NAME, categoryId);
        if (templateCategory != null)
            categoryName.Text = templateCategory.Name;

        CategoryId.Value = categoryId.ToString();

        panelTitle.Text = "Extenuating Circumstances";

        ScorecardCategoryDescriptionCollection descriptions = ScorecardCategoryDescriptionUtility.FindByCriteria(
            ConstantUtility.SCORECARD_DATASOURCE_NAME,
            ScorecardCategoryDescriptionManager.FIND_BY_CATEGORY,
            new object[] { categoryId });
        if (descriptions == null)
            descriptions = new ScorecardCategoryDescriptionCollection();
        for (int i = descriptions.Count; i < 5; i++)
        {
            ScorecardCategoryDescription description = ScorecardCategoryDescriptionUtility.CreateObject();
            descriptions.Add(description);
        }
        descriptionGrid.DataSource = descriptions;
        descriptionGrid.DataBind();

        ModalPopup_description.Show();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        ScorecardCategoryDescriptionCollection descriptions = new ScorecardCategoryDescriptionCollection();

        foreach (DataGridItem item in descriptionGrid.Items)
        {
            if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
            {
                int id = (int)descriptionGrid.DataKeys[item.ItemIndex];
                TextBox name = (TextBox)item.FindControl("name");

                ScorecardCategoryDescription description = ScorecardCategoryDescriptionUtility.CreateObject();
                description.Id = id;
                description.Name = name.Text;
                description.Value = name.Text;
                descriptions.Add(description);
            }
        }

        for (int i = 0; i < 3; i++)
        {
            ScorecardCategoryDescription description = ScorecardCategoryDescriptionUtility.CreateObject();
            descriptions.Add(description);
        }
        descriptionGrid.DataSource = descriptions;
        descriptionGrid.DataBind();

        ModalPopup_description.Show();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int categoryId = ConvertUtility.ConvertInt(CategoryId.Value);
        ScorecardCategoryDescriptionCollection descriptions = new ScorecardCategoryDescriptionCollection();

        foreach (DataGridItem item in descriptionGrid.Items)
        {
            if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
            {
                int id = (int)descriptionGrid.DataKeys[item.ItemIndex];
                TextBox name = (TextBox)item.FindControl("name");

                if (name.Text.Trim().Length > 0)
                {
                    ScorecardCategoryDescription description = ScorecardCategoryDescriptionUtility.CreateObject();
                    description.Id = id;
                    description.Name = name.Text;
                    description.Value = name.Text;
                    descriptions.Add(description);
                }
            }
        }

        ScorecardCategoryDescriptionUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
            categoryId, descriptions);

        PageBase_Initial pagelist = (PageBase_Initial)this.Page;
        pagelist.SetInitialValue();
    }
}
