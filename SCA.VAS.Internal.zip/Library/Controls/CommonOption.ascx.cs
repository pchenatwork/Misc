#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Configuration;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.ValueObjects.Template.Vetting;
#endregion

public partial class Global_Controls_CommonOption : System.Web.UI.UserControl
{
    #region Public Property
    public string QuestionText
    {
        get
        {
            return questionTxt.Text;
        }
    }
    public string QuestionName
    {
        get
        {
            return questionName.Text;
        }
    }
    public string IsRequired
    {
        get 
        { 
            return requiredCheck.Checked ? "Y" : "N"; 
        }
    }
    public string IsActive
    {
        get 
        { 
            return isActive.Checked ? "Y" : "N"; 
        }
    }
    public VettingAttachmentCollection Attachments
    {
        get
        {
            VettingAttachmentCollection attachments = new VettingAttachmentCollection();
            foreach (DataGridItem item in attachmentGrid.Items)
            {
                if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
                {
                    TextBox localText = (TextBox)item.FindControl("description");
                    HtmlInputFile localFile = (HtmlInputFile)item.FindControl("uploadFile");

                    if (localFile != null)
                    {
                        string filename = Path.GetFileName(localFile.PostedFile.FileName);

                        if (filename.Trim().Length > 0)
                        {
                            VettingAttachment vettingAttachment = VettingAttachmentUtility.CreateObject();

                            vettingAttachment.Filename = filename;
                            vettingAttachment.Description = localText.Text;

                            byte[] attachment = new byte[localFile.PostedFile.InputStream.Length];
                            localFile.PostedFile.InputStream.Read(attachment, 0, (int)localFile.PostedFile.InputStream.Length);
                            vettingAttachment.Attachment = attachment;

                            attachments.Add(vettingAttachment);
                        }
                        else
                        {
                            int attachmentId = (int)attachmentGrid.DataKeys[item.ItemIndex];
                            if (attachmentId > 0)
                            {
                                VettingAttachment vettingAttachment = VettingAttachmentUtility.CreateObject();

                                vettingAttachment.Id = attachmentId;
                                vettingAttachment.Description = localText.Text;

                                attachments.Add(vettingAttachment);
                            }
                        }
                    }
                }
            }
            return attachments;
        }
    }
    #endregion

    #region Public Method
    public void SetInitialValue(VettingQuestion question)
    {
        VettingAttachmentCollection attachments;
        if (question != null && question.Attachments != null)
            attachments = question.Attachments;
        else
            attachments = new VettingAttachmentCollection();
        if (attachments != null && attachments.Count > 0)
        {
            attachmentGrid.Style.Add("display", "");
            attachment.Checked = true;
        }
        else
        {
            attachmentGrid.Style.Add("display", "none");
            attachment.Checked = false;
        }
        attachments.Add(VettingAttachmentUtility.CreateObject());

        attachmentGrid.DataSource = attachments;
        attachmentGrid.DataBind();

        if (question != null)
        {
            questionTxt.Text = question.QuestionText;
            questionName.Text = question.QuestionName;
            requiredCheck.Checked = (question.IsRequired == "Y");
            isActive.Checked = (question.IsActive == "Y");
        }
        else
        {
            questionTxt.Text = "";
            questionName.Text = "";
            isActive.Checked = true;
        }
    }
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            attachment.Attributes.Add("onclick", "javascript:CheckAttachment(this);");
        }
    }

    protected void BindItem(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            VettingAttachment vettingAttachment = (VettingAttachment)e.Item.DataItem;
            
            TextBox localText = (TextBox)e.Item.FindControl("description");
            LinkButton localLink = (LinkButton)e.Item.FindControl("attachmentLink");
            LinkButton localButton = (LinkButton)e.Item.FindControl("deleteattachment");
            localButton.Attributes.Add("onclick", "javascript:return confirm('Are you sure you want to delete " + vettingAttachment.Filename.Replace("'", "\\'") + "?')");

            localText.Text = vettingAttachment.Description;

            if (vettingAttachment.Filename.Trim() != "")
            {
                localLink.Visible = true;
                localButton.Visible = true;
            }
        }
    }

    protected void ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Delete")
        {
            int attachmentId = (int)attachmentGrid.DataKeys[e.Item.ItemIndex];
            if (VettingAttachmentUtility.Delete(ConstantUtility.TEMPLATE_DATASOURCE_NAME, attachmentId))
            {
                LinkButton localLink = (LinkButton)e.Item.FindControl("attachmentLink");
                LinkButton localButton = (LinkButton)e.Item.FindControl("deleteattachment");
                TextBox localText = (TextBox)e.Item.FindControl("description");

                localLink.Visible = false;
                localButton.Visible = false;
                localText.Text = string.Empty;
            }
        }
        else if (e.CommandName == "View")
        {
            int attachmentId = (int)attachmentGrid.DataKeys[e.Item.ItemIndex];
            VettingAttachment vettingAttachment = VettingAttachmentUtility.Get(
                ConstantUtility.TEMPLATE_DATASOURCE_NAME, attachmentId);
            byte[] attachment = VettingAttachmentUtility.GetAttachment(
                ConstantUtility.TEMPLATE_DATASOURCE_NAME, attachmentId);

            Response.ContentType = "application/octet-stream";
            Response.AppendHeader("content-disposition",
                "attachment; filename=" + vettingAttachment.Filename);
            Response.BinaryWrite(attachment);
            Response.End();
        }
    }
    #endregion
}
