﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template;
using SCA.VAS.ValueObjects.Scorecard.Template;

public partial class Library_Controls_CategoryInfo : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            btnCancel.Attributes.Add("onclick", "return confirm('Are you sure you want to cancel?');");
        }
    }

    public void SetInitialValue(ScorecardTemplate template, ScorecardTemplateCategory category)
    {
        templateId.Value = template.Id.ToString();
        typeTr.Visible = template.Country.Trim().Length > 0;

        if (typeTr.Visible)
        {
            typeList.DataSource = CommonUtility.GetSettings("CIPProjectDuration.xml");
            typeList.DataBind();
            typeList.Items.Insert(0, new ListItem("Select One", ""));
        }

        if (category != null)
        {
            name.Text = category.Name;
            weight.Text = category.Weight.ToString();
            sequence.Text = category.Sequence.ToString();
            categoryId.Value = category.Id.ToString();
            if (typeTr.Visible)
                typeList.SelectedIndex = typeList.Items.IndexOf(typeList.Items.FindByValue(
                    category.Type));
        }
        else
            categoryId.Value = "0";

        ModalPopup_category.Show();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (!Page.IsValid)
        {
            ModalPopup_category.Show();
            return;
        }

        int id = ConvertUtility.ConvertInt(templateId.Value);
        ScorecardTemplateCategory scorecardTemplateCategory = null;

        int cId = ConvertUtility.ConvertInt(categoryId.Value);
        if (cId > 0)
            scorecardTemplateCategory = ScorecardTemplateCategoryUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, cId);
        else
        {
            scorecardTemplateCategory = ScorecardTemplateCategoryUtility.CreateObject();
            scorecardTemplateCategory.TemplateId = id;
        }

        scorecardTemplateCategory.Name = name.Text;
        scorecardTemplateCategory.Weight = ConvertUtility.ConvertInt(weight.Text);
        scorecardTemplateCategory.Sequence = ConvertUtility.ConvertInt(sequence.Text);
        if (typeTr.Visible)
            scorecardTemplateCategory.Type = typeList.SelectedValue;

        if (cId > 0)
            ScorecardTemplateCategoryUtility.Update(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardTemplateCategory);
        else

            ScorecardTemplateCategoryUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME,
                scorecardTemplateCategory);

        name.Text = "";
        weight.Text = "";
        sequence.Text = "";
        categoryId.Value = "0";

        PageBase_Initial pagelist = (PageBase_Initial)this.Page;
        pagelist.SetInitialValue();
    }
}
