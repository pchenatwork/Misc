#region Copyright
/*=======================================================================
*
* Modification History:
* Date       Programmer Description
* 03-25-2005 Lily Xiong Product & Service Section for Supplier Form
*
*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;
using System.Web.Security;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.ValueObjects.Scorecard.Template;
#endregion

public partial class TemplateInfo : System.Web.UI.UserControl
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            btnCancel.Attributes.Add("onclick", "return confirm('Are you sure you want to cancel?');");

            description.Attributes.Add("onKeyUp", "javascript:limitLength( this, 500 );");
        }
    }
    #endregion

    #region Public Method
    public void SetInitialValue(ScorecardTemplate template)
    {
        typeList.DataSource = CommonUtility.GetSettings("TemplateType.xml");
        typeList.DataBind();
        if (template != null)
        {
            panelTitle.Text = "Edit Template";
            templateId.Value = template.Id.ToString();
            name.Text = template.Name;
            description.Text = template.Description;
            typeList.SelectedIndex = typeList.Items.IndexOf(typeList.Items.FindByValue(template.Type));
        }
        else
        {
            panelTitle.Text = "Add New Template";
            templateId.Value = "0";
            name.Text = "";
            description.Text = "";
            typeList.SelectedIndex = -1;
        }

        ModalPopup_template.Show();
    }
    #endregion

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int id = ConvertUtility.ConvertInt(templateId.Value);

        ScorecardTemplate scorecardTemplate;
        if (id > 0)
            scorecardTemplate = ScorecardTemplateUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, id);
        else
            scorecardTemplate = ScorecardTemplateUtility.CreateObject();

        scorecardTemplate.Name = name.Text;
        scorecardTemplate.Description = description.Text;
        scorecardTemplate.Type = typeList.SelectedValue;
        scorecardTemplate.UserId = ((PageBase)Page).UserId;
        scorecardTemplate.ChangeUser = ((PageBase)Page).UserName;

        if (id > 0)
            ScorecardTemplateUtility.Update(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardTemplate);
        else
            ScorecardTemplateUtility.Create(ConstantUtility.SCORECARD_DATASOURCE_NAME, scorecardTemplate);

        PageBase_Initial pagelist = (PageBase_Initial)this.Page;
        pagelist.SetInitialValue();
    }
}
