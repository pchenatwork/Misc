#region Reference
using System;
using System.Configuration;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.WebControls;
using SCA.VAS.Workflow;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.ValueObjects.Template.Vetting;
#endregion

public partial class Global_Controls_VettingDetail : System.Web.UI.UserControl
{
    #region Public Method
    public void SetInitialValue(VettingList vetting)
    {
        if (vetting != null)
        {
            name.Text = vetting.Name;
            type.Text = vetting.Type;
            description.Text = vetting.Description;
            workflowName.Text = vetting.WorkflowName;
            if (vetting.HasExpireDate == "Y")
                options.Text = "Has Expiration Date<br />";
            if (vetting.InternalUse == "Y")
                options.Text += "Internal User";

            if (vetting.HasSchedule == "Y")
            {
                schedule.Visible = true;

                VettingSchedule vettingSchedule = VettingScheduleUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
                    vetting.Id);
                scheduleInfo.Text = CommonUtility.GetScheduleInfo(vettingSchedule);
            }

            rfxControl.ShowSequence = false;
            rfxControl.ShowAttachment = true;
            rfxControl.ShowQuestionName = false;
            rfxControl.TypeField = RfxControl.CONTROL_TYPE_DISPLAY;
            rfxControl.DisplayType = RfxControl.DISPLAY_TYPE_INTERNAL;
            rfxControl.AttachmentUrlIndicator = "~/Library/GetVettingAttachment.ashx";
            rfxControl.DataSource = vetting.Questions;
            rfxControl.DataBind();
        }
    }
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }
    #endregion Web Event Handler
}
