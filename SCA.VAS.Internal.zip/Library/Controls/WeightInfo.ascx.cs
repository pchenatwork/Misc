﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template;
using SCA.VAS.ValueObjects.Scorecard.Template;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

public partial class Library_Controls_WeightInfo : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            btnCancel.Attributes.Add("onclick", "return confirm('Are you sure you want to cancel?');");
        }
    }

    protected void BindItem(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ScorecardTemplateUserType scorecardTemplateUserType = (ScorecardTemplateUserType)e.Item.DataItem;

            DropDownList typeList = (DropDownList)e.Item.FindControl("typeList");
            typeList.DataSource = SettingUtility.FindByCriteria(
                ConstantUtility.COMMON_DATASOURCE_NAME,
                SettingManager.FIND_SETTING_BY_TYPE,
                new object[] { "CIPProjectType" });
            typeList.DataBind();
            typeList.SelectedIndex = typeList.Items.IndexOf(typeList.Items.FindByValue(
                scorecardTemplateUserType.Type));

            DropDownList userList = (DropDownList)e.Item.FindControl("userList");
            UserCollection users = UserUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                UserManager.FIND_USER_BY_TYPE,
                new object[] 
				{ 
					0,
					0,
					"Name",
					"ASC",
					scorecardTemplateUserType.UserType
				});

            userList.DataSource = users;
            userList.DataBind();
            userList.Items.Insert(0, new ListItem("Select One", ""));
            userList.SelectedIndex = userList.Items.IndexOf(userList.Items.FindByValue(
                scorecardTemplateUserType.UserId.ToString()));
        }
    }

    public void SetInitialValue(ScorecardTemplate template, ScorecardTemplateCategory category)
    {
        errormessage.Visible = false;
        weightTitle.Text = "Evaluators Weight for " + category.Name;
        categoryId.Value = category.Id.ToString();

        ScorecardTemplateUserTypeCollection userTypes =
            ScorecardTemplateUserTypeUtility.FindByCriteria(
            ConstantUtility.SCORECARD_DATASOURCE_NAME,
            ScorecardTemplateUserTypeManager.FIND_SCORECARDTEMPLATEUSERTYPE,
            new object[] { category.Id, "" });
        userTypeGrid.DataSource = userTypes;
        userTypeGrid.DataBind();

        userTypeGrid.Columns[1].Visible = (template.Country.Trim().Length > 0);

        ModalPopup_weight.Show();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (!Page.IsValid)
        {
            ModalPopup_weight.Show();
            return;
        }

        int id = ConvertUtility.ConvertInt(categoryId.Value);

        ScorecardTemplateCategory category = ScorecardTemplateCategoryUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME,
            id);
        ScorecardTemplate template = ScorecardTemplateUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME,
            category.TemplateId);

        ScorecardTemplateUserTypeCollection userTypes = new ScorecardTemplateUserTypeCollection();

        int totalWeight = 0;
        foreach (DataGridItem qi in userTypeGrid.Items)
        {
            if (qi.ItemType == ListItemType.Item || qi.ItemType == ListItemType.AlternatingItem)
            {
                DropDownList typeList = (DropDownList)qi.FindControl("typeList");
                DropDownList userList = (DropDownList)qi.FindControl("userList");
                TextBox weight = (TextBox)qi.FindControl("weight");
                ScorecardTemplateUserType userType = ScorecardTemplateUserTypeUtility.CreateObject();
                if (template.Country.Trim().Length > 0)
                    userType.Type = typeList.SelectedValue;
                userType.UserType = userTypeGrid.DataKeys[qi.ItemIndex].ToString();
                userType.UserId = ConvertUtility.ConvertInt(userList.SelectedValue);
                userType.Weight = ConvertUtility.ConvertInt(weight.Text);
                if (userType.Weight > 0)
                {
                    userTypes.Add(userType);
                    totalWeight += userType.Weight;
                }
            }
        }

        if (template.Country.Trim().Length == 0 && totalWeight != 100)
        {
            errormessage.Visible = true;
            ModalPopup_weight.Show();
            return;
        }

        ScorecardTemplateUserTypeUtility.UpdateCollection(ConstantUtility.SCORECARD_DATASOURCE_NAME,
            id, userTypes);

        PageBase_Initial pagelist = (PageBase_Initial)this.Page;
        pagelist.SetInitialValue();
    }
}
