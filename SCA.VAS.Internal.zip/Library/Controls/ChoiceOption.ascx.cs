#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.ValueObjects.Template.Vetting;
using SCA.VAS.Common.Utilities;
#endregion

public partial class Global_Controls_ChoiceOption : System.Web.UI.UserControl
{
    #region Public Property
    public int QuestionTypeId
    {
        get
        {
            return ConvertUtility.ConvertInt(typeList.SelectedValue);
        }
    }
    #endregion

    #region Public Method
    public void SetInitialValue(VettingQuestion question)
    {
        QuestionTypeCollection typeCollection = QuestionTypeUtility.FindByCriteria(
            ConstantUtility.COMMON_DATASOURCE_NAME,
            QuestionTypeManager.FIND_QUESTIONTYPE_BY_CATEGORY,
            new object[] { QuestionType.VETTING, QuestionType.TOP_LEVEL_QUESTION });
        typeList.Items.Clear();
        for (int i = 0; i < typeCollection.Count; i++)
        {
            if (typeCollection[i].Type == QuestionType.DROPDOWN_MENU ||
                typeCollection[i].Type == QuestionType.RADIOBUTTON_QUESTION ||
                typeCollection[i].Type == QuestionType.CHECKBOX_QUESTION)
            {
                typeList.Items.Add(new ListItem(typeCollection[i].Type, typeCollection[i].Id.ToString()));
            }
        }

        if (question != null)
        {
            typeList.SelectedIndex = typeList.Items.IndexOf(typeList.Items.FindByText(question.QuestionType));
        }
    }
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }
    #endregion
}