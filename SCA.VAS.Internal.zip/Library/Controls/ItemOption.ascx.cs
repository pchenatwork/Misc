#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.ValueObjects.Template.Vetting;
using SCA.VAS.Common.Utilities;
#endregion

public partial class Global_Controls_ItemOption : System.Web.UI.UserControl
{
    #region Public Property
    public VettingAnswerCollection Answers
    {
        get
        {
            VettingAnswerCollection answers = new VettingAnswerCollection();
            foreach (DataGridItem item in answerGrid.Items)
            {
                if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
                {
                    TextBox localSequence = (TextBox)item.FindControl("sequenceTxt");
                    TextBox localAnswerText = (TextBox)item.FindControl("answerTxt");
                    TextBox localAnswerValue = (TextBox)item.FindControl("answerValue");
                    DropDownList localType = (DropDownList)item.FindControl("factorType");
                    CheckBox localWith = (CheckBox)item.FindControl("extraCheck");
                    CheckBox localDelete = (CheckBox)item.FindControl("deleteCheck");
                    if (!localDelete.Checked && localAnswerText.Text.Trim().Length > 0)
                    {
                        VettingAnswer answer = VettingAnswerUtility.CreateObject();
                        answer.Id = (int)answerGrid.DataKeys[item.ItemIndex];
                        answer.Sequence = ConvertUtility.ConvertInt(localSequence.Text);
                        answer.AnswerText = localAnswerText.Text;
                        answer.AnswerValue = localAnswerValue.Text;
                        answer.AnswerType = localWith.Checked ? VettingAnswer.WITH_TEXTBOX : "";
                        answers.Add(answer);
                    }
                }
            }
            return answers;
        }
    }
    #endregion

    #region Public Method
    public void HideTextBox()
    {
        answerGrid.Columns[4].Visible = false;
    }

    public void SetInitialValue(VettingAnswerCollection answers)
    {
        answerGrid.DataSource = answers;
        answerGrid.DataBind();
    }
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {

    }

    protected void btnUpdate_Click(object sender, System.EventArgs e)
    {
        VettingAnswerCollection answers = Answers;
        SetInitialValue(answers);
    }

    protected void btnAddRow_Click(object sender, System.EventArgs e)
    {
        VettingAnswerCollection answers = Answers;
        int count = answers.Count + 1;
        for (int i = count; i < count + 5; i++)
        {
            VettingAnswer answer = VettingAnswerUtility.CreateObject();
            answer.Sequence = i;
            answers.Add(answer);
        }
        SetInitialValue(answers);
    }
    #endregion
}