#region Reference
using System;
using System.Configuration;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;

using AjaxControlToolkit;
using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting;
using SCA.VAS.ValueObjects.Template.Vetting;
#endregion

public partial class Global_VettingExplorer : System.Web.UI.UserControl
{

    #region Public Property
    public int ParentId
    {
        get
        {
            return ConvertUtility.ConvertInt(ViewState["ParentId"].ToString());
        }
    }
    #endregion

    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    public void SetInitialValue(int parentId, string moveType)
    {
        ViewState["ParentId"] = parentId;

        type.Value = moveType;

        TreeView1.Nodes.Clear();
        BuildTree(parentId);
        CommonUtility.ExpandAll(TreeView1.SelectedNode);
    }

    private void BuildTree(int parentId)
    {
        // Create a root node
        TreeNode root = new TreeNode("Global Vetting Library", "0");
        if (parentId == 0)
        {
            root.Selected = true;
        }

        // Add children to the root node
        VettingLibraryCollection libraries = VettingLibraryUtility.FindByCriteria(
            ConstantUtility.TEMPLATE_DATASOURCE_NAME,
            VettingLibraryManager.FIND_VETTINGLIBRARY,
            new object[] { 0 } );
        BuildVettingTree(libraries, root, parentId);

        // Add root node to TreeView
        TreeView1.Nodes.Add(root);
    }

    private void BuildVettingTree(VettingLibraryCollection libraries, TreeNode node, int parentId)
    {
        if (libraries == null) return;

        foreach (VettingLibrary vettingLibrary in libraries)
        {
            TreeNode n1 = new TreeNode(vettingLibrary.Name, vettingLibrary.Id.ToString());
            node.ChildNodes.Add(n1);
            if (vettingLibrary.Id == parentId)
            {
                n1.Selected = true;
            }
            if (vettingLibrary.SubLibraries != null)
            {
                BuildVettingTree(vettingLibrary.SubLibraries, n1, parentId);
            }
        }
    }

    protected void NodeChange(object sender, System.EventArgs e)
    {
        ViewState["ParentId"] = TreeView1.SelectedNode.Value;

        if (type.Value == "0")
        {
            ((Button)this.Parent.FindControl("btnMoveFolder")).Enabled = (((GlobalVettingLibrary)Page.Master).ParentId != ParentId);
            ((ModalPopupExtender)this.Parent.FindControl("moveFolderModalPopup")).Show();
        }
        else
        {
            ((Button)this.Parent.FindControl("btnMove")).Enabled = (((GlobalVettingLibrary)Page.Master).ParentId != ParentId);
            ((ModalPopupExtender)this.Parent.FindControl("moveModalPopup")).Show();
        }
    }
}