﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template;
using SCA.VAS.ValueObjects.Scorecard.Template;

public partial class Library_Controls_ViewAnswerInfo : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    public void SetInitialValue(int questionId, string userType)
    {
        ScorecardTemplateQuestion templateQuestion = ScorecardTemplateQuestionUtility.Get(
            ConstantUtility.SCORECARD_DATASOURCE_NAME, questionId);
        if (templateQuestion != null)
            questionName.Text = templateQuestion.Name;

        UserType.Value = userType;
        QuestionId.Value = questionId.ToString();

        panelTitle.Text = "Rating Description for " + userType;

        answerGrid.DataSource = ScorecardTemplateAnswerUtility.FindByCriteria(
            ConstantUtility.SCORECARD_DATASOURCE_NAME,
            ScorecardTemplateAnswerManager.FIND_BY_TYPE,
            new object[] { questionId, userType });
        answerGrid.DataBind();

        ModalPopup_view.Show();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int questionId = ConvertUtility.ConvertInt(QuestionId.Value);

        answerinfo.SetInitialValue(questionId, UserType.Value);
    }
}
