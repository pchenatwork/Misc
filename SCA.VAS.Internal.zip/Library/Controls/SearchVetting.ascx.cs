using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;

public partial class Global_Controls_SearchVetting : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    public string Type
    {
        get
        {
            return string.Empty;
        }
    }

    public string InternalUse
    {
        get
        {
            return internalUse.SelectedValue;
        }
    }

    public string Keyword
    {
        get
        {
            return keyword.Text.Trim();
        }
    }

    public int Status
    {
        get
        {
            return ConvertUtility.ConvertInt(statusList.SelectedValue);
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ControlBase_Initial vettinglist = (ControlBase_Initial)this.Parent;
        vettinglist.SetInitialValue();
    }
}
