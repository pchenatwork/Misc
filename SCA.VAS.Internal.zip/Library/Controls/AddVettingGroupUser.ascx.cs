using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.Template.Vetting;
using SCA.VAS.ValueObjects.User;

public partial class Library_Controls_AddVettingGroupUser : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public void SetInitialValue(int vettingGroupId)
    {
        ViewState["VettingGroupId"] = vettingGroupId;
        ViewState["SortField"] = "FullName";
        ViewState["SortSequence"] = "ASC";
        userList.Visible = false;
        usercount.Text = "";
    }

    protected void SearchButtonClick(object sender, System.EventArgs e)
    {
        userList.CurrentPageIndex = 0;
        BindGrid();
        user_ModalPopupExtender.Show();
    }

    protected void addButton_Click(object sender, EventArgs e)
    {
        VettingGroupUserCollection vettingGroupUsers = new VettingGroupUserCollection();
        foreach (DataGridItem dataItem in userList.Items)
        {
            if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
            {
                CheckBox localUser = (CheckBox)dataItem.FindControl("selected");
                if (localUser.Checked)
                {
                    int userId = (int)userList.DataKeys[dataItem.ItemIndex];
                    VettingGroupUser vettingGroupUser = VettingGroupUserUtility.CreateObject();
                    vettingGroupUser.UserId = userId;
                    vettingGroupUsers.Add(vettingGroupUser);
                }
            }
        }

        VettingGroupUserUtility.UpdateCollection(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
            (int)ViewState["VettingGroupId"], vettingGroupUsers);

        PageBase_Initial UserList = (PageBase_Initial)this.Page;
        UserList.SetInitialValue();
    }

    private void BindGrid()
    {
        int pageSize = userList.PageSize;
        string extraXml = "<ArrayOfExtra>";
        extraXml += "<Extra Name=\"Project\" Value=\"0\" />";
        extraXml += "</ArrayOfExtra>";
        
        UserCollection users = UserUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            UserManager.SEARCH_USER_NOT_SELECTED,
            new object[]
            {
                pageSize,
				userList.CurrentPageIndex,
                ViewState["SortField"].ToString(),
                ViewState["SortSequence"].ToString(),
                search.Keyword, 
				search.Status,
                search.Name,
                search.Email,
				search.UserRole,
				search.Division,
				extraXml,
                "VettingGroup",
                (int)ViewState["VettingGroupId"]
            });

        if (users != null && users.Count > 0)
        {
            int totalNumber = users[0].TotalRecordNumber;
            if (totalNumber > 1)
                usercount.Text = totalNumber.ToString() + " users found.";
            else
                usercount.Text = totalNumber.ToString() + " user found.";
            CommonUtility.Display(userList, totalNumber);

            userList.DataSource = users;
            userList.DataBind();
            btnAdd.Visible = true;
        }
        else
        {
            userList.Visible = false;
            usercount.Text = "No user found.";
            btnAdd.Visible = false;
        }
    }

    protected void SortItem(object o, DataGridSortCommandEventArgs e)
    {
        if (ViewState["SortField"].ToString() == e.SortExpression)
        {
            if (ViewState["SortSequence"].ToString() == "ASC")
                ViewState["SortSequence"] = "DESC";
            else
                ViewState["SortSequence"] = "ASC";
        }
        else
        {
            ViewState["SortField"] = e.SortExpression;
        }
        BindGrid();
        user_ModalPopupExtender.Show();
    }

    protected void PageChange(object o, DataGridPageChangedEventArgs e)
    {
        userList.CurrentPageIndex = e.NewPageIndex;
        BindGrid();
        user_ModalPopupExtender.Show();
    }
}
