#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
#endregion

public partial class SearchTemplate : System.Web.UI.UserControl
{
    #region Web Control Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    protected void searchButton_Click(object sender, System.EventArgs e)
    {
        OnSearchClick(e);
    }

    public event EventHandler SearchClick;
    public event EventHandler AddClick;

    protected void OnSearchClick(EventArgs e)
    {
        if (SearchClick != null)
        {
            SearchClick(this, e);
        }
    }

    protected void OnAddClick(EventArgs e)
    {
        if (AddClick != null)
        {
            AddClick(this, e);
        }
    }
    #endregion

    #region Public Property
    public string Keyword
    {
        get { return keyword.Text.Trim(); }
    }
    #endregion

    protected void addButton_Click(object sender, EventArgs e)
    {
        OnAddClick(e);
    }
}