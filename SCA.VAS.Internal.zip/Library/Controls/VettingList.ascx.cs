using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting;
using SCA.VAS.ValueObjects.Template.Vetting;

public partial class Global_VettingList : ControlBase_Initial
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            info.BindControl();
        }
    }

    protected void BindItem(object o, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
		{
            HtmlGenericControl actionsSet = (HtmlGenericControl)e.Item.FindControl("actionsSet");
            HtmlGenericControl actionsMenuSet = (HtmlGenericControl)e.Item.FindControl("actionsMenuSet");
            actionsSet.Attributes.Add("onmouseover", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');getElement('" + actionsMenuSet.ClientID + "').style.width=(this.offsetWidth-2)+'px';this.className='actionsSet_Over';");
            actionsSet.Attributes.Add("onmouseout", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');this.className='actionsSet_Up';");
            
            VettingList vetting = (VettingList)e.Item.DataItem;

            Label status = (Label)e.Item.FindControl("status");
            Label statusLabel = (Label)e.Item.FindControl("statusLabel");
            LinkButton statusButton = (LinkButton)e.Item.FindControl("statusButton");
            if (vetting.Status == 0)
            {
                status.Text = "Active";
                statusLabel.Text = " Deactivate";
                statusButton.Attributes.Add("onclick", "return confirm('Are you sure you want to deactivate " + vetting.Name.Replace("'", "\\'") + "?');");
            }
            else
            {
                status.Text = "Inactive";
                statusLabel.Text = " Activate";
                statusButton.Attributes.Add("onclick", "return confirm('Are you sure you want to activate " + vetting.Name.Replace("'", "\\'") + "?');");
            }

            HyperLink questionLink = (HyperLink)e.Item.FindControl("questionLink");
            questionLink.Enabled = (vetting.Url.Trim().Length == 0);

			LinkButton localDelete = (LinkButton)e.Item.FindControl("deleteButton");
            localDelete.Attributes.Add("onclick", "return confirm('Are you sure that you want to delete " + vetting.Name.Replace("'", "\\'") + "?');");

            //Label hasSchedule = (Label)e.Item.FindControl("hasSchedule");
            //if (vetting.HasSchedule == "Y")
            //    hasSchedule.Text = "<a href=\"javascript:void(0);\" onclick=\"popup('VettingScheduleConfig.aspx?Id=" + vetting.Id.ToString() + "', 500, 400);\">Y</a>";
            //else
            //    hasSchedule.Text = "N";
        }
    }

    override public void SetInitialValue()
    {
        int parentId = ((GlobalVettingLibrary)Page.Master).ParentId;
        if (parentId > 0)
        {
            VettingLibrary vettingLibrary = VettingLibraryUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
                parentId);
            folder.Text = ": " + vettingLibrary.Name;
            description.Text = vettingLibrary.Description;
            btnDeleteFolder.Attributes.Add("onclick", "return confirm('Are you sure that you want to delete " + vettingLibrary.Name.Replace("'", "\\'") + "?');");
        }
        else
        {
            description.Text = "Root";
            linkEditFolder.Visible = false;
            linkMoveFolder.Visible = false;
            btnDeleteFolder.Visible = false;
        }
        BindGrid();
    }

    private void BindGrid()
    {
        VettingListCollection vettings = VettingListUtility.FindByCriteria(
            ConstantUtility.TEMPLATE_DATASOURCE_NAME,
            VettingListManager.SEARCH_VETTINGLIST,
            new object[]
            {
                search.Type,
                search.InternalUse,
                search.Keyword,
                search.Status,
                0,
                ((GlobalVettingLibrary)Page.Master).ParentId
            });
        if (vettings != null && vettings.Count > 0)
        {
            vettingGrid.AllowPaging = (vettings.Count > vettingGrid.PageSize);
            vettingGrid.Visible = true;
            vettingGrid.DataSource = vettings;
            vettingGrid.DataBind();
        }
        else
        {
            vettingGrid.Visible = false;
        }
        ((GlobalVettingLibrary)Page.Master).SetControlPermission();
    }

    protected void ItemCommand(object source, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Edit")
        {
            int id = (int)vettingGrid.DataKeys[e.Item.ItemIndex];
            VettingList vetting = VettingListUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME, id);
            info.SetInitialValue(vetting);
        }
        else if (e.CommandName == "Delete")
        {
            int id = (int)vettingGrid.DataKeys[e.Item.ItemIndex];
            VettingListUtility.Delete(ConstantUtility.TEMPLATE_DATASOURCE_NAME, id);
            
            BindGrid();
        }
        else if (e.CommandName == "Status")
        {
            int id = (int)vettingGrid.DataKeys[e.Item.ItemIndex];
            VettingList vetting = VettingListUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME, id);
            if (vetting.Status == 1)
            {
                vetting.Status = 0;
            }
            else
            {
                vetting.Status = 1;
            }

            VettingListUtility.Update(ConstantUtility.TEMPLATE_DATASOURCE_NAME, vetting);

            BindGrid();
        }
        else if (e.CommandName == "Move")
        {
            int id = (int)vettingGrid.DataKeys[e.Item.ItemIndex];
            VettingList vetting = VettingListUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME, id);
            info.SetMoveValue(vetting);
        }
    }

    protected void ChangePage(object source, DataGridPageChangedEventArgs e)
    {
        vettingGrid.CurrentPageIndex = e.NewPageIndex;
        BindGrid();
    }

    protected void btnAddVetting_Click(object sender, EventArgs e)
    {
        info.SetInitialValue(null);
    }

    protected void btnEditFolder_Click(object sender, EventArgs e)
    {
        if (((GlobalVettingLibrary)Page.Master).ParentId <= 0) return;

        VettingLibrary vetting = VettingLibraryUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
            ((GlobalVettingLibrary)Page.Master).ParentId);
        
        info.SetFolderValue(vetting);
    }

    protected void btnDeleteFolder_Click(object sender, EventArgs e)
    {
        if (((GlobalVettingLibrary)Page.Master).ParentId <= 0) return;

        VettingLibrary vetting = VettingLibraryUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
            ((GlobalVettingLibrary)Page.Master).ParentId);
        VettingLibraryUtility.Delete(ConstantUtility.TEMPLATE_DATASOURCE_NAME, ((GlobalVettingLibrary)Page.Master).ParentId);

        Response.Redirect("Vetting_Explorer.aspx?parentId=" + vetting.ParentId);
    }

    protected void btnCreateFolder_Click(object sender, EventArgs e)
    {
        info.SetFolderValue(null);
    }
}
