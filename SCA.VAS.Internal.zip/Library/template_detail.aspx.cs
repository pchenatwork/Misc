#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template;
using SCA.VAS.ValueObjects.Scorecard.Template;
using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.ValueObjects.Rfd;
#endregion Reference

public partial class Template_Detail : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int templateId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            ScorecardTemplate scorecardTemplate = ScorecardTemplateUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, templateId);
            templateName.Text = scorecardTemplate.Name;

            if (scorecardTemplate != null && scorecardTemplate.Categories != null)
            {
                categoryList.DataSource = scorecardTemplate.Categories;
                categoryList.DataBind();
            }
        }
    }

    protected void BindItem(object o, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ScorecardTemplateCategory scorecardTemplateCategory = (ScorecardTemplateCategory)e.Item.DataItem;

            ScorecardTemplateUserTypeCollection userTypes = ScorecardTemplateUserTypeUtility.FindByCriteria(
                ConstantUtility.SCORECARD_DATASOURCE_NAME,
                ScorecardTemplateUserTypeManager.FIND_SCORECARDTEMPLATEUSERTYPE,
                new object[] { scorecardTemplateCategory.Id, "" });
            Repeater userTypeList = (Repeater)e.Item.FindControl("userTypeList");
            userTypeList.DataSource = userTypes;
            userTypeList.DataBind();
        }
    }
    #endregion Web Event Handler
}