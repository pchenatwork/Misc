using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.ValueObjects.Template.Vetting;

public partial class Global_Vetting_Detail : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int vettingId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            VettingList vetting = VettingListUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME, vettingId);
            ((GlobalVettingLibrary)Page.Master).SetInitialValue(ConstantUtility.VETTING_NODE, vetting.LibraryId);
            detail.SetInitialValue(vetting);
        }
    }
}
