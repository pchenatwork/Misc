#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template;
using SCA.VAS.ValueObjects.Scorecard.Template;
#endregion Reference

public partial class Template_Question : PageBase_Initial
{
    private bool isAdministrator = false;
    private ScorecardTemplate scorecardTemplate = null;

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {            
            btnAdd.Visible = isAdministrator;

            ViewState["SortField"] = "Sequence";
            ViewState["SortSequence"] = "ASC";
            templateName.Text = scorecardTemplate.Name;

            if (scorecardTemplate != null && scorecardTemplate.Categories != null)
            {
                categoryList.DataSource = scorecardTemplate.Categories;
                categoryList.DataBind();
            }
        }
    }

    protected void BindItem(object o, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            if (isAdministrator)
            {
                HtmlGenericControl actionsSet = (HtmlGenericControl)e.Item.FindControl("actionsSet");
                HtmlGenericControl actionsMenuSet = (HtmlGenericControl)e.Item.FindControl("actionsMenuSet");
                actionsSet.Attributes.Add("onmouseover", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');getElement('" + actionsMenuSet.ClientID + "').style.width=(this.offsetWidth-2)+'px';this.className='actionsSet_Over';");
                actionsSet.Attributes.Add("onmouseout", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');this.className='actionsSet_Up';");

                actionsSet.Visible = true;
            }

            ScorecardTemplateCategory scorecardTemplateCategory = (ScorecardTemplateCategory)e.Item.DataItem;
            
            LinkButton deleteButton = (LinkButton)e.Item.FindControl("btnDelete");
            deleteButton.Attributes.Add("onclick", "return confirm('Are you sure you want to delete " + scorecardTemplateCategory.Name + "?');");

            Repeater questionList = (Repeater)e.Item.FindControl("questionList");
            questionList.DataSource = scorecardTemplateCategory.Questions;
            questionList.DataBind();
        }
    }

    protected void ItemCommand(object o, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "Delete")
        {
            int id = ConvertUtility.ConvertInt(e.CommandArgument.ToString());
            ScorecardTemplateCategoryUtility.Delete(ConstantUtility.SCORECARD_DATASOURCE_NAME, id);

            SetInitialValue();
        }
        else if (e.CommandName == "AddQuestion")
        {
            int id = ConvertUtility.ConvertInt(e.CommandArgument.ToString());

            ScorecardTemplateCategory category = ScorecardTemplateCategoryUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, id);

            questioninfo.SetInitialValue(category, null);
        }
        else if (e.CommandName == "Weight")
        {
            int id = ConvertUtility.ConvertInt(e.CommandArgument.ToString());

            ScorecardTemplateCategory category = ScorecardTemplateCategoryUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, id);

            weightinfo.SetInitialValue(scorecardTemplate, category);
        }
        else if (e.CommandName == "Description")
        {
            int id = ConvertUtility.ConvertInt(e.CommandArgument.ToString());

            descriptioninfo.SetInitialValue(id);
        }
        else if (e.CommandName == "Edit")
        {
            int id = ConvertUtility.ConvertInt(e.CommandArgument.ToString());
            ScorecardTemplateCategory category = ScorecardTemplateCategoryUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, id);

            categoryinfo.SetInitialValue(scorecardTemplate, category);
        }
    }

    protected void BindQuestionItem(object o, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            if (isAdministrator)
            {
                HtmlGenericControl actionsSet = (HtmlGenericControl)e.Item.FindControl("actionsSet");
                HtmlGenericControl actionsMenuSet = (HtmlGenericControl)e.Item.FindControl("actionsMenuSet");
                actionsSet.Attributes.Add("onmouseover", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');getElement('" + actionsMenuSet.ClientID + "').style.width=(this.offsetWidth-2)+'px';this.className='actionsSet_Over';");
                actionsSet.Attributes.Add("onmouseout", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');this.className='actionsSet_Up';");

                actionsSet.Visible = true;

                LinkButton deleteButton = (LinkButton)e.Item.FindControl("deleteLink");
                deleteButton.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this question?');");
            }
        }
    }

    protected void QuestionItemCommand(object o, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "Edit")
        {
            int id = ConvertUtility.ConvertInt(e.CommandArgument.ToString());

            ScorecardTemplateQuestion templateQuestion = ScorecardTemplateQuestionUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, id);

            ScorecardTemplateCategory category = ScorecardTemplateCategoryUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, templateQuestion.CategoryId);

            questioninfo.SetInitialValue(category, templateQuestion);
        }
        else if (e.CommandName == "Delete")
        {
            int id = ConvertUtility.ConvertInt(e.CommandArgument.ToString());
            ScorecardTemplateQuestionUtility.Delete(ConstantUtility.SCORECARD_DATASOURCE_NAME, id);

            SetInitialValue();
        }
    }

    protected void QuestionUserTypeItemCommand(object o, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "Answer")
        {
            string[] arguments = e.CommandArgument.ToString().Split('|');
            if (arguments.Length == 2)
            {
                int id = ConvertUtility.ConvertInt(arguments[0]);

                answerinfo.SetInitialValue(id, arguments[1]);
            }
        }
    }
    #endregion Web Event Handler

    override public void SetInitialValue()
    {
        int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        scorecardTemplate = ScorecardTemplateUtility.Get(
            ConstantUtility.SCORECARD_DATASOURCE_NAME, id);

        if (scorecardTemplate != null && scorecardTemplate.Categories != null)
        {
            categoryList.DataSource = scorecardTemplate.Categories;
            categoryList.DataBind();
        }
    }

    override protected void OnInit(EventArgs e)
    {
        int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        scorecardTemplate = ScorecardTemplateUtility.Get(
            ConstantUtility.SCORECARD_DATASOURCE_NAME, id);
        isAdministrator = CommonUtility.IsGlobalCESAdmin(((PageBase)Page).UserName);
        base.OnInit(e);
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);

        categoryinfo.SetInitialValue(scorecardTemplate, null);
    }
}