#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.ValueObjects.Scorecard.Template;
#endregion Reference

public partial class Rating_List : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            ScorecardTemplateAnswerCollection answers = ScorecardTemplateAnswerUtility.GetAll(
                ConstantUtility.SCORECARD_DATASOURCE_NAME);
            answerRepeater.DataSource = answers;
            answerRepeater.DataBind();
        }
    }
    #endregion Web Event Handler
}