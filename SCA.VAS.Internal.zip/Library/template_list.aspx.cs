#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template;
using SCA.VAS.ValueObjects.Scorecard.Template;
#endregion Reference

public partial class Template_List : PageBase_Initial
{
    private bool isAdministrator = false;
    
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            ViewState["SortField"] = "Name";
            ViewState["SortSequence"] = "ASC";
            SetInitialValue();
        }
    }

    protected void BindItem(object o, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            e.Item.Attributes.Add("onmouseover", "this.className='datagridSelectedItem'");
            if (e.Item.ItemType == ListItemType.Item)
                e.Item.Attributes.Add("onmouseout", "this.className='datagridItem'");
            else
                e.Item.Attributes.Add("onmouseout", "this.className='datagridAlternateItem'");

            HtmlGenericControl actionsSet = (HtmlGenericControl)e.Item.FindControl("actionsSet");
            HtmlGenericControl actionsMenuSet = (HtmlGenericControl)e.Item.FindControl("actionsMenuSet");
            actionsSet.Attributes.Add("onmouseover", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');getElement('" + actionsMenuSet.ClientID + "').style.width=(this.offsetWidth-2)+'px';this.className='actionsSet_Over';");
            actionsSet.Attributes.Add("onmouseout", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');this.className='actionsSet_Up';");

            LinkButton copyButton = (LinkButton)e.Item.FindControl("copyBtn");
            copyButton.Attributes.Add("onclick", "return confirm('Are you sure you want to copy this template?');");
            
            LinkButton deleteButton = (LinkButton)e.Item.FindControl("deleteLink");
            deleteButton.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this template?');");

            ScorecardTemplate scorecardTemplate = (ScorecardTemplate)e.Item.DataItem;

            Label status = (Label)e.Item.FindControl("status");
            Label statusLabel = (Label)e.Item.FindControl("statusLabel");
            LinkButton statusButton = (LinkButton)e.Item.FindControl("statusButton");
            if (scorecardTemplate.Status == 1)
            {
                status.Text = "Active";
                statusLabel.Text = " Deactivate";
                statusButton.Attributes.Add("onclick", "return confirm('Are you sure you want to deactivate this template?');");
            }
            else
            {
                status.Text = "Pending";
                statusLabel.Text = " Activate";
                statusButton.Attributes.Add("onclick", "return confirm('Are you sure you want to activate this template?');");
            }

            LinkButton editButton = (LinkButton)e.Item.FindControl("editButton");

            deleteButton.Visible = isAdministrator;
            editButton.Visible = isAdministrator;
            statusButton.Visible = isAdministrator;
        }
    }

    protected void ItemCommand(object o, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Edit")
        {
            int id = (int)templateGrid.DataKeys[e.Item.ItemIndex];
            ScorecardTemplate scorecardTemplate = ScorecardTemplateUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, id);

            templateinfo.SetInitialValue(scorecardTemplate);
        }
        else if (e.CommandName == "Delete")
        {
            int id = (int)templateGrid.DataKeys[e.Item.ItemIndex];
            ScorecardTemplateUtility.Delete(ConstantUtility.SCORECARD_DATASOURCE_NAME, id);

            SetInitialValue();
        }
        else if (e.CommandName == "Copy")
        {
            int id = (int)templateGrid.DataKeys[e.Item.ItemIndex];
            ScorecardTemplateUtility.Copy(ConstantUtility.SCORECARD_DATASOURCE_NAME, id);

            SetInitialValue();
        }
        else if (e.CommandName == "Status")
        {
            int id = (int)templateGrid.DataKeys[e.Item.ItemIndex];
            ScorecardTemplate scorecardTemplate = ScorecardTemplateUtility.Get(ConstantUtility.SCORECARD_DATASOURCE_NAME, id);
           
            if (scorecardTemplate.Status == 1)
            {
                scorecardTemplate.Status = 0;
            }
            else
            {
                scorecardTemplate.Status = 1;
            }
            ScorecardTemplateUtility.UpdateStatus(ConstantUtility.SCORECARD_DATASOURCE_NAME, id, scorecardTemplate.Status);
            
            SetInitialValue();
        }
    }

    protected void SearchButtonClick(object sender, System.EventArgs e)
    {
        SetInitialValue();
    }

    protected void SortItem(object o, DataGridSortCommandEventArgs e)
    {
        if (ViewState["SortField"].ToString() == e.SortExpression)
        {
            if (ViewState["SortSequence"].ToString() == "ASC")
                ViewState["SortSequence"] = "DESC";
            else
                ViewState["SortSequence"] = "ASC";
        }
        else
        {
            ViewState["SortField"] = e.SortExpression;
        }
        SetInitialValue();
    }

    protected void PageChange(object o, DataGridPageChangedEventArgs e)
    {
        templateGrid.CurrentPageIndex = e.NewPageIndex;
        SetInitialValue();
    }
    #endregion Web Event Handler

    override public void SetInitialValue()
    {
        ScorecardTemplateCollection templates = ScorecardTemplateUtility.FindByCriteria(
            ConstantUtility.SCORECARD_DATASOURCE_NAME,
            ScorecardTemplateManager.SEARCH_SCORECARDTEMPLATE,
            new object[] 
            { 
                templateGrid.PageSize,
				templateGrid.CurrentPageIndex,
				ViewState["SortField"].ToString(),
				ViewState["SortSequence"].ToString(),
                0,
				-1,
				search.Keyword,
                "<ArrayOfExtra />"
            });
        int pageSize = templateGrid.PageSize;
        if (templates != null && templates.Count > 0)
        {
            templateGrid.Visible = true;
            int totalNumber = templates[0].TotalRecordNumber;
            templateGrid.VirtualItemCount = totalNumber;
            if (templates.Count > 1)
                templatecount.Text = totalNumber.ToString() + " templates found";
            else
                templatecount.Text = totalNumber.ToString() + " template found";
            if (totalNumber <= pageSize)
            {
                templateGrid.AllowCustomPaging = false;
                templateGrid.AllowPaging = false;
            }
            else
            {
                templateGrid.AllowCustomPaging = true;
                templateGrid.AllowPaging = true;
            }

            templateGrid.DataSource = templates;
            templateGrid.DataBind();
        }
        else
        {
            templateGrid.Visible = false;
            templatecount.Text = "No template found.";
        }
    }

    override protected void OnInit(EventArgs e)
    {
        isAdministrator = CommonUtility.IsGlobalCESAdmin(UserName);
        base.OnInit(e);
    }

    protected void AddButtonClick(object sender, System.EventArgs e)
    {
        templateinfo.SetInitialValue(null);
    }
}