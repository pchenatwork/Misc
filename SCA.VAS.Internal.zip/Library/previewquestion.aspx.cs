#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.WebControls;
using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.ValueObjects.Template.Vetting;
#endregion Reference

public partial class Global_PreviewQuestion : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            VettingList vetting = VettingListUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME,
                ConvertUtility.ConvertInt(Request.QueryString["Id"]));

            vettingName.Text = vetting.Name;

            rfxControl.ShowSequence = false;
            rfxControl.ShowAttachment = true;
            rfxControl.ShowQuestionName = false;
            rfxControl.TypeField = RfxControl.CONTROL_TYPE_DISPLAY;
            rfxControl.DisplayType = RfxControl.DISPLAY_TYPE_INTERNAL;
            rfxControl.AttachmentUrlIndicator = "~/Library/GetVettingAttachment.ashx";
            rfxControl.DataSource = vetting.Questions;
            rfxControl.DataBind();
        }
    }

    #endregion Web Event Handler
}
