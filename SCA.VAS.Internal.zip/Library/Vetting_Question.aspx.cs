#region Reference
using System;
using System.Data;
using System.Collections;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting;
using SCA.VAS.ValueObjects.Template.Vetting;
using SCA.VAS.BusinessLogic.Supplier.Vetting.Utilities;
using SCA.VAS.ValueObjects.Supplier.Vetting;
#endregion Reference

public partial class Global_Vetting_Question : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int vettingId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            VettingList vetting = VettingListUtility.Get(ConstantUtility.TEMPLATE_DATASOURCE_NAME, vettingId);
            ((GlobalVettingLibrary)Page.Master).SetInitialValue(ConstantUtility.VETTING_NODE, vetting.LibraryId);
            vettingName.Text = vetting.Name;
            //fileSizeNotice.Text = ConstantUtility.FILE_SIZE_NOTICE;

            question.SetInitialValue();
        }
    }
    #endregion Web Event Handler
}
