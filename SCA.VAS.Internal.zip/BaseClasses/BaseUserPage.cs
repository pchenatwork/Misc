﻿using SCA.VAS.Common.UserManagement;
using SCA.VAS.UserManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SCA.VAS.Internal.BaseClasses
{
    /// <summary>
    /// This class is specific to System.Web.UI.Page, to handle all Application related ID stored in session and validation on each request.
    /// </summary>
    public class BaseUserPage : PageBase
    {
        public VASUserManagement UserProvider = new VASUserManagement(VASUserManagementConstants.VASUserManagementManagerInternal, 
                                                                      VASUserManagementConstants.VASUserManagementUserInternal,
                                                                      VASUserManagementConstants.VASUserManagementResultInternal);
    }
}