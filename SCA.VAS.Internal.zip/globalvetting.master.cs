using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Template.Utilities;
using SCA.VAS.ValueObjects.Template;
using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.ValueObjects.Template.Vetting;

public partial class Master_GlobalVetting : VettingMasterPage
{
	#region Public Property
	override public int ParentId
	{
		get
		{
			return ConvertUtility.ConvertInt(ViewState["ParentId"].ToString());
		}
		set
		{
			ViewState["ParentId"] = value;
		}
	}

    override public int VettingId
    {
        get
        {
            return ConvertUtility.ConvertInt(ViewState["VettingId"].ToString());
        }
        set
        {
            ViewState["VettingId"] = value;
        }
    }
	#endregion

	protected void Page_Load(object sender, EventArgs e)
	{
		sidebarToggleImg.Style["cursor"] = "hand";
		sidebarToggleImg.Attributes.Add("onmouseover", "btnImgSwap(this,'rollover');");
		sidebarToggleImg.Attributes.Add("onmouseout", "btnImgSwap(this,'rollup');");
		sidebarToggleImg.Attributes.Add("onmousedown", "btnImgSwap(this,'rolldown');");
		sidebarToggleImg.Attributes.Add("onmouseup", "btnImgSwap(this,'rollup');");
		sidebarToggleImg.Attributes.Add("onclick", "sidebarToggle(this,'" + sidebarToggleImg.ClientID + "');");

		pageTitle.Text = ConfigurationManager.AppSettings["SiteTitle"];
    }

	#region Public Method
	override public void SetInitialValue(int parentId, int vettingId)
	{
		ViewState["ParentId"] = parentId;
        ViewState["VettingId"] = vettingId;

        menu.SetInitialValue(true);
        explorer.SetInitialValue(parentId, vettingId);

        CommonUtility.CreateUserLog(((PageBase)Page).UserId, ((PageBase)Page).PageUrl, 
            "Vetting", vettingId, Request.UserHostAddress);
	}
	#endregion Public Method
}
