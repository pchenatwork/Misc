using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

public partial class Home : PageBase
{
	protected void Page_Load(object sender, System.EventArgs e)
	{
        if (!IsPostBack)
        {
            externalLink.NavigateUrl = ConfigurationSettings.AppSettings["SiteUrl"].ToString();
            externalLink.Text = externalLink.NavigateUrl;
            announcement.InnerText = SCA.VAS.BusinessLogic.Common.Utilities.SettingUtility.GetValueByName(SCA.VAS.Workflow.ConstantUtility.COMMON_DATASOURCE_NAME, "Announcements");
            if (announcement.InnerText.Trim().Length == 0)
                annHeader.Visible = false;
        }
	}
}
