using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

public partial class ErrorPage : PageBase
{
	protected void Page_Load(object sender, System.EventArgs e)
	{
        if (!IsPostBack)
        {
            supportPhone.Text = ConfigurationManager.AppSettings["SupportPhone"];
            supportEmail.Text = ConfigurationManager.AppSettings["SupportEmail"];
            supportEmail.NavigateUrl = "mailto:" + supportEmail.Text;
        }
	}
}
