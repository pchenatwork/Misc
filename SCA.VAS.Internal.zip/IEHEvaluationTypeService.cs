using System;
using System.Web;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web.Services;
using System.Web.Services.Protocols;
using AjaxControlToolkit;

using SCA.VAS.Workflow;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.BusinessLogic.Scorecard.Template.Utilities;
using SCA.VAS.BusinessLogic.Scorecard.Template;
using SCA.VAS.ValueObjects.Scorecard.Template;

/// <summary>
/// Summary description for IEHEvaluationTypeService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[System.Web.Script.Services.ScriptService]
public class IEHEvaluationTypeService : System.Web.Services.WebService
{
    public IEHEvaluationTypeService()
    {
    }

    [WebMethod]
    public CascadingDropDownNameValue[] GetTypes(
        string knownCategoryValues,
        string category)
    {
        List<CascadingDropDownNameValue> values = new List<CascadingDropDownNameValue>();
        SettingCollection settings = CommonUtility.GetSettings("IEHEvaluationType.xml");
        if (settings != null)
        {
            foreach (Setting setting in settings)
            {
                values.Add(new CascadingDropDownNameValue(setting.Name, setting.Value));
            }
        }
        return values.ToArray();
    }

    [WebMethod]
    public CascadingDropDownNameValue[] GetMilestones(
        string knownCategoryValues,
        string category)
    {
        StringDictionary kv = CascadingDropDown.ParseKnownCategoryValuesString(
            knownCategoryValues);
        List<CascadingDropDownNameValue> values = new List<CascadingDropDownNameValue>();
        ScorecardTemplateCollection templates = ScorecardTemplateUtility.FindByCriteria(
            ConstantUtility.SCORECARD_DATASOURCE_NAME,
            ScorecardTemplateManager.FIND_ACTIVE_SCORECARDTEMPLATE,
            new object[] { 0, kv["Type"] });
        if (templates != null && templates.Count > 0)
        {
            ScorecardTemplate scorecardTemplate = ScorecardTemplateUtility.Get(
                ConstantUtility.SCORECARD_DATASOURCE_NAME, templates[0].Id);
            if (scorecardTemplate.Categories != null)
            {
                foreach (ScorecardTemplateCategory templateCategory in scorecardTemplate.Categories)
                {
                    if (templateCategory.Type.Trim().Length == 0)
                        values.Add(new CascadingDropDownNameValue(templateCategory.Name, templateCategory.Id.ToString()));
                    else
                        values.Add(new CascadingDropDownNameValue(templateCategory.Name + " " + templateCategory.Type, templateCategory.Id.ToString()));
                }
            }
        }
        return values.ToArray();
    }
}

