#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class Category_Modify : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            ViewState["Id"] = Request.QueryString["Id"];
            Category category = CategoryUtility.Get(ConstantUtility.COMMON_DATASOURCE_NAME,
                ConvertUtility.ConvertInt(Request.QueryString["Id"]));
            if (category != null)
            {
                name.Text = category.Name;
                ParentCategoryId.Value = category.ParentId.ToString();
                isActive.SelectedIndex = isActive.Items.IndexOf(isActive.Items.FindByValue(category.IsActive));
                if (category.ParentId > 0)
                {
                    Category parentCategory = CategoryUtility.Get(ConstantUtility.COMMON_DATASOURCE_NAME,
                        category.ParentId);
                    ParentCategoryName.Value = parentCategory.Name;
                }
                else
                {
                    ParentCategoryName.Value = "Root";
                }
            }
        }
    }

    protected void submitButton_Click(object sender, System.EventArgs e)
    {
        int categoryId = ConvertUtility.ConvertInt(ViewState["Id"].ToString());
        Category category = CategoryUtility.Get(ConstantUtility.COMMON_DATASOURCE_NAME,
            categoryId);
        category.Name = name.Text;
        category.IsActive = isActive.SelectedValue;
        category.ParentId = ConvertUtility.ConvertInt(ParentCategoryId.Value);
        CategoryUtility.Update(ConstantUtility.COMMON_DATASOURCE_NAME, category);

        Response.Redirect("Category_List.aspx");
    }
    #endregion Web Event Handler
}
