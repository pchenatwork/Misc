#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;


using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class EmailLogDetail : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            EmailLog emailLog = EmailLogUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, id);
            if (emailLog != null)
            {
                to.Text = emailLog.ToEmail;
                sentTime.Text = emailLog.SentTime.ToString();
                body.Text = emailLog.Body;
            }

            EmailHistory emailHistory = EmailHistoryUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
                emailLog.EmailHistoryId);
            if (emailHistory != null)
            {
                from.Text = emailHistory.FromEmail;
                subject.Text = emailHistory.Subject;
                cc.Text = emailHistory.CcEmail;

                // attachments
                EmailAttachmentCollection emailatts = EmailAttachmentUtility.GetAttachments(ConstantUtility.USER_DATASOURCE_NAME, emailHistory.Id);
                if (emailatts != null && emailatts.Count > 0)
                {
                    attachmentGrid.DataSource = emailatts;
                    attachmentGrid.DataBind();
                    attachmentGrid.Visible = true;
                }

                //if (emailHistory.EmailAttachments != null && emailHistory.EmailAttachments.Count > 0)
                //{
                //    attachmentGrid.DataSource = emailHistory.EmailAttachments;
                //    attachmentGrid.DataBind();

                //    attachmentGrid.Visible = true;
                //}
            }
        }
    }

    protected void DownloadSelect(object o, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {
            int id = (int)attachmentGrid.DataKeys[e.Item.ItemIndex];
            EmailAttachment attachment = EmailAttachmentUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, id);

            string uploadDirectory = CommonUtility.GetEmailHistoryFullFolder(attachment.EmailHistoryId);

            Response.ContentType = "application/octet-stream";
            Response.AppendHeader("content-disposition",
                "attachment; filename=" + attachment.Filename);
            Response.WriteFile(uploadDirectory + attachment.Filename);
            Response.End();
        }
    }
    #endregion Web Event Handler
}