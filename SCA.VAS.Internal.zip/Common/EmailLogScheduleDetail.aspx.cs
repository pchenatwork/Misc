#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;



using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class EmailLogScheduleDetail : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            EmailLogCollection scheduleLogCollection = EmailLogUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                EmailLogManager.FIND_EMAILLOG_BY_SCHEDULE,
                new object[] { id });
            if (scheduleLogCollection != null && scheduleLogCollection.Count > 0)
            {
                logGrid.DataSource = scheduleLogCollection;
                logGrid.DataBind();
            }
            else
            {
                msg.Text = "No Email Log.";
                msg.Visible = true;
            }
        }
    }

    protected void BindItem(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            EmailLog emailLog = (EmailLog)e.Item.DataItem;

            HyperLink sentTime = (HyperLink)e.Item.FindControl("sentTime");
            sentTime.NavigateUrl = "javascript:newwindow('../Common/EmailLogDetail.aspx?Id=" + emailLog.Id + "', 400, 400);";
            sentTime.Text = emailLog.SentTime.ToString();
        }
    }
    #endregion Web Event Handler
}