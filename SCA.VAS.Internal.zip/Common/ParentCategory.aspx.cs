#region Reference
using System;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;
#endregion Reference

public partial class ParentCategory : PageBase
{
    #region Private Member
    private int level;
    private CategoryCollection allLevelCategories;
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }

    protected void ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
    {
        if (((Button)(e.Item.Cells[0].Controls[0])).Text == "+")
        {
            // condition for node opening
            int Root = ConvertUtility.ConvertInt(categoryGrid.Items[e.Item.ItemIndex].Cells[1].Text);
            for (int i = 1; i < categoryGrid.Items.Count - 1; i++)
            {
                // condition checking for the level just below the root using ParentId
                if (categoryGrid.Items[i].Cells[3].Text == Root.ToString())
                    categoryGrid.Items[i].Visible = true;
            }

            // changing the text of Push Button to looks like opened tree node
            ((Button)(e.Item.Cells[0].Controls[0])).Text = "-";
        }
        else
        {
            // condition for tree closing
            int Root = Convert.ToInt32(categoryGrid.Items[e.Item.ItemIndex].Cells[1].Text);

            // all the chid of the root is stored in this arraylist object
            ArrayList ArrC = new ArrayList();
            ArrC.Add(Root);

            // this loop will exit when the iteration through all the child of the selected node is over
            do
            {
                for (int i = 1; i < categoryGrid.Items.Count - 1; i++)
                {
                    if (categoryGrid.Items[i].Cells[3].Text == ArrC[0].ToString())
                    {
                        ArrC.Add(categoryGrid.Items[i].Cells[1].Text);
                        categoryGrid.Items[i].Visible = false;
                        ((Button)(categoryGrid.Items[i].Cells[0].Controls[0])).Text = "+";
                    }
                }

                // removing the executed node form the arraylist
                ArrC.Remove(ArrC[0]);
            } while (ArrC.Count > 0);

            //after closing all the child node putting back the text back to orginal value
            ((Button)(e.Item.Cells[0].Controls[0])).Text = "+";
        }
    }
    #endregion Web Event Handler

    #region Private Method
    private void BindGrid()
    {
        CategoryCollection categories = CategoryUtility.GetAll(
            ConstantUtility.COMMON_DATASOURCE_NAME);
        level = 0;

        allLevelCategories = new CategoryCollection();

        GetAllLevelCategory(categories);

        categoryGrid.DataSource = allLevelCategories;
        categoryGrid.DataBind();
    }

    private void GetAllLevelCategory(CategoryCollection categories)
    {
        if (categories != null)
        {
            foreach (Category m in categories)
            {
                string toolTip = "";
                for (int i = 0; i < level; i++)
                    toolTip += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                toolTip += "<a href=\"javascript:SelectCategory(" + m.Id + ", '" + m.Name.Replace("'", "\\'") + "');\">" + m.Name + "</a>";
                m.Name = toolTip;
                allLevelCategories.Add(m);
                if (m.SubCategories != null)
                {
                    level++;
                    GetAllLevelCategory(m.SubCategories);
                }
            }
        }
        level--;
    }
    #endregion Private Method
}
