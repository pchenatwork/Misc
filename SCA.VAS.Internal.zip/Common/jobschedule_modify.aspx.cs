#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class JobSchedule_Modify : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    protected void submit_Click(object sender, EventArgs e)
    {
        int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        JobSchedule jobSchedule = JobScheduleUtility.Get(ConstantUtility.COMMON_DATASOURCE_NAME, id);
        if (jobSchedule != null)
        {
            jobSchedule.JobName = detail.JobName;
            jobSchedule.EmailName = detail.EmailName;
            jobSchedule.Description = detail.Description;
            jobSchedule.StartDate = detail.StartDate;
            jobSchedule.Frequency = detail.Frequency;
            jobSchedule.ScheduleType = detail.ScheduleType;
            jobSchedule.DayOfMonth = detail.DayOfMonth;
            jobSchedule.WeekNumber = detail.WeekNumber;
            jobSchedule.WeekDays = detail.Weekdays;
            jobSchedule.SelectedMonths = detail.SelectedMonths;
            jobSchedule.RepeatNumber = detail.RepeatDay;
            jobSchedule.DueNumber = detail.DueNumber;
            jobSchedule.IsActive = detail.IsActive;
            jobSchedule.ScheduledGroup = detail.ScheduledGroup;

            JobScheduleUtility.Update(ConstantUtility.COMMON_DATASOURCE_NAME, jobSchedule);
        }

        Response.Redirect("JobSchedule_List.aspx");
    }
    #endregion Web Event Handler
    #region Private Method
    private void SetInitialValue()
    {
        int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        JobSchedule jobSchedule = JobScheduleUtility.Get(ConstantUtility.COMMON_DATASOURCE_NAME, id);
        detail.SetInitialValue(jobSchedule);
    }
    #endregion Private Method
}
