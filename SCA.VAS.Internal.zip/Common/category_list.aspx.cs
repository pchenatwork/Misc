#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class Category_List : PageBase
{
     #region Private Member
    private int level;
    private CategoryCollection allLevelCategories;
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }
    protected void GridPageChange(Object sender, DataGridPageChangedEventArgs e)
    {
        categoryGrid.CurrentPageIndex = e.NewPageIndex;
        BindGrid();
    }

    protected void BindItem(object o, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ImageButton tempDelete = (ImageButton)e.Item.FindControl("deleteButton");
            tempDelete.Attributes.Add("onclick", "javascript:return confirm('Are you sure you want to delete this category?');");

            Category localCategory = (Category)e.Item.DataItem;
            if (localCategory.SubCategories.Count > 0)
            {
                tempDelete.Visible = false;
            }
        }
    }

    protected void DeleteItem(object sender, DataGridCommandEventArgs e)
    {
        int categoryId = ConvertUtility.ConvertInt(categoryGrid.DataKeys[e.Item.ItemIndex].ToString());

        CategoryUtility.Delete(ConstantUtility.COMMON_DATASOURCE_NAME, categoryId);
        BindGrid();
    }

    protected void searchButton_Click(object sender, System.EventArgs e)
    {
        categoryGrid.CurrentPageIndex = 0;
        BindGrid();
    }

    protected void addButton_Click(object sender, System.EventArgs e)
    {
        Response.Redirect("Category_Add.aspx");
    }

    #endregion Web Event Handler

    #region Private Method
    private void BindGrid()
    {
        CategoryCollection categories = CategoryUtility.FindByCriteria(
            ConstantUtility.COMMON_DATASOURCE_NAME,
            CategoryManager.FIND_CATEGORY_BY_NAME,
            new object[] 
				{ 
					searchBox.Text,
                    ""
				});
        level = 0;
        allLevelCategories = new CategoryCollection();
        GetAllLevelCategory(categories);

        if (allLevelCategories.Count > categoryGrid.PageSize)
            categoryGrid.AllowPaging = true;
        else
            categoryGrid.AllowPaging = false;
        categoryGrid.DataSource = allLevelCategories;
        categoryGrid.DataBind();
        if (allLevelCategories.Count > 0)
            categoryGrid.Visible = true;
        else
            categoryGrid.Visible = false;
    }

    private void GetAllLevelCategory(CategoryCollection categories)
    {
        if (categories != null)
        {
            foreach (Category m in categories)
            {
                string name = "";
                for (int i = 0; i < level; i++)
                {
                    if (i != level - 1)
                    {
                        name += "<img src=\"" + Page.ResolveUrl("~/images/spacer.gif") + "\">";
                    }
                    else
                    {
                        name += "<img src=\"" + Page.ResolveUrl("~/images/icon-forward.gif") + "\">";
                    }
                }
                m.Name = name + m.Name;
                allLevelCategories.Add(m);
                if (m.SubCategories != null)
                {
                    level++;
                    GetAllLevelCategory(m.SubCategories);
                }
            }
        }
        level--;
    }
    #endregion Private Method

}
