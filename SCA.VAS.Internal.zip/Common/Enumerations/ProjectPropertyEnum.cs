﻿namespace SCA.VAS.Internal.Common.Enumerations
{
    public enum ProjectPropertyEnum
    {
        IgRecommendRespondDecision= 50,
        IgRecommendRespondComment= 51,
        IgRecommendMemoDecision=48,
        IgRecommendMemoComment = 49,

        VettingReviewerDecision = 52,
        VettingReviewerComment = 53,
        VettingBondBidReveiwerDecision = 54,
        VettingBondBidReveiwerComment = 55,
        VettingTradeRemediateDecision=56,
        VettingTradeRemediateComments=57,
        VettingManagerDecision=58,
        VettingManagerRejectReason=59,
        VettingManagerComments=60,
        VettingBondFinancialReveiwDecision = 61,
        VettingBondFinancialReveiwComments = 62,
        NextVettingBidderListComments=63,
        FinanceVerificationDecision=64,
        FinanceVerificationComment=65,
        FinanceVerificationAdditionDecision=66,
        FinanceVerificationAdditionComment=67,
        CMPackageDecision=68,
        CMPackageComment=69,
        CPOPackageDecision=70,
        CPOPackageComment=71,

        BidProjectBudgetReviewDecision = 724,
        BidProjectBudgetReviewComment = 725,
        CIPBudgetsUpdated =73,
        OracleBudgetsUpdated = 74,
        FMSBudgetsUpdated = 75,
        OracleContractNumber = 76,
        BidProjectVPCMComment = 80,
        BidProjectCQUDecision = 81,
        BidProjectBDDDecision = 82,
        BidProjectAdminDecision = 83,
        BidProjectVPCMDecision = 84,

        SrDirectorDesicion=22,
        SrDirectorComments=23,
        LegalDesicion = 24,
        LegalComments = 25,
        PresidentDesicion=135,
        PresidentComments=136



    }
}