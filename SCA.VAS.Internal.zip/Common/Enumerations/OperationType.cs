﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SCA.VAS.Internal.Common.Enumerations
{
    public enum OperationType
    {
        INITIALIZATION,
        CREATE,
        SAVE,
        SUBMISSION,
        DELETION,
        CREATION,
        UPDATE,
        DOWNLOAD
    }
}