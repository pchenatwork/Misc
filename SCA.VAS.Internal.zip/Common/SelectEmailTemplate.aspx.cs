#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;

using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class SelectEmailTemplate : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }
    protected void BindItem(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            int offset = templateGrid.AllowPaging ? 3 : 2;
            HyperLink selectLink = (HyperLink)e.Item.FindControl("select");
            selectLink.NavigateUrl = "javascript:SelectMessage(" + (e.Item.ItemIndex + offset) + ");";
        }
    }
    protected void PageChange(object o, DataGridPageChangedEventArgs e)
    {
        templateGrid.CurrentPageIndex = e.NewPageIndex;
        BindGrid();
    }
    #endregion Web Event Handler
    #region Private Method
    private void BindGrid()
    {
        EmailTemplateCollection templateCollection = EmailTemplateUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            EmailTemplateManager.FIND_EMAILTEMPLATE_BY_USER,
            new object[] { UserId });
        if (templateCollection != null && templateCollection.Count > templateGrid.PageSize)
        {
            templateGrid.AllowPaging = true;
        }
        else
        {
            templateGrid.AllowPaging = false;
        }
        templateGrid.DataSource = templateCollection;
        templateGrid.DataBind();
        if (templateCollection.Count > 0)
        {
            templateGrid.Visible = true;
        }
        else
        {
            templateGrid.Visible = false;
        }
    }
    #endregion Private Method
}