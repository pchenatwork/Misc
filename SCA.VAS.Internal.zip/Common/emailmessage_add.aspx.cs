#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
#endregion Reference

public partial class EmailMessage_Add : PageBase
{

    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    protected void submitButton_Click(object sender, System.EventArgs e)
    {
        detail.SaveAttachment();
        
        EmailMessage emailMessage = EmailMessageUtility.CreateObject();

        emailMessage.Name = detail.Name;
        emailMessage.Description = detail.Description;
        emailMessage.FromEmail = detail.FromEmail;
        emailMessage.FromName = detail.FromName;
        emailMessage.ToEmail = detail.ToEmail;
        emailMessage.ToName = detail.ToName;
        emailMessage.CcEmail = detail.CcEmail;
        emailMessage.BccEmail = detail.BccEmail;
        emailMessage.Subject = detail.Subject;
        emailMessage.Body = detail.Body;
        emailMessage.Objects = detail.RecipientType;
        emailMessage.Type = detail.EmailType;
        emailMessage.Filename = detail.Filename;

        EmailMessageUtility.Create(ConstantUtility.COMMON_DATASOURCE_NAME, emailMessage);

        Response.Redirect("EmailMessage_List.aspx");
    }
}
