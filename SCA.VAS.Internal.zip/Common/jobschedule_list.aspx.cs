#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class JobSchedule_List : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        // Put user code to initialize the page here
        if (!IsPostBack)
        {
            BindGrid();
        }
    }

    protected void BindItem(object o, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ImageButton localButton = (ImageButton)e.Item.FindControl("deleteButton");
            localButton.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this job?');");

            JobSchedule jobSchedule = (JobSchedule)e.Item.DataItem;
            Label localDate = (Label)e.Item.FindControl("nextScheduleDate");
            DateTime nextDate = JobScheduleUtility.NextScheduleDate(jobSchedule);
            if (jobSchedule.IsActive == "N" || nextDate == new DateTime(2999, 12, 31))
                localDate.Text = "Never";
            else
                localDate.Text = nextDate.ToString(ConstantUtility.DATE_FORMAT);
        }
    }
    protected void DeleteItem(object o, DataGridCommandEventArgs e)
    {
        int id = ConvertUtility.ConvertInt(jobGrid.DataKeys[e.Item.ItemIndex].ToString());
        JobScheduleUtility.Delete(ConstantUtility.COMMON_DATASOURCE_NAME, id);
        BindGrid();
    }
    protected void addButton_Click(object sender, System.EventArgs e)
    {
        Response.Redirect("JobSchedule_Add.aspx");
    }
    #endregion Web Event Handler

    #region Private Method
    private void BindGrid()
    {
        jobGrid.DataSource = JobScheduleUtility.GetAll(ConstantUtility.COMMON_DATASOURCE_NAME);
        jobGrid.DataBind();
    }
    #endregion Private Method
}
