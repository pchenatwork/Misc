#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Internal.Rfc.Common.Utility;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.ValueObjects.Rfd;

#endregion Reference

public partial class EmailMessage_Modify : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            EmailMessage emailMessage = EmailMessageUtility.Get(ConstantUtility.COMMON_DATASOURCE_NAME, id);
            detail.SetInitialValue(emailMessage);
        }
    }

    protected void submitButton_Click(object sender, System.EventArgs e)
    {
        int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        EmailMessage emailMessage = EmailMessageUtility.Get(ConstantUtility.COMMON_DATASOURCE_NAME, id);
        if (emailMessage != null)
        {
            detail.SaveAttachment();
            
            emailMessage.Name = detail.Name;
            emailMessage.Description = detail.Description;
            emailMessage.FromEmail = detail.FromEmail;
            emailMessage.FromName = detail.FromName;
            emailMessage.ToEmail = detail.ToEmail;
            emailMessage.ToName = detail.ToName;
            emailMessage.CcEmail = detail.CcEmail;
            emailMessage.BccEmail = detail.BccEmail;
            emailMessage.Subject = detail.Subject;
            emailMessage.Body = detail.Body;
            emailMessage.Objects = detail.RecipientType;
            emailMessage.Type = detail.EmailType;
            emailMessage.Filename = detail.Filename;

            EmailMessageUtility.Update(ConstantUtility.COMMON_DATASOURCE_NAME, emailMessage);
        }

        Response.Redirect("EmailMessage_List.aspx");
    }

    #endregion Web Event Handler

    
}