#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class EmailTemplateDetail : System.Web.UI.UserControl
{
    #region Public Property
    public string Subject
    {
        get
        {
            return subject.Text;
        }
    }

    public string ViewByOther
    {
        get
        {
            return viewByOther.SelectedValue;
        }
    }

    public string Body
    {
        get
        {
            return emailBody.Text;
        }
    }
    #endregion

    #region Public Method
    public void SetInitialValue(EmailTemplate emailTemplate)
    {
        if (emailTemplate != null)
        {
            subject.Text = emailTemplate.Subject;
            viewByOther.SelectedIndex = viewByOther.Items.IndexOf(
                viewByOther.Items.FindByValue(emailTemplate.ViewByOther));
            emailBody.Text = emailTemplate.Body;
        }
    }
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }
    #endregion
}
