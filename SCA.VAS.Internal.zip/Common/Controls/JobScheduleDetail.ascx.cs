#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
#endregion Reference

public partial class JobScheduleDetail : System.Web.UI.UserControl
{

    #region Public Property
    public string JobName
    {
        get
        {
            return jobName.Text;
        }
    }

    public string EmailName
    {
        get
        {
            return emailName.Text;
        }
    }

    public string Description
    {
        get
        {
            return description.Text;
        }
    }

    public string Frequency
    {
        get
        {
            return frequency.SelectedValue;
        }
    }

    public DateTime StartDate
    {
        get
        {
            return (startDate.SelectedDate == DateTime.MinValue) ?
                new DateTime(1900, 1, 1) : startDate.SelectedDate;
        }
    }

    public int RepeatDay
    {
        get
        {
            return ConvertUtility.ConvertInt(repeatday.Text);
        }
    }

    public int RepeatWeek
    {
        get
        {
            return ConvertUtility.ConvertInt(repeatweek.Text);
        }
    }

    public string Weekdays
    {
        get
        {
            string weekDays = string.Empty;
            foreach (ListItem listItem in weekdaylist.Items)
            {
                if (listItem.Selected)
                {
                    weekDays += listItem.Value + " ";
                }
            }
            return weekDays;
        }
    }

    public int WeekNumber
    {
        get
        {
            return ConvertUtility.ConvertInt(weeknumber.SelectedValue);
        }
    }

    public int ScheduleType
    {
        get
        {
            if (scheduleType1.Checked)
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
    }

    public int DayOfMonth
    {
        get
        {
            return ConvertUtility.ConvertInt(dayofmonth.Text);
        }
    }

    public string WeekDay
    {
        get
        {
            return weekday.SelectedValue;
        }
    }

    public string SelectedMonths
    {
        get
        {
            return selectedMonths.Value;
        }
    }

    public int DueNumber
    {
        get
        {
            return ConvertUtility.ConvertInt(duenumber.Text);
        }
    }

    public string IsActive
    {
        get
        {
            return isActive.SelectedValue;
        }
    }


    public string ScheduledGroup
    {
        get
        {
            return scheduledGroup.SelectedValue;
        }
    }
    #endregion

    #region Public Method
    public void SetInitialValue(JobSchedule jobSchedule)
    {
        monthlyschedule1.Visible = false;
        monthlyschedule2.Visible = false;
        weeklyschedule1.Visible = false;
        weeklyschedule2.Visible = false;
        dailyschedule.Visible = true;

        if (jobSchedule != null)
        {
            jobName.Text = jobSchedule.JobName;
            emailName.Text = jobSchedule.EmailName;
            description.Text = jobSchedule.Description;
            startDate.SelectedDate = (jobSchedule.StartDate == new DateTime(1900, 1, 1))
                ? DateTime.MinValue : jobSchedule.StartDate;
            frequency.SelectedIndex = frequency.Items.IndexOf(frequency.Items.FindByValue(jobSchedule.Frequency));
            DisplayFields(jobSchedule.Frequency);
            switch (jobSchedule.Frequency)
            {
                case JobSchedule.WEEK_SCHEDULE:
                    {
                        repeatweek.Text = jobSchedule.RepeatNumber.ToString();
                        weekdaylist.ClearSelection();
                        string[] weekdayList = jobSchedule.WeekDays.Split(new Char[] { ',', ' ' });
                        if (jobSchedule.WeekDays != string.Empty)
                        {
                            foreach (ListItem li in weekdaylist.Items)
                            {
                                foreach (string s in weekdayList)
                                {
                                    if (li.Value == s)
                                        li.Selected = true;
                                }
                            }
                        }
                        break;
                    }
                case JobSchedule.MONTH_SCHEDULE:
                    {
                        if (jobSchedule.ScheduleType == 0)
                        {
                            scheduleType1.Checked = true;
                        }
                        else
                        {
                            scheduleType2.Checked = true;
                        }
                        dayofmonth.Text = jobSchedule.DayOfMonth.ToString();
                        weeknumber.SelectedIndex = weeknumber.Items.IndexOf(weeknumber.Items.FindByValue(jobSchedule.WeekNumber.ToString()));
                        weekday.SelectedIndex = weekday.Items.IndexOf(weekday.Items.FindByValue(jobSchedule.WeekDays));
                        selectedMonths.Value = jobSchedule.SelectedMonths;
                        break;
                    }
                case JobSchedule.DAY_SCHEDULE:
                    {
                        repeatday.Text = jobSchedule.RepeatNumber.ToString();
                        break;
                    }
            }
            duenumber.Text = jobSchedule.DueNumber.ToString();
            isActive.SelectedIndex = isActive.Items.IndexOf(isActive.Items.FindByValue(jobSchedule.IsActive));
            scheduledGroup.SelectedIndex = scheduledGroup.Items.IndexOf(scheduledGroup.Items.FindByValue(jobSchedule.ScheduledGroup));
        }
    }
    #endregion

    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    private void DisplayFields(string scheduleFrequency)
    {
        switch (scheduleFrequency)
        {
            case JobSchedule.MONTH_SCHEDULE:
                {
                    dailyschedule.Visible = false;
                    weeklyschedule1.Visible = false;
                    weeklyschedule2.Visible = false;
                    monthlyschedule1.Visible = true;
                    monthlyschedule2.Visible = true;
                    break;
                }
            case JobSchedule.WEEK_SCHEDULE:
                {
                    dailyschedule.Visible = false;
                    weeklyschedule1.Visible = true;
                    weeklyschedule2.Visible = true;
                    monthlyschedule1.Visible = false;
                    monthlyschedule2.Visible = false;
                    break;
                }
            case JobSchedule.DAY_SCHEDULE:
                {
                    dailyschedule.Visible = true;
                    weeklyschedule1.Visible = false;
                    weeklyschedule2.Visible = false;
                    monthlyschedule1.Visible = false;
                    monthlyschedule2.Visible = false;
                    break;
                }
            default:
                {
                    dailyschedule.Visible = false;
                    weeklyschedule1.Visible = false;
                    weeklyschedule2.Visible = false;
                    monthlyschedule1.Visible = false;
                    monthlyschedule2.Visible = false;
                    break;
                }
        }
    }

    protected void frequency_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        DisplayFields(frequency.SelectedValue);
    }
}