#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
#endregion Reference

public partial class EmailMessageDetail : System.Web.UI.UserControl
{
    #region Public Property
    public string Name
    {
        get
        {
            return name.Text;
        }
    }

    public string RecipientType
    {
        get
        {
            return recipientType.SelectedValue;
        }
    }

    public string EmailType
    {
        get
        {
            return emailType.SelectedValue;
        }
    }

    public string Description
    {
        get
        {
            return description.Text;
        }
    }

    public string FromEmail
    {
        get
        {
            return fromemail.Text;
        }
    }

    public string FromName
    {
        get
        {
            return fromname.Text;
        }
    }

    public string ToEmail
    {
        get
        {
            return toemail.Text;
        }
    }

    public string ToName
    {
        get
        {
            return toname.Text;
        }
    }

    public string CcEmail
    {
        get
        {
            return ccemail.Text;
        }
    }

    public string BccEmail
    {
        get
        {
            return bccemail.Text;
        }
    }

    public string Subject
    {
        get
        {
            return subject.Text;
        }
    }

    public string Body
    {
        get
        {
            return emailBody.Text;
        }
    }

    public string Filename
    {
        get
        {
            string filename = Path.GetFileName(attachmentFile.PostedFile.FileName);
            if (filename.Trim().Length > 0)
                return filename;
            else
                return oldFilename.Value;
        }
    }
    #endregion

    #region Public Method
    public void SetInitialValue(EmailMessage emailMessage)
    {
        if (emailMessage != null)
        {
            name.Text = emailMessage.Name;
            description.Text = emailMessage.Description;
            fromemail.Text = emailMessage.FromEmail;
            fromname.Text = emailMessage.FromName;
            toemail.Text = emailMessage.ToEmail;
            toname.Text = emailMessage.ToName;
            ccemail.Text = emailMessage.CcEmail;
            bccemail.Text = emailMessage.BccEmail;
            subject.Text = emailMessage.Subject;
            emailBody.Text = emailMessage.Body;

            recipientType.SelectedIndex = recipientType.Items.IndexOf(
                recipientType.Items.FindByValue(emailMessage.Objects));
            emailType.SelectedIndex = emailType.Items.IndexOf(
              emailType.Items.FindByValue(emailMessage.Type));

            if (emailMessage.Filename.Trim().Length > 0)
            {
                attachmentLink.Visible = true;
                deleteAttachment.Visible = true;
                oldFilename.Value = emailMessage.Filename;
            }
        }
    }

    public void SaveAttachment()
    {
        string filename = Path.GetFileName(attachmentFile.PostedFile.FileName);

        string emailFolder = CommonUtility.GetEmailFolder();
        string faxFolder = CommonUtility.GetFaxFolder();

        if (filename.Trim().Length > 0)
        {
            attachmentFile.PostedFile.SaveAs(emailFolder + filename);
            attachmentFile.PostedFile.SaveAs(faxFolder + filename);
        }
    }
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            deleteAttachment.Attributes.Add("onclick", "javascript:return confirm('Are you sure you want to delete this email attachment?');");
        }
    }
    #endregion

    protected void deleteAttachment_Click(object sender, EventArgs e)
    {
        oldFilename.Value = "";
        attachmentLink.Visible = false;
        deleteAttachment.Visible = false;
    }

    protected void attachmentLink_Click(object sender, EventArgs e)
    {
        int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        EmailMessage emailMessage = EmailMessageUtility.Get(ConstantUtility.COMMON_DATASOURCE_NAME, id);
        if (emailMessage != null)
        {
            string emailFolder = CommonUtility.GetEmailFolder();

            Response.ContentType = "application/octet-stream";
            Response.AppendHeader("content-disposition",
                "attachment; filename=" + emailMessage.Filename);
            Response.WriteFile(emailFolder + emailMessage.Filename);
            Response.End();
        }
    }
}
