#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;



using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class JobScheduleHistory : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            ScheduleHistoryCollection scheduleHistoryCollection = ScheduleHistoryUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                ScheduleHistoryManager.FIND_SCHEDULEHISTORY_BY_JOB,
                new object[] { id });
            if (scheduleHistoryCollection != null && scheduleHistoryCollection.Count > 0)
            {
                historyGrid.DataSource = scheduleHistoryCollection;
                historyGrid.DataBind();
            }
            else
            {
                msg.Text = "No Schedule History.";
                msg.Visible = true;
            }
        }
    }

    protected void BindItem(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ScheduleHistory scheduleHistory = (ScheduleHistory)e.Item.DataItem;

            Label startTime = (Label)e.Item.FindControl("startTime");
            startTime.Text = scheduleHistory.StartDate.ToString();

            Label endTime = (Label)e.Item.FindControl("endTime");
            endTime.Text = scheduleHistory.EndDate.ToString();
        }
    }
    #endregion Web Event Handler

}