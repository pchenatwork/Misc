#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class JobSchedule_Add : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            detail.SetInitialValue(null);
        }
    }

    protected void submit_Click(object sender, EventArgs e)
    {
        JobSchedule jobSchedule = JobScheduleUtility.CreateObject();
        jobSchedule.JobName = detail.JobName;
        jobSchedule.EmailName = detail.EmailName;
        jobSchedule.Description = detail.Description;
        jobSchedule.StartDate = detail.StartDate;
        jobSchedule.Frequency = detail.Frequency;
        jobSchedule.ScheduleType = detail.ScheduleType;
        jobSchedule.DayOfMonth = detail.DayOfMonth;
        jobSchedule.WeekNumber = detail.WeekNumber;
        jobSchedule.WeekDays = detail.Weekdays;
        jobSchedule.SelectedMonths = detail.SelectedMonths;
        jobSchedule.RepeatNumber = detail.RepeatDay;
        jobSchedule.DueNumber = detail.DueNumber;
        jobSchedule.IsActive = detail.IsActive;
        jobSchedule.ScheduledGroup = detail.ScheduledGroup;

        if (JobScheduleUtility.Create(ConstantUtility.COMMON_DATASOURCE_NAME, jobSchedule))
        {
            Response.Redirect("JobSchedule_List.aspx");
        }
    }

    #endregion Web Event Handler
}
