#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;

using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class Message : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        // Put user code to initialize the page here
        if (!IsPostBack)
        {
            int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            EmailTemplate emailTemplate = EmailTemplateUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, id);
            if (emailTemplate != null)
                body.Text = emailTemplate.Body;
        }
    }
    #endregion Web Event Handler
}