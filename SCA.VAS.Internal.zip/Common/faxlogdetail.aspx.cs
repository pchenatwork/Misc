#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;


using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class FaxLogDetail : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            FaxHistory faxHistory = FaxHistoryUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
                id);
            if (faxHistory != null)
            {
                from.Text = faxHistory.FromFax;
                subject.Text = faxHistory.Subject;
                to.Text = faxHistory.ToFax;
                sentTime.Text = faxHistory.SentTime.ToString();
                if (faxHistory.FaxAttachments != null && faxHistory.FaxAttachments.Count > 0)
                {
                    attachmentGrid.DataSource = faxHistory.FaxAttachments;
                    attachmentGrid.DataBind();

                    attachmentGrid.Visible = true;
                }
            }
        }
    }

    protected void DownloadSelect(object o, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {
            int id = (int)attachmentGrid.DataKeys[e.Item.ItemIndex];
            FaxAttachment attachment = FaxAttachmentUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, id);

            string uploadDirectory = CommonUtility.GetFaxHistoryFullFolder(attachment.FaxHistoryId);

            Response.ContentType = "application/octet-stream";
            Response.AppendHeader("content-disposition",
                "attachment; filename=" + attachment.Filename);
            Response.WriteFile(uploadDirectory + attachment.Filename);
            Response.End();
        }
    }
    #endregion Web Event Handler
}