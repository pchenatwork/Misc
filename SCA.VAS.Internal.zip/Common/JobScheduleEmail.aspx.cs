#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;

using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
#endregion Reference

public partial class JobScheduleEmail : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            string id = Request.QueryString["Id"];
            EmailMessage emailMessage = EmailMessageUtility.GetByName(ConstantUtility.COMMON_DATASOURCE_NAME, id);
            if (emailMessage != null)
                body.Text = emailMessage.Body;
        }
    }
    #endregion Web Event Handler
}