#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;



using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class EmailHistoryDetail : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            EmailLogCollection logCollection = EmailLogUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                EmailLogManager.FIND_EMAILLOG_BY_HISTORY,
                new object[] { id });
            if (logCollection != null && logCollection.Count > 0)
            {
                logGrid.DataSource = logCollection;
                logGrid.DataBind();

                EmailLog log = EmailLogUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, id);

                // attachments
                EmailAttachmentCollection emailatts = EmailAttachmentUtility.GetAttachments(ConstantUtility.USER_DATASOURCE_NAME, id);
                if (emailatts != null && emailatts.Count > 0)
                {
                    atts.DataSource = emailatts;
                    atts.DataBind();
                }
            }
            else
            {
                msg.Text = "No Email Log.";
                msg.Visible = true;
            }
        }
    }
    #endregion Web Event Handler

    protected void BindItem(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            EmailLog emailLog = (EmailLog)e.Item.DataItem;

            HyperLink sentTime = (HyperLink)e.Item.FindControl("sentTime");
            sentTime.NavigateUrl = "javascript:newwindow('../Common/EmailLogDetail.aspx?Id=" + emailLog.Id + "', 400, 400);";
            sentTime.Text = emailLog.SentTime.ToString();

            Label readTime = (Label)e.Item.FindControl("readTime");
            readTime.Text = (emailLog.ReadTime == new DateTime(1900, 1, 1)) ? "" : emailLog.ReadTime.ToString();
        }
    }

    protected void atts_ItemDataBound(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            EmailAttachment att = (EmailAttachment)e.Item.DataItem;

            HyperLink attlink = (HyperLink)e.Item.FindControl("AttachmentLink");
            attlink.NavigateUrl = "~/Supplier/GetSupplierDocument.ashx?type=doc&Id=" + att.AttachmentId;  // "javascript:newwindow('../Supplier/GetSupplierDocument.ashx?type=doc&Id=" + att.AttachmentId + "',100,100);";
            attlink.Text = att.Filename;
        }
    }
}