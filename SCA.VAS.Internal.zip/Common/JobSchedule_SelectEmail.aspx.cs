#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;

using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;
#endregion Reference

public partial class JobSchedule_SelectEmail : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }
    protected void PageChange(object o, DataGridPageChangedEventArgs e)
    {
        emailGrid.CurrentPageIndex = e.NewPageIndex;
        BindGrid();
    }
    protected string GetLink(object o1, object o2)
    {
        string name = (string)o1;
        string description = (string)o2;

        return "javascript:selectemail('" + name + "','" + description.Replace("'", "\\'") + "')";
    }
    #endregion Web Event Handler

    #region Private Method
    private void BindGrid()
    {
        EmailMessageCollection emailCollection = EmailMessageUtility.FindByCriteria(
            ConstantUtility.COMMON_DATASOURCE_NAME,
            EmailMessageManager.FIND_EMAILMESSAGE_BY_TYPE,
            new object[] { 0, 0, "Name", "ASC", "Batch", "" });
        if (emailCollection != null && emailCollection.Count > 0)
        {
            emailGrid.AllowPaging = (emailCollection.Count > emailGrid.PageSize);
            emailGrid.DataSource = emailCollection;
            emailGrid.DataBind();
            emailGrid.Visible = true;
        }
        else
        {
            emailGrid.Visible = false;
        }
    }
    #endregion Private Method
}