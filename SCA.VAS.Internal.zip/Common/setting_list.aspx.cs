#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;
#endregion Reference

public partial class Setting_List : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }

    protected void BindItem(object o, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            Setting setting = (Setting)e.Item.DataItem;

            LinkButton localDelete = (LinkButton)e.Item.FindControl("deleteButton");
            localDelete.Attributes.Add("onclick", "javascript:return confirm('Are you sure that you want to delete " + setting.Name.Replace("'", "\\'") + "?') ");

            HtmlGenericControl actionsSet = (HtmlGenericControl)e.Item.FindControl("actionsSet");
            HtmlGenericControl actionsMenuSet = (HtmlGenericControl)e.Item.FindControl("actionsMenuSet");
            actionsSet.Attributes.Add("onmouseover", "getElement('" + actionsMenuSet.ClientID + "').style.width=this.offsetWidth+'px';this.className='actionsSet_Over';");
            actionsSet.Attributes.Add("onmouseout", "this.className='actionsSet_Up';");
        }
    }

    protected void search_Click(object sender, System.EventArgs e)
    {
        BindGrid();
    }
    #endregion Web Event Handler

    #region Private Method
    private void BindGrid()
    {
        settingGrid.DataSource = SettingUtility.FindByCriteria(
            ConstantUtility.COMMON_DATASOURCE_NAME,
            SettingManager.FIND_SETTING_BY_KEYWORD,
            new object[] { keyword.Text });
        settingGrid.DataBind();
    }
    #endregion Private Method
    
    protected void addButton_Click(object sender, EventArgs e)
    {
        Setting setting = SettingUtility.CreateObject();
        if (name.Enabled)
            setting.Name = name.Text;
        else
            setting.Name = key.Value;
        setting.Value = value.Text;
        if (key.Value.Trim().Length == 0)
            SettingUtility.Create(ConstantUtility.COMMON_DATASOURCE_NAME, setting);
        else
            SettingUtility.Update(ConstantUtility.COMMON_DATASOURCE_NAME, setting);

        BindGrid();

        key.Value = string.Empty;
        name.Text = string.Empty;
        value.Text = string.Empty;
    }

    protected void ItemCommand(object source, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Edit")
        {
            string settingName = settingGrid.DataKeys[e.Item.ItemIndex].ToString();
            panelTitle.Text = "Edit System Setting";
            key.Value = settingName;
            name.Text = settingName;
            name.Enabled = false;
            value.Text = SettingUtility.GetValueByName(ConstantUtility.COMMON_DATASOURCE_NAME,
                settingName);

            string clientId = e.Item.FindControl("actionsSet").ClientID;
            Page.ClientScript.RegisterStartupScript(GetType(), "EditSetting",
                "SetSettingSet('" + clientId + "');", true);
        }
        else if (e.CommandName == "Delete")
        {
            string settingName = settingGrid.DataKeys[e.Item.ItemIndex].ToString();
            SettingUtility.Delete(ConstantUtility.COMMON_DATASOURCE_NAME, settingName);
            BindGrid();
        }
    }
}
