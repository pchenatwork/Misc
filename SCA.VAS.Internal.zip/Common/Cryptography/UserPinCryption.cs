﻿using SCA.VAS.Common.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCA.VAS.Internal.Common.Cryptography
{
    public static class UserPinCryption
    {
        private static Random _random = new Random();
        private static string _key = "KEYSALT_VAS_USER_PIN_INIT";

        private static string GenerateRandomNo()
        {
            return _random.Next(0, 999999).ToString("D6");
        }

        public static string GeneratePin()
        {
            return Encrypt(GenerateRandomNo());
        }

        public static string RetirevePin(string encPin)
        {
            return CryptUtility.Decrypt(encPin, _key);
        }

        public static string Encrypt(string pin)
        {
            return CryptUtility.Encrypt(pin, _key);
        }
    }
}
