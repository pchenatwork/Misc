#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
#endregion Reference

public partial class EmailMessage_List : PageBase
{

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        // Put user code to initialize the page here
        if (!IsPostBack)
        {
            BindGrid();
        }
    }

    protected void addButton_Click(object sender, System.EventArgs e)
    {
        Response.Redirect("EmailMessage_Add.aspx");
    }

    protected void BindItem(object o, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ((ImageButton)e.Item.FindControl("deleteButton")).Attributes.Add("onclick",
                "javascript:return confirm('Are you sure that you want to delete this email message?');");
            ((ImageButton)e.Item.FindControl("copyButton")).Attributes.Add("onclick",
                "javascript:return confirm('Are you sure that you want to make a copy of this email message?');");
        }
    }

    protected void ItemCommand(object o, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Delete")
        {
            int id = (int)emailGrid.DataKeys[e.Item.ItemIndex];
            EmailMessageUtility.Delete(ConstantUtility.COMMON_DATASOURCE_NAME, id);
            BindGrid();
        }
        else if (e.CommandName == "Copy")
        {
            int id = (int)emailGrid.DataKeys[e.Item.ItemIndex];
            EmailMessageUtility.Copy(ConstantUtility.COMMON_DATASOURCE_NAME, id);
            BindGrid();
        }
    }

    protected void search_Click(object sender, System.EventArgs e)
    {
        BindGrid();
    }
    #endregion Web Event Handler

    #region Private Method
    private void BindGrid()
    {
        emailGrid.DataSource = EmailMessageUtility.FindByCriteria(
            ConstantUtility.COMMON_DATASOURCE_NAME,
            EmailMessageManager.FIND_EMAILMESSAGE_BY_KEYWORD,
            new object[] { keyword.Text });
        emailGrid.DataBind();
    }
    #endregion Private Method

}