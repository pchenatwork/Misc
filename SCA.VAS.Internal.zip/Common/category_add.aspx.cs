#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class Category_Add : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    protected void submitButton_Click(object sender, System.EventArgs e)
    {
        Category category = CategoryUtility.CreateObject();
        category.Name = name.Text;
        category.IsActive = isActive.SelectedValue;
        category.ParentId = ConvertUtility.ConvertInt(ParentCategoryId.Value);
        CategoryUtility.Create(ConstantUtility.COMMON_DATASOURCE_NAME, category);

        Response.Redirect("Category_List.aspx");
    }
    #endregion Web Event Handler
}
