#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class EmailTemplate_List : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        // Put user code to initialize the page here
        if (!IsPostBack)
        {
            ListGrid();
        }
    }
    protected void TemplateBind(System.Object sender, DataGridItemEventArgs e)
    {
        ImageButton btn;
        if ((e.Item.ItemType == ListItemType.Item) || (e.Item.ItemType == ListItemType.AlternatingItem))
        {
            btn = (ImageButton)e.Item.FindControl("deleteImage");
            btn.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this Email Template?')");
        }
    }
    protected void DelEmail(Object o, DataGridCommandEventArgs e)
    {
        int id = Convert.ToInt32(templateGrid.DataKeys[e.Item.ItemIndex]);
        EmailTemplateUtility.Delete(ConstantUtility.USER_DATASOURCE_NAME, id);
        ListGrid();
    }
    protected void PageChange(object o, DataGridPageChangedEventArgs e)
    {
        templateGrid.CurrentPageIndex = e.NewPageIndex;
        ListGrid();
    }
    protected void addButton_Click(object sender, System.EventArgs e)
    {
        Response.Redirect("EmailTemplate_Add.aspx");
    }

    #endregion Web Event Handler
    #region Private Method
    private void ListGrid()
    {
        EmailTemplateCollection emailCollection = EmailTemplateUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            EmailTemplateManager.FIND_EMAILTEMPLATE_BY_USER,
            new object[] { UserId });
        if (emailCollection != null && emailCollection.Count > templateGrid.PageSize)
        {
            templateGrid.AllowPaging = true;
        }
        else
        {
            templateGrid.AllowPaging = false;
        }
        templateGrid.DataSource = emailCollection;
        templateGrid.DataBind();
        if (emailCollection.Count > 0)
        {
            templateGrid.Visible = true;
        }
        else
        {
            templateGrid.Visible = false;
        }
    }
    #endregion Private Method
}
