#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class EmailTemplate_Add : PageBase
{
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }


    protected void submit_Click(object sender, System.EventArgs e)
    {
        EmailTemplate emailTemplate = EmailTemplateUtility.CreateObject();

        emailTemplate.Subject = detail.Subject;
        emailTemplate.Body = detail.Body;
        emailTemplate.UserId = UserId;
        emailTemplate.ViewByOther = detail.ViewByOther;

        EmailTemplateUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, emailTemplate);

        Response.Redirect("EmailTemplate_List.aspx");
    }
}