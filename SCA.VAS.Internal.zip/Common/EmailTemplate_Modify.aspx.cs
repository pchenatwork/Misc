#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class EmailTemplate_Modify : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            EmailTemplate emailTemplate = EmailTemplateUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, id);
            detail.SetInitialValue(emailTemplate);
        }
    }

    protected void submit_Click(object sender, System.EventArgs e)
    {
        int id = ConvertUtility.ConvertInt(Request.QueryString["Id"]);

        EmailTemplate emailTemplate = EmailTemplateUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, id);

        if (emailTemplate != null)
        {
            emailTemplate.Subject = detail.Subject;
            emailTemplate.Body = detail.Body;
            emailTemplate.UserId = UserId;
            emailTemplate.ViewByOther = detail.ViewByOther;

            EmailTemplateUtility.Update(ConstantUtility.USER_DATASOURCE_NAME, emailTemplate);
        }

        Response.Redirect("EmailTemplate_List.aspx");
    }
    #endregion Web Event Handler
}
