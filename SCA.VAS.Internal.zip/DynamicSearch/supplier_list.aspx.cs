#region Reference
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.BusinessLogic.QEngine.Utilities;
using SCA.VAS.BusinessLogic.QEngine;
using SCA.VAS.ValueObjects.QEngine;
using SCA.VAS.Workflow;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.Common.Utilities;
using SCA.VAS.DataAccess;
using UNLV.IAP.WebControls;
using BaseRule = SCA.VAS.ValueObjects.QEngine.Rule;
using BaseIDataSource = SCA.VAS.DataAccess.IDataSource;
#endregion Reference

public partial class DynamicSearch_supplier_list : PageBase
{
	#region Web Event Handler
	protected void Page_Load(object sender, System.EventArgs e)
	{
		// Put user code to initialize the page here
		if (!IsPostBack)
		{
			ViewState["SortField"] = "Company";
			ViewState["SortSequence"] = "ASC";
			BindGrid();
		}
	}
	protected void PageChange(object o, DataGridPageChangedEventArgs e)
	{
		supplierGrid.CurrentPageIndex = e.NewPageIndex;
		BindGrid();
	}

	protected void SortItem(object o, DataGridSortCommandEventArgs e)
	{
		if (ViewState["SortField"].ToString() == e.SortExpression)
		{
			if (ViewState["SortSequence"].ToString() == "ASC")
				ViewState["SortSequence"] = "DESC";
			else
				ViewState["SortSequence"] = "ASC";
		}
		else
		{
			ViewState["SortField"] = e.SortExpression;
		}

		BindGrid();
	}
	#endregion Web Event Handler

	#region Private Method
	private void BindGrid()
	{
		int ruleId = ConvertUtility.ConvertInt(Request.QueryString["id"]);

		BaseRule rule = RuleUtility.Get(ConstantUtility.QENGINE_DATASOURCE_NAME, ruleId);
		swb1.Conditions = (SqlWhereBuilderConditionCollection)XmlUtility.Deserialize(rule.ConditionXml, typeof(SqlWhereBuilderConditionCollection));

		int pageSize = supplierGrid.PageSize;

		DataSet cds = new DataSet();
		DataSet ds = new DataSet();

		string countString = "Select count(*) From Supplier";

		string sqlString = "Select * From (Select Top " + pageSize.ToString() +
			" * From (Select Top " +
			Convert.ToString(pageSize * (supplierGrid.CurrentPageIndex + 1)) +
			" * From Supplier";

		SqlConnection connection = null;
		SqlCommand cmd = null;
		int totalNumber = 0;

		try
		{
			BaseIDataSource ds1 = DataSourceFactory.CreateInstance(ConstantUtility.SUPPLIER_DATASOURCE_NAME);
			connection = (SqlConnection)ds1.CreateConnection();
			cmd = new SqlCommand();
			cmd.Connection = connection;

			// get the where clause with parameters
			string sWhere = swb1.GetWhereClauseWithParameters(cmd);

			if (sWhere.Length > 0)
				countString += " WHERE " + sWhere;

			// execute the query
			cmd.CommandText = countString;
			SqlDataAdapter cda = new SqlDataAdapter(cmd);
			cda.Fill(cds);

			totalNumber = (int)cds.Tables[0].Rows[0].ItemArray[0];

			// concat to the select statement
			if (sWhere.Length > 0)
				sqlString += " WHERE " + sWhere;
			sqlString += " ORDER BY " + ViewState["SortField"].ToString() + " ) AS t1";
			sqlString += " ORDER BY " + ViewState["SortField"].ToString() + " DESC) AS t2";
			sqlString += " ORDER BY " + ViewState["SortField"].ToString();

			// execute the query
			cmd.CommandText = sqlString;
			SqlDataAdapter da = new SqlDataAdapter(cmd);
			da.Fill(ds);
		}
		catch (Exception ex)
		{
			throw ex;
		}
		finally
		{
			if (cmd != null) cmd.Dispose();
			if (connection != null)
			{
				connection.Close();
				connection.Dispose();
			}
		}

		DisplayGrid(totalNumber, ds);
	}

	private void DisplayGrid(int totalNumber, DataSet ds)
	{
		if (totalNumber > 0)
		{
			int pageSize = supplierGrid.PageSize;
			supplierGrid.Visible = true;
			supplierGrid.VirtualItemCount = totalNumber;
			if (totalNumber > 1)
				suppliercount.Text = totalNumber.ToString() + " applicants found";
			else
				suppliercount.Text = totalNumber.ToString() + " applicant found";
			if (totalNumber <= pageSize)
			{
				supplierGrid.AllowCustomPaging = false;
				supplierGrid.AllowPaging = false;
			}
			else
			{
				supplierGrid.AllowCustomPaging = true;
				supplierGrid.AllowPaging = true;
			}

			supplierGrid.DataSource = ds;
			supplierGrid.DataBind();
		}
		else
		{
			supplierGrid.Visible = false;
			suppliercount.Text = "No applicant found.";
		}
	}
	#endregion Private Method
}
