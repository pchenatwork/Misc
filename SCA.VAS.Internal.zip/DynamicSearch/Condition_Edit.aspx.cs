#region Reference
using System;
using System.Web.UI;
using SCA.VAS.Workflow;

using SCA.VAS.BusinessLogic.QEngine.Utilities;
using SCA.VAS.Common.Utilities;
using UNLV.IAP.WebControls;
using BaseRule = SCA.VAS.ValueObjects.QEngine.Rule;
#endregion Reference

public partial class DynamicSearch_Condition_Edit : PageBase
{
	#region Web Event Handler
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			SetInitialValue();
		}
	}

	protected void addButton_Click(object sender, EventArgs e)
	{
		if (!Page.IsValid) return;

		if (swb1.Conditions.Count == 0)
		{
			errmsg.Text = "Please add at least one condition to the query!<br>";
			errmsg.Visible = true;
			return;
		}

		if (UpdateRule())
		{
			Response.Redirect("Rule_List.aspx");
		}
		else
		{
			errmsg.Text = "Edit Query failed.";
			errmsg.Visible = true;
		}
	}
	#endregion Web Event Handler

	#region Private Method
	private void SetInitialValue()
	{
		int ruleId = ConvertUtility.ConvertInt(Request.QueryString["id"]);

		BaseRule rule = RuleUtility.Get(ConstantUtility.QENGINE_DATASOURCE_NAME, ruleId);

		if (rule != null)
		{
			ruleName.Text = rule.Name;
			description.Text = rule.Description;
			swb1.Conditions = (SqlWhereBuilderConditionCollection)XmlUtility.Deserialize(rule.ConditionXml, typeof(SqlWhereBuilderConditionCollection));
		}
	}

	private bool UpdateRule()
	{
		int ruleId = ConvertUtility.ConvertInt(Request.QueryString["id"]);

		BaseRule rule = RuleUtility.Get(ConstantUtility.QENGINE_DATASOURCE_NAME, ruleId);

		rule.Name = ruleName.Text;
		rule.Description = description.Text;
		rule.Condition = swb1.GetWhereClause();
		rule.ConditionXml = XmlUtility.ToXml(swb1.Conditions);

		return RuleUtility.Update(ConstantUtility.QENGINE_DATASOURCE_NAME, rule);
	}

	#endregion Private Method
}
