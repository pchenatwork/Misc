#region References
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.BusinessLogic.QEngine.Utilities;
using SCA.VAS.BusinessLogic.QEngine;
using SCA.VAS.ValueObjects.QEngine;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.Common.Utilities;
using SCA.VAS.DataAccess;
using SCA.VAS.Workflow;

using SCA.VAS.BusinessLogic.Content.Utilities;
using SCA.VAS.BusinessLogic.Content;
using SCA.VAS.ValueObjects.Content;
using BaseRule = SCA.VAS.ValueObjects.QEngine.Rule;
using BaseIDataSource = SCA.VAS.DataAccess.IDataSource;
#endregion Reference

public partial class DynamicSearch_dynamic_search : PageBase
{
	#region Web Event Handler
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			ViewState["SortField"] = "Company";
			ViewState["SortSequence"] = "ASC";

			SetPermission();
			BindGroup();
			groupArea.Visible = false;
		}
	}

	protected void addButton_Click(object sender, EventArgs e)
	{
	    BaseRule rule = RuleUtility.CreateObject();

		rule.QualificationId = ((PageBase)Page).UserId;
		rule.Name = ruleName.Text;
		rule.Condition = swb1.GetWhereClause();
		rule.ConditionXml = XmlUtility.ToXml(swb1.Conditions);

		if (RuleUtility.Create(ConstantUtility.QENGINE_DATASOURCE_NAME, rule))
		{
			Response.Redirect("Rule_List.aspx");
		}
	}

	protected void btnSearch_Click(object sender, EventArgs e)
	{
		BindGrid();
	}

	protected void btnNewSearch_Click(object sender, EventArgs e)
	{
		Response.Redirect("Dynamic_Search.aspx");
	}

	protected void btnDownload_Click(object sender, EventArgs e)
	{
		Server.Transfer("DownloadSupplier" + downloadType.SelectedValue + ".aspx");
	}

	protected void SortItem(object o, DataGridSortCommandEventArgs e)
	{
		if (ViewState["SortField"].ToString() == e.SortExpression)
		{
			if (ViewState["SortSequence"].ToString() == "ASC")
				ViewState["SortSequence"] = "DESC";
			else
				ViewState["SortSequence"] = "ASC";
		}
		else
		{
			ViewState["SortField"] = e.SortExpression;
		}
		BindGrid();
	}

	protected void PageChange(object o, DataGridPageChangedEventArgs e)
	{
		supplierGrid.CurrentPageIndex = e.NewPageIndex;
		BindGrid();
	}

	protected void addgroup_Click(object sender, EventArgs e)
	{
		int groupId = ConvertUtility.ConvertInt(grouplist.SelectedValue);

		if (groupId == -1) return;
		if (groupId == 0 && groupname.Text.Trim().Length == 0) return;
		if (groupId == 0)
		{
			Group group = GroupUtility.CreateObject();
			group.Name = groupname.Text.Trim();
			group.BuyerId = ((PageBase)Page).UserId;
			group.Active = "Y";
			GroupUtility.Create(ConstantUtility.CONTENT_DATASOURCE_NAME, group);
			groupId = group.Id;
		}
		GroupMemberCollection members = new GroupMemberCollection();
		foreach (DataGridItem item in supplierGrid.Items)
		{
			if ((item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem) &&
				((CheckBox)item.FindControl("supplierBox")).Checked)
			{
				GroupMember member = GroupMemberUtility.CreateObject();
				member.GroupId = groupId;
				member.SupplierId = Convert.ToInt32(supplierGrid.DataKeys[item.ItemIndex]);
				members.Add(member);
			}
		}
		GroupMemberUtility.UpdateCollection(ConstantUtility.CONTENT_DATASOURCE_NAME, groupId, members);

		BindGroup();
	}
	#endregion Web Event Handler

	#region Private Methods
	private void BindGrid()
	{
		int pageSize = supplierGrid.PageSize;

		DataSet cds = new DataSet();
		DataSet ds = new DataSet();

		string countString = "Select count(*) From Supplier";

		string sqlString = "Select * From (Select Top " + pageSize.ToString() +
			" * From (Select Top " +
			Convert.ToString(pageSize * (supplierGrid.CurrentPageIndex + 1)) +
			" * From Supplier";

		SqlConnection connection = null;
		SqlCommand cmd = null;
		int totalNumber = 0;

		try
		{
			BaseIDataSource ds1 = DataSourceFactory.CreateInstance(ConstantUtility.SUPPLIER_DATASOURCE_NAME);
			connection = (SqlConnection)ds1.CreateConnection();
			cmd = new SqlCommand();
			cmd.Connection = connection;

			// get the where clause with parameters
			string sWhere = swb1.GetWhereClauseWithParameters(cmd);

			if (sWhere.Length > 0)
				countString += " WHERE " + sWhere;

			// execute the query
			cmd.CommandText = countString;
			SqlDataAdapter cda = new SqlDataAdapter(cmd);
			cda.Fill(cds);

			totalNumber = (int)cds.Tables[0].Rows[0].ItemArray[0];

			// concat to the select statement
			if (sWhere.Length > 0)
				sqlString += " WHERE " + sWhere;
			sqlString += " ORDER BY " + ViewState["SortField"].ToString() + " ) AS t1";
			sqlString += " ORDER BY " + ViewState["SortField"].ToString() + " DESC) AS t2";
			sqlString += " ORDER BY " + ViewState["SortField"].ToString();

			// execute the query
			cmd.CommandText = sqlString;
			SqlDataAdapter da = new SqlDataAdapter(cmd);
			da.Fill(ds);
		}
		catch (Exception ex)
		{
			throw ex;
		}
		finally
		{
			if (cmd != null) cmd.Dispose();
			if (connection != null)
			{
				connection.Close();
				connection.Dispose();
			}
		}

		DisplayGrid(totalNumber, ds);
	}

	private void DisplayGrid(int totalNumber, DataSet ds)
	{
		if (totalNumber > 0)
		{
			int pageSize = supplierGrid.PageSize;
			supplierGrid.Visible = true;
			supplierGrid.VirtualItemCount = totalNumber;
			if (totalNumber > 1)
				suppliercount.Text = totalNumber.ToString() + " applicants found";
			else
				suppliercount.Text = totalNumber.ToString() + " applicant found";
			if (totalNumber <= pageSize)
			{
				supplierGrid.AllowCustomPaging = false;
				supplierGrid.AllowPaging = false;
			}
			else
			{
				supplierGrid.AllowCustomPaging = true;
				supplierGrid.AllowPaging = true;
			}

			supplierGrid.DataSource = ds;
			supplierGrid.DataBind();
			SetPermission();
		}
		else
		{
			supplierGrid.Visible = false;
			suppliercount.Text = "No applicant found.";
			btnDownload.Visible = false;
			downloadType.Visible = false;
		}
	}

	private void BindGroup()
	{
		//bind group
		grouplist.DataSource = GroupUtility.FindByCriteria(
			ConstantUtility.CONTENT_DATASOURCE_NAME,
			GroupManager.FIND_GROUP_BY_BUYER,
			new object[] { ((PageBase)Page).UserId });
		grouplist.DataBind();
		grouplist.Items.Insert(0, new ListItem("New Group", "0"));
		grouplist.Items.Insert(0, new ListItem("Select One", "-1"));
		grouplist.Attributes.Add("OnChange", "javascript:ChangeGroup(this);");
		groupname.Attributes.Add("style", "display:none");
		addgroup.Attributes.Add("style", "display:none");
	}

	private void SetPermission()
	{
		//CommonUtility.PagePermission pagePermission = CommonUtility.Permission( ((PageBase)Page).MenuId, ((PageBase)Page).UserId );

		//btnDownload.Visible = pagePermission.Download;
		//downloadType.Visible = pagePermission.Download;
	}
	#endregion Private Method
}
