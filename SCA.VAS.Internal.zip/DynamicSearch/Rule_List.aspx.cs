#region Reference
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.Workflow;

using SCA.VAS.BusinessLogic.QEngine.Utilities;
using SCA.VAS.BusinessLogic.QEngine;
using SCA.VAS.ValueObjects.QEngine;
#endregion Reference

public partial class DynamicSearch_Rule_List : PageBase
{
	#region Web Event Handler
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			BindControl();
		}
	}

	protected void BindItem(object sender, DataGridItemEventArgs e)
	{
		if (e.Item.ItemType == ListItemType.AlternatingItem ||
			e.Item.ItemType == ListItemType.Item)
		{
			ImageButton localDelete = (ImageButton)e.Item.FindControl("deleteButton");
			localDelete.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this query?')");
		}
	}

	protected void DeleteItem(object sender, DataGridCommandEventArgs e)
	{
		int id = Convert.ToInt32(RuleDataList.DataKeys[e.Item.ItemIndex]);
		RuleUtility.Delete(ConstantUtility.QENGINE_DATASOURCE_NAME, id);
		BindControl();
	}

	protected void addButton_Click(object sender, EventArgs e)
	{
		Response.Redirect("~/QEngine/Condition_Edit.aspx");
	}
	#endregion Web Event Handler

	#region Private Method
	private void BindControl()
	{
		RuleCollection rules = RuleUtility.FindByCriteria(
			ConstantUtility.QENGINE_DATASOURCE_NAME,
			RuleManager.FIND_RULE_BY_QUALIFICATION,
			new object[] { ((PageBase)Page).UserId });
		if (rules != null && rules.Count > 0)
		{
			RuleDataList.DataSource = rules;
			RuleDataList.DataBind();
			RuleDataList.Visible = true;
		}
		else
		{
			RuleDataList.Visible = false;
		}
	}
	#endregion Private Method
}
