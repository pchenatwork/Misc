using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.BusinessLogic.Common.Utilities;

using SCA.VAS.Workflow;


public partial class StateDropDown : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, System.EventArgs e)
    {
        ddstate.Items.Clear();
        ddstate.DataSource = StateUtility.GetAll(ConstantUtility.COMMON_DATASOURCE_NAME);
        ddstate.DataBind();
        ddstate.Items.Insert(0, new ListItem("All", ""));

    }
}