﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Workflow;
using Telerik.Web.UI;
using System.Threading;
using System.Timers;

public partial class CAU_Dashboard : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        affliatesTitle.Visible = false;
        peersTitle.Visible = false;
        InitializeMainDashboardGrid();
        if (!IsPostBack)
        {
            InitializeDashboardGrid();
        }
    }
    
    /// <summary>
    /// Loads the main dashboard.
    /// </summary>
    private void InitializeMainDashboardGrid()
    {
        var userDashboard = DashBoardUtility.GetDashboard(ConstantUtility.COMMON_DATASOURCE_NAME, UserName, "N")?.GetList();
        if (userDashboard != null && userDashboard.Count > 0)
        {
            var userDashboardCtrl = (UserDashboard)Page.LoadControl("~/Dashboard/UserDashBoard.ascx");
            userDashboardCtrl.BindDataGrid(userDashboard);
            UserDashboardPlaceHolder.Controls.Add(userDashboardCtrl);
        }
    }
    /// <summary>
    /// This is for child dashboards that are in Tabs right side to the main dashboard
    /// </summary>
    private void InitializeDashboardGrid()
    {
        var tabs = RadTabStripDashboard.GetAllTabs();
        bool isBudgetPeer = this.IsInRole("BA Budget Group") || this.IsInRole("BA Encumbrance Group") || this.IsInRole("VP of Finance");
        if (isBudgetPeer)
        {
          if(tabs.Count > 0)   tabs[0].Visible = true;
        }

        var userAffiliates = UserAffiliateUtility.FindByCriteria(ConstantUtility.USER_DATASOURCE_NAME, UserAffiliateManager.FIND_AFFILIATE_BY_USER, new object[] { UserId });
        if (userAffiliates != null && userAffiliates.Count > 0)
        {
            if (tabs.Count > 1) tabs[1].Visible = true;
        }
        bool isInformative = this.IsInRole("Contract Specialist") || this.IsInRole("CAU Director") || this.IsInRole("CAU Manager");
        if (isInformative)
        {
            if (tabs.Count > 2) tabs[2].Visible = true;
            if (tabs.Count > 3) tabs[3].Visible = true;
        }

        int tabCount = tabs.Where(x => x.Visible == true).Count();
        if(tabCount > 0)
        {
            string pageName = tabs[0].PageViewID;
            if (pageName == "RadPageInformativeView")
            {
                LoadInformationView();
            }
            if (pageName == "RadPageAffliatesView")
            {
                LoadAffliatesView();
            }
            if (pageName == "RadPagePeersView")
            {
                LoadPeersView();
            }

            if (pageName == "RadPageInformativeProjectView")
            {
                LoadInformationProjectsView();
            }
        }
    }

    private void LoadAffliatesView()
    {
        var userAffiliates = UserAffiliateUtility.FindByCriteria(ConstantUtility.USER_DATASOURCE_NAME,
        UserAffiliateManager.FIND_AFFILIATE_BY_USER, new object[] { UserId });
        if (userAffiliates != null && userAffiliates.Count > 0)
        {
            affliatesTitle.Visible = true;
            var userAffiliateDashboards =
                DashBoardUtility.GetDashboard(ConstantUtility.COMMON_DATASOURCE_NAME, UserName, "Y");
            if (userAffiliateDashboards != null && userAffiliateDashboards.Count > 0)
            {
                foreach (var item in userAffiliateDashboards.GetList().GroupBy(x => x.RoleName))
                {
                    var affiliateDashboardCtrl = (AffiliateDashboard)Page.LoadControl("~/Dashboard/AffiliateDashboard.ascx");
                    affiliateDashboardCtrl.BindDataGrid(item.Key, item.ToList());
                    AffiliateDashboardPlaceHolder.Controls.Add(affiliateDashboardCtrl);
                }
            }
        }
    }
    /// <summary>
    /// 
    /// </summary>
    private void LoadPeersView()
    {
        // ba groups and peers
        bool isBudgetPeer = this.IsInRole("BA Budget Group") || this.IsInRole("BA Encumbrance Group") || this.IsInRole("VP of Finance");
        if (isBudgetPeer)
        {
            var userPeersDashboards = DashBoardUtility.GetDashboard(ConstantUtility.COMMON_DATASOURCE_NAME, UserName, "P")?.GetList();
            if (userPeersDashboards != null && userPeersDashboards.Count > 0)
            {
                peersTitle.Visible = true;
                foreach (var item in userPeersDashboards.GroupBy(x => x.RoleName))
                {
                    var peersDashboardCtrl = (BAPeersDashboard)Page.LoadControl("~/Dashboard/BAPeersDashboard.ascx");
                    peersDashboardCtrl.BindDataGrid(item.Key, item.ToList());
                    BAPeersDashboardPlaceHolder.Controls.Add(peersDashboardCtrl);
                }
            }
        }
    }
    /// <summary>
    /// 
    /// </summary>
    private void LoadInformationView()
    {
        bool isInformative = this.IsInRole("Contract Specialist") || this.IsInRole("CAU Director") || this.IsInRole("CAU Manager");
        if (isInformative)
        {
            var userInfomrativeDashboards = DashBoardUtility.GetDashboard(ConstantUtility.COMMON_DATASOURCE_NAME, UserName, "I")?.GetList();
            if (userInfomrativeDashboards != null && userInfomrativeDashboards.Count > 0)
            {
                foreach (var item in userInfomrativeDashboards.GroupBy(x => x.RoleName))
                {
                    var informativeDashboardCtrl = (BAInformativeDashboard)Page.LoadControl("~/Dashboard/BAInformativeDashboard.ascx");
                    informativeDashboardCtrl.BindDataGrid(item.Key, item.ToList());
                    BAInformativeDashboardPlaceHolder.Controls.Add(informativeDashboardCtrl);
                }
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    private void LoadInformationProjectsView()
    {
        bool isInformative = this.IsInRole("Contract Specialist") || this.IsInRole("CAU Director") || this.IsInRole("CAU Manager");
        if (isInformative)
        {
            var userInfomrativeDashboardsProjectTypes = DashBoardUtility.GetDashboard(ConstantUtility.COMMON_DATASOURCE_NAME, UserName, "Z")?.GetList();
            if (userInfomrativeDashboardsProjectTypes != null && userInfomrativeDashboardsProjectTypes.Count > 0)
            {
                var informativeDashboardCtrlForProjects = (BAInformativeDashboardProjectType)Page.LoadControl("~/Dashboard/BAInformativeDashboardProjectType.ascx");
                informativeDashboardCtrlForProjects.BindDataGrid(userInfomrativeDashboardsProjectTypes);
                BAInformativeDashboardPlaceHolderProjectType.Controls.Add(informativeDashboardCtrlForProjects);
            }
        }
    }

    protected void RadTabStripDashboard_TabClick(object sender, RadTabStripEventArgs e)
    {
        if ( e.Tab.PageViewID == "RadPageInformativeView")
        {
            LoadInformationView();
        }
        if (e.Tab.PageViewID == "RadPageAffliatesView")
        {
            LoadAffliatesView();
        }
        if (e.Tab.PageViewID == "RadPagePeersView")
        {
            LoadPeersView();
        }
        if (e.Tab.PageViewID == "RadPageInformativeProjectView")
        {
            LoadInformationProjectsView();
        }
    }
}