﻿using System;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

public partial class BA_Dashboard : PageBase
 {
     protected void Page_Load(object sender, System.EventArgs e)
     {
         
     }
     
}
