﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Dynamic;
using System.Linq;
using System.Web.UI.WebControls;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Workflow;
 
public partial class BAInformativeDashboardProjectType : ControlBase
{
    public void BindDataGrid(IEnumerable<DashBoard> userDashboards)
    {
        dynGrid.DataSource = userDashboards;
        dynGrid.DataBind();
    }

    public void MergeRows(GridView gridView)
    {
        for (var rowIndex = gridView.Rows.Count - 2; rowIndex >= 0; rowIndex--)
        {
            var row = gridView.Rows[rowIndex];
            var previousRow = gridView.Rows[rowIndex + 1];

            if (row.Cells[0].Text == previousRow.Cells[0].Text)
            {
                row.Cells[0].RowSpan = previousRow.Cells[0].RowSpan < 2 ? 2 : previousRow.Cells[0].RowSpan + 1;
                previousRow.Cells[0].Visible = false;
            }
        }
    }

    protected void gridView_PreRender(object sender, EventArgs e)
    {
        MergeRows(dynGrid);
        for (var rowIndex = 0; rowIndex < dynGrid.Rows.Count; rowIndex++)
        {
            var row = dynGrid.Rows[rowIndex];
            if (row.Cells.Count > 2)
                row.Cells[2].HorizontalAlign = HorizontalAlign.Center;
        }
    }
}