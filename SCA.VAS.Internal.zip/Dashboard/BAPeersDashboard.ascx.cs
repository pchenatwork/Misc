﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Dynamic;
using System.Linq;
using System.Web.UI.WebControls;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Workflow;
 
public partial class BAPeersDashboard : ControlBase
{

    public void MergeRows(GridView gridView)
    {
        for (var rowIndex = gridView.Rows.Count - 2; rowIndex >= 0; rowIndex--)
        {
            var gvRow = gridView.Rows[rowIndex];
            var previousRow = gridView.Rows[rowIndex + 1];

            if (gvRow.Cells[0].Text == previousRow.Cells[0].Text)
            {
                gvRow.Cells[0].RowSpan = previousRow.Cells[0].RowSpan < 2 ? 2 : previousRow.Cells[0].RowSpan + 1;
                previousRow.Cells[0].Visible = false;
            }

            //for (int cellCount = 0; cellCount < gvRow.Cells.Count; cellCount++)
            //{

            //}
        }
    }

    protected void gridView_PreRender(object sender, EventArgs e)
    {
        MergeRows(dynGrid);
        for (var rowIndex = 0; rowIndex < dynGrid.Rows.Count; rowIndex++)
        {
            var row = dynGrid.Rows[rowIndex];
            if (row.Cells.Count > 2)
            {
                for (int i = 2; i < row.Cells.Count; i++)
                {
                    row.Cells[i].HorizontalAlign = HorizontalAlign.Center;
                }
            }
        }

    }

    public void BindDataGrid(string roleName, IEnumerable<DashBoard> dashboards)
    {
        DashboadHeader.Text = roleName;
        dynGrid.DataSource = PivotDashBoardRows(dashboards);
        dynGrid.DataBind();
    }

    protected void gridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            for (int cellIndex = 2; cellIndex < e.Row.Cells.Count; cellIndex++)
            {
                var currentCell = e.Row.Cells[cellIndex];
                currentCell.Controls.Clear();
                var strArr= currentCell.Text.Split('|');
                currentCell.Controls.Add(new HyperLink { Text = strArr[0], NavigateUrl = Server.HtmlDecode(strArr[1]) });
            }
        }
        if (e.Row.RowType == DataControlRowType.Header)
        {
            for (int cellIndex = 0; cellIndex < e.Row.Cells.Count; cellIndex++)
            {
                e.Row.Cells[cellIndex].BackColor = Color.FromName("#cce6ff");
                e.Row.Cells[cellIndex].BorderStyle = BorderStyle.Outset;
                e.Row.Cells[cellIndex].ForeColor = Color.FromName("#980000");
            }
        }

    }

    private DataTable PivotDashBoardRows(IEnumerable<DashBoard> dashboards)
    {
        var results =  dashboards.ToPivotTable(d => d.User,
          d => new PivotKey {Module   = d.Type,Status =  d.Name   }  ,
          d =>  d.Select(x=>new DataKey { Count = x.Count,Url = x.Url }).First() );
        return results;
    }
}