#region Reference
using System;
using System.Configuration;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting;
using SCA.VAS.ValueObjects.Template.Vetting;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion

public partial class Library_Explorer_Control : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    public void SetInitialValue(string type, int parentId)
    {
        TreeView1.Nodes.Clear();
        BuildTree(type, parentId);
        CommonUtility.ExpandAll(TreeView1.SelectedNode);
    }

    private void BuildTree(string type, int parentId)
    {
        TreeNode node = new TreeNode("Global Vettings");
        node.ImageUrl = "~/images/TreeViewImages/vetting.gif";
        node.NavigateUrl = "~/Library/Vetting_Explorer.aspx";
        VettingLibraryCollection vettingLibraries = VettingLibraryUtility.FindByCriteria(
            ConstantUtility.TEMPLATE_DATASOURCE_NAME,
            VettingLibraryManager.FIND_VETTINGLIBRARY,
            new object[] { 0 });
        BuildVettingLibraryTree(vettingLibraries, node, parentId);
        TreeView1.Nodes.Add(node);
    }
    
    private void BuildVettingLibraryTree(VettingLibraryCollection vettingLibraries, TreeNode node, int parentId)
    {
        if (vettingLibraries == null) return;

        foreach (VettingLibrary vettingLibrary in vettingLibraries)
        {
            TreeNode n1 = new TreeNode(vettingLibrary.Name);
            n1.ImageUrl = "~/images/folder.gif";
            n1.NavigateUrl = "~/Library/Vetting_Explorer.aspx?parentId=" + vettingLibrary.Id.ToString();
            node.ChildNodes.Add(n1);
            if (vettingLibrary.Id == parentId)
            {
                n1.Selected = true;
            }

            if (vettingLibrary.SubLibraries != null)
            {
                BuildVettingLibraryTree(vettingLibrary.SubLibraries, n1, parentId);
            }
        }
    }
}