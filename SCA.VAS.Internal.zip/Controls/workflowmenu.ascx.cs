using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using Menu = SCA.VAS.ValueObjects.User.Menu;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.ValueObjects.Workflow;
using SCA.VAS.BusinessLogic.Workflow.Utilities;

public partial class control_workflowmenu : UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    public void SetInitialValue()
    {
        TreeNode node = null;

        string[] keys = new string[] { "Pre Deny", "Deny", "Disqualify", "Suspend", "Withdraw", 
            "Rescind", "Reinstate", "Admin Close", "Reopen", "OIG Reopen","Ineligible","Reject", "Certification Appeal" };
        Hashtable qualHash = new Hashtable();
        qualHash.Add(keys[0], "~/Supplier/Workflow_Qual_Pre_Deny.aspx");
        qualHash.Add(keys[1], "~/Supplier/Workflow_Qual_Deny.aspx");
        qualHash.Add(keys[2], "~/Supplier/Workflow_Qual_Disqualify.aspx");
        qualHash.Add(keys[3], "~/Supplier/Workflow_Qual_Suspend.aspx");
        qualHash.Add(keys[4], "~/Supplier/Workflow_Qual_Withdraw.aspx");
        qualHash.Add(keys[5], "~/Supplier/Workflow_Qual_Rescind.aspx");
        qualHash.Add(keys[6], "~/Supplier/Workflow_Qual_Reinstate.aspx");
        qualHash.Add(keys[7], "~/Supplier/Workflow_Qual_Admin_Close.aspx");
        qualHash.Add(keys[8], "~/Supplier/Workflow_Qual_Reopen.aspx");
        qualHash.Add(keys[9], "~/Supplier/Workflow_Qual_OIG_Reopen.aspx");
        qualHash.Add(keys[10], "~/Supplier/Workflow_Qual_Ineligible.aspx");
        qualHash.Add(keys[11], "~/Supplier/Workflow_Qual_Reject.aspx");
        qualHash.Add(keys[12], "~/Supplier/Workflow_Cert_Appeal.aspx");

        PermissionDetailCollection permissionControls = PermissionDetailUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            PermissionDetailManager.FIND_PERMISSIONDETAIL_BY_USER,
            new object[] { 0, ((PageBase)Page).UserId, 
                ConstantUtility.SYSTEM_PERMISSION, 0 });

        qualTree.Nodes.Clear();
        for (int i = 0; i < keys.Length; i++)
        {
            bool hasPermission = false;
            if (permissionControls != null)
            {
                foreach (PermissionDetail permissionDetail in permissionControls)
                {
                    string[] controlPath = permissionDetail.ControlName.Split(':');
                    if (controlPath.Length > 1 && controlPath[0] == "ChangeStatusMenu"
                        && controlPath[1] == keys[i])
                    {
                        hasPermission = true;
                    }
                }
            }

            if (!hasPermission) continue;

            node = new TreeNode(keys[i], i.ToString(), "", qualHash[keys[i]].ToString() + "?Id=" + ((PageBase)Page).SupplierId.ToString(), "");
            if (((PageBase)Page).PageUrl.ToLower() == node.NavigateUrl.Substring(0, node.NavigateUrl.IndexOf("?")).ToLower())
            {
                node.Selected = true;
                node.Text = "<span style='color:#336600;'>" + node.Text + "</span>";
            }
            qualTree.Nodes.Add(node);
        }

    }

    #region Private Method
    #endregion
}
