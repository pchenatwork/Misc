﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.ValueObjects;

public partial class Control_FinancialScoringReport2 : ControlBase
{
    #region Properties
    /// <summary>
    //20190506 PCHEN: Capacity is user entered value. Using of this property is no need.
    /// </summary>
    public double Capacity
    {
        //// PCH 201904 this public property is of no use, to be obsoleted
        get
        {
            return ConvertUtility.ConvertDouble(txtCapacity.Text);
        }
    }

    public double Score
    {
        get
        {
            return ConvertUtility.ConvertDouble(txttotal_fin1.Text);
        }
    }
    private int _SupplierId
    {
        get
        {
            return ViewState["SupplierId"] == null ? 0 : (int)ViewState["SupplierId"];
        }
        set
        {
            ViewState["SupplierId"] = value;
        }
    }
    private int _RefId
    {
        get
        {
            return ViewState["RefId"] == null ? 0 : (int)ViewState["RefId"];
        }
        set
        {
            ViewState["RefId"] = value;
        }
    }
    private string _ReviewType
    {
        get
        {
            return ViewState["Type"] == null ? "" : (string)ViewState["Type"];
        }
        set
        {
            ViewState["Type"] = value;
        }
    }
    public bool ShowSaveButton
    {
        set
        {
            btnSave.Visible = value;
        }
    }
    public bool ShowHistory
    {
        get
        {
            return ViewState["ShowHistory"] == null ? true : (bool)ViewState["SupplierId"];
        }
        set
        {
            ViewState["ShowHistory"] = value;
        }
    }

    #endregion Properties
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
        }
    }

    public void SetInitialValue(int supplierId, string reviewType, int refId)
    {
        if (reviewType.In("BA","REQ"))
        {
            phPreaward1.Visible = true;
            phPreaward2.Visible = true;
        }

        ////hlPreviousFinancialModel.NavigateUrl = "~/Popup/FinancialScoringReportPopup.aspx?Id=" + supplierId.ToString();

        _SupplierId = supplierId;
        _ReviewType = reviewType;
        _RefId = refId;

        SupplierFinancialCollection supplierFinancials = SupplierFinancialUtility.FindByCriteria(
            ConstantUtility.SUPPLIER_DATASOURCE_NAME,
            SupplierFinancialManager.FIND_SUPPLIERFINANCIAL,
            new object[] { supplierId, reviewType, refId }); 
        if (supplierFinancials != null && supplierFinancials.Count > 0)
        {
            if (supplierFinancials[0].SupplierId == supplierId)
            {
                SetSupplierFinancial(supplierFinancials[0]);
                if ((supplierFinancials[0].PassOrFail??string.Empty).Length == 0) // Remove the top most record from history if there is not decision
                    supplierFinancials.Remove(supplierFinancials[0]); 
            }
                
            if (ShowHistory) _loadGrid_FinancialReportHistory(supplierFinancials);
        }
    }

    private void _loadGrid_FinancialReportHistory(SupplierFinancialCollection historyRecords)
    {
        if (historyRecords.Count > 0)
        {
            supplierFinancialGrid.DataSource = historyRecords;
            supplierFinancialGrid.DataBind();
            supplierFinancialGrid.Visible = true;
        }
        else
        {
            supplierFinancialGrid.Visible = false;
        }

    }
    public void SetInitialValue(SupplierFinancial supplierFinancial)
    {
        ///SupplierFinancial supplierFinancial = SupplierFinancialUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierFinancialId);
        SetSupplierFinancial(supplierFinancial);

        if (supplierFinancial != null)
        {
            _ReviewType = supplierFinancial.Type.Replace("Submit", string.Empty).Replace("Save", string.Empty);
            _SupplierId = supplierFinancial.SupplierId;
            _RefId = supplierFinancial.RefId;
        }

        //btnSave.Visible = false;
        //supplierFinancialGrid.Visible = false;
        ////hlPreviousFinancialModel.Visible = false;
    }
    public void SetSupplierFinancial(SupplierFinancial supplierFinancial)
    {
        if (supplierFinancial != null)
        {
            ddStatementPeriod.SelectedIndex = ddStatementPeriod.Items.IndexOf(ddStatementPeriod.Items.FindByValue(supplierFinancial.Period));
            txtAccountsReceivable.Text = supplierFinancial.AccountsReceivable.ToString();
            txtCurrentAssets.Text = supplierFinancial.AssetsCurrent.ToString();
            txtCurrentLiabilities.Text = supplierFinancial.LiabilitiesCurrent.ToString();
            txtTotalLiabilities.Text = supplierFinancial.LiabilitiesTotal.ToString();
            txtOwnersEquity.Text = supplierFinancial.Equity.ToString();
            txtRevenues.Text = supplierFinancial.Revenue.ToString();
            txtOperatingExpenses.Text = supplierFinancial.OperatingExpense.ToString();
            txtNOI.Text = supplierFinancial.NetIncome.ToString();
            txtBackLog.Text = supplierFinancial.Backlog.ToString();
            txtCurrentCash.Text = supplierFinancial.Cash.ToString();
            txtTotalLOC.Text = supplierFinancial.LocTotal.ToString();
            txtLOCDrawndown.Text = supplierFinancial.LocDrawndown.ToString();
            txtCapacity.Text = supplierFinancial.FinancialCapacity.ToString();
        }
    }
    /// <summary>
    /// PCHEN 201806 To be obsoleted. Use Save();
    /// </summary>
    public bool SaveSupplierFinancial(int supplierId, string type, int refId, string passorFail = "", string comments = "")
    {
        throw new System.NotImplementedException("SaveSupplierFinancial() obsoleted");
        /** Obsoleted **
        var type2 = type == "PreQualSubmit" ? "PreQual" : type;

        SupplierFinancial supplierFinancial = null;
        SupplierFinancialCollection supplierFinancials = SupplierFinancialUtility.FindByCriteria(
            ConstantUtility.SUPPLIER_DATASOURCE_NAME,
            SupplierFinancialManager.FIND_SUPPLIERFINANCIAL,
            new object[] { supplierId, type2, refId });
        if (supplierFinancials != null && supplierFinancials.Count > 0 && !type2.Contains("Save"))
        {
            supplierFinancial = supplierFinancials[0];

            supplierFinancials[0].Type = "PreQualSubmit";
            SupplierFinancialUtility.Update(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierFinancials[0]);
        }
        else
        {
            supplierFinancial = SupplierFinancialUtility.CreateObject();
            supplierFinancial.Type = type2;
            supplierFinancial.SupplierId = supplierId;
            supplierFinancial.RefId = refId;
            supplierFinancial.Comments = comments;
            supplierFinancial.PassOrFail = passorFail;
        }

        supplierFinancial.Period = ddStatementPeriod.SelectedValue;
        supplierFinancial.AccountsReceivable = ConvertUtility.ConvertLong(txtAccountsReceivable.Text);
        supplierFinancial.AssetsCurrent = ConvertUtility.ConvertLong(txtCurrentAssets.Text);
        supplierFinancial.LiabilitiesCurrent = ConvertUtility.ConvertLong(txtCurrentLiabilities.Text);
        supplierFinancial.LiabilitiesTotal = ConvertUtility.ConvertLong(txtTotalLiabilities.Text);
        supplierFinancial.Equity = ConvertUtility.ConvertLong(txtOwnersEquity.Text);
        supplierFinancial.Revenue = ConvertUtility.ConvertLong(txtRevenues.Text);
        supplierFinancial.OperatingExpense = ConvertUtility.ConvertLong(txtOperatingExpenses.Text);
        supplierFinancial.NetIncome = ConvertUtility.ConvertLong(txtNOI.Text);
        supplierFinancial.Backlog = ConvertUtility.ConvertLong(txtBackLog.Text);
        supplierFinancial.Cash = ConvertUtility.ConvertLong(txtCurrentCash.Text);
        supplierFinancial.LocTotal = ConvertUtility.ConvertLong(txtTotalLOC.Text);
        supplierFinancial.LocDrawndown = ConvertUtility.ConvertLong(txtLOCDrawndown.Text);
        supplierFinancial.FinancialCapacity = ConvertUtility.ConvertLong(txtCapacity.Text);
        supplierFinancial.ChangeUser = ((PageBase)this.Page).UserName;
        supplierFinancial.Comments = comments;
        supplierFinancial.PassOrFail = passorFail;
        if (supplierFinancial.Id > 0)
        {
            if (type == "PreQualSubmit")
            {
                supplierFinancial.Id = 0;
                supplierFinancial.Type = "PreQual";
                supplierFinancial.Comments = comments;
                supplierFinancial.PassOrFail = passorFail;
                supplierFinancial.CreateDate = DateTime.Now;
                return SupplierFinancialUtility.Create(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierFinancial);
            }
            else
            {
                return SupplierFinancialUtility.Update(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierFinancial);
            }

        }
        else
            return SupplierFinancialUtility.Create(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierFinancial);
        ***/
    }
    /// <summary>
    /// An attempt to replace SaveSupplierFinancial() to embrace Financial Scoring other than "PreQual"
    /// saveType 
    /// </summary>
    /// <param name="saveType">saveType is obsoleted (not needed any more)</param>
    /// <param name="passorFail">Decision</param>
    /// <param name="comments">Comments</param>
    /// <returns></returns>
    public bool Save(string saveType = "", string passorFail = "", string comments = "")
    {
        /* --------------------------------------------- *
         * Note PCHEN 201904, Created to replace SaveSupplierFinancial() to embrace "type" other than "PreQual".
         *  Once tested, this should replace existing SaveSupplierFinancial() method, which is only for 'PreQual'
         * --------------------------------------------- *
         * Assumption is 2 types of 'saveType' operations: 'Save' + 'Submit'
         *  By looking at existing records, the max(changedate) of 'PreQualSave' is '2016-05-24 12:07:59.100'
         *    Seem type of 'xxxSave' has been obsoleted. 
         *    Type => "PreQual" or "PreQualSubmit"
                       "BA" or "BASubmit"
         *    In order to backward compatible. treat parameter 'type' of "xxxSave" the same as "xxx".
         * --------------------------------------------- *
         * *** Revised 20190613. [SupplierFinancial].Type == {PreQual, PreQualSubmit} has caused confusion ***
         *  Since most of the SPs is referencing [SupplierFinancial].Type=='PreQual' for FinancialCapacity data,
         *  to make the lease amount of changes to SP script, here is the new defination of Type:
         *  1. Top most record is always "PreQual", and only one "PreQual" each Supplier
         *  2. 'PreQualSubmit' === Snapshot of historic record(with decision and comment)
         *  3. Note: Update would only apply to records without decision
         * --------------------------------------------- */

        if (!(_SupplierId > 0 && _ReviewType.Length > 0)) return false;

        bool bOK = true;
        var thisUser = ((PageBase)this.Page).UserName;

        SupplierFinancial supplierFinancial_0 = SupplierFinancialUtility.CreateObject(); // Current data from UI
        supplierFinancial_0.Type = _ReviewType;
        supplierFinancial_0.SupplierId = _SupplierId;
        supplierFinancial_0.RefId = _RefId;
        supplierFinancial_0.Period = ddStatementPeriod.SelectedValue;
        supplierFinancial_0.AccountsReceivable = ConvertUtility.ConvertLong(txtAccountsReceivable.Text);
        supplierFinancial_0.AssetsCurrent = ConvertUtility.ConvertLong(txtCurrentAssets.Text);
        supplierFinancial_0.LiabilitiesCurrent = ConvertUtility.ConvertLong(txtCurrentLiabilities.Text);
        supplierFinancial_0.LiabilitiesTotal = ConvertUtility.ConvertLong(txtTotalLiabilities.Text);
        supplierFinancial_0.Equity = ConvertUtility.ConvertLong(txtOwnersEquity.Text);
        supplierFinancial_0.Revenue = ConvertUtility.ConvertLong(txtRevenues.Text);
        supplierFinancial_0.OperatingExpense = ConvertUtility.ConvertLong(txtOperatingExpenses.Text);
        supplierFinancial_0.NetIncome = ConvertUtility.ConvertLong(txtNOI.Text);
        supplierFinancial_0.Backlog = ConvertUtility.ConvertLong(txtBackLog.Text);
        supplierFinancial_0.Cash = ConvertUtility.ConvertLong(txtCurrentCash.Text);
        supplierFinancial_0.LocTotal = ConvertUtility.ConvertLong(txtTotalLOC.Text);
        supplierFinancial_0.LocDrawndown = ConvertUtility.ConvertLong(txtLOCDrawndown.Text);
        supplierFinancial_0.FinancialCapacity = ConvertUtility.ConvertLong(txtCapacity.Text);
        supplierFinancial_0.Comments = comments;
        supplierFinancial_0.PassOrFail = passorFail;
        supplierFinancial_0.CreateUser = thisUser;
        supplierFinancial_0.CreateDate = DateTime.Now;
        supplierFinancial_0.ChangeUser = thisUser;
        supplierFinancial_0.ChangeDate = DateTime.Now;

        SupplierFinancial supplierFinancial_1 = null; 
        SupplierFinancialCollection supplierFinancials = SupplierFinancialUtility.FindByCriteria(
            ConstantUtility.SUPPLIER_DATASOURCE_NAME,
            SupplierFinancialManager.FIND_SUPPLIERFINANCIAL,
            new object[] { _SupplierId, _ReviewType, _RefId });
        if (supplierFinancials != null && supplierFinancials.Count > 0 )
        {
            if (supplierFinancials[0].SupplierId==_SupplierId)
                supplierFinancial_1 = supplierFinancials[0]; // Current topmost record in DB with same SupplierId
        }

        if (supplierFinancial_1 == null)
        {
            // If no record, insert _0
            bOK &= SupplierFinancialUtility.Create(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierFinancial_0);
        }
        else
        {
            /* *** *
             * If there is existing record
             * When submit(with decision)/Save(not decision):
             *  If the topmost existing record has decision, create a new one
             *  otherwise update the existing one
             * *** */
            /// bool isSubmit = saveType.ToLower().Contains("submit");

            if ((supplierFinancial_1.PassOrFail ?? string.Empty).Length > 0)  // Top most record has decision
            {
                supplierFinancial_1.Type = _ReviewType + "Submit"; // Mark "Submit" as historic record
                supplierFinancial_1.ChangeUser = thisUser;
                supplierFinancial_1.ChangeDate = DateTime.Now;
                bOK &= SupplierFinancialUtility.Update(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierFinancial_1);
                bOK &= SupplierFinancialUtility.Create(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierFinancial_0);
            }
            else  // update record without a decision yet, with the data from UI (_0)
            {
                // Update topmost record; _1 with value from _0 ()
                supplierFinancial_0.Id = supplierFinancial_1.Id;
                supplierFinancial_0.CreateUser = supplierFinancial_1.CreateUser;
                supplierFinancial_0.CreateDate = supplierFinancial_1.CreateDate;
                bOK &= SupplierFinancialUtility.Update(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierFinancial_0);
            }
        }
        
        if (bOK) SetInitialValue(_SupplierId, _ReviewType, _RefId);

        return bOK;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        Save();
    }

    protected void BindItem(object o, DataGridItemEventArgs e)
    {
        //if (e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem) return;

        //SupplierFinancial sf = (SupplierFinancial)e.Item.DataItem;
        //HyperLink hlView = (HyperLink)e.Item.FindControl("hlView");
        //hlView.NavigateUrl = "~/Popup/FinancialScoringReportPopup2.aspx?Id=" + sf.Id;

    }
}
