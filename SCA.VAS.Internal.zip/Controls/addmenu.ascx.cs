using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using Menu = SCA.VAS.ValueObjects.User.Menu;

public partial class addmenu : UserMenu
{
    protected string pageName;
    protected bool pagePermission;
    protected static string menuLocation;
    protected int menuLevel = 0;
    protected int stepId = -1;
    
    protected void Page_Load(object sender, EventArgs e)
    {
         if (!IsPostBack)
         {
         }
    }

    public void SetInitialValue(bool isPermissionControl)
    {
        bool isReadonly = false;
        if (Request.QueryString["readonly"] != null && Request.QueryString["readonly"] == "true")
            isReadonly = true;

        pageName = ((PageBase)this.Page).PageUrl;
        //Registration Menu
        if (pageName.ToLower().IndexOf("supplier_add_wizard") >= 0 && ((PageBase)Page).SupplierId > 0)
        {
            regMenu.Collapsed = false;
            stepId = ConvertUtility.ConvertInt(Request.QueryString["step"]);
            //if (stepId == 0) stepId++; //starting with one because Application Type not required internally
            MenuCollection regMenus = ((PageBase)Page).RegistrationMenus;
            int startIndex = 0;
            if (!((PageBase)Page).CurrentSupplier.IsNonAppplicant())
                startIndex = 0; //starting with one because Application Type not required internally
            if (regMenus != null)
            {
                for (int i = startIndex; i < regMenus.Count; i++)
                {
                    if (regMenus[i].ParentId > 0) continue;
                    string url = string.Empty;
                    if (Request.QueryString["step"] != null)
                        url = Request.Url.ToString().Replace("&step=" + stepId.ToString(), "&step=" + regMenus[i].Id.ToString());
                    else
                        url = Request.Url.ToString() + "&step=" + regMenus[i].Id.ToString();
                    TreeNode tn = new TreeNode(regMenus[i].Text, regMenus[i].Id.ToString(), regMenus[i].ImgLeft, url, "");

                    BindRegMenu(tn, regMenus[i]);
                    if (stepId == regMenus[i].Id)
                    {
                        tn.Selected = true;
                        tn.Text = "<span style='color:#336600;'>" + regMenus[i].Text + "</span>";
                    }
                    treeMenu.Nodes.Add(tn);
                }
            }
        }
        else
        {
            registrationMenu.Visible = false;
        }
    }

    override public int MenuId
    {
        get
        {
            if (ViewState["MenuId"] != null)
                return ConvertUtility.ConvertInt(ViewState["MenuId"].ToString());

            Menu menu = MenuUtility.GetByUrl(ConstantUtility.USER_DATASOURCE_NAME, Membership.ApplicationName,
                ((PageBase)this.Page).PageUrl);
            if (menu != null)
            {
                ViewState["MenuId"] = menu.Id;
                return menu.Id;
            }
            return 0;
        }
    }

    override public string ReadOnlyPermission
    {
        get { return string.Empty; }
    }

    #region Private Method

    private void BindRegMenu(TreeNode menuItem, Menu menu)
    {
        bool isReadonly = false;
        if (Request.QueryString["readonly"] != null && Request.QueryString["readonly"] == "true")
            isReadonly = true;

        if (menu.SubMenus == null || menu.SubMenus.Count == 0) return;
        MenuCollection menus = menu.SubMenus;
        for (int i = 0; i < menus.Count; i++)
        {
            string url = "~/Supplier/Supplier_Add_Wizard.aspx?Id=" + ((PageBase)Page).SupplierId.ToString() + "&step=" + menus[i].Id.ToString();
            if (isReadonly)
                url += "&readonly=true";
            else
                url += "&readonly=false";
            if (Request.QueryString["view"] != null)
                url += "&view=" + Request.QueryString["view"].ToString();
            if (Request.QueryString["type"] != null)
                url += "&type=" + Request.QueryString["type"].ToString();
            TreeNode subMenuItem = new TreeNode(menus[i].Text, menus[i].Id.ToString(), menus[i].ImgLeft, url, "");
            subMenuItem.Value = menus[i].Id.ToString();

            BindRegMenu(subMenuItem, menus[i]);
            menuItem.ChildNodes.Add(subMenuItem);

            //toggle tree
            if (menuItem.ChildNodes[i].Value == stepId.ToString())
            {
                menuItem.ChildNodes[i].Selected = true;
                menuItem.Expanded = true;
                menuItem.ChildNodes[i].Text = "<span style='color:#336600;'>" + menuItem.ChildNodes[i].Text + "</span>";
            }
        }
    }
    #endregion
}
