using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using Menu = SCA.VAS.ValueObjects.User.Menu;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.ValueObjects.Workflow;
using SCA.VAS.BusinessLogic.Workflow.Utilities;

public partial class control_safwfmenu : UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    public void SetInitialValue()
    {
        TreeNode node = null;

        string[] keys = new string[] { "Approve", "Deny", "Supercede" };
        Hashtable qualHash = new Hashtable();
        qualHash.Add(keys[0], "~/Subcontractor/SAF_Approve.aspx");
        qualHash.Add(keys[1], "~/Subcontractor/SAF_Deny.aspx");
        qualHash.Add(keys[2], "~/Subcontractor/SAF_Supercede.aspx");

        qualTree.Nodes.Clear();
        for (int i = 0; i < keys.Length; i++)
        {
            node = new TreeNode(keys[i], i.ToString(), "", qualHash[keys[i]].ToString() + "?Id=" + ((PageBase)Page).SupplierId.ToString(), "");
            if (((PageBase)Page).PageUrl.ToLower() == node.NavigateUrl.Substring(0, node.NavigateUrl.IndexOf("?")).ToLower())
            {
                node.Selected = true;
                node.Text = "<span style='color:#336600;'>" + node.Text + "</span>";
            }
            qualTree.Nodes.Add(node);
        }

    }

    #region Private Method
    #endregion
}
