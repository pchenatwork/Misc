using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.Win32;

public partial class top : System.Web.UI.UserControl
{
    protected string envText = string.Empty;
    protected string systemMsgText = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (((PageBase)Page).PageUrl == "~/login.aspx")
                logoImg.ImageUrl = "~/Images/logo_sm.gif";
        }
        envText = AppConfig.GetConfigValue("Environment");
        systemMsgText = SCA.VAS.BusinessLogic.Common.Utilities.SettingUtility.GetValueByName(SCA.VAS.Workflow.ConstantUtility.COMMON_DATASOURCE_NAME, "System Message"); // AppConfig.GetConfigValue("SystemMessage"); 

    }
}
