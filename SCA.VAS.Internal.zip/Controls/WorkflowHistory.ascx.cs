﻿using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.ValueObjects.Workflow;
using SCA.VAS.Workflow;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CTL_WorkflowHistory : ControlBase
{
    public void SetInitialValue(int tranId)
    {
        ValueObjectCollection<WorkflowHistory> h = new ValueObjectCollection<WorkflowHistory>();

        WorkflowHistoryCollection tempHistories = WorkflowHistoryUtility.FindByCriteria(
            ConstantUtility.WORKFLOW_DATASOURCE_NAME,
            WorkflowHistoryManager.FIND_WORKFLOWHISTORY_BY_TRANS,
            new object[] { tranId });

        if (tempHistories != null)
        {
            for (int i = 0; i < tempHistories.Count; i++)
            {
                if (tempHistories[i].CurrentNodeName.Length > 0)
                {
                    h.Add(tempHistories[i]);
                }
            }
        }
        grdWorkflowHistory.DataSource = h;
        grdWorkflowHistory.DataBind();
    }
}