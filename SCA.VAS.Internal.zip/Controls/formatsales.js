var n;
var f;
var p;
var p1;
function ValidateSales()
{
	var pv=p1.value;
	p="";
	for (var i = 0; i < pv.length; i++)
	{
		if (pv.charAt(i).match(/\d/) != null)
			p+=pv.charAt(i);
	}
	if (p.length > 3 && p.charAt(p.length-3) != ',')
	{
		length1=p.length;
		pre1=p.substring(0,length1-3);
		post1=p.substring(length1-3,length1);
		p=pre1+","+post1;
	}
	if (p.length > 7 && p.charAt(p.length-7) != ',')
	{
		length1=p.length;
		pre1=p.substring(0,length1-7);
		post1=p.substring(length1-7,length1);
		p=pre1+","+post1;
	}
	if (p.length > 11 && p.charAt(p.length-11) != ',')
	{
		length1=p.length;
		pre1=p.substring(0,length1-11);
		post1=p.substring(length1-11,length1);
		p=pre1+","+post1;
	}
	if (p!=pv)
	{
		eval('document.' + f + '.' + n + '.value="";');
		eval('document.' + f + '.' + n + '.value="' + p + '";');
	}
}

function SalesFormat(field, form)
{
	n = field.id;
	f = form.id;
	eval('p1 = document.' + f + '.' + n + ';');
	setTimeout('ValidateSales()',500);
}

function ClientFormat(objId)
{
    n = getElement(objId).id;
    f = getElement(objId).form.id;
    p1 = getElement(objId);
    ValidateSales();
}