using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;
using System.Web.Security;
using System.Web.Configuration;

public partial class Timeout : System.Web.UI.UserControl
{
    private bool _enabled = true;
    public bool Enabled
    {
        get
        {
            return _enabled;
        }
        set
        {
            this._enabled = value;
        }
    }
    private double _warningSeconds = 600; //10 minutes
    public double WarningSeconds
    {
        get
        {
            return _warningSeconds;
        }
        set
        {
            this._warningSeconds = value;
        }
    }
    private double _timeoutSeconds = 0;
    public double TimeoutSeconds
    {
        get
        {
            if (_timeoutSeconds == 0)
            {
                try
                {
                    _timeoutSeconds = Math.Round(((FormsIdentity)Context.User.Identity).Ticket.Expiration.Subtract(DateTime.Now).TotalSeconds);
                }
                catch { }
            }
            return _timeoutSeconds;
        }
    }
    
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!Request.IsAuthenticated)
            this.Enabled = false;
    }
    
    protected void btnContinue_Click(object sender, System.EventArgs e)
    {
    }

    protected void lbLogin_Click(object sender, System.EventArgs e)
    {
        if (!Request.IsAuthenticated)
            Response.Redirect("~/login.aspx");
    }
}