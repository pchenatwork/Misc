using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using Menu = SCA.VAS.ValueObjects.User.Menu;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.ValueObjects.Workflow;
using SCA.VAS.BusinessLogic.Workflow.Utilities;

public partial class control_limlistwfmenu : UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    public void SetInitialValue()
    {
        TreeNode node = null;

        string[] keys = new string[] { "Request for Inclusion", "Cancel List", "Refresh List", "Rescind Firm" };
        Hashtable qualHash = new Hashtable();
        qualHash.Add(keys[0], "~/Rfd/Project_SearchSupplier.aspx");
        qualHash.Add(keys[1], "~/Rfd/Project_Cancel.aspx");
        qualHash.Add(keys[2], "~/Rfd/Project_Refresh.aspx");
        qualHash.Add(keys[3], "~/Rfd/Workflow_Director_Rescind.aspx");

        PermissionDetailCollection permissionControls = PermissionDetailUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            PermissionDetailManager.FIND_PERMISSIONDETAIL_BY_USER,
            new object[] { 0, ((PageBase)Page).UserId, 
                ConstantUtility.SYSTEM_PERMISSION, 0 });

        qualTree.Nodes.Clear();
        for (int i = 0; i < keys.Length; i++)
        {
            bool hasPermission = false;
            if (permissionControls != null)
            {
                foreach (PermissionDetail permissionDetail in permissionControls)
                {
                    string[] controlPath = permissionDetail.ControlName.Split(':');
                    if (controlPath.Length > 1 && controlPath[0] == "ChangeStatusMenu"
                        && controlPath[1] == keys[i])
                    {
                        hasPermission = true;
                    }
                }
            }

            if (!hasPermission) continue;

            node = new TreeNode(keys[i], i.ToString(), "", qualHash[keys[i]].ToString() + "?Id=" + Request.QueryString["Id"], "");
            if (((PageBase)Page).PageUrl.ToLower() == node.NavigateUrl.Substring(0, node.NavigateUrl.IndexOf("?")).ToLower())
            {
                node.Selected = true;
                node.Text = "<span style='color:#336600;'>" + node.Text + "</span>";
            }
            qualTree.Nodes.Add(node);
        }

    }

    #region Private Method
    #endregion
}
