using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using Menu = SCA.VAS.ValueObjects.User.Menu;

public partial class menu : UserMenu
{
    protected string pageName;
    protected bool pagePermission;
    protected static string menuLocation;
    protected int menuLevel = 0;
    
    protected void Page_Load(object sender, EventArgs e)
    {
         if (!IsPostBack)
         {
            if (Context.User.Identity.IsAuthenticated)
            {
                User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, ((PageBase)this.Page).UserId);
                username.Text = "Welcome " + user.FullName;
            }
         }
    }

    public void SetInitialValue(bool isPermissionControl)
    {
        pageName = ((PageBase)this.Page).PageUrl;
        pagePermission = false;

        MenuCollection menus = MenuUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            MenuManager.FIND_MENU_BY_USER,
            new object[] { ((PageBase)this.Page).UserId, Membership.ApplicationName, pageName });
        
        Menu1.Items.Clear();
        Menu1.ScriptPath = Page.ResolveUrl("~/Controls/skmMenu.js");
        Menu1.IFrameSrc = Page.ResolveUrl("~/blank.htm");

        if (menus != null)
        {
            for (int i = 0; i < menus.Count; i++)
            {
                if (menus[i].ParentId > 0) continue;
                skmMenu.MenuItem menuItem = new skmMenu.MenuItem(
                    menus[i].Text, menus[i].Url, menus[i].ToolTip);
                menuItem.Text = "<div>" + menuItem.Text + "</div>";

                string pageUrl = Page.ResolveUrl(menus[i].Url);
                if (menus[i].Url.Trim().Length == 0)
                    menuLocation = menus[i].Text;
                else
                    menuLocation = "<a href=" + pageUrl + ">" + menus[i].Text + "</a>";

                if (!pagePermission && menus[i].Url.ToLower().IndexOf(pageName.ToLower()) != -1)
                {
                    pagePermission = true;
                    ViewState["MenuId"] = menus[i].Id;
                    ViewState["ReadOnlyPermission"] = menus[i].Result;
                    section.Text = menuLocation;
                }

                BindSubMenu(menuItem, menus[i]);
                if (menus[i].Display == "Y")
                    Menu1.Items.Add(menuItem);
            }
        }

        if (!pagePermission && isPermissionControl)
        {
            Response.Redirect("~/PermissionDenied.aspx");
        }
    }

    override public int MenuId
    {
        get
        {
            if (ViewState["MenuId"] != null)
                return ConvertUtility.ConvertInt(ViewState["MenuId"].ToString());

            Menu menu = MenuUtility.GetByUrl(ConstantUtility.USER_DATASOURCE_NAME, Membership.ApplicationName,
                ((PageBase)this.Page).PageUrl);
            if (menu != null)
            {
                ViewState["MenuId"] = menu.Id;
                return menu.Id;
            }
            return 0;
        }
    }

    override public string ReadOnlyPermission
    {
        get
        {
            if (ViewState["ReadOnlyPermission"] != null)
                return ViewState["ReadOnlyPermission"].ToString();

            return string.Empty;
        }
    }

    #region Private Method
    private void BindSubMenu(skmMenu.MenuItem menuItem, Menu menu)
    {
        menuLevel++;
        if (menu.SubMenus == null) return;
        MenuCollection menus = menu.SubMenus;
        for (int i = 0; i < menus.Count; i++)
        {
            skmMenu.MenuItem subMenuItem = new skmMenu.MenuItem(
				menus[i].Text, menus[i].Url, menus[i].ToolTip);
			subMenuItem.LeftImage = menus[i].ImgLeft;
			subMenuItem.RightImage = menus[i].ImgRight;

            if (!pagePermission && menus[i].Url.ToLower().IndexOf(pageName.ToLower()) != -1)
            {
                pagePermission = true;
                ViewState["MenuId"] = menus[i].Id;
                ViewState["ReadOnlyPermission"] = menus[i].Result;
                section.Text = menuLocation + " :: " + menus[i].Text;
            }

            string pageUrl = Page.ResolveUrl(menus[i].Url);
            if (menus[i].Url.Trim().Length == 0)
                menuLocation += " :: " + menus[i].Text;
            else
                menuLocation += " :: <a href=" + pageUrl + ">" + menus[i].Text + "</a>";
            BindSubMenu(subMenuItem, menus[i]);
            if (menus[i].Display == "Y")
                menuItem.SubItems.Add(subMenuItem);
            menuLocation = menuLocation.Substring(0, menuLocation.LastIndexOf("::") - 1);
        }
        if (menuLevel > 1 && menuItem.SubItems.Count > 0)
			menuItem.Text += " <img src=\"" + Page.ResolveUrl("~/App_Themes/" + Page.Theme + "/images/menu-arrow.gif") + "\" />";
        menuLevel--;
    }
    #endregion
}
