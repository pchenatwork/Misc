var helpTimeout = null;
var helpToggle = true;

function popup(url, width, height) 
{
	var pWin = window.open(url,"NewWin","height=" + height + ",width=" + width + ",location=no,toolbar=no,scrollbars=yes,resizable=no,menubar=no");
	pWin.focus();
	return pWin;
}
function popupResizeable(url, width, height, center) {
    if (center)
        return PopupCenter(url, "", width, height);
    else {
        var pWin = window.open(url, "NewWin", "height=" + height + ",width=" + width + ",location=no,toolbar=no,scrollbars=yes,resizable=yes,menubar=no");
        pWin.focus();       
        return pWin;
    }

}
function newwindow(url, width, height) 
{
	var Secondwin;
	Secondwin = window.open(url,"NewWin2","height=" + height + ",width=" + width + ",location=no,toolbar=no,scrollbars=yes,resizable=yes,menubar=no");
}
function limitLength( control, length )
{
	if( control.value.length > length )
	{
		control.value = control.value.substr( 0, length );
	}
}

function PopupCenter(url, title, w, h) {
    // Fixes dual-screen position                         Most browsers      Firefox

    var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : window.screenX;
    var dualScreenTop = window.screenTop != undefined ? window.screenTop : window.screenY;

    var width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
    var height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;

    var left = ((width / 2) - (w / 2)) + dualScreenLeft;
    var top = ((height / 2) - (h / 2)) + dualScreenTop;
    var newWindow = window.open(url, title, 'location=no,toolbar=no,scrollbars=yes,resizable=yes,menubar=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);

    // Puts focus on the newWindow
    if (window.focus) {
        newWindow.focus();
    }

    return newwindow;
}



function validate_username(oldname, name, url, textbox) {
    if (oldname != '' && oldname == name) return;
    document.body.style.cursor = 'wait';
    // Create an instance of the XML HTTP Request object
    var oXMLHTTP = zXmlHttp.createRequest();
    //XMLHTTP NOT SUPPORTED BY BROWSER
    if (!oXMLHTTP) return false;
    oXMLHTTP.onreadystatechange =
		function () {

		    if (oXMLHTTP.readyState != 4)
		        return;
		    if (oXMLHTTP.status == 200) {
		        if (oXMLHTTP.responseText == "exist") {
		            alert("Sorry - the user name " + name + " already exists.");
		            textbox.value = oldname;
		            textbox.focus();
		        }
		    }
		    else {

		        //code to handle bad data or no data
		    }
		};
    
    // Prepare the XMLHTTP object for a HTTP POST to our validation ASP page
		var sURL = url + "validateusername.ashx?name=" + name;
    oXMLHTTP.open("GET", sURL, true);
    // Execute the request
    oXMLHTTP.send("");

        document.body.style.cursor = 'auto';

}

function validateemail(name, url) {
	document.body.style.cursor='wait';

	// Create an instance of the XML HTTP Request object
	var oXMLHTTP = new ActiveXObject( "Microsoft.XMLHTTP" );
	
	// Prepare the XMLHTTP object for a HTTP POST to our validation ASP page
	var sURL = url + "validateemail.ashx?name=" + name;
	oXMLHTTP.open( "POST", sURL, false );

	// Execute the request
	oXMLHTTP.send();
	
	if (oXMLHTTP.responseText == "exist")
	{
		alert("Sorry - the user name " + name + " already exists.");
		document.getElementById('ctl00_content_companyinfo_username').value = '';
		document.getElementById('ctl00_content_companyinfo_username').focus();
	}

	document.body.style.cursor='auto';
}
function validate_fedid(fid,vid, url,textbox) {
	document.body.style.cursor='wait';

	// Create an instance of the XML HTTP Request object
	var oXMLHTTP = zXmlHttp.createRequest();
	//XMLHTTP NOT SUPPORTED BY BROWSER
	if (!oXMLHTTP) return false;
	
	oXMLHTTP.onreadystatechange = 
		function()
		{
			if (oXMLHTTP.readyState != 4)
				return;
			if (oXMLHTTP.status == 200)
			{
				if (oXMLHTTP.responseText == "exist")
				{
					alert("Sorry - a company with Federal ID: " + fid + " already exists.");
					textbox.value = '';
					textbox.focus();
				}
			}
			else
			{
				//code to handle bad data or no data
			}
		};
	
	// Prepare the XMLHTTP object for a HTTP POST to our validation ASP page
		var sURL = url + "validatefedid.ashx?fid=" + fid + "&vid=" + vid;
	oXMLHTTP.open("GET", sURL, true);
	// Execute the request
	oXMLHTTP.send("");
	
	document.body.style.cursor='auto';
}
function validateemail1(name, url) {
	document.body.style.cursor='wait';

	// Create an instance of the XML HTTP Request object
	var oXMLHTTP = new ActiveXObject( "Microsoft.XMLHTTP" );
	
	// Prepare the XMLHTTP object for a HTTP POST to our validation ASP page
	var sURL = url + "validateemail.ashx?name=" + name;
	oXMLHTTP.open( "POST", sURL, false );

	// Execute the request
	oXMLHTTP.send();
	
	if (oXMLHTTP.responseText == "exist")
	{
		alert("Sorry - the user name " + name + " already exists.");
		document.getElementById('ctl00_content_newid').value = '';
		document.getElementById('ctl00_content_newid').focus();
	}

	document.body.style.cursor='auto';
}
function validate_keyperson(ssn, supplierId, url, pId, textbox) {
	document.body.style.cursor='wait';

	// Create an instance of the XML HTTP Request object
	var oXMLHTTP = zXmlHttp.createRequest();
	//XMLHTTP NOT SUPPORTED BY BROWSER
	if (!oXMLHTTP) return false;
	
	oXMLHTTP.onreadystatechange = 
		function()
		{
			if (oXMLHTTP.readyState != 4)
				return;
			if (oXMLHTTP.status == 200)
			{
				if (oXMLHTTP.responseText == "exist")
				{
					alert("Sorry - a key person with SSN: " + ssn + " already exists.");
					textbox.value = '';
					textbox.focus();
				}
			}
			else
			{
				//code to handle bad data or no data
			}
		};
	
	// Prepare the XMLHTTP object for a HTTP POST to our validation ASP page
	var sURL = url + "validatekeyperson.ashx?ssn=" + ssn + "&Id=" + supplierId + "&pId=" + pId;
	oXMLHTTP.open("GET", sURL, true);
	// Execute the request
	oXMLHTTP.send("");
	
	document.body.style.cursor='auto';
}

function getTop(o, sBreakAt) 
{
	var iTop = 0;
	if (o.offsetParent) {
		if(sBreakAt && (oParent = getElement(sBreakAt))) 
		{
			while (o.offsetParent && (o.offsetParent != oParent)){
				iTop += o.offsetTop;o = o.offsetParent;
			}
		}
		else
		{	
			while (o.offsetParent){
				iTop += o.offsetTop;o = o.offsetParent;
			}
		}
		
	} else if (o.y) {
		iTop += o.y;
	}
	return iTop + 4;
}

function getLeft(o) 
{
	var iLeft = 0;
	if (o.offsetParent) {
		while (o.offsetParent) {
			iLeft += o.offsetLeft;o = o.offsetParent;
		}
	} else if (o.x) {
		iLeft += o.x;
	}
	return iLeft + 4;
}


function setEvent(oElement, sEventType, fEventHandler) 
{
	if (typeof(oElement) == 'string')
		oElement = getElement(oElement);
	if(window.attachEvent) {
		oElement.attachEvent('on'+sEventType, fEventHandler);
	} else if (window.addEventListener) {
		oElement.addEventListener(sEventType, fEventHandler, false);
	} else {
		
		if(oElement['on'+sEventType]) {		
			oldFunc = oElement['on'+sEventType];
			oElement['on'+sEventType] = function() {
				oldFunc;
				fEventHandler;
			}
		} else {
			oElement['on'+sEventType] = fEventHandler;
		}
	}
}

function getElementsByTagAndClass(a_sTagName, a_sClassName) 
{
	var aReturnElements = [];
	if(document.getElementsByTagName) {
		var aAllTags = document.getElementsByTagName(a_sTagName);
		for(j = 0; j < aAllTags.length; j++) {
			var oCurrentTag = aAllTags[j];
			if(oCurrentTag.className == a_sClassName) {
				aReturnElements[aReturnElements.length] = oCurrentTag;
			}
		}
	}
	return aReturnElements;
}

function getElement(a_sElementId) 
{
	if (typeof(a_sElementId) != "string")
		return a_sElementId;
	var oElement = (document.getElementById) ? document.getElementById(a_sElementId) : (document.all) ? document.all[a_sElementId] : null;
	if(oElement == null) {	
		for(i = 0; i < document.forms.length; i++) {
			var form = document.forms[i];
			if(form.name == a_sElementId) {
				return form;
			} else {
				for(j = 0; j < form.elements.length; j++) {
					element = form.elements[j];
					if(element.name == a_sElementId) {
						return element;
					}
				}
			}
		}
		if(document.images[a_sElementId]) {
			return document.images[a_sElementId];
		} else if(document.anchors[a_sElementId]) {
			return document.anchors[a_sElementId];
		} else if (document.layers) { 
		}
	}
	return oElement;
}

function showFormHelp(sHeader, sInfo)
{
	var oHelp = getElement('formHelp');

	var oHelpHeader = getElement('formHelpHeader');
	var oHelpText = getElement('formHelpInfo');
	
	if(sHeader && sInfo)
	{
		oHelpHeader.innerHTML = sHeader;
		oHelpText.innerHTML = sInfo;
		if (helpToggle)
			oHelp.className = 'formHelpOn';
		oHelp.style.display = 'block';
	}
	else
		oHelp.style.display = 'none';
}

function hideFormHelp()
{
	var oHelp = getElement('formHelp');
	var oHelpToggle = getElement('formHelpMini');
	
	oHelpToggle.innerHTML = '?';
	oHelp.className = 'formHelpOff';
}

function toggleFormHelp()
{
	var oHelp = getElement('formHelp');
	var oHelpToggle = getElement('formHelpMini');
	if (oHelp.className == 'formHelpOff')
	{
		oHelp.className = 'formHelpOn';
		oHelpToggle.innerHTML = '&ndash;';
		helpToggle = true;
	}
	else
	{
		oHelp.className = 'formHelpOff';
		oHelpToggle.innerHTML = '?';
		helpToggle = false;
	}
	clearTimeout(helpTimeout);
}

function showFormHelp(sHeader, sInfo)
{
	var oHelp = getElement('formHelp');
	var oHelpHeader = getElement('formHelpHeader');
	var oHelpText = getElement('formHelpInfo');
	
	if(sHeader && sInfo)
	{
		oHelpHeader.innerHTML = sHeader;
		oHelpText.innerHTML = sInfo;
		oHelp.style.display = 'block';
	}
	else
		oHelp.style.display = 'none';
}

function hideFormHelp(thisElement)
{
	var oHelp = getElement('formHelp');
	var oHelpToggle = getElement('formHelpMini');
	
	oHelpToggle.innerHTML = '&nbsp;';
	oHelp.className = 'formHelpOff';
	moveHelp(thisElement, oHelp);
}

function toggleFormHelp(thisElement)
{
	var oHelp = getElement('formHelp');
	var oHelpToggle = getElement('formHelpMini');
	if (oHelp.className == 'formHelpOff')
	{
		oHelp.className = 'formHelpOn';
		oHelpToggle.innerHTML = '&ndash;';
		helpToggle = true;
		if (thisElement != null)
			moveHelp(thisElement, oHelp);
	}
	else
	{
		hideFormHelp(thisElement);
		helpToggle = false;
	}
	clearTimeout(helpTimeout);
}

function setFormHelp(thisElement)
{
	if (typeof(thisElement) == 'string')
		thisElement = getElement(thisElement);
	var id = thisElement.id || thisElement.name;
	var oHelp = getElement('formHelp');
	var oHelpToggle = getElement('formHelpMini');
	
	oHelpToggle.href = "javascript:toggleFormHelp(\'" + id + "\');";
	if (id.indexOf('Link') != -1 && !helpToggle)
		toggleFormHelp(id);
	showFormHelp(helptips[id + 'Title'], helptips[id + 'Text']);
	if (helpToggle)
	{
		oHelp.className = 'formHelpOn';
		oHelpToggle.innerHTML = '&ndash;';
	}
	moveHelp(thisElement, oHelp);
	clearTimeout(helpTimeout);
	helpTimeout = setTimeout("hideFormHelp(\'" + id + "\')", Math.pow(oHelp.offsetHeight - 15,1.1) * 100 );
}

function moveHelp(thisElement, oHelp)
{
	if (typeof(thisElement) == 'string')
		thisElement = getElement(thisElement);
	if (typeof(oHelp) == 'string')
		oHelp = getElement(oHelp);
	var y = getTop(thisElement);
	var x = getLeft(thisElement);
	var id = thisElement.id || thisElement.name;
	var anchor = helptips[id + 'Anchor'];
	var theme = getElement("ctl00_content_tooltip_themeName").value;
	var backgroundStyle = "url(" + theme + "/images/bg_help_box_YLOCXLOC.gif) no-repeat YALIGN XALIGN";
	
	if(isNaN(helptips[id + '_OffsetX']) == false)
		x += parseInt(helptips[id + '_OffsetX']);
	if(isNaN(helptips[id + '_OffsetY']) == false)
		y += parseInt(helptips[id + '_OffsetY']);
	if(anchor) {
		if( anchor.indexOf('top') >= 0 )
		{
			oHelp.style.top = (y - oHelp.offsetHeight) + "px";
			backgroundStyle = backgroundStyle.replace(/YLOC/,'b');
			backgroundStyle = backgroundStyle.replace(/YALIGN/,'bottom');
		}
		else if( anchor.indexOf('middle') >= 0 )
		{
			oHelp.style.top = (y + (thisElement.offsetHeight/2) - (oHelp.offsetHeight/2)) + "px";
			backgroundStyle = backgroundStyle.replace(/YLOC/,'m');
			backgroundStyle = backgroundStyle.replace(/YALIGN/,'center');
		}
		else if( anchor.indexOf('bottom') >= 0 )
		{
			oHelp.style.top = (y + thisElement.offsetHeight) + "px";
			backgroundStyle = backgroundStyle.replace(/YLOC/,'t');
			backgroundStyle = backgroundStyle.replace(/YALIGN/,'top');
		}
		if( anchor.indexOf('left') >= 0 )
		{
			oHelp.style.left = (x - oHelp.offsetWidth) + "px";
			backgroundStyle = backgroundStyle.replace(/XLOC/,'r');
			backgroundStyle = backgroundStyle.replace(/XALIGN/,'right');
		}
		else if( anchor.indexOf('center') >= 0 )
		{
			oHelp.style.left = (x + (thisElement.offsetWidth/2) - (oHelp.offsetWidth/2)) + "px";
			backgroundStyle = backgroundStyle.replace(/XLOC/,'c');
			backgroundStyle = backgroundStyle.replace(/XALIGN/,'center');
		}
		else if( anchor.indexOf('right') >= 0 )
		{
			oHelp.style.left = (x + thisElement.offsetWidth) + "px";
			backgroundStyle = backgroundStyle.replace(/XLOC/,'l');
			backgroundStyle = backgroundStyle.replace(/XALIGN/,'left');
		}
	}
	else
	{
		oHelp.style.top = (y + (thisElement.offsetHeight/2) - (oHelp.offsetHeight/2)) + "px";
		backgroundStyle = backgroundStyle.replace(/YLOC/,'m');
		backgroundStyle = backgroundStyle.replace(/YALIGN/,'center');
		oHelp.style.left = (x + thisElement.offsetWidth) + "px";
		backgroundStyle = backgroundStyle.replace(/XLOC/,'l');
		backgroundStyle = backgroundStyle.replace(/XALIGN/,'left');
	}
	oHelp.style.background = backgroundStyle;
}

function attachHelpTexts()
{	
	for(var i = 0; i < document.forms[0].elements.length; i++)
	{
		if (document.forms[0].elements[i].type == "button" || document.forms[0].elements[i].type == "submit")
		{
			var element = document.forms[0].elements[i];
			element.onmouseover = function (){setFormHelp(this);};
			element.onmouseout = function (){setFormHelp(this);};
		}
		else if (document.forms[0].elements[i].getAttribute('id')) 
		{
			var element = document.forms[0].elements[i];
			element.onfocus = function (){setFormHelp(this);};
		}
	}
}


function toggleElementDisplay(elementRef) {
    try {
        var oElement = getElement(elementRef);
        if (oElement.style.display == 'none')
            oElement.style.display = '';
        else
            oElement.style.display = 'none';
    }
    catch (e) {
        return false;
    }
}

function topImgSwap(thisElement, str)
{
	thisElement = getElement(thisElement);
	thisElement.src = thisElement.src.replace(/_off|_on/ , str);
}

function isLeapYear(year)
{
	year = parseInt(year);
	if(year%4 == 0)
	{
		if(year%100 != 0)
			return true;
		else
		{
			if(year%400 == 0)
				return true;
			else
				return false;
		}
	}
	return false;
}

function dateIsValid(month, day, year)
{
	month = parseInt(month);
	day = parseInt(day);
	year = parseInt(year);
	switch(month)
	{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			if(day <= 31)
				return true;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			if(day <= 30)
				return true;
			break;
		case 2:
			if(day <= 28 || (day == 29 && isLeapYear(year)))
				return true;
			break;
	}
	return false;
}

function dateIsGreater(datestring1, datestring2) //checks if the first date is later than the second date
{
	if(datestring1 == "invalid" || datestring2 == "invalid") //do not validate incomplete dates
		return true;
	
	var date1, date2;
	
	if(datestring1 == "now")
		date1 = new Date();
	else
		date1 = new Date(datestring1);
	if(datestring2 == "now")
		date2 = new Date();
	else
		date2 = new Date(datestring2);
	
	var month1 = date1.getMonth();
	var day1 = date1.getDate();
	var year1 = date1.getFullYear();
	
	var month2 = date2.getMonth();
	var day2 = date2.getDate();
	var year2 = date2.getFullYear();
	
	if(year1 > year2)
		return true;
	else if(year1 < year2)
		return false;
	else //if same year
	{
		if(month1 > month2)
			return true;
		else if(month1 < month2)
			return false;
		else //if same month
		{
			if(day1 > day2)
				return true;
			else //if day2 is greater or if dates are equal
				return false;
		}
	}
}

function fileIsTooBig(file, validator)
{
//	validator.errormessage = "File cannot be larger than 10MB";
//	var oas = new ActiveXObject("Scripting.FileSystemObject");
//	var d = file.value;
//	if(d != "")
//	{
//		var e = oas.getFile(d);
//		var g
//		var f = e.size;
//		if(f/1024 > 10240)
//			return true;
//		//alert(f/1024 + " Kilo-bytes");
//	}
	return false;
}

function getQueryString(key)
{
    var querystrings = window.location.search.substring(1).split('&');
    var value = "";
    for(var i=0; i<querystrings.length; i++)
    {
		if(querystrings[i].indexOf(key + "=") == 0)
		{
			value = querystrings[i].substring(querystrings[i].indexOf("=") + 1);
			break;
		}
    }
    return value;
}

function fixedDecimal(value, decimal_places) {
    return (Math.round(value * Math.pow(10, decimal_places)) / Math.pow(10, decimal_places)).toFixed(decimal_places);
}