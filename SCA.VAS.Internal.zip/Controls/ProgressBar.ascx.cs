using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.Common.Utilities;

public partial class Controls_ProgressBar : System.Web.UI.UserControl
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
		}
	}

    public void SetProgress(int totalNum, int completeNum)
    {
        progressTable.Rows.Add(new TableRow());
        double widthNum = 100 / totalNum;
        widthNum = Math.Round(widthNum);
        Unit width = new Unit(widthNum, UnitType.Percentage);
        for (int i = 0; i < totalNum; i++)
        {
            TableCell tableCell = new TableCell();
            tableCell.Width = width;
            tableCell.BorderWidth = 1;
            if (i < completeNum)
                tableCell.CssClass = "activeCell";
            else
                tableCell.CssClass = "inactiveCell";
            progressTable.Rows[0].Cells.Add(tableCell);
        }
    }
}
