﻿
(function($) {

    $.fn.salesFormat = function(options) {

        var defaults = {
            prefix: '',
            centsSeparator: '',
            thousandsSeparator: ',',
            limit: false,
            centsLimit: 0
        };

        var options = $.extend(defaults, options);

        return this.each(function() {

            // pre defined options
            var obj = $(this);
            var is_number = /[0-9]/;

            // load the pluggings settings
            var prefix = options.prefix;
            var centsSeparator = options.centsSeparator;
            var thousandsSeparator = options.thousandsSeparator;
            var limit = options.limit;
            var centsLimit = options.centsLimit;

            // skip everything that isn't a number
            // and also skip the left zeroes
            function to_numbers(str) {
                var formatted = '';
                for (var i = 0; i < (str.length); i++) {
                    char = str.charAt(i);
                    if (formatted.length == 0 && char == 0) char = false;
                    if (char && char.match(is_number)) {
                        if (limit) {
                            if (formatted.length < limit) formatted = formatted + char;
                        } else {
                            formatted = formatted + char;
                        }
                    }
                }
                return formatted;
            }

            // format to fill with zeros to complete cents chars
            function fill_with_zeroes(str) {
                while (str.length < (centsLimit + 1)) str = '0' + str;
                return str;
            }

            function post_zeros_for_decimal(val, climit)
            {                
                while (val.length < climit) {
                    val = val + '0';
                }

                return val;
            }

            // format as price
            function price_format(str) {
                /*
                var number = parseFloat(str.replace(/,/g, ''));
                if (isNaN(number)==false) {
                    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                } else return 0;

                //return number.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                */
                
                    if (centsLimit > 0) 
                    {
                        if (str.indexOf('.') > 0) 
                        {
                            var decimals = str.substr(str.indexOf('.') + 1);
                            var num = str.substr(0, str.indexOf('.'));

                            if (decimals.length > centsLimit)
                                decimals = decimals.substr(0, 2);
                            else                                
                                decimals = post_zeros_for_decimal(decimals, centsLimit);
                            
                            str = num + decimals;
                        }
                        else
                            str = post_zeros_for_decimal(str, str.length + centsLimit);
                    }

                    // formatting settings
                    var formatted = str;  //fill_with_zeroes(to_numbers(str));
                    
                    var thousandsFormatted = '';
                    var thousandsCount = 0;
    
                    // split integer from cents
                    var centsVal = formatted.substr(formatted.length - centsLimit, centsLimit);
                    var integerVal = formatted.substr(0, formatted.length - centsLimit);
    
                    // apply cents pontuation
                    formatted = integerVal + centsSeparator + centsVal;
    
                    // apply thousands pontuation
                    if (thousandsSeparator) {
                        for (var j = integerVal.length; j > 0; j--) {
                            char = integerVal.substr(j - 1, 1);
                            thousandsCount++;
                            if (thousandsCount % 3 == 0) char = thousandsSeparator + char;
                            thousandsFormatted = char + thousandsFormatted;
                        }
                        if (thousandsFormatted.substr(0, 1) == thousandsSeparator) thousandsFormatted = thousandsFormatted.substring(1, thousandsFormatted.length);
                        formatted = thousandsFormatted + centsSeparator + centsVal;
                    }
    
                    // apply the prefix
                    if (prefix && formatted.indexOf(prefix) < 0 ) formatted = prefix + formatted;
    
                    return formatted;
                    

            }

            // filter what user type (only numbers and functional keys)
            function key_check(e) {
                
                var code = (e.keyCode ? e.keyCode : e.which); 
                var typed = String.fromCharCode(code);
                var functional = false;
                var str = obj.val();
                var newValue = price_format(str + typed);
                
                functional = checkCopyPaste(e);

                // allow keypad numbers, 0 to 9
                if (code >= 48 && code <= 57) functional = true;
                if (code >= 96 && code <= 105) functional = true;

                // check Backspace, Tab, Enter, and left/right arrows, Delete
                if (code == 8) functional = true;
                if (code == 9) functional = true;
                if (code == 13) functional = true;
                if (code == 37) functional = true;
                if (code == 39) functional = true;
                if (code == 46) functional = true;
                
                if ((code == 190 || code == 110) && centsLimit > 0)
                    functional = !str.includes('.');

                if (code == 189 || code == 109) {
                    prefix = '-';
                }
                if (code == 107) {
                    prefix = '';
                }
                if (!functional) {
                    e.preventDefault();
                    e.stopPropagation();
                   //if (str != newValue) obj.val(newValue);
                }

            }

            function checkCopyPaste(event) {
                if (
                    // Allow: Ctrl+A
                    (event.keyCode == 65 && event.ctrlKey === true) ||

                        // Allow: Ctrl+V
                        (event.ctrlKey == true && (event.which == '118' || event.which == '86')) ||

                        // Allow: Ctrl+c
                        (event.ctrlKey == true && (event.which == '99' || event.which == '67')) ||

                        // Allow: Ctrl+x
                        (event.ctrlKey == true && (event.which == '120' || event.which == '88')) ||

                        // Allow: home, end, left, right
                        (event.keyCode >= 35 && event.keyCode <= 39)) {
                    // let it happen, don't do anything
                    return true;
                } else {
                    return false;
                }
            }

            // inster formatted price as a value of an input field
            function price_it() {
                var str = obj.val();
                var price = price_format(str);
                if (str !== price ) obj.val(price);
            }
            function toNumeric() {
                var str = obj.val().replace('$', '');
                var number = parseFloat(str.replace(/,/g, '')); 
                if (str !== number) {
                    obj.val(number);
                } //else obj.val(0);
                if (isNaN(obj.val()) || obj.val() === "0"  ) obj.val("");
            }
            //function formatNumbers(e) {

            //    // skip for arrow keys
            //    if(e.which >= 37 && e.which <= 40) return;

            //    // format number
            //    $(this).val(function(index, value) {
            //        return value
            //                .replace(/\D/g, "")
            //                .replace(/\B(?=(\d{3})+(?!\d))/g, ",")
            //            ;
            //    });
            //}

            // bind the actions
            $(this).bind('keydown', key_check);
            //$(this).bind('keyup', price_it);
            //$(this).bind('keyup', formatNumbers);
            $(this).bind('blur', price_it);
            $(this).bind('focus', toNumeric);
            //if ($(this).val().length > 0) price_it();

        });

    };
    $.fn.alterFormat = function(options) {

        var defaults = {
            prefix: '',
            centsSeparator: '',
            thousandsSeparator: ',',
            limit: false,
            centsLimit: 0
        };

        var options = $.extend(defaults, options);

        return this.each(function() {

            // pre defined options
            var obj = $(this);
            var is_number = /[0-9]/;

            // load the pluggings settings
            var prefix = options.prefix;
            var centsSeparator = options.centsSeparator;
            var thousandsSeparator = options.thousandsSeparator;
            var limit = options.limit;
            var centsLimit = options.centsLimit;

            // skip everything that isn't a number
            // and also skip the left zeroes
            function to_numbers(str) {
                var formatted = '';
                for (var i = 0; i < (str.length); i++) {
                    char = str.charAt(i);
                    if (formatted.length == 0 && char == 0) char = false;
                    if (char && char.match(is_number)) {
                        if (limit) {
                            if (formatted.length < limit) formatted = formatted + char;
                        } else {
                            formatted = formatted + char;
                        }
                    }
                }
                return formatted;
            }

            // format to fill with zeros to complete cents chars
            function fill_with_zeroes(str) {
                while (str.length < (centsLimit + 1)) str = '0' + str;
                return str;
            }

            // format as price
            function price_format(str) {
                
                var number = parseFloat(str.replace(/,/g, ''));
                if (isNaN(number)==false) {
                    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                } else return 0;
                //return number.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                /*
                    
                    // formatting settings
                    var formatted = fill_with_zeroes(to_numbers(str));
                    var thousandsFormatted = '';
                    var thousandsCount = 0;
    
                    // split integer from cents
                    var centsVal = formatted.substr(formatted.length - centsLimit, centsLimit);
                    var integerVal = formatted.substr(0, formatted.length - centsLimit);
    
                    // apply cents pontuation
                    formatted = integerVal + centsSeparator + centsVal;
    
                    // apply thousands pontuation
                    if (thousandsSeparator) {
                        for (var j = integerVal.length; j > 0; j--) {
                            char = integerVal.substr(j - 1, 1);
                            thousandsCount++;
                            if (thousandsCount % 3 == 0) char = thousandsSeparator + char;
                            thousandsFormatted = char + thousandsFormatted;
                        }
                        if (thousandsFormatted.substr(0, 1) == thousandsSeparator) thousandsFormatted = thousandsFormatted.substring(1, thousandsFormatted.length);
                        formatted = thousandsFormatted + centsSeparator + centsVal;
                    }
    
                    // apply the prefix
                    if (prefix) formatted = prefix + formatted;
    
                    return formatted;
                    */

            }

            // filter what user type (only numbers and functional keys)
            function key_check(e) {

                var code = (e.keyCode ? e.keyCode : e.which);
                var typed = String.fromCharCode(code);
                var functional = false;
                var str = obj.val();

                if (code == 189 || code == 109) {
                    var position = str.indexOf('-');
                    if (position > -1 || this.selectionStart > 0) {
                        return false;
                    }
                }
                //if (str < 0 && this.selectionStart === 0) return false;

                var newValue = price_format(str + typed);

                functional = checkCopyPaste(e);
                
                // allow keypad numbers, 0 to 9
                if (code >= 48 && code <= 57) functional = true;
                if (code >= 96 && code <= 105) functional = true;

                // check Backspace, Tab, Enter, and left/right arrows, Delete
                if (code == 8) functional = true;
                if (code == 9) functional = true;
                if (code == 13) functional = true;
                if (code == 37) functional = true;
                if (code == 39) functional = true;
                if (code == 46) functional = true;

                if (code == 189 || code == 109) {
                    functional = true;
                    prefix = '-';
                }
                if (code == 107) {
                    prefix = '';
                }

                if (!functional) {
                    e.preventDefault();
                    e.stopPropagation();
                    //if (str != newValue) obj.val(newValue);
                }
         

            }

            function checkCopyPaste(event) {
                if (
                    // Allow: Ctrl+A
                    (event.keyCode == 65 && event.ctrlKey === true) ||

                    // Allow: Ctrl+V
                    (event.ctrlKey == true && (event.which == '118' || event.which == '86')) ||

                    // Allow: Ctrl+c
                    (event.ctrlKey == true && (event.which == '99' || event.which == '67')) ||

                    // Allow: Ctrl+x
                    (event.ctrlKey == true && (event.which == '120' || event.which == '88')) ||

                    // Allow: home, end, left, right
                    (event.keyCode >= 35 && event.keyCode <= 39)) {
                    // let it happen, don't do anything
                    return true;
                } else {
                    return false;
                }
            }

            // inster formatted price as a value of an input field
            function price_it() {
                var str = obj.val();
                var price = price_format(str);
                if (str !== price ) obj.val(price);
            }
            function toNumeric() {
                var str = obj.val();
                var number = parseFloat(str.replace(/,/g, ''));
                if (str !== number) {
                    obj.val(number);
                } //else obj.val(0);
                if (isNaN(obj.val()) || obj.val() === "0"  ) obj.val("");
               
            }

            //function formatNumbers(e) {

            //    // skip for arrow keys
            //    if(e.which >= 37 && e.which <= 40) return;

            //    // format number
            //    $(this).val(function(index, value) {
            //        return value
            //                .replace(/\D/g, "")
            //                .replace(/\B(?=(\d{3})+(?!\d))/g, ",")
            //            ;
            //    });
            //}

            // bind the actions
            $(this).bind('keydown', key_check);
            //$(this).bind('keyup', price_it);
            //$(this).bind('keyup', formatNumbers);
            $(this).bind('blur', price_it);
            $(this).bind('focus', toNumeric);
            //if ($(this).val().length > 0) price_it();

        });

    };
})(jQuery);
