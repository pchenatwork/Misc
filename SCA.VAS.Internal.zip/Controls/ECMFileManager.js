﻿/* PCHEN 202011 JS behind control of same name */
var JS = (function () {
    return {
        ValidateMe: function (src, args) {
            args.IsValid = false;
            var e = $('#' + src.id.replace('_Validator', '') + '_Selector').find('[type=file]');
            if (e.length > 0 && e[0].value.length > 0) {
                args.IsValid = true;
            };
        }
    }
})();