#region Reference
using System;
using System.Configuration;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Template.Vetting.Utilities;
using SCA.VAS.BusinessLogic.Template.Vetting;
using SCA.VAS.ValueObjects.Template.Vetting;
#endregion

public partial class GlobalVetting_Explorer_Control : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    public void SetInitialValue(int parentId, int vettingId)
    {
        TreeView1.Nodes.Clear();
        BuildTree(parentId, vettingId);
        CommonUtility.ExpandAll(TreeView1.SelectedNode);
    }

    private void BuildTree(int parentId, int vettingId)
    {
        // Create a root node
        TreeNode root = new TreeNode("Vettings");
        root.NavigateUrl = "~/Vetting/Vetting_List.aspx";
        root.ImageUrl = "~/images/TreeViewImages/vetting.gif";

        VettingListCollection vettings = VettingListUtility.FindByCriteria(
            ConstantUtility.TEMPLATE_DATASOURCE_NAME,
            VettingListManager.FIND_VETTINGLIST_BY_USER,
            new object[]
            {
                0,
                0,
                ((PageBase)Page).UserId
            });
        if (vettings != null && vettings.Count > 0)
        {
            foreach (VettingList vetting in vettings)
            {
                TreeNode c = new TreeNode(CommonUtility.GetShortName(vetting.Name));
                c.ImageUrl = "~/images/TreeViewImages/vetting.gif";
                c.NavigateUrl = "~/Vetting/Vetting_List.aspx?parentId=0&vettingId=" + vetting.Id.ToString();
                root.ChildNodes.Add(c);
                if (vettingId == vetting.Id)
                {
                    c.Selected = true;
                }
            }
        }

        VettingLibraryCollection vettingLibraries = VettingLibraryUtility.FindByCriteria(
            ConstantUtility.TEMPLATE_DATASOURCE_NAME,
            VettingLibraryManager.FIND_VETTINGLIBRARY_BY_USER,
            new object[] { 0, ((PageBase)Page).UserId });

        BuildLibraryTree(vettingLibraries, root, parentId, vettingId);

        if (parentId == 0)
        {
            root.Selected = true;
        }

        // Add root node to TreeView
        TreeView1.Nodes.Add(root);
        CommonUtility.ExpandAll(TreeView1.SelectedNode);
    }

    private void BuildLibraryTree(VettingLibraryCollection vettingLibraries, TreeNode node, int parentId, int vettingId)
    {
        if (vettingLibraries == null) return;

        foreach (VettingLibrary vettingLibrary in vettingLibraries)
        {
            TreeNode n1 = new TreeNode(vettingLibrary.Name);
			n1.ImageUrl = "~/images/folder.gif";
            n1.NavigateUrl = "~/Vetting/Vetting_List.aspx?parentId=" + vettingLibrary.Id.ToString();
            node.ChildNodes.Add(n1);
            if (vettingLibrary.Id == parentId)
            {
                n1.Selected = true;
            }

            VettingListCollection vettings = VettingListUtility.FindByCriteria(
                ConstantUtility.TEMPLATE_DATASOURCE_NAME,
                VettingListManager.FIND_VETTINGLIST_BY_USER,
                new object[]
                {
                    0,
                    vettingLibrary.Id,
                    ((PageBase)Page).UserId
                });
            if (vettings != null && vettings.Count > 0)
            {
                foreach (VettingList vetting in vettings)
                {
                    TreeNode c = new TreeNode(CommonUtility.GetShortName(vetting.Name));
                    c.ImageUrl = "~/images/TreeViewImages/vetting.gif";
                    c.NavigateUrl = "~/Vetting/Vetting_List.aspx?parentId=" + vettingLibrary.Id.ToString()
                        + "&vettingId=" + vetting.Id.ToString();
                    n1.ChildNodes.Add(c);
                    if (vettingId == vetting.Id)
                    {
                        c.Selected = true;
                    }
                }
            }

            if (vettingLibrary.SubLibraries != null)
            {
                BuildLibraryTree(vettingLibrary.SubLibraries, n1, parentId, vettingId);
            }
        }
    }
}