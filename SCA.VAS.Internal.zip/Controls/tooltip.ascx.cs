using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class tooltip : System.Web.UI.UserControl
{
	protected void Page_Load(object sender, System.EventArgs e)
	{
		if (!IsPostBack)
		{
			themeName.Value = Page.ResolveUrl("~") + "App_Themes/" + Page.Theme;
		}
	}
}