<!-- Begin
function IsValidTime(timeStr) {
	// Checks if time is in HH:MM format.
	var timePat = /^(\d{1,2}):(\d{2})?$/;

	var matchArray = timeStr.match(timePat);
	if (matchArray == null) {
		//alert("Time is not in a valid format.");
		return false;
	}
	hour = matchArray[1];
	minute = matchArray[2];

	if (hour < 1 || hour > 12) {
		//alert("Hour must be between 1 and 12.");
		return false;
	}
	
	if (minute == null)
	{
		return false;
	}
	
	if (minute < 0 || minute > 59) {
		//alert ("Minute must be between 0 and 59.");
		return false;
	}
	return true;
}
//  End -->
