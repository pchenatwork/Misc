﻿function zXmlHttpThreadArray(name)
{
	this.name = name;
	this.threadId = new Array();
	this.threadArray = new Array();
}
zXmlHttpThreadArray.prototype.getLength = function(){return this.threadArray.length;};
zXmlHttpThreadArray.prototype.getThread = function(arrayIndex){return this.threadArray[arrayIndex];};
zXmlHttpThreadArray.prototype.addThread = function(oXmlHttpThread)
{
	this.threadArray.push(oXmlHttpThread);
	this.threadId.push(oXmlHttpThread.id);
	return this.threadArray.length;
};
zXmlHttpThreadArray.prototype.removeThread = function(oXmlHttpThread)
{
	var arrayIndex = null;
	for (var i = 0; i < this.getLength(); i++)
		arrayIndex = this.threadId[i] == oXmlHttpThread.id ? i : arrayIndex;
	this.threadId[arrayIndex] = null;
	this.threadArray[arrayIndex] = null;
	return null;
};

function zXmlHttpThread(id, type)
{
	this.id = id;
	this.type = type;
	this.request = zXmlHttp.createRequest();
}
zXmlHttpThread.prototype.register = function(oXmlHttpThreadArray)
{
	oXmlHttpThreadArray.addThread(this);
};
zXmlHttpThread.prototype.unregister = function(oXmlHttpThreadArray)
{
	oXmlHttpThreadArray.removeThread(this);
};