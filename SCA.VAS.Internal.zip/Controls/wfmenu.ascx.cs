using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using Menu = SCA.VAS.ValueObjects.User.Menu;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.ValueObjects.Workflow;
using SCA.VAS.BusinessLogic.Workflow.Utilities;

public partial class wfmenu : UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    public void SetInitialValue()
    {
        if (((PageBase)Page).PageUrl.ToLower().IndexOf("workflow_qual") < 0)
        {
            //qMenu.Collapsed = true;
            qualMenu.Visible = false;
            CertAppealMenu.Visible = false;
        }
        else if (((PageBase)Page).PageUrl.ToLower().IndexOf("workflow_cert_") < 0)
        {
            //cMenu.Collapsed = true;
            certMenu.Visible = false;
            CertAppealMenu.Visible = false;
        }
        if (((PageBase)Page).PageUrl.ToLower().IndexOf("workflow_certappeal") > 0)
        {
            qualMenu.Visible = false;

            CertAppealMenu.Visible = true;
            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, ((PageBase)Page).UserId);

            string[] userRoles = Roles.GetRolesForUser(user.UserName);

            foreach (string userRole in userRoles)
            {
                if (userRole.IndexOf("General Counsel") != -1)
                    certMenu.Visible = false;
            }

        }
        string qualNodeString = "";
        string certNodeString = "";
        Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, ((PageBase)Page).SupplierId);
        SupplierCertDenialAppeal appealrecord =
            SupplierCertDenialAppealUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, ((PageBase)Page).SupplierId);
        if (appealrecord != null)
            CertAppealMenu.Visible = true;
        if (supplier.SupplierWorkflows != null && supplier.SupplierWorkflows.Count > 0)
        {
            foreach (SupplierWorkflow sf in supplier.SupplierWorkflows)
            {
                if (sf.WorkflowId == 1)
                {
                    WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNodeByUser(sf.TransactionId, ((PageBase)Page).UserId);

                    if (workflowHistory != null)
                    {
                        foreach (WorkflowNode wn in workflowHistory.NextLinks)
                        {
                            qualNodeString += wn.Name + "|";
                        }
                        if (qualNodeString.Length > 0)
                            qualNodeString = qualNodeString.Substring(0, qualNodeString.Length - 1);
                    }
                }
                if (sf.WorkflowId == 2)
                {
                    WorkflowHistory workflowHistory = WorkflowControl.GetFirstActiveNodeByUser(sf.TransactionId, ((PageBase)Page).UserId);

                    if (workflowHistory != null)
                    {
                        foreach (WorkflowNode wn in workflowHistory.NextLinks)
                        {
                            certNodeString += wn.Name + "|";
                        }
                    }
                    if (certNodeString.Length > 0)
                        certNodeString = certNodeString.Substring(0, certNodeString.Length - 1);
                }
            }
        }

        string[] qualNodes = qualNodeString.Split('|');
        string[] certNodes = certNodeString.Split('|');


        SupplierStatus supplierQualStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_QUALIFICATION);
        SupplierStatus supplierCertStatus = supplier.SupplierStatuses.FindByType(ConstantUtility.WORKFLOW_CERTIFICATION);

        TreeNode node = null;

        string[] keys = new string[] { "Manager Review", "Reviewer Review", "Reference Review", "Financial Analysis", "OIG Review", "OIG Response", "Reviewer Final Review", "Final Review"/*, "Disqualify", "Application Withdraw"*/ };
        Hashtable qualHash = new Hashtable();
        qualHash.Add(keys[0], "~/Supplier/Workflow_Qual_Review.aspx");
        qualHash.Add(keys[1], "~/Supplier/Workflow_Qual_Review2.aspx");
        qualHash.Add(keys[2], "~/Supplier/Workflow_Qual_Ref_Review.aspx");
        qualHash.Add(keys[3], "~/Supplier/Workflow_Qual_Financial_Review_new.aspx");
        qualHash.Add(keys[4], "~/Supplier/Workflow_Qual_OIG_Review.aspx");
        qualHash.Add(keys[5], "~/Supplier/Workflow_Qual_OIG_Response.aspx");
        qualHash.Add(keys[6], "~/Supplier/Workflow_Qual_Review3.aspx");
        qualHash.Add(keys[7], "~/Supplier/Workflow_Qual_Final_Review.aspx");
        //qualHash.Add(keys[8], "~/Supplier/Workflow_Qual_Disqualify.aspx");
        //qualHash.Add(keys[9], "~/Supplier/Workflow_Qual_Withdraw.aspx");

        qualTree.Nodes.Clear();
        bool isNext = false;
        for (int i = 0; i < keys.Length; i++)
        {
            node = new TreeNode(keys[i], i.ToString(), "", qualHash[keys[i]].ToString() + "?Id=" + ((PageBase)Page).SupplierId.ToString(), "");
            if (((PageBase)Page).PageUrl.ToLower() == node.NavigateUrl.Substring(0, node.NavigateUrl.IndexOf("?")).ToLower())
            {
                node.Selected = true;
                node.Text = "<span style='color:#336600;'>" + node.Text + "</span>";
            }
            qualTree.Nodes.Add(node);
            //foreach (string qualNode in qualNodes)
            //{
            //    if (keys[i] == qualNode)
            //        isNext = true;
            //}
            //if (isNext)
            //    break;
        }

        string[] keys2 = new string[] { "Certification Analyst Review", "MWBE / LBE Review", "Supervising Analyst Review", "Director Review", "Certification Final Review" };
        Hashtable certHash = new Hashtable();
        certHash.Add(keys2[0], "~/Supplier/Workflow_Cert_Review.aspx");
        certHash.Add(keys2[1], "~/Supplier/Workflow_Cert_MwbeReview.aspx");

        certHash.Add(keys2[2], "~/Supplier/Workflow_Cert_SupervisorReview.aspx");
        certHash.Add(keys2[3], "~/Supplier/Workflow_Cert_DirectorReview.aspx");
        certHash.Add(keys2[4], "~/Supplier/Workflow_Cert_FinalReview.aspx");



        certTree.Nodes.Clear();
        isNext = false;
        for (int j = 0; j < keys2.Length; j++)
        {
            node = new TreeNode(keys2[j], j.ToString(), "", certHash[keys2[j]].ToString() + "?Id=" + ((PageBase)Page).SupplierId.ToString(), "");
            if (((PageBase)Page).PageUrl.ToLower() == node.NavigateUrl.Substring(0, node.NavigateUrl.IndexOf("?")).ToLower())
            {
                node.Selected = true;
                node.Text = "<span style='color:#336600;'>" + node.Text + "</span>";
            }
            certTree.Nodes.Add(node);
            //foreach (string certNode in certNodes)
            //{
            //    if (keys2[j] == certNode)
            //        isNext = true;
            //}
            //if (isNext)
            //    break;
        }
        string[] keys3 = new string[] { "General Counsel Review", "Supervising Analyst Appeal Review", "Director Appeal Review" };
        Hashtable certappealhash = new Hashtable();

        certappealhash.Add(keys3[0], "~/Supplier/Workflow_CertAppeal_GCReview.aspx");

        certappealhash.Add(keys3[1], "~/Supplier/Workflow_CertAppeal_SupReview.aspx");
        certappealhash.Add(keys3[2], "~/Supplier/Workflow_CertAppeal_DirectorReview.aspx");




        certappealTree.Nodes.Clear();
        isNext = false;
        for (int j = 0; j < keys3.Length; j++)
        {
            node = new TreeNode(keys3[j], j.ToString(), "", certappealhash[keys3[j]].ToString() + "?Id=" + ((PageBase)Page).SupplierId.ToString(), "");
            if (((PageBase)Page).PageUrl.ToLower() == node.NavigateUrl.Substring(0, node.NavigateUrl.IndexOf("?")).ToLower())
            {
                node.Selected = true;
                node.Text = "<span style='color:#336600;'>" + node.Text + "</span>";
            }
            certappealTree.Nodes.Add(node);
            //foreach (string certNode in certNodes)
            //{
            //    if (keys2[j] == certNode)
            //        isNext = true;
            //}
            //if (isNext)
            //    break;
        }

    }

    #region Private Method
    #endregion
}
