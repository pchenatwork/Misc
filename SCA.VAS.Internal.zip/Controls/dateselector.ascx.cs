using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using SCA.VAS.Common.Utilities;
using System.Web.UI;

public partial class DateSelector : System.Web.UI.UserControl
{
    #region Public Properties
    private bool _isRequired = false;
    public bool IsRequired
    {
        get
        {
            return this._isRequired;
        }
        set
        {
            this._isRequired = this.dateCustValidator2.Enabled = value;
        }
    }
    private string _validationGroup = string.Empty;
    public string ValidationGroup
    {
        get
        {
            return this._validationGroup;
        }
        set
        {
            this._validationGroup = value;
            this.dateCustValidator.ValidationGroup = this._validationGroup;
            this.dateCustValidator2.ValidationGroup = this._validationGroup;
            this.dateCustValidator3.ValidationGroup = this._validationGroup;
        }
    }
    private string _validErrorMessage = "";
    public string ValidErrorMessage
    {
        get
        {
            return this._validErrorMessage;
        }
        set
        {
            this._validErrorMessage = value;
        }
    }
    private string _requiredErrorMessage = "";
    public string RequiredErrorMessage
    {
        get
        {
            return this._requiredErrorMessage;
        }
        set
        {
            this._requiredErrorMessage = value;
        }
    }
    private string _requiredValidationFunction = string.Empty;
    public string RequiredValidationFunction
    {
        get
        {
            if (this._requiredValidationFunction == string.Empty)
                return this.ClientID + "_checkdateisentered";
            return this._requiredValidationFunction;
        }
        set
        {
            this._requiredValidationFunction = value;
        }
    }
    private string _yearRange = "-1";
    public string YearRange
    {
        get
        {
            return this._yearRange;
        }
        set
        {
            this._yearRange = value;
            AddYears();
        }
    }
    private string _dayRange = "";
    public string DayRange
    {
        get
        {
            return this._dayRange;
        }
        set
        {
            this._dayRange = value;
            SetCompareDate();
        }
    }
    private string _rangeErrorMessage = "";
    public string RangeErrorMessage
    {
        get
        {
            return this._rangeErrorMessage;
        }
        set
        {
            this._rangeErrorMessage = value;
        }
    }
    public bool RangeValidatorEnabled
    {
        get
        {
            return dateCustValidator3.Enabled;
        }
        set
        {
            dateCustValidator3.Enabled = value;
        }
    }
    private bool _includeFuture = false;
    public bool IncludeFuture
    {
        get
        {
            return this._includeFuture;
        }
        set
        {
            this._includeFuture = value;
        }
    }
    private string _futureYearRange = "10";
    public string FutureYearRange
    {
        get
        {
            return this._futureYearRange;
        }
        set
        {
            this._futureYearRange = value;
        }
    }
    private bool _showDay = true;
    public bool ShowDay
    {
        get
        {
            return this._showDay;
        }
        set
        {
            this._showDay = value;
            if (value)
                this.day.SelectedIndex = 1;
            this.showDay.Value = value ? "Y" : "N";
        }
    }
    private string _startingTabIndex = string.Empty;
    public string StartingTabIndex
    {
        get
        {
            return this._startingTabIndex;
        }
        set
        {
            this._startingTabIndex = value;
        }
    }
    private bool _visible = true;
    public override bool Visible
    {
        get
        {
            return this._visible;
        }
        set
        {
            this._visible = value;
            this.day.Style["Display"] = value ? "" : "none";
            this.month.Style["Display"] = value ? "" : "none";
            this.year.Style["Display"] = value ? "" : "none";
            this.comma.Style["Display"] = value ? "" : "none";
            this.na.Visible = !value;
        }
    }
    private bool _enabled = true;
    public bool Enabled
    {
        get
        {
            return this._enabled;
        }
        set
        {
            this._enabled = value;
            this.day.Enabled = value;
            this.month.Enabled = value;
            this.year.Enabled = value;

            if (!value)
            {
                this.day.Attributes["disabled"] = value ? "" : "disabled";
                this.month.Attributes["disabled"] = value ? "" : "disabled";
                this.year.Attributes["disabled"] = value ? "" : "disabled";
            }
            
            
        }
    }
    public DateTime SelectedDate
    {
        get
        {
            if (!_showDay && this.day.SelectedIndex == 0)
                this.day.SelectedIndex = 1;
            if (this.month.SelectedIndex == 0 || this.day.SelectedIndex == 0 || this.year.SelectedIndex == 0)
                return DateTime.MinValue;
            return new DateTime(ConvertUtility.ConvertInt(this.year.SelectedValue),
                ConvertUtility.ConvertInt(this.month.SelectedValue),
                ConvertUtility.ConvertInt(this.day.SelectedValue));
        }
        set
        {
            string sdatestring = string.Empty;
            this.month.SelectedIndex = this.month.Items.IndexOf(
                this.month.Items.FindByValue(value.Month.ToString()));
            this.day.SelectedIndex = this.day.Items.IndexOf(
                this.day.Items.FindByValue(value.Day.ToString()));

            if (this.year.Items.FindByValue(value.Year.ToString()) == null && value.Year> 1980)
            {
                // 202001 PCHEN. Add option if given year is outside the default
                this.year.Items.Add(new ListItem(value.Year.ToString()));
            }

            this.year.SelectedIndex = this.year.Items.IndexOf(
                this.year.Items.FindByValue(value.Year.ToString()));
            if (SelectedDate == DateTime.MinValue)
                sdatestring = "invalid";
            else
                sdatestring = SelectedDate.ToShortDateString();

            dateString.Value = sdatestring;
            //if (dateString.Value != DateTime.MinValue.ToShortDateString()) dateString.Value = sdatestring;
        }
    }


    public DateTime HiddenSelectedDate
    {
        get {
            DateTime d=new DateTime();
            try
            {

                if (dateString.Value!="Invalid")
                     d= Convert.ToDateTime(dateString.Value.ToString());

            }
            catch (Exception ex)
            {
                d = DateTime.MinValue;
            }
            return d;
        }
    }
    public string ValidValidationFunction
    {
        get
        {
            return this.ClientID + "_checkdateisvalid";
        }
    }
    #endregion Public Properties

    #region Public Methods
    public void Clear()
    {
        this.month.SelectedIndex = 0;
        this.day.SelectedIndex = 0;
        this.year.SelectedIndex = 0;
    }
    #endregion Public Methods

    #region Private Methods
    protected override void OnPreRender(EventArgs e)
    {
        if (!_showDay)
            this.day.SelectedIndex = 1;
        if (Page is PageBase)
        {
            this.Enabled = !(((PageBase)Page).IsReadOnly);
            if (((PageBase)Page).IsReadOnly)
            {
                this.Controls.Remove(dateCustValidator);
                this.Controls.Remove(dateCustValidator2);
                this.Controls.Remove(dateCustValidator3);
            }
        }
        base.OnPreRender(e);
    }
    protected override void OnInit(EventArgs e)
    {
        this.Clear();
        this.month.Attributes.Add("onchange", this.ClientID + "_setdatestring();");
        this.day.Attributes.Add("onchange", this.ClientID + "_setdatestring();");
        this.year.Attributes.Add("onchange", this.ClientID + "_setdatestring();");
        base.OnInit(e);
        SetInitialValue();
    }
    private void SetInitialValue()
    {
        AddYears();

        this.day.Items.Clear();
        this.day.Items.Add(new ListItem("Day", ""));
        for (int i = 1; i <= 31; i++)
        {
            this.day.Items.Add(new ListItem(i.ToString(), i.ToString()));
        }

        this.showDay.Value = _showDay ? "Y" : "N";
        if (!_showDay)
        {
            this.day.SelectedIndex = 1;
            this.day.Style["Display"] = "none";
            this.comma.InnerHtml = "/";
        }

        if (_startingTabIndex != string.Empty)
        {
            short tabIndex = (short)ConvertUtility.ConvertInt(_startingTabIndex);
            this.month.TabIndex = tabIndex;
            this.day.TabIndex = (short)(tabIndex + 1);
            this.year.TabIndex = (short)(tabIndex + 2);
        }

        this.dateCustValidator.ErrorMessage = _validErrorMessage;
        this.dateCustValidator.ClientValidationFunction = ValidValidationFunction;
        this.dateCustValidator.ValidationGroup = _validationGroup;

        this.dateCustValidator2.ErrorMessage = _requiredErrorMessage;
        this.dateCustValidator2.ClientValidationFunction = RequiredValidationFunction;
        this.dateCustValidator2.ValidationGroup = _validationGroup;
        this.dateCustValidator2.Enabled = _isRequired;

        this.dateCustValidator3.ErrorMessage = _rangeErrorMessage;
        this.dateCustValidator3.ClientValidationFunction = this.ClientID + "_checkdaterange";
        this.dateCustValidator3.ValidationGroup = _validationGroup;

        SetCompareDate();
    }
    private void AddYears()
    {
        this.year.Items.Clear();
        this.year.Items.Add(new ListItem("Year", ""));
        int endingyear = 0;
        if (_includeFuture)
            endingyear = DateTime.Today.Year + ConvertUtility.ConvertInt(_futureYearRange);
        else
            endingyear = DateTime.Today.Year;
        int startingyear = 0;
        if (ConvertUtility.ConvertInt(_yearRange) == -1)
            startingyear = 1900;
        else
            startingyear = DateTime.Today.Year - ConvertUtility.ConvertInt(_yearRange);
        for (int i = endingyear; i >= startingyear; i--)
        {
            this.year.Items.Add(new ListItem(i.ToString(), i.ToString()));
        }
    }
    private void SetCompareDate()
    {
        double range = ConvertUtility.ConvertDouble(_dayRange);
        if (range != 0)
        {
            compareDate.Value = DateTime.Now.AddDays(range).ToShortDateString();
            if (range < 0)
                compareDate.Value += "|<";
            else
                compareDate.Value += "|>";
            this.dateCustValidator3.Enabled = true;
        }
    }
    #endregion Private Methods

    #region Server Validation
    protected void ServerValidate_checkdateisvalid(object source, ServerValidateEventArgs args)
    {
        bool isValid = false;
        if (this.month.SelectedIndex == 0 && this.day.SelectedIndex == 0 && this.year.SelectedIndex == 0)
            args.IsValid = true;
        else if (!_showDay && this.month.SelectedIndex == 0 && this.day.SelectedIndex == 1 && this.year.SelectedIndex == 0)
            args.IsValid = true;
        else
        {
            int thisDay = ConvertUtility.ConvertInt(this.day.SelectedValue);
            switch (ConvertUtility.ConvertInt(this.month.SelectedValue))
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    if (thisDay <= 31)
                        isValid = true;
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    if (thisDay <= 30)
                        isValid = true;
                    break;
                case 2:
                    if (thisDay <= 28 || (thisDay == 29 && DateTime.IsLeapYear(ConvertUtility.ConvertInt(this.year.SelectedValue))))
                        isValid = true;
                    break;
            }
            args.IsValid = isValid;
        }
    }
    protected void ServerValidate_checkdateisentered(object source, ServerValidateEventArgs args)
    {
        args.IsValid = true;
        string defaultValidationFunction = this.ClientID + "_checkdateisentered";
        if (this.RequiredValidationFunction == defaultValidationFunction)
        {
            if ((this.month.SelectedIndex == 0 || this.day.SelectedIndex == 0 || this.year.SelectedIndex == 0) && this.HiddenSelectedDate==DateTime.MinValue)
                args.IsValid = false;
        }
    }
    protected void ServerValidate_checkdaterange(object source, ServerValidateEventArgs args)
    {
        args.IsValid = true;
        double range = ConvertUtility.ConvertDouble(_dayRange);
        if (SelectedDate == DateTime.MinValue) SelectedDate = HiddenSelectedDate;
        if (range != 0 && SelectedDate != new DateTime(1900, 1, 1))
        {
            if (range < 0 && !(SelectedDate.CompareTo(DateTime.Today) < 0 && SelectedDate.CompareTo(DateTime.Today.AddDays(range)) >= 0))
                args.IsValid = false;
            else if (range > 0 && !(SelectedDate.CompareTo(DateTime.Today) > 0 && SelectedDate.CompareTo(DateTime.Today.AddDays(range)) <= 0))
                args.IsValid = false;
        }
    }
    #endregion Server Validation
}