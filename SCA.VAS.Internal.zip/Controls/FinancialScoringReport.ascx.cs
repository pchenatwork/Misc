﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.Workflow;

public partial class Supplier_Controls_FinancialScoringReport : ControlBase
{
    public string CurrentLocation
    {
        get
        {
            return  txtBackLog.Text + "|" +
                    txtCA.Text + "|" +
                    txtCL.Text + "|" +
                    txtTL.Text + "|" +
                    txtOE.Text + "|" +
                    txtAR.Text + "|" +
                    txtAR2.Text + "|" +
                    txtSR.Text + "|" +
                    txtNOI.Text + "|" +
                    txtQA.Text + "|" +
                    txtTA.Text + "|" +
                    txtI2.Text;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {   
            
            this.txtBackLog.Attributes.Add("onkeyup", "OnChange();");
            this.txtBackLog.Attributes.Add("onblur", "OnChange();");
            this.txtCA.Attributes.Add("onkeyup", "OnChange();");
            this.txtCA.Attributes.Add("onblur", "OnChange();");
            this.txtCL.Attributes.Add("onkeyup", "OnChange();");
            this.txtCL.Attributes.Add("onblur", "OnChange();");
            this.txtTL.Attributes.Add("onkeyup", "OnChange();");
            this.txtTL.Attributes.Add("onblur", "OnChange();");
            this.txtOE.Attributes.Add("onkeyup", "OnChange();");
            this.txtOE.Attributes.Add("onblur", "OnChange();");
            this.txtAR.Attributes.Add("onkeyup", "OnChange();");
            this.txtAR.Attributes.Add("onblur", "OnChange();");
            this.txtAR2.Attributes.Add("onkeyup", "OnChange();");
            this.txtAR2.Attributes.Add("onblur", "OnChange();");
            this.txtSR.Attributes.Add("onkeyup", "OnChange();");
            this.txtSR.Attributes.Add("onblur", "OnChange();");
            this.txtNOI.Attributes.Add("onkeyup", "OnChange();");
            this.txtNOI.Attributes.Add("onblur", "OnChange();");
            this.txtQA.Attributes.Add("onkeyup", "OnChange();");
            this.txtQA.Attributes.Add("onblur", "OnChange();");
            this.txtTA.Attributes.Add("onkeyup", "OnChange();");
            this.txtTA.Attributes.Add("onblur", "OnChange();");
            this.txtI2.Attributes.Add("onkeyup", "OnChange();");
            this.txtI2.Attributes.Add("onblur", "OnChange();");

           

        }
        
    }

    public void SetInitialValue(Supplier supplier)
    {
        if (supplier != null &&supplier.CurrentLocation.IndexOf('|')>=0)
        {
            string[] financailSettings = supplier.CurrentLocation.Split('|');
            txtBackLog.Text = financailSettings[0];
            txtCA.Text = financailSettings[1];
            txtCL.Text = financailSettings[2];
            txtTL.Text = financailSettings[3];
            txtOE.Text = financailSettings[4];
            txtAR.Text = financailSettings[5];
            txtAR2.Text = financailSettings[6];
            txtSR.Text = financailSettings[7];
            txtNOI.Text = financailSettings[8];
            txtQA.Text = financailSettings[9];
            txtTA.Text = financailSettings[10];
            txtI2.Text = financailSettings[11];
        }


    }
    protected void submitButton_Click(object sender, EventArgs e)
    {

        //    //Label1
        //    try
        //    {
        //        Label1.Text = ((Convert.ToDecimal(txtCA.Text) - Convert.ToDecimal(txtCL.Text)) / (Convert.ToDecimal(txtBackLog.Text) + Convert.ToDecimal(txtI2.Text))).ToString("F3");
        //        //Label2
        //        if (Convert.ToDecimal(Label1.Text) < Convert.ToDecimal(lblThreshold1.Text))
        //        {
        //            Label2.Text = 0.ToString();
        //        }
        //        else
        //        {
        //            Label2.Text = ((Convert.ToDecimal(lblWtdScore1.Text) * Convert.ToDecimal(Label1.Text)) / (Convert.ToDecimal(lblThreshold1.Text))).ToString("F3");
        //        }
        //    }
        //    catch(DivideByZeroException)
        //    {
        //        Label1.Text = "Infinity";
        //        Label2.Text = "Infinity";
        //    }


        //    ////Label3
        //    try
        //    {
        //        Label3.Text = ((Convert.ToDecimal(txtCA.Text) - Convert.ToDecimal(txtCL.Text)) / (Convert.ToDecimal(txtBackLog.Text) + Convert.ToDecimal(lblK2.Text))).ToString("F3");
        //        //Label4
        //        if (Convert.ToDecimal(Label3.Text) < Convert.ToDecimal(lblThreshold1.Text))
        //        {
        //            Label4.Text = 0.ToString();
        //        }
        //        else
        //        {
        //            Label4.Text = ((Convert.ToDecimal(lblWtdScore1.Text) * Convert.ToDecimal(Label3.Text)) / (Convert.ToDecimal(lblThreshold1.Text))).ToString("F3");
        //        }
        //    }
        //    catch (DivideByZeroException)
        //    {
        //        Label3.Text = "Infinity";
        //        Label4.Text = "Infinity";
        //    }




        //    //Label5
        //    try
        //    {
        //        Label5.Text = ((Convert.ToDecimal(txtCA.Text) - Convert.ToDecimal(txtCL.Text)) / (Convert.ToDecimal(txtBackLog.Text) + Convert.ToDecimal(lblM2.Text))).ToString("F3");
        //        //Label6
        //        if (Convert.ToDecimal(Label5.Text) < Convert.ToDecimal(lblThreshold1.Text))
        //        {
        //            Label6.Text = 0.ToString();
        //        }
        //        else
        //        {
        //            Label6.Text = ((Convert.ToDecimal(lblWtdScore1.Text) * Convert.ToDecimal(Label5.Text)) / (Convert.ToDecimal(lblThreshold1.Text))).ToString("F3");
        //        }
        //    }
        //    catch (DivideByZeroException)
        //    {
        //        Label5.Text = "Infinity";
        //        Label6.Text = "Infinity";
        //    }




        //    //Label7
        //    try
        //    {
        //        Label7.Text = ((Convert.ToDecimal(txtCA.Text) - Convert.ToDecimal(txtCL.Text)) / (Convert.ToDecimal(txtBackLog.Text) + Convert.ToDecimal(lblO2.Text))).ToString("F3");
        //        //Label8
        //        if (Convert.ToDecimal(Label7.Text) < Convert.ToDecimal(lblThreshold1.Text))
        //        {
        //            Label8.Text = 0.ToString();
        //        }
        //        else
        //        {
        //            Label8.Text = ((Convert.ToDecimal(lblWtdScore1.Text) * Convert.ToDecimal(Label7.Text)) / (Convert.ToDecimal(lblThreshold1.Text))).ToString("F3");
        //        }
        //    }
        //    catch (DivideByZeroException)
        //    {
        //        Label7.Text = "Infinity";
        //        Label8.Text = "Infinity";
        //    }


        //    //Label9
        //    try
        //    {
        //        Label9.Text = ((Convert.ToDecimal(txtCA.Text) - Convert.ToDecimal(txtCL.Text)) / (Convert.ToDecimal(txtBackLog.Text) + Convert.ToDecimal(lblQ2.Text))).ToString("F3");
        //        //Label10
        //        if (Convert.ToDecimal(Label9.Text) < Convert.ToDecimal(lblThreshold1.Text))
        //        {
        //            Label10.Text = 0.ToString();
        //        }
        //        else
        //        {
        //            Label10.Text = ((Convert.ToDecimal(lblWtdScore1.Text) * Convert.ToDecimal(Label9.Text)) / (Convert.ToDecimal(lblThreshold1.Text))).ToString("F3");
        //        }

        //    }
        //    catch (DivideByZeroException)
        //    {
        //        Label9.Text = "Infinity";
        //        Label10.Text = "Infinity";
        //    }



        //    //Label11
        //    try
        //    {
        //        Label11.Text = ((Convert.ToDecimal(txtCA.Text) - Convert.ToDecimal(txtCL.Text)) / (Convert.ToDecimal(txtBackLog.Text) + Convert.ToDecimal(lblS2.Text))).ToString("F3");
        //        //Label12
        //        if (Convert.ToDecimal(Label11.Text) < Convert.ToDecimal(lblThreshold1.Text))
        //        {
        //            Label12.Text = 0.ToString();
        //        }
        //        else
        //        {
        //            Label12.Text = ((Convert.ToDecimal(lblWtdScore1.Text) * Convert.ToDecimal(Label11.Text)) / (Convert.ToDecimal(lblThreshold1.Text))).ToString("F3");
        //        }
        //    }
        //    catch (DivideByZeroException)
        //    {
        //        Label11.Text = "Infinity";
        //        Label12.Text = "Infinity";
        //    }
    }
    protected void save_Click(object sender, EventArgs e)
    {
        OnSaveSettingsClick(e);
       
    }

    public event EventHandler SaveSettingsClick;

    protected void OnSaveSettingsClick(EventArgs e)
    {
        if (SaveSettingsClick != null)
        {
            SaveSettingsClick(this, e);
        }
    }
}
