var n;
var f;
var p;
var p1;
function ValidateZip(field, form)
{
	var pv=p1.value;
	p="";
	for (var i = 0; i < pv.length; i++)
	{
		if (pv.charAt(i).match(/\d/) != null)
			p+=pv.charAt(i);
	}
	if (p.length>10)
		p=p.substring(0,10);
	if (p.length>5){
		length1=p.length;
		pre1=p.substring(0,5);
		post1=p.substring(5,length1);
		p=pre1+"-"+post1;
	}
	if (p!=pv)
	{
		eval('document.' + f + '.' + n + '.value="";');
		eval('document.' + f + '.' + n + '.value="' + p + '";');
	}
}

function ZipFormat(field, form, country)
{
	n = field.id;
	f = form.id;
	//country = "US";
	
	if (country == 'USA')
	{
		eval('p1 = document.' + f + '.' + n + ';');
		eval('document.' + f + '.' + n + '.maxLength=10;');
		ValidateZip(field, form);
	}
//	else
//	{
//		eval('document.' + f + '.' + n + '.maxLength=5;');
//	}		
}