using System;
using System.Data;
using System.Collections.Generic;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.ValueObjects.User;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Workflow;

public partial class labelextender : System.Web.UI.UserControl
{
    public labelextender()
    {

    }

    private string _controlIdToExtend = null;
    public string ControlToExtend
    {
        set
        {
            _controlIdToExtend = value;
        }
    }
    private int _truncateLength = 50;
    public int TruncateLength
    {
        set
        {
            _truncateLength = value;
        }
    }

    private string _cssClass = "";
    public string CssClass
    {
        set
        {
            _cssClass = value;
        }
    }

    private string _replaceText = "";
    public string ReplaceText
    {
        set
        {
            _replaceText = value;
        }
    }
    protected override void OnInit(EventArgs e)
    {
        if (this.Page.Items["Extenders"] == null)
            this.Page.Items["Extenders"] = new List<labelextender>();

        if (this.Page.Items["ExtendersScriptRegistered"] == null)
            this.Page.Items["ExtendersScriptRegistered"] = false;


        ((List<labelextender>)this.Page.Items["Extenders"]).Add(this);

        base.OnInit(e);
    }


    private string _trunctext = "";
    private WebControl _controlToExtend = null;
    protected override void OnPreRender(EventArgs e)
    {


        if (!(bool)this.Page.Items["ExtendersScriptRegistered"])
        {
            string script = "<script language=\"javascript\" type=\"text/javascript\">\r\n";
            script += "    \r\n";
            script += "    \r\n";

            script += "function show_labelextender(extenderid){             \r\n";
            script += "     var currentextender = document.getElementById(extenderid);   \r\n";
            script += "     if(currentextender == null) return;             \r\n";
            script += "                                                     \r\n";
            script += "     var text = document.getElementById(currentextender.controltoextend);\r\n";
            script += "                                                     \r\n";
            script += "                                                     \r\n";
            script += "     currentextender.style.display = '';             \r\n";
            script += "\r\n";
            script += "\r\n";
            script += "\r\n";
            script += "\r\n";
            script += "\r\n";
            script += "\r\n";
            script += "}\r\n";


            script += "function hideall_labelextender(){\r\n";
            script += "   \r\n";
            script += "   for (var i=0; i < labelextenders.length; i++){\r\n";
            script += "   \r\n";
            script += "         hide_labelextender(labelextenders[i]);\r\n";
            script += "    \r\n";
            script += "   }\r\n";
            script += "\r\n";
            script += "}\r\n";

            script += "function hide_labelextender(extenderid){\r\n";
            script += "     var currentextender = document.getElementById(extenderid);\r\n";
            script += "     if(currentextender == null) return; \r\n";
            script += "                                         \r\n";
            script += "     currentextender.style.display = 'none';\r\n";
            script += "}\r\n";



            script += "    \r\n";
            script += "var labelextenders = new Array();\r\n";

            foreach (labelextender extender in ((List<labelextender>)this.Page.Items["Extenders"]))
            {
                script += "labelextenders[labelextenders.length]= '" + extender.ClientID + "';\r\n";
            }
            script += "</script>\r\n";
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "labelextender", script);
            this.Page.Items["ExtendersScriptRegistered"] = true;
        }



        _controlToExtend = (WebControl)this.NamingContainer.FindControl(_controlIdToExtend);

        if (_controlToExtend is Label)
        {
            Label _labelToExtend = (Label)_controlToExtend;
            if (_labelToExtend.Text.Length > _truncateLength || _replaceText != "")
            {
                _labelToExtend.Attributes.Add("onmouseover", "hideall_labelextender();show_labelextender('" + this.ClientID + "');");
                if (_replaceText == "") _replaceText = _labelToExtend.Text;
                if (_labelToExtend.Text.Length > _truncateLength)
                    _labelToExtend.Text = _labelToExtend.Text.Substring(0, _truncateLength - 1) + "...";
                _trunctext = _labelToExtend.Text;
            }
        }
        else
        {
            _controlToExtend.Attributes.Add("onmouseover", "hideall_labelextender();show_labelextender('" + this.ClientID + "');");
        }
    }
    protected override void Render(System.Web.UI.HtmlTextWriter writer)
    {

        if (_controlToExtend is Label)
        {
            Label _labelToExtend = (Label)_controlToExtend;
            if (_labelToExtend.Text.Length <= _truncateLength && _replaceText == "")
                return;
        }



        if (_cssClass == "") _cssClass = _controlToExtend.CssClass;
        writer.Write("<span id=\"" + this.ClientID + "\" truntext=\"" + _trunctext + "\" controltoextend=\"" + _controlToExtend.ClientID + "\" class=\"" + _cssClass + "\" style=\"position:absolute;display:none;\"     onmouseout=\"hide_labelextender(this.id);\">");
        writer.Write(_replaceText);
        writer.Write("</span>");
    }
}
