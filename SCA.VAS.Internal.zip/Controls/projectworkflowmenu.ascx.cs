using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using Menu = SCA.VAS.ValueObjects.User.Menu;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.ValueObjects.Workflow;
using SCA.VAS.BusinessLogic.Workflow.Utilities;

public partial class control_projectworkflowmenu : UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    public void SetInitialValue()
    {
        TreeNode node = null;

        string[] keys = new string[] { "Next Low Bidder", "Cancel Project", "On Hold" , "Rebid"};
        Hashtable projectHash = new Hashtable();
        projectHash.Add(keys[0], "~/Rfc/Next_Vetting_Bidder_List.aspx");
        //projectHash.Add(keys[1], "~/Rfc/Vetting_Financial_Review.aspx");
        projectHash.Add(keys[1], "~/Rfc/Project_Cancel.aspx");
        projectHash.Add(keys[2], "~/Rfc/Project_OnHold.aspx");
        projectHash.Add(keys[3], "~/Rfc/Project_Rebid.aspx");

        PermissionDetailCollection permissionControls = PermissionDetailUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            PermissionDetailManager.FIND_PERMISSIONDETAIL_BY_USER,
            new object[] { 0, ((PageBase)Page).UserId, 
                ConstantUtility.SYSTEM_PERMISSION, 0 });

        projectTree.Nodes.Clear();
        for (int i = 0; i < keys.Length; i++)
        {
            bool hasPermission = false;
            if (permissionControls != null)
            {
                foreach (PermissionDetail permissionDetail in permissionControls)
                {
                    string[] controlPath = permissionDetail.ControlName.Split(':');
                    if (controlPath.Length > 1 && controlPath[0] == "ChangeStatusMenu"
                        && controlPath[1] == keys[i])
                    {
                        hasPermission = true;
                    }
                }
            }

            //if (!hasPermission) continue;

            node = new TreeNode(keys[i], i.ToString(), "", projectHash[keys[i]].ToString() + "?Id=" + ((PageBase)Page).SupplierId.ToString(), "");
            if (((PageBase)Page).PageUrl.ToLower() == node.NavigateUrl.Substring(0, node.NavigateUrl.IndexOf("?")).ToLower())
            {
                node.Selected = true;
                node.Text = "<span style='color:#336600;'>" + node.Text + "</span>";
            }
            projectTree.Nodes.Add(node);
        }

    }

    #region Private Method
    #endregion
}
