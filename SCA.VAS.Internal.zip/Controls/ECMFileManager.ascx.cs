﻿using log4net;
using SCA.VAS.Common.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ECMFileManager : ControlBase
{   
/*=======================================================================*       
* 202011  PCHEN Introduced as a universal "single file uploader" 
* This control has to pair with GetECMFile.ashx to download file from ECM
* Parent control needs to register its FileUpdate() method to 'OnFileChanged' event to update parent specific FileId/FileName
*=======================================================================*/
    public delegate void FileChanged(long FileAttachmenId, string FileName);

    public event FileChanged OnFileChanged;

    private static ILog _logger = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        Type me = this.GetType();
        if (!Page.ClientScript.IsClientScriptIncludeRegistered(me, me.BaseType.Name))
        {
            string url = "~/Controls/" + me.BaseType.Name + ".js";
            Page.ClientScript.RegisterClientScriptInclude(me, me.BaseType.Name, ResolveClientUrl(url));
        }
        _logger = LoggingUtility.GetLogger(typeof(ECMFileManager).FullName);
    }

    public bool NoValidation
    {
        set
        {
            if (value)
            {
                ctlFile_Validator.ServerValidate -= Validate_File;
            }
        }
    }
    public string ValidationGroup
    {
        set
        {
            ctlFile_Validator.ValidationGroup = btnSave.ValidationGroup = value;
        }
    }
    public void SetInitialValue(string TaxId, long EcmRecordId, string FileName)
    {
        EIN = TaxId;
        SetValue(EcmRecordId, FileName);
    }
    public void SetInitialValue(string TaxId, string docType, long EcmRecordId, string fileName)
    {
        EIN = TaxId;
        DocType = docType;
        SetValue(EcmRecordId, fileName);
    }
    public void SetInitialValue(string TaxId, string docType, string l1, long EcmRecordId, string fileName)
    {
        EIN = TaxId;
        DocType = docType;
        L1 = l1;
        SetValue(EcmRecordId, fileName);
    }
    public void SetValue(long EcmRecordId, string FileName)
    {
        if (EIN.Length.Equals(0) || ctlFile_Selector.DocType.Length.Equals(0))
        {
            lbErrMsg.Text = "EIN or DocType Needed For File Upload. Please Contact VAS Support.";
            lbErrMsg.Visible = true;
        }
        else
        {
            lbErrMsg.Text = string.Empty;
            lbErrMsg.Visible = false;
        }
        _docRecordId_ = EcmRecordId;
        _docname_ = FileName ?? string.Empty;
        _displayDoc(EcmRecordId, FileName);
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        long _id = ConvertUtility.ConvertLong(btnDelete.CommandArgument);
        SCA.VAS.ECMWrapper.DocServiceHelper.DeleteDoc(_id);
        OnFileChanged?.Invoke(0, string.Empty);
        SetValue(0, string.Empty);
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (ctlFile_Selector.HasFile)
        {
            string docname = ctlFile_Selector.PostedFileName;
            ctlFile_Selector.EIN = EIN;
            long newdocid = ctlFile_Selector.UploadFile();
            long olddocid = ConvertUtility.ConvertLong(btnSave.CommandArgument);

            if (newdocid > 0 && olddocid > 0)
            {
                // Remove existing EDOC file, soft delet for now
                SCA.VAS.ECMWrapper.DocServiceHelper.DeleteDoc(olddocid);
            }

            OnFileChanged?.Invoke(newdocid, docname);
            SetValue(newdocid, docname);
        }
    }

    private void _displayDoc(long docId, string fileName)
    {
        btnShowDoc.Text = fileName;
        string v = docId.ToString();
        string f = WebUtility.UrlEncode(fileName);
        btnShowDoc.NavigateUrl = "~/GetECMFile.ashx?v=" + v + "&f=" + f;
        btnShowDoc.Enabled = docId > 0;

        string sMsg = "Are you sure to delete file \"" + fileName + "\"?";
        btnDelete.Attributes.Add("onclick", "return confirm('" + sMsg + "');");
        btnDelete.ToolTip = "Delete '" + fileName + "'";
        btnDelete.Visible = docId > 0;
        btnDelete.CommandArgument = docId.ToString();

        btnSave.CommandArgument = docId.ToString();

        SetReadOnly();
    }

    private void SetReadOnly()
    {
        bool _readOnly = this.RenderMode.Equals(ControlRenderMode.ReadOnly);

        div_uploader.Visible = !_readOnly;
        tdDocName.Style.Remove("width");
        tdDocName.Style.Add("width", _readOnly ? "100%" : "150px");
    }

    #region Public Properties
    /// <summary>
    /// Limited to File Ext, eg ".doc" ".pdf"
    /// </summary>
    public string FileExt
    {
        set
        {
            ctlFile_Selector.Extensions = value;
        }
    }
    public string EIN
    {
        get
        {
            return (string)ViewState["_EIN_"] ?? string.Empty;
        }
        set
        {
            ViewState["_EIN_"] = value;
        }
    }
    public string DocType
    {
        set
        {
            ctlFile_Selector.DocType = value;
        }
    }
    /// <summary>
    /// DocType Sub L1 type
    /// </summary>
    public string L1
    {
        set
        {
            ctlFile_Selector.L1 = value;
        }
    }
    private long _docRecordId_
    {
        set
        {
            ctlFile_Selector.RecordId = value; ;
        }
    }
    private string _docname_
    {
        get
        {
            if (ViewState["_docname_"] == null)
                ViewState["_docname_"] = string.Empty;
            return (string)ViewState["_docname_"];
        }
        set
        {
            ViewState["_docname_"] = value;
        }
    }

    protected void Validate_File(object source, ServerValidateEventArgs args)
    {
        args.IsValid = ctlFile_Selector.PostedFileName.Trim().Length > 0;
    }


    #endregion Properties
}