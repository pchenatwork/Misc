﻿using Microsoft.ReportingServices.ReportProcessing.ReportObjectModel;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Workflow;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using _User = SCA.VAS.ValueObjects.User.User;
using User = SCA.VAS.ValueObjects.User.User;

namespace SCA.VAS.Internal.Controls
{
    public partial class CtrlDropDownUsersOnRoleBase : ControlBase
    {
        #region ^Public Properties
        /// <summary>
        /// User Text Roles defined at VAS 
        /// Chief Project Office / Project Officer etc..
        /// </summary>
        public string Role { set; private get; }

        /// <summary>
        /// At the zero index, put empty element that is "" with Option Value as blank
        /// </summary>
        public bool EmptyElementAtZeroIndex { set; private get; } = true;

        public override string Value { get { return ddlUsers.SelectedValue; } }

        public void Clear()
        {
            ddlUsers.SelectedIndex = 0;
        }

        #endregion ~End of Public Properties


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack) InitializeControl();
        }
    }

    partial class CtrlDropDownUsersOnRoleBase
    {
        private void InitializeControl()
        {
            if (!Role.Empty()) GetUsers();
            IncludeEmptyElement();

        }

        private void GetUsers()
        {
            var users = UserUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                UserManager.SEARCH_USER,
                new object[]
                    {
                        0,
                        0,
                        string.Empty,
                        string.Empty,
                        string.Empty,
                        1,                  //Only active users.
                        string.Empty,
                        string.Empty,
                        Role,
                        string.Empty,
                        string.Empty,
                    });

            var _users = (users ?? new UserCollection()).Cast<User>().OrderBy(c => c.Name);

            ddlUsers.DataSource = _users;
            ddlUsers.DataBind();

        }

        private void IncludeEmptyElement()
        {
            if (EmptyElementAtZeroIndex)
                ddlUsers.Items.Insert(0, new ListItem("All", ""));
        }
    }
}