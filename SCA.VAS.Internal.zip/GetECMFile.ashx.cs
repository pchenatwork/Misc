﻿using SCA.VAS.Common.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace SCA.VAS.Internal
{
    /// <summary>
    /// Summary description for GetECMFile
    /// </summary>
    public class GetECMFile : IHttpHandler
    {
        /* ========================================
         * PCHEN Oct 2020 Introduced 
         *  paired with /Controls/ECMSingleFileMananger.ascx for ECM file download
         * ======================================== */
        public void ProcessRequest(HttpContext context)
        {
            string v = context.Request.QueryString["v"] == null ? string.Empty : context.Request.QueryString["v"];
            string f = context.Request.QueryString["f"] == null ? string.Empty : context.Request.QueryString["f"];
            try
            {
                long id = ConvertUtility.ConvertLong(v);
                byte[] attachment = SCA.VAS.ECMWrapper.DocServiceHelper.DownloadDoc(id).Contents;
                if (attachment != null)
                {
                    context.Response.ContentType = "application/octet-stream";
                    context.Response.AddHeader("Content-Disposition", "attachment;filename=" + WebUtility.UrlDecode(f));
                    context.Response.BinaryWrite(attachment);
                }
            }
            catch (Exception e)
            {

            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}