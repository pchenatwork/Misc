#region Reference

using System.Web.UI.WebControls;
using System.Web.Security;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

#endregion Reference

public partial class Workflow_Node_Edit : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int nodeId = ConvertUtility.ConvertInt(Request.QueryString["nid"]);
            WorkflowNode workflowNode = null;
            if (nodeId != 0)
            {
                workflowNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, nodeId);
                ViewState["wid"] = workflowNode.WorkflowId;
            }
            else
            {
                ViewState["wid"] = Request.QueryString["Id"];
            }
            int workflowId = ConvertUtility.ConvertInt(ViewState["wid"].ToString());
            WorkflowList workflowList = WorkflowListUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowId);

            switch (workflowList.Type)
            {
                case ConstantUtility.WORKFLOW_QUALIFICATION:
                    systemStatus.DataSource = SupplierStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_CERTIFICATION:
                    systemStatus.DataSource = CertificationStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_OIG_QUALIFICATION:
                    systemStatus.DataSource = OIGStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_AMENDED_TRADE_CODE:
                    systemStatus.DataSource = AmendedTradeCodeStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_OVER_1MM:
                    systemStatus.DataSource = Over1MMStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_RS1_SUBCONTRACTOR:
                    systemStatus.DataSource = RS1SubcontractorStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_CHANGE_IN_APPLICATION:
                    systemStatus.DataSource = ChangeInAppStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_MENTOR:
                    systemStatus.DataSource = SupplierMentorType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_PREQUAL_LIMITEDLIST:
                case ConstantUtility.WORKFLOW_MENTOR_LIMITEDLIST:
                case ConstantUtility.WORKFLOW_MENTORGRADUATE_LIMITEDLIST:
                    systemStatus.DataSource = RfdProjectStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_SUPPLIER_LIMITEDLIST:
                    systemStatus.DataSource = RfdSupplierStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_SUBCONTRACTOR:
                    systemStatus.DataSource = SubcontractorStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_CAPACITY_EVALUATION:
                case ConstantUtility.WORKFLOW_CIP_EVALUATION:
                case ConstantUtility.WORKFLOW_CCFU_EVALUATION:
                case ConstantUtility.WORKFLOW_PROJECT_CONTRACT_EVALUATION:
                case ConstantUtility.WORKFLOW_MENTORA_EVALUATION:
                case ConstantUtility.WORKFLOW_MENTORA_CONTRACT_EVALUATION:
                case ConstantUtility.WORKFLOW_MENTORB_EVALUATION:
                case ConstantUtility.WORKFLOW_IEH_EVALUATION:
                case ConstantUtility.WORKFLOW_IEH_CONTRACT_EVALUATION:
                    systemStatus.DataSource = ScorecardStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_EVALUATION:
                    systemStatus.DataSource = EvaluationStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_BID_AWARD_GENERAL:
                    systemStatus.DataSource = ProjectBidAwardStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_ADDENDUM:
                    systemStatus.DataSource = ProjectAddendumStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_RFI_SUBMISSION_PROCESSING:
                    systemStatus.DataSource = ProjectRfiSubmissionStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_BID_BREAKDOWN_ANALYSIS:
                    systemStatus.DataSource = ProjectBidBreakdownAnalysisStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING:
                    systemStatus.DataSource = ProjectPreAwardVettingStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                //case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_BOND:
                //    systemStatus.DataSource = ProjectPreAwardVettingBondStatusType.GetEnumList();
                //    systemStatus.DataBind();
                //    break;
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_BIDBOND_REVIEW:
                    systemStatus.DataSource = ProjectPreAwardVettingBidBondReviewStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_FINANCIAL_REVIEW:
                    systemStatus.DataSource = ProjectPreAwardVettingFinancialReviewStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_MENTOR:
                    systemStatus.DataSource = ProjectPreAwardVettingMentorStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_RS1_VETTING:
                    systemStatus.DataSource = ProjectRS1VettingStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_ROUTING_OIG:
                    systemStatus.DataSource = ProjectRoutingOIGStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_ROUTING_FINANCE:
                    systemStatus.DataSource = ProjectRoutingFinanceStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_ROUTING_CQU:
                    systemStatus.DataSource = ProjectRoutingCQUStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_ROUTING_VPCM:
                    systemStatus.DataSource = ProjectRoutingVPCMStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_ROUTING_BDD:
                    systemStatus.DataSource = ProjectRoutingBDDStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_ROUTING_ADMIN:
                    systemStatus.DataSource = ProjectRoutingAdminStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_BID_DOCUMENT_REPRODUCTION:
                    systemStatus.DataSource = ProjectBidDocumentReproductionStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_BID_REPRODUCTION_ORDER:
                    systemStatus.DataSource = ProjectOrderStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_BID_REPRODUCTION_ORDER_SUPPLIER:
                    systemStatus.DataSource = ProjectOrderSupplierStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_BID_MENTOR:
                    systemStatus.DataSource = ProjectBidMentorStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_SUP:
                    systemStatus.DataSource = PlanStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_SUP_MONITORING:
                    systemStatus.DataSource = PlanSubcontractorStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;

                // HARDBID //
                case ConstantUtility.WORKFLOW_HB_GENERAL:
                    systemStatus.DataSource = HBGeneralStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;

                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_PRIME:
                    systemStatus.DataSource = HBPreAwardVettingPrimeStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;

                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_BIDBOND:
                    systemStatus.DataSource = HBPreAwardVettingBidBondStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;

                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_FINANCIAL:
                    systemStatus.DataSource = HBPreAwardVettingFinancialStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;

                case ConstantUtility.WORKFLOW_HB_BAFO:
                    systemStatus.DataSource = HBBidderBafoStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;

                case ConstantUtility.WORKFLOW_HB_ROUTING_PACKAGE:
                    systemStatus.DataSource = HBRoutingPackageStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_HB_ROUTING_FINANCE:
                    systemStatus.DataSource = HBRoutingFinanceStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;

                case ConstantUtility.WORKFLOW_HB_ROUTING_OIG:
                    systemStatus.DataSource = HBRoutingOIGStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;

                case ConstantUtility.WORKFLOW_HB_ROUTING_CQU: //Prequal
                    systemStatus.DataSource = HBRoutingCQUStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;

                case ConstantUtility.WORKFLOW_HB_ROUTING_VPCM:
                    systemStatus.DataSource = HBRoutingVPCMStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;

                case ConstantUtility.WORKFLOW_HB_ROUTING_VPIEH:
                    systemStatus.DataSource = HBRoutingVPIEHStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;

                case ConstantUtility.WORKFLOW_HB_ROUTING_VPAE:
                    systemStatus.DataSource = HBRoutingVPAEStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;

                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE:
                    systemStatus.DataSource = HBExecutionPackageStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_LEGAL:
                    systemStatus.DataSource = HBExecutionPackageLegalStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_VPCP:
                    systemStatus.DataSource = HBExecutionPackageVPCPStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_EVP:
                    systemStatus.DataSource = HBExecutionPackageEVPStatusType.GetEnumList();
                    systemStatus.DataBind();
                    break;
            }
            systemStatus.Items.Insert(0, new ListItem("Select One", ""));

            if (workflowNode != null)
            {
                nodeName.Text = workflowNode.Name;
                desc.Text = workflowNode.Description;
                systemStatus.SelectedIndex = systemStatus.Items.IndexOf(
                    systemStatus.Items.FindByValue(workflowNode.Action6));
                if (workflowNode.Type == 7)
                    this.startNode.Checked = true;
            }

            if (workflowList != null)
            {
                name.Text = workflowList.Name;
                WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                    ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                    WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                    new object[] { workflowId, "UserStepId", "ASC" });

                WorkflowNodeCollection workflowNodesBind = new WorkflowNodeCollection();
                if (workflowNodes != null)
                {
                    foreach (WorkflowNode wn in workflowNodes)
                        if (wn.Type != 1 && wn.Id != nodeId) workflowNodesBind.Add(wn);
                }

                fromNodes.DataSource = workflowNodesBind;
                fromNodes.DataBind();
                toNodes.DataSource = workflowNodesBind;
                toNodes.DataBind();

                PermissionCollection permissions = PermissionUtility.FindByCriteria(
                    ConstantUtility.USER_DATASOURCE_NAME,
                    PermissionManager.FIND_PERMISSION_BY_TYPE,
                    new object[] { ConstantUtility.WORKFLOW_PERMISSION });
                permissionList.DataSource = permissions;
                permissionList.DataBind();

                if (nodeId != 0)
                {
                    // bind from links
                    foreach (ListItem li in fromNodes.Items)
                    {
                        int fromId = ConvertUtility.ConvertInt(li.Value);
                        if (workflowNodes != null)
                        {
                            foreach (WorkflowNode wn in workflowNodes)
                            {
                                if (wn.NodeFromId == fromId && wn.NodeToId == nodeId)
                                {
                                    li.Selected = true;
                                    break;
                                }
                            }
                        }
                    }

                    // bind to links
                    foreach (ListItem li in toNodes.Items)
                    {
                        int toId = ConvertUtility.ConvertInt(li.Value);
                        if (workflowNodes != null)
                        {
                            foreach (WorkflowNode wn in workflowNodes)
                            {
                                if (wn.NodeFromId == nodeId && wn.NodeToId == toId)
                                {
                                    li.Selected = true;
                                    break;
                                }
                            }
                        }
                    }
                }

                //Bind roles Permission
                string[] userRoles = Roles.GetAllRoles();
                if (userRoles != null)
                {
                    foreach (string roleName in userRoles)
                        userRoleList.Items.Add(new ListItem(roleName, roleName));
                }
                //checkAllRoles.Attributes.Add("OnClick", "javascript:SelectRole();");

                if (workflowNode == null) return;

                if (workflowNode.IsPermCtrl == 0)
                {
                    checkAllRoles.Items[0].Selected = true;
                    //Page.ClientScript.RegisterStartupScript(GetType(), "SelectRole", "javascript:SelectRole();", true);
                }
                else
                {
                    WorkflowNodeUserCollection workflowNodeUsers = WorkflowNodeUserUtility.FindByCriteria(
                        ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowNodeUserManager.FIND_WORKFLOWNODEUSER_BY_NODE,
                        new object[] { nodeId });

                    foreach (ListItem li in this.userRoleList.Items)
                    {
                        if (workflowNodeUsers != null)
                        {
                            foreach (WorkflowNodeUser wu in workflowNodeUsers)
                            {
                                if (wu.RoleName == li.Text)
                                {
                                    li.Selected = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            BindPermission();
        }
    }

    protected void permissionList_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            Permission localPermission = (Permission)e.Item.DataItem;
            CheckBoxList localPermissionList = (CheckBoxList)e.Item.FindControl("permissionList2");

            localPermissionList.DataSource = localPermission.SubPermissions;
            localPermissionList.DataBind();
        }
    }

    protected void btnSubmit_Click(object sender, System.EventArgs e)
    {
        if (!this.Page.IsValid) return;

        int workflowId = ConvertUtility.ConvertInt(ViewState["wid"].ToString());
        WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(ConstantUtility.WORKFLOW_DATASOURCE_NAME,
            WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW, new object[] { workflowId, "UserStepId", "ASC" });

        // Add & Update a node
        int nodeId = ConvertUtility.ConvertInt(Request.QueryString["nid"]);
        if (workflowNodes != null)
        {
            foreach (WorkflowNode wn in workflowNodes)
            {
                if (wn.Name.Trim() == nodeName.Text.Trim() && wn.Id != nodeId)
                {
                    errmsg.Text = "Duplicate status was found, please change status name!";
                    errmsg.Visible = true;
                    return;
                }
            }
        }

        WorkflowNode workflowNode = null;
        if (nodeId == 0)
        {
            workflowNode = WorkflowNodeUtility.CreateObject();
            workflowNode.WorkflowId = workflowId;
            workflowNode.Type = 2;
            workflowNode.ConditionId = 1;
        }
        else
        {
            workflowNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, nodeId);
        }
        workflowNode.Name = nodeName.Text;
        workflowNode.Description = desc.Text;
        workflowNode.Action6 = systemStatus.SelectedValue;

        if (this.startNode.Checked)
        {
            workflowNode.Type = 7;
            if (workflowNodes != null)
            {
                foreach (WorkflowNode wn in workflowNodes)
                {
                    if (wn.Type == workflowNode.Type)
                    {
                        wn.Type = 2;
                        WorkflowNodeUtility.Update(ConstantUtility.WORKFLOW_DATASOURCE_NAME, wn);
                    }
                }
            }
        }

        if (nodeId == 0)
        {
            WorkflowNodeUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode);
            nodeId = workflowNode.Id;
        }
        else
        {
            WorkflowNodeUtility.Update(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode);
        }

        //build Form Links
        foreach (ListItem li in fromNodes.Items)
        {
            int fromId = ConvertUtility.ConvertInt(li.Value);
            int tempId = 0;
            if (workflowNodes != null)
            {
                foreach (WorkflowNode wn in workflowNodes)
                {
                    if (wn.NodeFromId == fromId && wn.NodeToId == nodeId)
                    {
                        tempId = wn.Id;
                        break;
                    }
                }
            }
            if (tempId == 0 && li.Selected)
            {
                WorkflowNode newNode = WorkflowNodeUtility.CreateObject();
                newNode.WorkflowId = workflowId;
                newNode.Type = 1;
                newNode.ConditionId = 1;
                newNode.Name = workflowNode.Name + "_Action";
                newNode.NodeFromId = fromId;
                newNode.NodeToId = nodeId;
                WorkflowNodeUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, newNode);
            }
            if (tempId != 0 && !li.Selected)
            {
                WorkflowNodeUtility.Delete(ConstantUtility.WORKFLOW_DATASOURCE_NAME, tempId);
            }
        }

        //build To Links
        foreach (ListItem li in toNodes.Items)
        {
            int toId = ConvertUtility.ConvertInt(li.Value);
            string toNodeName = li.Text;
            int tempId = 0;
            if (workflowNodes != null)
            {
                foreach (WorkflowNode wn in workflowNodes)
                {
                    if (wn.NodeFromId == nodeId && wn.NodeToId == toId)
                    {
                        tempId = wn.Id;
                        break;
                    }
                }
            }
            if (tempId == 0 && li.Selected)
            {
                WorkflowNode newNode = WorkflowNodeUtility.CreateObject();
                newNode.WorkflowId = workflowId;
                newNode.Type = 1;
                newNode.ConditionId = 1;
                newNode.Name = toNodeName + "_Action";
                newNode.NodeFromId = nodeId;
                newNode.NodeToId = toId;
                WorkflowNodeUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, newNode);
            }
            if (tempId != 0 && !li.Selected)
            {
                WorkflowNodeUtility.Delete(ConstantUtility.WORKFLOW_DATASOURCE_NAME, tempId);
            }
        }

        WorkflowNodeUserCollection workflowNodeUsers = WorkflowNodeUserUtility.FindByCriteria(
            ConstantUtility.WORKFLOW_DATASOURCE_NAME,
            WorkflowNodeUserManager.FIND_WORKFLOWNODEUSER_BY_NODE,
            new object[] { nodeId });

        //build Permission
        if (!checkAllRoles.Items[0].Selected)
        {
            foreach (ListItem li in this.userRoleList.Items)
            {
                int tempId = 0;
                if (workflowNodeUsers != null)
                {
                    foreach (WorkflowNodeUser wu in workflowNodeUsers)
                    {
                        if (wu.RoleName == li.Text)
                        {
                            tempId = wu.Id;
                            break;
                        }
                    }
                }
                if (tempId == 0 && li.Selected)
                {
                    WorkflowNodeUser newRole = WorkflowNodeUserUtility.CreateObject();
                    newRole.WorkflowNodeId = nodeId;
                    newRole.Status = 1;
                    newRole.ApplicationName = Roles.ApplicationName;
                    newRole.RoleName = li.Text;

                    WorkflowNodeUserUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, newRole);
                }
                if (tempId != 0 && !li.Selected)
                {
                    WorkflowNodeUserUtility.Delete(ConstantUtility.WORKFLOW_DATASOURCE_NAME, tempId);
                }
            }
        }

        WorkflowPermissionCollection workflowPermissions = new WorkflowPermissionCollection();
        foreach (DataListItem dataItem in permissionList.Items)
        {
            if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
            {
                CheckBoxList localPermissionList = (CheckBoxList)dataItem.FindControl("permissionList2");

                foreach (ListItem li in localPermissionList.Items)
                {
                    if (li.Selected)
                    {
                        WorkflowPermission workflowPermission = WorkflowPermissionUtility.CreateObject();
                        workflowPermission.WorkflowNodeId = nodeId;
                        workflowPermission.PermissionId = ConvertUtility.ConvertInt(li.Value);
                        workflowPermissions.Add(workflowPermission);
                    }
                }
            }
        }
        WorkflowPermissionUtility.UpdateCollection(ConstantUtility.WORKFLOW_DATASOURCE_NAME,
            nodeId, workflowPermissions);

        Response.Redirect("Workflow_Edit.aspx?Id=" + workflowId.ToString());
    }
    #endregion Web Event Handler

    private void BindPermission()
    {
        int nodeId = ConvertUtility.ConvertInt(Request.QueryString["nid"]);

        WorkflowPermissionCollection workflowPermissions = WorkflowPermissionUtility.FindByCriteria(
            ConstantUtility.WORKFLOW_DATASOURCE_NAME,
            WorkflowPermissionManager.FIND_WORKFLOWPERMISSION_BY_NODE,
            new object[] { nodeId });

        foreach (DataListItem dataItem in permissionList.Items)
        {
            if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
            {
                CheckBoxList localPermissionList = (CheckBoxList)dataItem.FindControl("permissionList2");

                foreach (ListItem li in localPermissionList.Items)
                {
                    li.Selected = false;
                    if (workflowPermissions != null)
                    {
                        foreach (WorkflowPermission workflowPermission in workflowPermissions)
                        {
                            if (workflowPermission.PermissionId == ConvertUtility.ConvertInt(li.Value))
                            {
                                li.Selected = true;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

}
