#region Reference
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class Admin_Permission_Edit : PageBase_Initial
{
    #region Web Event Handler
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        int permissionId = ConvertUtility.ConvertInt(Request.QueryString["id"]);
        Permission permission = PermissionUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, permissionId);
        PermissionDetailCollection permissionDetails = new PermissionDetailCollection();

        permission.Name = name.Text;
        
        foreach (DataGridItem dataItem in pagePermissionList.Items)
        {
            if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
            {
                CheckBoxList localPermission = (CheckBoxList)dataItem.FindControl("permissionvalue");

                PermissionDetail permissionDetail = null;
                foreach(PermissionDetail pd in permission.Details)
                {
                    if(pd.Id == (int)pagePermissionList.DataKeys[dataItem.ItemIndex])
                    {
                        permissionDetail = pd;
                        break;
                    }
                }
                if(permissionDetail == null) continue;
                
                permissionDetail.PermissionValue = 0;
                bool delete = false;
                
                foreach (ListItem li in localPermission.Items)
                {
                    int permissionValue = ConvertUtility.ConvertInt(li.Value);
                    if (permissionValue == 15 && !li.Selected)
                        delete = true;
                    if (li.Selected)
                        permissionDetail.PermissionValue = permissionDetail.PermissionValue | permissionValue;
                }
                if (!delete || permissionDetail.PermissionValue > 0)
                    permissionDetails.Add(permissionDetail);
            }
        }

        foreach (DataGridItem dataItem in controlPermissionList.Items)
        {
            if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
            {
                CheckBoxList localPermission = (CheckBoxList)dataItem.FindControl("permissionvalue");

                PermissionDetail permissionDetail = null;
                foreach (PermissionDetail pd in permission.Details)
                {
                    if (pd.Id == (int)controlPermissionList.DataKeys[dataItem.ItemIndex])
                    {
                        permissionDetail = pd;
                        break;
                    }
                }
                if (permissionDetail == null) continue;

                permissionDetail.PermissionValue = 0;
                bool delete = false;

                foreach (ListItem li in localPermission.Items)
                {
                    int permissionValue = ConvertUtility.ConvertInt(li.Value);
                    if (permissionValue == 15 && !li.Selected)
                        delete = true;
                    if (li.Selected)
                        permissionDetail.PermissionValue = permissionDetail.PermissionValue | permissionValue;
                }
                if (!delete || permissionDetail.PermissionValue > 0)
                    permissionDetails.Add(permissionDetail);
            }
        }

        PermissionUtility.Update(ConstantUtility.USER_DATASOURCE_NAME, permission);
        PermissionDetailUtility.UpdateCollectionByPermission(ConstantUtility.USER_DATASOURCE_NAME,
           permissionId, permissionDetails);

        Response.Redirect("Permission_List.aspx?Id=" + permission.Type.ToString());
    }

    protected void pagePermissionList_ItemDataBound(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            PermissionDetail localPermissionDetail = (PermissionDetail)e.Item.DataItem;
            CheckBoxList localPermission = (CheckBoxList)e.Item.FindControl("permissionvalue");

            foreach (ListItem li in localPermission.Items)
            {
                int permissionValue = ConvertUtility.ConvertInt(li.Value);
                if (permissionValue == (permissionValue & localPermissionDetail.PermissionValue))
                    li.Selected = true;
            }
        }
    }

    protected void pagePermissionList_DeleteCommand(object source, DataGridCommandEventArgs e)
    {
        int permissionDetailId = (int)pagePermissionList.DataKeys[e.Item.ItemIndex];
        PermissionDetailUtility.Delete(ConstantUtility.USER_DATASOURCE_NAME, permissionDetailId);
        SetInitialValue();
    }

    protected void controlPermissionList_DeleteCommand(object source, DataGridCommandEventArgs e)
    {
        int permissionDetailId = (int)controlPermissionList.DataKeys[e.Item.ItemIndex];
        PermissionDetailUtility.Delete(ConstantUtility.USER_DATASOURCE_NAME, permissionDetailId);
        SetInitialValue();
    }
    #endregion Web Event Handler
 
    #region Public Method
    override public void SetInitialValue()
    {
        detail.SetInitialValue();
        int permissionId = ConvertUtility.ConvertInt(Request.QueryString["id"]);
        Permission permission = PermissionUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, permissionId);

        if (permission != null)
        {
            name.Text = permission.Name;
            if (permission.Details != null && permission.Details.Count > 0)
            {
                PermissionDetailCollection menuDetails = new PermissionDetailCollection();
                foreach (PermissionDetail pd in permission.Details)
                {
                    if (pd.Type.ToLower() == "menu") menuDetails.Add(pd);
                }
                pagePermissionList.DataSource = menuDetails;
                pagePermissionList.DataBind();

                PermissionDetailCollection controlDetails = new PermissionDetailCollection();
                foreach (PermissionDetail pd in permission.Details)
                {
                    if (pd.Type.ToLower() == "control") controlDetails.Add(pd);
                }
                controlPermissionList.DataSource = controlDetails;
                controlPermissionList.DataBind();

            }
        }

        //string[] controlNames = { @"content:pagePermissionList:_ctl\d:permissionvalue", "content:addpage" };
        //CommonUtility.SetRfxControlPermission(Page.Form.Controls, controlNames);
    }
    #endregion Public Method
}
