#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Web.Security;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class User_Supervisor : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    protected void btnSubmit_Click(object sender, System.EventArgs e)
    {
        if (SaveAffiliates())
            Response.Redirect("User_Search.aspx");
    }
    #endregion Web Event Handler

    #region Private Method
    private void SetInitialValue()
    {
        if (Request.QueryString["User"] != null)
        {
            ViewState["User"] = Request.QueryString["User"];
            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
                ConvertUtility.ConvertInt(Request.QueryString["User"].ToString()));
            if (user != null)
            {
                name.Text = user.UserName;

                supervisors.SetInitialValue(user);
            }
            else
                Response.Redirect("User_Search.aspx");
        }
        else
            Response.Redirect("User_Search.aspx");
    }

    private bool SaveAffiliates()
    {
        User user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME,
            name.Text);
        if (user != null)
        {
            bool success = true;
            user.UserAffiliates = supervisors.GetUserAffiliates(user);
            if(UserAffiliateUtility.UpdateCollection(ConstantUtility.USER_DATASOURCE_NAME, user.Id, user.UserAffiliates))
                return true;
        }

        return false;
    }
    #endregion
}
