#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text.RegularExpressions;
using System.Web.Security;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.Common.Utilities;
using AspImage = System.Web.UI.WebControls.Image;
using Menu = SCA.VAS.ValueObjects.User.Menu;
#endregion Reference

public partial class InternalPage_List : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }

    protected void PageChange(Object sender, DataGridPageChangedEventArgs e)
    {
        pageGrid.CurrentPageIndex = e.NewPageIndex;
        BindGrid();
    }

    protected void BindItem(object o, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            AspImage localIcon = (AspImage)e.Item.FindControl("iconimage");
            ImageButton tempDelete = (ImageButton)e.Item.FindControl("deleteButton");
            AspImage tempDeleteImg = (AspImage)e.Item.FindControl("deleteImg");
            ImageButton tempCopy = (ImageButton)e.Item.FindControl("copyButton");

            Menu localMenu = (Menu)e.Item.DataItem;
            if (localMenu.SubMenus.Count > 0)
            {
                tempDelete.Visible = false;
                tempDeleteImg.Visible = true;
            }
            tempDelete.Attributes.Add("onclick", "javascript:return confirm('Are you sure you want to delete this menu?');");
            tempDeleteImg.Attributes.Add("onclick", "javascript:return alert('This menu item can not be deleted until all attached menu items are deleted.');");
            tempCopy.Attributes.Add("onclick", "javascript:return confirm('Are you sure that you want to make a copy of this menu?');");
            if (localIcon.ImageUrl.Trim().Length == 0)
            {
                localIcon.Visible = false;
            }
        }
    }

    protected void addButton_Click(object sender, System.EventArgs e)
    {
        Response.Redirect("~/Admin/InternalPage_Modify.aspx");
    }

    protected void ItemCommand(object o, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Delete")
        {
            int id = (int)pageGrid.DataKeys[e.Item.ItemIndex];
            MenuUtility.Delete(ConstantUtility.USER_DATASOURCE_NAME, id);
            BindGrid();
        }
        else if (e.CommandName == "Copy")
        {
            int id = (int)pageGrid.DataKeys[e.Item.ItemIndex];
            MenuUtility.Copy(ConstantUtility.USER_DATASOURCE_NAME, id);
            BindGrid();
        }
    }

    protected void search_Click(object sender, System.EventArgs e)
    {
        BindGrid();
    }

    protected void btnUpdate_Click(object sender, System.EventArgs e)
    {
        MenuCollection menus = new MenuCollection();

        foreach (DataGridItem qi in pageGrid.Items)
        {
            if (qi.ItemType == ListItemType.Item ||
                qi.ItemType == ListItemType.AlternatingItem)
            {
                // add menu
                Menu menu = MenuUtility.CreateObject();
                menu.Id = Convert.ToInt32(pageGrid.DataKeys[qi.ItemIndex]);
                menu.ParentId = ConvertUtility.ConvertInt(((TextBox)qi.FindControl("parentId")).Text);
                menu.DisplayOrder = ConvertUtility.ConvertInt(((TextBox)qi.FindControl("displayOrder")).Text);
                menu.Display = ((TextBox)qi.FindControl("display")).Text;
                menus.Add(menu);
            }
        }

        MenuUtility.UpdateCollection(ConstantUtility.USER_DATASOURCE_NAME, menus);

        BindGrid();
    }
    #endregion Web Event Handler

    #region Private Member
    private int level;
    private MenuCollection allLevelMenus;
    #endregion

    #region Private Method
    private void BindGrid()
    {
        MenuCollection menus = MenuUtility.FindByCriteria(ConstantUtility.USER_DATASOURCE_NAME,
            MenuManager.SEARCH_MENU,
            new object[] { Membership.ApplicationName, keyword.Text, listDisplay.SelectedValue });
        level = 0;
        allLevelMenus = new MenuCollection();
        GetAllLevelMenu(menus);

        pageGrid.DataSource = allLevelMenus;
        pageGrid.DataBind();
    }

    private void GetAllLevelMenu(MenuCollection menus)
    {
        if (menus != null)
        {
            foreach (Menu m in menus)
            {
                m.ToolTip = "";
                for (int i = 0; i < level; i++)
                {
                    if (i != level - 1)
                    {
                        m.ToolTip += "<img src=\"" + Page.ResolveUrl("~/images/spacer.gif") + "\">";
                    }
                    else
                    {
                        m.ToolTip += "<img src=\"" + Page.ResolveUrl("~/images/icon-forward.gif") + "\">";
                    }
                }
                m.ToolTip += m.Text;
                allLevelMenus.Add(m);
                if (m.SubMenus != null)
                {
                    level++;
                    GetAllLevelMenu(m.SubMenus);
                }
            }
        }
        level--;
    }
    #endregion Private Method
}
