#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.Workflow;
#endregion Reference

public partial class DownloadUserExcel : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    protected override void Render(System.Web.UI.HtmlTextWriter writer)
    {
        Response.ContentType = "application/ms-excel";
        Response.AddHeader("Content-Disposition", "attachment;filename=users.xls");

        SearchUser localSearchUser = (SearchUser)((PageBase)Context.Handler).Form.FindControl("content").FindControl("search");

        UserCollection users = UserUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            UserManager.SEARCH_USER,
            new object[]
                {
                    0, 0, "Name", "ASC",
                    localSearchUser.Keyword,
                    localSearchUser.Status,
                    localSearchUser.Name,
                    localSearchUser.Email,
                    localSearchUser.UserRole,
                    localSearchUser.Division,
                    localSearchUser.ExtraXml
                });

        userGrid.DataSource = users;
        userGrid.DataBind();
        userGrid.RenderControl(writer);
    }
    #endregion Web Event Handler
}
