#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class Workflow_List : PageBase
{
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            workflow.SetInitialValue();
        }
    }
}
