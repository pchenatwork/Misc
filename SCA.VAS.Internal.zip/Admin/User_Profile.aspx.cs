#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using System.Web.Security;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;
#endregion Reference

public partial class User_Profile : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        // Put user code to initialize the page here
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    protected void Submit_Click(object sender, System.EventArgs e)
    {
        if (!Page.IsValid) return;
        try
        {
            if (UpdateUser())
            {
                Response.Redirect("~/home.aspx");
            }
            else
            {
                errmsg.Text = "Update failed";
                errmsg.Visible = true;
            }
        }
        catch (Exception ex)
        {
            errmsg.Text = "Update failed because of: " + ex.Message;
            errmsg.Visible = true;
        }
    }

    #endregion Web Event Handler

    #region Private Method
    private void SetInitialValue()
    {
        User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, UserId);

        userinfo.SetInitialValue(user);
    }

    private bool UpdateUser()
    {
        User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, UserId);

        if (String.Compare(user.Email, userinfo.Email, true) != 0)
        {
            MembershipUser membershipUser = Membership.GetUser(userinfo.UserName);
            membershipUser.Email = userinfo.Email;
            Membership.UpdateUser(membershipUser);
        }

        user.UserName = userinfo.UserName;
        user.ApplicationName = Membership.ApplicationName;
        user.Email = userinfo.Email;
        user.Title = userinfo.FederalId;
        user.FirstName = userinfo.FirstName;
        user.LastName = userinfo.LastName;
        user.Phone = userinfo.Phone;
        user.Extension = userinfo.Extension;
        user.Fax = userinfo.Fax;
        user.Division = userinfo.Division;
        user.City = userinfo.City;
        user.State = userinfo.State;
        user.Company = userinfo.Company;
        user.Department = userinfo.Department;
        user.ZipCode = userinfo.ZipCode;
        user.Address = userinfo.Address;
        user.Country = userinfo.Country;
        user.Location = userinfo.Location;
        user.TimeZone = userinfo.TimeZone;
        user.EmailNotification = userinfo.EmailNotification;

        UserUtility.Update(ConstantUtility.USER_DATASOURCE_NAME, user);

        return true;
    }

    #endregion Private Method
}
