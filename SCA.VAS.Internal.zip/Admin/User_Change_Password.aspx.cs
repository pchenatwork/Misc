#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;
#endregion

public partial class User_Change_Password : PageBase
{

    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    protected void submit_Click(object sender, System.EventArgs e)
    {
        if (!Page.IsValid) return;
        User user1 = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, UserId);
        MembershipUser user = Membership.GetUser(user1.UserName);
        if (user.ChangePassword(oldPassword.Text, password.Text))
        {
            Response.Redirect("~/home.aspx");
        }
        else
        {
            errmsg.Text = "Change password failed!";
            errmsg.Visible = true;
        }
    }
}
