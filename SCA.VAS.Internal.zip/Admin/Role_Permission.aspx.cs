#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;
using Menu = SCA.VAS.ValueObjects.User.Menu;
#endregion Reference

public partial class Role_Permission : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    protected void btnSubmit_Click(object sender, System.EventArgs e)
    {
        UpdateMenuPermission();
        Response.Redirect("UserRole_List.aspx");
    }

    protected void permissionList_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            Permission localPermission = (Permission)e.Item.DataItem;
            CheckBoxList localPermissionList = (CheckBoxList)e.Item.FindControl("permissionList2");

            localPermissionList.DataSource = localPermission.SubPermissions;
            localPermissionList.DataBind();

            LinkButton localApplyAll = (LinkButton)e.Item.FindControl("applyAll");
            localApplyAll.Text = "Apply " + localPermission.Name + " permissions to All " + Request.QueryString["Role"] + "s";
            localApplyAll.Visible = localPermission.Type == 2;
        }
    }
    #endregion Web Event Handler

    #region Private Method
    private void SetInitialValue()
    {
        if ( Request.QueryString["Role"] == null )
        {
            Response.Redirect("UserRole_List.aspx");
        }
        name.Text = Request.QueryString["Role"].ToString();

        PermissionCollection permissions = PermissionUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            PermissionManager.FIND_PERMISSION_BY_TYPE,
            new object[] { 0 });
        permissionList.DataSource = permissions;
        permissionList.DataBind();

        BindUserPermission();
    }

    private void BindUserPermission()
    {
        PermissionRoleCollection permissionRoles = PermissionRoleUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            PermissionRoleManager.FIND_PERMISSIONROLE_BY_ROLE,
            new object[] { Membership.ApplicationName, name.Text });

        foreach (DataListItem dataItem in permissionList.Items)
        {
            if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
            {
                CheckBoxList localPermissionList = (CheckBoxList)dataItem.FindControl("permissionList2");

                foreach (ListItem li in localPermissionList.Items)
                {
                    li.Selected = false;
                    if (permissionRoles != null)
                    {
                        foreach (PermissionRole permissionRole in permissionRoles)
                            if (permissionRole.PermissionId == ConvertUtility.ConvertInt(li.Value))
                                li.Selected = true;
                    }
                }
            }
        }
    }


    private bool UpdateMenuPermission()
    {
        PermissionRoleCollection permissionRoles = new PermissionRoleCollection();
        foreach (DataListItem dataItem in permissionList.Items)
        {
            if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
            {
                CheckBoxList localPermissionList = (CheckBoxList)dataItem.FindControl("permissionList2");

                foreach (ListItem li in localPermissionList.Items)
                {
                    if (li.Selected)
                    {
                        PermissionRole permissionRole = PermissionRoleUtility.CreateObject();
                        permissionRole.PermissionValue = 15;
                        permissionRole.PermissionId = ConvertUtility.ConvertInt(li.Value);
                        permissionRoles.Add(permissionRole);
                    }
                }
            }
        }

        PermissionRoleUtility.UpdateCollectionByRole(ConstantUtility.USER_DATASOURCE_NAME,
            Membership.ApplicationName, name.Text, permissionRoles);

        return true;
    }
    #endregion

    protected void permissionList_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (e.CommandName == "ApplyAll")
        {
            UpdateMenuPermission();

            Response.Redirect("UserRole_List.aspx");
        }
    }
}