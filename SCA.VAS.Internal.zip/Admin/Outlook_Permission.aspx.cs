#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

using SCA.VAS.Workflow;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class Outlook_Permission : PageBase
{
    private OutlookCollection outlooks;
    private OutlookPermissionCollection outlookPermissions;

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    protected void BindItem(object sender, DataListItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            DataList localOutlookList = (DataList)e.Item.FindControl("outlookList");
            Label localType = (Label)e.Item.FindControl("type");
            OutlookCollection outlookList = new OutlookCollection();

            if (outlooks != null)
            {
                foreach (Outlook o in outlooks)
                {
                    if (string.Compare(o.Type, localType.Text, true) == 0)
                    {
                        outlookList.Add(o);
                    }
                }
            }
            if (outlookList.Count == 0)
            {
                e.Item.CssClass = "invisible";
            }
            else
            {
                localOutlookList.DataSource = outlookList;
                localOutlookList.DataBind();
            }
        }
    }

    protected void BindSelectedItem(object sender, DataListItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            Outlook outlook = (Outlook)e.Item.DataItem;
            CheckBox localCheck = (CheckBox)e.Item.FindControl("check");

            if (outlookPermissions != null)
            {
                foreach (OutlookPermission o in outlookPermissions)
                {
                    if (o.OutlookId == outlook.Id)
                    {
                        localCheck.Checked = true;
                        break;
                    }
                }
            }
        }
    }

    protected void btnSubmit_Click(object sender, System.EventArgs e)
    {
        UpdateOutlookPermission();
        Response.Redirect("UserRole_List.aspx");
    }
    #endregion Web Event Handler

    #region Private Method
    private void SetInitialValue()
    {
        if (Request.QueryString["Role"] == null)
        {
            Response.Redirect("UserRole_List.aspx");
        }
        name.Text = Request.QueryString["Role"];

        outlooks = OutlookUtility.GetAll(ConstantUtility.USER_DATASOURCE_NAME);

        outlookPermissions = OutlookPermissionUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            OutlookPermissionManager.FIND_OUTLOOKPERMISSION_BY_ROLE,
            new object[] { name.Text });

        string outlookTypeStr = "";
        if (outlooks != null)
        {
            foreach (Outlook o in outlooks)
            {
                if (outlookTypeStr.IndexOf(o.Type) < 0)
                    outlookTypeStr += (o.Type + "|");
            }
        }
        if (outlookTypeStr.Length > 0)
            outlookTypeStr = outlookTypeStr.Substring(0, outlookTypeStr.Length - 1);

        outlookType.DataSource = outlookTypeStr.Split('|');
        outlookType.DataBind();
    }

    private bool UpdateOutlookPermission()
    {
        OutlookPermissionCollection outlookPermissions = new OutlookPermissionCollection();
        foreach (DataListItem typeItem in outlookType.Items)
        {
            if (typeItem.ItemType == ListItemType.Item || typeItem.ItemType == ListItemType.AlternatingItem)
            {
                DataList outlookList = (DataList)typeItem.FindControl("outlookList");
                foreach (DataListItem dataItem in outlookList.Items)
                {
                    if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
                    {
                        CheckBox localCheck = (CheckBox)dataItem.FindControl("check");
                        if (localCheck.Checked)
                        {
                            OutlookPermission outlookPermission = OutlookPermissionUtility.CreateObject();
                            outlookPermission.OutlookId = (int)outlookList.DataKeys[dataItem.ItemIndex];
                            outlookPermission.PermissionId = 0xF;

                            outlookPermissions.Add(outlookPermission);
                        }
                    }
                }
            }
        }
        OutlookPermissionUtility.UpdateCollectionByRole(ConstantUtility.USER_DATASOURCE_NAME, name.Text, outlookPermissions);

        return true;
    }
    #endregion
}
