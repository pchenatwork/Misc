#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;
using AspImage = System.Web.UI.WebControls.Image;
#endregion Reference

public partial class Workflow_Action : PageBase
{
    #region Private Member
    WorkflowNodeCollection workflowNodes;
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {            
            int workflowId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            WorkflowList workflowlist = WorkflowListUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowId);

            if (workflowList != null)
            {
                name.Text = workflowlist.Name;
            }

            ViewState["SortField"] = "UserStepId";
            ViewState["SortSequence"] = "ASC";
            BindGrid();
        }
    }

    protected void BindItem(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.AlternatingItem ||
            e.Item.ItemType == ListItemType.Item)
        {
            AspImage localStartNodeImg = (AspImage)e.Item.FindControl("startNodeImg");
            Label localFromNode = (Label)e.Item.FindControl("fromNodes");
            Label localToNode = (Label)e.Item.FindControl("toNodes");
            Label localRoles = (Label)e.Item.FindControl("roles");
            Label localChangeType = (Label)e.Item.FindControl("changeType");
            HyperLink localEdit = (HyperLink)e.Item.FindControl("editButton");

            ImageButton localCopy = (ImageButton)e.Item.FindControl("copyButton");
            localCopy.Attributes.Add("onclick", "return confirm('Are you sure you want to make a copy of this workflow node?');");

            WorkflowNode localWorkflowNode = (WorkflowNode)e.Item.DataItem;

            localChangeType.Text = "Manual";
            if (localWorkflowNode.TimeToSkip == 1)
                localChangeType.Text = "Automatic";
            else if (localWorkflowNode.TimeToSkip == 2)
                localChangeType.Text = "System";

            if (workflowNodes != null)
            {
                foreach (WorkflowNode wn in workflowNodes)
                {
                    if (wn.Id == localWorkflowNode.NodeFromId)
                        localFromNode.Text += "<img src=\"" + Page.ResolveUrl("~/images/icon-node-from.gif") +
                            "\" style=\"vertical-align: middle;\">&nbsp;" + wn.Name + "<br />";

                    if (wn.Id == localWorkflowNode.NodeToId)
                        localToNode.Text += "<img src=\"" + Page.ResolveUrl("~/images/icon-node-to.gif") +
                            "\" style=\"vertical-align: middle;\">&nbsp;" + wn.Name + "<br />";
                }
            }

            WorkflowNodeUserCollection workflowNodeUsers = WorkflowNodeUserUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeUserManager.FIND_WORKFLOWNODEUSER_BY_NODE,
                new object[] { (int)this.workflowList.DataKeys[e.Item.ItemIndex] });

            if (workflowNodeUsers != null)
            {
                foreach (WorkflowNodeUser wu in workflowNodeUsers)
                {
                    localRoles.Text += "<img src=\"" + Page.ResolveUrl("~/images/icon-u-role.gif") + "\" style=\"vertical-align: middle;\">&nbsp;" + wu.RoleName + "<br />";
                }
            }
            if (localRoles.Text == "")
                localRoles.Text = "<img src=\"" + Page.ResolveUrl("~/images/icon-u-xrole.gif") + "\" style=\"vertical-align: middle;\">&nbsp;None";
            if (localWorkflowNode.IsPermCtrl == 0)
                localRoles.Text = "<img src=\"" + Page.ResolveUrl("~/images/icon-u-role.gif") + "\" style=\"vertical-align: middle;\">&nbsp;All";

            localEdit.NavigateUrl = "Workflow_Action_Edit.aspx?nid=" + localWorkflowNode.Id.ToString();

            ImageButton localDelete = (ImageButton)e.Item.FindControl("deleteButton");
            localDelete.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this Node?')");
        }
    }

    protected void DeleteItem(object sender, DataGridCommandEventArgs e)
    {
        int listId = (int)workflowList.DataKeys[e.Item.ItemIndex];
        WorkflowNodeUtility.Delete(ConstantUtility.WORKFLOW_DATASOURCE_NAME, listId);

        BindGrid();
    }

    protected void btnSubmit_Click(object sender, System.EventArgs e)
    {
        int workflowId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        WorkflowList workflowList = WorkflowListUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME,
            workflowId);

        workflowList.Name = name.Text;

        WorkflowListUtility.Update(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowList);

        workflowNodes = WorkflowNodeUtility.FindByCriteria(ConstantUtility.WORKFLOW_DATASOURCE_NAME,
            WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW, new object[] { workflowId, "UserStepId", "ASC" });

        foreach (DataGridItem dataItem in this.workflowList.Items)
        {
            if (dataItem.ItemType == ListItemType.AlternatingItem || dataItem.ItemType == ListItemType.Item)
            {
                TextBox localNodeOrder = (TextBox)dataItem.FindControl("nodeorder");
                Label localOrderId = (Label)dataItem.FindControl("orderId");
                if (localNodeOrder.Text == localOrderId.Text) continue;

                if (workflowNodes != null)
                {
                    foreach (WorkflowNode wn in workflowNodes)
                    {
                        if (wn.Id == (int)this.workflowList.DataKeys[dataItem.ItemIndex])
                        {
                            wn.UserStepId = ConvertUtility.ConvertInt(localNodeOrder.Text);
                            WorkflowNodeUtility.Update(ConstantUtility.WORKFLOW_DATASOURCE_NAME, wn);
                        }
                    }
                }
            }
        }

        Response.Redirect("Workflow_List.aspx");
    }

    protected void saveStepButton_Click(object sender, EventArgs e)
    {
        WorkflowNode newNode = WorkflowNodeUtility.CreateObject();
        newNode.WorkflowId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        newNode.Type = 1;
        newNode.ConditionId = 1;
        newNode.Name = stepName.Text;
        newNode.NodeFromId = ConvertUtility.ConvertInt(fromList.SelectedValue);
        WorkflowNodeUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, newNode);

        BindGrid();
    }

    protected void ItemCommand(object o, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Copy")
        {
            int id = (int)workflowList.DataKeys[e.Item.ItemIndex];
            WorkflowNodeUtility.Copy(ConstantUtility.WORKFLOW_DATASOURCE_NAME, id);
            BindGrid();
        }
    }

    protected void SortItem(object source, DataGridSortCommandEventArgs e)
    {
        if (ViewState["SortField"].ToString() == e.SortExpression)
        {
            if (ViewState["SortSequence"].ToString() == "ASC")
                ViewState["SortSequence"] = "DESC";
            else
                ViewState["SortSequence"] = "ASC";
        }
        else
        {
            ViewState["SortField"] = e.SortExpression;
        }

        BindGrid();
    }
    #endregion Web Event Handler

    #region Private Method
    private void BindGrid()
    {
        int workflowId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        workflowNodes = WorkflowNodeUtility.FindByCriteria(
            ConstantUtility.WORKFLOW_DATASOURCE_NAME,
            WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
            new object[] 
            { 
                workflowId,
                ViewState["SortField"].ToString(),
                ViewState["SortSequence"].ToString()
            });

        WorkflowNodeCollection workflowNodesBind = new WorkflowNodeCollection();
        WorkflowNodeCollection workflowNewNodes = new WorkflowNodeCollection();
        if (workflowNodes != null)
        {
            foreach (WorkflowNode wn in workflowNodes)
            {
                if (wn.Type == 1)
                    workflowNodesBind.Add(wn);
                else
                    workflowNewNodes.Add(wn);
            }
        }

        if (workflowNodesBind.Count > 0)
        {
            workflowList.DataSource = workflowNodesBind;
            workflowList.DataBind();
            workflowList.Visible = true;
        }
        else
        {
            workflowList.Visible = false;
        }
        fromList.DataSource = workflowNewNodes;
        fromList.DataBind();
    }
    #endregion Private Method
}