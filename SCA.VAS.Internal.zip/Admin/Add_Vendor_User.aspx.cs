﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DocumentFormat.OpenXml;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.Workflow;
using SCA.VAS.Internal.BaseClasses;

namespace SCA.VAS.Internal.Admin
{
    public partial class Add_Vendor_User : BaseUserPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                contactTypeList.Attributes.Add("onclick", "processContactTypeList();");
                SetInitialValue(null);
            }
        }



        #region Public Method
        public void SetInitialValue(VendorContact contact)
        {
         
            string country = "USA";
            phone.Attributes.Add("onkeyup", "PhoneFormat(this, this.form, '" + country + "');");
            phone.Attributes.Add("onclick", "PhoneFormat(this, this.form, '" + country + "');");
            cell.Attributes.Add("onkeyup", "PhoneFormat(this, this.form, '" + country + "');");
            cell.Attributes.Add("onclick", "PhoneFormat(this, this.form, '" + country + "');");

            contactTypeList.Enabled = true;
            //contactTypeList.DataSource = CommonUtility.GetSettings("ContactType.xml");
            contactTypeList.DataSource = VendorContactRoleType.GetEnumList();
            contactTypeList.DataBind();

            string currenturl = Request.Url.ToString();
            int location = currenturl.LastIndexOf("/");
            currenturl = currenturl.Substring(0, location + 1);
            if (contact != null)
            {
               
                btnSubmit.Text = "Save";

           

                if (contact.Roles != null && contact.Roles.Count > 0)
                {
                    foreach (VendorContactRole role in contact.Roles)
                    {
                        foreach (ListItem item in contactTypeList.Items)
                        {
                            if (item.Value == role.VendorContactRoleId.ToString())
                            {
                                item.Selected = true;
                            }
                        }
                    }
                }



              
                title.SelectedIndex = title.Items.IndexOf(
                    title.Items.FindByValue(contact.Department));
                name.Text = contact.Name;
                email.Text = contact.Email;
                businessTitle.Text = contact.Title;
                phone.Text = contact.Phone;
                extension.Text = contact.Extension;
                cell.Text = contact.Fax;

              //  userName.Text = contact.UserName;
               // userName.Attributes.Add("onblur", "validate_username('" + contact.UserName + "', this.value,'" + currenturl + "', document.getElementById('" + userName.ClientID + "'));");

                foreach (ListItem li in contactTypeList.Items)
                    foreach (VendorContactRole vendorContactRole in contact.Roles)
                        if (li.Value == vendorContactRole.VendorContactRoleId.ToString())
                        {
                            li.Selected = true;
                            break;
                        }
            }
            else
            {
               
               
                btnSubmit.Text = "Add Contact";

               // userName.Attributes.Add("onblur", "validate_username('', this.value,'" + currenturl + "', document.getElementById('" + userName.ClientID + "'));");
                //contactTypeList.SelectedIndex = 0;
                title.SelectedIndex = 0;
                name.Text = "";
                email.Text = "";
                businessTitle.Text = "";
                extension.Text = "";
                cell.Text = "";
                phone.Text = "";
                primaryPhoneType.SelectedIndex = 0;
                secondaryPhoneType.SelectedIndex = 0;
                //userName.Text = "";
            }

           
        }
        #endregion

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid)
                return;

            VendorContact vendorContact = new VendorContact();
            
            vendorContact = VendorContactUtility.CreateObject();
           
            vendorContact.VendorId = Int32.Parse(txtvendorId.Value);

            //set default create message
            errmsgcreate.Text = "Create User Failed.Please contact VAS admin";

            // if fed id doesn't match of selected
            Vendor vendor =
                VendorUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, Int32.Parse(txtvendorId.Value));
            if (vendor == null || vendor.FederalId != txtFedId.Text)
            {
                errmsg.Visible = true;
                errmsg.Text = @"Company Not Found";
                return;
            }
            if (contactTypeList.SelectedIndex < 0)
                return;

            vendorContact.ContactType = contactTypeList.Items[contactTypeList.SelectedIndex].Text;
            //foreach (ListItem li in contactTypeList.Items)
            //{
            //    if(li.Selected)
            //        vendorContact.ContactType += li.Text;
                
            //}
            //vendorContact.UserName = userName.Text.Trim();
            vendorContact.Department = title.SelectedValue;
            vendorContact.Name = name.Text;
            vendorContact.Title = businessTitle.Text;
            vendorContact.Phone = phone.Text;
            vendorContact.Extension = extension.Text;
            vendorContact.Fax = cell.Text;
            vendorContact.Email = email.Text;
            vendorContact.FirstName = primaryPhoneType.SelectedValue;
            vendorContact.LastName = secondaryPhoneType.SelectedValue;
            vendorContact.ChangeUser = ((PageBase)Page).ChangeUser;

            if (vendorContact.Id > 0)
            {
                //Azure Update for the user.
                if (!vendorContact.ContactType.Contains("CES"))
                    if (UserProvider.Update(vendorContact).IsError) return;

                VendorContactUtility.Update(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorContact);
            }
            else
            {
                //add error handling for azure 
                try
                {

                    // When CES is selected, dont create Azure Account, store password
                    //if (contactTypeList.Items[2].Selected)
                    if (vendorContact.ContactType.Contains("CES"))
                    {
                        //generate system password for CES user, username is their email address
                        vendorContact.UserName = email.Text;
                        vendorContact.Password = System.Web.Security.Membership.GeneratePassword(8, 0);

                        if (VendorContactUtility.Create(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorContact))
                        {
                            vendorContact = VendorContactUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorContact.Id);
                            CommonUtility.SendEmail("VENDOR_ADD_CONTACT_PW_CES", new object[] { vendorContact }, "Supplier", SupplierId);
                            //refreshing the page, show alert upon user creation
                            Response.Write("<script language='javascript'>window.alert('User Created Successfully');window.location='Add_Vendor_User.aspx';</script>");
                        }
                        else {
                            errmsgcreate.Text = "Could not create CES user " + email.Text + ".  Please contact the VAS admin.";
                            errmsgcreate.Visible = true;
                            
                        }
                    }

                    //For non CES user, create Azure Account
                    else
                    {
                        var azResult = UserProvider.Create(vendorContact);
                        if ((vendorContact = UserProvider.InduceResult(vendorContact)) != null)
                        {
                            if (VendorContactUtility.Create(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorContact))
                            {
                                vendorContact = VendorContactUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorContact.Id);

                                CommonUtility.SendEmail("VENDOR_ADD_CONTACT_PW", new object[] { vendorContact }, "Supplier", SupplierId);

                                //Once again Update to remove userid/password     

                                vendorContact.Password = "";
                                VendorContactUtility.Update(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorContact);
                                //refreshing the page, show alert upon user creation
                                Response.Write("<script language='javascript'>window.alert('User Created Successfully');window.location='Add_Vendor_User.aspx';</script>");
                            }
                        }
                        else { errmsgcreate.Visible = true; }
                    }
                }
                catch (Exception ex)
                {
                    errmsgcreate.Visible = true;
                }
                
            }

            if (vendorContact != null)
            {
                VendorContactRoleCollection vendorContactRoles = new VendorContactRoleCollection();
                foreach (ListItem li in contactTypeList.Items)
                {
                    if (li.Selected)
                    {
                        VendorContactRole vendorContactRole = VendorContactRoleUtility.CreateObject();
                        vendorContactRole.VendorContactId = vendorContact.Id;
                        vendorContactRole.VendorContactRoleId = ConvertUtility.ConvertInt(li.Value);
                        vendorContactRoles.Add(vendorContactRole);
                    }
                }
                VendorContactRoleUtility.UpdateCollection(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorContact.Id, vendorContactRoles);
            }
            //ControlBase_Initial contacts = (ControlBase_Initial)this.Parent.Parent;
            //contacts.SetInitialValue();
            //OnUpdateContactCount(e);

        }

        public event EventHandler UpdateContactCount;

        protected void OnUpdateContactCount(EventArgs e)
        {
            if (UpdateContactCount != null)
            {
                UpdateContactCount(this, e);
            }
        }

        protected void btn_ClearForm(object sender, EventArgs e)
        {
            Page.Response.Redirect(Page.Request.Url.ToString(), true);
        }
    }
}