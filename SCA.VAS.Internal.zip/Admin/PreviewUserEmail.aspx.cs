#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;

using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

using SCA.VAS.Workflow;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class PreviewUserEmail : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            Page.ClientScript.RegisterStartupScript(GetType(), "PreviewEmail", "javascript:SetInitData();", true);
            if (Session["Users"] != null)
            {
                ArrayList selectedIds = (ArrayList)Session["Users"];
                string selectedUsers = "<ArrayOfUser>";
                for (int i = 0; i < selectedIds.Count; i++)
                {
                    selectedUsers += "<User Id=\"" + selectedIds[i].ToString() + "\" />";
                }
                selectedUsers += "</ArrayOfUser>";
                UserCollection users = UserUtility.FindByCriteria(
                    ConstantUtility.USER_DATASOURCE_NAME,
                    UserManager.FIND_USER,
                    new object[] { 0, 0, "LastName", "ASC", selectedUsers });
                userList.DataSource = users;
                userList.DataBind();
            }
            userList.Items.Insert(0, new ListItem("Select One", "0"));
        }
    }

    protected void userList_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        int userId = ConvertUtility.ConvertInt(userList.SelectedValue);
        if (userId > 0)
        {
            User user = CommonUtility.GetUser(userId);
            user.Password = "CANNOT DISPLAY PASSWORD";
            emailMessage.InnerHtml = CommonUtility.Replace(this.originalMessage.Value, new object[] { user });
        }

    }
    #endregion Web Event Handler
}
