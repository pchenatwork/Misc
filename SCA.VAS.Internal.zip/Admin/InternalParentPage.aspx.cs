#region Reference
using System;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using Menu = SCA.VAS.ValueObjects.User.Menu;
#endregion Reference

public partial class InternalParentPage : PageBase
{

    #region Private Member
    private int level;
    private MenuCollection allLevelMenus;
    #endregion

    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }

    protected void ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
    {
        if (((Button)(e.Item.Cells[0].Controls[0])).Text == "+")
        {
            // condition for node opening
            int Root = ConvertUtility.ConvertInt(pageGrid.Items[e.Item.ItemIndex].Cells[1].Text);
            for (int i = 1; i < pageGrid.Items.Count - 1; i++)
            {
                // condition checking for the level just below the root using ParentId
                if (pageGrid.Items[i].Cells[3].Text == Root.ToString())
                    pageGrid.Items[i].Visible = true;
            }

            // changing the text of Push Button to looks like opened tree node
            ((Button)(e.Item.Cells[0].Controls[0])).Text = "-";
        }
        else
        {
            // condition for tree closing
            int Root = Convert.ToInt32(pageGrid.Items[e.Item.ItemIndex].Cells[1].Text);

            // all the chid of the root is stored in this arraylist object
            ArrayList ArrC = new ArrayList();
            ArrC.Add(Root);

            // this loop will exit when the iteration through all the child of the selected node is over
            do
            {
                for (int i = 1; i < pageGrid.Items.Count - 1; i++)
                {
                    if (pageGrid.Items[i].Cells[3].Text == ArrC[0].ToString())
                    {
                        ArrC.Add(pageGrid.Items[i].Cells[1].Text);
                        pageGrid.Items[i].Visible = false;
                        ((Button)(pageGrid.Items[i].Cells[0].Controls[0])).Text = "+";
                    }
                }

                // removing the executed node form the arraylist
                ArrC.Remove(ArrC[0]);
            } while (ArrC.Count > 0);

            //after closing all the child node putting back the text back to orginal value
            ((Button)(e.Item.Cells[0].Controls[0])).Text = "+";
        }
    }
    #endregion Web Event Handler

    #region Private Method
    private void BindGrid()
    {
        MenuCollection menus = MenuUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            MenuManager.FIND_MENU_BY_APPLICATION,
            new object[] { Membership.ApplicationName });
        level = 0;

        allLevelMenus = new MenuCollection();

        GetAllLevelMenu(menus);

        pageGrid.DataSource = allLevelMenus;
        pageGrid.DataBind();
    }

    private void GetAllLevelMenu(MenuCollection menus)
    {
        if (menus != null)
        {
            foreach (Menu m in menus)
            {
                string toolTip = "";
                for (int i = 0; i < level; i++)
                    toolTip += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                toolTip += "<a href=\"javascript:SelectParentPage(" + m.Id + ", '" + m.Text.Replace("'", "\\'") + "');\">" + m.Text + "</a>";
                m.Text = toolTip;
                if (m.Display == "Y")
                    allLevelMenus.Add(m);
                if (m.SubMenus != null)
                {
                    level++;
                    GetAllLevelMenu(m.SubMenus);
                }
            }
        }
        level--;
    }
    #endregion Private Method
}