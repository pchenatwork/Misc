#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using System.Web.Security;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.Internal.Common.Cryptography;
#endregion Reference

public partial class User_Edit : PageBase
{
   
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["Id"] == null)
            {
                utitle.Text = "Add New User";
                userinfo.IsUpdate = false;
            }
            SetInitialValue();
        }
    }

    protected void Submit_Click(object sender, System.EventArgs e)
    {
        if (!Page.IsValid) return;
        bool flag = true;
        try
        {
            if (Request.QueryString["Id"] == null)
                flag = SaveUser();
            else
                UpdateUser();

            if (flag)
                Response.Redirect("User_Search.aspx");
            else
            {
                errmsg.Text = "Registration failed because of duplicate email address";
                errmsg.Visible = true;
            }
        }
        catch (Exception ex)
        {
            errmsg.Text = "Registration failed because of: " + ex.Message;
            errmsg.Visible = true;
        }
    }

    #endregion Web Event Handler

    #region Private Method
    private void SetInitialValue()
    {
        User user = null;
        if (Request.QueryString["Id"] != null)
        {
            user = UserUtility.GetById(ConstantUtility.USER_DATASOURCE_NAME,
                new Guid(Request.QueryString["Id"]));
        }

        userinfo.SetInitialValue(user);
    }

    /// <summary>
    /// save user information into database
    /// </summary>
    /// <returns>status</returns>
    private bool SaveUser()
    {
        MembershipUser membershipUser = Membership.CreateUser(userinfo.UserName, "password", userinfo.Email);
        string password = membershipUser.ResetPassword();
        User user = UpdateUser();
        user.UserName = membershipUser.UserName;
        user.Password = password;
        membershipUser.IsApproved = false;
        Membership.UpdateUser(membershipUser);

        CommonUtility.SendEmail("NEW_USER_REGISTRATION_ADMIN", new object[] { user }, "User", user.Id);

        return true;
    }

    private User UpdateUser()
    {
        User user = null;
         user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME,
               userinfo.UserName);
        if (user == null)
        {
               user = UserUtility.GetById(ConstantUtility.USER_DATASOURCE_NAME,
                new Guid(Request.QueryString["Id"]));
        }
     
        if (String.Compare(user.Email, userinfo.Email, true) != 0)
        {
            MembershipUser membershipUser = Membership.GetUser(userinfo.UserName);
            membershipUser.Email = userinfo.Email;
            Membership.UpdateUser(membershipUser);
        }

        user.UserName = userinfo.UserName;
        user.ApplicationName = Membership.ApplicationName;
        user.Email = userinfo.Email;
        user.FirstName = userinfo.FirstName;
        user.LastName = userinfo.LastName;
        user.Phone = userinfo.Phone;
        user.Extension = userinfo.Extension;
        user.Fax = userinfo.Fax;
        user.Division = !string.IsNullOrWhiteSpace(userinfo.Division) ? userinfo.Division : userinfo.Title;
        user.City = userinfo.City;
        user.State = userinfo.State;
        user.Company = userinfo.Company;
        user.Title  = userinfo.FederalId;
        user.Department = userinfo.Department;
        user.ZipCode = userinfo.ZipCode;
        user.Address = userinfo.Address;
        user.Country = userinfo.Country;
        user.Location = userinfo.Location;
        user.TimeZone = userinfo.TimeZone;
        user.EmailNotification = userinfo.EmailNotification;
        
        bool isPinRevoked = !user.Pin.Empty() && userinfo.Pin.Empty();
        bool isChanged = user.Pin != userinfo.Pin;
        user.Pin = userinfo.Pin;

        if ( UserUtility.UpdateUser(ConstantUtility.USER_DATASOURCE_NAME, user) )
        {
            if (isChanged && !isPinRevoked )
            {
                var _pin = UserPinCryption.RetirevePin(user.Pin);
                user.Pin = _pin; //To put the Human Readable PIN in Email.
                CommonUtility.SendEmail("USER_NEW_PIN_GENERATION_ADMIN", new object[] { user }, "User", user.Id);
            }
            else if (isPinRevoked)
            {
                //TODO: when pin is revoked should user be informed about it?
                //CommonUtility.SendEmail("USER_PIN_REVOKED_ADMIN", new object[] { user }, "User", user.Id);
            }
        }

        return user;
    }
    #endregion Private Method
}
