#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.BusinessLogic.Scorecard.Utilities;
using SCA.VAS.BusinessLogic.Scorecard;
using SCA.VAS.ValueObjects.Scorecard;
#endregion Reference

public partial class DeactivateAccount : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            bool pagePermission = CommonUtility.HasPermission(UserId, PageUrl);
            if (!pagePermission)
            {
                Response.Redirect("~/PermissionDenied.aspx");
            }

            userName.Text = Request.QueryString["Id"];
        }
    }
    #endregion Web Event Handler

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        MembershipUser mUser = Membership.GetUser(userName.Text);
        mUser.IsApproved = false;
        mUser.Comment = comments.Text;
        
        CommonUtility.DeactivateUser(userName.Text, UserId);
        Membership.UpdateUser(mUser);

        Page.ClientScript.RegisterStartupScript(GetType(), "RefreshParent", "window.opener.refreshpage();window.close();", true);
    }
}
