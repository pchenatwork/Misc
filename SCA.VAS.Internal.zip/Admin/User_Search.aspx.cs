#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;


using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class User_Search : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            ViewState["SortField"] = "Name";
            ViewState["SortSequence"] = "ASC";

            BindGrid();
        }
    }

    protected void SearchButtonClick(object sender, System.EventArgs e)
    {
        userGrid.CurrentPageIndex = 0;
        BindGrid();
    }

    protected void ItemCommand(object sender, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Delete")
        {
            string userName = (string)userGrid.DataKeys[e.Item.ItemIndex];
            Membership.DeleteUser(userName);
            BindGrid();
        }
        else if (e.CommandName == "Unlock")
        {
            string userName = (string)userGrid.DataKeys[e.Item.ItemIndex];
            MembershipUser mUser = Membership.GetUser(userName);
            mUser.UnlockUser();
            BindGrid();
        }
        else if (e.CommandName == "Reminder")
        {
            string userName = (string)userGrid.DataKeys[e.Item.ItemIndex];
            MembershipUser mUser = Membership.GetUser(userName);
            User user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, userName);
            user.Password = mUser.GetPassword();
            CommonUtility.SendEmail("USER_PASSWORD_REMINDER", new object[] { user }, "User", user.Id);
        }
        else if (e.CommandName == "Password")
        {
            string userName = (string)userGrid.DataKeys[e.Item.ItemIndex];
            MembershipUser mUser = Membership.GetUser(userName);
            User user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, userName);
            user.Password = mUser.ResetPassword();
            CommonUtility.SendEmail("USER_PASSWORD_RESET", new object[] { user }, "User", user.Id);
        }
    }

    protected void SortItem(object o, DataGridSortCommandEventArgs e)
    {
        if (ViewState["SortField"].ToString() == e.SortExpression)
        {
            if (ViewState["SortSequence"].ToString() == "ASC")
                ViewState["SortSequence"] = "DESC";
            else
                ViewState["SortSequence"] = "ASC";
        }
        else
        {
            ViewState["SortField"] = e.SortExpression;
        }
        BindGrid();
    }

    protected void PageChange(object o, DataGridPageChangedEventArgs e)
    {
        userGrid.CurrentPageIndex = e.NewPageIndex;
        BindGrid();
    }
    #endregion Web Event Handler

    #region Private Method
    private void BindGrid()
    {
        UserCollection users = UserUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            UserManager.SEARCH_USER,
            new object[] 
				{ 
					userGrid.PageSize,
					userGrid.CurrentPageIndex,
					ViewState["SortField"].ToString(),
					ViewState["SortSequence"].ToString(),
					search.Keyword, 
					search.Status,
                    search.Name,
                    search.Email,
					search.UserRole,
					search.Division,
					search.ExtraXml
				});
        DisplayGrid(users);
    }

    private void DisplayGrid(UserCollection users)
    {
        int pageSize = userGrid.PageSize;
        if (users != null && users.Count > 0)
        {
            userGrid.Visible = true;
            int totalNumber = users[0].TotalRecordNumber;
            userGrid.VirtualItemCount = totalNumber;
            if (users.Count > 1)
                usercount.Text = totalNumber.ToString() + " users found";
            else
                usercount.Text = totalNumber.ToString() + " user found";
            if (totalNumber <= pageSize)
            {
                userGrid.AllowCustomPaging = false;
                userGrid.AllowPaging = false;
            }
            else
            {
                userGrid.AllowCustomPaging = true;
                userGrid.AllowPaging = true;
            }

            userGrid.DataSource = users;
            userGrid.DataBind();

            ((Button)search.FindControl("btnDownload")).Enabled = true;

            SetSystemControlPermission(this.Page);
        }
        else
        {
            userGrid.Visible = false;
            usercount.Text = "No user found.";

            search.FindControl("btnDownload").Visible = false;
        }
    }

    protected void BindItem(object o, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            e.Item.Attributes.Add("onmouseover", "this.className='datagridSelectedItem'");
            if (e.Item.ItemType == ListItemType.Item)
                e.Item.Attributes.Add("onmouseout", "this.className='datagridItem'");
            else
                e.Item.Attributes.Add("onmouseout", "this.className='datagridAlternateItem'");

            HtmlGenericControl actionsSet = (HtmlGenericControl)e.Item.FindControl("actionsSet");
            HtmlGenericControl actionsMenuSet = (HtmlGenericControl)e.Item.FindControl("actionsMenuSet");
            actionsSet.Attributes.Add("onmouseover", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');getElement('" + actionsMenuSet.ClientID + "').style.width=(this.offsetWidth-2)+'px';this.className='actionsSet_Over';");
            actionsSet.Attributes.Add("onmouseout", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');this.className='actionsSet_Up';");

            User user = (User)e.Item.DataItem;
            MembershipUser mUser = Membership.GetUser(user.UserName);
            if (mUser != null)
            {
                ImageButton unlockStatus = (ImageButton)e.Item.FindControl("unlockStatus");
                unlockStatus.Visible = mUser.IsLockedOut;

                LinkButton unlockButton = (LinkButton)e.Item.FindControl("unlockButton");
                unlockButton.Enabled = mUser.IsLockedOut;

                Label localDate = (Label)e.Item.FindControl("lastLogin");
                localDate.Text = mUser.LastLoginDate.ToString();

                HyperLink statusLink = (HyperLink)e.Item.FindControl("status");
                LinkButton activateButton = (LinkButton)e.Item.FindControl("activateButton");
                LinkButton deactivateButton = (LinkButton)e.Item.FindControl("deactivateButton");
                if (mUser.IsApproved)
                {
                    statusLink.Text = "Active";
                    deactivateButton.Enabled = true;
                    deactivateButton.Attributes.Add("onclick", "javascript:popup(\"DeactivateAccount.aspx?Id=" + user.UserName.Replace("'", "\\'") + "\",500,400); return false;");
                }
                else
                {
                    statusLink.Text = "Inactive";
                    activateButton.Enabled = true;
                    activateButton.Attributes.Add("onclick", "javascript:popup(\"ApproveUser.aspx?Id=" + user.UserName.Replace("'", "\\'") + "\",500,400); return false;");
                }

                HtmlGenericControl localDescDiv = (HtmlGenericControl)e.Item.FindControl("descriptionDiv");
                Label description = (Label)e.Item.FindControl("description");
                if (mUser.Comment != null && mUser.Comment.Trim().Length > 0)
                {
                    description.Text = mUser.Comment;
                    statusLink.NavigateUrl = "javascript:toggleElementOverflow('" + localDescDiv.ClientID + "','hidden');";
                    statusLink.Attributes.Add("onmouseover", " if(getElement('" + localDescDiv.ClientID + "').style.overflow!='auto'){toggleElementDisplay('" + localDescDiv.ClientID + "','');}");
                    statusLink.Attributes.Add("onmouseout", " if(getElement('" + localDescDiv.ClientID + "').style.overflow!='auto'){toggleElementDisplay('" + localDescDiv.ClientID + "','');}");
                }

            }

            //LinkButton resetPassword = (LinkButton)e.Item.FindControl("resetPassword");
            //resetPassword.Attributes.Add("onclick", "javascript:return confirm('Are you sure you want to reset password for " + user.FullName.Replace("'", "\\'") + "?');");
            
            LinkButton deleteButton = (LinkButton)e.Item.FindControl("deleteLink");
            deleteButton.Attributes.Add("onclick", "return confirm('Are you sure you want to delete " + user.FullName.Replace("'", "\\'") + "?');");

            //LinkButton localReminderLink = (LinkButton)e.Item.FindControl("passwordReminderLink");
            //localReminderLink.Attributes.Add("onclick", "return confirm('Are you sure you want to send email reminder to " + user.Email.Replace("'", "\\'") + "?');");
        }
    }
    #endregion Private Method
}