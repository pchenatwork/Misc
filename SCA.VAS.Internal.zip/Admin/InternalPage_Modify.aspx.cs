#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using System.Web.Security;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.Common.Utilities;
using Menu = SCA.VAS.ValueObjects.User.Menu;
#endregion Reference 

public partial class InternalPage_Modify : PageBase
{
    #region Web Control Page Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    protected void Submit_Click(object sender, System.EventArgs e)
    {
        if (ModifyPage() > 0)
        {
            Response.Redirect("InternalPage_List.aspx");
        }
        else
        {
            errmsg.Text = "Modify Page Failed";
            errmsg.Visible = true;
        }
    }
    protected void permissionList_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            Permission localPermission = (Permission)e.Item.DataItem;
            CheckBoxList localPermissionList = (CheckBoxList)e.Item.FindControl("permissionList2");

            localPermissionList.DataSource = localPermission.SubPermissions;
            localPermissionList.DataBind();
        }
    }

    #endregion Web Control Page Handler

    #region Private Method

    /// <summary>
    /// SetInitialValue import all page's information into the form
    /// </summary>
    private void SetInitialValue()
    {
        ViewState["Id"] = Request.QueryString["Id"];
        if (ViewState["Id"] == null)
            ViewState["Id"] = "New Page";

        PermissionCollection permissions = PermissionUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            PermissionManager.FIND_PERMISSION_BY_TYPE,
            new object[] { 0 });
        permissionList.DataSource = permissions;
        permissionList.DataBind();


        if (ViewState["Id"].ToString() != "New Page")
        {
            int menuId = ConvertUtility.ConvertInt(ViewState["Id"].ToString());
            Menu menu = MenuUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, menuId);

            ParentPageId.Value = menu.ParentId.ToString();
            if (menu.ParentId == 0)
            {
                ParentPageName.Value = "Root";
            }
            else
            {
                Menu pMenu = MenuUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, menu.ParentId);
                ParentPageName.Value = pMenu.Text;
            }

            name.Text = menu.Text;
            url.Text = menu.Url;
            tooltip.Text = menu.ToolTip;
            iconpath.Text = menu.ImgLeft;
            displayorder.Text = menu.DisplayOrder.ToString();
            display.SelectedIndex = display.Items.IndexOf(
                display.Items.FindByValue(menu.Display));
            menuType.SelectedIndex = menuType.Items.IndexOf(
                menuType.Items.FindByValue(menu.Type));

            PermissionDetailCollection permissionDetails = PermissionDetailUtility.FindByCriteria(
                ConstantUtility.USER_DATASOURCE_NAME,
                PermissionDetailManager.FIND_PERMISSIONDETAIL_BY_USER,
                new object[] { menuId, 0, 0, 0 });

            foreach (DataListItem dataItem in permissionList.Items)
            {
                if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
                {
                    CheckBoxList localPermissionList = (CheckBoxList)dataItem.FindControl("permissionList2");

                    foreach (ListItem li in localPermissionList.Items)
                    {
                        li.Selected = false;
                        foreach (PermissionDetail permissionDetail in permissionDetails)
                            if (permissionDetail.PermissionId == ConvertUtility.ConvertInt(li.Value))
                                li.Selected = true;
                    }
                }
            }
       }
        else
        {
            int pId = 0;
            if (Request.QueryString["pId"] != null)
            {
                pId = ConvertUtility.ConvertInt(Request.QueryString["pId"].ToString());
            }
            ParentPageId.Value = pId.ToString();
            if (pId == 0)
            {
                ParentPageName.Value = "Root";
            }
            else
            {
                Menu pMenu = MenuUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, pId);
                ParentPageName.Value = pMenu.Text;
            }
        }
    }

    private int ModifyPage()
    {
        Menu menu = null;
        if (ViewState["Id"].ToString() != "New Page")
        {
            menu = MenuUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
                ConvertUtility.ConvertInt(ViewState["Id"].ToString()));
        }
        if (menu == null) menu = MenuUtility.CreateObject();

        menu.Text = name.Text;
        menu.Url = url.Text;
        menu.ToolTip = tooltip.Text;
        menu.ImgLeft = iconpath.Text;
        menu.DisplayOrder = ConvertUtility.ConvertInt(displayorder.Text);
        menu.ParentId = ConvertUtility.ConvertInt(ParentPageId.Value);
        menu.Display = display.SelectedValue;
        menu.Type = menuType.SelectedValue;
        menu.ApplicationName = Membership.ApplicationName;

        if (menu.Id == 0)
            MenuUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, menu);
        else
            MenuUtility.Update(ConstantUtility.USER_DATASOURCE_NAME, menu);

        PermissionDetailCollection permissionDetails = PermissionDetailUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            PermissionDetailManager.FIND_PERMISSIONDETAIL_BY_USER,
            new object[] { menu.Id, 0, 0, 0 });

        foreach (DataListItem dataItem in permissionList.Items)
        {
            if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
            {
                CheckBoxList localPermissionList = (CheckBoxList)dataItem.FindControl("permissionList2");

                foreach (ListItem li in localPermissionList.Items)
                {
                    int detailId = 0;
                    for (int i = 0; i < permissionDetails.Count; i++)
                    {
                        if (permissionDetails[i].PermissionId == ConvertUtility.ConvertInt(li.Value))
                        {
                            detailId = permissionDetails[i].Id;
                            break;
                        }
                    }
                    if (li.Selected && detailId == 0)
                    {
                        PermissionDetail permissionDetail = PermissionDetailUtility.CreateObject();
                        permissionDetail.PermissionId = ConvertUtility.ConvertInt(li.Value);
                        permissionDetail.MenuId = menu.Id;
                        permissionDetail.Type = "Menu";
                        permissionDetail.PermissionValue = 0xF;

                        PermissionDetailUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, permissionDetail);
                    }
                    else if (!li.Selected && detailId > 0)
                    {
                        PermissionDetailUtility.Delete(ConstantUtility.USER_DATASOURCE_NAME, detailId);
                    }
                }
            }
        }

        return menu.Id;
    }
    #endregion
}