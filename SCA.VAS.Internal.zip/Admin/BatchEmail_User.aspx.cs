#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class Admin_BatchEmail_User : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            btnPreview.Attributes.Add("onclick", "javascript:popup( 'PreviewUserEmail.aspx', 600, 400 );return false;");
            Session["Users"] = null;
            SetInitialValue();
        }
    }

    protected void send_Click(object sender, System.EventArgs e)
    {
        if (Session["Users"] == null)
        {
            errmsg.Text = "Please select users first!";
            return;
        }
        ArrayList idList = (ArrayList)(Session["Users"]);
        if (idList.Count == 0)
        {
            errmsg.Text = "Please select users first!";
            return;
        }

        ArrayList selectedIds = (ArrayList)Session["Users"];
        string selectedUsers = "<ArrayOfUser>";
        for (int i = 0; i < selectedIds.Count; i++)
        {
            selectedUsers += "<User Id=\"" + selectedIds[i].ToString() + "\" />";
        }
        selectedUsers += "</ArrayOfUser>";
        UserCollection users = UserUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            UserManager.FIND_USER,
            new object[] { 0, 0, "LastName", "ASC", selectedUsers });

        EmailMessage email = EmailMessageUtility.CreateObject();
        email.Type = "BatchUser";
        email.Name = "Batch Email to User";
        email.FromEmail = fromEmail.Text;
        email.FromName = fromName.Text;
        email.CcEmail = cc.Text;
        email.Subject = subject.Text;
        email.Body = emailBody.Text;
        int emailCount = CommonUtility.SendEmail(UserId, email, users, true);

        if (saveTemplate.SelectedValue == "Y")
        {
            EmailTemplate emailTemplate = EmailTemplateUtility.CreateObject();
            emailTemplate.Body = emailBody.Text;
            emailTemplate.Subject = subject.Text;
            emailTemplate.UserId = UserId;
            emailTemplate.ViewByOther = viewByOther.SelectedValue;
            EmailTemplateUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, emailTemplate);
        }
        Session["Users"] = null;
        string message = emailCount.ToString();
        if (emailCount > 1)
            message += " email(s) have been sent.";
        else
            message += " email has been sent.";
        Page.ClientScript.RegisterStartupScript(GetType(), "SendEmail", "javascript:alert('" + message + "');self.location.href='../home.aspx';", true);
    }
    #endregion Web Event Handler

    #region Private Method
    private void SetInitialValue()
    {
        User user = CommonUtility.GetUser(UserId);
        if (user != null)
        {
            fromEmail.Text = user.Email;
            fromName.Text = user.FullName;
        }
    }
    #endregion Private Method
}
