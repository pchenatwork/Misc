#region Reference
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
#endregion Reference

public partial class ApproveUser : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            bool pagePermission = CommonUtility.HasPermission(UserId, PageUrl);
            if (!pagePermission)
            {
                Response.Redirect("~/PermissionDenied.aspx");
            }
            
            userName.Text = Request.QueryString["Id"];
            
            Roles.ApplicationName = Membership.ApplicationName;
            string[] roles = Roles.GetAllRoles();
            roleList.DataSource = roles;
            roleList.DataBind();

            string[] userRoles = Roles.GetRolesForUser(userName.Text);
            for (int i = 0; i < roleList.Items.Count; i++)
            {
                DataListItem dataItem = roleList.Items[i];
                CheckBox localUserRole = (CheckBox)dataItem.FindControl("userRole");

                for (int j = 0; j < userRoles.Length; j++)
                {
                    if (localUserRole.Text == userRoles[j])
                    {
                        localUserRole.Checked = true;
                        break;
                    }
                }
            }
        }
    }
    #endregion Web Event Handler

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        MembershipUser mUser = Membership.GetUser(userName.Text);
        mUser.IsApproved = true;
        Membership.UpdateUser(mUser);

        foreach (DataListItem dataItem in roleList.Items)
        {
            if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
            {
                CheckBox localUserRole = (CheckBox)dataItem.FindControl("userRole");
                if (localUserRole.Checked && !Roles.IsUserInRole(userName.Text, localUserRole.Text))
                {
                    Roles.AddUserToRole(userName.Text, localUserRole.Text);
                }
                if (!localUserRole.Checked && Roles.IsUserInRole(userName.Text, localUserRole.Text))
                {
                    Roles.RemoveUserFromRole(userName.Text, localUserRole.Text);
                }
            }
        } 
        
        Page.ClientScript.RegisterStartupScript(GetType(), "RefreshParent", "window.opener.refreshpage();window.close();", true);
    }
}
