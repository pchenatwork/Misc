using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Xsl;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.User;

public partial class Admin_ImportUser : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void Submit_Click(object sender, EventArgs e)
    {
        if (!Page.IsValid) return;

        errmsg.Text = ImportUser();
        errmsg.Visible = errmsg.Text.Trim().Length > 0; 
    }

    #region Private Method
    private string ImportUser()
    {
        string msg = string.Empty;

        string xml = CommonUtility.GetXmlString(excelfile.PostedFile);

        string xslFileName = HttpRuntime.AppDomainAppPath + "Data\\User.xsl";
        XslCompiledTransform xslTransform = new XslCompiledTransform();
        XmlDocument xmlDocument = new XmlDocument();
        xmlDocument.LoadXml(xml);
        xslTransform.Load(xslFileName);
        StringWriter stream = new StringWriter();
        xslTransform.Transform(xmlDocument, null, stream);
        string userXml = stream.ToString();
        stream.Close();
        
        UserCollection users = (UserCollection)XmlUtility.Deserialize(userXml, typeof(UserCollection));

        if (users != null)
        {
            int userCount = 0;
            foreach (User user in users)
            {
                if (user.UserName.Trim().Length > 0)
                {
                    if (Membership.GetUser(user.UserName) == null)
                    {
                        MembershipUser membershipUser = Membership.CreateUser(user.UserName, "password", user.Email);

                        user.ApplicationName = Membership.ApplicationName;

                        UserUtility.Update(ConstantUtility.USER_DATASOURCE_NAME, user);

                        string password = membershipUser.ResetPassword();

                        user.UserName = membershipUser.UserName;
                        user.Password = password;
                    }
                    userCount++;
                }
            }

            msg += "Imported " + userCount.ToString() + " new user(s).";
        }
        return msg;
    }
    #endregion Private Method
}
