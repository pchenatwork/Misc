using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;

public partial class Admin_Controls_PermissionDetail : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void addButton_Click(object sender, EventArgs e)
    {
        int menuId = ConvertUtility.ConvertInt(pageList.SelectedValue);
        int permissionId = ConvertUtility.ConvertInt(Request.QueryString["id"]);
        Permission permission = PermissionUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, permissionId);

        foreach (PermissionDetail pd in permission.Details)
        {
            if (pd.MenuId == menuId && pd.Type == "Menu" && permissionType.SelectedValue == pd.Type ) return;
        }

        PermissionDetail permissionDetail = PermissionDetailUtility.CreateObject();
        permissionDetail.MenuId = menuId;
        permissionDetail.MenuName = pageList.SelectedItem.Text;
        permissionDetail.Type = permissionType.SelectedValue;
        permissionDetail.ControlName = name.Text;
        permissionDetail.PermissionValue = 0xF;
        permissionDetail.Description = desc.Text;
        permission.Details.Add(permissionDetail);

        PermissionDetailUtility.UpdateCollectionByPermission(ConstantUtility.USER_DATASOURCE_NAME,
            permissionId, permission.Details);

        PageBase_Initial PermissionEdit = (PageBase_Initial)this.Page;
        PermissionEdit.SetInitialValue();
    }

    #region Public Method
    public void SetInitialValue()
    {
        int permissionId = ConvertUtility.ConvertInt(Request.QueryString["id"]);
        Permission permission = PermissionUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, permissionId);
        
        MenuCollection menus = MenuUtility.FindByCriteria(ConstantUtility.USER_DATASOURCE_NAME,
            MenuManager.FIND_MENU_BY_TYPE, new object[] { permission.TypeName });
        pageList.DataSource = menus;
        pageList.DataBind();
        pageList.Items.Insert(0, new ListItem("Select One", ""));
    }
    #endregion Public Method

}
