﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.Internal.BaseClasses;

public partial class VendorContactExternals : BaseUserControlPage
{
    private System.Delegate _delPageMethod;

    public Delegate CallDelegate
    {
        set { _delPageMethod=value; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            contactTypeList.Attributes.Add("onclick", "processContactTypeList();");
        }
    }

    public int SupplierId
    {
        get
        {
            if (ViewState["SupplierId"] != null)
                return (int)ViewState["SupplierId"];
            return 0;
        }
        set
        {
            ViewState["SupplierId"] = value;
        }
    }

    public int VendorId
    {
        get
        {
            if (ViewState["VendorId"] != null)
                return (int)ViewState["VendorId"];
            return 0;
        }
        set
        {
            ViewState["VendorId"] = value;
        }
    }

    public int VendorContactExternalId
    {
        get
        {
            if (ViewState["VendorContactExternalId"] != null)
                return (int)ViewState["VendorContactExternalId"];
            return 0;
        }
        set
        {
            ViewState["VendorContactExternalId"] = value;
        }
    }

    #region Public Method
    public void SetInitialValue(VendorContactExternal contact, int vendorId, int supplierId)
    {
        VendorId = vendorId;
        SupplierId = supplierId;
              
        string country = "";
        Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierId);
        if (supplier.PhysicalAddress != null)
            country = supplier.PhysicalAddress.Country;
        phone.Attributes.Add("onkeyup", "PhoneFormat(this, this.form, '" + country + "');");
        phone.Attributes.Add("onclick", "PhoneFormat(this, this.form, '" + country + "');");
        cell.Attributes.Add("onkeyup", "PhoneFormat(this, this.form, '" + country + "');");
        cell.Attributes.Add("onclick", "PhoneFormat(this, this.form, '" + country + "');");

        contactTypeList.Enabled = true;
        //contactTypeList.DataSource = CommonUtility.GetSettings("ContactType.xml");
        contactTypeList.DataSource = VendorContactExternalRoleType.GetEnumList();
        contactTypeList.DataBind();

        string currenturl = Request.Url.ToString();
        int location = currenturl.LastIndexOf("/");
        currenturl = currenturl.Substring(0, location + 1);
        if (contact != null)
        {
            panelTitle.Text = "Edit Contact";
            btnSubmit.Text = "Save";

            VendorContactExternalId = contact.Id;

            if (contact.Roles != null && contact.Roles.Count > 0)
            {
                foreach (VendorContactExternalRole role in contact.Roles)
                {
                    foreach (ListItem item in contactTypeList.Items)
                    {
                        if (item.Value == role.VendorContactExternalRoleId.ToString())
                        {
                            item.Selected = true;
                        }
                    }
                }
            }



            title.SelectedIndex = title.Items.IndexOf(
                title.Items.FindByValue(contact.Department));
            name.Text = contact.Name;
            email.Text = contact.Email;
            hidEmail.Value = contact.Email;
            businessTitle.Text = contact.Title;
            phone.Text = contact.Phone;
            extension.Text = contact.Extension;
            cell.Text = contact.Fax;
            //userName.Text = contact.UserName;
            //userName.Attributes.Add("onblur", "validate_username('" + contact.UserName + "', this.value,'" + currenturl + "', document.getElementById('" + userName.ClientID + "'));");

            foreach (ListItem li in contactTypeList.Items)
                foreach (VendorContactExternalRole VendorContactExternalRole in contact.Roles)
                    if (li.Value == VendorContactExternalRole.VendorContactExternalRoleId.ToString())
                    {
                        li.Selected = true;
                        break;
                    }

            //btnReset.Text = string.Format("Reset {0}", contact.Migrated  == 1 ? "Migration Process" : "User Id"  );

        }
        else
        {
            VendorContactExternalId = 0;
            panelTitle.Text = "Add Contact";
            btnSubmit.Text = "Add Contact";

           // userName.Attributes.Add("onblur", "validate_username('', this.value,'" + currenturl + "', document.getElementById('" + userName.ClientID + "'));");
            //contactTypeList.SelectedIndex = 0;
            title.SelectedIndex = 0;
            name.Text = "";
            email.Text = "";
            businessTitle.Text = "";
            extension.Text = "";
            cell.Text = "";
            phone.Text = "";
            primaryPhoneType.SelectedIndex = 0;
            secondaryPhoneType.SelectedIndex = 0;
           // userName.Text = "";
        }

        supplierContactModalPopup.Show();
    }
    #endregion

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (!Page.IsValid)
            return;

        VendorContactExternal VendorContactExternal = null;

        if (VendorContactExternalId > 0)
            VendorContactExternal = VendorContactExternalUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, VendorContactExternalId);
        else
            return;

        if (contactTypeList.SelectedIndex < 0)
            return;

        VendorContactExternal.ContactType = contactTypeList.Items[contactTypeList.SelectedIndex].Text;
        foreach (ListItem li in contactTypeList.Items)
        {
            if (!li.Selected) continue;
            if (li.Value == "2")
              VendorContactExternal.ContactRole = "2";
          
        }
        VendorContactExternal.Department = title.SelectedValue;
        VendorContactExternal.Name = name.Text;
        VendorContactExternal.Title = businessTitle.Text;
        VendorContactExternal.Phone = phone.Text;
        VendorContactExternal.Extension = extension.Text;
        VendorContactExternal.Fax = cell.Text;
        VendorContactExternal.Email = email.Text;
        VendorContactExternal.FirstName = primaryPhoneType.SelectedValue;
        VendorContactExternal.LastName = secondaryPhoneType.SelectedValue;
        VendorContactExternal.ChangeUser = ((PageBase)Page).ChangeUser;

        if (VendorContactExternalUtility.Update(ConstantUtility.SUPPLIER_DATASOURCE_NAME, VendorContactExternal))
        {
            VendorContactExternalRoleCollection VendorContactExternalRoles = new VendorContactExternalRoleCollection();
            foreach (ListItem li in contactTypeList.Items)
            {
                if (li.Selected)
                {
                    VendorContactExternalRole VendorContactExternalRole = VendorContactExternalRoleUtility.CreateObject();
                    VendorContactExternalRole.VendorContactExternalId = VendorContactExternal.Id;
                    VendorContactExternalRole.VendorContactExternalRoleId = ConvertUtility.ConvertInt(li.Value);
                    VendorContactExternalRoles.Add(VendorContactExternalRole);
                }
            }
            VendorContactExternalRoleUtility.UpdateCollection(ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                VendorContactExternal.Id, VendorContactExternalRoles);
        }


        _delPageMethod.DynamicInvoke();


    }

    //protected void btnReset_Click(object sender, EventArgs e)
    //{
    //    VendorContactExternal VendorContactExternal = null;

    //    if (VendorContactExternalId > 0)
    //        VendorContactExternal = VendorContactExternalUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, VendorContactExternalId);
    //    else
    //        return;
        
    //    VendorContactExternal.Migrated = 0;
    //    VendorContactExternal.AzureObjectId = null;
    //    VendorContactExternal.Email = hidEmail.Value;
    //    if (VendorContactExternal.UserName.Contains("@") || VendorContactExternal.UserName.Empty())
    //        VendorContactExternal.UserName = string.Format("SCA{0}", VendorContactExternal.Id);
    //    VendorContactExternal.Password = System.Web.Security.Membership.GeneratePassword(8, 2);
        
    //    if (VendorContactExternalUtility.Update(ConstantUtility.SUPPLIER_DATASOURCE_NAME, VendorContactExternal))
    //    {
    //        CommonUtility.SendEmail("VENDOR_ADD_CONTACT_PW", new object[] { VendorContactExternal }, "Admin", VendorContactExternal.Id);
    //    }

    //    _delPageMethod.DynamicInvoke();
        
    //}
    
    public event EventHandler UpdateContactCount;

    protected void OnUpdateContactCount(EventArgs e)
    {
        if (UpdateContactCount != null)
        {
            UpdateContactCount(this, e);
        }
    }
}

    
