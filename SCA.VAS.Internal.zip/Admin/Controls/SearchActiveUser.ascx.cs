#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;
using System.Web.Security;

using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.Common.Utilities;
#endregion

public partial class SearchActiveUser : System.Web.UI.UserControl
{
    #region Web Control Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    protected void searchButton_Click(object sender, System.EventArgs e)
    {
        OnSearchClick(e);
    }

    public event EventHandler SearchClick;

    protected void OnSearchClick(EventArgs e)
    {
        if (SearchClick != null)
        {
            SearchClick(this, e);
        }
    }
    #endregion

    #region Public Property
    public string Keyword
    {
        get { return keyword.Text.Trim(); }
    }
    public int Status
    {
        get { return 1; }
    }
    public string UserRole
    {
        get { return userRole.Text.Trim(); }
    }
    public string Name
    {
        get
        {
            return name.Text.Trim();
        }
    }
    public string Email
    {
        get
        {
            return email.Text.Trim();
        }
    }
    public string Division
    {
        get
        {
            return division.Text.Trim();
        }
    }
    public string ExtraXml
    {
        get
        {
            return string.Empty;
        }
    }
    #endregion

}