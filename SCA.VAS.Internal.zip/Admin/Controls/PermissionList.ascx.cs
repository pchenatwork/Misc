#region Reference
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class Admin_Controls_PermissionList : System.Web.UI.UserControl
{
    #region Web Event Handler
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Permission permission = PermissionUtility.CreateObject();
        permission.Name = name.Text;
        permission.Type = ConvertUtility.ConvertInt(permissionType.SelectedValue);
        permission.ParentId = ConvertUtility.ConvertInt(parent.SelectedValue);

        PermissionUtility.Create(ConstantUtility.USER_DATASOURCE_NAME, permission);
        BindGrid();
        name.Text = string.Empty;
    }
    
    protected void permissionList_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            Permission localPermission = (Permission)e.Item.DataItem;
            
            DataGrid localPermissionList = (DataGrid)e.Item.FindControl("permissionList2");

            localPermissionList.DataSource = localPermission.SubPermissions;
            localPermissionList.DataBind();

            Button deleteButton = (Button)e.Item.FindControl("deleteButton");
            deleteButton.Attributes.Add("onclick", "javascript:return confirm('Are you sure you want to delete this permission?');");
            
            if (localPermission.SubPermissions != null && localPermission.SubPermissions.Count > 0)
                deleteButton.Visible = false;
        }
    }

    protected void permissionList2_ItemDataBound(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            HtmlGenericControl actionsSet = (HtmlGenericControl)e.Item.FindControl("actionsSet");
            HtmlGenericControl actionsMenuSet = (HtmlGenericControl)e.Item.FindControl("actionsMenuSet");
            actionsSet.Attributes.Add("onmouseover", "getElement('" + actionsMenuSet.ClientID + "').style.width=this.offsetWidth+'px';this.className='actionsSet_Over';");
            actionsSet.Attributes.Add("onmouseout", "this.className='actionsSet_Up';");

            LinkButton deleteButton = (LinkButton)e.Item.FindControl("DeleteButton");
            deleteButton.Attributes.Add("onclick", "javascript:return confirm('Are you sure you want to delete this permission?');");
        }
    }
    
    protected void permissionList_DeleteCommand(object source, DataListCommandEventArgs e)
    {
        int permissionId = (int)permissionList.DataKeys[e.Item.ItemIndex];
        PermissionUtility.Delete(ConstantUtility.USER_DATASOURCE_NAME, permissionId);
        BindGrid();
    }

    protected void permissionList2_DeleteCommand(object source, DataGridCommandEventArgs e)
    {
        DataGrid permissionGrid = (DataGrid)e.Item.Parent.Parent;
        int permissionId = (int)permissionGrid.DataKeys[e.Item.ItemIndex];
        PermissionUtility.Delete(ConstantUtility.USER_DATASOURCE_NAME, permissionId);
        BindGrid();
    }
    
    protected void permissionType_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindGrid();
    }
    #endregion Web Event Handler

    #region Public Method
    public void SetInitialValue()
    {
        PermissionTypeCollection permissionTypes = PermissionTypeUtility.GetAll(ConstantUtility.USER_DATASOURCE_NAME);
        permissionType.DataSource = permissionTypes;
        permissionType.DataBind();

        if (Request.QueryString["id"] != null)
            permissionType.SelectedIndex = permissionType.Items.IndexOf(
                permissionType.Items.FindByValue(Request.QueryString["id"]));

        BindGrid();
    }
    #endregion Public Method

    #region Private Method
    private void BindGrid()
    {
        PermissionCollection permissions = PermissionUtility.FindByCriteria(ConstantUtility.USER_DATASOURCE_NAME,
            PermissionManager.FIND_PERMISSION_BY_TYPE, 
            new object[] { ConvertUtility.ConvertInt(permissionType.SelectedValue) });
        permissionList.DataSource = permissions;
        permissionList.DataBind();

        parent.DataSource = permissions;
        parent.DataBind();
        parent.Items.Insert(0, new ListItem("Root", "0"));
    }
    #endregion Private Method

}
