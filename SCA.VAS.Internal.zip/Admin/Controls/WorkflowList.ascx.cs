using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;
using SCA.VAS.Workflow;

public partial class Workflow_WorkflowList : System.Web.UI.UserControl
{
    private bool isAdministrator = false;
    
    protected void Page_Load(object sender, EventArgs e)
	{
	}

	protected void BindItem(object sender, DataGridItemEventArgs e)
	{
        if (e.Item.ItemType == ListItemType.AlternatingItem ||
            e.Item.ItemType == ListItemType.Item)
        {
            WorkflowList workflow = (WorkflowList)e.Item.DataItem;

            e.Item.Attributes.Add("onmouseover", "this.className='datagridSelectedItem'");
            if (e.Item.ItemType == ListItemType.Item)
                e.Item.Attributes.Add("onmouseout", "this.className='datagridItem'");
            else
                e.Item.Attributes.Add("onmouseout", "this.className='datagridAlternateItem'");

            HtmlGenericControl actionsSet = (HtmlGenericControl)e.Item.FindControl("actionsSet");
            HtmlGenericControl actionsMenuSet = (HtmlGenericControl)e.Item.FindControl("actionsMenuSet");
            actionsSet.Attributes.Add("onmouseover", "getElement('" + actionsMenuSet.ClientID + "','').style.width=(this.offsetWidth-2)+'px';this.className='actionsSet_Over';");
            actionsSet.Attributes.Add("onmouseout", "this.className='actionsSet_Up';");

            HyperLink localStep = (HyperLink)e.Item.FindControl("stepButton");
            localStep.NavigateUrl = "~/Admin/Workflow_Action.aspx?id=" + workflow.Id.ToString();
            HyperLink localEdit = (HyperLink)e.Item.FindControl("editButton");
            LinkButton localDelete = (LinkButton)e.Item.FindControl("deleteButton");
            localDelete.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this workflow?');");

            if (isAdministrator)
            {
                localEdit.Visible = true;
                localStep.Visible = true;
                localDelete.Visible = true;
            }
            else
            {
                localDelete.Visible = false;
                localEdit.Visible = false;
                localStep.Visible = false;
            }
        }
	}

    protected void ItemCommand(object o, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Download")
        {
            Response.Redirect("DownloadWorkflow.aspx?Id=" + workflowList.DataKeys[e.Item.ItemIndex].ToString());
        }
    }

	protected void DeleteItem(object sender, DataGridCommandEventArgs e)
	{
		int id = (int)((DataGrid)sender).DataKeys[e.Item.ItemIndex];
		WorkflowListUtility.Delete(ConstantUtility.WORKFLOW_DATASOURCE_NAME, id);

		BindGrid();
	}

	protected void addButton_Click(object sender, System.EventArgs e)
	{
		WorkflowList workflowList = WorkflowListUtility.CreateObject();
		workflowList.Name = name.Text;
		workflowList.Description = desc.Text;

		WorkflowListUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowList);

		BindGrid();
	}

	public void SetInitialValue()
	{
		BindGrid();
	}

	private void BindGrid()
	{
        WorkflowListCollection workflowLists = WorkflowListUtility.FindByCriteria(
             ConstantUtility.WORKFLOW_DATASOURCE_NAME,
             WorkflowListManager.FIND_WORKFLOWLIST_BY_PROJECT,
             new object[] { 0, "", -1 });

		workflowList.DataSource = workflowLists;
		workflowList.DataBind();

	}

    override protected void OnInit(EventArgs e)
    {
        isAdministrator = CommonUtility.IsAdministrator(((PageBase)Page).UserName);
        base.OnInit(e);
    }


}
