#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;
using System.Web.Security;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.Common.Utilities;
#endregion

public partial class SearchUser : System.Web.UI.UserControl
{
    #region Web Control Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            Roles.ApplicationName = Membership.ApplicationName;
            roleList.DataSource = Roles.GetAllRoles();
            roleList.DataBind();
            roleList.Items.Insert(0, new ListItem("All", ""));
        }
    }

    protected void searchButton_Click(object sender, System.EventArgs e)
    {
        OnSearchClick(e);
    }

    public event EventHandler SearchClick;

    protected void OnSearchClick(EventArgs e)
    {
        if (SearchClick != null)
        {
            SearchClick(this, e);
        }
    }

    protected void addNew_Click(object sender, System.EventArgs e)
    {
        Response.Redirect("~/Admin/User_Edit.aspx");
    }
    #endregion

    #region Public Property
    public string Keyword
    {
        get { return keyword.Text.Trim(); }
    }
    public int Status
    {
        get { return ConvertUtility.ConvertInt(statusList.SelectedValue); }
    }

    public string UserRole
    {
        get { return roleList.SelectedValue; }
    }

    public string Name
    {
        get
        {
            return name.Text.Trim();
        }
    }
    public string Email
    {
        get
        {
            return email.Text.Trim();
        }
    }

    public string Division
    {
        get
        {
            return string.Empty;
        }
    }
    public string ExtraXml
    {
        get
        {
            return string.Empty;
        }
    }
    #endregion

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        Server.Transfer("DownloadUserExcel.aspx");
    }
}