#region Copyright
/*=======================================================================
*
* Modification History:
* Date       Programmer Description
* 03-25-2005 Lily Xiong eBusiness Section for Supplier Form
*
*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion
#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Supplier;

using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using log4net;
using System.Text.RegularExpressions;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
#endregion

/// <summary>
///		Summary description for SupervisorList.
/// </summary>
public partial class SupervisorList : ControlBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            ViewState["SortField"] = "LastName";
            ViewState["SortSequence"] = "ASC";
            btnCancel.Attributes.Add("onclick", "return confirm('Are you sure you want to cancel?');");
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        IsComplete = true;
        ((PopupControlBase)this.Parent.Parent).ChangeBaseControl(this);
    }

    protected void searchButton_Click(object sender, System.EventArgs e)
    {
        BindSearchGrid();
        IsComplete = false;
        ((PopupControlBase)this.Parent.Parent).ChangeBaseControl(this);
    }

    protected void addSelected_Click(object sender, System.EventArgs e)
    {
        if (Session["Users"] == null)
            Session["Users"] = new ArrayList();
        foreach (DataGridItem item in searchGrid.Items)
        {
            if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
            {
                if (((CheckBox)item.FindControl("selectBox")).Checked)
                {
                    ((ArrayList)Session["Users"]).Add((int)searchGrid.DataKeys[item.ItemIndex]);
                }
            }
        }
        IsComplete = true;
        ((PopupControlBase)this.Parent.Parent).ChangeBaseControl(this);
    }

    protected void AddPageChange(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
    {
        searchGrid.CurrentPageIndex = e.NewPageIndex;
        BindSearchGrid();
        IsComplete = false;
        ((PopupControlBase)this.Parent.Parent).ChangeBaseControl(this);
    }
    #endregion Web Event Handler

    public bool IsComplete
    {
        get { return (bool)ViewState["IsComplete"]; }
        set { ViewState["IsComplete"] = value; }
    }

    #region Private Method
    private void BindSearchGrid()
    {
        searchArea.Visible = true;

        string selectedUsers = "<ArrayOfUser>";
        if (Session["Users"] != null)
        {
            ArrayList selectedIds = (ArrayList)Session["Users"];
            for (int i = 0; i < selectedIds.Count; i++)
            {
                selectedUsers += "<User Id=\"" + selectedIds[i].ToString() + "\" />";
            }
        }
        selectedUsers += "</ArrayOfUser>";

        int pageSize = searchGrid.PageSize;
        UserCollection users = UserUtility.FindByCriteria(
            ConstantUtility.USER_DATASOURCE_NAME,
            UserManager.FIND_USER_NOT_SELECTED,
            new object[]
				{ 
					pageSize,
					searchGrid.CurrentPageIndex,
					ViewState["SortField"].ToString(),
					ViewState["SortSequence"].ToString(),
					search.Keyword, 
					search.Status,
					search.Name,
					search.Email,
					search.UserRole,
					search.Division,
					search.ExtraXml,
					selectedUsers 
				});

        if (users != null && users.Count > 0)
        {
            addSelected.Visible = true;
            searchGrid.Visible = true;

            int totalCount = users[0].TotalRecordNumber;
            searchGrid.VirtualItemCount = totalCount;

            if (totalCount > pageSize)
            {
                searchGrid.AllowCustomPaging = true;
                searchGrid.AllowPaging = true;
            }
            else
            {
                searchGrid.AllowCustomPaging = false;
                searchGrid.AllowPaging = false;
            }

            searchGrid.DataSource = users;
            searchGrid.DataBind();

            if (totalCount == 1)
                totalNumber.Text = totalCount.ToString() + " user found.";
            else
                totalNumber.Text = totalCount.ToString() + " users found.";
        }
        else
        {
            searchGrid.Visible = false;
            addSelected.Visible = false;
            totalNumber.Text = "No users match search criteria.";
        }
    }
    #endregion Private Method
}