﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.Internal.BaseClasses;
using SCA.VAS.ValueObjects.User;


public partial class VendorContacts : BaseUserControlPage
{
    private System.Delegate _delPageMethod;

    public Delegate CallDelegate
    {
        set { _delPageMethod=value; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            contactTypeList.Attributes.Add("onclick", "processContactTypeList();");
        }
    }

    public int SupplierId
    {
        get
        {
            if (ViewState["SupplierId"] != null)
                return (int)ViewState["SupplierId"];
            return 0;
        }
        set
        {
            ViewState["SupplierId"] = value;
        }
    }

    public int VendorId
    {
        get
        {
            if (ViewState["VendorId"] != null)
                return (int)ViewState["VendorId"];
            return 0;
        }
        set
        {
            ViewState["VendorId"] = value;
        }
    }

    public int VendorContactId
    {
        get
        {
            if (ViewState["VendorContactId"] != null)
                return (int)ViewState["VendorContactId"];
            return 0;
        }
        set
        {
            ViewState["VendorContactId"] = value;
        }
    }

    #region Public Method
    public void SetInitialValue(VendorContact contact, int vendorId, int supplierId)
    {
        VendorId = vendorId;
        SupplierId = supplierId;
              
        VendorContact primaryContact = CommonUtility.GetPrimaryContact(vendorId);

        string country = "";
        Supplier supplier = SupplierUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, supplierId);
        if (supplier.PhysicalAddress != null)
            country = supplier.PhysicalAddress.Country;
        phone.Attributes.Add("onkeyup", "PhoneFormat(this, this.form, '" + country + "');");
        phone.Attributes.Add("onclick", "PhoneFormat(this, this.form, '" + country + "');");
        cell.Attributes.Add("onkeyup", "PhoneFormat(this, this.form, '" + country + "');");
        cell.Attributes.Add("onclick", "PhoneFormat(this, this.form, '" + country + "');");

        contactTypeList.Enabled = true;
        //contactTypeList.DataSource = CommonUtility.GetSettings("ContactType.xml");
        contactTypeList.DataSource = VendorContactRoleType.GetEnumList();
        contactTypeList.DataBind();
        if (primaryContact != null && (contact == null || contact.ContactType != SupplierContact.PRIMARY_CONTACT))
        {
            //contactTypeList.Items.Remove(contactTypeList.Items.FindByValue(VendorContactRoleType.Primary.Id.ToString()));
            contactTypeList.Items.FindByValue(VendorContactRoleType.Primary.Id.ToString()).Enabled = false;
        }
        string currenturl = Request.Url.ToString();
        int location = currenturl.LastIndexOf("/");
        currenturl = currenturl.Substring(0, location + 1);
        if (contact != null)
        {
            panelTitle.Text = "Edit Contact";
            btnSubmit.Text = "Save";

            VendorContactId = contact.Id;

            if (contact.Roles != null && contact.Roles.Count > 0)
            {
                foreach (VendorContactRole role in contact.Roles)
                {
                    foreach (ListItem item in contactTypeList.Items)
                    {
                        if (item.Value == role.VendorContactRoleId.ToString())
                        {
                            item.Selected = true;
                        }
                    }
                }
            }



            if (contact.Id == primaryContact.Id) contactTypeList.Enabled = false;
            title.SelectedIndex = title.Items.IndexOf(
                title.Items.FindByValue(contact.Department));
            name.Text = contact.Name;
            email.Text = contact.Email;
            hidEmail.Value = contact.Email;
            businessTitle.Text = contact.Title;
            phone.Text = contact.Phone;
            extension.Text = contact.Extension;
            cell.Text = contact.Fax;
            primaryPhoneType.SelectedIndex = primaryPhoneType.Items.IndexOf(primaryPhoneType.Items.FindByValue(
                primaryContact.FirstName));
            secondaryPhoneType.SelectedIndex = secondaryPhoneType.Items.IndexOf(secondaryPhoneType.Items.FindByValue(
                primaryContact.LastName));
            //userName.Text = contact.UserName;
            //userName.Attributes.Add("onblur", "validate_username('" + contact.UserName + "', this.value,'" + currenturl + "', document.getElementById('" + userName.ClientID + "'));");

            foreach (ListItem li in contactTypeList.Items)
                foreach (VendorContactRole vendorContactRole in contact.Roles)
                    if (li.Value == vendorContactRole.VendorContactRoleId.ToString())
                    {
                        li.Selected = true;
                        break;
                    }

            btnReset.Text = string.Format("Reset {0}", contact.Migrated  == 1 ? "Migration Process" : "User Id"  );

        }
        else
        {
            VendorContactId = 0;
            panelTitle.Text = "Add Contact";
            btnSubmit.Text = "Add Contact";

           // userName.Attributes.Add("onblur", "validate_username('', this.value,'" + currenturl + "', document.getElementById('" + userName.ClientID + "'));");
            //contactTypeList.SelectedIndex = 0;
            title.SelectedIndex = 0;
            name.Text = "";
            email.Text = "";
            businessTitle.Text = "";
            extension.Text = "";
            cell.Text = "";
            phone.Text = "";
            primaryPhoneType.SelectedIndex = 0;
            secondaryPhoneType.SelectedIndex = 0;
           // userName.Text = "";
        }

        supplierContactModalPopup.Show();
    }
    #endregion

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (!Page.IsValid)
            return;

        VendorContact vendorContact = null;

        if (VendorContactId > 0)
            vendorContact = VendorContactUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, VendorContactId);
        else
            return;

        if (contactTypeList.SelectedIndex < 0)
            return;

        vendorContact.ContactType = contactTypeList.Items[contactTypeList.SelectedIndex].Text;
        //foreach (ListItem li in contactTypeList.Items)
        //{
        //    if (li.Selected && (li.Text == "Primary" || li.Text == "Secondary"))
        //    {
        //        vendorContact.ContactType = li.Text;
        //    }
        //}       
        //  vendorContact.UserName = userName.Text.Trim();
 
        bool changed = false;
        if (vendorContact.Email.Trim() != email.Text.Trim())
            changed = true;
        
        vendorContact.Department = title.SelectedValue;
        vendorContact.Name = name.Text;
        vendorContact.Title = businessTitle.Text;
        vendorContact.Phone = phone.Text;
        vendorContact.Extension = extension.Text;
        vendorContact.Fax = cell.Text;
        vendorContact.Email = email.Text;
        vendorContact.FirstName = primaryPhoneType.SelectedValue;
        vendorContact.LastName = secondaryPhoneType.SelectedValue;
        vendorContact.ChangeUser = ((PageBase)Page).ChangeUser;

        if (VendorContactUtility.Update(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorContact))
        {
            if ((vendorContact.ContactType == "Primary") && (changed) && (vendorContact.Email != vendorContact.UserName))
            {
                Vendor Vendor = VendorUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorContact.VendorId);
                User ChangeUser = SCA.VAS.BusinessLogic.User.Utilities.UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, ((PageBase)Page).UserName);
                CommonUtility.SendEmail("PRIMARY_CONTACT_CHANGE", new object[] { Vendor, ChangeUser }, "Admin", vendorContact.Id);
            }
        }

        if (vendorContact != null)
        {
            VendorContactRoleCollection vendorContactRoles = new VendorContactRoleCollection();
            foreach (ListItem li in contactTypeList.Items)
            {
                if (li.Selected)
                {
                    VendorContactRole vendorContactRole = VendorContactRoleUtility.CreateObject();
                    vendorContactRole.VendorContactId = vendorContact.Id;
                    vendorContactRole.VendorContactRoleId = ConvertUtility.ConvertInt(li.Value);
                    vendorContactRoles.Add(vendorContactRole);
                }
            }
            VendorContactRoleUtility.UpdateCollection(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorContact.Id, vendorContactRoles);
        }

        _delPageMethod.DynamicInvoke();
        // de.SetInitialValue();
        //OnUpdateContactCount(e);

    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        VendorContact vendorContact = null;

        if (VendorContactId > 0)
            vendorContact = VendorContactUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, VendorContactId);
        else
            return;
        
        vendorContact.Migrated = 0;
        vendorContact.AzureObjectId = null;
        vendorContact.Email = hidEmail.Value;
        if (vendorContact.UserName.Contains("@") || vendorContact.UserName.Empty())
            vendorContact.UserName = string.Format("SCA{0}", vendorContact.Id);
        vendorContact.Password = System.Web.Security.Membership.GeneratePassword(8, 2);
        
        if (VendorContactUtility.Update(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorContact))
        {
            CommonUtility.SendEmail("VENDOR_ADD_CONTACT_PW", new object[] { vendorContact }, "Admin", vendorContact.Id);
        }

        _delPageMethod.DynamicInvoke();
        
    }
    
    public event EventHandler UpdateContactCount;

    protected void OnUpdateContactCount(EventArgs e)
    {
        if (UpdateContactCount != null)
        {
            UpdateContactCount(this, e);
        }
    }
}

    
