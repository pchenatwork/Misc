#region Copyright
/*=======================================================================
*
* Modification History:
* Date       Programmer Description
* 03-25-2005 Lily Xiong Product & Service Section for Supplier Form
*
*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;
using System.Web.Security;
using System.IO;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.BusinessLogic.Rfd.Utilities;
using SCA.VAS.ValueObjects.Rfd;
#endregion

public partial class UserInfo : ControlBase
{
    #region Web Event Handler
    string _title = string.Empty;
    bool _isUpdate = true;
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        tmpUserPin.Visible = _isUpdate;
    }
    #endregion

    #region Public Property
    public string UserName
    {
        get
        {
            return username.Text;
        }
    }
    public string Email
    {
        get
        {
            return email.Text;
        }
    }
    public string FirstName
    {
        get
        {
            return firstname.Text;
        }
    }
    public string LastName
    {
        get
        {
            return lastname.Text;
        }
    }
    public string Phone
    {
        get
        {
            return phone.Text;
        }
    }
    public string Extension
    {
        get
        {
            return extension.Text;
        }
    }
    public string Fax
    {
        get
        {
            return fax.Text;
        }
    }
    public string Division
    {
        get
        {
            return division.Text;
        }
    }

    public string Title
    {
        get
        {
            return _title;
        }
    }
    public string Company
    {
        get
        {
            return company.Text;
        }
    }
    public string FederalId
    {
        get
        {
            return federalId.Text;
        }
    }
    public string Department
    {
        get
        {
            //return department.SelectedValue;
            return _department.Text;
        }
    }
    public string Address
    {
        get
        {
            return address.Text;
        }
    }
    public string City
    {
        get
        {
            return city.Text;
        }
    }
    public string State
    {
        get
        {
            return state.Text;
        }
    }
    public string ZipCode
    {
        get
        {
            return zipCode.Text;
        }
    }
    public string Location
    {
        get
        {
            return location.Text;
        }
    }
    public string Country
    {
        get
        {
            return country.SelectedValue;
        }
    }
    public string TimeZone
    {
        get
        {
            return timezoneList.SelectedValue;
        }
    }

    public string EmailNotification
    {
        get
        {
            return emailNotification.Checked ? "Y" : "N";
        }
    }

    public string Pin
    {
        get
        {
            return hidCurrentPin.Value;
        }
    }

    public bool IsUpdate
    {
        set
        {
            _isUpdate = value;
        }
    }

    #endregion

    #region Public Method
    public void SetInitialValue(User user)
    {
        ViewState["UserId"] = user == null ? 0 : user.Id;
        Session["Users"] = new ArrayList();

        hidOrginalPin.Value = hidCurrentPin.Value = "";

        department.DataSource = BusinessUnitUtility.GetAll(ConstantUtility.COMMON_DATASOURCE_NAME);
        department.DataBind();
        department.Items.Insert(0, new ListItem("Select One", ""));

        country.DataSource = CountryUtility.GetAll(ConstantUtility.COMMON_DATASOURCE_NAME);
        country.DataBind();
        country.SelectedIndex = country.Items.IndexOf(country.Items.FindByValue(ConstantUtility.DEFAULT_COUNTRY));

        timezoneList.DataSource = CommonUtility.AllTimeZones();
        timezoneList.DataBind();

        if (user != null)
        {
            username.Text = user.UserName;
            username.Enabled = false;
            email.Text = user.Email;
            firstname.Text = user.FirstName;
            lastname.Text = user.LastName;
            phone.Text = user.Phone;
            extension.Text = user.Extension;
            fax.Text = user.Fax;
            division.Text = user.Division;
            company.Text = user.Company;
            federalId.Text = user.Title ;
            //department.SelectedIndex = department.Items.IndexOf(department.Items.FindByValue(user.Department));
            _department.Text = user.Department;
            address.Text = user.Address;
            city.Text = user.City;
            state.Text = user.State;
            zipCode.Text = user.ZipCode;
            location.Text = user.Location;
            country.SelectedIndex = country.Items.IndexOf(country.Items.FindByValue(user.Country));
            timezoneList.SelectedIndex = timezoneList.Items.IndexOf(
                timezoneList.Items.FindByValue(user.TimeZone));
            emailNotification.Checked = (user.EmailNotification == "Y");
            btnRetrieve.Visible = false;

            if (!CommonUtility.IsAdministrator(((PageBase)Page).UserName))
            {
                federalId.ReadOnly = true;
            }

            if (!user.Pin.Empty()) //must be checked with !user.Pin.Empty()
            {
                hidOrginalPin.Value = user.Pin;            
                hidCurrentPin.Value = user.Pin;
            }
        }
        else
        {
            company.Text = ConfigurationManager.AppSettings["Company"];
            timezoneList.SelectedIndex = timezoneList.Items.IndexOf(
                timezoneList.Items.FindByValue(System.TimeZone.CurrentTimeZone.StandardName));
            btnRetrieve.Visible = true;
        }


    }
    #endregion

    protected void btnRetrieve_Click(object sender, EventArgs e)
    {
        CesUser cesUser = CesUserUtility.Get(ConstantUtility.RFD_DATASOURCE_NAME,
            username.Text);
        if (cesUser != null)
        {
            email.Text = cesUser.Email;
            firstname.Text = cesUser.FirstName;
            lastname.Text = cesUser.LastName;

            division.Text = cesUser.Division;
            _department.Text = cesUser.Department;
            _title = cesUser.Title;
        }
    }
}
