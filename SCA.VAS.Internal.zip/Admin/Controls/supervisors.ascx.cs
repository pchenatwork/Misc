#region Copyright
/*=======================================================================
*
* Modification History:
* Date       Programmer Description
* 03-25-2005 Lily Xiong Product & Service Section for Supplier Form
*
*=======================================================================
* Copyright (C) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region References
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;
using System.Web.Security;
using System.IO;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.Common;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.Workflow;
using SCA.VAS.BusinessLogic.User;
#endregion

public partial class Supervisors : PopupControlBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }

    protected void addSupervisor_Click(object sender, EventArgs e)
    {
        ModalPopup_supervisor.Show();
    }
    override public void ShowPopup(object sender)
    {
    }
    override public void HidePopup(object sender)
    {
        if (sender is SupervisorList)
        {
            ModalPopup_supervisor.Hide();
            BindSupervisors();
        }
    }
    override public void ChangeBaseControl(object sender)
    {
        if (sender is SupervisorList)
        {
            if (((SupervisorList)sender).IsComplete)
                BindSupervisors();
            else
                ModalPopup_supervisor.Show();
        }
    }
    protected void DeleteItem(object sender, DataGridCommandEventArgs e)
    {
        int userId = ConvertUtility.ConvertInt(supervisorGrid.DataKeys[e.Item.ItemIndex].ToString());
        for (int i = 0; i < ((ArrayList)Session["Users"]).Count; i++)
        {
            if ((int)(((ArrayList)Session["Users"])[i]) == userId)
                ((ArrayList)Session["Users"]).Remove(((ArrayList)Session["Users"])[i--]);
        }
        BindSupervisors();
    }
    #endregion

    #region Public Property
    #endregion

    #region Public Method
    public void SetInitialValue(User user)
    {
        Session["Users"] = new ArrayList();

        if (user != null)
        {
            if (user.UserAffiliates != null && user.UserAffiliates.Count > 0)
            {
                foreach (UserAffiliate ua in user.UserAffiliates)
                {
                    ((ArrayList)Session["Users"]).Add(ua.AffiliateId);
                }
                BindSupervisors();
            }
        }
    }

    public UserAffiliateCollection GetUserAffiliates(User user)
    {
        UserAffiliateCollection userAffiliates = new UserAffiliateCollection();
        foreach (DataGridItem dataItem in supervisorGrid.Items)
        {
            if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
            {
                UserAffiliate userAffiliate = UserAffiliateUtility.CreateObject();
                userAffiliate.UserId = user.Id;
                userAffiliate.AffiliateId = (int)supervisorGrid.DataKeys[dataItem.ItemIndex];
                userAffiliates.Add(userAffiliate);
            }
        }
        return userAffiliates;
    }

    private void BindSupervisors()
    {
        UserCollection users = new UserCollection();
        if (Session["Users"] != null)
            foreach (int uid in (ArrayList)Session["Users"])
            {
                User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME, uid);
                if (user != null) users.Add(user);
            }

        supervisorGrid.DataSource = users;
        supervisorGrid.DataBind();
    }
    #endregion
}
