#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Web.Security;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;
//using SCA.VAS.BusinessLogic.Scorecard.Utilities;
//using SCA.VAS.BusinessLogic.Scorecard;
//using SCA.VAS.ValueObjects.Scorecard;
#endregion Reference

public partial class User_Role : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    protected void btnSubmit_Click(object sender, System.EventArgs e)
    {
        UpdateUserRole();
        Response.Redirect("User_Search.aspx");
    }
    #endregion Web Event Handler

    #region Private Method
    private void SetInitialValue()
    {
        if (Request.QueryString["User"] != null)
        {
            ViewState["User"] = Request.QueryString["User"];
            User user = UserUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
                ConvertUtility.ConvertInt(Request.QueryString["User"].ToString()));
            name.Text = user.UserName;

            Roles.ApplicationName = Membership.ApplicationName;
            string[] roles = Roles.GetAllRoles();
            roleList.DataSource = roles;
            roleList.DataBind();

            string[] userRoles = Roles.GetRolesForUser(user.UserName);
            for (int i = 0; i < roleList.Items.Count; i++)
            {
                DataListItem dataItem = roleList.Items[i];
                CheckBox localUserRole = (CheckBox)dataItem.FindControl("userRole");

                for (int j = 0; j < userRoles.Length; j++)
                {
                    if (localUserRole.Text == userRoles[j])
                    {
                        localUserRole.Checked = true;
                    }
                }
            }

            //ScorecardCollection scorecards = ScorecardUtility.FindByCriteria(
            //    ConstantUtility.SCORECARD_DATASOURCE_NAME,
            //    ScorecardManager.FIND_SCORECARD_BY_INVITEE,
            //    new object[] 
            //    {
            //        0, 0, "CloseDate", "DESC", user.Id,
            //        "", -1, "", new DateTime(1900, 1, 1),
            //        new DateTime(1900, 1, 1), "",
            //        "<ArrayOfExtra />"
            //    });

            //string[] userRoles = Roles.GetRolesForUser(user.UserName);
            //for (int i = 0; i < roleList.Items.Count; i++)
            //{
            //    DataListItem dataItem = roleList.Items[i];
            //    CheckBox localUserRole = (CheckBox)(dataItem.FindControl("userRole"));

            //    for (int j = 0; j < userRoles.Length; j++)
            //    {
            //        if (localUserRole.Text == userRoles[j])
            //        {
            //            localUserRole.Checked = true;
            //            if (scorecards != null)
            //            {
            //                foreach (Scorecard scorecard in scorecards)
            //                {
            //                    if ((scorecard.Invitee != null && scorecard.Invitee.UserType == userRoles[j]) ||
            //                        (scorecard.Supervisor != null && scorecard.Supervisor.SupervisorType == userRoles[j]))
            //                    {
            //                        localUserRole.Enabled = false;
            //                        break;
            //                    }
            //                    if (scorecard.Users != null)
            //                    {
            //                        foreach (ScorecardUser scorecardUser in scorecard.Users)
            //                        {
            //                            if (scorecardUser.UserType == userRoles[j])
            //                            {
            //                                localUserRole.Enabled = false;
            //                                break;
            //                            }
            //                        }
            //                    }
            //                }
            //            }
            //        }
            //    }
            //}
        }
        else
        {
            Response.Redirect("User_Search.aspx");
        }
    }

    private void UpdateUserRole()
    {
        bool roleChecked = false;
        foreach (DataListItem dataItem in roleList.Items)
        {
            if (dataItem.ItemType == ListItemType.Item || dataItem.ItemType == ListItemType.AlternatingItem)
            {
                CheckBox localUserRole = (CheckBox)(dataItem.FindControl("userRole"));
                if (localUserRole.Checked && !roleChecked) roleChecked = true;
                if (localUserRole.Checked && !Roles.IsUserInRole(name.Text, localUserRole.Text))
                {
                    Roles.AddUserToRole(name.Text, localUserRole.Text);
                }
                if (!localUserRole.Checked && Roles.IsUserInRole(name.Text, localUserRole.Text))
                {
                    Roles.RemoveUserFromRole(name.Text, localUserRole.Text);
                }
            }
        }

        MembershipUser membershipUser = Membership.GetUser(name.Text);
        if (!membershipUser.IsApproved && roleChecked)
        {
            User user = UserUtility.GetByName(ConstantUtility.USER_DATASOURCE_NAME, name.Text);
            user.Password = membershipUser.GetPassword();
            CommonUtility.SendEmail("NEW_USER_REGISTRATION", new object[] { user }, "User", user.Id);
        }

        if (membershipUser.IsApproved != roleChecked)
        {
            membershipUser.IsApproved = roleChecked;
            Membership.UpdateUser(membershipUser);
        }
    }
    #endregion
}
