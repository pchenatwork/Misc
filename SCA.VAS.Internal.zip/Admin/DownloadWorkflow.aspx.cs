﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.IO;

using Microsoft.Office.Interop.Visio;

using SCA.VAS.Workflow;

using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

public partial class Admin_DownloadWorkflow : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int workflowId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
            WorkflowList workflow = WorkflowListUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                workflowId);
            WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                new object[] { workflowId, "UserStepId", "ASC" });
            if (workflowNodes == null)
                return;

            WorkflowNodeCollection nodes = new WorkflowNodeCollection();
            WorkflowNodeCollection links = new WorkflowNodeCollection();
            foreach (WorkflowNode workflowNode in workflowNodes)
            {
                if (workflowNode.Type == 1 && workflowNode.NodeToId > 0)
                    links.Add(workflowNode);
                else if (workflowNode.Type != 1)
                    nodes.Add(workflowNode);
            }

            Application vApp = new Application();
            Document vDoc;
            Shape vFromShape = null;
            Shape vToShape = null;
            Shape vNodeShape;
            Shape vAnnotation;
            Master vFlowChartMaster;
            Master vAnnotationMaster;
            Document vStencil;
            double dblXLocation;
            double dblYLocation;
            string roles = string.Empty;
            string conditions = string.Empty;

            string downloadFolder = CommonUtility.GetDownloadFolder(UserId);
            string fileName = workflow.Name.Replace("/", "") + ".vsd";

            // Start point measured from the bottom left corner.
            dblXLocation = 4.25;
            dblYLocation = 10;

            // Create a new document; note the empty string.
            vDoc = vApp.Documents.Add("");
            vStencil = vApp.Documents.OpenEx(ConfigurationManager.AppSettings["LookupFolder"] + "BASFLO_U.VSS", (short)VisOpenSaveArgs.visOpenDocked);

            for (int i = 0; i < nodes.Count; i++)
            {
                if (nodes[i].Type == 7)
                    vFlowChartMaster = vStencil.Masters["Terminator"];
                else
                    vFlowChartMaster = vStencil.Masters["Predefined process"];
                vNodeShape = vApp.ActivePage.Drop(vFlowChartMaster, dblXLocation, dblYLocation);
                vNodeShape.Text = nodes[i].Name;
                dblYLocation = dblYLocation - 2;
            }

            for (int i = 0; i < links.Count; i++)
            {
                WorkflowNode fromNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                    links[i].NodeFromId);
                WorkflowNode toNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                    links[i].NodeToId);

                foreach (Shape shape in vApp.ActivePage.Shapes)
                {
                    if (shape.Text == fromNode.Name)
                        vFromShape = shape;
                    else if (shape.Text == toNode.Name)
                        vToShape = shape;
                }

                vFlowChartMaster = vStencil.Masters["Process"];
                vNodeShape = vApp.ActivePage.Drop(vFlowChartMaster, 0, 0);
                vNodeShape.Text = links[i].Name;

                conditions = string.Empty;
                if (links[i].WorkflowActions != null)
                {
                    foreach (WorkflowCondition workflowCondition in links[i].WorkflowConditions)
                        conditions += workflowCondition.Name + "\r\n";
                }

                if (conditions.Length == 0)
                {
                    ConnectWithDynamicGlueAndConnector(vApp.ActivePage, vStencil, vFromShape, vNodeShape);
                    ConnectWithDynamicGlueAndConnector(vApp.ActivePage, vStencil, vNodeShape, vToShape);
                }
                else
                {
                    vAnnotationMaster = vStencil.Masters["Decision"];
                    vAnnotation = vApp.ActivePage.Drop(vAnnotationMaster, 0, 0);
                    vAnnotation.Text = conditions;

                    ConnectWithDynamicGlueAndConnector(vApp.ActivePage, vStencil, vFromShape, vAnnotation);
                    ConnectWithDynamicGlueAndConnector(vApp.ActivePage, vStencil, vAnnotation, vNodeShape);
                    ConnectWithDynamicGlueAndConnector(vApp.ActivePage, vStencil, vNodeShape, vToShape);
                }

                roles = string.Empty;
                if (links[i].WorkflowNodeUsers != null && links[i].WorkflowNodeUsers.Count > 0)
                {
                    foreach (WorkflowNodeUser nodeUser in links[i].WorkflowNodeUsers)
                        roles += nodeUser.RoleName + "\r\n";

                    if (roles.Length > 0)
                    {
                        //vAnnotationMaster = vStencil.Masters["Annotation"];

                        //vAnnotation = vApp.ActivePage.Drop(vAnnotationMaster, 0, 0);
                        //vAnnotation.Text = roles;

                        //vAnnotation.get_Cells("BeginX").GlueTo(vNodeShape.get_Cells("AlignRight"));
                        //vAnnotation.SendToBack();

                        vAnnotationMaster = vStencil.Masters["Display"];
                        vAnnotation = vApp.ActivePage.Drop(vAnnotationMaster, 0, 0);
                        vAnnotation.Text = roles;

                        ConnectWithDynamicGlueAndConnector(vApp.ActivePage, vStencil, vAnnotation, vNodeShape);
                    }
                }
            }

            Microsoft.Office.Interop.Visio.Page page = vDoc.Pages[1];
            page.PageSheet.get_CellsU("PlaceStyle").FormulaU = "2";
            page.PageSheet.get_CellsU("RouteStyle").FormulaU = "6";
            // code to drop and glue all the shapes
            page.Layout();
            page.ResizeToFitContents();

            vDoc.Pages[1].Name = workflow.Name;
            
            try
            {
                //Delete the previous version of the file.
                File.Delete(downloadFolder + fileName);
            }
            catch
            {
            }
            vDoc.SaveAs(downloadFolder + fileName);
            vDoc.Close();
            vApp.Quit();
            GC.Collect();

            Response.ContentType = "application/octet-stream";
            Response.AppendHeader("content-disposition",
                "attachment; filename=" + fileName + ".vsd");
            Response.WriteFile(downloadFolder + fileName);
            Response.End();
        }
    }

    /// <summary>  
    /// This method drops a Dynamic connector master on  
    /// the page, then connects the shapes by gluing the Dynamic   
    /// connector to the PinX values of the 2-D shapes to create   
    /// dynamic glue.</summary>  
    /// <param name="shapeFrom">  
    /// Shape where the Dynamic connector begins.  
    /// </param>  
    /// <param name="shapeTo">  
    /// Shape where the Dynamic connector ends.  
    /// </param>  
    private void ConnectWithDynamicGlueAndConnector(Microsoft.Office.Interop.Visio.Page page, 
        Document stencil, Shape shapeFrom, Shape shapeTo)
    {
        // Create Visio Cells and Shape  
        Cell beginXCell;
        Cell endXCell;
        Shape connector;

        connector = page.Drop(stencil.Masters["Dynamic Connector"], 0, 0);

        // Connect the begin point.  
        beginXCell = connector.get_CellsSRC(
            (short)VisSectionIndices.visSectionObject,
            (short)VisRowIndices.visRowXForm1D,
            (short)VisCellIndices.vis1DBeginX);

        // Glue to  
        beginXCell.GlueTo(shapeFrom.get_CellsSRC(
            (short)VisSectionIndices.visSectionObject,
            (short)VisRowIndices.visRowXFormOut,
            (short)VisCellIndices.visXFormPinX));

        // Connect the end point.  
        endXCell = connector.get_CellsSRC(
            (short)VisSectionIndices.visSectionObject,
            (short)VisRowIndices.visRowXForm1D,
            (short)VisCellIndices.vis1DEndX);

        endXCell.GlueTo(shapeTo.get_CellsSRC(
            (short)VisSectionIndices.visSectionObject,
            (short)VisRowIndices.visRowXFormOut,
            (short)VisCellIndices.visXFormPinX));
    } 
}
