﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.DataAccess.Scorecard.Brand;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.Workflow;
using SCA.VAS.Internal.BaseClasses;
using SCA.VAS.Common.Utilities;
using System.Collections;

namespace SCA.VAS.Internal.Admin
{
    public partial class NonVasVendorUser_Edit : BaseUserPage
    {
        delegate void DeluserControlMethod();
        List<VendorContactExternalRoleType> roles;
        protected void Page_Load(object sender, EventArgs e)
        {
            DeluserControlMethod deluserControl = new DeluserControlMethod(SetInitialValue);

            vendorcontactexternal.CallDelegate = deluserControl;
        }


        public int VendorId
        {
            get
            {
                if (ViewState["VendorId"] != null)
                    return (int)ViewState["VendorId"];
                return 0;
            }
            set
            {
                ViewState["VendorId"] = value;
            }
        }
        public int SupplierId
        {
            get
            {
                if (ViewState["SupplierId"] != null)
                    return (int)ViewState["SupplierId"];
                return 0;
            }
            set
            {
                ViewState["SupplierId"] = value;
            }
        }
        protected void SetInitialValue()
        {
            roles = VendorContactExternalRoleType.GetEnumList().Cast<VendorContactExternalRoleType>().Where(r => r.Name.StartsWith("A & E")).ToList();
            BindGrid();
        }
    
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            VendorCollection vendors = VendorUtility.GetVendorCompanyFedId(ConstantUtility.SUPPLIER_DATASOURCE_NAME, txtFedId.Text);
             

            foreach (Vendor vendor in vendors)
            {
                VendorId = vendor.Id;
                SupplierId = vendor.CurrentSupplierId;
                SetInitialValue();
            }
        }
        private void BindGrid()
        {
            //Vendor vendor = VendorUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, VendorId);
            //VendorId = vendor.Id;
            VendorContactExternalCollection contacts = VendorContactExternalUtility.FindByCriteria(
                ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                VendorContactExternalManager.FIND_CONTACT_BY_VENDOR,
                new object[] { VendorId });
            ViewState["ContactCount"] = (contacts == null) ? 0 : contacts.Count;
            contactGrid.DataSource = contacts;
            contactGrid.DataBind();

            PageBase.SetSystemControlPermission(this.Page);
        }


        protected void BindItem(object o, DataGridItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                //HtmlGenericControl actionsSet = (HtmlGenericControl)e.Item.FindControl("actionsSet");
                //HtmlGenericControl actionsMenuSet = (HtmlGenericControl)e.Item.FindControl("actionsMenuSet");
                //actionsSet.Attributes.Add("onmouseover", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');getElement('" + actionsMenuSet.ClientID + "').style.width=(this.offsetWidth-2)+'px';this.className='actionsSet_Over';");
                //actionsSet.Attributes.Add("onmouseout", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');this.className='actionsSet_Up';");

                VendorContactExternal contact = (VendorContactExternal)e.Item.DataItem;

                LinkButton tempDelete = (LinkButton)e.Item.FindControl("ContactDeleteButton");
                ImageButton deleteButton = (ImageButton)(e.Item.FindControl("deleteButton"));
                deleteButton.Attributes.Add("onclick", "return confirm('Are you sure you want to delete " + contact.Name.Replace("'", "\\'") + "?');");
            }

            if (e.Item.DataItem is VendorContactExternal)
            {
                var _contact = e.Item.DataItem as VendorContactExternal;

                var _finance = e.Item.FindControl("aefinanceIcon");
                var _technicial = e.Item.FindControl("aetechnicianIcon");
                var _principal = e.Item.FindControl("aeprincipalIcon");

                if (_contact != null && (_finance != null && _technicial != null && _principal != null))
                {
                    var _roles = _contact.Roles.OfType<VendorContactExternalRole>();

                    _principal.Visible = _roles.Any(r => r.VendorContactExternalRoleId == roles.Find(x => x.Name.EndsWith("Principal")).Id);
                    _finance.Visible = _roles.Any(r => r.VendorContactExternalRoleId == roles.Find(x => x.Name.EndsWith("Financial")).Id);
                    _technicial.Visible = _roles.Any(r => r.VendorContactExternalRoleId == roles.Find(x => x.Name.EndsWith("Technical")).Id);
                }

            }
            
        }

        protected void ItemCommand(object sender, DataGridCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                int id = (int)contactGrid.DataKeys[e.Item.ItemIndex];

                //Azure Deactivation.
                if (!UserProvider.Deactivate(id).IsError)
                {
                    VendorContactExternalUtility.Delete(ConstantUtility.SUPPLIER_DATASOURCE_NAME, id);
                }

                SetInitialValue();
                //OnUpdateContactCount(e);
            }
            else if (e.CommandName == "Edit")
            {
                int id = (int)contactGrid.DataKeys[e.Item.ItemIndex];
                VendorContactExternal VendorContactExternal = VendorContactExternalUtility.Get(
                    ConstantUtility.SUPPLIER_DATASOURCE_NAME, id);
                vendorcontactexternal.SetInitialValue(VendorContactExternal, VendorContactExternal.VendorId, SupplierId);
            }
 
            else if (e.CommandName == "ResetPassword")
            {
                int id = (int)contactGrid.DataKeys[e.Item.ItemIndex];
                VendorContactExternal VendorContactExternal = VendorContactExternalUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, id);
                VendorContactExternal.Password = PasswordUtility.Generate(ConstantUtility.PASSWORD_LENGTH);
               // VendorContactExternalUtility.ChangePassword(ConstantUtility.SUPPLIER_DATASOURCE_NAME, VendorContactExternal.Id, VendorContactExternal.Password);
               // CommonUtility.SendEmail("VENDOR_PASSWORD_RESET", new object[] { VendorContactExternal }, "Supplier", SupplierId);

                SetInitialValue();
            }

            else if (e.CommandName == "PasswordReminder")
            {
                int id = (int)contactGrid.DataKeys[e.Item.ItemIndex];
                VendorContactExternal VendorContactExternal = VendorContactExternalUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, id);
                CommonUtility.SendEmail("VENDOR_PASSWORD_REMINDER", new object[] { VendorContactExternal }, "Admin", VendorContactExternal.Id);
            }

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            vendorcontactexternal.SetInitialValue(null, VendorId, SupplierId);
        }



    }
}