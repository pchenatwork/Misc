#region Reference
using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class UserRole_List : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            BindControl();
        }
    }

    protected void BindItem(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ImageButton localDelete = (ImageButton)e.Item.FindControl("deleteButton");
            localDelete.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this User Role?')");

            HyperLink localPermission = (HyperLink)e.Item.FindControl("permission");
            localPermission.NavigateUrl = "Role_Permission.aspx?Role=" + HttpUtility.UrlEncode(e.Item.DataItem.ToString());

            HyperLink localOutlook = (HyperLink)e.Item.FindControl("outlook");
            localOutlook.NavigateUrl = "Outlook_Permission.aspx?Role=" + HttpUtility.UrlEncode(e.Item.DataItem.ToString());

            if (e.Item.DataItem.ToString() == "Administrator")
            {
                localDelete.Visible = false;
                localPermission.Text = "Built in administrator account, <BR>can not change permission";
                localPermission.NavigateUrl = "";
            }
        }
    }

    protected void DeleteItem(object sender, DataGridCommandEventArgs e)
    {
        Label roleName = (Label)e.Item.FindControl("rolename");
        Roles.DeleteRole(roleName.Text);

        BindControl();
    }

    protected void addButton_Click(object sender, System.EventArgs e)
    {
        if (name.Text.Trim() != "" && !Roles.RoleExists(name.Text.Trim()))
        {
            Roles.CreateRole(name.Text.Trim());
            BindControl();
        }
        name.Text = "";
    }
    #endregion Web Event Handler

    #region Private Method
    private void BindControl()
    {
        Roles.ApplicationName = Membership.ApplicationName;
        string[] userRoles = Roles.GetAllRoles();

        if (userRoles.Length > 0)
        {
            userRoleDataList.DataSource = userRoles;
            userRoleDataList.DataBind();
            userRoleDataList.Visible = true;
        }
        else
        {
            userRoleDataList.Visible = false;
        }
    }
    #endregion Private Method

}
