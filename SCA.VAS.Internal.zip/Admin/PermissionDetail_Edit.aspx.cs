#region Reference
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;
using SCA.VAS.BusinessLogic.User.Utilities;
using SCA.VAS.BusinessLogic.User;
using SCA.VAS.ValueObjects.User;
#endregion Reference

public partial class Admin_PermissionDetail_Edit : PageBase_Initial
{
    #region Web Event Handler
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SetInitialValue();
        }
    }

    protected void saveButton_Click(object sender, EventArgs e)
    {
        int PermissionDetailId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        PermissionDetail permissionDetail = PermissionDetailUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
            PermissionDetailId);

        permissionDetail.MenuId = ConvertUtility.ConvertInt(pageList.SelectedValue);
        permissionDetail.Type = permissionType.SelectedValue;
        permissionDetail.ControlName = name.Text; ;
        permissionDetail.Description = desc.Text;

        PermissionDetailUtility.Update(ConstantUtility.USER_DATASOURCE_NAME, permissionDetail);

        Response.Redirect("Permission_Edit.aspx?id=" + permissionDetail.PermissionId);
    }

    #endregion Web Event Handler
 
    #region Public Method
    override public void SetInitialValue()
    {
        MenuCollection menus = MenuUtility.FindByCriteria(ConstantUtility.USER_DATASOURCE_NAME,
            MenuManager.FIND_MENU_BY_TYPE, new object[] { "" });
        pageList.DataSource = menus;
        pageList.DataBind();

        int PermissionDetailId = ConvertUtility.ConvertInt(Request.QueryString["Id"]);
        PermissionDetail permissionDetail = PermissionDetailUtility.Get(ConstantUtility.USER_DATASOURCE_NAME,
            PermissionDetailId);

        if (permissionDetail != null)
        {
            pageList.SelectedIndex = pageList.Items.IndexOf(
                pageList.Items.FindByValue(permissionDetail.MenuId.ToString()));
            permissionType.SelectedIndex = permissionType.Items.IndexOf(
                permissionType.Items.FindByValue(permissionDetail.Type));

            name.Text = permissionDetail.ControlName;
            desc.Text = permissionDetail.Description;
        }
    }
    #endregion Public Method
}
