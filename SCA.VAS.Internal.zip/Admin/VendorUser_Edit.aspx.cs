﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.DataAccess.Scorecard.Brand;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.Workflow;
using SCA.VAS.Internal.BaseClasses;
using SCA.VAS.Common.Utilities;


namespace SCA.VAS.Internal.Admin
{
    public partial class VendorUser_Edit : BaseUserPage
    {
        delegate void DeluserControlMethod();
        protected void Page_Load(object sender, EventArgs e)
        {
            DeluserControlMethod deluserControl = new DeluserControlMethod(SetInitialValue);
            vendorcontacts.CallDelegate = deluserControl;
        }


        public int VendorId
        {
            get
            {
                if (ViewState["VendorId"] != null)
                    return (int)ViewState["VendorId"];
                return 0;
            }
            set
            {
                ViewState["VendorId"] = value;
            }
        }
        public int SupplierId
        {
            get
            {
                if (ViewState["SupplierId"] != null)
                    return (int)ViewState["SupplierId"];
                return 0;
            }
            set
            {
                ViewState["SupplierId"] = value;
            }
        }
        protected void SetInitialValue()
        {
            BindGrid();
        }
    
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            VendorCollection vendors = VendorUtility.GetVendorCompanyFedId(ConstantUtility.SUPPLIER_DATASOURCE_NAME, txtFedId.Text);
             

            foreach (Vendor vendor in vendors)
            {
                VendorId = vendor.Id;
                SupplierId = vendor.CurrentSupplierId;
                SetInitialValue();
            }
        }
        private void BindGrid()
        {
            //Vendor vendor = VendorUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, VendorId);
            //VendorId = vendor.Id;
            VendorContactCollection contacts = VendorContactUtility.FindByCriteria(
                ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                VendorContactManager.FIND_CONTACT_BY_VENDOR,
                new object[] { VendorId });
            ViewState["ContactCount"] = (contacts == null) ? 0 : contacts.Count;
            contactGrid.DataSource = contacts;
            contactGrid.DataBind();

            PageBase.SetSystemControlPermission(this.Page);
        }


        protected void BindItem(object o, DataGridItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                //HtmlGenericControl actionsSet = (HtmlGenericControl)e.Item.FindControl("actionsSet");
                //HtmlGenericControl actionsMenuSet = (HtmlGenericControl)e.Item.FindControl("actionsMenuSet");
                //actionsSet.Attributes.Add("onmouseover", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');getElement('" + actionsMenuSet.ClientID + "').style.width=(this.offsetWidth-2)+'px';this.className='actionsSet_Over';");
                //actionsSet.Attributes.Add("onmouseout", "toggleElementDisplay('" + actionsMenuSet.ClientID + "','');this.className='actionsSet_Up';");

                VendorContact contact = (VendorContact)e.Item.DataItem;

                LinkButton tempDelete = (LinkButton)e.Item.FindControl("ContactDeleteButton");
                ImageButton deleteButton = (ImageButton)(e.Item.FindControl("deleteButton"));
                deleteButton.Attributes.Add("onclick", "return confirm('Are you sure you want to delete " + contact.Name.Replace("'", "\\'") + "?');");
                deleteButton.Enabled = ((int)ViewState["ContactCount"] > 1) && contact.ContactType != SupplierContact.PRIMARY_CONTACT;

                //hide delete button for primary contact
                if (contact.ContactType == "Primary")
                    deleteButton.Visible = false;

                LinkButton localReminderLink = (LinkButton)e.Item.FindControl("passwordReminderLink");

                localReminderLink.Visible = (contact.Migrated == 0 && !contact.UserName.Empty());
            }

            
        }

        protected void ItemCommand(object sender, DataGridCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                int id = (int)contactGrid.DataKeys[e.Item.ItemIndex];

                //Azure Deactivation.
                if (!UserProvider.Deactivate(id).IsError)
                {
                    VendorContactUtility.Delete(ConstantUtility.SUPPLIER_DATASOURCE_NAME, id);
                }

                SetInitialValue();
                //OnUpdateContactCount(e);
            }
            else if (e.CommandName == "Edit")
            {
                Button btn = (Button)vendorcontacts.FindControl("btnReset");
                btn.Visible = true;
                int id = (int)contactGrid.DataKeys[e.Item.ItemIndex];
                VendorContact vendorContact = VendorContactUtility.Get(
                    ConstantUtility.SUPPLIER_DATASOURCE_NAME, id);

                if ((vendorContact.Email == vendorContact.UserName) && (vendorContact.AzureObjectId != null) && (vendorContact.Migrated == 1))
                {
                    btn.Visible = false;
                }

                vendorcontacts.SetInitialValue(vendorContact, vendorContact.VendorId, SupplierId);
            }
 
            else if (e.CommandName == "ResetPassword")
            {
                int id = (int)contactGrid.DataKeys[e.Item.ItemIndex];
                VendorContact vendorContact = VendorContactUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, id);
                vendorContact.Password = PasswordUtility.Generate(ConstantUtility.PASSWORD_LENGTH);
                VendorContactUtility.ChangePassword(ConstantUtility.SUPPLIER_DATASOURCE_NAME, vendorContact.Id, vendorContact.Password);
                CommonUtility.SendEmail("VENDOR_PASSWORD_RESET", new object[] { vendorContact }, "Supplier", SupplierId);

                SetInitialValue();
            }

            else if (e.CommandName == "PasswordReminder")
            {
                int id = (int)contactGrid.DataKeys[e.Item.ItemIndex];
                VendorContact vendorContact = VendorContactUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, id);
                CommonUtility.SendEmail("VENDOR_PASSWORD_REMINDER", new object[] { vendorContact }, "Admin", vendorContact.Id);
            }

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            vendorcontacts.SetInitialValue(null, VendorId, SupplierId);
        }



    }
}