﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Supplier;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Supplier;
using SCA.VAS.Workflow;
using SCA.VAS.Internal.BaseClasses;

namespace SCA.VAS.Internal.Admin
{
    public partial class Add_NonVasVendor_User : BaseUserPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                contactTypeList.Attributes.Add("onclick", "processContactTypeList();");
                SetInitialValue(null);
            }
        }



        #region Public Method
        public void SetInitialValue(VendorContactExternal contact)
        {
         
            string country = "USA";
            phone.Attributes.Add("onkeyup", "PhoneFormat(this, this.form, '" + country + "');");
            phone.Attributes.Add("onclick", "PhoneFormat(this, this.form, '" + country + "');");
            cell.Attributes.Add("onkeyup", "PhoneFormat(this, this.form, '" + country + "');");
            cell.Attributes.Add("onclick", "PhoneFormat(this, this.form, '" + country + "');");

            contactTypeList.Enabled = true;
            //contactTypeList.DataSource = CommonUtility.GetSettings("ContactType.xml");
            contactTypeList.DataSource = VendorContactExternalRoleType.GetEnumList();
            contactTypeList.DataBind();

            string currenturl = Request.Url.ToString();
            int location = currenturl.LastIndexOf("/");
            currenturl = currenturl.Substring(0, location + 1);

            btnSubmit.Text = "Add Contact";

            // userName.Attributes.Add("onblur", "validate_username('', this.value,'" + currenturl + "', document.getElementById('" + userName.ClientID + "'));");
            //contactTypeList.SelectedIndex = 0;
            title.SelectedIndex = 0;
            name.Text = "";
            email.Text = "";
            businessTitle.Text = "";
            extension.Text = "";
            cell.Text = "";
            phone.Text = "";
            primaryPhoneType.SelectedIndex = 0;
            secondaryPhoneType.SelectedIndex = 0;
            //userName.Text = "";   

        }
        #endregion

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid)
                return;
            VendorContactExternal VendorContactExternal = new VendorContactExternal();
            
            VendorContactExternal = VendorContactExternalUtility.CreateObject();
           
            VendorContactExternal.VendorId = Int32.Parse(txtvendorId.Value);

            VendorContactExternalCollection contacts = VendorContactExternalUtility.FindByCriteria(
                ConstantUtility.SUPPLIER_DATASOURCE_NAME,
                VendorContactExternalManager.FIND_CONTACT_BY_VENDOR,
                new object[] { Int32.Parse(txtvendorId.Value) });
            string vendorroles = string.Empty;
            if (contacts != null)
            {
                foreach (VendorContactExternal contact in contacts)
                {
                    vendorroles = contact.Roles.Cast<VendorContactExternalRole>().Aggregate(vendorroles, (current, role) => current + role.VendorContactExternalRoleId.ToString());
                }
            }
          
          
            bool isces = false;
            bool isAandE = false;
            foreach (ListItem li in contactTypeList.Items)
            {
                if (!li.Selected) continue;
                if (li.Value != "1") //Not CES 
                {
                    if (vendorroles.Contains(li.Value))
                    {
                        errmsgcreate.Visible = true;
                        errmsgcreate.Text = "Duplicate Role Selected.";
                        return;
                    }
                }
                //CES Account
                if (li.Value == "1" || li.Value == "2")
                {
                    isces = true;                        
                }
                //A & E Account    
                else if (li.Text.Contains("A & E"))
                    isAandE = true;
            }

            if (contactTypeList.SelectedIndex < 0)
                return;

            VendorContactExternal.ContactType = contactTypeList.Items[contactTypeList.SelectedIndex].Text;
            VendorContactExternal.Department = title.SelectedValue;
            VendorContactExternal.Name = name.Text;
            VendorContactExternal.Title = businessTitle.Text;
            VendorContactExternal.Phone = phone.Text;
            VendorContactExternal.Extension = extension.Text;
            VendorContactExternal.Fax = cell.Text;
            VendorContactExternal.Email = email.Text;
            VendorContactExternal.FirstName = primaryPhoneType.SelectedValue;
            VendorContactExternal.LastName = secondaryPhoneType.SelectedValue;
            VendorContactExternal.ChangeUser = ((PageBase)Page).ChangeUser;

            if (VendorContactExternal.Id > 0)
            {

                VendorContactExternalUtility.Update(ConstantUtility.SUPPLIER_DATASOURCE_NAME, VendorContactExternal);
            }
            else
            {
               //add error handling for azure 
                try
                {
                    // When CES/A & E is selected, dont create Azure Account, store password
                    //if (contactTypeList.Items[2].Selected)
               
                        //generate system password for CES user, username is their email address
                        VendorContactExternal.UserName = email.Text;
                        VendorContactExternal.Password = System.Web.Security.Membership.GeneratePassword(8, 0);

                        if (VendorContactExternalUtility.Create(ConstantUtility.SUPPLIER_DATASOURCE_NAME, VendorContactExternal))
                        {
                            if (isces)
                            {
                                VendorContactExternal = VendorContactExternalUtility.Get(ConstantUtility.SUPPLIER_DATASOURCE_NAME, VendorContactExternal.Id);
                                CommonUtility.SendEmail("VENDOR_ADD_CONTACT_PW_CES", new object[] { VendorContactExternal }, "Supplier", SupplierId);
                            }
                            //refreshing the page, show alert upon user creation
                            Response.Write("<script language='javascript'>window.alert('User Created Successfully');window.location='Add_NonVasVendor_User.aspx';</script>");
                        }
                        else { errmsgcreate.Visible = true; }                                 

                }
                catch (Exception ex)
                {
                    errmsgcreate.Visible = true;
                }
                
            }

            if (VendorContactExternal != null)
            {
                VendorContactExternalRoleCollection VendorContactExternalRoles = new VendorContactExternalRoleCollection();
                foreach (ListItem li in contactTypeList.Items)
                {
                    if (li.Selected)
                    {
                        VendorContactExternalRole VendorContactExternalRole = VendorContactExternalRoleUtility.CreateObject();
                        VendorContactExternalRole.VendorContactExternalId = VendorContactExternal.Id;
                        VendorContactExternalRole.VendorContactExternalRoleId = ConvertUtility.ConvertInt(li.Value);
                        VendorContactExternalRoles.Add(VendorContactExternalRole);
                    }
                }
                VendorContactExternalRoleUtility.UpdateCollection(ConstantUtility.SUPPLIER_DATASOURCE_NAME, VendorContactExternal.Id, VendorContactExternalRoles);
            }
            //ControlBase_Initial contacts = (ControlBase_Initial)this.Parent.Parent;
            //contacts.SetInitialValue();
            //OnUpdateContactCount(e);

        }

        public event EventHandler UpdateContactCount;

        protected void OnUpdateContactCount(EventArgs e)
        {
            if (UpdateContactCount != null)
            {
                UpdateContactCount(this, e);
            }
        }
    }
}