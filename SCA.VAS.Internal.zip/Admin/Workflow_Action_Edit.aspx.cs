#region Reference
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

using SCA.VAS.Workflow;
using SCA.VAS.Common.Utilities;

using SCA.VAS.BusinessLogic.Workflow.Utilities;
using SCA.VAS.BusinessLogic.Workflow;
using SCA.VAS.ValueObjects.Workflow;

using SCA.VAS.BusinessLogic.Common.Utilities;
using SCA.VAS.BusinessLogic.Common;
using SCA.VAS.ValueObjects.Common;

using UNLV.IAP.WebControls;
#endregion Reference

static class Extensions
{
    /// <summary>
    /// Convert ArrayList to List.
    /// </summary>
    public static List<T> ToList<T>(this ArrayList arrayList)
    {
        List<T> list = new List<T>(arrayList.Count);
        foreach (T instance in arrayList)
        {
            list.Add(instance);
        }
        return list;
    }
}


public partial class Workflow_Action_Edit : PageBase
{
    #region Web Event Handler
    protected void Page_Load(object sender, System.EventArgs e)
    {
        if (!IsPostBack)
        {
            int nodeId = ConvertUtility.ConvertInt(Request.QueryString["nid"]);
            WorkflowNode workflowNode = null;
            if (nodeId != 0)
            {
                workflowNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, nodeId);
                ViewState["wid"] = workflowNode.WorkflowId;
            }
            else
            {
                ViewState["wid"] = Request.QueryString["Id"];
            }

            int workflowId = ConvertUtility.ConvertInt(ViewState["wid"].ToString());
            WorkflowList workflowList = WorkflowListUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowId);
            ViewState["Type"] = workflowList.Type;

            switch (workflowList.Type)
            {
                case ConstantUtility.WORKFLOW_RFP_JM_SUBMISSION:
                    var rfpActionEnums = RFPAction.GetEnumList().ToList<RFPAction>();
                    systemStatus.DataSource = rfpActionEnums.OrderBy(x => x.Name).ToArray();
                    break;
                case ConstantUtility.WORKFLOW_RFP_JM_THROUGH:
                    var rfpThroughActionEnums = RFPAction.GetEnumList().ToList<RFPAction>();
                    systemStatus.DataSource = rfpThroughActionEnums.OrderBy(x => x.Name).ToArray();
                    break;
                case ConstantUtility.WORKFLOW_QUALIFICATION:
                case ConstantUtility.WORKFLOW_CERTIFICATION:
                case ConstantUtility.WORKFLOW_OIG_QUALIFICATION:
                case ConstantUtility.WORKFLOW_AMENDED_TRADE_CODE:
                case ConstantUtility.WORKFLOW_OVER_1MM:
                case ConstantUtility.WORKFLOW_CHANGE_IN_APPLICATION:
                case ConstantUtility.WORKFLOW_MENTOR:
                    var supplierActionEnums= SupplierAction.GetEnumList().ToList<SupplierAction>();
                    systemStatus.DataSource = supplierActionEnums.OrderBy(x => x.Name).ToArray();
                    break;
                case ConstantUtility.WORKFLOW_PREQUAL_LIMITEDLIST:
                case ConstantUtility.WORKFLOW_MENTOR_LIMITEDLIST:
                case ConstantUtility.WORKFLOW_MENTORGRADUATE_LIMITEDLIST:
                    var rfdProjectActionEnums = RfdProjectAction.GetEnumList().ToList<RfdProjectAction>();
                    systemStatus.DataSource = rfdProjectActionEnums.OrderBy(x => x.Name).ToArray();
                    break;
                case ConstantUtility.WORKFLOW_SUPPLIER_LIMITEDLIST:
                    var rfdSupplierActionEnums = RfdSupplierAction.GetEnumList().ToList<RfdSupplierAction>();
                    systemStatus.DataSource = rfdSupplierActionEnums.OrderBy(x => x.Name).ToArray();
                    break;
                case ConstantUtility.WORKFLOW_SUBCONTRACTOR:
                    var subcontractorActionEnums = SubcontractorAction.GetEnumList().ToList<SubcontractorAction>();
                    systemStatus.DataSource = subcontractorActionEnums.OrderBy(x => x.Name).ToArray();
                    break;
                case ConstantUtility.WORKFLOW_CAPACITY_EVALUATION:
                case ConstantUtility.WORKFLOW_CIP_EVALUATION:
                case ConstantUtility.WORKFLOW_CCFU_EVALUATION:
                case ConstantUtility.WORKFLOW_PROJECT_CONTRACT_EVALUATION:
                case ConstantUtility.WORKFLOW_MENTORA_EVALUATION:
                case ConstantUtility.WORKFLOW_MENTORA_CONTRACT_EVALUATION:
                case ConstantUtility.WORKFLOW_MENTORB_EVALUATION:
                case ConstantUtility.WORKFLOW_IEH_EVALUATION:
                case ConstantUtility.WORKFLOW_IEH_CONTRACT_EVALUATION:
                    var scorecardActionEnums = ScorecardAction.GetEnumList().ToList<ScorecardAction>();
                    systemStatus.DataSource = scorecardActionEnums.OrderBy(x => x.Name).ToArray();
                    break;
                case ConstantUtility.WORKFLOW_EVALUATION:
                    var evaluationActionEnums = EvaluationAction.GetEnumList().ToList<EvaluationAction>();
                    systemStatus.DataSource = evaluationActionEnums.OrderBy(x => x.Name).ToArray();
                    break;
                case ConstantUtility.WORKFLOW_BID_AWARD_GENERAL:
                case ConstantUtility.WORKFLOW_RFI_SUBMISSION_PROCESSING:
                case ConstantUtility.WORKFLOW_BID_BREAKDOWN_ANALYSIS:
                case ConstantUtility.WORKFLOW_ADDENDUM:
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING:
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_BIDBOND_REVIEW:
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_FINANCIAL_REVIEW:
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_MENTOR:
                case ConstantUtility.WORKFLOW_ROUTING_OIG:
                case ConstantUtility.WORKFLOW_ROUTING_FINANCE:
                case ConstantUtility.WORKFLOW_ROUTING_CQU:
                case ConstantUtility.WORKFLOW_ROUTING_VPCM:
                case ConstantUtility.WORKFLOW_ROUTING_BDD:
                case ConstantUtility.WORKFLOW_ROUTING_ADMIN:
                case ConstantUtility.WORKFLOW_BID_MENTOR:
                case ConstantUtility.WORKFLOW_BID_MENTOR_FINANCE:
                case ConstantUtility.WORKFLOW_RS1_VETTING:
                    var projectActionEnums = ProjectAction.GetEnumList().ToList<ProjectAction>();
                    systemStatus.DataSource = projectActionEnums.OrderBy(x => x.Name).ToArray();
                    break;
                case ConstantUtility.WORKFLOW_BID_DOCUMENT_REPRODUCTION:
                case ConstantUtility.WORKFLOW_BID_REPRODUCTION_ORDER:
                case ConstantUtility.WORKFLOW_BID_REPRODUCTION_ORDER_SUPPLIER:
                    var projectOrderActionEnums = ProjectOrderAction.GetEnumList().ToList<ProjectOrderAction>();
                    systemStatus.DataSource = projectOrderActionEnums.OrderBy(x => x.Name).ToArray();
                    break;
                case ConstantUtility.WORKFLOW_SUP:
                case ConstantUtility.WORKFLOW_SUP_MONITORING:
                    var planActionEnums = PlanAction.GetEnumList().ToList<PlanAction>();
                    systemStatus.DataSource = planActionEnums.OrderBy(x => x.Name).ToArray();
                    break;
                case ConstantUtility.WORKFLOW_RS1_SUBCONTRACTOR:
                case ConstantUtility.WORKFLOW_HB_RS1_SUBCONTRACTOR:
                    var rs1SubcontractorActionEnums = RS1SubcontractorAction.GetEnumList().ToList<RS1SubcontractorAction>(); ;
                    systemStatus.DataSource = rs1SubcontractorActionEnums.OrderBy(x => x.Name).ToArray();
                    break;
                ///Hardbid//
                case ConstantUtility.WORKFLOW_HB_GENERAL:
                case ConstantUtility.WORKFLOW_HB_RFI_SUBMISSION_PROCESSING:                
                case ConstantUtility.WORKFLOW_HB_ADDENDUM:
                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_PRIME:
                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_BIDBOND:
                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_FINANCIAL:
                case ConstantUtility.WORKFLOW_HB_ROUTING_PACKAGE:
                case ConstantUtility.WORKFLOW_HB_ROUTING_OIG:
                case ConstantUtility.WORKFLOW_HB_ROUTING_FINANCE:
                case ConstantUtility.WORKFLOW_HB_ROUTING_CQU:
                case ConstantUtility.WORKFLOW_HB_ROUTING_VPCM:
                case ConstantUtility.WORKFLOW_HB_ROUTING_VPIEH:
                case ConstantUtility.WORKFLOW_HB_ROUTING_VPAE:
                case ConstantUtility.WORKFLOW_HB_RS1_VETTING:
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE:
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_LEGAL:
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_VPCP:
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_EVP:
                    var hbprojectActionEnums = HBProjectAction.GetEnumList().ToList<HBProjectAction>();
                    systemStatus.DataSource = hbprojectActionEnums.OrderBy(x => x.Name).ToArray();
                    break;
                case ConstantUtility.WORKFLOW_HB_BAFO:
                    var hbBafoActionEnums = HBProjectAction.GetEnumList().ToList<HBProjectAction>();
                    systemStatus.DataSource = hbBafoActionEnums.OrderBy(x => x.Name).ToArray();
                    break; 
                case ConstantUtility.WORKFLOW_HB_BID_DOCUMENT_REPRODUCTION:                
                    var hbprojectOrderActionEnums = HBProjectOrderAction.GetEnumList().ToList<HBProjectOrderAction>(); //need to put HBHookup here as HBProjectAction
                    systemStatus.DataSource = hbprojectOrderActionEnums.OrderBy(x => x.Name).ToArray();
                    break;               
            }
            systemStatus.DataBind();
            systemStatus.Items.Insert(0, new ListItem("Select One", ""));

            switch (workflowList.Type)
            {
                case ConstantUtility.WORKFLOW_SUBCONTRACTOR:
                    swb1.LoadOperatorListsFromXml(Server.MapPath("~/QEngine/Subcontractor/operatorLists.config"));
                    swb1.LoadValueEntryDivsFromXml(Server.MapPath("~/QEngine/Subcontractor/valueEntryDivs.config"));
                    swb1.LoadFieldsFromXml(Server.MapPath("~/QEngine/Subcontractor/fields.config"));
                    break;
                case ConstantUtility.WORKFLOW_PREQUAL_LIMITEDLIST:
                case ConstantUtility.WORKFLOW_MENTOR_LIMITEDLIST:
                case ConstantUtility.WORKFLOW_MENTORGRADUATE_LIMITEDLIST:
                    swb1.LoadOperatorListsFromXml(Server.MapPath("~/QEngine/LimitedList/operatorLists.config"));
                    swb1.LoadValueEntryDivsFromXml(Server.MapPath("~/QEngine/LimitedList/valueEntryDivs.config"));
                    swb1.LoadFieldsFromXml(Server.MapPath("~/QEngine/LimitedList/fields.config"));
                    break;
                //PS 02/28/2013
                case ConstantUtility.WORKFLOW_SUPPLIER_LIMITEDLIST:
                    swb1.LoadOperatorListsFromXml(Server.MapPath("~/QEngine/LimitedListSupplier/operatorLists.config"));
                    swb1.LoadValueEntryDivsFromXml(Server.MapPath("~/QEngine/LimitedListSupplier/valueEntryDivs.config"));
                    swb1.LoadFieldsFromXml(Server.MapPath("~/QEngine/LimitedListSupplier/fields.config"));
                    break;
                    
                case ConstantUtility.WORKFLOW_CAPACITY_EVALUATION:
                case ConstantUtility.WORKFLOW_CIP_EVALUATION:
                case ConstantUtility.WORKFLOW_CCFU_EVALUATION:
                case ConstantUtility.WORKFLOW_PROJECT_CONTRACT_EVALUATION:
                case ConstantUtility.WORKFLOW_MENTORA_EVALUATION:
                case ConstantUtility.WORKFLOW_MENTORA_CONTRACT_EVALUATION:
                case ConstantUtility.WORKFLOW_MENTORB_EVALUATION:
                case ConstantUtility.WORKFLOW_IEH_EVALUATION:
                case ConstantUtility.WORKFLOW_IEH_CONTRACT_EVALUATION:
                    swb1.LoadOperatorListsFromXml(Server.MapPath("~/QEngine/Scorecard/operatorLists.config"));
                    swb1.LoadValueEntryDivsFromXml(Server.MapPath("~/QEngine/Scorecard/valueEntryDivs.config"));
                    swb1.LoadFieldsFromXml(Server.MapPath("~/QEngine/Scorecard/fields.config"));
                    break;
                case ConstantUtility.WORKFLOW_EVALUATION:
                    swb1.LoadOperatorListsFromXml(Server.MapPath("~/QEngine/Evaluation/operatorLists.config"));
                    swb1.LoadValueEntryDivsFromXml(Server.MapPath("~/QEngine/Evaluation/valueEntryDivs.config"));
                    swb1.LoadFieldsFromXml(Server.MapPath("~/QEngine/Evaluation/fields.config"));
                    break;
                case ConstantUtility.WORKFLOW_SUP:
                    swb1.LoadOperatorListsFromXml(Server.MapPath("~/QEngine/SUP/operatorLists.config"));
                    swb1.LoadValueEntryDivsFromXml(Server.MapPath("~/QEngine/SUP/valueEntryDivs.config"));
                    swb1.LoadFieldsFromXml(Server.MapPath("~/QEngine/SUP/fields.config"));
                    break;
                case ConstantUtility.WORKFLOW_BID_AWARD_GENERAL:
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING:
                case ConstantUtility.WORKFLOW_BID_BREAKDOWN_ANALYSIS:
                case ConstantUtility.WORKFLOW_BID_MENTOR:
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_FINANCIAL_REVIEW:
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_BIDBOND_REVIEW:
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_MENTOR:
                    swb1.LoadOperatorListsFromXml(Server.MapPath("~/QEngine/Rfc/operatorLists.config"));
                    swb1.LoadValueEntryDivsFromXml(Server.MapPath("~/QEngine/Rfc/valueEntryDivs.config"));
                    swb1.LoadFieldsFromXml(Server.MapPath("~/QEngine/Rfc/fields.config"));
                    break;
                
                //HARDBID//
                case ConstantUtility.WORKFLOW_HB_GENERAL:
                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_PRIME:
                case ConstantUtility.WORKFLOW_HB_BAFO:
                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_FINANCIAL:
                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_BIDBOND:
                case ConstantUtility.WORKFLOW_HB_ROUTING_PACKAGE:
                case ConstantUtility.WORKFLOW_HB_ROUTING_OIG:
                case ConstantUtility.WORKFLOW_HB_ROUTING_FINANCE:
                case ConstantUtility.WORKFLOW_HB_ROUTING_CQU:
                case ConstantUtility.WORKFLOW_HB_ROUTING_VPCM:
                case ConstantUtility.WORKFLOW_HB_RS1_VETTING:
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE:
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_LEGAL:
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_VPCP:
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_EVP:
                    swb1.LoadOperatorListsFromXml(Server.MapPath("~/QEngine/Hardbid/operatorLists.config"));
                    swb1.LoadValueEntryDivsFromXml(Server.MapPath("~/QEngine/Hardbid/valueEntryDivs.config"));
                    swb1.LoadFieldsFromXml(Server.MapPath("~/QEngine/Hardbid/fields.config"));
                    break;




                default:
                    swb1.LoadOperatorListsFromXml(Server.MapPath("~/QEngine/Supplier/operatorLists.config"));
                    swb1.LoadValueEntryDivsFromXml(Server.MapPath("~/QEngine/Supplier/valueEntryDivs.config"));
                    swb1.LoadFieldsFromXml(Server.MapPath("~/QEngine/Supplier/fields.config"));
                    break;
            }

            if (workflowNode != null)
            {
                nodeName.Text = workflowNode.Name;
                desc.Text = workflowNode.Description;
                systemStatus.SelectedIndex = systemStatus.Items.IndexOf(systemStatus.Items.FindByValue(workflowNode.Action6));
                //actiondesc.Text = workflowNode.Action6;

                switch (workflowNode.Action1)
                {
                    case "Owner":
                        approve1.Checked = true;
                        break;
                    case "Sequence":
                        approve2.Checked = true;
                        break;
                    case "All":
                        approve3.Checked = true;
                        break;
                    case "One":
                        approve4.Checked = true;
                        break;
                    case "Majority":
                        approve5.Checked = true;
                        break;
                    case "Count":
                        approve6.Checked = true;
                        approveKnt6.Text = workflowNode.Action2;
                        break;
                    case "Timer":
                        approve7.Checked = true;
                        approveKnt7.Text = workflowNode.Action2;
                        break;
                }
            }

            EmailMessageCollection emails = EmailMessageUtility.FindByCriteria(
               ConstantUtility.COMMON_DATASOURCE_NAME,
               EmailMessageManager.FIND_EMAILMESSAGE_BY_TYPE,
               new object[] { 0, 0, "Name", "ASC", workflowList.EmailType, "" });
            emailList.DataSource = emails;
            emailList.DataBind();
            emailList.Items.Insert(0, new ListItem("Select One", ""));

            ConditionBind();
            ActionBind();

            if (workflowList != null)
            {
                name.Text = workflowList.Name;
                WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
                    ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                    WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
                    new object[] { workflowId, "UserStepId", "ASC" });

                WorkflowNodeCollection workflowNodesBind = new WorkflowNodeCollection();
                if (workflowNodes != null)
                {
                    foreach (WorkflowNode wn in workflowNodes)
                    {
                        //if (wn.Id == workflowNode.NodeFromId)
                        //    fromNode.Text = wn.Name;
                        //if (wn.Id == workflowNode.NodeToId)
                        //    toNode.Text = wn.Name;
                        if (wn.Type != 1) workflowNodesBind.Add(wn);
                    }
                }

                //Bind status
                fromNode.DataSource = workflowNodesBind;
                fromNode.DataBind();

                toNode.DataSource = workflowNodesBind;
                toNode.DataBind();
                toNode.Items.Insert(0, new ListItem("No Change", ""));

                fromNode.SelectedIndex = fromNode.Items.IndexOf(fromNode.Items.FindByValue(
                    workflowNode.NodeFromId.ToString()));
                toNode.SelectedIndex = toNode.Items.IndexOf(toNode.Items.FindByValue(
                    workflowNode.NodeToId.ToString()));
                changeType.SelectedIndex = changeType.Items.IndexOf(changeType.Items.FindByValue(
                    workflowNode.TimeToSkip.ToString()));

                //Bind roles Permission
                string[] userRoles = Roles.GetAllRoles();
                if (userRoles != null)
                {
                    foreach (string roleName in userRoles)
                        userRoleList.Items.Add(new ListItem(roleName, roleName));
                }
                checkAllRoles.Attributes.Add("OnClick", "javascript:SelectRole();");

                if (workflowNode == null) return;

                if (workflowNode.IsPermCtrl == 0)
                {
                    checkAllRoles.Items[0].Selected = true;
                    Page.ClientScript.RegisterStartupScript(GetType(), "SelectRole", "javascript:SelectRole();", true);
                }
                else
                {
                    WorkflowNodeUserCollection workflowNodeUsers = WorkflowNodeUserUtility.FindByCriteria(
                        ConstantUtility.WORKFLOW_DATASOURCE_NAME,
                        WorkflowNodeUserManager.FIND_WORKFLOWNODEUSER_BY_NODE,
                        new object[] { nodeId });

                    foreach (ListItem li in this.userRoleList.Items)
                    {
                        if (workflowNodeUsers != null)
                        {
                            foreach (WorkflowNodeUser wu in workflowNodeUsers)
                            {
                                if (wu.RoleName == li.Text)
                                {
                                    li.Selected = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    protected void btnSubmit_Click(object sender, System.EventArgs e)
    {
        if (!this.Page.IsValid) return;

        int workflowId = ConvertUtility.ConvertInt(ViewState["wid"].ToString());
        WorkflowNodeCollection workflowNodes = WorkflowNodeUtility.FindByCriteria(
            ConstantUtility.WORKFLOW_DATASOURCE_NAME,
            WorkflowNodeManager.FIND_WORKFLOWNODE_BY_WORKFLOW,
            new object[] { workflowId, "UserStepId", "ASC" });

        int permissionFlag = 1;
        if (this.checkAllRoles.Items[0].Selected)
            permissionFlag = 0;

        // Add & Update a node
        int nodeId = ConvertUtility.ConvertInt(Request.QueryString["nid"]);
        WorkflowNode workflowNode = null;
        if (nodeId == 0)
        {
            workflowNode = WorkflowNodeUtility.CreateObject();
            workflowNode.WorkflowId = workflowId;
            workflowNode.Type = 2;
            workflowNode.ConditionId = 1;
        }
        else
        {
            workflowNode = WorkflowNodeUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, nodeId);
        }
        workflowNode.Name = nodeName.Text;
        workflowNode.Description = desc.Text;
        workflowNode.Action6 = systemStatus.SelectedValue;
        workflowNode.IsPermCtrl = permissionFlag;
        workflowNode.NodeFromId = ConvertUtility.ConvertInt(fromNode.SelectedValue);
        workflowNode.NodeToId = ConvertUtility.ConvertInt(toNode.SelectedValue);
        workflowNode.TimeToSkip = ConvertUtility.ConvertInt(changeType.SelectedValue);

        if (approve1.Checked)
            workflowNode.Action1 = "Owner";
        else if (approve2.Checked)
            workflowNode.Action1 = "Sequence";
        else if (approve3.Checked)
            workflowNode.Action1 = "All";
        else if (approve4.Checked)
            workflowNode.Action1 = "One";
        else if (approve5.Checked)
            workflowNode.Action1 = "Majority";
        else if (approve6.Checked)
        {
            workflowNode.Action1 = "Count";
            workflowNode.Action2 = approveKnt6.Text;
        }
        else if (approve7.Checked)
        {
            workflowNode.Action1 = "Timer";
            workflowNode.Action2 = approveKnt7.Text;
        }

        if (nodeId == 0)
        {
            WorkflowNodeUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode);
            nodeId = workflowNode.Id;
        }
        else
        {
            WorkflowNodeUtility.Update(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowNode);
        }

        WorkflowNodeUserCollection workflowNodeUsers = WorkflowNodeUserUtility.FindByCriteria(
            ConstantUtility.WORKFLOW_DATASOURCE_NAME,
            WorkflowNodeUserManager.FIND_WORKFLOWNODEUSER_BY_NODE,
            new object[] { nodeId });

        //build Permission
        if (!checkAllRoles.Items[0].Selected)
        {
            foreach (ListItem li in this.userRoleList.Items)
            {
                int tempId = 0;
                if (workflowNodeUsers != null)
                {
                    foreach (WorkflowNodeUser wu in workflowNodeUsers)
                    {
                        if (wu.RoleName == li.Text)
                        {
                            tempId = wu.Id;
                        }
                    }
                }
                if (tempId == 0 && li.Selected)
                {
                    WorkflowNodeUser newRole = WorkflowNodeUserUtility.CreateObject();
                    newRole.WorkflowNodeId = nodeId;
                    newRole.Status = 1;
                    newRole.ApplicationName = Roles.ApplicationName;
                    newRole.RoleName = li.Text;

                    WorkflowNodeUserUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, newRole);
                }
                if (tempId != 0 && !li.Selected)
                {
                    WorkflowNodeUserUtility.Delete(ConstantUtility.WORKFLOW_DATASOURCE_NAME, tempId);
                }
            }
        }
        Response.Redirect("Workflow_Action.aspx?Id=" + workflowId.ToString());
    }

    protected void Action_BindItem(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.AlternatingItem ||
            e.Item.ItemType == ListItemType.Item)
        {
            Label localActionType = (Label)e.Item.FindControl("actionType");
            WorkflowAction localWorkflowAction = (WorkflowAction)e.Item.DataItem;

            if (actionType.Items.FindByValue(localWorkflowAction.Type.ToString()) != null)
                localActionType.Text = (actionType.Items.FindByValue(localWorkflowAction.Type.ToString())).Text;

            ImageButton localDelete = (ImageButton)e.Item.FindControl("deleteButton");
            localDelete.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this Action?')");
        }
    }

    protected void Action_DeleteItem(object sender, DataGridCommandEventArgs e)
    {
        int actionId = (int)actionList.DataKeys[e.Item.ItemIndex];
        WorkflowActionUtility.Delete(ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);

        ActionBind();
    }

    protected void Action_EditItem(object sender, DataGridCommandEventArgs e)
    {
        int actionId = (int)actionList.DataKeys[e.Item.ItemIndex];
        WorkflowAction workflowAction = WorkflowActionUtility.Get(
            ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);

        actionType.SelectedIndex = actionType.Items.IndexOf(
            actionType.Items.FindByValue(workflowAction.Type.ToString()));
        actionHideId.Value = workflowAction.Id.ToString();
        actionName.Text = workflowAction.Name;
        actionDesc.Text = workflowAction.Description;
        //actionDisplay.Text = workflowAction.DisplayName;
        if (workflowAction.Type == 1)// IF workflowAction.Type IS "Send Email"
        {
            emailrow.Style.Add("display", "");
            actionrow.Style.Add("display", "none");
            emailList.SelectedIndex = emailList.Items.IndexOf(
                emailList.Items.FindByValue(workflowAction.FunctionName));

        }
        else
        {
            emailrow.Style.Add("display", "none");
            actionrow.Style.Add("display", "");
            actionFunc.Text = workflowAction.FunctionName;
        }
        actionValue.Text = workflowAction.FunctionValue;

        panelTable_Action.Attributes.Remove("style");
        panelTable_Action.Attributes.Add("style", "display: inline; width: 400px; background-color: #FFFFFF;");
    }

    protected void saveActionButton_Click(object sender, EventArgs e)
    {
        int nodeId = ConvertUtility.ConvertInt(Request.QueryString["nid"]);
        int actionId = ConvertUtility.ConvertInt(actionHideId.Value);

        //WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(ConstantUtility.WORKFLOW_DATASOURCE_NAME,
        //    WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE, new object[] { nodeID });

        WorkflowAction workflowAction = null;
        if (actionId == 0)
        {
            workflowAction = WorkflowActionUtility.CreateObject();
            workflowAction.WorkflowNodeId = nodeId;
        }
        else
        {
            workflowAction = WorkflowActionUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, actionId);
        }

        if (workflowAction != null)
        {
            workflowAction.Name = actionName.Text;
            workflowAction.Type = ConvertUtility.ConvertInt(actionType.SelectedValue);
            workflowAction.Description = actionDesc.Text;
            //workflowAction.DisplayName = actionDisplay.Text;
            workflowAction.FunctionName = actionFunc.Text;
            workflowAction.FunctionValue = actionValue.Text;

            //email name
            if (workflowAction.Type == 1)
                workflowAction.FunctionName = emailList.SelectedValue;

            if (workflowAction.Id > 0)
                WorkflowActionUtility.Update(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowAction);
            else
                WorkflowActionUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowAction);
            ActionBind();
        }
        panelTable_Action.Attributes.Remove("style");
        panelTable_Action.Attributes.Add("style", "; display: none; width: 400px; background-color: #FFFFFF;");

    }

    protected void Condition_BindItem(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            Label localConditionType = (Label)e.Item.FindControl("conditionType");
            WorkflowCondition localWorkflowCondition = (WorkflowCondition)e.Item.DataItem;

            //if (conditionType.Items.FindByValue(localWorkflowCondition.Type.ToString()) != null)
            //    localConditionType.Text = (conditionType.Items.FindByValue(localWorkflowCondition.Type.ToString())).Text;

            ImageButton localEdit = (ImageButton)e.Item.FindControl("editButton");
            string prefix = localEdit.ClientID.Substring(0, localEdit.ClientID.LastIndexOf("_") + 1);
            //localEdit.Attributes.Add("onclick", "return toggleConditionSet('" + prefix + "');");

            ImageButton localDelete = (ImageButton)e.Item.FindControl("deleteButton");
            localDelete.Attributes.Add("onclick", "return confirm('Are you sure you want to delete this Condition?')");

        }
    }

    protected void Condition_DeleteItem(object sender, DataGridCommandEventArgs e)
    {
        int conditionId = (int)conditionList.DataKeys[e.Item.ItemIndex];
        WorkflowConditionUtility.Delete(ConstantUtility.WORKFLOW_DATASOURCE_NAME, conditionId);

        ConditionBind();
    }

    protected void Condition_EditItem(object sender, DataGridCommandEventArgs e)
    {
        int conditionId = (int)conditionList.DataKeys[e.Item.ItemIndex];
        WorkflowCondition workflowCondition = WorkflowConditionUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, conditionId);

        //conditionType.SelectedIndex = conditionType.Items.IndexOf(
        //    conditionType.Items.FindByValue(workflowCondition.Type.ToString()));
        conditionHideId.Text = workflowCondition.Id.ToString();
        conditionName.Text = workflowCondition.Name;
        conditionDesc.Text = workflowCondition.Description;
        //conditionDisplay.Text = workflowCondition.DisplayName;
        //conditionFunc.Text = workflowCondition.FunctionName;

        swb1.Conditions = (SqlWhereBuilderConditionCollection)XmlUtility.Deserialize(
            workflowCondition.ConditionXml, typeof(SqlWhereBuilderConditionCollection));

        errorMessage.Text = workflowCondition.ErrorMessage;

        panelTable_Condition.Attributes.Remove("style");
        panelTable_Condition.Attributes.Add("style", "display: inline; width: 600px; background-color: #FFFFFF;");
    }

    protected void saveConditionButton_Click(object sender, EventArgs e)
    {
        int nodeId = ConvertUtility.ConvertInt(Request.QueryString["nid"]);
        int conditionId = ConvertUtility.ConvertInt(conditionHideId.Text);

        WorkflowCondition workflowCondition = null;
        if (conditionId == 0)
        {
            workflowCondition = WorkflowConditionUtility.CreateObject();
            workflowCondition.WorkflowNodeId = nodeId;
        }
        else
        {
            workflowCondition = WorkflowConditionUtility.Get(ConstantUtility.WORKFLOW_DATASOURCE_NAME, conditionId);
        }

        if (workflowCondition != null)
        {
            string sWhere = swb1.GetWhereClause();
            sWhere = CommonUtility.LimpaSqlWhere(sWhere);

            workflowCondition.Name = conditionName.Text;
            //workflowCondition.Type = ConvertUtility.ConvertInt(conditionType.SelectedValue);
            workflowCondition.Description = conditionDesc.Text;
            //workflowCondition.DisplayName = conditionDisplay.Text;
            //workflowCondition.FunctionName = conditionFunc.Text;
            switch (ViewState["Type"].ToString())
            {
                case ConstantUtility.WORKFLOW_SUBCONTRACTOR:
                    workflowCondition.Condition = "/Subcontractor[" + sWhere + "]";
                    break;
                case ConstantUtility.WORKFLOW_PREQUAL_LIMITEDLIST:
                case ConstantUtility.WORKFLOW_MENTOR_LIMITEDLIST:
                case ConstantUtility.WORKFLOW_MENTORGRADUATE_LIMITEDLIST:
                    workflowCondition.Condition = "/RfdProject[" + sWhere + "]";
                    break;
                case ConstantUtility.WORKFLOW_SUPPLIER_LIMITEDLIST:
                    workflowCondition.Condition = "/RfdSupplier[" + sWhere + "]";
                    break;
                case ConstantUtility.WORKFLOW_CAPACITY_EVALUATION:
                case ConstantUtility.WORKFLOW_CIP_EVALUATION:
                case ConstantUtility.WORKFLOW_CCFU_EVALUATION:
                case ConstantUtility.WORKFLOW_PROJECT_CONTRACT_EVALUATION:
                case ConstantUtility.WORKFLOW_MENTORA_EVALUATION:
                case ConstantUtility.WORKFLOW_MENTORA_CONTRACT_EVALUATION:
                case ConstantUtility.WORKFLOW_MENTORB_EVALUATION:
                case ConstantUtility.WORKFLOW_IEH_EVALUATION:
                case ConstantUtility.WORKFLOW_IEH_CONTRACT_EVALUATION:
                    workflowCondition.Condition = "/Scorecard[" + sWhere + "]";
                    break;
                case ConstantUtility.WORKFLOW_EVALUATION:
                    workflowCondition.Condition = "/ScorecardInvitee[" + sWhere + "]";
                    break;
                case ConstantUtility.WORKFLOW_SUP:
                    workflowCondition.Condition = "/Plan[" + sWhere + "]";
                    break;
                case ConstantUtility.WORKFLOW_BID_AWARD_GENERAL:
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING:
                case ConstantUtility.WORKFLOW_BID_BREAKDOWN_ANALYSIS:
                case ConstantUtility.WORKFLOW_BID_MENTOR:
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_FINANCIAL_REVIEW:
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_BIDBOND_REVIEW:
                case ConstantUtility.WORKFLOW_PRE_AWARD_VETTING_MENTOR:
                    workflowCondition.Condition = "/Project[" + sWhere + "]";
                    break;
                case ConstantUtility.WORKFLOW_HB_GENERAL:
                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_PRIME:
                case ConstantUtility.WORKFLOW_HB_BAFO:                
                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_FINANCIAL:
                case ConstantUtility.WORKFLOW_HB_PRE_AWARD_VETTING_BIDBOND:
                case ConstantUtility.WORKFLOW_HB_ROUTING_PACKAGE:
                case ConstantUtility.WORKFLOW_HB_ROUTING_CQU:
                case ConstantUtility.WORKFLOW_HB_ROUTING_FINANCE:
                case ConstantUtility.WORKFLOW_HB_ROUTING_VPCM:
                case ConstantUtility.WORKFLOW_HB_ROUTING_OIG:
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE:
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_LEGAL:
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_VPCP:
                case ConstantUtility.WORKFLOW_HB_EXECUTION_PACKAGE_EVP:
                    workflowCondition.Condition = "/HBProject[" + sWhere + "]";
                    break;
                default:
                    workflowCondition.Condition = "/Supplier[" + sWhere + "]";
                    break;
            }
            workflowCondition.ConditionXml = XmlUtility.ToXml(swb1.Conditions);
            workflowCondition.ErrorMessage = errorMessage.Text;

            if (workflowCondition.Id > 0)
                WorkflowConditionUtility.Update(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowCondition);
            else
                WorkflowConditionUtility.Create(ConstantUtility.WORKFLOW_DATASOURCE_NAME, workflowCondition);
            ConditionBind();
        }
        panelTable_Condition.Attributes.Remove("style");
        panelTable_Condition.Attributes.Add("style", "display: none; width: 600px; background-color: #FFFFFF;");
    }

    #endregion Web Event Handler

    #region Private Method
    private void ActionSetInitialValue(int actionId)
    {
        if (actionId == 0)
        {
            actionType.SelectedIndex = 0;
            actionName.Text = string.Empty;
            actionDesc.Text = string.Empty;
            //actionDisplay.Text = string.Empty;
            actionFunc.Text = string.Empty;
            actionValue.Text = string.Empty;
            actionHideId.Value = "0";
        }

    }
    private void ActionBind()
    {
        int nodeId = ConvertUtility.ConvertInt(Request.QueryString["nid"]);
        actionList.Visible = false;

        WorkflowActionCollection workflowActions = WorkflowActionUtility.FindByCriteria(ConstantUtility.WORKFLOW_DATASOURCE_NAME,
            WorkflowActionManager.FIND_WORKFLOWACTION_BY_NODE, new object[] { nodeId });

        if (workflowActions != null && workflowActions.Count > 0)
        {
            actionList.DataSource = workflowActions;
            actionList.DataBind();
            actionList.Visible = true;
        }

        ActionClear();
    }

    private void ConditionBind()
    {
        int nodeId = ConvertUtility.ConvertInt(Request.QueryString["nid"]);
        conditionList.Visible = false;

        WorkflowConditionCollection workflowConditions = WorkflowConditionUtility.FindByCriteria(ConstantUtility.WORKFLOW_DATASOURCE_NAME,
            WorkflowConditionManager.FIND_WORKFLOWCONDITION_BY_NODE, new object[] { nodeId });
        if (workflowConditions != null && workflowConditions.Count > 0)
        {
            conditionList.DataSource = workflowConditions;
            conditionList.DataBind();
            conditionList.Visible = true;
        }
        ConditionClear();
    }


    private void ActionClear()
    {
        actionType.SelectedIndex = 0;
        actionName.Text = string.Empty;
        actionDesc.Text = string.Empty;
        //actionDisplay.Text = string.Empty;
        actionFunc.Text = string.Empty;
        actionValue.Text = string.Empty;
        actionHideId.Value = "0";
    }

    private void ConditionClear()
    {
        //conditionType.SelectedIndex = 0;
        conditionName.Text = string.Empty;
        conditionDesc.Text = string.Empty;
        //conditionDisplay.Text = string.Empty;
        //conditionFunc.Text = string.Empty;
        errorMessage.Text = string.Empty;
        conditionHideId.Text = "0";
        swb1.Conditions.Clear();
    }
    #endregion Private Method
}
