﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SCA.VAS.BusinessLogic.Supplier.Utilities;
using SCA.VAS.Workflow;
using SCA.VAS.ValueObjects.Supplier;
using System.Data.SqlClient;
using System.Text;

public partial class Admin_ChangeApplicationCreationDate : PageBase
{
    const string kChangeSupplierCreatedDateSp = "AdminChangeSupplierCreatedDate";

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSupplierSearch_Click(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(txtSupplierID.Text))
        {
            DisplaySupplier(txtSupplierID.Text);
        }
        else
        {
            litSuplierSerachMsg.Text = "Please specify a Fedreal Tax ID";
        }
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        calNewCreatedDate.Text = "";
        litSuplierSerachMsg.Text = "";
        txtSupplierID.Text = "";
        tdVersionCount.InnerHtml = "";
        tdVendorName.InnerHtml = "";
        tdVendorDateCreated.InnerHtml = "";
        pnlSupplier.Visible = false;

    }

    protected void btnChangeCreatedDate_Click(object sender, EventArgs e)
    {
        msgRow.InnerHtml = ChangeSupplierCreatedDate(txtSupplierID.Text, calNewCreatedDate.SelectedDate);
        DisplaySupplier(txtSupplierID.Text);
        calNewCreatedDate.Clear();
        
        
    }

    protected void DisplaySupplier(string federalId)
    {
        Supplier supplier = SupplierUtility.GetByUniqueKey(ConstantUtility.SUPPLIER_DATASOURCE_NAME, "FederalId", federalId);
        int intVersion;
        if (supplier == null)
        {
            litSuplierSerachMsg.Text = "Supplier not found.";
            return;
        }

        pnlSupplier.Visible = true;

        bool multiVersions = HasPreviousApplication(federalId, out intVersion);

        tdVersionCount.InnerHtml = intVersion.ToString();
        tdVendorName.InnerHtml = supplier.Company;
        tdVendorDateCreated.InnerHtml = supplier.ApplyDate.ToShortDateString();
    }

    protected bool HasPreviousApplication(string federalId, out int intVer)
    {

        string sql = string.Format("select count(sv.id) from supplier s, supplierversion sv where s.federalid='{0}' and s.id=sv.supplierid", federalId);
        string connString = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        int? rowCount;
        using (SqlConnection conn = new SqlConnection(connString))
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = sql;
            cmd.Connection = conn;
            conn.Open();
            rowCount = cmd.ExecuteScalar() as int?;
            conn.Close();

        }
        intVer = rowCount.Value;
        return (rowCount.HasValue && rowCount.Value > 1) ? true : false;

    }

    protected string ChangeSupplierCreatedDate(string federalId, DateTime changeDate)
    {

        string msg;

        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = System.Data.CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@federalId", federalId));
        cmd.Parameters.Add(new SqlParameter("@changeDate", changeDate));
        cmd.CommandText = kChangeSupplierCreatedDateSp;
       
        string connString = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        using (SqlConnection conn = new SqlConnection(connString))
        {

            cmd.Connection = conn;
            conn.Open();
            int rowCount = cmd.ExecuteNonQuery();
            conn.Close();
            msg = (rowCount > 0 ? "Created date changed." : "Operation did not affect any applications.");

        }

        return msg;
    }
}