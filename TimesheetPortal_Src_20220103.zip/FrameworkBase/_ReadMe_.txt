﻿Oct 2021 PCHEN introduced:

This project defines a generic application framework fundation that can be shared by multiple applications

(1) IValueObject: All business entities need to implement this interface
(2) DataAccess : Base class/interface for <<Entity>>Dao
(3) DbSession defines a Data Access Session ( IDbConnection + IDbTransaction)
(4) BusinessLogic : Base class/interface for <<Entity>>Manager 
(5) EnumBase : Custom type that extends the features of Struct Enum Type