﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using System;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

#endregion

namespace FrameworkBase.Util
{
    public static class XMLSerializer
    {
        public static string Serialize<T>(this T toSerialize, string xmlRootName = null)
        {
            return Serialize<T>(toSerialize, xmlRootName, null);
        }

        public static string Serialize<T>(this T toSerialize, string xmlRootName = null, string nameSpace = null)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T), CreateXmlRootAttribute(xmlRootName, nameSpace));
            using (StringWriter writer = new StringWriter())
            {
                xmlSerializer.Serialize(writer, toSerialize);
                var x = writer.ToString();
                return x;
            }
        }

        public static T Deserialize<T>(XmlReader reader)
        {
            object result = null;
            XmlSerializer mySerializer = new XmlSerializer(typeof(T));
            result = mySerializer.Deserialize(reader);
            return (T)result;
        }

        public static T Deserialize<T>(string sXML) where T : class
        {
            /** PCHEN: Borrow idea from here, good read :
             * https://stackoverflow.com/questions/2347642/deserialize-from-string-instead-textreader/42796061
             * ************************************************/
            var serializer = new XmlSerializer(typeof(T));
            T result = null;

            using (TextReader reader = new StringReader(sXML))
            {
                result = (T)serializer.Deserialize(reader);
            }

            return result;
        }

        #region	Private Methods

        private static XmlRootAttribute CreateXmlRootAttribute(string xmlRootName, string nameSpace)
        {
            var x = new XmlRootAttribute();
            XmlRootAttribute xmlRoot = new XmlRootAttribute
            {
                ElementName = string.IsNullOrWhiteSpace(xmlRootName) ? string.Empty : xmlRootName,
                Namespace = string.IsNullOrWhiteSpace(nameSpace) ? string.Empty : nameSpace,
                IsNullable = true
            };
            return xmlRoot;
        }

        #endregion	Private Methods
    }


}