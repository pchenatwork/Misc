﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using FrameworkBase.Common;
using System;
using System.Reflection;

#endregion Header Info

namespace FrameworkBase.DataAccess
{
    /// <summary>
    /// Return a DbSession
    /// </summary>
    public sealed class DbSessionFactory : FactoryBase<DbSessionFactory>
    {
        /// <summary>
        /// Return a SQL Connection Session
        /// </summary>
        /// <param name="connStr"></param>
        /// <returns></returns>
        public SqlSession GetSqlSession(string connStr)
        {
            return new SqlSession(connStr);
        }
    }
}