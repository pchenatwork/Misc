﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Reflection;

#endregion Header Info

namespace FrameworkBase.DataAccess
{
    /// <summary>
    /// Abstract DAO that all xxxDAO class should be based on
    /// </summary>
    /// <typeparam name="T">IValueObject</typeparam>
    public abstract class AbstractDao<T> : IDataAccessObject<T> where T : IValueObject
    {
        #region constructor

        protected AbstractDao()
        {
        }

        static AbstractDao()
        {
        }

        #endregion constructor

        #region IDatabaseObject
        public virtual int Create(IDbSession dbSession, T newObject)
        {
            throw new NotImplementedException();
        }

        public virtual bool Update(IDbSession dbSession, T obj)
        {
            throw new NotImplementedException();
        }

        public virtual bool Delete(IDbSession dbSession, dynamic Id, dynamic By = null)
        {
            throw new NotImplementedException();
        }

        public virtual IEnumerable<T> Find(IDbSession dbSession, string jsonTokens)
        {
            throw new NotImplementedException();
        }
        //public virtual IEnumerable<T> FindByCriteria(IDbSession dbSession, string finderType, params object[] criteria)
        //{
        //    throw new NotImplementedException();
        //}

        public virtual IEnumerable<T> FindByEntity(IDbSession dbSession, IValueObject entity)
        {
            throw new NotImplementedException();
        }

        public virtual T Get(IDbSession dbSession, dynamic id)
        {
            throw new NotImplementedException();
        }

        public virtual IEnumerable<T> GetAll(IDbSession dbSession)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Make sure IDbSession is the first in parameters[]
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public dynamic InvokeByMethodName(string methodName, params object[] parameters)
        {
            Type type = this.GetType();
            return type.InvokeMember(methodName, BindingFlags.DeclaredOnly |
                BindingFlags.Public| BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.InvokeMethod,
                null, this, parameters);
        }

        #endregion

        #region Static Helpers

        ///// <summary>
        ///// Wrapper for executing  SqlCommand.ExecuteXmlReader() method, See MSDN for more details
        ///// </summary>
        ///// <param name="dbSession"></param>
        ///// <param name="commandText"></param>
        ///// <param name="parameters">parameters[0] = new SqlParameter("@ReturnValue", SqlDbType.Int);</param>
        ///// <returns></returns>
        //protected static XmlReader ExecuteXmlReader(IDbSession dbSession, string commandText, IEnumerable<SqlParameter> parameters)
        //{
        //    XmlReader reader;
        //    using (SqlCommand cmd = new SqlCommand())
        //    {
        //        cmd.Connection = (SqlConnection)dbSession.DbConnection;
        //        if (dbSession.Transaction != null) cmd.Transaction = (SqlTransaction)dbSession.Transaction;

        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;
        //        cmd.CommandText = commandText;

        //        foreach (SqlParameter p in parameters)
        //        {
        //            cmd.Parameters.Add(p);
        //        }

        //        if (cmd.Connection.State != ConnectionState.Open) cmd.Connection.Open();

        //        reader = cmd.ExecuteXmlReader();
        //    }
        //    return reader;
        //}

        ///// <summary>
        ///// Wrapper for executing SqlCommand.ExecuteNonQuery() Command, See MSDN for more details
        ///// </summary>
        ///// <param name="dbSession"></param>
        ///// <param name="commandText"></param>
        ///// <param name="parameters"></param>
        ///// <returns>row count</returns>
        //protected static int ExecuteNonQuery(IDbSession dbSession, string commandText, IEnumerable<SqlParameter> parameters, out object retval)
        //{
        //    using (SqlCommand cmd = new SqlCommand())
        //    {
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.CommandText = commandText;

        //        foreach (SqlParameter p in parameters)
        //        {
        //            cmd.Parameters.Add(p);
        //        }

        //        if (dbSession.Transaction != null)
        //        {
        //            cmd.Transaction = (SqlTransaction)dbSession.Transaction;
        //            cmd.Connection = cmd.Transaction.Connection;
        //        }
        //        else
        //            cmd.Connection = (SqlConnection)dbSession.DbConnection;

        //        if (cmd.Connection.State != ConnectionState.Open) cmd.Connection.Open();

        //        int rowcount = cmd.ExecuteNonQuery();
        //        retval = cmd.Parameters["@ReturnValue"].Value;
        //        return rowcount;
        //    }
        //}

        //protected static T Deserialize(XmlReader reader)
        //{
        //    return Util.XMLSerializer.Deserialize<T>(reader);
        //}

        //protected static IEnumerable<T> DeserializeCollection(XmlReader reader)
        //{
        //    return Util.XMLSerializer.Deserialize<T[]>(reader);
        //}

        #endregion
    }
}