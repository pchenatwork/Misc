﻿using EVO.TimesheetPortal.Entity;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EVO.TimesheetPortal.Site.Models
{
    public class TeamModel : BaseModel
    {
        [DataType(DataType.Text)]
        [Required]
        public string Name { get; set; }

        [Required]
        [StringLength(50)]
        public string DeptCode { get; set; }

        [DataType(DataType.Text)]
        [StringLength(50)]
        [Required(ErrorMessage ="The Short Name field is required.")]
        [RegularExpression("^[a-zA-Z0-9_&\x20]*$", ErrorMessage = "The Short Name can only input alphanumeric character. ")]
        public string ShortName { get; set; }

        [Required(ErrorMessage = "The Manager field is required.")]
        public ManagerModel Manager { get; set; }

        [Required(ErrorMessage = "The Team Owner is required.")]
        public ManagerModel Owner { get; set; }

        [Required(ErrorMessage = "The Team Owner is required.")]
        public int TeamOwner { get; set; }

        public static List<TeamModel> MapObjectToModel(List<Team> list)
        {
            var returnObj = new List<TeamModel>();
            if (list == null)
            {
                return returnObj;
            }
            foreach (var entity in list)
            {
                TeamModel model = new TeamModel();
                model.ID = entity.Id;
                model.Name = entity.Name;
                model.ShortName = entity.ShortName;
                model.IsActive = entity.IsActive;
                model.Manager = entity.Manager == null ? new ManagerModel() : new ManagerModel() { ID = entity.Manager.Id, DisplayName = entity.Manager.DisplayName };
                model.Owner = entity.Owner == null ? new ManagerModel() : new ManagerModel() { ID = entity.Owner.Id, DisplayName = entity.Owner.DisplayName };
                model.TeamOwner = model.Owner.ID;
                model.UpdateBy = entity.UpdateBy;
                model.UpdateDate = entity.UpdateDate;
                model.DeptCode = entity.DeptCode;
                model.CreateBy = entity.CreateBy;
                model.CreateDate = entity.CreateDate;
                returnObj.Add(model);
            }
            return returnObj;
        }

        public static Team MapModelToObject(TeamModel model)
        {
            var entity = new Team();
            entity.Id = model.ID;
            entity.Name = model.Name;
            entity.ShortName = model.ShortName;
            entity.ManagerId = (model.Manager?.ID).GetValueOrDefault();
            entity.Manager = model.Manager == null ? new Employee() : new Employee() { Id = model.Manager.ID, DisplayName = model.Manager.DisplayName };
            entity.DeptCode = model.DeptCode;
            entity.OwnerId = (model.Owner?.ID).GetValueOrDefault();
            entity.Owner = model.Owner == null ? new Employee() : new Employee() { Id = model.Owner.ID, DisplayName = model.Owner.DisplayName };
            entity.CreateBy = model.CreateBy;
            entity.CreateDate = model.CreateDate;
            entity.UpdateBy = model.UpdateBy;
            entity.UpdateDate = model.UpdateDate;
            entity.IsActive = model.IsActive;
            return entity;
        }

        public static TeamModel MapEntiyToModel(Team entity)
        {
            var model = new TeamModel();
            model.ID = entity.Id;
            model.ID = entity.Id;
            model.Name = entity.Name;
            model.ShortName = entity.ShortName;
            model.IsActive = entity.IsActive;
            model.Manager = entity.Manager == null ? new ManagerModel() : new ManagerModel() { ID = entity.Manager.Id, DisplayName = entity.Manager.DisplayName };
            model.Owner = entity.Owner == null ? new ManagerModel() : new ManagerModel() { ID = entity.Owner.Id, DisplayName = entity.Owner.DisplayName };
            model.TeamOwner = model.Owner.ID;
            model.UpdateBy = entity.UpdateBy;
            model.UpdateDate = entity.UpdateDate;
            model.DeptCode = entity.DeptCode;
            model.CreateBy = entity.CreateBy;
            model.CreateDate = entity.CreateDate;
            return model;
        }
    }

    public class ExecutiveTeamModel
    {
        public int Id { get; set; }
        public string Name { get; set; }

        
        public string DeptCode { get; set; }

       
        public string ShortName { get; set; }

        public ManagerModel Owner { get; set; }
        public static List<ExecutiveTeamModel> MapEntitysToModels(List<Team> list)
        {
            var returnObj = new List<ExecutiveTeamModel>();
            if (list == null)
            {
                return returnObj;
            }
            foreach (var entity in list)
            {
                ExecutiveTeamModel model = new ExecutiveTeamModel();
                model.Id = entity.Id;
                model.Name = entity.Name;
                model.ShortName = entity.ShortName;

                model.Owner = entity.Owner == null ? new ManagerModel() : new ManagerModel() { ID = entity.Owner.Id, DisplayName = GetDisplayName(entity.Owner) };
                model.DeptCode = entity.DeptCode;
              
                returnObj.Add(model);
            }
            return returnObj;
        }

        private static string GetDisplayName(Employee employee)
        {
            if(employee == null)
            {
                return "";
            }
            var displayName = "";
            if(!string.IsNullOrWhiteSpace(employee.FirstName))
            {
                displayName = employee.FirstName;
                if(!string.IsNullOrWhiteSpace(employee.LastName))
                {
                    displayName += " " + employee.LastName.Substring(0, 1);
                }
            }

            return displayName;
        }
    }
}