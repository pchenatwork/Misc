﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Models
{
    public class TimeSheetUploadModel
    {
        public decimal? Hours { get; set; }
        public string UserId { get; set; }
        public string Project { get; set; }
        public string Activity { get; set; }
        public DateTime? Date { get; set; }

        public string Error { get; set; }
    }
}
