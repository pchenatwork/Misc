﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Models
{
    public class NewTaskModel
    {
        public int ResourceID { get; set; }
        [Required(ErrorMessage = "Project is required.")]
        public int ProjectId { get; set; }
        [Required(ErrorMessage = "Activity is required.")]
        public int ActivityId { get; set; }
        public DateTime ActivityDate { get; set; }
    }
}
