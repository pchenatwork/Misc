﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Site.Models
{
    [BindProperties]
    public class TimesheetCreateModel
    {
        public int EmployeeId { get; set; }

        public int ProjectId { get; set; }

        public int ActivityId { get; set; }

        public DateTime ActivityDate { get; set; }
    }
}
