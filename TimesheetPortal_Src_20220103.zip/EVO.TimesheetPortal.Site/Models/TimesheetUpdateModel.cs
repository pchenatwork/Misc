﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace EVO.TimesheetPortal.Site.Models
{
    [BindProperties]
    public class TimesheetUpdateModel
    {
        public int Id { get; set; }
        [Required]
        [UIHint("NumericTextBox")]
        [Range(0, 999)]
        public decimal Hours { get; set; }
        [DataType(DataType.Text)]
        [StringLength(2000)]
        [UIHint("TextBox")]
        public string Description { get; set; }
        public int IsTimeSheet { get; set; }
        public int EmployeeId { get; set; }
        public int ProjectId { get; set; }
        public int ActivityId { get; set; }
        public DateTime ActivityDate { get; set; }
    }
}
