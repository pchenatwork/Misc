﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Diagnostics;
using UAParser;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class HomeController : BaseController
    {
        public HomeController()
        {
        }

        public IActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        public IActionResult Error()
        {
            var exception = HttpContext.Features.Get<IExceptionHandlerFeature>();
            var error = exception?.Error;
            if (error != null)
            {
                try
                {
                    //ServiceClient.LogError(new ApplicationLogEntity()
                    //{
                    //    Message = error.Message,
                    //    StackTrace = error.StackTrace,
                    //    UserName = ApplicationSession.GetUser().User?.UserName,
                    //    MachineName = Environment.MachineName,
                    //    OperatingSystem = GetOperatingSystem(HttpContext),
                    //    Browser = GetBrowser(HttpContext),
                    //    Date = DateTime.Now
                    //});
                }
                catch (Exception ex)
                {
                    Serilog.Log.Error(ex, "Save log to server occur error.");
                }
            }
            Serilog.Log.Error(error, "Server occur error.");
            return View();
        }

        public IActionResult Permission()
        {
            return View();
        }

        [AllowAnonymous]
        [IgnoreAntiforgeryToken]
        public IActionResult StatusCode(string code)
        {
            ViewBag.Code = code;
            string mssage = "";
            if (code == "404")
            {
                mssage = "The request was not found.";
            }

            var RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
            var ErrorStatusCode = code;

            var statusCodeReExecuteFeature = HttpContext.Features.Get<IStatusCodeReExecuteFeature>();
            string OriginalURL = "unkonw";
            if (statusCodeReExecuteFeature != null)
            {
                 OriginalURL =
                      statusCodeReExecuteFeature.OriginalPathBase
                      + statusCodeReExecuteFeature.OriginalPath
                      + statusCodeReExecuteFeature.OriginalQueryString;
            }
            if (code == "400")
            {
                
            }

            ViewBag.Message = mssage;
            Serilog.Log.Error($"code:{code}, from:{OriginalURL}");
            return View();
        }

        private string GetOperatingSystem(HttpContext context)
        {
            var clientInfo = GetUserAgent(context);
            var os = clientInfo.OS.Family;
            if (os == null) return "Unknown";

            if (os.IndexOf("Windows NT 5.1", StringComparison.Ordinal) > 0)
            {
                return "Window XP";
            }

            if (os.IndexOf("Windows NT 6.0", StringComparison.Ordinal) > 0)
            {
                return "Window Vista";
            }

            if (os.IndexOf("Windows NT 6.1", StringComparison.Ordinal) > 0)
            {
                return "Window 7";
            }

            if (os.IndexOf("Windows NT 10.0", StringComparison.Ordinal) > 0)
            {
                return "Window 10";
            }

            if (os.IndexOf("Intel Mac OS X", StringComparison.Ordinal) > 0)
            {
                return "Intel Mac OS X";
            }

            return "Unknown";
        }

        private string GetBrowser(HttpContext context)
        {
            var clientInfo = GetUserAgent(context);
            var browser = clientInfo.UA.Family;
            return browser;
        }

        private ClientInfo GetUserAgent(HttpContext context)
        {
            var userAgent = context.Request.Headers["User-Agent"];
            string uaString = Convert.ToString(userAgent[0]);
            var uaParser = Parser.GetDefault();
            ClientInfo c = uaParser.Parse(uaString);
            return c;
        }
    }
}