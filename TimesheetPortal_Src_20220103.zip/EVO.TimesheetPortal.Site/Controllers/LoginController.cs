using EVO.TimesheetPortal.Entity;
using EVO.TimesheetPortal.Site.App_Classes;
using EVO.TimesheetPortal.Site.Models;
using EVO.TimesheetPortal.Site.Service;
using EVOUserWSServiceReference;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using TimeSheetTrackerCore.Site.Models;
using TimeSheetTrackerCore.Site.Service;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class LoginController : Controller
    {
        private IEmployeeService ResourceService;
        private ITeamService TeamService;
        public IConfiguration Configuration;
        public static string DomainName;
        private readonly IHttpContextAccessor HttpContextAccessor;
        protected IEVOUserWS UserManagementClient;
        private LoginService LoginService;
        public IWebHostEnvironment Environment { get; set; }

        public LoginController(
            IEVOUserWS userManagementClient,
            IEmployeeService service,
            ITeamService teamService,
            LoginService loginService,
            IConfiguration configuration,
            IWebHostEnvironment environment,
            IHttpContextAccessor httpContextAccessor
            )
        {
            ResourceService = service;
            Configuration = configuration;
            Environment = environment;
            DomainName = Configuration.GetValue<string>("Application:DefualtDomainName");
            HttpContextAccessor = httpContextAccessor;
            UserManagementClient = userManagementClient;
            TeamService = teamService;
            LoginService = loginService;
        }

        [HttpGet]
        public async Task<IActionResult> UserLogin(string returnUrl)
        {
            returnUrl = FormatReturn(returnUrl);
            ViewBag.ReturnUrl = returnUrl;
            ViewBag.UserName = HttpContextAccessor.HttpContext.User.Identity.Name;
            var authCookie = ApplicationContext.Current.Request.Cookies["TimeSheetTrackerCookie"];
            if (authCookie != null)
            {
                await HttpContext.SignOutAsync();
                HttpContext.Session.Clear();
                return RedirectToAction("UserLogin","Login");
            }
            return View();
        }

        public async Task<IActionResult> Logout()
        {
            var authCookie = ApplicationContext.Current.Request.Cookies["TimeSheetTrackerCookie"];
            if (authCookie != null)
            {
                await HttpContext.SignOutAsync();
                HttpContext.Session.Clear();
               
            }
            return Redirect("UserLogin");
        }

        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public async Task<IActionResult> UserLogin([Bind("UserName,Password")] LoginViewModel model, string returnUrl)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            returnUrl = FormatReturn(returnUrl);
            if (string.IsNullOrEmpty(model.UserName))
            {
                ModelState.AddModelError("", "The user name is empty.");
                return View();
            }

            var userName = ResolveDomainAccount(model.UserName);
            PrincipalContext context = new PrincipalContext(ContextType.Domain, DomainName);
            if (!context.ValidateCredentials(userName, model.Password.ToString()))
            {
                ModelState.AddModelError("", "The username or password is incorrect. Please try again. Your windows account will be locked after the 3rd unsuccessful attempt.");
                return View();
            }

            try
            {
                var user = await ResolveUserAsync(userName);
                if (user.User == null)
                {
                    ModelState.AddModelError("", "Cannot get user data from eUser.");
                    return View();
                }
                return await LoginAuthenticate(returnUrl, user);
            }
            catch (Exception error)
            {
                Log.Error(error, "Login Error!");
                ModelState.AddModelError("", "Login failed, Please contact administrator to check the eUser service.");
                return View();
            }
        }

        [HttpGet]
        public async Task<IActionResult> SuperUserLogin(string returnUrl)
        {
            returnUrl = FormatReturn(returnUrl);
            ViewBag.ReturnUrl = returnUrl;
            var authCookie = ApplicationContext.Current.Request.Cookies["TimeSheetTrackerCookie"];
            if (authCookie != null)
            {
                await HttpContext.SignOutAsync();
                HttpContext.Session.Clear();

                return Redirect("SuperUserLogin");
            }
            return View();
        }

        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public async Task<IActionResult> SuperUserLogin([Bind("UserName,Password")] LoginViewModel model, string returnUrl)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            returnUrl = FormatReturn(returnUrl);
            string token = Configuration.GetValue<string>("SuperUserToken");
            if (string.IsNullOrEmpty(token))
            {
                ModelState.AddModelError("", "Super user log in is closed.");
                return View();
            }

            var inputToken = model.Password.ToString();
            var userName = ResolveDomainAccount(model.UserName);
            if (token != inputToken)
            {
                ModelState.AddModelError("", "Please provide the correct token!");
                return View();
            }

            var user = await ResolveUserAsync(userName);
            if (user.User == null)
            {
                ModelState.AddModelError("", "Cannot get user data from eUser.");
                return View();
            }
            return await LoginAuthenticate(returnUrl, user);
        }

        private async Task<IActionResult> LoginAuthenticate(string returnUrl, UserModel userModel)
        {
            var userClaims = new List<Claim>()
                            {
                                new Claim(ClaimTypes.Name, userModel.User.UserName),
                                new Claim(ClaimTypes.Email, userModel.User.Email),
                            };
            var grandmaIdentity = new ClaimsIdentity(userClaims, "Forms");
            var idleTimeOut = Configuration.GetValue<double>("Application:TimeOut");
            var authProperties = new AuthenticationProperties
            {
                AllowRefresh = true,
                ExpiresUtc = DateTimeOffset.UtcNow.AddSeconds(idleTimeOut),
                IsPersistent = false,
                IssuedUtc = DateTimeOffset.UtcNow,
                RedirectUri = null
            };
            var userPrincipal = new ClaimsPrincipal(new[] { grandmaIdentity });
            await HttpContext.SignInAsync(userPrincipal, authProperties);

            if (userModel.Employee != null && userModel.Employee.ID > 0)
            {
                if (!userModel.Employee.IsActive)
                {
                    ModelState.AddModelError("", "Your account is disabled, please contact your team manager to enable.");
                    return View();
                }
                var employeee = userModel.Employee;
                var userName = userModel.User.FirstName + " " + userModel.User.LastName;
                var roleName = userModel.User.Roles?.RoleName;
                if (!string.IsNullOrEmpty(userName.Trim(' ')) && (!employeee.RoleNames.Any(s => s == roleName) || employeee.DisplayName != userName || employeee.Email != userModel.User.Email))
                {
                    employeee.DisplayName = userName;
                    await LoginService.SyncEmployee(employeee.ID, employeee.UserId, userName, roleName, userModel.User.Email);
                }
            }
            else  // insert employee record to timesheet
            {
                var user = userModel.User;

                var employee = new Employee();
                var roleName = user.Roles?.RoleName;
                roleName = string.IsNullOrWhiteSpace(roleName) ? ResouceRolesEnum.Employee.Name : roleName;
                employee.Title = roleName;
                employee.UserId = user.UserName;
                employee.DisplayName = user.FirstName + " " + user.LastName;
                employee.Email = user.Email;
                employee.FirstName = user.FirstName;
                employee.LastName = user.LastName;
                employee.IsActive = true;
                employee.CreateBy = user.UserName;
                employee.UpdateBy = user.UserName;
                employee.RoleNames = new Collection<string>() { roleName };
                userModel.Employee = EmployeeModel.EntityToModel(employee);
                var ressult = await ResourceService.CreateAsync(employee);
            }

            ApplicationSession.CurrentLanguage = GetCurrentLanuage(Request.Headers["Accept-Language"].ToString());
            ApplicationSession.SetUser(userModel);

            string tempUrl = returnUrl;
            if (string.IsNullOrEmpty(returnUrl) || (returnUrl?.Contains("StatusCode") ?? false))
            {
                tempUrl = Url.Action("index", "TimeSheet");
                if (userModel.Employee != null)
                {
                    switch (userModel.User.Roles?.RoleName?.ToLower())
                    {
                        case "manager":
                            tempUrl = Url.Action("approval", "TimeSheet");
                            break;

                        case "itexecutive":
                            tempUrl = Url.Action("approval", "project");
                            break;

                        case "projectadmin":
                            tempUrl = Url.Action("Index", "Project");
                            break;

                        case "employee":
                        case "timesheetadmin":
                            tempUrl = Url.Action("Index", "TimeSheet");
                            break;

                        case "accounting":
                            tempUrl = Url.Action("Index", "Accounting");
                            break;

                        case "teamowner":
                            tempUrl = Url.Action("Index", "Employee");
                            break;

                        default:
                            tempUrl = Url.Action("Index", "TimeSheet");
                            break;
                    }
                }
            }

            if (Url.IsLocalUrl(tempUrl))
            {
                ViewBag.ReturnUrl = returnUrl;
                return Redirect(tempUrl);
            }
            else
            {
                return View("Error", model: "The return url is incorrect, please re-login the application.");
            }
        }

        private string FormatReturn(string returnUrl)
        {
            if (returnUrl?.Contains("SessionID") ?? false)
                returnUrl = returnUrl.Substring(0, returnUrl.IndexOf("SessionID") - (returnUrl.Contains("&SessionID") ? 1 : 0));
            if (CheckReturnUrlInBlackList(returnUrl))
            {
                returnUrl = string.Empty;
            }
            return returnUrl;
        }

        private bool CheckReturnUrlInBlackList(string url)
        {
            if (string.IsNullOrWhiteSpace(url))
            {
                return false;
            }
            var blackList = new List<string>() { "Excel_Export" };
            return blackList.Any(s => url.Contains(s));
        }

        private string ResolveDomainAccount(string domainName)
        {
            if (string.IsNullOrEmpty(domainName))
            {
                return string.Empty;
            }
            var domainArray = domainName.Split(new char[] { '\\' });
            var emailFormatArray = domainName.Split(new char[] { '@' });

            string userName = domainName;

            if (domainArray.Length > 1)
            {
                userName = domainArray[1];
            }
            else if (emailFormatArray.Length > 1)
            {
                userName = emailFormatArray[0];
            }

            return userName;
        }

        private async Task<UserWP> GetUserData(string userName)
        {
            string applicationName = Configuration.GetValue<string>("Application:Name");
            return await UserManagementClient.GetUserProfileAsync(applicationName, userName);
        }

        private async Task<EmployeeModel> GetCurrentUser(string loginName)
        {
            var apiResponse = await ResourceService.GetByUserIdAsync(loginName);
            var entity = apiResponse.Content;
            var model = new EmployeeModel();
            if (entity == null)
            {
                return model;
            }
            model.UserId = entity.UserId;
            model.LastName = entity.LastName;
            model.FirstName = entity.FirstName;
            model.Email = entity.Email;
            model.CountryCode = entity.CountryCode;
            model.CreateBy = entity.CreateBy;
            model.CreateDate = entity.CreateDate;
            model.DeptCode = entity.DeptCode;
            model.DisplayName = entity.DisplayName;
            model.ID = entity.Id;
            model.JobGradeId = entity.JobGradeId;
            model.IsActive = entity.IsActive;
            model.Manager = new ManagerModel
            {
                ID = entity.Manager?.Id ?? 0,
                DisplayName = entity.Manager?.DisplayName
            };
            model.Team = new TeamModel
            {
                ID = entity.Team?.Id ?? 0,
                Name = entity.Team?.Name,
                Manager = new ManagerModel { ID = entity.Team?.Manager?.Id ?? 0, UserId = entity.Team?.Manager?.UserId },
                Owner = new ManagerModel { ID = entity.Team?.Owner?.Id ?? 0, UserId = entity.Team?.Owner?.UserId }
            };
            model.RoleNames = entity.RoleNames.ToList();
            return model;
        }

        private async Task<UserModel> ResolveUserAsync(string userName)
        {
            var userWP = await GetUserData(userName);
            var currentUser = await GetCurrentUser(userName);
            var teamResult = await TeamService.GetTeamAsync(currentUser?.Team?.ID ?? -1);
            if (teamResult?.Content != null)
            {
                var team = teamResult.Content;
                currentUser.Team = new TeamModel
                {
                    ID = team.Id,
                    DeptCode = team.DeptCode,
                    Name = team.Name,
                    Manager = new ManagerModel { ID = team.Manager?.Id ?? 0 },
                    Owner = new ManagerModel { ID = team.Owner?.Id ?? 0 }
                };
            }
            var teamListResult = await TeamService.SearchAsync(new TeamCriteria { IsAdmin = true });
            var teamList = teamListResult.Content?.Where(w => w.Owner.Id == currentUser.ID || w.Manager.Id == currentUser.ID).ToList();
            var userModel = new UserModel()
            {
                User = userWP.user,
                Employee = currentUser,
                LoginUserTeam = TeamModel.MapObjectToModel(teamList)
            };
            if (userModel.LoginUserTeam.Count == 0 && currentUser.Team?.ID > 0)
            {
                userModel.LoginUserTeam.Add(currentUser.Team);
            }
            userModel.IsAdmin = userModel.CheckIsAdmin(userWP.user);
            return userModel;
        }

        private string GetCurrentLanuage(string acceptLang)
        {
            string lang = "en-US";
            if (!string.IsNullOrEmpty(acceptLang))
            {
                lang = acceptLang.Split(',')?.FirstOrDefault();
            }
            return lang;
        }
    }
}