﻿using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using EVO.TimesheetPortal.Site.App_Classes;
using EVO.TimesheetPortal.Site.Service;

namespace EVO.TimesheetPortal.Site.Controllers
{
    public class ApplicationLogController : BaseController<ApplicationLogService>
    {
        public ApplicationLogController(ApplicationLogService service) : base(service)
        { }

        [PageEntry(ActionName = "index", ControllerName = "ApplicationLog")]
        public IActionResult Index()
        {
            return View();
        }

        public ActionResult Read([DataSourceRequest] DataSourceRequest request)
        {
            return Json(Client.GetList().ToDataSourceResult(request));
        }
    }
}