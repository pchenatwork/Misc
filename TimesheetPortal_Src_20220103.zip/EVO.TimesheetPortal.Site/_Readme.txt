﻿Note: TimeSheetTracketCore.Site relies on TimeSheetTracker.Service
So we can set solution to have "multiple startup project"
"
Project Log:
20210519 PCHEN 
	Shuffle TFS folder structure
	Make solution to run with 3.1.15 (Needs to install hosting bundle from https://dotnet.microsoft.com/download/dotnet/3.1)
f20210625 PCHEN Kendo Component Upgrade from 2019.xx->2021.2.511