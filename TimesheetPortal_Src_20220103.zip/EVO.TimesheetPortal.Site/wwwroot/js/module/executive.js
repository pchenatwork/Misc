﻿
    $(document).ready(function () {
        $('#btnApprove').on('click', function () {
            ProjectViewGrid.approveExecutive('project');
        })

        $("#tabstrip").kendoTabStrip({
            animation: {
                open: {
                    effects: "fadeIn"
                }
            },
            activate: function (e) {

                $('.k-state-active').css('height', '100%');
                var id = e.item.id;
                var type = id == 'tabProject' ? 'project' : 'resource';


                if (type == 'resource') {
                    var grid = $('#ResourceViewGrid').data('kendoGrid');
                    if (grid) {
                        grid.dataSource.read();
                    }

                } else {
                    var grid = $('#projectViewGrid').data('kendoGrid');
                    if (grid) {
                        grid.refresh();
                        grid._resize();

                    }
                }

                var currentDate =  new Date($('#taskDate').val()) ;
                currentDate = kendo.toString(currentDate, 'yyyyMM')
                var currentPeriodCode = $('#currentPeriodCode').val();
                var disabled = currentDate != currentPeriodCode
                ProjectViewGrid.setApproveButtonStatus(disabled);
                $('#btnApprove').off('click');
                $('#btnApprove').on('click', function () {
                    ProjectViewGrid.approveExecutive(type)
                })
            }
        });


        $('#exportResource').click(function () {

            var tab = $("#tabstrip").data('kendoTabStrip');
            var isResource = tab.select().attr('id') == 'tabResource';
            var grid = $('#ResourceViewGrid').data('kendoGrid');
            if (grid) {
                var currentDate = new Date($('#resourceTaskDate').val());
                currentDate = kendo.toString(currentDate, 'yyyyMM')
                grid.options.excel.fileName = 'ResourceView-' + currentDate;
                // grid.saveAsExcel();

                $('.k-grid-EXPORT').click();

            }
        })
    });

    function onFilterChange() {

        var currentDate = new Date($('#taskDate').val());
        currentDate = kendo.toString(currentDate, 'yyyyMM')
      

        var accountEntityId = $("#AccountingEntity").data('kendoComboBox').value();
        if (!accountEntityId) {
            accountEntityId = 0;
        }
        $.when($.post("/timesheet/GetExecutionSummary?periodCode=" + currentDate + "&entityId=" + accountEntityId, forgeryToken())).then(function (data) {

            generateGrid(data);

        })

        var grid = $('#ResourceViewGrid').data('kendoGrid');
        if (grid) {
            grid.dataSource.read();
        }

        //var grid = $("#projectViewGrid").data("kendoGrid");
        //grid.dataSource.read();
    }



   function onDataFilter() {
        var currentDate = new Date($('#taskDate').val());
        currentDate = kendo.toString(currentDate, 'yyyyMM')
        var accountEntityId = $("#AccountingEntity").data('kendoComboBox').value();
        if (!accountEntityId) {
            accountEntityId = 0;
        }
        var obj = {
            periodCode: currentDate,
            entityId: accountEntityId
        }
        return compoundObjectWithForgeryToken(obj);
    };
   
