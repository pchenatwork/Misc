﻿$(document).ready(function () {
    if (location.href.toLowerCase().includes('daterange')) {
        var dateStrig = location.href.split('=')[2]
        setDate(new Date(dateStrig.substring(0, 4) + '/' + dateStrig.substring(4, 6) + '/1'));
        if (location.href.split('=').length > 3) {
            var selectedIds = location.href.split('=')[3].split(',')
            var entities = $("#AccountingEntity").data("kendoMultiSelect");
            entities.value(selectedIds);
        }
    } else {
        setDate(new Date());
    }
    $("#btnDate").kendoDatePicker({
        start: "year",
        depth: "year",
        format: "yyyyMM",
        change: function () {
            setDate(this.value());
        }
    });
    $('#btnPreDate').click(function () {
        setDate(addMonth($('#taskDate').val(), -1));
    });
    $('#btnNextDate').click(function () {
        setDate(addMonth($('#taskDate').val(), 1));
    });

    $("#importRateFiles").kendoUpload({
        "upload": OnAttachUpload,
        "success": OnAttachSuccess,
        "select": onSelect,
        "validation": {
            "allowedExtensions": [".xlsx"],
            "maxFileSize": 900000,
        },
        "error": OnError,
        "async": { "autoUpload": true, "saveUrl": "/Accounting/UploadPayRate" },
        "multiple": false,
        "showFileList": false
    });

    $("#exportCalculated").bind("click", function () {
        $('.k-grid-EXPORT').click();
    })

    $('#downloadTemplate').click(function () {
        kConfirm("Please Confirm","Are you sure that you want to download?").then(function () {
            var form = $("<form></form>").attr("action", "/accounting/Download").attr("method", "post");
            var token = $("[name='__RequestVerificationToken']").val();
            form.append($("<input></input>").attr("type", "hidden").attr("name", "__RequestVerificationToken").attr("value", token));
            form.appendTo('body').submit().remove();
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    })
});

function setDate(date) {
    $("#currentDate").text(kendo.toString(date, 'MMMM, yyyy'));
    $('#taskDate').val(date);
    var datepicker = $("#datepicker").data("kendoDatePicker");
    if (datepicker) {
        datepicker.value(date);
    }
    onFilterChange();
}

function OnAttachUpload(arg) {
    var dateRangeValue = kendo.toString(new Date($('#taskDate').val()), 'yyyyMM');
    var entities = $("#AccountingEntity").data("kendoMultiSelect");
    var selectedIDs = entities.value().toString();
    arg.data = { DateRange: dateRangeValue, entitiesID: selectedIDs };
}

function OnAttachSuccess(arg) {
    var entities = $("#AccountingEntity").data("kendoMultiSelect");
    var selectedIDs = entities.value().toString();
    if ([200, 299].includes(arg.response.status)) {
        kConfirm("Import Payrate Information", arg.response.detail).then(function () {
            location.href = "/accounting/index?isParticalView=true&&DateRange=" + arg.response.DateRange + "&entity=" + selectedIDs;
        }, function () {
            location.href = "/accounting/index?isParticalView=true&&DateRange=" + arg.response.DateRange + "&entity=" + selectedIDs;
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    } else {
        DisplayNotification(arg.response.detail, "error");
    }
    $('.k-upload-status').hide();
    $("#uploadIcon").removeClass("k-i-loading");
    $("#uploadIcon").addClass("k-i-upload");
    $("#uploadLbl").text("Import Payrate");
    $("#importRateFiles").data("kendoUpload").enable();
}

function onSelect(e) {
    $('.k-upload-status').remove();
    $("#uploadIcon").removeClass("k-i-upload");
    $("#uploadIcon").addClass("k-i-loading");
    $("#uploadLbl").text("Uploading...");
    $("#importRateFiles").data("kendoUpload").disable();
};

function OnError(arg) {
    $('.k-upload-status').hide();
    $("#uploadIcon").removeClass("k-i-loading");
    $("#uploadIcon").addClass("k-i-upload");
    $("#importRateFiles").data("kendoUpload").enable();
    $("#uploadLbl").text("Import Payrate");
    if (arg.XMLHttpRequest.status == '500') {
        DisplayNotification("Import file error occurred, please try again!", "error");
    }

    if (arg.XMLHttpRequest.status == "200") {
        location.href = "/accounting/index?isParticalView=true";
        DisplayNotification("Import file success!", "success");
    }
}

function btnImportPayRate(e) {
    e.preventDefault();

    var upload = $("#importRateFiles").data("kendoUpload");
    upload.upload();
}

function dataSource_error(e) {
}

function onFilterChange() {
    var grid = $("#TimesheetAccounting").data("kendoGrid");
    grid.dataSource.read();
}

function onDataFilter() {
    var dateRangeValue = kendo.toString(new Date($('#taskDate').val()), 'yyyyMM');
    var entities = $("#AccountingEntity").data("kendoMultiSelect");
    var selectedIDs = entities.value().toString();
    var obj = {
        Extra: dateRangeValue + '~' + selectedIDs
    }

    $.extend(true, obj, forgeryToken());
    return obj
}