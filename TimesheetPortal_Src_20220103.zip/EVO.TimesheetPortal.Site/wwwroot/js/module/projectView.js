﻿

$(document).ready(function () {

    function setDate(date) {
        $("#currentDate").text(kendo.toString(date, 'MMMM, yyyy'));
        $('#taskDate').val(date);
        var datepicker = $("#datepicker").data("kendoDatePicker");
        if (datepicker) {
            datepicker.value(date);
        }

        var currentDate = new Date($('#taskDate').val());
        currentDate = kendo.toString(currentDate, 'yyyyMM')
        var currentPeriodCode = $('#currentPeriodCode').val();
        var disabled = currentDate != currentPeriodCode
        ProjectViewGrid.setApproveButtonStatus(disabled);

        var accountEntityId = $("#AccountingEntity").data('kendoComboBox').value();
        if (!accountEntityId) {
            accountEntityId = 0;
            //return;
        }
        $.when($.post("/timesheet/GetExecutionSummary?periodCode=" + currentDate + "&entityId=" + accountEntityId, forgeryToken())).then(function (data) {

            generateGrid(data);

        })

        // refresh resource view
        var grid = $('#ResourceViewGrid').data('kendoGrid');
        if (grid) {
            grid.dataSource.read();
        }


    }
    setDate(new Date());
    $("#btnDate").kendoDatePicker({
        start: "year",
        depth: "year",
        format: "yyyyMM",
        change: function () {
            setDate(this.value());
        }
    });
    $('#btnPreDate').click(function () {
        setDate(addMonth($('#taskDate').val(), -1));
    });
    $('#btnNextDate').click(function () {
        setDate(addMonth($('#taskDate').val(), 1));
    });
    $('#btnDate').click(function () {
        $("#btnDate").kendoDatePicker().open();
    });

    $('#projectViewExport').click(function () {

        var tab = $("#tabstrip").data('kendoTabStrip');
        var isResource = tab.select().attr('id') == 'tabResource';
        if (isResource) {
            var grid = $('#ResourceViewGrid').data('kendoGrid');
            if (grid) {
                var currentDate = new Date($('#resourceTaskDate').val());
                currentDate = kendo.toString(currentDate, 'yyyyMM')
                grid.options.excel.fileName = 'ResourceView-' + currentDate;
                // grid.saveAsExcel();

                $('.k-grid-EXPORT').click();

            }
        } else {
            var grid = $('#projectViewGrid').data('kendoGrid');
            if (grid) {
                var currentDate = new Date($('#taskDate').val());
                currentDate = kendo.toString(currentDate, 'yyyyMM')
                grid.options.excel.fileName = 'ProjectView-' + currentDate;
                grid.saveAsExcel();

            }
        }
    })
});


function generateGrid(gridData) {

    var model = ProjectViewGrid.generateGridModel(gridData[0]);
    var columns = ProjectViewGrid.generateColumn(gridData[0]);


    var grid = $("#projectViewGrid").data('kendoGrid');
    if (grid) {
        $("#projectViewGrid").html('');
    }

    var grid = $("#projectViewGrid").kendoGrid({
        /*height: "742px",*/
        filterable: {
            extra: false,
            operators: {

                string: {
                    contains: "Contains",
                    eq: "Equal to",
                    neq: "Not equal to"

                }
            }
        },
        dataSource: {
            pageSize: 20,
            data: gridData
            , schema: {
                model: model
            }
        },

        excelExport: function (e) {
            var workbook = e.workbook;
            var sheet = workbook.sheets[0];
            for (var i = 0; i < sheet.rows.length; i++) {
                for (var ci = 0; ci < sheet.rows[i].cells.length; ci++) {
                    var row = sheet.rows[i];
                    var value = row.cells[ci].value
                    if (ci > 0) {
                        sheet.rows[i].cells[ci].hAlign = "right";
                    }
                    if (row.type == 'data') {
                        sheet.rows[i].cells[ci].value = ((value || '') + "").split("::")[0] || 0;
                    }

                    if (row.type == 'header' && ci > 0) {
                        var elem = document.createElement('div')
                        elem.innerHTML = kendo.template(value)({})
                        sheet.rows[i].cells[ci].value = elem.innerText;
                    }

                }
            }
        },
        editable: false,
        sortable: true,
        pageable: true,
        excel: {
            allPages: true
        },
        columns: columns

    });

}

function ShowDetailTemplate(data, fieldName) {
    var item = (data[fieldName] || '') + "";
    if (!item) {
        if (fieldName == 'Project') {
            return '';
        } else {
            return 0;
        }
    }
    if (fieldName == 'NoTeam') {
        return 0;
    }
    var datas = item.split("::");
    var hours = 0, teamId = 0, projectId = 0
    if (datas && datas.length == 3) {
        hours = datas[0];
        projectId = datas[1];
        teamId = datas[2]
    } else {
        return data[fieldName];
    }

    var html;
    html = kendo.format(
        "<a  style='color:blue' id = 'btnShowDetail'" + data.id + "onClick = 'onShowDetail(this,\"" + projectId + "\",\"" + teamId + "\")' href = 'javascript:void(0)' >" + hours + " </a> "
    );
    return html;
}

function onShowDetail(e, projectId, teamId) {

    var currentDate = new Date($('#taskDate').val());
    currentDate = kendo.toString(currentDate, 'yyyyMM')

    var accountEntityId = $("#AccountingEntity").data('kendoComboBox').value();
    $.when($.post("/TimeSheet/GetResourceDetail?projectId=" + projectId + "&teamId=" + teamId + "&periodCode=" + currentDate + "&entityId=" + accountEntityId, forgeryToken())).then(function (data) {
        var detailWindow = $("#resourceDetail");
        detailWindow.html('');
        detailWindow.append(data);
        detailWindow = detailWindow.kendoWindow({
            modal: true,
            title: "Hours Detail",
            visible: false,
            width: "750px",
            actions: ["Close"]
        }).data("kendoWindow");
        if (detailWindow) {
            detailWindow.center().open();
            setTimeout(function () {
                var wheight = $('#resourceDetail').parent()[0].scrollHeight / 2;
                var wWidth = $('#resourceDetail').parent()[0].scrollWidth / 2;

            }, 500)
        }
    });
}

function _generateGridModel(gridData) {
    var model = {};
    model.id = "ID";
    var fields = {};
    for (var property in gridData) {
        var propType = typeof gridData[property];

        if (propType == "number") {
            fields[property] = {
                type: "number",
                validation: {
                    required: true
                }
            };
        } else if (propType == "boolean") {
            fields[property] = {
                type: "boolean",
                validation: {
                    required: true
                }
            };
        } else if (propType == "string") {
            var parsedDate = kendo.parseDate(gridData[property]);
            if (parsedDate) {
                fields[property] = {
                    type: "date",
                    validation: {
                        required: true
                    }
                };
                dateFields.push(property);
            } else {
                fields[property] = {
                    validation: {
                        required: true
                    }
                };
            }
        } else {
            fields[property] = {
                validation: {
                    required: true
                }
            };
        }

    }
    model.fields = fields;

    return model;
};

function _formatTeamName (teamName) {
    if (!teamName) {
        teamName = "";
    }
    teamName = teamName.replace(/space/i, ' ').replace(/strike/i, '&').replace(/underline/i, '-');

    if (teams && teams.length > 0) {

        var item = teams.find(function (o) { return ((o.DeptCode || "") + o.Id).toLowerCase() == (teamName || "").replace('S', "").toLowerCase() })
        if (item && item.DeptCode) {
            var ownerName = (item.Owner || {}).DisplayName || '';
            var hiddenElement = "<input id='teamName' class='teamName' type='text' hidden='true' value='" + item.Name + " '/>" + "<div title='" + item.Name + "'> "
            teamName = hiddenElement + "<div  style='text-align:center'><span > <b>" + item.DeptCode + "</b></span></div><div style='text-align:center'><span style='text-align:center'><b> (" + ownerName + ") </b></span></div></div>";
        }
    }
    return teamName;
};
function _setApproveButtonStatus(disable) {
    var endDateStr = $('#endDate').val();
    disable = !!disable;
    if (endDateStr) {
        var endDate = new Date(endDateStr);
        if (!disable) {
            if (new Date() < endDate) {
                disable = !disable;
            }
        }
    }
    var btn = $('#btnApprove');
    if (btn) {
        btn.prop('disabled', !!disable);
    }
}

var ProjectViewGrid = {
    setApproveButtonStatus: function (disable) {
        return _setApproveButtonStatus(disable);
    },
    approveExecutive: function (type) {
        var isProject = type && type == 'project';

        var currentDate = isProject ? new Date($('#taskDate').val()) : new Date($('#resourceTaskDate').val());
        var periodCoed = kendo.toString(currentDate, 'yyyyMM')
        $.when($.post("/timesheet/ExecutiveApproval", { periodCode: periodCoed }, forgeryToken())).then(function (data) {
            if (data.Success) {
                _setApproveButtonStatus(true);
                DisplayNotification("Record approved successfully!", "success");
                window.location.reload();
            } else {
                DisplayNotification("This operation failed.", "error");
            }

        })
    },
    generateColumn: function (item) {
        if (!item) {
            return [];
        }

        var keys = Object.keys(item);
        if (!keys || keys.length < 0) {
            return []
        }

        var isNoProject = item['Project'] == 'No Project Data';
        var columns = [];
        keys.forEach(o => {

            var filterColumn = o == 'Project' ? {
                cell: {
                    operator: "contains"
                }
            } : false;

            var columnWidth = 100;
            if (o == 'Project') {
                columnWidth = 250;
            }
            if (o == 'Total') {
                columnWidth = 50;
            }
            columns.push({
                field: o,
                name: o.replace(/space/i, ' ').replace(/strike/i, '&').replace(/underline/i, '-'),
                title: _formatTeamName(o),
                filterable: filterColumn,
                sortable: o == 'Project' ? true : false,
                width: columnWidth,
                locked: o == 'Project',
                lockable: false,
                attributes: o != 'Project' ? {
                    "class": "countRightAlign"

                } : {},
                template: "#=ShowDetailTemplate(data, '" + o + "')#"
            })
        })
        return columns;
    },
    buildData: function (data) {

    },
    generateGridModel: function (data) {
        return _generateGridModel(data);
    }
};