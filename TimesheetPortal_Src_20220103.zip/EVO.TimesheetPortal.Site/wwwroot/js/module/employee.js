﻿
function onEmployeeDataBound(e) {
    var grid = $("#Employees").data("kendoGrid");
    if (grid) {
        var allRows = grid.items();
        $.each(allRows, function (index, value) {

            var item = grid.dataItem(value);
            if (item.isNew()) {
                $(value).attr('style', 'background-color: lightsalmon');
            }

        })
    }
}

$.extend(true, kendo.ui.validator, {
    rules: { // custom rules

        employeenameevalidation: function (input) {
            //check if it is the ProductName field
            if (input.is("[name=EmployeeName]")) {
                input.attr("data-EmployeeNamevalidation-msg", "Employee Name is required.");
                return !!input.val();
            }
            return true;
        },
    
        employeetitlevalidation: function (input) {
            //check if it is the ProductName field
            if (input.is("[name=EmployeeTitle]")) {
                input.attr("data-EmployeeTitlevalidation-msg", "Employee Title is required.");
                return !!input.val() && input.val() != -1 ;
            }
            return true;
        },
        jobgradevalidation: function (input) {
            //check if it is the ProductName field
            if (input.is("[name=JobGrade]")) {
                input.attr("data-JobGradevalidation-msg", "Job Grade is required.");
                return !!input.val() && input.val() != -1;
            }
            return true;
        },
        TeamItemvalidation: function (input) {
           
            //check if it is the ProductName field
            if (input.is("[name='TeamItem']")) {
                var form = !employeeFormEditor.isEdit ? $("#CreateEmployeeForm").data('kendoForm') : $("#editEmployeeForm").data('kendoForm');
                var dataRow = form.editable.options.model;
                if (dataRow && dataRow.RoleName) {
                    var roleName = (dataRow.RoleName || "").toLowerCase();
                    var roleList = ResourceRoles || ['employee', 'manager', 'teamowner'];
                    if (roleList.includes(roleName)){
                        input.attr("data-TeamItemvalidation-msg", "Team is required.");
                        return !!input.val() && input.val() != -1;
                    }
                }
               
                
            }
            return true;
        },
        DepartmentDataTextvalidation: function (input) {
            //check if it is the ProductName field
            if (input.is("[name='Department.DataText']")) {
                input.attr("data-DepartmentDataTextvalidation-msg", "Department is required.");
                return !!input.val() && input.val() != -1;
            }
            return true;
        },
        CountryDataTextvalidation: function (input) {
            //check if it is the ProductName field
            if (input.is("[name='Country.DataText']")) {
                input.attr("data-CountryDataTextvalidation-msg", "Country is required.");
                return !!input.val() && input.val() != -1;
            }
            return true;
        }
    }
});



function renderDropDownInGridCell(e) {
    if (e && e.DataText) {
        return e.DataText;
    }
    return '';
}

function renderManagerInGridCell(e) {
    if (e && e.EmployeeName) {
        return e.EmployeeName;
    }
    return '';
}


function renderText(displayText) {
    if (!displayText) {
        return ''
    }
    if (displayText && displayText.DataID <= 0) {
        return '';
    }

    return displayText.DataText || '';
}

function renderManagerText(manager) {
    if (!manager) {
        return ''
    }
    if (manager && manager.ManagerID <= 0) {
        return ''
    }

    return manager.EmployeeName || '';
}





function itemTemplate(options) {
    var field = options.field;
    var format = options.format;
    var valueField = options.valueField;

    if (field == "isNull") {
        return '';
    }


    var valueFormat = '';
    if (valueField === undefined) {
        valueField = field;
    }
    if (options.type == 'date') {
        valueFormat = ':yyyy-MM-ddTHH:mm:sszzz';
    }

    return '<li class=\'k-item\'>' + '<label class=\'k-label k-checkbox-label\'>' + '<input type=\'checkbox\' class=\'k-checkbox\' value=\'#:kendo.format(\'{0' + valueFormat + '}\',' + valueField + ')#\'/>' + '<span>#:kendo.format(\'' + (format ? format : '{0}') + '\', ' + field + ')#</span>' + '</label>' + '</li>';
}

$(document).ready(function () {

    $("#Employees").kendoTooltip({
        filter: ".tooltips",
        width: '300px',
        show: function (e) {
            if (this.content.text().length > 0) {
                this.content.parent().css("visibility", "visible");
            }
        },
        hide: function (e) {
            this.content.parent().css("visibility", "hidden");
        },
        content: function (e) {
            var dataItem = $(".k-grid").data("kendoGrid").dataItem(e.target.closest("tr"));
            if (formatLongStr(dataItem.TeamItem.DataText, 20) === e.target.html()) {
                return dataItem.TeamItem.DataText;
            } 
        }
    });

    $('.k-grid-Add').click(function () {
        employeeFormEditor.isEdit = false;
        $.when($.post("/employee/CreateEmployee", forgeryToken())).then(function (data) {
            var employeeWindow = $("#employeeList");
            var editWindow = $("#employeeEditList");
            if (editWindow) {
                editWindow.html('');
            }
            employeeWindow.html('');
            employeeWindow.append(data);
            employeeWindow = employeeWindow.kendoWindow({
                modal: true,
                title: "+Resource",
                visible: false,
                width: "600px",
                //content: data,
                actions: ["Close"]
            }).data("kendoWindow");
            if (employeeWindow) {
                employeeWindow.center().open();

                setTimeout(function () {
                    var h = window.innerHeight;
                    var w = window.innerWidth;
                    var wheight = $('#employeeList').parent()[0].scrollHeight / 2;
                    var wWidth = $('#employeeList').parent()[0].scrollWidth / 2;
                    $('#employeeList').closest(".k-window").css({
                        top: h / 2 - wheight,
                        left: w / 2 - wWidth
                    });
                }, 500)

                $('#btnCloseEmployee').click(function () {
                    var win = $('#employeeList').data("kendoWindow");
                    checkedEmployeeIds = [];
                    win.close();
                });
                employeeFormEditor.fixKendoDropdownPopup();

            }
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });


    });
})

function onResourceChange(e) {
   
    var dataItem = e.sender.dataItem();
    var form = $("#CreateEmployeeForm").data('kendoForm');
    var model = form.editable.options.model;
    model.set("Email", dataItem.Email);
    model.set("RoleName", dataItem.RoleName);

    model.set("FirstName", dataItem.FirstName);
    model.set("LastName", dataItem.LastName);
    model.set("DisplayName", (dataItem.FirstName || "") + " " + (dataItem.LastName || ""));
}


var employeeFormEditor = {
    isEdit: false,
    onFormValidateField: function (e) {
        //console.log(e);
        $("#validation-success").html("");
    },
    onFormSubmit: function (e) {
        var model = e.model;
        employeeFormEditor.submitData(model);
        e.preventDefault();
    },
    onFormCreateAndSubmit: function () {
        var validator = $("#TeamForm").kendoValidator().data("kendoValidator");
        if (validator.validate()) {
            projectFormEditor.submitData(true);
        }
    },
    onFormClear: function (e) {
        $("#validation-success").html("");
    },
    submitData: function (model) {

        //var data = {};
        var idEdit = model.ID > 0;
        if (model.TeamItem) {
            var team = { "ID": model.TeamItem.DataID, "Name": model.TeamItem.DataText };
            model.Team = team;
        }

        if (model.CountryCode) {
            var countryCode = model.CountryCode.DataID || model.CountryCode;

            model.CountryCode = countryCode;
        }
       
        model.RoleNames = [model.RoleName];
        //var ownerCombox = $("input[name='Owner.ID']").data('kendoComboBox');
       // model.Owner.ID = $("#TeamOwner").val() || model.TeamOwner;
        $.when($.ajax({
            url: "/Employee/Save",
            type: "POST",
            data: model
        })).then(function (data) {
            var grid = $('#Employees').data('kendoGrid');
            grid.dataSource.read();
            var window = !idEdit ?  $("#employeeList").data("kendoWindow") : $("#employeeEditList").data("kendoWindow") ;
            window.close();

            DisplayNotification("Save successfully.", "success");
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    },
    onWindowClose: function () {
        var grid = $('#Employees').data('kendoGrid');
        grid.dataSource.read();
    },
    onEdit: function (e) {
        
        var self = e;
        var grid = $(".k-grid").data("kendoGrid");
        var item = grid.dataItem($(self).closest("tr"));
        employeeFormEditor.isEdit = true;
        $.when($.post("/employee/EditEmployee?id=" + item.ID, forgeryToken())).then(function (data) {
            var employeeWindow = $("#employeeList");
            if (employeeWindow) {
                window.html('');
            }
            var window = $("#employeeEditList");
          
            window.html('');
            window.append(data);
            window = window.kendoWindow({
                modal: true,
                title: "Update Employee",
                visible: false,
                width: "600px",
                //content: data,
                actions: ["Close"]
            }).data("kendoWindow");
            if (window) {
                window.center().open();

                setTimeout(function () {
                    var h = window.innerHeight;
                    var w = window.innerWidth;
                    var wheight = $('#employeeEditList').parent()[0].scrollHeight / 2;
                    var wWidth = $('#employeeEditList').parent()[0].scrollWidth / 2;
                    $('#employeeEditList').closest(".k-window").css({
                        top: h / 2 - wheight,
                        left: w / 2 - wWidth
                    });
                }, 500)

                $('#btnCloseTeam').click(function () {
                    var win = $('#employeeEditList').data("kendoWindow");

                    win.close();
                });

            }
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    },
    onDataBound: function (e) {
        var grid = $(".k-grid").data("kendoGrid");
        var data = grid.dataSource.data();
        $.each(data, function (i, row) {
           
            var des = $('tr[data-uid="' + row.uid + '"]').find("[id*='_action_for_']");
            if (des.length == 1) {
                ActionMenuMaker.MakeMenu(des[0]);
            }

        });
    },
    /*workaround for the BUG 237640:
     for the dropdown editor if different form(f.g. Create and Edit in this case) has same fields, open the these forms, 
     then click on the label on the form last opened, the dropdown content window popups on the left top corner.*/
    fixKendoDropdownPopup: function () {
        $('label[for="JobGradeId"]').attr('for', '');
        $('label[for="TeamItem"]').attr('for', '');
        $('label[for="Manager"]').attr('for', '');
        $('label[for="CountryCode"]').attr('for', '');
    }
};


var ActionMenuMaker = (function () {
    /* Use bootstrap dropdown menu to construct the ActionOption Menu */
    var _popup = function (name, value, extra) {
        // Logic for preparing element that will link a "Popup" goes here
        var item = $('<button class="btn btn-default btn-sm dropdown-item" type="button">' + name + '</button>');
        item.on('click', function () {
            if (value.split(':')[0] === 'edit') {
                employeeFormEditor.isEdit = true;
                $.when($.post("/employee/EditEmployee?id="  + value.split(':')[1], forgeryToken())).then(function (data) {
                    var window = $("#employeeEditList");
                    window.html('');
                    window.append(data);
                    window = window.kendoWindow({
                        modal: true,
                        title: "Update Employee",
                        visible: false,
                        width: "600px",
                        //content: data,
                        actions: ["Close"]
                    }).data("kendoWindow");
                    if (window) {
                        window.center().open();

                        setTimeout(function () {
                            var h = window.innerHeight;
                            var w = window.innerWidth;
                            var wheight = $('#employeeEditList').parent()[0].scrollHeight / 2;
                            var wWidth = $('#employeeEditList').parent()[0].scrollWidth / 2;
                            $('#employeeEditList').closest(".k-window").css({
                                top: h / 2 - wheight,
                                left: w / 2 - wWidth
                            });
                        }, 500)

                        $('#btnCloseTeam').click(function () {
                            var win = $('#employeeEditList').data("kendoWindow");

                            win.close();
                        });
                        employeeFormEditor.fixKendoDropdownPopup();
                    }
                }, function (e) {
                    DisplayNotification("Connot connect to the Server", "warning");
                });
            }
        });
        return item;
    };
    var _redirect = function (name, value, extra) {
        // Logic for preparing element that will "Redirect" to a new page goes here
        var item = $('<a class="dropdown-item" href="#">' + name + '</a>');
        item.on('click', function () {
           
        });
        return item;
    };
    var _formpost = function (name, value, extra) {
        // Logic for preparing element that will result a "Form Post" goes here
        var item = $('<a class="dropdown-item" href="#">' + name + '</a>');
        item.on('click', function () {
            $.when($.post("/employee/Delete?id=" + value.split(':')[1], forgeryToken())).then(function (data) {
                DisplayNotification("Delete successfully!", "success");
                var grid = $('#Employees').data('kendoGrid');
                grid.dataSource.read();
            }, function (e) {
                DisplayNotification("Connot connect to the Server", "warning");
            });
        });
        return item;
    };
    return {
        MakeMenu: function (ele) {
            var arr = JSON.parse($(ele).attr("data-options"));
            if (arr.length > 0) {
                var id = "ActionOption" + ele.id.substring(ele.id.lastIndexOf("_"), ele.length);
                var div = $('<div class="dropdown" />');
                div.hover(function () {
                    $('.k-i-gear', this).trigger('click');
                });
                // var btn = $('<button class="btn btn-info btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="' + id + '">Action</button>');
                var btn = $('<span class="k-icon k-i-gear dropdown-toggle.caret-off" ' +
                    'data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id = "' + id + '" /> ');
                div.append(btn);

                var menuitem = $('<div class="dropdown-menu" aria-labelledby="' + id + '" />');
                menuitem.append($('<h4 class="dropdown-header">Action</h4>'));
                menuitem.append($('<div class="dropdown-divider" />'));
                arr.forEach(function (o) {
                    switch (o.T) {
                        case 1: // popup
                            menuitem.append(_popup(o.N, o.V, o.E));
                            break;
                        case 2: // redirect
                            menuitem.append(_redirect(o.N, o.V, o.E));
                            break;
                        case 3:  // form post
                            menuitem.append(_formpost(o.N, o.V, o.E));
                            break;
                        default:
                            break
                    }
                })
                div.append(menuitem);

                $(ele).append(div);
            }
        }
    }
})();





