﻿
function AllowEditable(dataItem) {
    return dataItem.Editable || dataItem.isNew() || dataItem.id > 0;
}

function isNewAllowTeamOwnerEditable(dataItem) {
    return dataItem.isNew() || isAdmin;
}

(function ($, kendo) {
    $.extend(true, kendo.ui.validator, {
        rules: { // custom rules
            namevalidation: function (input, params) {
                var retValue = false;
                if (input.is("[name='Name']") && input.val() != "") {
                    input.attr("data-namevalidation-msg", "Team Name is existing.");
                    $.ajax(
                        {
                            url: "/Team/CheckTeamName?name=" + input.val(),
                            type: 'get',
                            dataType: "json",
                            contentType: 'application/json; charset=utf-8',
                            async: false,
                            success: function (result) {
                                retValue = !result;
                            },
                            error: function (e) {
                                return true;
                            }
                        });
                    return retValue;
                } else {
                    return true;
                }
            },
                     
            OwnerIdvalidation: function (input, params) {
                if (input.is("[name='Owner.ID_input']")) {
                    input.attr("data-OwnerIdvalidation-msg", "Owner is required.");
                    return !!input.val() && input.val() != -1 && input.val() != "";
                }
                return true;
            },
            IsActivevalidation: function (input, params) {
                if (input.is("[name='IsActive']")) {
                  
                    var form = $("#EditTeam").data('kendoForm');
                    var retValue = true;
                    if (form) {
                        var datarow =  form.editable.options.model;
                        if (datarow && datarow.ID > 0) {
                            //var checkBox = $("input:hidden[name=IsActive]");
                            
                                if (datarow.IsActive == datarow.dirtyFields.IsActive) { // check whether can do deactive

                                    input.attr("data-IsActivevalidation-msg", "A team with one or more employees cannot be deactivated.");
                                    $.ajax(
                                        {
                                            url: "/Team/CheckTeamDeactive?teamID=" + datarow.ID,
                                            type: 'get',
                                            dataType: "json",
                                            contentType: 'application/json; charset=utf-8',
                                            async: false,
                                            success: function (result) {
                                                retValue = !result;
                                            },
                                            error: function (e) {
                                                return true;
                                            }
                                        });
                                }
                          
                        }
                    }
                    return retValue;
                }
                return true;
            }

        }
   
    });
})(jQuery, kendo);


$(document).ready(function () {
    $('.k-grid-Add').click(function () {
        var grid = $(".k-grid").data("kendoGrid");
        $.when($.post("/team/CreateTeam", forgeryToken())).then(function (data) {
            var teamWindow = $("#teamForm");
            teamWindow.html('');
            teamWindow.append(data);
            teamWindow = teamWindow.kendoWindow({
                modal: true,
                title: "+Team",
                visible: false,
                width: "600px",
                //content: data,
                actions: ["Close"]
            }).data("kendoWindow");
            if (teamWindow) {
                teamWindow.center().open();

                setTimeout(function () {
                    var h = window.innerHeight;
                    var w = window.innerWidth;
                    var wheight = $('#teamForm').parent()[0].scrollHeight / 2;
                    var wWidth = $('#teamForm').parent()[0].scrollWidth / 2;
                    $('#teamForm').closest(".k-window").css({
                        top: h / 2 - wheight,
                        left: w / 2 - wWidth
                    });
                }, 500)

                $('#btnCloseTeam').click(function () {
                    var win = $('#teamForm').data("kendoWindow");
                   
                    win.close();
                });

            }
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    });
});

var teamFormEditor = {

    onFormValidateField: function (e) {
      
        $("#validation-success").html("");
    },
    onFormSubmit: function (e) {
        var model = e.model;
        teamFormEditor.submitData(model);
        e.preventDefault();
    },
    onFormCreateAndSubmit: function () {
        var validator = $("#TeamForm").kendoValidator().data("kendoValidator");
        if (validator.validate()) {
            projectFormEditor.submitData(true);
        }
    },
    onFormClear: function (e) {
        $("#validation-success").html("");
    },
    submitData: function (model) {
      
        var idEdit = model.ID > 0;
        var url = idEdit ? "/Team/Update" : "/Team/Create"
        //var ownerCombox = $("input[name='Owner.ID']").data('kendoComboBox');
        //model.Owner = model.Owner || {};
        //model.Owner.ID = $("#TeamOwner").val() || model.TeamOwner;
        if (model.DeptCode) {
            model.DeptCode = $("#DeptCode").val();
        }
      
        $.when($.ajax({
            url: url,
            type: "POST",
            data: model
        })).then(function (data) {
            var grid = $('#Teams').data('kendoGrid');
            grid.dataSource.read();
            var projectWindow = $("#teamForm").data("kendoWindow");
            projectWindow.close();
            DisplayNotification("Save successfully.", "success");
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    },
    onWindowClose: function () {
        var grid = $('#team').data('kendoGrid');
        grid.dataSource.read();
    },
    onEdit: function (e) {
        var self = e;
        var grid = $(".k-grid").data("kendoGrid") || $(".k-treelist").data("kendoTreeList");
        var item = grid.dataItem($(self).closest("tr"));
        $.when($.post("/team/EditTeam?id="+item.ID, forgeryToken())).then(function (data) {
            var teamWindow = $("#teamForm");
            teamWindow.html('');
            teamWindow.append(data);
            teamWindow = teamWindow.kendoWindow({
                modal: true,
                title: "Update Team",
                visible: false,
                width: "600px",
                //content: data,
                actions: ["Close"]
            }).data("kendoWindow");
            if (teamWindow) {
                teamWindow.center().open();

                setTimeout(function () {
                    var h = window.innerHeight;
                    var w = window.innerWidth;
                    var wheight = $('#teamForm').parent()[0].scrollHeight / 2;
                    var wWidth = $('#teamForm').parent()[0].scrollWidth / 2;
                    $('#teamForm').closest(".k-window").css({
                        top: h / 2 - wheight,
                        left: w / 2 - wWidth
                    });
                }, 500)

                $('#btnCloseTeam').click(function () {
                    var win = $('#teamForm').data("kendoWindow");

                    win.close();
                });

            }
        }, function (e) {
            DisplayNotification("Connot connect to the Server", "warning");
        });
    }
};


function setReadEditor(container, options) {
    
    var item = options.model;
    var field = options.field;
    var name = item[field] || '';
    container.append($("<label class='k-label k-form-label' >" + name + " </label>"));
}

function setManagerReadEditor(container, options) {

    var item = options.model;
    var field = options.field;
    var name = item.Manager.DisplayName || '';
    container.append($("<label>" + name + " </label>"));
}

function onSaveChanges(e) {
    var valid = true;
    var grid = $(".k-grid").data("kendoGrid");
    var rows = grid.tbody.find("tr");
    grid.options.editable.mode = "inline"
    var model = grid.dataItem(rows[0]);
    if (model && model.isNew()) {
        grid.editRow(rows[0]);
        var cols = $(rows[0]).find("td");
        for (var j = 0; j < cols.length; j++) {
            if (!grid.editable.validatable.options.rules.projectType_datatextvalidation($(cols[j]).find('input'))) {
                valid = false;
                break;
            }
        }
    }
    if (!valid) {
        e.preventDefault(true);
    } else {
        $('.k-grid-add').attr('disabled', false);
    }
    grid.options.editable.mode = "incell"
}



function itemTemplate(options) {
    var field = options.field;
    var format = options.format;
    var valueField = options.valueField;

    if (field == "isNull") {
        return '';
    }

    var valueFormat = '';
    if (valueField === undefined) {
        valueField = field;
    }
    if (options.type == 'date') {
        valueFormat = ':yyyy-MM-ddTHH:mm:sszzz';
    }

    return '<li class=\'k-item\'>' + '<label class=\'k-label k-checkbox-label\'>' + '<input type=\'checkbox\' class=\'k-checkbox\' value=\'#:kendo.format(\'{0' + valueFormat + '}\',' + valueField + ')#\'/>' + '<span>#:kendo.format(\'' + (format ? format : '{0}') + '\', ' + field + ')#</span>' + '</label>' + '</li>';
}

function onCellClose(e) {

    var model = e.model
    var container = e.container;
    if (model.dirtyFields.ManagerOne) {
        container.addClass("k-dirty-cell");
        model.dirtyFields["ManagerOne.EmployeeName"] = true;
    }
    if (model.dirtyFields.ManagerTwo) {
        container.addClass("k-dirty-cell");
        model.dirtyFields["ManagerTwo.EmployeeName"] = true;
    }

    if (model.dirtyFields.Owner) {
        container.addClass("k-dirty-cell");
        model.dirtyFields["Owner.EmployeeName"] = true;
    }

}

function BuildManagerItem() {
    var form = $("#EditTeam").data('kendoForm');

    if (form) {
        var datarow = form._model || {};
        var manager = datarow.Manager || {};
        return {
            text: manager.DisplayName,
            Id: manager.ID,
            isEdit: true
        }
    }
}