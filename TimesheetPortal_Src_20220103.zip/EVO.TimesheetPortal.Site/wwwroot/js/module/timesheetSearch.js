﻿var isFirstLoad = true;
$(document).ready(function () {
    setDate(new Date());
    $("#btnDate").kendoDatePicker({
        start: "year",
        depth: "year",
        format: "yyyyMM",
        change: function () {
            setDate(this.value());
        }
    });
    $('#btnPreDate').click(function () {
        setDate(addMonth($('#taskDate').val(), -1));
    });
    $('#btnNextDate').click(function () {
        setDate(addMonth($('#taskDate').val(), 1));
    });
    $('#btnDate').click(function () {
        $("#btnDate").kendoDatePicker().open();
    });
 
    $("#timesheet").kendoTooltip({
        filter: ".tooltips",
        width: '300px',
        show: function (e) {
            if (this.content.text().length > 0) {
                this.content.parent().css("visibility", "visible");
            }
        },
        hide: function (e) {
            this.content.parent().css("visibility", "hidden");
        },
        content: function (e) {
            var dataItem = $(".k-grid").data("kendoGrid").dataItem(e.target.closest("tr"));
            if (formatLongStr(dataItem.Team, 20) === e.target.html()) {
                return dataItem.Team;
            } else if (formatLongStr(dataItem.Description, 20) === e.target.html()) {
                return dataItem.Description;
            } else if (formatLongStr(dataItem.Project.Phase, 20) === e.target.html()) {
                return dataItem.Project.Phase;
            } else if (formatLongStr(dataItem.Name, 20) === e.target.html()) {
                return dataItem.Name;
            } else if (formatLongStr(dataItem.Project.Type, 20) === e.target.html()) {
                return dataItem.Project.Type;
            }
            return '';
        }
    });
 
});

function error_handler(e) {
    if (e.errors) {
        var message = "Errors:\n";
        $.each(e.errors, function (key, value) {
            if ('errors' in value) {
                $.each(value.errors, function () {
                    message += this + "\n";
                });
            }
        });
        alert(message);
    }
}

 
 
function setDate(date) {
    $("#currentDate").text(kendo.toString(date, 'MMMM, yyyy'));
    $('#taskDate').val(date);
    var datepicker = $("#datepicker").data("kendoDatePicker");
    if (datepicker) {
        datepicker.value(date);
    }
    if (!isFirstLoad) {
        onReloadGridDataSource();
    }
    isFirstLoad = false;
   
}

function onReloadGridDataSource() {
    var grid = $("#timesheet").data("kendoGrid");
    grid.dataSource.read();
}

function onDataFilter() {
    var periodCode = kendo.toString(new Date($('#taskDate').val()), 'yyyyMM');
    if (!$('#taskDate').val()) {
        periodCode = kendo.toString(new Date(), 'yyyyMM')
    }
    var obj = {
        periodCode: periodCode
    }
    return compoundObjectWithForgeryToken(obj);
}