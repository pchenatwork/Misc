﻿using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Internal;
using System;
using System.Threading;
using System.Threading.Tasks;
using TimeSheetTrackerServiceReference;

namespace EVO.TimesheetPortal.Site.App_Classes.Cache
{
    public class RestClientCache : IDistributedCache
    {
        private ITimeSheetTracker TimesheetTrackerClient;

        private readonly TimeSpan _defaultSlidingExpiration = TimeSpan.FromSeconds(30);

        private readonly ISystemClock _systemClock = new SystemClock();
        private readonly TimeSpan _expiredItemsDeletionInterval = TimeSpan.FromMinutes(30);
        private DateTimeOffset _lastExpirationScan;
        private readonly Action _deleteExpiredCachedItemsDelegate;

        public RestClientCache(ITimeSheetTracker timeSheetTracker)
        {
            TimesheetTrackerClient = timeSheetTracker;
            _deleteExpiredCachedItemsDelegate = DeleteExpiredCacheItems;
        }

        public byte[] Get(string key)
        {
            if (key == null)
            {
                throw new ArgumentNullException(nameof(key));
            }

            var data = TimesheetTrackerClient.GetCache(key);
            ScanForExpiredItemsIfRequired();
            return data;
        }

        public async Task<byte[]> GetAsync(string key, CancellationToken token = default)
        {
            if (key == null)
            {
                throw new ArgumentNullException(nameof(key));
            }

            token.ThrowIfCancellationRequested();

            var value = await TimesheetTrackerClient.GetCacheAsync(key).ConfigureAwait(false);

            ScanForExpiredItemsIfRequired();

            return value;
        }

        public void Refresh(string key)
        {
            if (key == null)
            {
                throw new ArgumentNullException(nameof(key));
            }
            TimesheetTrackerClient.RefreshCache(key);
            ScanForExpiredItemsIfRequired();
        }

        public async Task RefreshAsync(string key, CancellationToken token = default)
        {
            if (key == null)
            {
                throw new ArgumentNullException(nameof(key));
            }
            await TimesheetTrackerClient.RefreshCacheAsync(key).ConfigureAwait(false);
            ScanForExpiredItemsIfRequired();
        }

        public void Remove(string key)
        {
            if (key == null)
            {
                throw new ArgumentNullException(nameof(key));
            }

            TimesheetTrackerClient.RemoveCache(key);
            ScanForExpiredItemsIfRequired();
        }

        public async Task RemoveAsync(string key, CancellationToken token = default)
        {
            if (key == null)
            {
                throw new ArgumentNullException(nameof(key));
            }

            token.ThrowIfCancellationRequested();

            await TimesheetTrackerClient.RemoveCacheAsync(key).ConfigureAwait(false);
            ScanForExpiredItemsIfRequired();
        }

        public void Set(string key, byte[] value, DistributedCacheEntryOptions options)
        {
            if (key == null)
            {
                throw new ArgumentNullException(nameof(key));
            }

            if (value == null)
            {
                throw new ArgumentNullException(nameof(value));
            }
            if (options == null)
            {
                options = new DistributedCacheEntryOptions();
                GetOptions(ref options);
            }
            TimesheetTrackerClient.SetCache(key, value, options.SlidingExpiration.Value.Ticks, options.AbsoluteExpiration);
            ScanForExpiredItemsIfRequired();
        }

        public async Task SetAsync(string key, byte[] value, DistributedCacheEntryOptions options, CancellationToken token = default)
        {
            if (key == null)
            {
                throw new ArgumentNullException(nameof(key));
            }

            if (value == null)
            {
                throw new ArgumentNullException(nameof(value));
            }
            if (options == null)
            {
                options = new DistributedCacheEntryOptions();
                GetOptions(ref options);
            }
            await TimesheetTrackerClient.SetCacheAsync
                (key, value, (long)options.SlidingExpiration.GetValueOrDefault().TotalSeconds, options.AbsoluteExpiration);
            ScanForExpiredItemsIfRequired();
        }

        private void GetOptions(ref DistributedCacheEntryOptions options)
        {
            if (!options.AbsoluteExpiration.HasValue
                && !options.AbsoluteExpirationRelativeToNow.HasValue
                && !options.SlidingExpiration.HasValue)
            {
                options = new DistributedCacheEntryOptions()
                {
                    SlidingExpiration = _defaultSlidingExpiration
                };
            }
        }

        private void ScanForExpiredItemsIfRequired()
        {
            var utcNow = _systemClock.UtcNow;
            // TODO: Multiple threads could trigger this scan which leads to multiple calls to database.
            if ((utcNow - _lastExpirationScan) > _expiredItemsDeletionInterval)
            {
                _lastExpirationScan = utcNow;
                Task.Run(_deleteExpiredCachedItemsDelegate);
            }
        }

        private void DeleteExpiredCacheItems()
        {
            TimesheetTrackerClient.RemoveExpiredCache(null);
        }
    }

    public static class RestClientCacheingServicesExtensions
    {
        public static IServiceCollection AddDistributedRestClientCache(this IServiceCollection services, Action<DistributedCacheEntryOptions> setupAction)
        {
            if (services == null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            if (setupAction == null)
            {
                throw new ArgumentNullException(nameof(setupAction));
            }

            services.AddOptions();
            AddRestClientCacheServices(services);
            services.Configure(setupAction);

            return services;
        }

        // to enable unit testing
        public static void AddRestClientCacheServices(IServiceCollection services)
        {
            services.Add(ServiceDescriptor.Singleton<IDistributedCache, RestClientCache>());
        }
    }
}