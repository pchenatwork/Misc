﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace EVO.TimesheetPortal.Site.App_Classes
{
    public class AuthHeaderHandler: DelegatingHandler
    {
        private readonly IConfiguration _configuration;
      
        public AuthHeaderHandler(IConfiguration configuration)
        {
            this._configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
           
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var key = _configuration.GetValue<string>("APIKey");

            //potentially refresh token here if it has expired etc.

            request.Headers.Add("Authorization", key);
           
            return await base.SendAsync(request, cancellationToken).ConfigureAwait(false);
        }
    }
}
