﻿using Microsoft.AspNetCore.Http;

namespace EVO.TimesheetPortal.Site
{
    public class ApplicationContext
    {
        public static IHttpContextAccessor Accessor;

        public static HttpContext Current
        {
            get { return Accessor.HttpContext; }
        }
    }
}