﻿using EasyCaching.Core;
using EasyCaching.Interceptor.AspectCore;
using EmailService;
using EVO.TimesheetPortal.Site.App_Classes;
using EVOUserWSServiceReference;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using MoreLinq;
using Newtonsoft.Json.Serialization;
using Refit;
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceModel;

namespace EVO.TimesheetPortal.Site
{
    public class Startup
    {
        public Startup(IWebHostEnvironment env, IConfiguration configuration)
        {
            Env = env;
            Configuration = configuration;
        }

        public IWebHostEnvironment Env { get; set; }
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            IMvcBuilder builder = services.AddRazorPages();

#if DEBUG
            if (Env.IsDevelopment())
            {
                builder.AddRazorRuntimeCompilation();
            }
#endif
            var assemblies = Assembly.GetExecutingAssembly().GetTypes().Where(type => type.Name.EndsWith("Service")
                && !type.Name.Contains("Configuration")
                && !type.Name.StartsWith("I"));
            assemblies.ForEach(type => services.TryAddScoped(type));

            //services.TryAddScoped<ISettingsService, SettingsService>();

            services.AddEasyCaching(options =>
            {
                options.UseInMemory(config =>
                {
                    config.MaxRdSecond = 0;
                    config.EnableLogging = true;
                },
                "timesheetcache"
               );
            });

            services
                .AddResponseCompression((option) =>
                {
                    option.EnableForHttps = true;
                })
                .AddControllersWithViews(option =>
                {
                    //option.Filters.Add()
                })
                .SetCompatibilityVersion(CompatibilityVersion.Version_3_0)
                // Maintain property names during serialization. See:
                // https://github.com/aspnet/Announcements/issues/194
                .AddNewtonsoftJson(options =>
                {
                    options.SerializerSettings.ContractResolver = new DefaultContractResolver();
                    options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
                }
                );

            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddHttpContextAccessor();

            services.TryAddTransient<IEVOUserWS>(provider =>
            {
                var userAddress = Configuration.GetValue<string>("TimeSheetWCF:UserAddress");
                var isHttps = userAddress.ToLower().IndexOf("https") > -1;

                BasicHttpBinding binding = new BasicHttpBinding(BasicHttpSecurityMode.Transport);
                binding.MaxReceivedMessageSize = 2147483647;
                binding.MaxBufferPoolSize = 2147483647;

                var client = isHttps ? new EVOUserWSClient(binding, new EndpointAddress(userAddress)) : new EVOUserWSClient(EVOUserWSClient.EndpointConfiguration.BasicHttpBinding_IEVOUserWS);
                client.Endpoint.Address = new System.ServiceModel.EndpointAddress(userAddress);

                return client;
            });

            services.TryAddTransient<EmailServiceSoapClient>(provider =>
            {
                var emailAddress = Configuration.GetValue<string>("TimeSheetWCF:EmailAddress");
                var isHttps = emailAddress.ToLower().IndexOf("https") > -1;

                BasicHttpBinding binding = new BasicHttpBinding(BasicHttpSecurityMode.Transport);
                binding.MaxReceivedMessageSize = 2147483647;
                binding.MaxBufferPoolSize = 2147483647;

                var client = isHttps ? new EmailServiceSoapClient(binding, new EndpointAddress(emailAddress)) : new EmailServiceSoapClient(EmailServiceSoapClient.EndpointConfiguration.EmailServiceSoap);
                client.Endpoint.Address = new System.ServiceModel.EndpointAddress(emailAddress);

                return client;
            });

            //services.AddDistributedRestClientCache(c=>c.AbsoluteExpirationRelativeToNow = TimeSpan.FromDays(1));

            services.AddAuthentication("CookieAuthentication")
                 .AddCookie("CookieAuthentication", config =>
                 {
                     config.Cookie.Name = "TimeSheetTrackerCookie";
                     config.LoginPath = Configuration.GetValue<string>("Application:DefualtLogin") ?? "/Login/UserLogin";
                     config.Cookie.HttpOnly = true;
                     // config.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
                 })
                ;
            services.AddSession(options =>
            {
                options.Cookie.Name = "TimeSheetTrackerSession";
                options.IdleTimeout = System.TimeSpan.FromSeconds(Configuration.GetValue<double>("Application:TimeOut"));
            });

            services.ConfigureAspectCoreInterceptor(options => options.CacheProviderName = EasyCachingConstValue.DefaultInMemoryName);
            services.AddTransient<AuthHeaderHandler>();
            //Register Rpc service
            var refitSettings = new RefitSettings(new SystemTextJsonContentSerializer());

            var rpcLibs = Assembly.GetExecutingAssembly().GetTypes().Where(type => type.Name.EndsWith("Service")
               && type.Name.StartsWith("I"));
            var userAddress = Configuration.GetValue<string>("TimeSheetWCF:ApiAddress");
            rpcLibs.ForEach(type =>
            {
                var clientBuilder = services.AddRefitClient(type, refitSettings).SetHandlerLifetime(TimeSpan.FromMinutes(2));
                clientBuilder = clientBuilder.ConfigureHttpClient(client => client.BaseAddress = new Uri(userAddress))
                .AddHttpMessageHandler<AuthHeaderHandler>(); 
            });

            // Add Kendo UI services to the services container
            services.AddKendo();

            services.AddDataProtection()
              .PersistKeysToFileSystem(new DirectoryInfo(Path.GetFullPath("./logs/")));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IHttpContextAccessor accessor)
        {
            ApplicationContext.Accessor = accessor;
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseBrowserLink();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseResponseCompression();
            app.UseStatusCodePagesWithReExecute("/Home/StatusCode", "?code={0}");
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();
            app.UseSession();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Login}/{action=UserLogin}/{id?}");

                endpoints.MapControllerRoute(
                   name: "default",
                   pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }

    /// <summary>
    /// Global static data/info
    /// </summary>
    public static class INFO
    {
        private static readonly string _bt;

        static INFO()
        {
            FileInfo fi = new FileInfo(Assembly.GetExecutingAssembly().Location);
            _bt = fi.LastWriteTime.ToShortDateString() + " " + fi.LastWriteTime.ToLongTimeString();
        }

        public static string LAST_MODIFIED => _bt;
    }
}