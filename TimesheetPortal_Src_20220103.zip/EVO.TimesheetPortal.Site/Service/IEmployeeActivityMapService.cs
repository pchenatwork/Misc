﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Refit;
using EVO.TimesheetPortal.Entity;
using Microsoft.AspNetCore.Mvc;

namespace EVO.TimesheetPortal.Site.Service
{
    public interface IEmployeeActivityMapService : IService
    {
        [Get("/api/EmployeeActivityMap")]
        Task<ApiResponse<List<EmployeeActivityMap>>> SearchAsync([FromQuery] EmployeeActivityMap activityMap);

        [Post("/api/EmployeeActivityMap")]
        Task<ApiResponse<int>> InsertAsync([FromBody] EmployeeActivityMap activityMap);

        [Put("/api/EmployeeActivityMap")]
        Task<ApiResponse<int>> SaveAsync([FromBody] EmployeeActivityMap activityMap);

        [Delete("/api/EmployeeActivityMap")]
        Task<ApiResponse<bool>> DeleteAsync(int id);

        [Get("/api/EmployeeActivityMap/get")]
        Task<EmployeeActivityMap> GetAsync(int id);
    }
}
