﻿using EVO.TimesheetPortal.Entity;
using Refit;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Service
{
    public interface IAccountingService : IService
    {
        [Get("/api/accounting/search")]
        Task<ApiResponse<IList<TimeSheetAccounting>>> SearchAsync(string periodCode, string entitiesID);
    }
}