﻿using EVO.TimesheetPortal.Entity;
using Refit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Site.Service
{
    public interface IProjectService : IService
    {
        [Post("/api/project/search")]
        Task<ApiResponse<List<Project>>> SearchAsync(Project entity);

        [Get("/api/project/get")]
        Task<ApiResponse<Project>> GetAsync(int Id);

        [Post("/api/project/save")]
        Task<ApiResponse<Project>> SaveAsync(Project entity);

        [Get("/api/project/delete")]
        Task<ApiResponse<bool>> DeleteAsync(int Id);

        [Get("/api/project/approve")]
        Task<ApiResponse<bool>> ApproveAsync(int Id);

        [Get("/api/project/reject")]
        Task<ApiResponse<bool>> RejectAsync(int Id);
        [Post("/api/project/updatestatus")]
        Task<ApiResponse<bool>> UpdateStatusAsync(WorkflowHistory workflowHistory);
    }
}
