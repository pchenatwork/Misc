﻿using EVO.TimesheetPortal.Site.App_Classes;
using EVO.TimesheetPortal.Site.Models;
using EVOUserWSServiceReference;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MoreLinq;
using Refit;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.BusinessLogic;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Numeric;

namespace EVO.TimesheetPortal.Site.Service
{
    public class EmployeeService
    {

        private readonly IEVOUserWS UserManagementClient;

        private readonly IConfiguration Configuration;

        private readonly IEmployeeService Service;

        private readonly ITeamService TeamService;

        private readonly ISettingService SettingService;

        public EmployeeService(IEVOUserWS userManagementClient, IConfiguration configuration, IEmployeeService service,ITeamService teamService,ISettingService settingService)
        {
            UserManagementClient = userManagementClient;
            Configuration = configuration;
            Service = service;
            TeamService = teamService;
            SettingService = settingService;
        }


        public async Task<List<EmployeeSearchModel>> GetUserListByAppName(string roleName)
        {
            var employeeSearchList = new List<EmployeeSearchModel>();
            try
            {
                var result = await UserManagementClient.GetUsersByRoleNameAsync(string.Empty, ApplicationSession.ApplicationName);

                result.ForEach(user =>
                {
                    employeeSearchList.Add(new EmployeeSearchModel()
                    {
                        UserID = user.UserID,
                        UserName = user.UserName,
                        FirstName = user.FirstName,
                        MiddleName = user.MiddleName,
                        LastName = user.LastName,
                        Email = user.Email,
                        RoleName = user.Roles == null ? "" : user.Roles.RoleName
                    });
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeSearchList;
        }


        public async Task<EmployeeModel> GetEmployeeById (int id)
        {
            var result = await Service.GetAsync(id);
            return EmployeeModel.EntityToModel(result.Content);
        }

        public async Task<List<EmployeeModel>> GetList(int ownerID = 0)
        {
            var result = await Service.SearchAsync(new Employee()); ;
            var emmployees = result.Content;
            return EmployeeModel.MapEntitysToModels(emmployees.ToList()).ToList();
        }

        public async Task<List<EmployeeModel>> GetListForManagerApproval(int FinderId)
        {
            var result = await Service.FindForManagerApprovalAsync(FinderId); ;
            var employees = result.Content;
            if (employees != null)
            {
                return EmployeeModel.MapEntitysToModels(employees.ToList()).ToList();
            }
            else 
            {
                return new List<EmployeeModel>();
            }
           
        }

        public async Task<List<EmployeeModel>> GetListByTeam(int TeamID = 0)
        {
            var search = new Employee();
            if (TeamID != 0)
            {
                search.Team = new Team { Id = TeamID };
            }
            var result = await Service.SearchAsync(search);
            var emmployees = result.Content;
            return EmployeeModel.MapEntitysToModels(emmployees.ToList()).ToList();
        }

        public async Task<List<EmployeeModel>> GetListByEntity(Employee employee)
        {
            employee = employee ?? new Employee();
            var result = await Service.SearchAsync(employee);
            var emmployees = result.Content;
            return EmployeeModel.MapEntitysToModels(emmployees.ToList()).ToList();
        }

        public async Task<List<DropDownItemModel>> GetAllResource()
        {
            var result = await Service.SearchAsync(new Employee());
            var emmployees = result.Content;

            var list = emmployees.ToList().Select(s => new DropDownItemModel { DataID = s.Id, DataText = s.DisplayName });
            return list.ToList(); 
        }


        


        public async Task<List<EmployeeSearchModel>> PopulateEmployeeSearchData()
        {
            var result = await GetUserListByAppName("");
            var employeeList = await GetList(0);

            result.ForEach(user =>
            {
                var employee = employeeList.Find(o => o.IsActive && (o.DisplayName.Equals(user.UserName, StringComparison.InvariantCultureIgnoreCase) || o.UserId.Equals(user.UserName, StringComparison.InvariantCultureIgnoreCase)));
                if (employee != null)
                {
                    user.IsAdd = true;
                }
            });
            return result.Where(o => !o.IsAdd).ToList();
        }


        public async Task<List<TeamDropDownItemModel>> GetTeams(int? ownerID)
        {
            var list = new List<TeamDropDownItemModel>();
            var teamEntity = new TeamCriteria();
            var result = await TeamService.SearchAsync(teamEntity);
            var teamList = result.Content;


            teamList.ForEach(p =>
            {
                if (p.IsActive)
                {
                    if (ownerID.HasValue && p.Owner != null && p.Owner.Id != ownerID.Value)
                    {

                    }
                    else
                    {
                        if (p.Manager != null)
                        {
                            list.Add(new TeamDropDownItemModel() { DataText = p.Name, DataID = p.Id, ManagerName = p.Manager.DisplayName, ManagerID = p.Manager.Id });
                        }
                        
                    }

                }
            });
            return list;
        }


        public async Task<List<DropDownItemStringKeyModel>> GetCountryCodeList()
        {
            var list = new List<DropDownItemStringKeyModel>();

            var result = await SettingService.SearchAsync(new Setting() { Name = "CountryCode" });
            result.Content.ForEach(p =>
            {
                list.Add(new DropDownItemStringKeyModel() { DataText = p.TextVal, DataID = p.KeyVal });
            });
            return list;
        }

        public async Task<List<DropDownItemStringKeyModel>> GetDepartmentCodeList()
        {

            var list = new List<DropDownItemStringKeyModel>();

            var result = await SettingService.SearchAsync(new Setting() { Name = "DeptCode" });
            result.Content.ForEach(p =>
            {
                list.Add(new DropDownItemStringKeyModel() { DataText = p.KeyVal, DataID = p.KeyVal });
            });
            return list;
            
        }

        public async  Task<List<DropDownItemModel>> GetJobGradeCodeList()
        {

            var list = new List<DropDownItemModel>();

            var result = await SettingService.SearchAsync(new Setting() { Name = "JobGrade" });
            result.Content.OrderBy(o=>o.OrderSeq).ForEach(p =>
            {
                list.Add(new DropDownItemModel() { DataText = p.KeyVal, DataID = int.Parse(p.KeyVal) });
            });
            return list;
           
        }

        public async Task<ApiResponse<int>> SaveAsync(EmployeeModel model)
        {
            
            var entity = EmployeeModel.ModelToEntity(model);
            if(entity.Id > 0 )
            {
                var result = await  Service.UpdateAsync(entity);
                return result;
            }
             else
            {
                var result = await Service.CreateAsync(entity);
                return result;
            }
                 
        }


        public  async Task<ApiResponse<bool>> DeleteAsync(int id, string updateBy)
        {
            var result = await Service.DeleteAsync(id, updateBy);
            return result;

        }
       

        //public async Task<List<DropDownItemModel>>> GetEmployeeTitleList()
        //{

        //    var list = new List<DropDownItemModel>();

        //    var result = await Service.SearchAsync(new Setting() { Name = "EmployeeTitle" });
        //    result.Content.ForEach(p =>
        //    {
        //        list.Add(new DropDownItemModel() { DataText = p.TextVal, DataID = p.KeyVal });
        //    });
        //    return list;

        //}
    }
}
