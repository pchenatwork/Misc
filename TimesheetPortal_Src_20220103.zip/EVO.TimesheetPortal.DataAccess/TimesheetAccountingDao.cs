﻿using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Xml;

namespace EVO.TimesheetPortal.DataAccess
{
    public class TimesheetAccountingDao : DaoBase<TimeSheetAccounting>
    {
        #region	Constructors

        private TimesheetAccountingDao()
        {
        }

        #endregion constructors

        #region Override IDataAccessObject

        public IEnumerable<TimeSheetAccounting> FindByPeriodCode(IDbSession dbSession, string periodCode, string entitiesID)
        {
            var listSqlParameter = new List<SqlParameter>
            {
                new SqlParameter("@PeriodCode",periodCode),
                new SqlParameter("@EntitiesID", entitiesID)
            };
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_TimesheetAccounting_FindByCriteria", listSqlParameter);
            return DeserializeCollection(reader);
        }

        #endregion
    }
}