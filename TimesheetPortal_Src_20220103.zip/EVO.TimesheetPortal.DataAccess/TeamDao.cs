﻿/*=======================================================================
* Modification History:
* ----------------------------------------------------------------------
* 10/14/2021   DINO       Introduced
* 10/19/2021   PCHEN      Revise _UpSert, Added soft delete
*=======================================================================*/

using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using FrameworkBase.ValueObject;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Data;
using System.Xml;

namespace EVO.TimesheetPortal.DataAccess
{
    public class TeamDao : DaoBase<Team>
    {
        private const string CLASSNAME = nameof(TeamDao);

        private TeamDao()
        {
        }

        public override int Create(IDbSession dbSession, Team newObject)
        {
            return _Upsert(dbSession, newObject);
        }

        public override bool Update(IDbSession dbSession, Team obj)
        {
            return _Upsert(dbSession, obj) > 0;
        }
        public override bool Delete(IDbSession dbSession, dynamic Id, dynamic By = null)
        {
            // Mockup the Entity to soft delete
            Team o = ValueObjectFactory<Team>.Instance.Create();
            o.Id = Id;
            o.ManagerId = -1; // To skip update
            o.OwnerId = -1; // To skip update
            o.IsActive = false;
            o.UpdateBy = By; 
            return _Upsert(dbSession, o) > 0; ;
        }

        public  IEnumerable<Team> FindByEntity(IDbSession dbSession, TeamCriteria criteria)
        {
            List<SqlParameter> listSqlParameter = new List<SqlParameter>();
            if (criteria != null)
            {
                listSqlParameter = new List<SqlParameter>
                            {
                                new SqlParameter("@Id",criteria.Id),
                                new SqlParameter("@Name",criteria.Name),
                                new SqlParameter("@DeptCode", criteria.DeptCode),
                                new SqlParameter("@ManagerId", criteria.ManagerId.GetValueOrDefault()),
                                new SqlParameter("@OwnerId", criteria.OwnerId.GetValueOrDefault()),
                                new SqlParameter("@ParentId", criteria.ParentId.GetValueOrDefault()),
                                
                                 new SqlParameter("@IsAdmin", criteria.IsAdmin)
                            };
            }

            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Team_FindByCriteria", listSqlParameter);
            return DeserializeCollection(reader);
        }

        public override Team Get(IDbSession dbSession, dynamic id)
        {
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@Id", id);
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Team_Get", parameters);
            return Deserialize(reader);
        }

        private static int _Upsert(IDbSession dbSession, Team entity)
        {
            var paras = new List<SqlParameter>();
            paras.Add(new SqlParameter("@Id", entity.Id));
            if (entity.Name!=null) paras.Add(new SqlParameter("@Name", entity.Name));
            if (entity.ShortName!=null) paras.Add(new SqlParameter("@ShortName", entity.ShortName));
            if (entity.DeptCode!=null) paras.Add(new SqlParameter("@DeptCode", entity.DeptCode));
            if (entity.ManagerId >=0) paras.Add(new SqlParameter("@ManagerId", entity.ManagerId));
            if (entity.OwnerId >= 0) paras.Add(new SqlParameter("@OwnerId", entity.OwnerId));
            paras.Add(new SqlParameter("@IsActive", entity.IsActive));
            paras.Add(new SqlParameter("@By", entity.UpdateBy));

            int rowcount;
            rowcount = ExecuteNonQuery(dbSession, "SPU_Team_UpSert", paras, out object retval);
            return (int)retval;
        }
    }
}