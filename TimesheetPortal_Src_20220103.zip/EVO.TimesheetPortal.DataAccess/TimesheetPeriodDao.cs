﻿using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using FrameworkBase.ValueObject;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Xml;

namespace EVO.TimesheetPortal.DataAccess
{
    public class TimesheetPeriodDao : DaoBase<TimesheetPeriod>
    {
        private const string CLASSNAME = nameof(TimesheetPeriodDao);

        #region Constructor

        private TimesheetPeriodDao()
        {
        }

        static TimesheetPeriodDao()
        {
            // logger can go here if needed
        }

        #endregion Constructor

        public override int Create(IDbSession dbSession, TimesheetPeriod eneity)
        {
            return _Upsert(dbSession, eneity);
        }

        #region Custon Dao Method

        private static int _Upsert(IDbSession dbSession, TimesheetPeriod entity)
        {
            var paras = new List<SqlParameter>();
            int rowcount;
            rowcount = ExecuteNonQuery(dbSession, "SPU_TimesheetPeriod_Insert", paras, out object retval);
            return (int)retval;
        }


        public  IEnumerable<TimesheetPeriod> FindByEntity(IDbSession dbSession, TimesheetPeriod criteria)
        {
        
            List<SqlParameter> listSqlParameter = new List<SqlParameter>();
            if (criteria != null)
            {
                listSqlParameter = new List<SqlParameter>();

                if (criteria.Id > 0) listSqlParameter.Add(new SqlParameter("@Id", criteria.Id));
                if(criteria.StatusId > 0) listSqlParameter.Add(new SqlParameter("@StatusId", criteria.StatusId));
                listSqlParameter.Add(new SqlParameter("@PeriodCode", criteria.PeriodCode));
            }

            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_TimesheetPeriod_Find", listSqlParameter);
            return DeserializeCollection(reader);
        }
        #endregion Custon Dao Method
    }
}