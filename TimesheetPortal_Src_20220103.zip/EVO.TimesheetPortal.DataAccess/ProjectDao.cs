﻿#region Header Info

/*=======================================================================
* Modification History:
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using FrameworkBase.Util;
using FrameworkBase.ValueObject;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.Json;
using System.Xml;

#endregion Header Info

namespace EVO.TimesheetPortal.DataAccess
{
    /// <summary>
    /// </summary>
    public class ProjectDao : DaoBase<Project>
    {
        #region	Constructors

        private ProjectDao()
        {
        }

        #endregion constructors

        #region Override IDataAccessObject

        public override Project Get(IDbSession dbSession, dynamic id)
        {
            SqlParameter[] p = new SqlParameter[] { new SqlParameter("@Id", id) };
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Project_Get", p);
            return Deserialize(reader);
        }

        public override IEnumerable<Project> FindByEntity(IDbSession dbSession, IValueObject entity)
        {
            Project criteria = (Project)entity;
            List<SqlParameter> listSqlParameter = new List<SqlParameter>();
            if (criteria != null)
            {
                if (criteria.Teams?.Count > 0 && criteria.QueryStatus?.Count > 0)
                {
                    var jsonTokens = new { team = criteria.Teams?.Select(s => s.Id), statusids = criteria.QueryStatus?.ToArray() };
                    criteria.Extra = JsonSerializer.Serialize(jsonTokens);
                }
                else if (criteria.Teams?.Count > 0 && criteria.QueryStatus?.Count == 0)
                {
                    var jsonTokens = new { team = criteria.Teams?.Select(s => s.Id) };
                    criteria.Extra = JsonSerializer.Serialize(jsonTokens);
                }
                else if (criteria.Teams?.Count == 0 && criteria.QueryStatus?.Count > 0)
                {
                    var jsonTokens = new { statusids = criteria.QueryStatus?.ToArray() };
                    criteria.Extra = JsonSerializer.Serialize(jsonTokens);
                }

                if (criteria.Name != null) 
                    listSqlParameter.Add(new SqlParameter("@Name", criteria.Name));
                if (criteria.PIRNum != null) 
                    listSqlParameter.Add(new SqlParameter("@PIRNum", criteria.PIRNum));
                if (criteria.TypeId > 0) 
                    listSqlParameter.Add(new SqlParameter("@ProjectTypeID", criteria.TypeId));
                //Note: PCHEN introduced a more generic DataHelper.IsNull() to replace CheckDateTime()
                //new SqlParameter("@StartDate", CheckDateTime(criteria.StartDate)),
                //new SqlParameter("@EndDate", CheckDateTime(criteria.EndDate)),
                //new SqlParameter("@ProdDate", CheckDateTime(criteria.ProdDate)),
                if (!DataHelper.IsNull(criteria.StartDate))
                    listSqlParameter.Add(new SqlParameter("@StartDate", criteria.StartDate));
                if (!DataHelper.IsNull(criteria.EndDate))
                    listSqlParameter.Add(new SqlParameter("@EndDate", criteria.EndDate));
                if (!DataHelper.IsNull(criteria.ProdDate))
                    listSqlParameter.Add(new SqlParameter("@ProdDate", criteria.ProdDate));
                if (criteria.CountryCode != null) listSqlParameter.Add(new SqlParameter("@CountryCode", criteria.CountryCode));
                if (criteria.Extra != null) listSqlParameter.Add(new SqlParameter("@JsonExtras", criteria.Extra));
                listSqlParameter.Add(new SqlParameter("@IsAdmin", criteria.IsAdmin));
            }

          
            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Project_FindByCriteria", listSqlParameter);
            var result= DeserializeCollection(reader);
            return result;
        }

        public override IEnumerable<Project> Find(IDbSession dbSession, string jsonTokens)
        {
            return _Find(dbSession, "SPU_Project_Find", jsonTokens);
        }
        public override int Create(IDbSession dbSession, Project proj)
        {
            int newId =  _Upsert(dbSession, proj);
            if (proj.Teams!=null)
            {
                var x = from t in proj.Teams select new { Id = t.Id };
                UpdateTeams(dbSession, newId, JsonSerializer.Serialize(x), proj.UpdateBy);
            }
            if (proj.Activities != null)
            {
                var x = from t in proj.Activities select new { Id = t.KeyVal };
                UpdateActivities(dbSession, newId, JsonSerializer.Serialize(x), proj.UpdateBy);
            }

            return newId;
        }
        public override bool Update(IDbSession dbSession, Project proj)
        {
            if (proj.Teams != null)
            {
                var x = from t in proj.Teams select new { t.Id }; // => form of [{"Id":4}, {"Id":3}]

                UpdateTeams(dbSession, proj.Id, JsonSerializer.Serialize(x), proj.UpdateBy);
            }
            if (proj.Activities != null)
            {
                var x = from t in proj.Activities select new { Id = t.KeyVal }; // => form of [{"Id":4}, {"Id":3}]
                UpdateActivities(dbSession, proj.Id, JsonSerializer.Serialize(x), proj.UpdateBy);
            }
            return _Upsert(dbSession, proj) > 0;
        }
        public override bool Delete(IDbSession dbSession, dynamic Id, dynamic By)
        {   // instead of hard delete, update Project Workflow status to "Deleted"
            return UpdateWorkflowStatus(dbSession, Id, ProjectStatusEnum.Deleted.Id, By);
        }

        public bool UpdateTeams(IDbSession dbSession, int ProjectId, string IdsJson, string By)
        {
            var L = new List<SqlParameter>();

            L.Add(new SqlParameter("@ProjectId", ProjectId));
            L.Add(new SqlParameter("@TeamIdJson", IdsJson));
            L.Add(new SqlParameter("@By", By));

            int rowcount = ExecuteNonQuery(dbSession, "SPU_ProjectTeam_UpSert", L, out object retval);
            return (int)retval == 0;
        }
        public bool UpdateActivities(IDbSession dbSession, int ProjectId, string IdsJson, string By)
        {
            var L = new List<SqlParameter>();
            L.Add(new SqlParameter("@ProjectId", ProjectId));
            L.Add(new SqlParameter("@ActivityIdJson", IdsJson));
            L.Add(new SqlParameter("@By", By));

            int rowcount = ExecuteNonQuery(dbSession, "SPU_ProjectActivity_UpSert", L, out object retval);
            return (int)retval == 0;
        }
        public bool UpdateWorkflowStatus(IDbSession dbSession, int ProjectId, int NewStatusId, string By, string Comment = null)
        {
            var L = new List<SqlParameter>();
            L.Add(new SqlParameter("@WorkflowId", 1)); // for Project Workflow
            L.Add(new SqlParameter("@EntityId", ProjectId));
            L.Add(new SqlParameter("@StatusId", NewStatusId));
            if (Comment != null) L.Add(new SqlParameter("@Comment", Comment));
            L.Add(new SqlParameter("@By", By));

            int rowcount = ExecuteNonQuery(dbSession, "SPU_Workflow_Update", L, out object retval);  // SPU_Workflow_Update will return 0 where succeed.

            bool bOK = (int)retval == 0;

            // If it is approve, needs to create ProjectNo,
            if (bOK && ProjectStatusEnum.Approved.Id.Equals(NewStatusId))
            {
                bOK = _UpdateProjectNo(dbSession, ProjectId, By);
            }
            
            return bOK;
        }

        #endregion

        #region Private Wrapper Methods

        /// <summary>
        ///     Wrapper function for sp 'SPU_Project_UpdateProjectNo'.
        /// </summary>
        private static bool _UpdateProjectNo(IDbSession dbSession, int ProjectId, string By)
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@ProjectId", ProjectId);
            p[1] = new SqlParameter("@By", By);

            int rowcount = ExecuteNonQuery(dbSession, "SPU_Project_UpdateProjectNo", p, out object retval); 
            return (int)retval>0;
        }

        /// <summary>
        ///     Wrapper function for sp 'SPU_Project_UpSert'.
        /// </summary>
        private static int _Upsert(IDbSession dbSession, Project o)
        {
            var L = new List<SqlParameter>();
            L.Add(new SqlParameter("@Id", o.Id));
            if (o.Name != null) L.Add(new SqlParameter("@Name", o.Name));
            if (o.Description != null) L.Add(new SqlParameter("@Description", o.Description));
            if (o.TypeId > 0) L.Add(new SqlParameter("@TypeId", o.TypeId));
            if (!DataHelper.IsNull(o.StartDate)) L.Add(new SqlParameter("@StartDate", o.StartDate));
            if (!DataHelper.IsNull(o.EndDate)) L.Add(new SqlParameter("@EndDate", o.EndDate));
            if (!DataHelper.IsNull(o.ProdDate)) L.Add(new SqlParameter("@ProdDate", o.ProdDate));
            if (o.EstHrs > 0 ) L.Add(new SqlParameter("@EstHrs", o.EstHrs));
            if (o.PIRNum != null) L.Add(new SqlParameter("@PIRNum", o.PIRNum));
            if (o.CountryCode != null) L.Add(new SqlParameter("@CountryCode", o.CountryCode));
            if (o.RequestBy != null) L.Add(new SqlParameter("@RequestBy", o.RequestBy));
            if (!o.IsPredefined) L.Add(new SqlParameter("@IsPredefined", 0)); // Assume not a predefined project
            L.Add(new SqlParameter("@By", o.UpdateBy));
            L.Add(new SqlParameter("@Team", ResolveListOfID(o.Teams.Select(s=>s.Id))));
            L.Add(new SqlParameter("@Activity", ResolveListOfID(o.Activities.Select(s => s.Id))));
            int rowcount;
            rowcount = ExecuteNonQuery(dbSession, "SPU_Project_UpSert", L, out object retval);
            return (int)retval;
        }

        private static DataTable ResolveListOfID(IEnumerable<int> IDList)
        {
            var teamsDt = new DataTable();
            teamsDt.Columns.Add("ID", typeof(int));
            IDList.ToList()?.ForEach(f => teamsDt.Rows.Add(f));
            return teamsDt;
        }

        #endregion
    }
}