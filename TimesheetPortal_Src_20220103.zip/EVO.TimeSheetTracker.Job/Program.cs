﻿using EVO.TimeSheetTracker.Job.Config;
using EVOUserManagement;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Serilog;
using SilkierQuartz;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;
using TimeSheetTrackerService;

namespace EVO.TimeSheetTracker.Job
{
    public class Program
    {
        private static async Task Main(string[] args)
        {
            var isService = !(Debugger.IsAttached || args.Contains("--console"));

            if (isService)
            {
                var pathToExe = Process.GetCurrentProcess().MainModule.FileName;
                var pathToContentRoot = Path.GetDirectoryName(pathToExe);
                Directory.SetCurrentDirectory(pathToContentRoot);
            }

            IConfiguration Configuration = new ConfigurationBuilder()
                  .SetBasePath(Directory.GetCurrentDirectory())
                  .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                  .AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production"}.json", optional: true)
                  .AddEnvironmentVariables()
                  .Build();

            Log.Logger = new LoggerConfiguration()
                  .ReadFrom.Configuration(Configuration)
                  .Enrich.FromLogContext()
                  .WriteTo.Debug()
                  .WriteTo.Console(
                      outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] {Message:lj} {Properties:j}{NewLine}{Exception}")
                  .CreateLogger();

            try
            {
                Log.Information("Application job start!");
                Log.Information(Configuration.GetSection("Urls").Value);
                var hostBuilder =
                  Host.CreateDefaultBuilder(args)
                  .UseContentRoot(Directory.GetCurrentDirectory())
                  .UseSerilog()
                  .UseWindowsService()
                  .UseEnvironment(Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production")
                .ConfigureServices(services =>
                {
                    services.AddOptions();
                    services.Configure<ServiceOption>(Configuration.GetSection("WCF"));

                    services.AddScoped<ITimeSheetTracker>(provider =>
                    {
                        var option = provider.GetService<IOptionsSnapshot<ServiceOption>>();
                        var address = option.Value.ServiceUrl;
                        var isHttps = address.ToLower().IndexOf("https") > -1;

                        var client = isHttps ? new TimeSheetTrackerClient(new BasicHttpBinding(BasicHttpSecurityMode.Transport), new EndpointAddress(address)) : new TimeSheetTrackerClient(TimeSheetTrackerClient.EndpointConfiguration.BasicHttpBinding_ITimeSheetTracker);
                        client.Endpoint.Address = new System.ServiceModel.EndpointAddress(address);
                        return client;
                    });

                    services.AddScoped<EVOUserManagementClient>(provider =>
                    {
                        var option = provider.GetService<IOptionsSnapshot<ServiceOption>>();
                        var managerAddress = option.Value.UserManagerServiceUrl;
                        var isHttps = managerAddress.ToLower().IndexOf("https") > -1;

                        var client = isHttps ? new EVOUserManagementClient(new BasicHttpBinding(BasicHttpSecurityMode.Transport), new EndpointAddress(managerAddress)) : new EVOUserManagementClient(EVOUserManagementClient.EndpointConfiguration.BasicHttpBinding_IEVOUserManagement);
                        client.Endpoint.Address = new System.ServiceModel.EndpointAddress(managerAddress);
                        return client;
                    });
                })
                 .ConfigureWebHostDefaults(webBuilder =>
                 {
                     webBuilder.UseStartup<Startup>();
                     webBuilder.UseUrls($"{Configuration.GetSection("Urls").Value}");
                 })
                 .ConfigureSilkierQuartzHost();

                await hostBuilder.Build().RunAsync();
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "Host terminated unexpectedly");
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }
    }
}