﻿using System.Collections.Generic;
using TimeSheetTrackerService;

namespace EVO.TimeSheetTracker.Job.Common
{
    public class EmployeeEntityCompares : IEqualityComparer<EmployeeEntity>
    {
        bool IEqualityComparer<EmployeeEntity>.Equals(EmployeeEntity x, EmployeeEntity y)
        {
            if (x.EmployeeID == y.EmployeeID || x.UserID == y.UserID)
                return true;
            return false;
        }

        int IEqualityComparer<EmployeeEntity>.GetHashCode(EmployeeEntity obj)
        {
            return obj.UserID.GetHashCode();
        }
    }
}
