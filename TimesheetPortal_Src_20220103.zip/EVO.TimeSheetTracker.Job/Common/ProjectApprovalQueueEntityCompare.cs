﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using TimeSheetTrackerService;

namespace EVO.TimeSheetTracker.Job.Common
{
    public class ProjectApprovalQueueEntityCompare : IEqualityComparer<ProjectApprovalQueueEntity>
    {
        public bool Equals( ProjectApprovalQueueEntity x,  ProjectApprovalQueueEntity y)
        {
            if (x.ProjectID == y.ProjectID)
                return true;
            return false;
        }

        public int GetHashCode([DisallowNull] ProjectApprovalQueueEntity obj)
        {
            return obj.ProjectID.GetHashCode();
        }
    }
}
