﻿using EVO.TimeSheetTracker.Job.Config;
using Microsoft.Extensions.Options;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using TimeSheetTrackerService;

namespace EVO.TimeSheetTracker.Job.Jobs
{
    public abstract class EmailJobBase : JobBase
    {
        protected ITimeSheetTracker _timeSheetClient;
        protected ServiceOption _serviceOption;
        protected abstract string EmailTemplateName { get; set; }

        protected EmailJobBase(ITimeSheetTracker timeSheetClient, IOptionsSnapshot<ServiceOption> serviceOption, ILogger logger)
            : base(logger)
        {
            _timeSheetClient = timeSheetClient;
            _serviceOption = serviceOption.Value;
        }

        protected SaveResult SendEmail(MailEntity mail)
        {
            // Swap MailTo(for testing) if a valid MailTo email is defined in appsetting.{env}.json config file.
            mail.To = Regex.IsMatch(_serviceOption.MailTo ?? string.Empty, @"^[^@\s]+@[^@\s]+\.[^@\s]+$") ? _serviceOption.MailTo : mail.To;
            var result = _timeSheetClient.SendEmail(mail.From, mail.To, mail.Subject, mail.Body, mail.Bcc, mail.Cc);
            return result;
        }

        protected JobResult SendEmailList(List<MailEntity> mails)
        {
            int iCnt = 0, iTotal = mails.Count;
            var result = Parallel.ForEach(mails, item =>
            {
                if (SendEmail(item).Success) Interlocked.Increment(ref iCnt);
            });
            return iTotal.Equals(iCnt) ? JobResult.Success : JobResult.Warning;
        }

        protected EmployeeEntity[] GetEmplyoeeByRoleNames(string[] roleNames)
        {
            var result = _timeSheetClient.GetEmployeesByRoleNames(roleNames);
            return result;
        }

        private EmailTemplateEntity GetEmailTemplate()
        {
            var result = _timeSheetClient.GetEmailTemplates();
            if (!string.IsNullOrWhiteSpace(EmailTemplateName) && result != null)
            {
                return result.Where(o => o.TemplateName.Equals(EmailTemplateName, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
            }
            return null;
        }

        protected EmailTemplateEntity EmailTemplate => this.GetEmailTemplate();
    }

    public class MailEntity
    {
        public string From { get; set; }

        public string To { get; set; }

        public string Subject { get; set; }

        public string Body { get; set; }

        public string Bcc { get; set; }

        public string Cc { get; set; }
    }
}