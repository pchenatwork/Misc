﻿using EVO.TimeSheetTracker.Job.Config;
//using Microsoft.Extensions.Logging;
using Serilog;
using Microsoft.Extensions.Options;
using Quartz;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimeSheetTrackerService;

namespace EVO.TimeSheetTracker.Job.Jobs
{
    [DisallowConcurrentExecution, PersistJobDataAfterExecution]
    public class TimesheetManagerRemindJob : EmailJobBase
    {
        protected override string EmailTemplateName { get; set; } = "TimesheetReview";
        private static string _subject = " Sumbit Timesheet Reminder for manager";
        public TimesheetManagerRemindJob(ITimeSheetTracker timeSheetClient, IOptionsSnapshot<ServiceOption> serviceOption, ILogger logger)
            : base(timeSheetClient, serviceOption, logger.ForContext<TimesheetManagerRemindJob>())
        {

        }
     
        protected override async Task<JobResult> Run(IJobExecutionContext context)
        {
            var entitys = await _timeSheetClient.GetTeamsAsync(new TeamEntity() { IsAdmin = true });

            if (entitys.Length < 1)
            {
                return JobResult.Success;
            }
            var mangagerTwoEmails = entitys.Where(o => o.Manager2 !=null && o.Manager2.EmailAlert.GetValueOrDefault()  && o.Manager2.Email !=null).Select(o => o.Manager2.Email)
              .Concat(entitys.Where(o=> o.Manager1 !=null && o.Manager1.EmailAlert.GetValueOrDefault() && o.Manager1.Email !=null).Select(o=> o.Manager1.Email));
            
            var mailList = new List<MailEntity>();
            foreach (var mail in mangagerTwoEmails.Distinct())
            {
                mailList.Add(new MailEntity()
                {
                    From = _serviceOption.MailFrom,
                    To = mail,
                    Subject = EmailTemplate !=null ? EmailTemplate.EmailSubject :_subject,
                    Body = EmailTemplate != null ? EmailTemplate.EmailContent : "Plase submit your timesheet by EOD(11:59:59 pm EST) of 26th."
                });

            }
            return SendEmailList(mailList);
        }
    }
}
