﻿using EVO.TimeSheetTracker.Job.Common;
using EVO.TimeSheetTracker.Job.Config;
//using Microsoft.Extensions.Logging;
using Serilog;
using Microsoft.Extensions.Options;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimeSheetTrackerService;

namespace EVO.TimeSheetTracker.Job.Jobs
{
    [DisallowConcurrentExecution, PersistJobDataAfterExecution]
    public class SendMailJob : EmailJobBase
    {
        protected override string EmailTemplateName { get; set; }
        public SendMailJob(ITimeSheetTracker timeSheetClient, ILogger logger, IOptionsSnapshot<ServiceOption> serviceOption)
           : base(timeSheetClient, serviceOption, logger.ForContext<SendMailJob>())
        {
        }
        protected override async Task<JobResult> Run(IJobExecutionContext context)
        {
            var pendingList = await _timeSheetClient.GetPendingEmailListAsync(DateTime.Now);

            if (pendingList == null || pendingList.Length < 1) return JobResult.Success;
            
             var mailList = new List<MailEntity>();
              foreach (var mail in pendingList)
                {
                    mailList.Add(new MailEntity()
                    {
                        From = mail.Sender,
                        To = mail.Recipients,
                        Subject = mail.Subject,
                        Bcc = mail.Bcc ?? "",
                        Cc= mail.Cc ?? "",
                        Body = mail.Body
                    });

                }
            var mailIds = pendingList.Select(o => o.EmailID).ToArray();
            _logger.Information("start update mail list", mailIds);
            var result = await _timeSheetClient.UpdateEmailListAsync(mailIds);
            _logger.Information("update mail list successFul");
            return SendEmailList(mailList);
        }
    }
}
