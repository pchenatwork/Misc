﻿using EVO.TimeSheetTracker.Job.Common;
using EVO.TimeSheetTracker.Job.Config;
//using Microsoft.Extensions.Logging;
using Serilog;
using Microsoft.Extensions.Options;
using Quartz;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimeSheetTrackerService;

namespace EVO.TimeSheetTracker.Job.Jobs
{
    [DisallowConcurrentExecution, PersistJobDataAfterExecution]
    //[SilkierQuartz(20, "ProjectApprovedRemindJob", "ProjectApprovedRemindJob", TriggerGroup = "ProjectApprovedReminder")]
    public class ProjectApprovedRemindJob : EmailJobBase
    {
        protected override string EmailTemplateName { get; set; } = "ProjectApproval";
        public ProjectApprovedRemindJob(ITimeSheetTracker timeSheetClient, ILogger logger, IOptionsSnapshot<ServiceOption> serviceOption)
            : base(timeSheetClient, serviceOption, logger.ForContext<ProjectApprovedRemindJob>())
        {
        }

        protected override async Task<JobResult> Run(IJobExecutionContext context)
        {
            var query = new TimeSheetQueryEntity()
            {
                IsAdmin = true,
                StatusID = new int[] { 3 }
            };
            var teamEntities =  await _timeSheetClient.GetTeamProjectReminderDataAsync(query);
            var managerTeams = teamEntities.Where(o => o.Manager2 != null);
            var groupEntities = managerTeams.GroupBy(team => team.Manager2, new EmployeeEntityCompares());
            var mailList = new List<MailEntity>();
            var subject = "Approved project list";
            foreach (var group in groupEntities)
            {
                var manager = group.Key;
                var projects = group.SelectMany(o => o.Projects).Distinct(new ProjectApprovalQueueEntityCompare()).ToList();
                if (projects.Count > 0)
                {
                    mailList.Add(new MailEntity()
                    {
                        From = _serviceOption.MailFrom,
                        To = manager.Email,
                        Subject = subject,
                        Body = string.Join(",", projects.Select(o => o.ProjectName).ToList())
                    });
                }
            }

            return SendEmailList(mailList);
        }
    }
}
