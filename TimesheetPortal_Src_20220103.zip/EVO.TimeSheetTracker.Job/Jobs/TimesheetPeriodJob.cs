﻿using Quartz;
using Serilog;
using System.Threading.Tasks;
using TimeSheetTrackerService;

namespace EVO.TimeSheetTracker.Job.Jobs
{
    [DisallowConcurrentExecution, PersistJobDataAfterExecution]
    public class TimesheetPeriodJob : JobBase
    {
        protected ITimeSheetTracker _timeSheetClient;

        public TimesheetPeriodJob(ITimeSheetTracker timeSheetClient, ILogger logger)
            : base(logger)
        {
            _timeSheetClient = timeSheetClient;
        }

        protected async override Task<JobResult> Run(IJobExecutionContext context)
        {
            var result = await _timeSheetClient.CreateTimesheetPeriodAsync();
            if (result.Success)
            {
                return JobResult.Success;
            }
            else
            {
                return JobResult.Failed;
            }
        }
    }
}