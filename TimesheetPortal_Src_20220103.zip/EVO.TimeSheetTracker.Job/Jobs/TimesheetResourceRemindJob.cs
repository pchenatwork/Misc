﻿using EVO.TimeSheetTracker.Job.Config;
//using Microsoft.Extensions.Logging;
using Serilog;
using Microsoft.Extensions.Options;
using Quartz;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimeSheetTrackerService;

namespace EVO.TimeSheetTracker.Job.Jobs
{
    [DisallowConcurrentExecution, PersistJobDataAfterExecution]
    public class TimesheetResourceRemindJob : EmailJobBase
    {
        protected override string EmailTemplateName { get; set; } = "TimesheetSubmission";

        private readonly List<string> RoleNameList = new List<string>(){"employee","manager","teamowner"};
        public TimesheetResourceRemindJob(ITimeSheetTracker timeSheetClient, IOptionsSnapshot<ServiceOption> serviceOption, ILogger logger)
            : base(timeSheetClient, serviceOption, logger.ForContext<TimesheetResourceRemindJob>())
        {
        }
     
        protected override async Task<JobResult> Run(IJobExecutionContext context)
        {
            var employees = await _timeSheetClient.GetEmployeesAsync(new EmployeeEntity());
            var subject = " Sumbit Timesheet Reminder";
            var mailList = new List<MailEntity>();
            var x = employees.Where(o => o.IsActive && o.Email != null && o.EmailAlert.GetValueOrDefault() && RoleNameList.Contains(o.RoleName?.ToLower()))
                .GroupBy(m => m.Email).Select(grp => grp.First());
            foreach (var employee in x)
            {

                mailList.Add(new MailEntity()
                {
                    From = _serviceOption.MailFrom,
                    To = employee.Email,
                    Subject = EmailTemplate !=null ? EmailTemplate.EmailSubject : subject,
                    Body = EmailTemplate != null ? EmailTemplate.EmailContent : "Please be reminded that you need to submit your timesheet by EOD(11:59:59 pm EST) on the 25th of each month."
                });
            }
            return SendEmailList(mailList);           
        }
    }
}
