﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 11/15/2021 Dino       Created
* 10/15/2021 PCHEN      Redefined some properties
*=======================================================================*/

using FrameworkBase.ValueObject;
using System;
using System.Collections.ObjectModel;
using System.Xml.Serialization;

#endregion


namespace EVO.TimesheetPortal.Entity
{
    public class Project : ValueObjectBase
    {
        #region	Private Members
        private DateTime _startDate = new DateTime(1900, 1, 1);
        private DateTime _endDate = new DateTime(1900, 1, 1);
        private DateTime _prodDate = new DateTime(1900, 1, 1);
        private DateTime _statusDate = new DateTime(1900, 1, 1);
        #endregion

        #region Propertied
        [XmlAttribute()]
        public string Name { get; set; }
        [XmlAttribute()]
        public string Description { get; set; }
        [XmlAttribute()]
        public int TypeId { get; set; }
        [XmlAttribute()]
        public string Type { get; set; }
        [XmlAttribute()]
        public DateTime StartDate
        {
            get
            {
                return this._startDate;
            }
            set
            {
                this._startDate = value;
            }
        }
        [XmlAttribute()]
        public DateTime EndDate
        {
            get
            {
                return this._endDate;
            }
            set
            {
                this._endDate = value;
            }
        }
        [XmlAttribute()]
        public DateTime ProdDate
        {
            get
            {
                return this._prodDate;
            }
            set
            {
                this._prodDate = value;
            }
        }
        [XmlAttribute()]
        public decimal EstHrs { get; set; }
        [XmlAttribute()]
        public string ProjectNo { get; set; }
        [XmlAttribute()]
        public string PIRNum { get; set; }
        [XmlAttribute()]
        public string CountryCode { get; set; }
        [XmlAttribute()]
        public string RequestBy { get; set; }
        [XmlAttribute()]
        public int StatusId { get; set; }
        /// <summary>
        /// StatusName value is coming from ProjectStatusEnum
        /// </summary>
        public string StatusName {
            get { return ProjectStatusEnum.GetById(StatusId).Name; } }
        [XmlAttribute()]
        public DateTime StatusDate
        {
            get
            {
                return this._statusDate;
            }
            set
            {
                this._statusDate = value;
            }
        }
        [XmlAttribute()]
        public bool IsPredefined { get; set; }
        [XmlArray("ArrayOfTeam")]
        public Collection<Team> Teams { get; set; }
        [XmlArray("ArrayOfActivity")]
        public Collection<Setting> Activities { get; set; }
        [XmlArray("ArrayOfWorkflowHistory")]
        public Collection<WorkflowHistory> History { get; set; }

        [XmlIgnore]
        public bool IsAdmin { get; set; }
        [XmlIgnore]
        public Collection<int> QueryStatus { get; set; }
        #endregion
    }
}