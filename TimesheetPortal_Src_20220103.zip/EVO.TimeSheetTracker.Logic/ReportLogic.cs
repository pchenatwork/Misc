﻿using EVO.TimeSheetTracker.DataAccess;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Logic
{
    public class ReportLogic
    {
        public ReportProjectStatusEntity GetProjectSubmittedStatus()
        {
            return new ReportDA().GetProjectSubmittedStatus();
        }

        public List<ReportTimesheetStatusEntity> GetTimesheetSubmittedStatus()
        {
            return new ReportDA().GetTimesheetSubmittedStatus();
        }
    }
}
