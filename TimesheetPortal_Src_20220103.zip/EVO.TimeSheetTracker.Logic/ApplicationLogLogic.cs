﻿using EVO.TimeSheetTracker.DataAccess;
using EVO.TimeSheetTracker.Entity;
using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Text;


using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using EVO.TimesheetPortal.BusinessLogic;

namespace EVO.TimeSheetTracker.Logic
{
   public class ApplicationLogLogic
    {
        public SaveResult LogError(ApplicationLogEntity log)
        {

            /// PCHEN: Demo to use the new Framework.
            var result = new SaveResult();
            result.Success = true; // Assume successful
            result.AssociatedObject = log;
            try
            {
                // Convert the old Entity to new ValueObject Entity for processing
                var log_new = ValueObjectFactory<TimesheetPortal.Entity.ApplicationLog>.Instance.Create();
                log_new.ApplicationLogID = log.ApplicationLogID;
                log_new.Browser = log.Browser;
                log_new.CreateBy = log.CreateBy;
                log_new.CreateDate = log.CreateDate;
                log_new.Date = log.Date;
                log_new.Id = log.Id;
                log_new.MachineName = log.MachineName;
                log_new.Message = log.Message;
                log_new.OperatingSystem = log.OperatingSystem;
                log_new.StackTrace = log.StackTrace;
                log_new.UpdateBy = log.UpdateBy;
                log_new.UpdateDate = log.UpdateDate;
                log_new.UserName = log.UserName;

                // Using the new Framework to store data
                using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbSessionEnum.ConnStr.Extra))
                {
                    var mgr = ManagerFactory<TimesheetPortal.Entity.ApplicationLog>.Instance.GetManager(session);
                    if (mgr.Create(log_new) > 0)
                    {
                        result.Success = true;
                    }
                    else
                    {
                        result.Success = false;
                        result.ErrorDescription = "ApplicationLogManager.Create() not successful.";
                    }
                }
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }

            return result;
            //return new ApplicationLog().LogError(log);
        }

        public IEnumerable<ApplicationLogEntity> GetApplicationLogs(ApplicationLogEntity entity)
        {
            //return new ApplicationLog().GetApplicationLogs(entity);

            // Using the new Framework to store data
            List<ApplicationLogEntity> L  = new List<ApplicationLogEntity>();
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbSessionEnum.ConnStr.Extra))
            {
                var mgr = ManagerFactory<TimesheetPortal.Entity.ApplicationLog>.Instance.GetManager(session);
                var x = mgr.GetAll();
                foreach(var log in x)
                {
                    L.Add(new ApplicationLogEntity()
                    {
                        ApplicationLogID = log.ApplicationLogID,
                        Browser = log.Browser,
                        CreateBy = log.CreateBy,
                        CreateDate = log.CreateDate,
                        Date = log.Date,
                        Id = log.Id,
                        MachineName = log.MachineName,
                        Message = log.Message,
                        OperatingSystem = log.OperatingSystem,
                        StackTrace = log.StackTrace,
                        UpdateBy = log.UpdateBy,
                        UpdateDate = log.UpdateDate,
                        UserName = log.UserName
                    });
                }
            }
            return L;
        }




    }
}
