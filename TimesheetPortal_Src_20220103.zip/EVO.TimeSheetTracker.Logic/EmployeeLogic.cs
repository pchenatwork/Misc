﻿using EVO.TimeSheetTracker.DataAccess;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Logic
{
   public class EmployeeLogic
    {
      

        public List<EmployeeEntity> GetEmployees(EmployeeEntity entity)
        {
            return new EmployeeDA().GetEmployees(entity);
        }


        public List<EmployeeEntity> GetEmployeesByRoleNames(IList<string> roleNameList)
        {
            return new EmployeeDA().GetEmployeesByRoleNames(roleNameList);
        }
        public SaveResult Insert(List<EmployeeEntity> entity)
        {
            return new EmployeeDA().Insert(entity);
        }

        public SaveResult Update(List<EmployeeEntity> entitys)
        {
            return new EmployeeDA().Update(entitys);
        }

        public SaveResult SyncEmployee(EmployeeEntity entity)
        {
            return new EmployeeDA().SyncEmployee(entity);
        }

        public bool DeactiveTeamCheck(int ID)
        {
            return new EmployeeDA().DeactiveTeamCheck(ID);
        }

        public SaveResult Delete(EmployeeEntity entity)
        {
            return new EmployeeDA().Delete(entity);
        }
    }
}
