﻿using EVO.TimeSheetTracker.DataAccess;
using EVO.TimeSheetTracker.Entity;
using System.Collections.Generic;
using System.Linq;

namespace EVO.TimeSheetTracker.Logic
{
    public class SettingsLogic
    {
        public List<SettingsEntity> GetProjectType()
        {
            return new SettingsDA().GetProjectType();
        }

        public List<SettingsEntity> GetProjectStatus()
        {
            return new SettingsDA().GetProjectStatus();
        }

        public List<SettingsEntity> GetTimesheetStatus()
        {
            return new SettingsDA().GetTimesheetStatus();
        }

        public SaveResult Update(SettingsEntity entity)
        {
            return new SettingsDA().Update(entity);
        }

        public SaveResult Insert(SettingsEntity entity)
        {
            return new SettingsDA().Insert(entity);
        }

        public SaveResult Delete(int Id)
        {
            return new SettingsDA().Delete(Id);
        }

        public List<SettingsEntity> GetSettings(SettingsEntity entity)
        {
            return new SettingsDA().GetSettings(entity);
        }

        public List<SettingsEntity> GetSettingsByCategory(string category)
        {
            return new SettingsDA().GetSettingsByCategory(category);
        }

        public List<SystemAssetEntity> GetSystemAssets(bool isAdmin)
        {
            return new SettingsDA().GetSystemAssets(isAdmin);
        }

        public SaveResult InsertSystemAsset(SettingsEntity entity)
        {
            return new SettingsDA().InsertSystemAsset(entity);
        }

        public SaveResult UpdateSystemAsset(SettingsEntity entity)
        {
            return new SettingsDA().UpdateSystemAsset(entity);
        }

        public SaveResult DeleteSystemAsset(int Id)
        {
            return new SettingsDA().DeleteSystemAsset(Id);
        }

        public List<RoleStatusEntity> GetRoleStatus()
        {
            return new SettingsDA().GetRoleStatus();
        }

        public List<SettingsEntity> GetTimehseetProjectPhase(int projectID, string resourceID)
        {
            int ownerID =  new EmployeeDA().GetEmployees(new EmployeeEntity { UserID = resourceID })?.FirstOrDefault()?.TeamOwnerID ?? 0;
            return new SettingsDA().GetTimehseetProjectPhase(projectID, ownerID);
        }

        public List<EmailTemplateEntity> GetEmailTemplates()
        {
            return new SettingsDA().GetEmailTemplates();
        }

        public SaveResult CreateTimesheetPeriod()
        {
            return new SettingsDA().CreateTimesheetPeriod();
        }
    }
}