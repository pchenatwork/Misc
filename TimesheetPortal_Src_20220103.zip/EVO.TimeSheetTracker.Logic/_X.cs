﻿using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Logic
{
    /// <summary>
    /// 用在临时储存connection string,做功能显示用
    /// </summary>
    public class DbSessionEnum : EnumBase<DbSessionEnum>
    {
        #region Enumeration Elements
        /* ==========================================================================
         * Name: 
         * Description:  
         * ==========================================================================*/
        public static readonly DbSessionEnum Provider = new DbSessionEnum(1, "Provider", "System.Data.SqlClient");
        public static readonly DbSessionEnum ConnStr = new DbSessionEnum(2, "ConnStr", "data source=US007-DC-SQL03;initial catalog=US_TimesheetPortal;persist security info=True;integrated security=SSPI;");

        #endregion

        #region Constructors
        private DbSessionEnum(int id, string name, string extra) : base(id, name, extra)
        {
        }
        #endregion
    }
}
