﻿using EVO.TimeSheetTracker.DataAccess;
using EVO.TimeSheetTracker.Entity;
using System.Collections.Generic;

namespace EVO.TimeSheetTracker.Logic
{
    public class ProjectLogic
    {
        public List<ProjectEntity> GetProject(ProjectEntity entity)
        {
            return new ProjectDA().GetProject(entity);
        }

        public SaveResult Insert(ProjectEntity entity)
        {
            return new ProjectDA().Insert(entity);
        }

        public SaveResult Update(ProjectEntity entity)
        {
            return new ProjectDA().Update(entity);
        }

        public SaveResult Delete(int ID)
        {
            return new ProjectDA().Delete(ID);
        }

        public bool CheckProjectName(string projectName, int ID)
        {
            return new ProjectDA().CheckProjectName(projectName, ID);
        }

        public SaveResult SubmitProjects(List<int> projectIDs, string userID)
        {
            return new ProjectDA().SubmitProjects(projectIDs, userID);
        }

        /// <summary>
        /// validate project before submit
        /// </summary>
        /// <param name="projectIDs"></param>
        /// <param name="userID"></param>
        /// <returns>empty string indicates no errors, not empty string indicates a error message.</returns>
        public string ValidateSubmittedProjects(List<int> projectIDs, string userID)
        {
            return new ProjectDA().ValidateSubmittedProjects(projectIDs, userID);
        }

        public List<ProjectApprovalQueueEntity> GetProjectApprovalList(TimeSheetQueryEntity entity)
        {
            return new ProjectDA().GetProjectApprovalList(entity);
        }

        public SaveResult RejectProjects(List<int> requestIDs, string userID)
        {
            return new ProjectDA().RejectProjects(requestIDs, userID);
        }

        public SaveResult ApprovalProjects(List<int> requestIDs, string userID)
        {
            return new ProjectDA().ApprovalProjects(requestIDs, userID);
        }

        public SaveResult CloseProjects(List<int> requestIDs, string userID)
        {
            return new ProjectDA().CloseProjects(requestIDs, userID);
        }

        public SaveResult UpdateProjectComment(ProjectApprovalQueueEntity entity)
        {
            return new ProjectDA().UpdateProjectComment(entity);
        }

        public List<PeriodMonthEntity> GetPeriodMonth()
        {
            return new ProjectDA().GetPeriodMonth();
        }

        public List<SystemAssetEntity> GetSystemAssets()
        {
            return new ProjectDA().GetSystemAssets();
        }

        public List<SettingsEntity> GetSubmittedUsersOfProject(int period)
        {
            return new ProjectDA().GetSubmittedUsersOfProject(period);
        }

        public List<SettingsEntity> GetProjectNames(string resourceID, bool isAdmin)
        {
            return new ProjectDA().GetProjectNames(resourceID, isAdmin);
        }

        public List<ProjectEntity> GetProjectByID(int ID)
        {
            return new ProjectDA().GetProjectByID(ID);
        }

        public List<ProjectEntity> GetProjectByNumber(string projectNumber, string employeeName)
        {
            return new ProjectDA().GetProjectByNumber(projectNumber, employeeName);
        }

        public List<ProjectPhaseEntity> GetProjectPhaseWithTeamOwner(int ProjectID, int OwnerID, int RequestType, string userName = "")
        {
            return new ProjectDA().GetProjectPhaseWithTeamOwner(ProjectID, OwnerID, RequestType, userName);
        }

        public List<SettingsEntity> GetTeamAndOwners(string userID, bool isAdmin, int projectID)
        {
            return new ProjectDA().GetTeamAndOwners(userID, isAdmin, projectID);
        }

        public SaveResult UpdateProjectPhaseWithTeam(List<ProjectPhaseEntity> projectPhaseEntities, string userID)
        {
            return new ProjectDA().UpdateProjectPhaseWithTeam(projectPhaseEntities, userID);
        }

        public List<string> GetProjectNameForFilter(string userName, int period, bool isAdmin, int requestType)
        {
            return new ProjectDA().GetProjectNameForFilter(userName, period, isAdmin, requestType);
        }
    }
}