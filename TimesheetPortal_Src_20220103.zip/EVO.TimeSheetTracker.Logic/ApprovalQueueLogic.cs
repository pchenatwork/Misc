﻿using EVO.TimeSheetTracker.DataAccess;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Logic
{
    public class ApprovalQueueLogic
    {
        public ApprovalQueueEntity GetApprovalQueueByID(int requestID)
        {
            return new ApprovalQueueDAO().GetApprovalQueueByID(requestID);
        }

        public List<ApprovalQueueEntity> GetApprovals(int referenceID, int requstTypeID)
        {
            return new ApprovalQueueDAO().GetApprovals(referenceID, requstTypeID);
        }
    }
}
