﻿using EVO.TimesheetPortal.Entity;
using FrameworkBase.BusinessLogic;
using FrameworkBase.DataAccess;
using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimesheetPortal.BusinessLogic
{
    public class EmailTemplateManager : ManagerBase<EmailTemplate>
    {
        #region	Constructors

        private EmailTemplateManager(IDbSession dbSession, IDataAccessObject<EmailTemplate> dao) : base(dbSession, dao)
        {
        }

        static EmailTemplateManager()
        {
            // Initialize logger here if needed
        }

        #endregion constructors

        #region Custom menthods can't handle by IManager

        #endregion
    }
}