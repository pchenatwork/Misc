﻿/*=======================================================================
* Modification History:
* ----------------------------------------------------------------------
* 10/14/2021   DINO       Introduced
*=======================================================================*/

using EVO.TimesheetPortal.Entity;
using FrameworkBase.BusinessLogic;
using FrameworkBase.DataAccess;

namespace EVO.TimesheetPortal.BusinessLogic
{
    public class EmployeeActivityMapManager : ManagerBase<EmployeeActivityMap>
    {
        #region	Constructors

        private EmployeeActivityMapManager(IDbSession dbSession, IDataAccessObject<EmployeeActivityMap> dao) : base(dbSession, dao)
        {
        }

        static EmployeeActivityMapManager()
        {
        }

        #endregion constructors

        #region Custom menthods can't handle by IManager
        #endregion
    }
}