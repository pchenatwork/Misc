﻿using EVO.TimesheetPortal.Entity;
using FrameworkBase.BusinessLogic;
using FrameworkBase.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;

#region
/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/
#endregion

namespace EVO.TimesheetPortal.BusinessLogic
{
    public class ProjectManager : ManagerBase<Project>
    {
        #region	Constructors
        private ProjectManager(IDbSession dbSession, IDataAccessObject<Project> dao)
            : base(dbSession, dao)
        {
        }

        static ProjectManager()
        {
            //_logger can go here
        }
        #endregion constructors

        #region Custom menthods outside of IManager
        public bool UpdateWorkflowStatus(int ProjectId, int NewStatusId, string By, string Comment)
        {
            return (bool)dao.InvokeByMethodName("UpdateWorkflowStatus",
                new object[] { dbSession, ProjectId, NewStatusId, By, Comment });
        }
        /// <summary>
        /// Individually update ProjectTeam association
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <param name="IdsJson">TeamId in Json form eg '[{"Id":4}, {"Id":3}]'</param>
        /// <param name="by">Update By UserName</param>
        /// <returns></returns>
        public bool UpdateTeams(int ProjectId, string IdsJson, string by)
        {
            return (bool)dao.InvokeByMethodName("UpdateTeams",
                new object[] { dbSession, ProjectId, IdsJson, by });

        }
        /// <summary>
        /// Individually update ProjectActivity association
        /// </summary>
        /// <param name="ProjectId"></param>
        /// <param name="IdsJson">ActivityId in Json form eg '[{"Id":4}, {"Id":3}]'</param>
        /// <param name="by">Update By UserName</param>
        /// <returns></returns>
        public bool UpdateActivities(int ProjectId, string IdsJson, string by)
        {
            return (bool)dao.InvokeByMethodName("UpdateActivities",
                new object[] { dbSession, ProjectId, IdsJson, by });

        }

        public List<Project> FindAllByProjectAdmin()
        {
            var jsonTokens = new { };
            return this.dao.Find(this.dbSession, JsonSerializer.Serialize(jsonTokens)).ToList();
        }
        public List<Project> FindAllByAccounting()
        {
            // Accounting only see Approved and Impaired project 
            var jsonTokens = new { statusids = new int[] { 
                        ProjectStatusEnum.Approved.Id,
                        ProjectStatusEnum.Impaired.Id} };
            return this.dao.Find(this.dbSession, JsonSerializer.Serialize(jsonTokens)).ToList();
        }
        public List<Project> FindAllByITExecutive()
        {
            // IT Exec will see all but "deleted"/draft project ?? To be confirmed
            var jsonTokens = new
            {
                statusids = new int[] {
                        ProjectStatusEnum.Approved.Id,
                        ProjectStatusEnum.Closed.Id,
                        ProjectStatusEnum.Impaired.Id,
                        ProjectStatusEnum.PendAppv.Id,
                        ProjectStatusEnum.Rejected.Id}
            };
            return this.dao.Find(this.dbSession, JsonSerializer.Serialize(jsonTokens)).ToList();
        }

        public string JsonTest()
        {
            var jsonTokens = new { deptcode = "724", statusids = new int[] { 11, 12, 13 } };
            return JsonSerializer.Serialize(jsonTokens);

        }
        #endregion
    }
}
