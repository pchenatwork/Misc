﻿using EVO.TimesheetPortal.Entity;
using FrameworkBase.BusinessLogic;
using FrameworkBase.DataAccess;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace EVO.TimesheetPortal.BusinessLogic
{
    public class TimesheetAccountingManager : ManagerBase<TimeSheetAccounting>
    {
        #region	Constructors
        private TimesheetAccountingManager(IDbSession dbSession, IDataAccessObject<TimeSheetAccounting> dao)
            : base(dbSession, dao)
        {
        }

        static TimesheetAccountingManager()
        {
            //_logger can go here
        }
        #endregion constructors

        public IList<TimeSheetAccounting> FindByPeriodCode(string periodCode, string entitiesID)
        {
            return dao.InvokeByMethodName("FindByPeriodCode", new object[] { this.dbSession, periodCode, entitiesID });
        }
    }
}