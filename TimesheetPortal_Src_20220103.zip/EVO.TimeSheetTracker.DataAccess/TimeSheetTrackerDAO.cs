﻿using EVO.Components2;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Configuration;

namespace EVO.TimeSheetTracker.DataAccess
{
    public abstract class TimeSheetTrackerDAO : DAO
    {
        internal override string DataBaseConnectionString()
        {
            return "data source=US007-DC-SQL03;initial catalog=US_TimesheetPortal_v1;persist security info=True;integrated security=SSPI;";
            //string connectionString = @"ConfigurationManager.ConnectionStrings["TimeSheetTrackerV1"].ToString()";
            //return EncDec.EVODecrypt(connectionString);
        }

        internal void LogError(Exception ex)
        {
            new ApplicationLog().LogError(new ApplicationLogEntity
            {
                StackTrace = ex.StackTrace,
                UserName = "ServerException",
                Message = ex.Message,
                Date = DateTime.Now,
                Browser = "",
                MachineName = Environment.MachineName,
                OperatingSystem = Environment.OSVersion.ToString()
            });
        }
    }
}