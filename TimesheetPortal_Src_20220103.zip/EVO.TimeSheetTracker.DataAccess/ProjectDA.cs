﻿using EVO.Common.UtilityCore;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Transactions;

namespace EVO.TimeSheetTracker.DataAccess
{
    public class ProjectDA : TimeSheetTrackerDAO
    {
        public List<ProjectEntity> GetProject(ProjectEntity entity)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@StartDate",entity.StartDate),
                    new SqlParameter("@EndDate",entity.EndDate),
                    new SqlParameter("@Teams",ResolveListOfID(entity.Teams)),
                    new SqlParameter("@IsAdmin",entity.IsAdmin),
                    new SqlParameter("@IsActive",entity.IsActive),
                    new SqlParameter("@CreateBy",entity.CreateBy)
                };
                var xml = new ProjectDA().RunProcedureXmlString("SPU_Get_Project", listSqlParameter);
                return SerializeObject<List<ProjectEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public SaveResult Insert(ProjectEntity entity)
        {
            var result = new SaveResult();
            using (var trans = new TransactionScope())
            {
                try
                {
                    List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ProjectName",entity.ProjectName),
                    new SqlParameter("@Description",entity.Description),
                    new SqlParameter("@StartDate",entity.StartDate),
                    new SqlParameter("@EndDate",entity.EndDate),
                    new SqlParameter("@ProductionDate",entity.ProductionDate),
                    new SqlParameter("@TotalEstimatedHours",entity.TotalEstimatedHours),
                    new SqlParameter("@StatusID",entity.StatusID),
                    new SqlParameter("@Phases",ResolveListOfID(entity.Phases)),
                    new SqlParameter("@TypeID",entity.TypeID),
                    new SqlParameter("@Impairment",entity.Impairment),
                    new SqlParameter("@NewProjectOfMonth",entity.NewProjectOfMonth),
                    new SqlParameter("@IsActive",entity.IsActive),
                    new SqlParameter("@UpdateDate",entity.UpdateDate),
                    new SqlParameter("@UpdateBy",entity.UpdateBy),
                    new SqlParameter("@SystemRef",entity.SystemRef),
                    new SqlParameter("@SystemName",ResolveListOfID(entity.SystemName)),
                    new SqlParameter("@Teams",ResolveListOfID(entity.Teams)),
                    new SqlParameter("@TimezoneOffset",entity.TimezoneOffset)
                };
                    string retval = new ProjectDA().RunProcedureXmlString("SPU_Insert_Project", listSqlParameter);
                    if (int.TryParse(retval, out int newID))
                    {
                        result.Success = true;
                        entity.ProjectID = newID;
                        result.AssociatedObject = newID;
                    }
                    else
                    {
                        result.Success = false;
                        result.ErrorDescription = retval;
                    }
                    if (entity.Phases != null)
                    {                   
                        UpdateProjectPhase(entity.Phases, newID, entity.UpdateBy, 1);
                    }
                    if (entity.TimesheetProjectPhases != null)
                    {
                        UpdateProjectPhase(entity.TimesheetProjectPhases, newID, entity.UpdateBy, 2);
                    }
                    trans.Complete();
                }
                catch (Exception ex)
                {
                    
                    LogError(ex);
                    result.Success = false;
                    result.ErrorDescription = ex.Message;
                }
                if (!System.Diagnostics.Debugger.IsAttached)
                {
                    result.ErrorDescription = "Failed to Insert the Project Record.";
                }
            }
            return result;
        }
        public void UpdateProjectPhase(List<SettingsEntity> Phases,int projectID,string userId,int requesttype)
        {
            var ownerIdList = Phases.Select(s => s.SettingsID).Distinct();
            foreach (int ownerId in ownerIdList)
            {
                var phaselist = Phases.Where(p => p.SettingsID == ownerId);
                if (phaselist != null && phaselist.Count() > 0)
                {
                    List<SqlParameter> sqlParameter = new List<SqlParameter>{
                                    new SqlParameter("@ProjectID", projectID),
                                    new SqlParameter("@OwnerID", phaselist.FirstOrDefault()?.SettingsID),
                                    new SqlParameter("@Phases",ResolveListOfID(phaselist.Select(s=> int.Parse(s.Type)).ToList())),
                                    new SqlParameter("@User", userId),
                                    new SqlParameter("@RequestType",requesttype)
                                };
                    new ProjectDA().RunProcedureXmlString("SPU_Update_ProjectPhase", sqlParameter);
                }

            }
        }

        public SaveResult Update(ProjectEntity entity)
        {
            var result = new SaveResult();
            using (var trans = new TransactionScope())
            {
                try
                {
                    List<SqlParameter> listSqlParameter = new List<SqlParameter>{
                    new SqlParameter("@ID",entity.ProjectID),
                    new SqlParameter("@ProjectName",entity.ProjectName),
                    new SqlParameter("@Description",entity.Description),
                    new SqlParameter("@StartDate",entity.StartDate),
                    new SqlParameter("@EndDate",entity.EndDate),
                    new SqlParameter("@ProductionDate",entity.ProductionDate),
                    new SqlParameter("@TotalEstimatedHours",entity.TotalEstimatedHours),
                    new SqlParameter("@StatusID",entity.StatusID),
                    new SqlParameter("@TypeID",entity.TypeID),
                    new SqlParameter("@NewProjectOfMonth",entity.NewProjectOfMonth),
                    new SqlParameter("@Impairment",entity.Impairment),
                    new SqlParameter("@IsActive",entity.IsActive),
                    new SqlParameter("@UpdateDate",entity.UpdateDate),
                    new SqlParameter("@UpdateBy",entity.UpdateBy),
                    new SqlParameter("@SystemRef",entity.SystemRef),
                    new SqlParameter("@SystemName",ResolveListOfID(entity.SystemName)),
                    new SqlParameter("@Teams",ResolveListOfID(entity.Teams))
                };
                    string retval = new ProjectDA().RunProcedureXmlString("SPU_Update_Project", listSqlParameter);
                    if (int.TryParse(retval, out int count))
                    {
                        result.Success = true;
                    }
                    else
                    {
                        result.Success = false;
                        result.ErrorDescription = retval;
                    }
                    if (entity.Phases != null)
                    {
                        UpdateProjectPhase(entity.Phases, entity.ProjectID, entity.UpdateBy, 1);
                    }
                    if (entity.TimesheetProjectPhases != null)
                    {
                        UpdateProjectPhase(entity.TimesheetProjectPhases, entity.ProjectID, entity.UpdateBy, 2);
                    }
                    trans.Complete();
                }
                catch (Exception ex)
                {
                    LogError(ex);
                    result.Success = false;
                    result.ErrorDescription = ex.Message;
                }
                if (!System.Diagnostics.Debugger.IsAttached)
                {
                    result.ErrorDescription = "Failed to Update the Project Record.";
                }
            }
            
            return result;
        }

        public SaveResult Delete(int Id)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                new SqlParameter("@ID", Id)
                };
                string retval = new ProjectDA().SqlExecuteNonQuery("SPU_Delete_Project", 180, listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Delete the Project Record.";
            }
            return result;
        }

        public bool CheckProjectName(string projectName, int ID)
        {
            List<SqlParameter> listSqlParameter = new List<SqlParameter>
            {
                new SqlParameter("@projectName", projectName),
                new SqlParameter("@ID", ID)
            };
            var retval = new ProjectDA().RunProcedureXmlString("SPU_Project_CheckName", listSqlParameter);
            return retval.Length > 0;
        }

        public SaveResult SubmitProjects(List<int> projectIDs, string userID)
        {
            var result = new SaveResult();
            string spName = "SPU_Project_Submit";
            List<SaveResult> errorIds = new List<SaveResult>();
            string errorMessage = "";
            projectIDs.ForEach(f =>
            {
                var r = ProjectApprovalProcess(f, userID, spName);
                if (!r.Success)
                {
                    r.AssociatedObject = f;
                    errorMessage += r.ErrorDescription;
                    errorIds.Add(r);
                }
            });
            result.Success = errorIds.Count == 0;
            result.ErrorDescription = errorMessage;
            return result;
        }

        public List<ProjectApprovalQueueEntity> GetProjectApprovalList(TimeSheetQueryEntity entity)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@SubmittedBy",entity.SubmittedBy),
                    new SqlParameter("@PeriodMonthID",entity.PeriodMonthID),
                    new SqlParameter("@Teams",ResolveListOfID(entity.Teams)),
                    new SqlParameter("@IsAdmin",entity.IsAdmin),
                    new SqlParameter("@StatusIDs",ResolveListOfID(entity.StatusID))
                };
                var xml = new ProjectDA().RunProcedureXmlString("SPU_Get_ProjectApprovalData", listSqlParameter);
                return SerializeObject<List<ProjectApprovalQueueEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public SaveResult RejectProjects(List<int> requestIDs, string userID)
        {
            var result = new SaveResult();
            string spName = "SPU_Project_Reject";
            List<SaveResult> errorIds = new List<SaveResult>();
            requestIDs.ForEach(requestID =>
            {
                var r = ProjectApprovalProcess(requestID, userID, spName, false);
                if (!r.Success)
                {
                    r.AssociatedObject = requestID;
                    errorIds.Add(r);
                }
            });
            result.Success = errorIds.Count == 0;
            return result;
        }

        public SaveResult ApprovalProjects(List<int> requestIDs, string userID)
        {
            var result = new SaveResult();
            string spName = "SPU_Project_Approve";
            List<SaveResult> errorIds = new List<SaveResult>();
            requestIDs.ForEach(requestID =>
            {
                var r = ProjectApprovalProcess(requestID, userID, spName, false);
                if (!r.Success)
                {
                    r.AssociatedObject = requestID;
                    errorIds.Add(r);
                }
            });
            result.Success = errorIds.Count == 0;
            return result;
        }

        public SaveResult CloseProjects(List<int> requestIDs, string userID)
        {
            var result = new SaveResult();
            string spName = "SPU_Project_Close";
            List<SaveResult> errorIds = new List<SaveResult>();
            requestIDs.ForEach(requestID =>
            {
                var r = ProjectApprovalProcess(requestID, userID, spName, true);
                if (!r.Success)
                {
                    r.AssociatedObject = requestID;
                    errorIds.Add(r);
                }
            });
            result.Success = errorIds.Count == 0;
            return result;
        }

        public SaveResult UpdateProjectComment(ProjectApprovalQueueEntity entity)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@RequestID",entity.RequestID),
                    new SqlParameter("@Comment",entity.Comment)
                };
                string retval = new ProjectDA().RunProcedureXmlString("SPU_Update_ApprovalQueueComment", listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Update the Project Record.";
            }
            return result;
        }

        public List<PeriodMonthEntity> GetPeriodMonth()
        {
            try
            {
                var xml = new ProjectDA().RunProcedureXmlString("SPU_Get_PeriodMonth");
                return SerializeObject<List<PeriodMonthEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<SystemAssetEntity> GetSystemAssets()
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@IsAdmin",0)
                };
                var xml = new ProjectDA().RunProcedureXmlString("SPU_Get_SystemAsset", listSqlParameter);
                return SerializeObject<List<SystemAssetEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<SettingsEntity> GetSubmittedUsersOfProject(int period)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@PeriodMonthID",period)
                };

                var xml = new ProjectDA().RunProcedureXmlString("SPU_Get_ProjectSubmittedUsers", listSqlParameter);
                return SerializeObject<List<SettingsEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<SettingsEntity> GetProjectNames(string resourceID, bool isAdmin)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@IsAdmin", isAdmin),
                    new SqlParameter("@ResourceID",resourceID)
                };

                var xml = new ProjectDA().RunProcedureXmlString("SPU_Get_ProjectNames", listSqlParameter);
                return SerializeObject<List<SettingsEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<ProjectEntity> GetProjectByID(int ID)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID", ID)
                };

                var xml = new ProjectDA().RunProcedureXmlString("SPU_Get_ProjectByID", listSqlParameter);
                return SerializeObject<List<ProjectEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<ProjectEntity> GetProjectByNumber(string projectNumber, string employeeName)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ProjectNumber", projectNumber),
                    new SqlParameter("@EmployeeName", employeeName)
                };

                var xml = new ProjectDA().RunProcedureXmlString("SPU_Get_ProjectByNumber", listSqlParameter);
                return SerializeObject<List<ProjectEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<ProjectPhaseEntity> GetProjectPhaseWithTeamOwner(int ProjectID, int OwnerID, int RequestType, string userName = "")
        {
            try
            {
                var project = GetProjectByID(ProjectID).FirstOrDefault();
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ProjectID", ProjectID),
                    new SqlParameter("@OwnerID", OwnerID)
                };
                string procName;
                if (RequestType == 1)
                {
                    procName = (!"NonProjectItems".Equals(project?.SystemRef, StringComparison.OrdinalIgnoreCase) && OwnerID > 0) ? "SPU_Get_ProjectPhaseWithTeamOwner" : "SPU_Get_ProjectPhaseForNonTeam";
                }
                else
                {
                    procName = (!"NonProjectItems".Equals(project?.SystemRef, StringComparison.OrdinalIgnoreCase) && OwnerID > 0) ? "SPU_Get_TimesheetProjectPhase" : "SPU_Get_ProjectPhaseForNonTeam";
                }

                var xml = new ProjectDA().RunProcedureXmlString(procName, listSqlParameter);
                return SerializeObject<List<ProjectPhaseEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<SettingsEntity> GetTeamAndOwners(string userID, bool isAdmin, int projectID)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@userID", userID),
                    new SqlParameter("@isAdmin", isAdmin),
                    new SqlParameter("@projectID", projectID)
                };

                var xml = new ProjectDA().RunProcedureXmlString("SPU_Get_TeamAndOwners", listSqlParameter);
                return SerializeObject<List<SettingsEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public SaveResult UpdateProjectPhaseWithTeam(List<ProjectPhaseEntity> projectPhaseEntities, string userID)
        {
            var result = new SaveResult();

            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ProjectID",projectPhaseEntities.FirstOrDefault()?.ProjectID),
                    new SqlParameter("@OwnerID",projectPhaseEntities.FirstOrDefault()?.OwnerID),
                    new SqlParameter("@Phases",ResolveListOfID(projectPhaseEntities.Select(s=>s.PhaseID).ToList())),
                    new SqlParameter("@User",userID),
                    new SqlParameter("@RequestType",projectPhaseEntities.FirstOrDefault()?.RequestType)
                };
                string retval = new ProjectDA().RunProcedureXmlString("SPU_Update_ProjectPhase", listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Update the Project Record.";
            }
            return result;
        }

        public List<string> GetProjectNameForFilter(string userName, int period, bool isAdmin, int requestType)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@UserName", userName),
                    new SqlParameter("@Period", period),
                    new SqlParameter("@IsAdmin", isAdmin),
                    new SqlParameter("@RequestType", requestType)
                };

                var xml = new ProjectDA().RunProcedureXmlString("SPU_Get_ProjectNamesForFilter", listSqlParameter);
                return SerializeObject<List<SettingsEntity>>.FromXml(xml).Select(s => s.Description).ToList();
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        #region Private  methods

        private void CheckTimesheetProjectPhase(List<int> projectIDs, string userID)
        {
            try
            {
                projectIDs.ForEach(f =>
                {
                    var listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ProjectID",f),
                    new SqlParameter("@UserID",userID)
                };
                    new ProjectDA().RunProcedureScaler("SPU_Timesheet_ProjectPhase_Check", listSqlParameter);
                });
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        /// <summary>
        /// validate project before submit
        /// </summary>
        /// <param name="projectIDs"></param>
        /// <param name="userID"></param>
        /// <returns>empty string indicates no errors, not empty string indicates a error message.</returns>
        public string ValidateSubmittedProjects(List<int> projectIDs, string userID)
        {
            //insert default values for timesheet project phase if no data in current month.
            CheckTimesheetProjectPhase(projectIDs, userID);
            //1. check project teams.
            //2. check every team has set a project phase.
            //3. check every team has set a project phase for timesheet.
            string errorMessage = string.Empty;
            List<string> noProjectPhaseTeam = new List<string>();
            List<string> noTimesheetProjectPhaseTeam = new List<string>();

            foreach (var id in projectIDs)
            {
                ProjectEntity project = GetProjectByID(id).FirstOrDefault();
                project?.Teams?.ForEach(team =>
                {
                    var projectPhaseList = GetProjectPhaseWithTeamOwner(id, team.Owner.EmployeeID, 1);
                    var timesheetProjectPhaseList = GetProjectPhaseWithTeamOwner(id, team.Owner.EmployeeID, 2);
                    if (!projectPhaseList.Any(t => t.IsChecked && t.OwnerID == team.Owner.EmployeeID))
                    {
                        if (!noProjectPhaseTeam.Any(a => a == project.ProjectName))
                        {
                            noProjectPhaseTeam.Add(project.ProjectName);
                        }
                    }
                    if (!timesheetProjectPhaseList.Any(t => t.IsChecked && t.OwnerID == team.Owner.EmployeeID))
                    {
                        if (!noTimesheetProjectPhaseTeam.Any(a => a == project.ProjectName))
                        {
                            noTimesheetProjectPhaseTeam.Add(project.ProjectName);
                        }
                    }
                });
            }

            if (noProjectPhaseTeam.Count > 0 && noTimesheetProjectPhaseTeam.Count > 0)
            {
                errorMessage = $"Please set Project phase and Timesheet project phase for all team owners in project [{string.Join(",", noProjectPhaseTeam)}].";
            }
            else
            {
                if (noProjectPhaseTeam.Count > 0)
                {
                    errorMessage = $"Please set Project phase for all team owners in project [{string.Join(",", noProjectPhaseTeam)}].";
                }
                if (noTimesheetProjectPhaseTeam.Count > 0)
                {
                    errorMessage = $"Please set Timesheet project phase for all team owners in project [{string.Join(",", noTimesheetProjectPhaseTeam)}].";
                }
            }
            return errorMessage;
        }

        private DataTable ResolveListOfID(List<SettingsEntity> list)
        {
            var listDt = new DataTable();
            listDt.Columns.Add("ID", typeof(int));
            list?.ForEach(f => listDt.Rows.Add(f.SettingsID));
            return listDt;
        }

        private DataTable ResolveListOfID(List<TeamEntity> list)
        {
            var listDt = new DataTable();
            listDt.Columns.Add("ID", typeof(int));
            list?.ForEach(f => listDt.Rows.Add(f.TeamID));
            return listDt;
        }

        private DataTable ResolveListOfID(List<SystemAssetEntity> list)
        {
            var listDt = new DataTable();
            listDt.Columns.Add("ID", typeof(int));
            list?.ForEach(f => listDt.Rows.Add(f.SystemAssetID));
            return listDt;
        }

        private DataTable ResolveListOfID(List<int> IDList)
        {
            var teamsDt = new DataTable();
            teamsDt.Columns.Add("ID", typeof(int));
            IDList?.ForEach(f => teamsDt.Rows.Add(f));
            return teamsDt;
        }

        private SaveResult ProjectApprovalProcess(int projectID, string userID, string spName, bool HasProjectID = true)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = null;
                if (HasProjectID)
                {
                    listSqlParameter = new List<SqlParameter>
                    {
                        new SqlParameter("@ProjectID", projectID),
                        new SqlParameter("@UserID",userID),
                    };
                }
                else
                {
                    listSqlParameter = new List<SqlParameter>
                    {
                        new SqlParameter("@OldRequestID", projectID),
                        new SqlParameter("@UserID",userID),
                    };
                }

                string retval = new ProjectDA().RunProcedureXmlString(spName, listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            return result;
        }

        #endregion Private  methods
    }
}