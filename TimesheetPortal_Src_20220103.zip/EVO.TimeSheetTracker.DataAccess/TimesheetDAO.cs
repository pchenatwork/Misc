﻿using EVO.Components2;
using FrameworkBase.DataAccess;

using System.Collections.Generic;

using Microsoft.Data.SqlClient;
using System.Xml;
using System.Data;
using System;
using EVO.TimeSheetTracker.Entity;
using FrameworkBase.ValueObject;

#if NETFRAMEWORK
using System.Configuration;
#else
using EVO.Common.UtilityCore.Configuration;
using Microsoft.Extensions.Configuration;
#endif


namespace EVO.TimeSheetTracker.DataAccess
{
    public abstract class TimesheetDAO<T> : DaoBase<T> where T : IValueObject
    {
        private static SqlSession GetDbSession()
        {
#if NETFRAMEWORK
             string connectionString = ConfigurationManager.ConnectionStrings["TimeSheetTrackerV1"].ToString();
#else
            string connectionString = ConfigurationManager.Configuration.GetConnectionString("TimeSheetTracker");
#endif

            string connDecrypted = EncDec.EVODecrypt(connectionString);
            return DbSessionFactory.Instance.GetSqlSession(connDecrypted);
        }

        public virtual int Create(T newObject)
        {
            return Create(GetDbSession(), newObject);
        }
        public virtual bool Update(T obj)
        {
            return Update(GetDbSession(), obj);
        }
        public virtual bool Delete(dynamic Id)
        {
            return Delete(GetDbSession(), Id);
        }
        //public virtual IEnumerable<T> FindByCriteria(string finderType, params object[] criteria)
        //{
        //    return FindByCriteria(GetDbSession(), finderType, criteria);
        //}
        public virtual T Get(dynamic id)
        {
            return Get(GetDbSession(), id);
        }
        public virtual IEnumerable<T> GetAll()
        {
            return GetAll(GetDbSession());
        }
        public virtual object InvokeByMethodName(string methodName, params object[] parameters)
        {
            // return InvokeByMethodName(GetDbSession(), methodName, parameters);
            return null;
        }

        public virtual XmlReader ExecuteXmlReader(string commandText, IEnumerable<SqlParameter> parameters)
        {
            return ExecuteXmlReader(GetDbSession(), commandText, parameters);
        }

        public virtual int ExecuteNonQuery(string commandText, IEnumerable<SqlParameter> parameters, out object retval)
        {
            int execReuslt = ExecuteNonQuery(GetDbSession(), commandText, parameters, out object valOut);
            retval = valOut;
            return execReuslt;
        }

        public void LogError(Exception ex)
        {
            new ApplicationLog().LogError(new ApplicationLogEntity
            {
                StackTrace = ex.StackTrace,
                UserName = "ServerException",
                Message = ex.Message,
                Date = DateTime.Now,
                Browser = "",
                MachineName = Environment.MachineName,
                OperatingSystem = Environment.OSVersion.ToString()
            });
        }
    }
}