﻿using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;

namespace EVO.TimeSheetTracker.DataAccess
{
    public class ApplicationLog : TimesheetDAO<ApplicationLogEntity>
    {
        public SaveResult LogError(ApplicationLogEntity log)
        {
            var result = new SaveResult();

            try
            {
                var parameters = new List<SqlParameter>
                {
                    new SqlParameter("@Message", log.Message),
                    new SqlParameter("@StackTrace", log.StackTrace),
                    new SqlParameter("@UserName", log.UserName),
                    new SqlParameter("@OperatingSystem", log.OperatingSystem),
                    new SqlParameter("@Browser", log.Browser),
                    new SqlParameter("@MachineName", log.MachineName),
                    new SqlParameter("@Date", log.Date)
                };

                var retval = ExecuteNonQuery("SPU_ApplicationLog_Update", parameters, out object retvalOut);

                if (int.TryParse($"{retvalOut}", out int count))
                {
                    result.Success = true;

                    result.ErrorDescription = $"{0} Application Log updated successfully!";
                }
                else
                {
                    result.Success = false;

                    result.ErrorDescription = "Application Log update failed!";
                }
            }
            catch (Exception ex)
            {
                //LogError(ex);
                result.Success = false;

                result.ErrorDescription = ex.Message;
            }

            return result;
        }

        public IEnumerable<ApplicationLogEntity> GetApplicationLogs(ApplicationLogEntity entity)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>();
                var reader = ExecuteXmlReader("SPU_ApplicationLog_Get", listSqlParameter);
                return DeserializeCollection(reader);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }
    }
}