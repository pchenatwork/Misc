﻿using EVO.Common.UtilityCore;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace EVO.TimeSheetTracker.DataAccess
{
    public class SettingsDA : TimeSheetTrackerDAO
    {
        public List<SettingsEntity> GetProjectType()
        {
            try
            {
                var xml = new SettingsDA().RunProcedureXmlString("SPU_Get_ProjectType");
                var res = SerializeObject<List<SettingsEntity>>.FromXml(xml);
                return res;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<SettingsEntity> GetProjectStatus()
        {
            try
            {
                var xml = new SettingsDA().RunProcedureXmlString("SPU_Get_ProjectStatus");
                var res = SerializeObject<List<SettingsEntity>>.FromXml(xml);
                return res;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<SettingsEntity> GetTimesheetStatus()
        {
            try
            {
                var xml = new SettingsDA().RunProcedureXmlString("SPU_Get_TimesheetStatus");
                var res = SerializeObject<List<SettingsEntity>>.FromXml(xml);
                return res;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<SettingsEntity> GetSettingsByCategory(string category)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@Category",category),
                };
                var xml = new SettingsDA().RunProcedureXmlString("SPU_Get_SettingByCategory", listSqlParameter);
                return SerializeObject<List<SettingsEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<SettingsEntity> GetSettings(SettingsEntity entity)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID",entity.SettingsID),
                    new SqlParameter("@Description",entity.Description),
                    new SqlParameter("@Category",entity.Category),
                    new SqlParameter("@IsActive",entity.IsActive),
                    new SqlParameter("@OrderBy",entity.OrderBy),
                };
                var xml = new SettingsDA().RunProcedureXmlString("SPU_Get_Settings", listSqlParameter);
                return SerializeObject<List<SettingsEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public SaveResult Insert(SettingsEntity entity)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@Description",entity.Description),
                    new SqlParameter("@Category",entity.Category),
                    new SqlParameter("@IsActive",entity.IsActive),
                    new SqlParameter("@OrderBy",entity.OrderBy),
                };
                string retval = new SettingsDA().RunProcedureXmlString("SPU_Insert_Settings", listSqlParameter);
                if (int.TryParse(retval, out int newID))
                {
                    result.AssociatedObject = newID;
                    entity.SettingsID = newID;
                    result.Success = true;
                    result.AssociatedObject = newID;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Insert the Settings Record.";
            }
            return result;
        }

        public SaveResult Update(SettingsEntity entity)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID",entity.SettingsID),
                    new SqlParameter("@Description",entity.Description),
                    new SqlParameter("@Category",entity.Category),
                    new SqlParameter("@IsActive",entity.IsActive),
                    new SqlParameter("@OrderBy",entity.OrderBy),
                };
                string retval = new SettingsDA().SqlExecuteNonQuery("SPU_Update_Settings", 180, listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Update the Settings Record.";
            }
            return result;
        }

        public SaveResult Delete(int Id)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
            {
                new SqlParameter("@ID", Id)
            };
                string retval = new SettingsDA().SqlExecuteNonQuery("SPU_Delete_Settings", 180, listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Delete the Settings Record.";
            }
            return result;
        }

        public List<SystemAssetEntity> GetSystemAssets(bool isAdmin)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@IsAdmin", isAdmin)
                };
                var xml = new SettingsDA().RunProcedureXmlString("SPU_Get_SystemAsset", listSqlParameter);
                return SerializeObject<List<SystemAssetEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public SaveResult InsertSystemAsset(SettingsEntity entity)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@Description",entity.Description),
                    new SqlParameter("@IsActive",entity.IsActive)
                };
                string retval = new SettingsDA().RunProcedureXmlString("SPU_Insert_SystemAsset", listSqlParameter);
                if (int.TryParse(retval, out int newID))
                {
                    result.AssociatedObject = newID;
                    entity.SettingsID = newID;
                    result.Success = true;
                    result.AssociatedObject = newID;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Insert the Settings Record.";
            }
            return result;
        }

        public SaveResult UpdateSystemAsset(SettingsEntity entity)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID",entity.SettingsID),
                    new SqlParameter("@Description",entity.Description),
                    new SqlParameter("@IsActive",entity.IsActive)
                };
                string retval = new SettingsDA().SqlExecuteNonQuery("SPU_Update_SystemAsset", 180, listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Update the Settings Record.";
            }
            return result;
        }

        public SaveResult DeleteSystemAsset(int Id)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
            {
                new SqlParameter("@ID", Id)
            };
                string retval = new SettingsDA().SqlExecuteNonQuery("SPU_Delete_SystemAsset", 180, listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Delete the Settings Record.";
            }
            return result;
        }

        public List<RoleStatusEntity> GetRoleStatus()
        {
            try
            {
                var xml = new SettingsDA().RunProcedureXmlString("SPU_Get_RoleStatus");
                return SerializeObject<List<RoleStatusEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<SettingsEntity> GetTimehseetProjectPhase(int projectID, int teamOwnerID)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ProjectID",projectID),
                    new SqlParameter("@OwnerID",teamOwnerID)
                };
                var xml = new SettingsDA().RunProcedureXmlString("SPU_Get_TimesheetProjectPhase", listSqlParameter);
                var settingList = new List<SettingsEntity>();
                SerializeObject<List<ProjectPhaseEntity>>.FromXml(xml).ForEach(f =>
                {
                    if (f.IsChecked)
                    {
                        settingList.Add(new SettingsEntity
                        {
                            Description = f.PhaseDesc,
                            SettingsID = f.PhaseID
                        });
                    }
                });
                return settingList;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }


        public List<EmailTemplateEntity> GetEmailTemplates()
        {
            try
            {
                var xml = new SettingsDA().RunProcedureXmlString("SPU_Get_EmailTemplate");
                var res = SerializeObject<List<EmailTemplateEntity>>.FromXml(xml);
                return res;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }



        public SaveResult CreateTimesheetPeriod()
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
            {
            };
                string retval = new SettingsDA().SqlExecuteNonQuery("SPU_Insert_PeriodMonth", 180, listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Create the timesheet period Record.";
            }
            return result;
        }
    }
}