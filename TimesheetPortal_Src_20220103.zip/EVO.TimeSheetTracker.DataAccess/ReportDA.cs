﻿using EVO.Common.UtilityCore;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;

namespace EVO.TimeSheetTracker.DataAccess
{
    public class ReportDA : TimeSheetTrackerDAO
    {
        public ReportProjectStatusEntity GetProjectSubmittedStatus()
        {
            try
            {
                var xml = new ReportDA().RunProcedureXmlString("SPU_Report_ProjectSubmittedStatus");
                var res = SerializeObject<ReportProjectStatusEntity>.FromXml(xml);
                return res;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<ReportTimesheetStatusEntity> GetTimesheetSubmittedStatus()
        {
            try
            {
                var xml = new ReportDA().RunProcedureXmlString("SPU_Report_TimesheetSubmittedStatus");
                var res = SerializeObject<List<ReportTimesheetStatusEntity>>.FromXml(xml);
                return res;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }
    }
}