﻿#region Header Info

/*=======================================================================
* Modification History: 
* ----------------------------------------------------------------------
* 10/2021   PCHEN       Introduced
*=======================================================================*/

using FrameworkBase.DataAccess;
using FrameworkBase.ValueObject;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Data;
using System.Xml;
#endregion

namespace EVO.TimeSheetTracker.DataAccess
{
    /// <summary>
    /// Extend Framebase.AbstractDao() with project specific helper functions
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class DaoBase<T> : AbstractDao<T> where T : IValueObject
    {
        #region Static Helpers
        /// <summary>
        /// All finder SP must have only one @JsonTokens parameter
        /// </summary>
        /// <param name="dbSession"></param>
        /// <param name="spFinder">Name of the finder SP</param>
        /// <param name="jsonTokens"></param>
        /// <returns></returns>
        /// 
        //         public override IEnumerable<T> Find(IDbSession dbSession, string jsonTokens)
        protected static IEnumerable<T> _Find(IDbSession dbSession, string spFinder, string jsonTokens)
        {
            //string sp = "SPU_" + typeof(T).Name + "_Find";
            SqlParameter[] P = new SqlParameter[] { new SqlParameter("@JsonTokens", jsonTokens) };
            XmlReader reader = ExecuteXmlReader(dbSession, spFinder, P);
            return DeserializeCollection(reader);
        }

        /// <summary>
        /// Wrapper for executing  SqlCommand.ExecuteXmlReader() method, See MSDN for more details
        /// </summary>
        /// <param name="dbSession"></param>
        /// <param name="commandText"></param>
        /// <param name="parameters">parameters[0] = new SqlParameter("@ReturnValue", SqlDbType.Int);</param>
        /// <returns></returns>
        protected static XmlReader ExecuteXmlReader(IDbSession dbSession, string commandText, IEnumerable<SqlParameter> parameters)
        {
            XmlReader reader;
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = (SqlConnection)dbSession.DbConnection;
                if (dbSession.Transaction != null) cmd.Transaction = (SqlTransaction)dbSession.Transaction;

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = commandText;

                foreach (SqlParameter p in parameters)
                {
                    cmd.Parameters.Add(p);
                }

                if (cmd.Connection.State != ConnectionState.Open) cmd.Connection.Open();

                reader = cmd.ExecuteXmlReader();
            }
            return reader;
        }

        /// <summary>
        /// Wrapper for executing SqlCommand.ExecuteNonQuery() Command, See MSDN for more details
        /// </summary>
        /// <param name="dbSession"></param>
        /// <param name="commandText"></param>
        /// <param name="parameters"></param>
        /// <returns>row count</returns>
        protected static int ExecuteNonQuery(IDbSession dbSession, string commandText, IEnumerable<SqlParameter> parameters, out object retval)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = commandText;

                foreach (SqlParameter p in parameters)
                {
                    cmd.Parameters.Add(p);
                }

                if (dbSession.Transaction != null)
                {
                    cmd.Transaction = (SqlTransaction)dbSession.Transaction;
                    cmd.Connection = cmd.Transaction.Connection;
                }
                else
                    cmd.Connection = (SqlConnection)dbSession.DbConnection;

                if (cmd.Connection.State != ConnectionState.Open) cmd.Connection.Open();

                int rowcount = cmd.ExecuteNonQuery();
                retval = cmd.Parameters["@ReturnValue"].Value;
                return rowcount;
            }
        }

        protected static DataSet Execute (IDbSession dbSession, string commandText,IEnumerable<SqlParameter> parameters, int commandTimeOut = 30)
        {            
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = (SqlConnection)dbSession.DbConnection;
                if (dbSession.Transaction != null) cmd.Transaction = (SqlTransaction)dbSession.Transaction;

                cmd.CommandType =CommandType.StoredProcedure;
                cmd.CommandText = commandText;

                foreach (SqlParameter p in parameters)
                {
                    cmd.Parameters.Add(p);
                }

                if (cmd.Connection.State != ConnectionState.Open) cmd.Connection.Open();

                SqlDataAdapter da = new SqlDataAdapter();
                DataSet dataSet = new DataSet();

                da.SelectCommand = cmd;
                cmd.CommandTimeout = commandTimeOut;
                da.Fill(dataSet);
                return dataSet;
            }
           
        }

        protected static T Deserialize(XmlReader reader)
        {
            return FrameworkBase.Util.XMLSerializer.Deserialize<T>(reader);
        }

        protected static IEnumerable<T> DeserializeCollection(XmlReader reader)
        {
            return FrameworkBase.Util.XMLSerializer.Deserialize<T[]>(reader);
        }

        #endregion
    }
}
