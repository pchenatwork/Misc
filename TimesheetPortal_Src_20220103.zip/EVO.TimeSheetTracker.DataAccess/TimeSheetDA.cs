﻿using EVO.Common.UtilityCore;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Transactions;

namespace EVO.TimeSheetTracker.DataAccess
{
    public class TimeSheetDA : TimeSheetTrackerDAO
    {
        public List<TimeSheetEntity> GetTimeSheet(TimeSheetQueryEntity entity)
        {
            List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@PeriodMonthID",entity.PeriodMonthID),
                    new SqlParameter("@ResourceID",entity.SubmittedBy),
                    new SqlParameter("@IsAdmin",entity.IsAdmin),
                    new SqlParameter("@StatusIDs",ResolveListOfID(entity.StatusID)),
                    new SqlParameter("@TimesheetID",entity.TimesheetID),
                };

            var xml = new TimeSheetDA().RunProcedureXmlString("SPU_Get_Timesheet", listSqlParameter);
            try
            {
                return SerializeObject<List<TimeSheetEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public List<TimeSheetEntity> GetTimeSheetSummary(TimeSheetQueryEntity entity)
        {
            List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@PeriodMonthID",entity.PeriodMonthID),
                    new SqlParameter("@ResourceID",entity.SubmittedBy),
                    new SqlParameter("@Teams",ResolveListOfID(entity.Teams)),
                    new SqlParameter("@IsAdmin",entity.IsAdmin)
                };
            var xml = new TimeSheetDA().RunProcedureXmlString("SPU_Get_TimeSheetSummary", listSqlParameter);
            try
            {
                return SerializeObject<List<TimeSheetEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public SaveResult DeleteImportTimeSheet(string userName)
        {
            var result = new SaveResult();
            try
            {
                _DeleteImportTimeSheet(userName);

                result.Success = true;
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Delete all the import TimeSheet.";
            }
            return result;
        }

        private void _DeleteImportTimeSheet(string userName)
        {
            List<SqlParameter> listSqlParameter = new List<SqlParameter>() {
                 new SqlParameter("@UserName", userName)
            };
            new TimeSheetDA().SqlExecuteNonQuery("SPU_Delete_ImportTimeSheet", 500, listSqlParameter);
        }

        public SaveResult InsertTimeSheetBatch(List<TimeSheetEntity> entitys,string userName)
        {
            var result = new SaveResult();
            using (var scope = new TransactionScope())
            {
                _DeleteImportTimeSheet(userName); // delete import timesheet;
                foreach (var entity in entitys)
                {
                    string retval = InsertTimeSheet(entity);
                }

                scope.Complete();
            }
            result.Success = true;
            return result;
        }

        public SaveResult Insert(TimeSheetEntity entity)
        {
            var result = new SaveResult();
            try
            {
                string retval = InsertTimeSheet(entity);
                if (int.TryParse(retval, out int newID))
                {
                    result.Success = true;
                    entity.TimeSheetID = newID;
                    result.AssociatedObject = newID;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Insert the Record.";
            }
            return result;
        }

        private string InsertTimeSheet(TimeSheetEntity entity)
        {
            List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ProjectID",entity.Project.ProjectID),
                    new SqlParameter("@ResourceID",entity.ResourceID),
                    new SqlParameter("@ReportDate",entity.ReportDate),
                    new SqlParameter("@Hours",entity.Hours),
                    new SqlParameter("@Description",entity.Description),
                    new SqlParameter("@TFSID",entity.TFSID),
                    new SqlParameter("@StatusID",entity.Status.SettingsID),
                    new SqlParameter("@UpdateDate",entity.UpdateDate),
                    new SqlParameter("@UpdatedBy",entity.UpdatedBy),
                    new SqlParameter("@TimezoneOffset",entity.TimezoneOffset),
                    new SqlParameter("@Type",entity.Type),
                    new SqlParameter("@ProjectPhaseID",entity.Phase.SettingsID),
                    new SqlParameter("@ProjectPhaseLog",entity.ProjectPhaseLog)
                };
            string retval = new TimeSheetDA().RunProcedureXmlString("SPU_Insert_TimeSheet", listSqlParameter);
            return retval;
        }

        public SaveResult Update(TimeSheetEntity entity)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@ID",entity.TimeSheetID),
                    new SqlParameter("@ProjectID",entity.Project.ProjectID),
                    new SqlParameter("@ResourceID",entity.ResourceID),
                    new SqlParameter("@ReportDate",entity.ReportDate),
                    new SqlParameter("@Hours",entity.Hours),
                    new SqlParameter("@Description",entity.Description),
                    new SqlParameter("@TFSID",entity.TFSID),
                    new SqlParameter("@StatusID",entity.Status.SettingsID),
                    new SqlParameter("@UpdateDate",entity.UpdateDate),
                    new SqlParameter("@UpdatedBy",entity.UpdatedBy),
                    new SqlParameter("@ProjectPhaseID",entity.Phase.SettingsID),
                    new SqlParameter("@ProjectPhaseLog",entity.ProjectPhaseLog)
                };
                string retval = new TimeSheetDA().RunProcedureXmlString("SPU_Update_Timesheet", listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Update the Record.";
            }
            return result;
        }

        public SaveResult Delete(int Id)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                new SqlParameter("@ID", Id)
                };
                string retval = new TimeSheetDA().SqlExecuteNonQuery("SPU_Delete_Timesheet", 180, listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Delete the Record.";
            }
            return result;
        }

        public SaveResult SubmitTimeSheets(List<int> timeSheetIDS, string userID)
        {
            var result = new SaveResult();
            List<SaveResult> errorIds = new List<SaveResult>();
            timeSheetIDS.ForEach(f =>
            {
                var r = SubmitTimeSheet(f, userID);
                if (!r.Success)
                {
                    r.AssociatedObject = f;
                    errorIds.Add(r);
                }
            });
            result.Success = errorIds.Count == 0;
            return result;
        }

        private SaveResult SubmitTimeSheet(int timeSheetID, string userID)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@TimeSheetID", timeSheetID),
                    new SqlParameter("@UserID",userID),
                };
                string retval = new TimeSheetDA().RunProcedureXmlString("SPU_TimeSheet_Submit", listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Update the TimeSheet Record.";
            }
            return result;
        }

        private SaveResult TimesheetApprovalProcess(int timesheetID, string userID, string spName, bool HastimesheetID = true)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = null;
                if (HastimesheetID)
                {
                    listSqlParameter = new List<SqlParameter>
                    {
                        new SqlParameter("@TimesheetID", timesheetID),
                        new SqlParameter("@UserID",userID),
                    };
                }
                else
                {
                    listSqlParameter = new List<SqlParameter>
                    {
                        new SqlParameter("@OldRequestID", timesheetID),
                        new SqlParameter("@UserID",userID),
                    };
                }

                string retval = new TimeSheetDA().RunProcedureXmlString(spName, listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Update the Record.";
            }
            return result;
        }

        private DataTable ResolveListOfID(List<TeamEntity> teams)
        {
            var teamsDt = new DataTable();
            teamsDt.Columns.Add("ID", typeof(int));
            teams?.ForEach(f => teamsDt.Rows.Add(f.TeamID));
            return teamsDt;
        }

        private DataTable ResolveListOfID(List<int> IDList)
        {
            var teamsDt = new DataTable();
            teamsDt.Columns.Add("ID", typeof(int));
            IDList?.ForEach(f => teamsDt.Rows.Add(f));
            return teamsDt;
        }

        public List<TimeSheetApprovalQueueEntity> GetTimesheetApprovalList(TimeSheetQueryEntity entity)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@SubmittedBy",entity.SubmittedBy),
                    new SqlParameter("@PeriodMonthID",entity.PeriodMonthID),
                    new SqlParameter("@Teams",ResolveListOfID(entity.Teams)),
                    new SqlParameter("@IsAdmin",entity.IsAdmin),
                    new SqlParameter("@StatusIDs",ResolveListOfID(entity.StatusID))
                };
                var xml = new TimeSheetDA().RunProcedureXmlString("SPU_Get_TimeSheetApprovalData", listSqlParameter);
                return SerializeObject<List<TimeSheetApprovalQueueEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }

        public SaveResult RejectTimesheets(List<int> requestIDs, string userID)
        {
            var result = new SaveResult();
            string spName = "SPU_TimeSheet_Reject";
            List<SaveResult> errorIds = new List<SaveResult>();
            requestIDs.ForEach(f =>
            {
                var r = TimesheetApprovalProcess(f, userID, spName, false);
                if (!r.Success)
                {
                    r.AssociatedObject = f;
                    errorIds.Add(r);
                }
            });
            result.Success = errorIds.Count == 0;
            if (!result.Success)
            {
                result.ErrorDescription = "An error on the server";
            }
            return result;
        }

        public SaveResult ApprovalTimesheets(List<int> requestIDs, string userID)
        {
            var result = new SaveResult();
            string spName = "SPU_TimeSheet_Approve";
            List<SaveResult> errorIds = new List<SaveResult>();
            requestIDs.ForEach(f =>
            {
                var r = TimesheetApprovalProcess(f, userID, spName, false);
                if (!r.Success)
                {
                    r.AssociatedObject = f;
                    errorIds.Add(r);
                }
            });
            result.Success = errorIds.Count == 0;
            if (!result.Success)
            {
                result.ErrorDescription = "An error on the server";
            }
            return result;
        }

        public SaveResult UpdateTimesheetComment(TimeSheetApprovalQueueEntity entity)
        {
            var result = new SaveResult() { Success = true };
            if (string.IsNullOrEmpty(entity.Comment))
            {
                return result;
            }
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@RequestID",entity.RequestID),
                    new SqlParameter("@Comment",entity.Comment)
                };
                string retval = new TimeSheetDA().RunProcedureXmlString("SPU_Update_ApprovalQueueComment", listSqlParameter);
                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
                else
                {
                    result.Success = false;
                    result.ErrorDescription = retval;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Update the Record.";
            }
            return result;
        }

        public List<EmployeeEntity> GetTeamOwnersOfSubmittedTimesheetUser(int period)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@PeriodMonthID",period)
                };

                string xml = new TimeSheetDA().RunProcedureXmlString("SPU_Get_TeamOwnersOfSubmittedTimesheetUser", listSqlParameter);
                return SerializeObject<List<EmployeeEntity>>.FromXml(xml);
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw new Exception("Server side error");
            }
        }
    }
}