﻿using EVO.Common.UtilityCore;
using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace EVO.TimeSheetTracker.DataAccess
{
    public class EmailDA : TimeSheetTrackerDAO
    {
        public List<EmailEntity> GetPendingEmailList(DateTime sendDate)
        {
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@SendDate",sendDate),
                };
                var xml = new EmailDA().RunProcedureXmlString("SPU_Get_PendingEmails", listSqlParameter);
                var res = SerializeObject<List<EmailEntity>>.FromXml(xml);
                return res;
            }
            catch (Exception ex)
            {
                LogError(ex);
                throw ex;
            }
        }

        public SaveResult InsertEmailList(List<EmailRequestEntity> mailList)
        {
            var result = new SaveResult();

            using (var conn = new SqlConnection(new EmailDA().DataBaseConnectionString()))
            {
                conn.Open();

                using (var tx = conn.BeginTransaction())
                {
                    try
                    {
                        foreach (var mailEntity in mailList)
                        {
                            InsertEmail(mailEntity);
                        }

                        tx.Commit();

                        result.Success = true;
                    }
                    catch (Exception e)
                    {
                        LogError(e);

                        tx.Rollback();

                        result.Success = false;

                        result.ErrorDescription = e.Message.Replace("\r\n", "Submit request failed!");
                    }
                }

                conn.Close();
            }

            return result;
        }

        private void InsertEmail(EmailRequestEntity emailEntity)
        {
            List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@TemplateID",emailEntity.TemplateId),
                    new SqlParameter("@Source",emailEntity.Source),
                    new SqlParameter("@Priority",emailEntity.Priority),
                    new SqlParameter("@Subject",emailEntity.Subject),
                    new SqlParameter("@EmailBody",emailEntity.EmailBody),
                    new SqlParameter("@Sender",emailEntity.Sender),
                    new SqlParameter("@Recipients",emailEntity.Recipients),
                    new SqlParameter("@SendDate",emailEntity.SendDate),
                    new SqlParameter("@Status",emailEntity.Status),
                    new SqlParameter("@CC",emailEntity.Cc),
                    new SqlParameter("@Bcc",emailEntity.Bcc),
                    new SqlParameter("@IsHtml",emailEntity.IsHtml)
                };
            string retval = new EmployeeDA().SqlExecuteNonQuery("SPU_Insert_Email", 180, listSqlParameter);

            if (!int.TryParse(retval, out int count))
            {
                throw new Exception(string.Format("Insert email error occurred. Error: {0}", retval));
            }
        }

        public SaveResult UpdateEmailList(List<int> emailIDs)
        {
            var result = new SaveResult();
            try
            {
                List<SqlParameter> listSqlParameter = new List<SqlParameter>
                {
                    new SqlParameter("@EmailIDs",emailIDs.CopyToDataTable())
                };
                string retval = new EmployeeDA().SqlExecuteNonQuery("SPU_Update_EmailsStatus", 180, listSqlParameter);

                if (int.TryParse(retval, out int count))
                {
                    result.Success = true;
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                result.Success = false;
                result.ErrorDescription = ex.Message;
            }
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                result.ErrorDescription = "Failed to Update email list.";
            }
            return result;
        }
    }
}