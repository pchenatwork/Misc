﻿using EVO.TimesheetPortal.BusinessLogic;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace EVO.TimesheetPortal.xUnit
{
    public class Joy
    {

        [Fact]
        public void TimesheetManager_OutlookTest()
        {   // Joy: This method is to pull data for "Resource Project Activities Details"  at Manager Timesheet Approval
            // When "Hours" is clicked at the "Manager Approval" page
            // It is working PCHEN
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var TimesheetMgr = (TimesheetManager)ManagerFactory<Timesheet>.Instance.GetManager(session);
                var x1 = TimesheetMgr.GetOutlookByEmployeeProject(169, 1, "202110");
                var x2 = TimesheetMgr.GetOutlookByEmployee(169, "202110");

                var x3 = TimesheetMgr.ManagerApproval(169, "202110", "Paul.CHEN");

                Assert.True(x1 != null);
            }
        }


        [Fact]
        public void _SampeTester()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var mgr = (TeamManager)ManagerFactory<Team>.Instance.GetManager(session);
                var x = mgr.Get(1);
                Assert.True(x.DeptCode == "257");

                Assert.True(1 == 1);
                Assert.Contains("paul", "ppaaull");
            }
        }

        [Fact]
        public void TimesheetActivity_CreateTest()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                // Create the ValueObject to insert
                TimesheetActivity ts = ValueObjectFactory<TimesheetActivity>.Instance.Create();
                ts.EmployeeId = 17; // PCHEN
                ts.ProjectId = 2;
                ts.ActivityId = 2;
                ts.ActivityDate = DateTime.Parse("10/17/2021");
                ts.Description = "Activity from 10/17/2021 for Proj 2 Activity 2";
                ts.Hours = 1.17m;
                ts.UpdateBy = "paul.chen";

                // Call manager to do insertion
                var mgr = ManagerFactory<TimesheetActivity>.Instance.GetManager(session);
                var newID = mgr.Create(ts);

                Console.WriteLine("New id from [Timesheet] table is: {0}", newID);
                Assert.True(newID > 0);
            }
        }

        [Fact]
        public void TimesheetActivity_DeleteTest()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                // create manager 
                var mgr = ManagerFactory<TimesheetActivity>.Instance.GetManager(session);
                var t = mgr.Delete(11);
                Assert.True(t == true); // new value should match to new value
            }
        }

        [Fact]
        public void TimesheetActivity_UpdateTest()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                // create manager 
                var mgr = ManagerFactory<TimesheetActivity>.Instance.GetManager(session);
                var ts = mgr.Get(12); // to pull a record

                ts.Hours = 1.11m; // update a value
                ts.UpdateBy = "Joy";
                mgr.Update(ts); // call manager to update TS record

                var ts_after = mgr.Get(12); // Retrieve the record again
                Assert.True(ts_after.Hours == 1.77m); // new value should match to new value
            }
        }
        [Fact]
        public void TimesheetActivity_FindTest()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                // create manager 
                var mgr = (TimesheetActivityManager)ManagerFactory<TimesheetActivity>.Instance.GetManager(session);
                var l1 = mgr.FindByDate(171, DateTime.Parse("10/1/2021"));
                var l2 = mgr.FindByDate(171, DateTime.Parse("10/1/2021"), DateTime.Parse("11/1/2021"));

                Assert.True(1==1); 
            }
        }
    }
}
