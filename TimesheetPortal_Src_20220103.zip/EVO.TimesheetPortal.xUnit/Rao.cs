﻿using EVO.TimesheetPortal.BusinessLogic;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using System.Linq;
using EVO.TimesheetPortal.DataAccess;

namespace EVO.TimesheetPortal.xUnit
{
    public class Rao
    {
        [Fact]
        public void _SampeTester()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var mgr = (TeamManager)ManagerFactory<Team>.Instance.GetManager(session);
                var x = mgr.Get(1);
                Assert.True(x.DeptCode == "257");

                Assert.True(1 == 1);
                Assert.Contains("paul", "ppaaull");
            }
        }

        [Fact]
        public void AdminRole_Test()
        {
            var adminRole = AdminRolesEnum.Admin.Name;
            Assert.True(adminRole == "Admin");

            var datasource = (from a in AdminRolesEnum.List select new { Key = a.Id, DisplayValue = a.Name }).ToList();
            Assert.True(datasource.Count > 0);
        }

        [Fact]
        public void Timesheet_ExecutiveOutlook()
        {
            // To Rao: 2021/10/19 PCHEN: Intend to Demo the view the IT Executive Monthly View
            // Please run EXEC SPU_Timesheet_Outlook_Exec(_v2) in SQL Server SSMS to see how data look like
            // Note: Further DataTable manipulation is needed...
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var mgr = (TimesheetManager)ManagerFactory<Timesheet>.Instance.GetManager(session);
                //var dataTable = mgr.GetOutlookByExecutiveSummary("");
                var x = mgr.GetOutlookTeamResource("202110");
                Assert.True(x.Details.Count>0);
            }
        }


        [Fact]
        public void Test_Team_GetList()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var mgr = (TeamManager)ManagerFactory<Team>.Instance.GetManager(session);
                var x = mgr.Get(1);
                x.UpdateBy = "paul.rao";
                var updateResult = mgr.Update(x);

                x = mgr.Get(1);
                var teams = mgr.FindByEntity(new TeamCriteria() { Id = 1 });
                Assert.True(teams.Count== 1);

                Assert.True(teams.FirstOrDefault().Name  == x.Name);
               
            }
        }
    }
}
