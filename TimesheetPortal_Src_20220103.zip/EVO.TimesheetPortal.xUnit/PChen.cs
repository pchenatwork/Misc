﻿using EVO.TimesheetPortal.BusinessLogic;
using EVO.TimesheetPortal.DataAccess;
using EVO.TimesheetPortal.Entity;
using FrameworkBase.DataAccess;
using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Xunit;

namespace EVO.TimesheetPortal.xUnit
{
    public class PChen
    {


        //[Fact]
        //public void ProjectDao_GetNextProjectNo()
        //{
        //    int i = 0;

        //    using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
        //    {
        //        var dao = (ProjectDao)DaoFactory<Project>.Instance.GetDao();
        //        var x = dao._UpdateProjectNo(session, 21, "ProjNo.Tester");
        //        Assert.True(1==1);
        //    }
        //}


        [Fact]
        public void EmployeeRoles()
        {

            Employee E = ValueObjectFactory<Employee>.Instance.Create();

            E.RoleNames.Add("ProjectAdmin");
            E.RoleNames.Add("Resource");


            var str = JsonSerializer.Serialize(E.RoleNames);

            Assert.True(str.Length > 0);

        }


        [Fact]
        public void DemoEnum()
        {
            // Demo of using Enum to populate a dropdown
            var xx = ProjectStatusEnum.GetById(-11);
            var datasource = (from a in ProjectStatusEnum.List select new { Key =a.Id, DisplayValue = a.Name }).ToList();
            Assert.True(datasource.Count > 0);

            var StatusId = ProjectStatusEnum.Approved.Id;

            //var x = TimesheetStatusEnum.GetById(1);
            var x = TimesheetStatusEnum.GetById(-1);

            Assert.True(StatusId.Equals(2));

            var StatusName = ProjectStatusEnum.PendAppv.Name;
            Assert.True(StatusName.Equals("Pending Approval"));

        }

        [Fact]
        public void ProjectManager_Get()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var ProjectMgr = ManagerFactory<Project>.Instance.GetManager(session);
                var proj = ProjectMgr.Get(17);

                var x = JsonSerializer.Serialize(proj.Teams);
                var y = JsonSerializer.Serialize(proj.Activities);

                Assert.True(proj.Name == "Paul's Dummy Project 1 Name");
            }
         }

            [Fact]
        public void SqlSession_StressTest()
        {
            Employee e = new Employee();
            e.LastName = "xxx";

            //using 12 thread to do stress test, Pass. We just can't create DbSession multiple time within the same thread
            // The stress test !!WORKS!!
            Task task1 = Task.Factory.StartNew(() => _SqlSession_StressTest(1));
            Task task2 = Task.Factory.StartNew(() => _SqlSession_StressTest(2));
            Task task3 = Task.Factory.StartNew(() => _SqlSession_StressTest(3));
            Task task4 = Task.Factory.StartNew(() => _SqlSession_StressTest(4));
            Task task5 = Task.Factory.StartNew(() => _SqlSession_StressTest(5));
            Task task6 = Task.Factory.StartNew(() => _SqlSession_StressTest(6));
            Task task7 = Task.Factory.StartNew(() => _SqlSession_StressTest(7));
            Task task8 = Task.Factory.StartNew(() => _SqlSession_StressTest(8));
            Task task9 = Task.Factory.StartNew(() => _SqlSession_StressTest(9));
            Task task10 = Task.Factory.StartNew(() => _SqlSession_StressTest(10));
            Task task11 = Task.Factory.StartNew(() => _SqlSession_StressTest(11));
            Task task12 = Task.Factory.StartNew(() => _SqlSession_StressTest(12));

            Task.WaitAll(task1, task2, task3, task4, task5, task6, task7, task8, task9, task10, task11, task12);
        }

        static void _SqlSession_StressTest(int n)
        //[Fact]
        //public void _SqlSession_StressTest()
        {
            for(int i = 0; i<23; i++)
            {
                using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
                {
                    var mgrE = ManagerFactory<Employee>.Instance.GetManager(session);
                    var E1 = mgrE.Get(171);
                    var E2 = mgrE.Get(260);

                    var mgrT = ManagerFactory<Team>.Instance.GetManager(session);
                    var T1 = mgrT.Get(13);

                    string newuserId = E1.UserId + ".xUnit.StressTester." + i + "."+n;

                    session.BeginTrans();
                    try
                    {
                        string updateBy = "xxx_" + i + "_" + n; 
                        E1.Id = 0; // to be inserted
                        E1.UserId = newuserId;
                        E1.UpdateBy = updateBy;
                        int newPKId = mgrE.Create(E1);

                        if (newPKId < 0) throw new Exception("EmployeeManager.Create() failed with code " + newPKId);

                        string newDisplayName = E1.DisplayName + " {{junk to be delete }}";
                        E1.Id = newPKId;
                        E1.DisplayName = newDisplayName;
                        E1.UpdateBy = updateBy;

                        mgrE.Update(E1);

                        E2.DisplayName = "stress test i=" + i + "; n=" + n;

                        //mgrE.Update(E2);

                        T1.Name = "xUnit.StressTester." + updateBy;
                        T1.UpdateBy = updateBy;
                        mgrT.Update(T1);

                        session.Commit();
                        //session.Rollback();
                        Assert.True(1 == 1);

                    } 
                    catch (Exception ex)
                    {
                        Console.WriteLine("n"+ n + " i"+i + " :" + ex.Message);
                        session.Rollback();
                        Assert.True(1 == 2);
                    }

                }
            }

        }

        [Fact]
        public void ApplocationLogDao_GetAll()
        {
            int i = 0;

            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var dao = (ApplicationLogDao)DaoFactory<ApplicationLog>.Instance.GetDao();
                var x = dao.GetAll(session);
                foreach (var a in x)
                {
                    i++;
                }
            }
            Assert.True(i > 0);
        }

        //[Fact]
        //public void TeamManager_GetTeam()
        //{
        //    using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
        //    {
        //        var mgr = (TeamManager)ManagerFactory<Team>.Instance.GetManager(session);
        //        // Custom methos testing
        //        var x = mgr.Get(1);
        //        IEnumerable<Team> x1 = mgr.FindByCriteria("SPU_Team_Find", new object[] { });
        //        Assert.True(x.Id.Equals(1));
        //    }
        //}
        [Fact]

        public void TeamManager_GetTeamById()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var mgr = ManagerFactory<Team>.Instance.GetManager(session);
                var x = mgr.Get(9);
                Assert.True(x.DeptCode == "724");
            }
        }


        [Fact]
        public void EmployeeManager_Test1()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var mgr = (EmployeeManager)ManagerFactory<Employee>.Instance.GetManager(session);
                //var x1 = mgr.Get(171);

                // Custom methos testing
                //var x = mgr.MyDemoInvokeMethod1(123, "Paul Chen");

                var mgrAppLog = ManagerFactory<ApplicationLog>.Instance.GetManager(session);
                var GetAllLogs = mgrAppLog.GetAll();


                var X0 = mgr.FindByDeptCode("724");
                int i = 0;
                foreach (var a in X0)
                {
                    i++;
                }
                Assert.True(i > 0);
                i = 0;
                var X1 = mgr.FindByName("chen");
                foreach (var a in X0)
                {
                    i++;
                }
                Assert.True(i > 0);


            }
        }



        [Fact]
        public void EmployeeDao_GetTest()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var dao = DaoFactory<Employee>.Instance.GetDao();

                var x1 = dao.Get(session, 171);
                var x2 = dao.Get(session, "paul.chen");
                Assert.True(x1.Email == x2.Email);
            }
        }

        [Fact]
        public void EmployeeDao_Upsert1Commit()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var dao = (EmployeeDao)DaoFactory<Employee>.Instance.GetDao();

                var X1 = dao.Get(session, 171);
                string newuserId = X1.UserId + ".committer";

                session.BeginTrans();
                X1.Id = 0; // to be inserted
                X1.UserId = newuserId;
                X1.UpdateBy = "XXX_I";
                int newPKId = dao.Create(session, X1);

                string newDisplayName = X1.DisplayName + " {{junk to be delete }}";
                X1.Id = newPKId;
                X1.DisplayName = newDisplayName;
                X1.UpdateBy = "XXX_U";

                dao.Update(session, X1);

                session.Commit();

                var X2 = dao.Get(session, newuserId);

                Assert.True(X1.DisplayName == X2.DisplayName);

            }
        }
        [Fact]
        public void EmployeeDao_Upsert2Rollback()
        {
            using (IDbSession session = DbSessionFactory.Instance.GetSqlSession(DbConnEnum.ConnStr.Extra))
            {
                var dao = (EmployeeDao)DaoFactory<Employee>.Instance.GetDao();

                var employee = dao.Get(session, 171);
                string newuserId = employee.UserId + ".rollbacker";

                session.BeginTrans();
                employee.Id = 0; // to be inserted
                employee.UserId = newuserId;
                employee.UpdateBy = "XXX_I";
                int newPKId = dao.Create(session, employee);

                employee.Id = newPKId;
                employee.DisplayName = employee.DisplayName + " {{to be rollback }}";
                employee.UpdateBy = "XXX_U";

                dao.Update(session, employee);

                session.Rollback();

                employee = dao.Get(session, newuserId);

                Assert.True(employee == null);

            }
        }

    }
}
