﻿using FrameworkBase.ValueObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.xUnit
{
    public class DbConnEnum : EnumBase<DbConnEnum>
    {
        #region Enumeration Elements
        /* ==========================================================================
         * Name: 
         * Description:  
         * ==========================================================================*/
        public static readonly DbConnEnum Provider = new DbConnEnum(1, "Provider", "System.Data.SqlClient");
        public static readonly DbConnEnum ConnStr = new DbConnEnum(2, "ConnStr", "data source=US007-DC-SQL03;initial catalog=US_TimesheetPortal;persist security info=True;integrated security=SSPI;");

        #endregion

        #region Constructors
        private DbConnEnum(int id, string name, string extra) : base(id, name, extra)
        {
        }
        #endregion
    }
}
