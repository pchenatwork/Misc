﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
    public class EmailEntity
    {
        public int EmailID { get; set; }

        public string Sender { get; set; }
        public string Recipients { get; set; }

        public string Cc { get; set; }

        public string Bcc { get; set; }

        public bool isHtml { get; set; }

        public string Subject { get; set; }

        public string Body { get; set; }
    }

    public class EmailRequestEntity
    {
        public int TemplateId { get; set; }

        public string Source { get; set; }

        public int Priority { get; set; }

        public string Subject { get; set; } 

        public string EmailBody { get; set; }   
        public string Sender { get; set; }

        public string Recipients { get; set; }  

        public DateTime SendDate { get; set; }

        public int Status { get; set; }

        public string Cc { get; set; }

        public string Bcc { get; set; }

        public bool IsHtml { get; set; }
    }
}
