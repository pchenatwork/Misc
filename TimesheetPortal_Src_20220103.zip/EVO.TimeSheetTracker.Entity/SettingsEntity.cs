﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
	public class SettingsEntity
	{
		public int SettingsID { get; set; }
		public string Description { get; set; }
		public string Category { get; set; }
		public bool IsActive { get; set; }
		public string OrderBy { get; set; }

		public string Type { get; set; }
	}
}
