using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
    /// <summary>
    /// Wrapper object to signify success or failure persisting data (check exception)
    /// </summary>
    public class SaveResult
    {
        private bool _Success;
        public bool Success
        {
            get
            {
                return _Success;
            }
            set
            {
                _Success = value;
            }
        }
        private string _GlobalKey;
        public string GlobalKey
        {
            get
            {
                return _GlobalKey;
            }
            set
            {
                _GlobalKey = value;
            }
        }
        private List<string> _GlobalKeyValues;
        public List<string> GlobalKeyValues
        {
            get
            {
                return _GlobalKeyValues;
            }
            set
            {
                _GlobalKeyValues = value;
            }
        }

        private string _ErrorDescription;
        public string ErrorDescription
        {
            get
            {
                return _ErrorDescription;
            }
            set
            {
                _ErrorDescription = value;
            }
        }

    

        //private Exception _Exception;
        //public Exception Exception
        //{
        //    get
        //    {
        //        return _Exception;
        //    }
        //    set
        //    {
        //        _Exception = value;
        //    }
        //}

        private Object _AssociatedObject;
        public Object AssociatedObject
        {
            get
            {
                return _AssociatedObject;
            }
            set
            {
                _AssociatedObject = value;
            }
        }

        public SaveResult()
        {
            this.Success = false;
            //this.Exception = null;
            this.ErrorDescription = "";
            this.AssociatedObject = null;
            this.GlobalKey = "";
            this.GlobalKeyValues = new List<string>();
        }
    }
}
