﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
    public class SystemAssetEntity
    {
        public int SystemAssetID { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
    }
}
