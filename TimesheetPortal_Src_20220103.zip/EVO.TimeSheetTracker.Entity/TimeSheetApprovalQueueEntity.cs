﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
    public class TimeSheetApprovalQueueEntity
    {
		public int TimesheetID { get; set; }
		public ProjectEntity Project { get; set; }
		public DateTime ReportDate { get; set; }
		public decimal Hours { get; set; }
		public string Description { get; set; }
		public string TFSID { get; set; }

		public DateTime UpdateDate { get; set; }
		public string UpdatedBy { get; set; }
		public SettingsEntity Phase { get; set; }
		public SettingsEntity Status { get; set; }

		public string ResourceID { get; set; }
		public string ResourceName { get; set; }
		public string ResourceManager { get; set; }

		/// <summary>
		/// the project phase log for the current timesheet, once the timesheet approved by manager, then show it rather then data from project.
		/// </summary>
		public string ProjectPhaseLog { get; set; }

		#region Query entity properties
		public bool IsAdmin { get; set; }
		public int PeriodID { get; set; }
		#endregion

		public int RequestID { get; set; }
		public int RequstTypeID { get; set; }
		public string RequestedBy { get; set; }
		public DateTime RequestedDate { get; set; }
		public string DecidedBy { get; set; }
		public DateTime DecideDate { get; set; }
		public int ReferenceID { get; set; }
		public string Comment { get; set; }
		public int TimezoneOffset { get; set; }
	}
}
