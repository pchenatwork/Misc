﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
    public class ReportTimesheetStatusEntity
    {
        public string TeamName { get; set; }
        public int UserPerTeamTotalCount { get; set; }
        public int SubmittedUserPerTeamCount { get; set; }
    }
}
