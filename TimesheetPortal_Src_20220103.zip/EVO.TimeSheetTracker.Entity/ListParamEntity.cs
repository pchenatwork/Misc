﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
    public  class ListParamEntity
    {
        public IEnumerable<int> ListOfIDs { get; set; }
        public string UserID { get; set; }
        public string ExtendProperty { get; set; }
    }
}
