﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EVO.TimeSheetTracker.Entity
{
    public class ReportProjectStatusEntity
    {
        public int Submitted { get; set; }
        public int AllProject { get; set; }
        public int NonSubmitted { get { return AllProject - Submitted; } }
    }
}
