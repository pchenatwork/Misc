﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EVO.TimeSheetTracker.Entity
{
    public class TimeSheetEntity
    {
		public int TimeSheetID { get; set; }
		public ProjectEntity Project { get; set; }
		public DateTime ReportDate { get; set; }
		public decimal Hours { get; set; }
		public string Description { get; set; }
		public string TFSID { get; set; }

		/// <summary>
		/// 0: Creaty by Employee , 1: import by Manager
		/// </summary>
		public int Type { get; set; }

		public DateTime UpdateDate { get; set; }
		public string UpdatedBy { get; set; }
		public SettingsEntity Phase { get; set; }
		public SettingsEntity Status { get; set; }

		public string ResourceID { get; set; }
		public string ResourceName { get; set; }
		public string ResourceManager { get; set; }
        public string ResourceRoleName { get; set; }
        public string ProjectManager { get; set; }

		public string PayLevel { get; set; }
		public string ResourceCountry { get; set; }

		public string ResourceDepartment { get; set; }
		public int TimezoneOffset { get; set; }
		public string Comment { get; set; }
		/// <summary>
		/// the project phase log for the current timesheet, once the timesheet approved by manager, then show it rather then data from project.
		/// </summary>
        public string ProjectPhaseLog { get; set; }

		#region Query entity properties
		public bool IsAdmin { get; set; }
		public int PeriodID { get; set; }
        #endregion

    }
}

