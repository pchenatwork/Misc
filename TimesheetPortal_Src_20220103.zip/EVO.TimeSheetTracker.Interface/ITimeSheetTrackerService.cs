using EVO.TimeSheetTracker.Entity;
using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace EVO.TimeSheetTracker.Interface
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface ITimeSheetTracker
    {
        // TODO: Add your service operations here
        [OperationContract]
        SaveResult LogError(ApplicationLogEntity log);

        [OperationContract]
        List<ApplicationLogEntity> GetApplicationLogs(ApplicationLogEntity entity);

        [OperationContract]
        byte[] GetCache(string key);

        [OperationContract]
        void RefreshCache(string key);

        [OperationContract]
        SaveResult SetCache(string key, byte[] data, long expirationInSeconds, DateTimeOffset? absoluteExpiration);

        [OperationContract]
        SaveResult RemoveCache(string key);

        [OperationContract]
        SaveResult RemoveExpiredCache(DateTimeOffset? utcNow);

        [OperationContract]
        SaveResult SendEmail(string emailFrom, string emailTo, string subject, string body, string emailBcc = "", string emailCc = "");

        #region Activities

        [OperationContract]
        List<SettingsEntity> GetProjectPhase();

        [OperationContract]
        List<SettingsEntity> GetProjectType();

        [OperationContract]
        List<SettingsEntity> GetProjectStatus();

        [OperationContract]
        List<SettingsEntity> GetTimesheetStatus();

        [OperationContract]
        List<EmployeeEntity> GetTeamOwnersOfSubmittedTimesheetUser(int period);

        #endregion Activities

        #region Projects

        [OperationContract]
        List<ProjectEntity> GetProject(ProjectEntity entity);

        [OperationContract]
        SaveResult InsertProject(ProjectEntity entity);

        [OperationContract]
        SaveResult UpdateProject(ProjectEntity entity);

        [OperationContract]
        SaveResult DeleteProject(int ID);

        [OperationContract]
        bool CheckProjectName(string projectName, int ID);

        [OperationContract]
        SaveResult SubmitProjects(ListParamEntity listParam);

        [OperationContract]
        List<ProjectApprovalQueueEntity> GetProjectApprovalList(TimeSheetQueryEntity entity);

        [OperationContract]
        SaveResult RejectProjects(List<int> requestIDs, string userID);

        [OperationContract]
        SaveResult ApprovalProjects(List<int> requestIDs, string userID);

        [OperationContract]
        SaveResult CloseProjects(List<int> requestIDs, string userID);

        [OperationContract]
        SaveResult UpdateProjectComment(ProjectApprovalQueueEntity entity);

        [OperationContract]
        List<PeriodMonthEntity> GetPeriodMonth();

        [OperationContract]
        List<SystemAssetEntity> GetSystemAssets();

        [OperationContract]
        List<SettingsEntity> GetSubmittedUsersOfProject(int period);

        [OperationContract]
        List<SettingsEntity> GetProjectNames(string resourceID, bool isAdmin);

        [OperationContract]
        List<ProjectEntity> GetProjectByID(int ID);

        [OperationContract]
        List<ProjectEntity> GetProjectByNumber(string projectNumber, string employeeName);

        [OperationContract]
        List<ProjectPhaseEntity> GetProjectPhaseWithTeam(int ProjectID, int TeamID, int RequestType, string userName = "");

        [OperationContract]
        List<SettingsEntity> GetTeamAndOwners(string userID, bool isAdmin, int projectID);

        [OperationContract]
        SaveResult UpdateProjectPhaseWithTeam(List<ProjectPhaseEntity> projectPhaseEntities, string userID);

        [OperationContract]
        bool ProjectRestoreStatus(string userName);
        
        [OperationContract]
        List<string> GetProjectNameForFilter(string userName, int period, bool isAdmin, int requestType);
        #endregion Projects

        #region Teams

        [OperationContract]
        bool CheckTeamName(string name);

        [OperationContract]
        List<TeamEntity> GetTeamProjectReminderData(TimeSheetQueryEntity entity);

        [OperationContract]
        List<TeamEntity> GetTeams(TeamEntity entity);

        [OperationContract]
        SaveResult InsertTeam(List<TeamEntity> entity);

        [OperationContract]
        SaveResult UpdateTeam(TeamEntity entity);

        [OperationContract]
        SaveResult DeleteTeam(TeamEntity entity);

        #endregion Teams

        #region Employees

        [OperationContract]
        List<EmployeeEntity> GetEmployees(EmployeeEntity entity);

        [OperationContract]
        SaveResult InsertEmployees(List<EmployeeEntity> entity);

        [OperationContract]
        SaveResult UpdateEmployees(List<EmployeeEntity> entitys);

        [OperationContract]
        SaveResult DeleteEmployee(EmployeeEntity entity);

        #endregion Employees

        #region Settings

        [OperationContract]
        List<SettingsEntity> GetSettingsByCategory(string category);

        [OperationContract]
        SaveResult UpdateSettings(SettingsEntity entity);

        [OperationContract]
        SaveResult InsertSettings(SettingsEntity entity);

        [OperationContract]
        SaveResult DeleteSettings(int Id);

        [OperationContract]
        List<SettingsEntity> GetSetttings(SettingsEntity entity);

        [OperationContract]
        List<SystemAssetEntity> GetSystemAssetList(bool isAdmin);

        [OperationContract]
        SaveResult InsertSystemAsset(SettingsEntity entity);

        [OperationContract]
        SaveResult UpdateSystemAsset(SettingsEntity entity);

        [OperationContract]
        SaveResult DeleteSystemAsset(int Id);

        [OperationContract]
        List<RoleStatusEntity> GetRoleStatus();

        #endregion Settings

        #region TimeSheet

        [OperationContract]
        List<TimeSheetEntity> GetTimeSheet(TimeSheetQueryEntity entity);

        [OperationContract]
        List<TimeSheetEntity> GetTimeSheetSummary(TimeSheetQueryEntity entity);

        [OperationContract]
        SaveResult InsertTimeSheet(TimeSheetEntity entity);

        [OperationContract]
        SaveResult InsertTimeSheetBatch(List<TimeSheetEntity> entitys);

        [OperationContract]
        SaveResult UpdateTimeSheet(TimeSheetEntity entity);

        [OperationContract]
        SaveResult DeleteImportTimeSheet();

        [OperationContract]
        SaveResult DeleteTimeSheet(int ID);

        [OperationContract]
        SaveResult SubmitTimeSheets(ListParamEntity listParam);

        [OperationContract]
        List<TimeSheetApprovalQueueEntity> GetTimesheetApprovalList(TimeSheetQueryEntity entity);

        [OperationContract]
        SaveResult RejectTimesheets(List<int> requestIDs, string userID);

        [OperationContract]
        SaveResult ApprovalTimesheets(List<int> requestIDs, string userID);

        [OperationContract]
        SaveResult UpdateTimesheetComment(TimeSheetApprovalQueueEntity entity);

        #endregion TimeSheet

        #region EmailReminder

        [OperationContract]
        List<EmailEntity> GetPendingEmailList(DateTime sendDate);

        [OperationContract]
        SaveResult InsertEmailList(List<EmailRequestEntity> mailList);

        [OperationContract]
        SaveResult UpdateEmailList(List<int> emailIDs);

        #endregion EmailReminder

        #region Report

        [OperationContract]
        ReportProjectStatusEntity GetProjectSubmittedStatus();

        [OperationContract]
        List<ReportTimesheetStatusEntity> GetTimesheetSubmittedStatus();

        #endregion Report
    }
}