﻿using EVO.TimesheetPortal.Entity;
using System.Collections.Generic;

namespace EVO.TimesheetPortal.Job.Common
{
    public class EmployeeEntityCompares : IEqualityComparer<Employee>
    {
        bool IEqualityComparer<Employee>.Equals(Employee x, Employee y)
        {
            if (x.Id == y.Id || x.UserId == y.UserId)
                return true;
            return false;
        }

        int IEqualityComparer<Employee>.GetHashCode(Employee obj)
        {
            return obj.UserId.GetHashCode();
        }
    }
}