﻿using EVO.TimesheetPortal.Entity;
using Refit;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Job.Service
{
    public interface IEmailTemplateService : IService
    {
        [Get("/api/emailtemplate/search")]
        Task<ApiResponse<List<EmailTemplate>>> GetAllAsync();
    }
}