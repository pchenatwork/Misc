﻿using EmailService;
using EVO.TimesheetPortal.Entity;
using EVO.TimesheetPortal.Job.Config;
using EVO.TimesheetPortal.Job.Service;
using Microsoft.Extensions.Options;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Job.Jobs
{
    public abstract class EmailJobBase : JobBase
    {
        protected IEmailTemplateService EmailTemplateService;
        protected ServiceOption _serviceOption;
        protected abstract string EmailTemplateName { get; set; }
        protected EmailServiceSoapClient EmailService;

        protected EmailJobBase(IEmailTemplateService emailTemplateService,
            EmailServiceSoapClient emailService,
            IOptionsSnapshot<ServiceOption> serviceOption,
            ILogger logger)
            : base(logger)
        {
            EmailService = emailService;
            EmailTemplateService = emailTemplateService;
            _serviceOption = serviceOption.Value;
        }

        protected async Task<SaveResult> SendEmailAsync(EmailEntity mail)
        {
            // Swap MailTo(for testing) if a valid MailTo email is defined in appsetting.{env}.json config file.
            mail.To = !string.IsNullOrEmpty(_serviceOption.MailTo) ? _serviceOption.MailTo : mail.To;
            mail.Application = _serviceOption.ApplicationName;
            var result = await EmailHelper.SendEmailAsync(mail, EmailService);
            return result;
        }

        protected JobResult SendEmailListAsync(List<EmailEntity> mails)
        {
            int iCnt = 0, iTotal = mails.Count;
            var result = Parallel.ForEach(mails, item =>
            {
                if (SendEmailAsync(item).Result.Success) Interlocked.Increment(ref iCnt);
            });
            return iTotal.Equals(iCnt) ? JobResult.Success : JobResult.Warning;
        }

        private async Task<EmailTemplate> GetEmailTemplate()
        {
            var apiResponse = await EmailTemplateService.GetAllAsync();
            var result = apiResponse.Content;
            if (!string.IsNullOrWhiteSpace(EmailTemplateName) && result != null)
            {
                return result.Where(o => o.TemplateName.Equals(EmailTemplateName, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
            }
            return null;
        }

        protected Task<EmailTemplate> EmailTemplate => this.GetEmailTemplate();
    }
}