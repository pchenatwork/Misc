﻿using Quartz;
using Serilog;
using System;
using System.Threading.Tasks;

namespace EVO.TimesheetPortal.Job.Jobs
{
    public abstract class JobBase : IJob
    {
        protected readonly ILogger _logger;

        protected JobBase(ILogger logger)
        {
            _logger = logger;
        }

        protected virtual void Start(IJobExecutionContext context)
        {
            var jobName = context.JobDetail.JobType.Name;
            _logger.Information("{0} job start at {1}.", jobName, DateTime.Now);
        }

        public async Task Execute(IJobExecutionContext context)
        {
            try
            {
                Start(context);
                var status = await Run(context);

                switch (status)
                {
                    case JobResult.Warning:
                        _logger.Information("{0} finished with error.", context.JobDetail.JobType.Name); break;
                    case JobResult.Failed:
                        _logger.Information("{0} failed !!!", context.JobDetail.JobType.Name); break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.JobDetail.JobType.Name);
                throw ex;
            }
            finally
            {
                End(context);
            }
        }

        protected virtual void End(IJobExecutionContext context)
        {
            _logger.Information("{0} execute completed, runing with {1} seconds.", context.JobDetail.JobType.Name, context.JobRunTime.TotalSeconds);
        }

        protected abstract Task<JobResult> Run(IJobExecutionContext context);
    }

    /// <summary>
    /// Job Finished Status
    /// </summary>
    public enum JobResult
    {
        /// <summary>
        /// Finished with no error
        /// </summary>
        Success,

        /// <summary>
        /// Partial finished, probably data error
        /// </summary>
        Warning,

        /// <summary>
        /// Failed, some system errors
        /// </summary>
        Failed
    }
}