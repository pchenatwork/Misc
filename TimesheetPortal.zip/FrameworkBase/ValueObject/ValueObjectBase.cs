﻿using FrameworkBase.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

/* ============================================================================
 * PCHEN 202110 Introduced
 * Inspired by
   http://grabbagoft.blogspot.com/2007/06/generic-value-object-equality.html
   https://enterprisecraftsmanship.com/2015/01/03/value-objects-explained/
 * ============================================================================ */

namespace FrameworkBase.ValueObject
{
    [Serializable]
    public abstract class ValueObjectBase : IValueObject
    {
        #region	Private Members
        protected int _id;
        protected string _createBy = string.Empty;
        protected DateTime _createDate = new DateTime(1900, 1, 1);
        protected string _updateBy = string.Empty;
        protected DateTime _updateDate = new DateTime(1900, 1, 1);
        protected string _extra = string.Empty;
        #endregion
        #region constructor
        ///	<summary>
        ///	Private constructor to force using ValueObjectFactory<T>
        ///	</summary>
        protected ValueObjectBase()
        {
        }
        #endregion constructor
        #region Properties
        [XmlAttribute()]
        public int Id { get => this._id; set => _id = value; }
        [XmlAttribute()]
        public string CreateBy { get => _createBy; set => _createBy = value; }
        [XmlAttribute()]
        public DateTime CreateDate { get => _createDate; set => _createDate = value; }
        [XmlAttribute()]
        public string UpdateBy { get => _updateBy; set => _updateBy = value; }
        [XmlAttribute()]
        public DateTime UpdateDate { get => _updateDate; set => _updateDate = value; }
        [XmlAttribute()]
        public string Extra
        {
            get => _extra; set => _extra = value;
        }
        #endregion Properties
    }
}
