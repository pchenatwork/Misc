﻿#region Header Info
using System;
using System.Collections.Generic;
using System.Text;
using FrameworkBase.Common;

/* ============================================================================
 * PCHEN 202110 Introduced
 * ============================================================================ */
#endregion

namespace FrameworkBase.DataAccess
{
    /// <summary>
    /// Return a DbSession
    /// </summary>
    public sealed class DbSessionFactory : FactoryBase<DbSessionFactory>
    {
        public DbSession GetSession(string providerName, string connectionString)
        {
            return new DbSession(providerName, connectionString);
        }
    }
}
