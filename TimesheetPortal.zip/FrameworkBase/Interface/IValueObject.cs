﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FrameworkBase.Interface
{
    ///	<summary>
    ///	ValueObject == Domain Model. DO contain logic
    ///	NOT ORM Entities 
    ///	</summary>
    public interface IValueObject
    {
        /* ============================================================================
         * PCHEN 202110 
         * Inspired by https://enterprisecraftsmanship.com/2015/04/13/dto-vs-value-object-vs-poco/
         * ============================================================================ */
        int Id { get; set; }
        string CreateBy { get; set; }
        DateTime CreateDate { get; set; }
        string UpdateBy { get; set; }
        DateTime UpdateDate { get; set; }
        string Extra { get; set; }
    }
}
