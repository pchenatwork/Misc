using FrameworkBase.DataAccess;
using FrameworkBase.Interface;
using System;
using TimesheetPortal.DataAccess;
using TimesheetPortal.Entity;
using Xunit;

namespace TimesheetPortal.xUnit
{
    public class DaoTester
    {
        private const   string _providerName = "System.Data.SqlClient";
        private const   string _connnectionStr = "Server=localhost;Database=US_TimesheetPortal;Trusted_Connection=True";

        [Fact]
        public void EmployeeDaoTester()
        {
            Assert.True(EmployeeDaoTest() > 0);
        }

        private int EmployeeDaoTest()
        {
            int i = 0; 

            using (IDbSession session = DbSessionFactory.Instance.GetSession(_providerName, _connnectionStr))
            {
                var dao = (EmployeeDao)DaoFactory<Employee>.Instance.GetDAO();
                var x = dao.FindByCriteria(session, dao.FIND_BY_TOKENS,
                        new object[]
                        {
                            "Chen", // new SqlParameter("@Name",Name),
                            null,   // new SqlParameter("@ManagerId", ManagerId),
                            null,   // new SqlParameter("@DeptCode", DeptCode),
                            null    // new SqlParameter("@JsonExtra", JsonExtra)
                        });
                foreach(var a in x)
                {
                    i++;
                }
            }
            return i;
        }
    }
}
