﻿using FrameworkBase.Common;
using FrameworkBase.Interface;
using System;
using System.Linq;
using System.Reflection;

namespace TimesheetPortal.DataAccess
{
    public sealed class DaoFactory<T> : FactoryBase<DaoFactory<T>> where T : IValueObject
    {
        /// <summary>
        /// if daoClassName not provided, daoClassName= {{T name}}dao
        /// </summary>
        /// <param name="daoClassName"></param>
        /// <returns></returns>
        public IDataAccessObject<T> GetDAO(string daoClassName = null)
        {
            if (string.IsNullOrEmpty(daoClassName))
            {
                // get DaoClassName, should by in the convention of "{ValueObject}DAO"
                daoClassName = typeof(T).Name.ToLower() + "dao";
                // Search type in current assembly
                Type type = (from t in Assembly.GetExecutingAssembly().GetTypes()
                             where t.IsClass && t.Name.ToLower().Equals(daoClassName)
                             select t).Single();
                // create instance by reflection
                return Activator.CreateInstance(type,
                     BindingFlags.NonPublic | BindingFlags.Instance, null,
                     null, null) as IDataAccessObject<T>;
            }

            return Activator.CreateInstance(Type.GetType(daoClassName),
                     BindingFlags.NonPublic | BindingFlags.Instance, null,
                     null, null) as IDataAccessObject<T>;
        }
    }
}

