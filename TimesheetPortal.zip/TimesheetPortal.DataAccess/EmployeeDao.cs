﻿using FrameworkBase.DataAccess;
using FrameworkBase.Interface;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using TimesheetPortal.Entity;

namespace TimesheetPortal.DataAccess
{
    public class EmployeeDao : AbstractDAO<Employee>
    {
        #region constants
        private const string CLASSNAME = nameof(EmployeeDao);
        private const string _FIND_BY_TOKENS = "EmployeeFind";
        #endregion
        #region FinderType Properties
        /// <summary>
        /// [0] @Name [1]ManagerId [2]DeptCode [3]JsonExtra
        /// </summary>
        public string FIND_BY_TOKENS => _FIND_BY_TOKENS;
        #endregion

        #region	Constructors
        private EmployeeDao()
        {
        }
        #endregion constructors

        public override IEnumerable<Employee> FindByCriteria(IDbSession dbSession, string finderType, params object[] criteria)
        {
            try
            {
                switch (finderType)
                {
                    case _FIND_BY_TOKENS:
                        {
                            //string Name = (string)criteria[0];
                            //int ManagerId = (int)criteria[1];
                            //string DeptCode = (string)criteria[2];
                            //string JsonExtra = (string)criteria[3];

                            List<SqlParameter> listSqlParameter = new List<SqlParameter>
                            {
                                new SqlParameter("@Name",criteria[0]),
                                new SqlParameter("@ManagerId", criteria[1]),
                                new SqlParameter("@DeptCode", criteria[2]),
                                new SqlParameter("@JsonExtra", criteria[3])
                            };
                            XmlReader reader = ExecuteXmlReader(dbSession, "SPU_Employee_Find", listSqlParameter);
                            return DeserializeCollection(reader);
                        }
                    default:
                        return null;

                }
            }
            catch (Exception ex)
            {
                //LogError(ex);
                throw new Exception("Server side error");
            }
        }


    }
}
