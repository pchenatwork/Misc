﻿using FrameworkBase.ValueObject;
using System;
using System.Xml.Serialization;

namespace TimesheetPortal.Entity
{
    [Serializable]
    public class Employee : ValueObjectBase
    {
        [XmlAttribute()]
        public string UserId { get; set; }

        [XmlAttribute()]
        public string FirstName { get; set; }

        [XmlAttribute()]
        public string LastName { get; set; }

        [XmlAttribute()]
        public string DisplayName { get; set; }

        [XmlAttribute()]
        public string Email { get; set; }

        [XmlAttribute()]
        public string Title { get; set; }

        [XmlAttribute()]
        public int JobGradeId { get; set; }

        [XmlAttribute()]
        public bool EmailAlert { get; set; }

        [XmlAttribute()]
        public bool IsActive { get; set; }

        [XmlElement()]
        public Employee Manager { get; set; }

    }
}
