#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 - 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.Common.Utilities;
using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Managers
{
	#region	Header
	///	<summary>
	///	Abstract implementation of IManagerFactory.
	///	</summary>
	#endregion
	public abstract class AbstractManagerFactory : IManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>logging component</summary>
		protected static ILog				_logger = null;

        #endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		/// <summary>
		/// simple class constructor
		/// </summary>
		static AbstractManagerFactory()
		{
			_logger = LoggingUtility.GetLogger( typeof( AbstractManagerFactory ).FullName );
		} 
		#endregion	Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public abstract IManager CreateInstance( );
		public abstract IManager CreateInstance( string dataSourceName );
		#endregion 
	} 
}
