#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 - 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region References
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using SCA.VAS.Common;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.DataAccess;
#endregion References

namespace SCA.VAS.BusinessLogic.Managers
{
	#region Header
	/// <summary>
	/// Default implementation of IManager.
	/// </summary>
	#endregion
	public abstract class AbstractManager : IManager
	{
		#region Private Variables
		
		private IDataSource _dataSource;
		private IDataAccessObject _dao;

		#endregion

		#region Constructors
	
		public  AbstractManager( )
		{
			_dataSource = DataSourceFactory.CreateInstance( );
			_dao = _dataSource.CreateDataAccessObject( DaoClassName );
		}
		public  AbstractManager( string dataSourceName )
		{
			_dataSource = DataSourceFactory.CreateInstance( dataSourceName );
			_dao = _dataSource.CreateDataAccessObject( DaoClassName );
		}
		#endregion
		
		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************

		/// <summary>
		/// Property DataSource (IDataSource)
		/// </summary>
		public IDataSource DataSource
		{
			get
			{
				return this._dataSource;
			}
		}
		
		/// <summary>
		/// Property Dao (IDataAccessObject)
		/// </summary>
		public IDataAccessObject Dao
		{
			get
			{
				return this._dao;
			}
		}

		public abstract string DaoClassName 
		{
			get;
		}

		public virtual IValueObject CreateObject( )
		{
			throw new NotImplementedException();
		}
		public static T CreateObject<T>() where T : IValueObject
		{
			return (T)Activator.CreateInstance(typeof(T));
		}
		#endregion

		#region IPersistenceManager
		// *************************************************************************
		//                IPersistenceManager
		// *************************************************************************

		public virtual bool Create( IValueObject newObject )
		{
			return this.Dao.Create(this.DataSource, newObject);
		}

		public virtual bool Update( IValueObject existingObject )
		{
			return this.Dao.Update(this.DataSource, existingObject);
		} 

		public virtual bool Delete( int id )
		{
			return this.Dao.Delete(this.DataSource, id);
		} 
		#endregion

		#region IFinder
		// *************************************************************************
		//                IFinder
		// *************************************************************************
		/// <summary>
		/// Get a value object from database by its ID.
		/// </summary>
		public virtual IValueObject Get( int id )
		{
			return this.Dao.Get(this.DataSource, id);
		} 

		/// <summary>
		/// Gets all the value objects.
		/// </summary>
		/// <returns>a valid non-empty collection or null</returns>
		public virtual ICollection GetAll()
		{
			throw new NotImplementedException();
		} 
		
		/// <summary>
		/// Generic search function to get a list of value objects by certain criteria.
		/// </summary>
		/// <param name="finderType">a defined finder type</param>
		/// <param name="criteria">the list of arguments as criteria to the finder method</param>
		/// <returns>a valid non-empty collection or null</returns>
		public virtual ICollection FindByCriteria( string finderType, Object[] criteria )
		{
			return this.Dao.FindByCriteria(this.DataSource, finderType, criteria);
		} 
 		#endregion 
	}
}