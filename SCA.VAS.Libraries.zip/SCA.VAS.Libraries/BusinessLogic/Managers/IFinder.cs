#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 - 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using SCA.VAS.Common.ValueObjects;
#endregion References

namespace SCA.VAS.BusinessLogic.Managers
{
	#region	Header
	///	<summary>
	///	Interface for basic searching functions.
	///	</summary>
	#endregion
	public interface IFinder
	{
		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		/// <summary>
		/// Get a value object from database by its ID.
		/// </summary>
		IValueObject Get( int id );

		/// <summary>
		/// Gets all the value objects.
		/// </summary>
		/// <returns>a valid non-empty collection or null</returns>
		ICollection GetAll();

		/// <summary>
		/// Generic search function to get a list of value objects by certain criteria.
		/// </summary>
		/// <param name="finderType">a defined finder type</param>
		/// <param name="criteria">the list of arguments as criteria to the finder method</param>
		/// <returns>a valid non-empty collection or null</returns>
		ICollection FindByCriteria( string finderType, object[] criteria );
		#endregion
	}
} 
