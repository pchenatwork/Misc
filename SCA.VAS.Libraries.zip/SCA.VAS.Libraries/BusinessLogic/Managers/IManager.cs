#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 - 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.Common.ValueObjects;
using SCA.VAS.DataAccess;
#endregion References

namespace SCA.VAS.BusinessLogic.Managers
{
	#region	Header
	///	<summary>
	///	Aggregates IPersistenceManager and IFinder to make a IManger.
	///	</summary>
	#endregion

	public interface IManager : IFinder, IPersistenceManager
	{
		/// <summary>
		/// DataSource related to this Manager.
		/// </summary>
		IDataSource DataSource { get; }
		
		/// <summary>
		/// Cached DataAccessObject.
		/// </summary>
		IDataAccessObject Dao { get; }
	
		/// <summary>
		/// Force to tell the Dao Class Name. This means all implementatins should have the same class name.
		/// </summary>
		string DaoClassName { get; }
		
		/// <summary>
		/// Create a value object in memory.
		/// </summary>
		IValueObject CreateObject( );
	} 
}
