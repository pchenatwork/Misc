#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 - 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region Reference
using System;
using System.Data;

using SCA.VAS.Common.ValueObjects;
#endregion

namespace SCA.VAS.BusinessLogic.Managers
{
	/// <summary>
	/// Interface for CRUD functions 
	/// </summary>
	public interface IPersistenceManager 
	{
		/// <summary>
		/// Add a new value object to the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		bool Create( IValueObject newObject );
		
		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		bool Update( IValueObject existingObject );

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		bool Delete( int id );
	}
}
