#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 - 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using SCA.VAS.Common.ValueObjects;
#endregion References

namespace SCA.VAS.BusinessLogic.Managers
{
	#region	Header
	///	<summary>
	///	Interface for login functions.
	///	</summary>
	#endregion
	public interface ILogin
	{
		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		/// <summary>
		/// Get a value object from database by its unique name.
		/// </summary>
		IValueObject GetByName( string name );

		/// <summary>
		/// Return user id when login to database.
		/// </summary>
		int Login( string name, string password );

		/// <summary>
		/// Change user password.
		/// </summary>
		bool ChangePassword( int id, string password );
		#endregion
	}
} 
