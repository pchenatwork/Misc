#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 - 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

#endregion References

namespace SCA.VAS.BusinessLogic.Managers
{
	#region	Header
	///	<summary>
	/// Interface to define a value object ManagerFactory.
	///	</summary>
	#endregion

	public interface IManagerFactory
	{
		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		/// <summary>
		/// Factory creation method
		/// </summary>
		IManager CreateInstance ( );
		IManager CreateInstance ( string dataSourceName );
		#endregion
	}
}
