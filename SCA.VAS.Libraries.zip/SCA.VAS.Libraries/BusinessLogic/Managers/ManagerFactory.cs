﻿/*=======================================================================* 
* Aug 2020  PCHEN Create as part of Rfp project
* An attemp using generic factory class to replace all 'XXXManagerFactory'
*=======================================================================*/

#region References 
using SCA.VAS.Common;
using SCA.VAS.Common.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
#endregion

namespace SCA.VAS.BusinessLogic.Managers
{
    public sealed class ManagerFactory<T> : FactoryBase<ManagerFactory<T>> where T: IManager
    {
        #region	Constructors
        static ManagerFactory()
        {
            _logger = LoggingUtility.GetLogger(typeof(ManagerFactory<T>).FullName);
        }
        #endregion Constructors

        #region	Public Methods
        /// <summary>
        /// Factory creation method for Manager instances
        /// </summary>
        /// <returns>
        /// an instance of Manager
        /// </returns>
        public T CreateInstance()
		{
			return (T)Activator.CreateInstance(typeof(T));
		}

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public T CreateInstance(string dataSourceName)
        {
            return (T)Activator.CreateInstance(typeof(T), new object[] { dataSourceName } );
            //return (T)Activator.CreateInstance(typeof(T),
            //    BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance, null,
            //    new object[] { dataSourceName });
		}
        #endregion Public Methods
    }
}

