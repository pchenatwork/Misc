#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 - 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.QA;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.QA
{
	#region	Header
	///	<summary>
	///	Manager class for QuestionCategory.
	///	</summary>
	#endregion Header

	public class QuestionCategoryManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
		#endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static QuestionCategoryManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( QuestionCategoryManager ).FullName);
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public QuestionCategoryManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public QuestionCategoryManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.QA.QuestionCategoryDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new QuestionCategory( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <returns></returns>
		public bool UpdateCollection( int questionId, QuestionCategoryCollection collection )
		{
			return (bool)this.Dao.InvokeByMethodName( "UpdateCollection", 
				new object[] { this.DataSource, questionId, collection } );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 	
	} 
} 