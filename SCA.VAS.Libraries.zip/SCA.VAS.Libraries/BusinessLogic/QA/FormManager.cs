#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.QA;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.QA
{
	#region	Header
	///	<summary>
	///	Manager class for Form.
	///	</summary>
	#endregion Header

	public class FormManager : AbstractManager
	{		
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
		public const string SEARCH_FORM = "SearchForm";
		public const string FIND_FORM_BY_TYPE = "FindFormByType";
		#endregion Constants
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;

		#endregion Private Members
		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static FormManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( FormManager ).FullName);
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public FormManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public FormManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors
		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.QA.FormDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new Form( );
		}
		#endregion
		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************

		/// <summary>
		/// Create a new FormAnswer object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update( IValueObject existingObject )
		{
			return this.Dao.Update( this.DataSource, existingObject );
		}
		
		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete( int id )
		{
			return this.Dao.Delete( this.DataSource, id );
		}

		/// <summary>
		/// Copy this object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public int Copy( int id )
		{
			return (int)this.Dao.InvokeByMethodName( "Copy", 
				new object[] { this.DataSource, id } );
		}
		#endregion 
		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new Form object from the database.
		/// </summary>
		/// <param name="Id">Form Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}
		
		/// <summary>
		/// Get a new Form object from the database.
		/// </summary>
		/// <param name="Id">Form Id</param>
		/// <returns></returns>
		public IValueObject GetById( Guid formId )
		{
			return (IValueObject)this.Dao.InvokeByMethodName( "GetById", 
				new object[] { this.DataSource, formId } );
		}
		
		public IValueObject GetByParticipant( int id, int participantId )
		{
			return (IValueObject)this.Dao.InvokeByMethodName( "GetByParticipant", 
				new object[] { this.DataSource, id, participantId } );
		}
		
		public override ICollection GetAll()
		{
			return this.Dao.GetAll( this.DataSource );
		}

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 
	} 
} 