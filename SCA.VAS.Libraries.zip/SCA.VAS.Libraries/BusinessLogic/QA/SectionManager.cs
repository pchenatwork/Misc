#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.QA;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.QA
{
	#region	Header
	///	<summary>
	///	Manager class for Section.
	///	</summary>
	#endregion Header

	[Serializable]
	public class SectionManager : AbstractManager
	{		
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
		public const string FIND_SECTION_BY_TYPE = "FindSectionByType";
		public const string FIND_SECTION_BY_CATEGORY = "FindSectionByCategory";	
		public const string FIND_SECTION_BY_PARTICIPANT = "FindSectionByParticipant";	
		public const string FIND_SECTION_BY_IDS = "FindSectionByIds";
        public const string FIND_SECTION_BY_USER = "FindSectionByUser";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static SectionManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( SectionManager ).FullName );
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public SectionManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public SectionManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.QA.SectionDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new Section( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************

		/// <summary>
		/// Create a new Section object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update( IValueObject existingObject )
		{
			return this.Dao.Update( this.DataSource, existingObject );
		}

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete( int id )
		{
			return this.Dao.Delete( this.DataSource, id );
		}

		/// <summary>
		/// Update sequences of the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public bool UpdateSequence( SectionCollection sections )
		{
			return (bool)this.Dao.InvokeByMethodName( "UpdateSequence", 
				new object[] { this.DataSource, sections } );
		}

		/// <summary>
		/// Copy this object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public int Copy( int id )
		{
			return (int)this.Dao.InvokeByMethodName( "Copy", 
				new object[] { this.DataSource, id } );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************

		/// <summary>
		/// Get a new Section object from the database.
		/// </summary>
		/// <param name="Id">Section Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}
		
		public IValueObject GetBySequence( int sequence )
		{
			return (IValueObject)this.Dao.InvokeByMethodName( "GetBySequence", 
				new object[] { this.DataSource, sequence } );
		}

		public IValueObject GetByParticipant( int id, int participantId )
		{
			return (IValueObject)this.Dao.InvokeByMethodName( "GetByParticipant", 
				new object[] { this.DataSource, id, participantId } );
		}

		public IValueObject GetBySequenceByParticipant( int sequence, int participantId )
		{
			return (IValueObject)this.Dao.InvokeByMethodName( "GetBySequenceByParticipant", 
				new object[] { this.DataSource, sequence, participantId } );
		}

        public IValueObject GetBySequenceByLanguage(int sequence, int participantId, string language)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("GetBySequenceByLanguage",
                new object[] { this.DataSource, sequence, participantId, language });
        }

		public override ICollection GetAll()
		{
			return this.Dao.GetAll( this.DataSource );
		}

        public int CountByCriteria(string finderType, object[] criteria)
        {
            return (int)this.Dao.InvokeByMethodName("CountByCriteria",
                new object[] { this.DataSource, finderType, criteria });
        }

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 
	} 
} 
