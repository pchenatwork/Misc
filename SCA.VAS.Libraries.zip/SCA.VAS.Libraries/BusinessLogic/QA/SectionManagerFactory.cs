#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.QA
{
	#region	Header
	///	<summary>
	///	Factory for Section
	///	</summary>
	#endregion Header

	public sealed class SectionManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static SectionManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( SectionManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private SectionManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the SectionManagerFactory
		/// </summary>
		/// <returns>an instance of SectionManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( SectionManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new SectionManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new SectionManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new SectionManager( dataSourceName );
		} 
		
		#endregion
	} 
} 