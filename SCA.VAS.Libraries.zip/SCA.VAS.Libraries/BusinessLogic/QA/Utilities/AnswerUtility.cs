#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.QA;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.QA.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class AnswerUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly AnswerManagerFactory _answerManagerFactory = 
			( AnswerManagerFactory ) AnswerManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static AnswerUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( AnswerUtility ).FullName);
		}

		private AnswerUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Answer CreateObject( )
		{
			AnswerManager answerManager = ( AnswerManager ) _answerManagerFactory.CreateInstance( );

			return ( Answer )answerManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, Answer answer )
		{
			AnswerManager answerManager = ( AnswerManager ) _answerManagerFactory.CreateInstance( dataSourceName );

			return answerManager.Create( answer );
		}

		public static bool Update( string dataSourceName, Answer answer )
		{
			AnswerManager answerManager = ( AnswerManager ) _answerManagerFactory.CreateInstance( dataSourceName );

			return answerManager.Update( answer );
		}

		public static bool UpdateCollection( string dataSourceName, int questionId, AnswerCollection collection )
		{
			AnswerManager answerManager = ( AnswerManager ) _answerManagerFactory.CreateInstance( dataSourceName );

			return answerManager.UpdateCollection( questionId, collection );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			AnswerManager answerManager = ( AnswerManager ) _answerManagerFactory.CreateInstance( dataSourceName );

			return answerManager.Delete( id );
		}

		public static Answer Get( string dataSourceName, int id )
		{
			AnswerManager answerManager = ( AnswerManager ) _answerManagerFactory.CreateInstance( dataSourceName );

			return ( Answer )answerManager.Get( id );
		}

		public static void SortAnswers( AnswerCollection answers )
		{
			//get an new sorted answers collection
			Answer answer = AnswerUtility.CreateObject();

			// remove the empty answers
			int length = answers.Count;
			for( int i = length - 1; i >= 0; i-- )
			{
				if( answers[i].Sequence <= 0 || answers[i].AnswerText == "" )
				{
					answers.Remove( answers[i] );
				}
			}

			// recalculate the count and sort the answer collection
			length = answers.Count;
			int min = 0;
			AnswerCollection newAnswers = new AnswerCollection();
			for( int i = 0; i < length; i++ )
			{
				min = i;
				for( int j = i + 1; j < length; j++ )
				{
					if( answers[ j ].Sequence < answers[ min ].Sequence )
					{
						min = j;
					}
				}
				if( min != i )
				{
					answer = answers[ i ];
					answers[ i ] = answers[ min ];
					answers[ i ].Sequence = i + 1;
					answers[ min ] = answer;
				}
			}
		}

		#endregion

	}
}
