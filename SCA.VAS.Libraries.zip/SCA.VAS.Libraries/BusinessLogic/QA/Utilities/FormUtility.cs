#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.QA;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.QA.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class FormUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly FormManagerFactory _formManagerFactory = 
			( FormManagerFactory ) FormManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static FormUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( FormUtility ).FullName);
		}

		private FormUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Form CreateObject( )
		{
			FormManager formManager = ( FormManager ) _formManagerFactory.CreateInstance( );

			return ( Form )formManager.CreateObject( );
		}
	
		public static bool Create( string dataSourceName, Form form )
		{
			FormManager formManager = ( FormManager ) _formManagerFactory.CreateInstance( dataSourceName );

			return formManager.Create( form );
		}

		public static bool Update( string dataSourceName, Form form )
		{
			FormManager formManager = ( FormManager ) _formManagerFactory.CreateInstance( dataSourceName );

			return formManager.Update( form );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			FormManager formManager = ( FormManager ) _formManagerFactory.CreateInstance( dataSourceName );

			return formManager.Delete( id );
		}

		public static int Copy( string dataSourceName, int id )
		{
			FormManager formManager = ( FormManager ) _formManagerFactory.CreateInstance( dataSourceName );

			return formManager.Copy( id );
		}

		public static Form Get( string dataSourceName, int id )
		{
			FormManager formManager = ( FormManager ) _formManagerFactory.CreateInstance( dataSourceName );

			return ( Form )formManager.Get( id );
		}

		public static Form GetById( string dataSourceName, Guid formId )
		{
			FormManager formManager = ( FormManager ) _formManagerFactory.CreateInstance( dataSourceName );

			return ( Form )formManager.GetById( formId );
		}

		public static Form GetByParticipant( string dataSourceName, int id, int participantId )
		{
			FormManager formManager = ( FormManager ) _formManagerFactory.CreateInstance( dataSourceName );

			return ( Form )formManager.GetByParticipant( id, participantId );
		}

		public static FormCollection GetAll( string dataSourceName  )
		{
			FormManager formManager = ( FormManager ) _formManagerFactory.CreateInstance( dataSourceName );

			return ( FormCollection )formManager.GetAll( );
		}
		
		public static FormCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			FormManager formManager = ( FormManager ) _formManagerFactory.CreateInstance( dataSourceName );

			return ( FormCollection )formManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
