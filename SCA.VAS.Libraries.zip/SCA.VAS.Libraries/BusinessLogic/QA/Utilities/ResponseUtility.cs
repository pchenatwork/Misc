#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.QA;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.QA.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class ResponseUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly ResponseManagerFactory _responseManagerFactory = 
			( ResponseManagerFactory ) ResponseManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static ResponseUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ResponseUtility ).FullName);
		}

		private ResponseUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Response CreateObject( )
		{
			ResponseManager responseManager = ( ResponseManager ) _responseManagerFactory.CreateInstance( );

			return ( Response )responseManager.CreateObject( );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			ResponseManager responseManager = ( ResponseManager ) _responseManagerFactory.CreateInstance( dataSourceName );

			return responseManager.Delete( id );
		}

        public static bool UpdateCollection(string dataSourceName, int sectionId, int participantId, ResponseCollection collection)
        {
            ResponseManager responseManager = (ResponseManager)_responseManagerFactory.CreateInstance(dataSourceName);

            return responseManager.UpdateCollection(sectionId, participantId, collection);
        }

        public static bool UpdateAttachment(string dataSourceName, int id, int sectionId, int participantId,
            int questionId, string filename, long attachmentId)
        {
            ResponseManager responseManager = (ResponseManager)_responseManagerFactory.CreateInstance(dataSourceName);

            return responseManager.UpdateAttachment(id, sectionId, participantId, questionId, filename, attachmentId);
        }

		public static bool DeleteAttachment( string dataSourceName, int id )
		{
			ResponseManager responseManager = ( ResponseManager ) _responseManagerFactory.CreateInstance( dataSourceName );

			return responseManager.DeleteAttachment( id );
		}
		
		public static Response Get( string dataSourceName, int id )
		{
			ResponseManager responseManager = ( ResponseManager ) _responseManagerFactory.CreateInstance( dataSourceName );

			return ( Response )responseManager.Get( id );
		}

        public static byte[] GetAttachment(string dataSourceName, int id)
        {
            ResponseManager responseManager = (ResponseManager)_responseManagerFactory.CreateInstance(dataSourceName);

            return (byte[])responseManager.GetAttachment(id);
        }

        public static ResponseCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            ResponseManager responseManager = (ResponseManager)_responseManagerFactory.CreateInstance(dataSourceName);

            return (ResponseCollection)responseManager.FindByCriteria(finderType, criteria);
        }

		public static Response FindObject( ResponseCollection responses, int questionId, int answerId )
		{
			Response response = null;
			for (int i = 0; i < responses.Count; i++)
			{
				if (responses[i].QuestionId == questionId && responses[i].AnswerId == answerId)
				{
					response = responses[i];
					break;
				}
			}
			return response;
		}

		public static void CollectResponse( QuestionCollection questions, ResponseCollection responses )
		{
			foreach( Question question in questions )
			{
				if( question.Responses != null && question.Responses.Count > 0 )
				{
					foreach( Response response in question.Responses )
					{
						responses.Add( response );
					}
				}

				if( question.SubQuestions != null && question.SubQuestions.Count > 0 )
					CollectResponse( question.SubQuestions, responses );
			}
		}

        public static bool UpdateResponses(string dataSourceName, int sectionId, int participantId,
            ResponseCollection collection, ResponseCollection attachments)
        {
            TransactionContext context = TransactionContextFactory.GetContext(TransactionAffinity.Required);

            try
            {
                ResponseManager responseManager = (ResponseManager)_responseManagerFactory.CreateInstance(dataSourceName);

                context.Enter();

                bool bRet = responseManager.UpdateCollection(sectionId, participantId, collection);
                if (bRet)
                {
                    foreach (Response response in attachments)
                    {
                        if (bRet && response.Attachment != null)
                        {
                            bRet &= responseManager.UpdateAttachment(response.Id, sectionId, participantId,
                                response.QuestionId, response.AttachmentName, response.AttachmentId);
                        }
                    }
                }

                if (bRet)
                {
                    context.VoteCommit();
                    return true;
                }
                else
                {
                    context.VoteRollback();
                    return false;
                }
            }
            catch
            {
                context.VoteRollback();
                return false;
            }
            finally
            {
                context.Exit();
            }
        }

		#endregion
	}
}
