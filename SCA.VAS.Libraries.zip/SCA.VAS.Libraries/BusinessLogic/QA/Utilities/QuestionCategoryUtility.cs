#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.QA;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.QA.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class QuestionCategoryUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly QuestionCategoryManagerFactory _questionCategoryManagerFactory = 
			( QuestionCategoryManagerFactory ) QuestionCategoryManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static QuestionCategoryUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( QuestionCategoryUtility ).FullName);
		}

		private QuestionCategoryUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static QuestionCategory CreateObject( )
		{
			QuestionCategoryManager questionCategoryManager = ( QuestionCategoryManager ) _questionCategoryManagerFactory.CreateInstance( );

			return ( QuestionCategory )questionCategoryManager.CreateObject( );
		}

		public static bool UpdateCollection( string dataSourceName, int questionId, QuestionCategoryCollection collection )
		{
			QuestionCategoryManager questionCategoryManager = ( QuestionCategoryManager ) _questionCategoryManagerFactory.CreateInstance( dataSourceName );

			return questionCategoryManager.UpdateCollection( questionId, collection );
		}

		public static QuestionCategoryCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			QuestionCategoryManager questionCategoryManager = ( QuestionCategoryManager ) _questionCategoryManagerFactory.CreateInstance( dataSourceName );

			return ( QuestionCategoryCollection )questionCategoryManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
