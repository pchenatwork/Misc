#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.QA;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.QA.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class ParticipantUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly ParticipantManagerFactory _participantManagerFactory = 
			( ParticipantManagerFactory ) ParticipantManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static ParticipantUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ParticipantUtility ).FullName);
		}

		private ParticipantUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Participant CreateObject( )
		{
			ParticipantManager participantManager = ( ParticipantManager ) _participantManagerFactory.CreateInstance( );

			return ( Participant )participantManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, Participant participant )
		{
			ParticipantManager participantManager = ( ParticipantManager ) _participantManagerFactory.CreateInstance( dataSourceName );

			return participantManager.Create( participant );
		}

		public static bool Update( string dataSourceName, Participant participant )
		{
			ParticipantManager participantManager = ( ParticipantManager ) _participantManagerFactory.CreateInstance( dataSourceName );

			return participantManager.Update( participant );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			ParticipantManager participantManager = ( ParticipantManager ) _participantManagerFactory.CreateInstance( dataSourceName );

			return participantManager.Delete( id );
		}

		public static Participant Get( string dataSourceName, int id )
		{
			ParticipantManager participantManager = ( ParticipantManager ) _participantManagerFactory.CreateInstance( dataSourceName );

			return ( Participant )participantManager.Get( id );
		}

		public static ParticipantCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			ParticipantManager participantManager = ( ParticipantManager ) _participantManagerFactory.CreateInstance( dataSourceName );

			return ( ParticipantCollection )participantManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
