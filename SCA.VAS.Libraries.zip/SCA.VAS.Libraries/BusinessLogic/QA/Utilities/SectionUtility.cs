#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.QA;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.QA.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class SectionUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly SectionManagerFactory _sectionManagerFactory = 
			( SectionManagerFactory ) SectionManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static SectionUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( SectionUtility ).FullName);
		}

		private SectionUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Section CreateObject( )
		{
			SectionManager sectionManager = ( SectionManager ) _sectionManagerFactory.CreateInstance( );

			return ( Section )sectionManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, Section section )
		{
			SectionManager sectionManager = ( SectionManager ) _sectionManagerFactory.CreateInstance( dataSourceName );

			return sectionManager.Create( section );
		}

		public static bool Update( string dataSourceName, Section section )
		{
			SectionManager sectionManager = ( SectionManager ) _sectionManagerFactory.CreateInstance( dataSourceName );

			return sectionManager.Update( section );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			SectionManager sectionManager = ( SectionManager ) _sectionManagerFactory.CreateInstance( dataSourceName );

			return sectionManager.Delete( id );
		}

		public static bool UpdateSequence( string dataSourceName, SectionCollection sections )
		{
			SectionManager sectionManager = ( SectionManager ) _sectionManagerFactory.CreateInstance( dataSourceName );

			return sectionManager.UpdateSequence( sections );
		}

		public static int Copy( string dataSourceName, int id )
		{
			SectionManager sectionManager = ( SectionManager ) _sectionManagerFactory.CreateInstance( dataSourceName );

			return sectionManager.Copy( id );
		}

		public static Section Get( string dataSourceName, int id )
		{
			SectionManager sectionManager = ( SectionManager ) _sectionManagerFactory.CreateInstance( dataSourceName );

		    return ( Section )sectionManager.Get( id );
		}

		public static Section GetBySequence( string dataSourceName, int sequence )
		{
			SectionManager sectionManager = ( SectionManager ) _sectionManagerFactory.CreateInstance( dataSourceName );

			return ( Section )sectionManager.GetBySequence( sequence );
		}

		public static Section GetByParticipant( string dataSourceName, int id, int participantId )
		{
			SectionManager sectionManager = ( SectionManager ) _sectionManagerFactory.CreateInstance( dataSourceName );

			return ( Section )sectionManager.GetByParticipant( id, participantId );
		}

		public static Section GetBySequenceByParticipant( string dataSourceName, int sequence, int participantId )
		{
			SectionManager sectionManager = ( SectionManager ) _sectionManagerFactory.CreateInstance( dataSourceName );

			return ( Section )sectionManager.GetBySequenceByParticipant( sequence, participantId );
		}

        public static Section GetBySequenceByLanguage(string dataSourceName, int sequence, int participantId, string language)
        {
            SectionManager sectionManager = (SectionManager)_sectionManagerFactory.CreateInstance(dataSourceName);

            return (Section)sectionManager.GetBySequenceByLanguage(sequence, participantId, language);
        }

		public static SectionCollection GetAll( string dataSourceName  )
		{
			SectionManager sectionManager = ( SectionManager ) _sectionManagerFactory.CreateInstance( dataSourceName );
			
			return ( SectionCollection )sectionManager.GetAll( );
		}

        public static int CountByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            SectionManager sectionManager = (SectionManager)_sectionManagerFactory.CreateInstance(dataSourceName);

            return sectionManager.CountByCriteria(finderType, criteria);
        }

		public static SectionCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			SectionManager sectionManager = ( SectionManager ) _sectionManagerFactory.CreateInstance( dataSourceName );

			return ( SectionCollection )sectionManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
