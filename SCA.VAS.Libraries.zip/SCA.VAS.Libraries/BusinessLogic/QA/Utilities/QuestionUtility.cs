#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.QA;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.QA.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class QuestionUtility
	{

		#region	Private Questions
		// *************************************************************************
		//				 Private Questions
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly QuestionManagerFactory _questionManagerFactory = 
			( QuestionManagerFactory ) QuestionManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static QuestionUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( QuestionUtility ).FullName);
		}

		private QuestionUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Question CreateObject( )
		{
			QuestionManager questionManager = ( QuestionManager ) _questionManagerFactory.CreateInstance( );

			return ( Question )questionManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, Question question )
		{
			QuestionManager questionManager = ( QuestionManager ) _questionManagerFactory.CreateInstance( dataSourceName );

			return questionManager.Create( question );
		}

		public static bool Update( string dataSourceName, Question question )
		{
			QuestionManager questionManager = ( QuestionManager ) _questionManagerFactory.CreateInstance( dataSourceName );

			return questionManager.Update( question );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			QuestionManager questionManager = ( QuestionManager ) _questionManagerFactory.CreateInstance( dataSourceName );

			return questionManager.Delete( id );
		}

		public static bool UpdateSequence( string dataSourceName, QuestionCollection questions )
		{
			QuestionManager questionManager = ( QuestionManager ) _questionManagerFactory.CreateInstance( dataSourceName );

			return questionManager.UpdateSequence( questions );
		}

		public static int Copy( string dataSourceName, int id )
		{
			QuestionManager questionManager = ( QuestionManager ) _questionManagerFactory.CreateInstance( dataSourceName );

			return questionManager.Copy( id );
		}
		
		public static bool CreateMatrixQuestion( string dataSourceName, int sectionId, Question question )
		{
			QuestionManager questionManager = ( QuestionManager ) _questionManagerFactory.CreateInstance( dataSourceName );

			return questionManager.CreateMatrixQuestion( sectionId, question );
		}

		public static Question Get( string dataSourceName, int id )
		{
			QuestionManager questionManager = ( QuestionManager ) _questionManagerFactory.CreateInstance( dataSourceName );

			return ( Question )questionManager.Get( id );
		}

		public static QuestionCollection GetAll( string dataSourceName  )
		{
			QuestionManager questionManager = ( QuestionManager ) _questionManagerFactory.CreateInstance( dataSourceName );

			return ( QuestionCollection )questionManager.GetAll( );
		}

		public static QuestionCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			QuestionManager questionManager = ( QuestionManager ) _questionManagerFactory.CreateInstance( dataSourceName );

			return ( QuestionCollection )questionManager.FindByCriteria( finderType, criteria );
		}

        public static void GetAllQuestions(QuestionCollection questions, QuestionCollection allQuestions)
        {
            if (questions == null)
                return;

            foreach (Question q in questions)
            {
                allQuestions.Add(q);
                if (q.SubQuestions != null)
                {
                    GetAllQuestions(q.SubQuestions, allQuestions);
                }
            }
        }

		public static void OrganizeChild( Question question )
		{
			if( question.Answers != null )
			{
				for( int i = 0; i < question.Answers.Count; i++ )
				{
					question.Answers[i].Id = i + 1;
					question.Answers[i].QuestionId = question.Id;
				}
			}

			if( question.SubQuestions != null )
			{
				for( int i = 0; i < question.SubQuestions.Count; i ++ )
				{
					question.SubQuestions[i].Id = i + 1;
					question.SubQuestions[i].ParentId = question.Id;
					OrganizeChild( question.SubQuestions[i] );
				}
			}
		}

		public static void SortChild( Question question )
		{
			for( int i = 0; i < question.Answers.Count -1; i++ )
			{
				for( int j = question.Answers.Count -1; j > i ; j -- )
				{
					if( question.Answers[j].Sequence < question.Answers[j - 1].Sequence)
					{
						Answer answer = question.Answers[j];
						question.Answers[j] = question.Answers[j-1];
						question.Answers[j - 1] = answer;
					}
				}
			}
			for( int i = 0; i < question.SubQuestions.Count -1; i++ )
			{
				for( int j = question.SubQuestions.Count - 1; j > i ; j -- )
				{
					if( question.SubQuestions[j].Sequence < 
						question.SubQuestions[j - 1].Sequence)
					{
						Question subQuestion = question.SubQuestions[j];
						question.SubQuestions[j] = question.SubQuestions[j-1];
						question.SubQuestions[j - 1] = subQuestion;
					}
				}
			}

			foreach( Question subQuestion in question.SubQuestions )
			{
				SortChild( subQuestion );
			}
		}

		public static bool CreateQuestion( string dataSourceName, Question question )
		{
			TransactionContext context = TransactionContextFactory.GetContext( TransactionAffinity.Required );

			try
			{
				QuestionManager questionManager = ( QuestionManager ) _questionManagerFactory.CreateInstance( dataSourceName );

				context.Enter();

				bool bRet = questionManager.Create( question );
				if ( bRet )
				{
					if (bRet && question.QuestionCategories != null && question.QuestionCategories.Count > 0)
					{
						bRet &= QuestionCategoryUtility.UpdateCollection( dataSourceName, question.Id, question.QuestionCategories );
					}
					if (bRet && question.Answers != null && question.Answers.Count > 0)
					{
						bRet &= AnswerUtility.UpdateCollection( dataSourceName, question.Id, question.Answers );
					}
				}

				if ( bRet )
				{
					context.VoteCommit( );
					return true;
				}
				else
				{
					context.VoteRollback( );
					return false;
				}
			}
			catch
			{
				context.VoteRollback( );
				return false;
			}
			finally
			{
				context.Exit( );
			}
		}
		
		public static bool UpdateQuestion( string dataSourceName, Question question )
		{
			TransactionContext context = TransactionContextFactory.GetContext( TransactionAffinity.Required );

			try
			{
				QuestionManager questionManager = ( QuestionManager ) _questionManagerFactory.CreateInstance( dataSourceName );

				context.Enter();

				bool bRet = questionManager.Update( question );
				if ( bRet )
				{
					if (bRet && question.QuestionCategories != null && question.QuestionCategories.Count > 0)
					{
						bRet &= QuestionCategoryUtility.UpdateCollection( dataSourceName, question.Id, question.QuestionCategories );
					}
					if (bRet && question.Answers != null && question.Answers.Count > 0)
					{
						bRet &= AnswerUtility.UpdateCollection( dataSourceName, question.Id, question.Answers );
					}
				}

				if ( bRet )
				{
					context.VoteCommit( );
					return true;
				}
				else
				{
					context.VoteRollback( );
					return false;
				}
			}
			catch
			{
				context.VoteRollback( );
				return false;
			}
			finally
			{
				context.Exit( );
			}
		}
		#endregion

	}
}
