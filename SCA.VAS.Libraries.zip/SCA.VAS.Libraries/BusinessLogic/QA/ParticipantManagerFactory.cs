#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Participant
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.QA
{
	#region	Header
	///	<summary>
	///	Factory for Participant
	///	</summary>
	#endregion Header

	public sealed class ParticipantManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static ParticipantManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ParticipantManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private ParticipantManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the ParticipantManagerFactory
		/// </summary>
		/// <returns>an instance of ParticipantManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( ParticipantManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new ParticipantManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new ParticipantManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new ParticipantManager( dataSourceName );
		} 
		#endregion Public Methods
	} 
} 