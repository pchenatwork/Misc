#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.QA;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.QA
{
	#region	Header
	///	<summary>
	///	Manager class for Question.
	///	</summary>
	#endregion Header

	[Serializable]
	public class QuestionManager : AbstractManager
	{		
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
		public const string FIND_SEARCHABLE_QUESTION = "FindSearchableQuestion";
        public const string FIND_QUESTION_BY_CATEGORY = "FindQuestionByCategory";
        public const string FIND_QUESTION_BY_SUPPLIER = "FindQuestionBySupplier";
        public const string FIND_QUESTION_BY_USER = "FindQuestionByUser";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static QuestionManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( QuestionManager ).FullName );
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public QuestionManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public QuestionManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.QA.QuestionDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new Question( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************

		/// <summary>
		/// Create a new Question object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update( IValueObject existingObject )
		{
			return this.Dao.Update( this.DataSource, existingObject );
		}

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete( int id )
		{
			return this.Dao.Delete( this.DataSource, id );
		}

		
		/// <summary>
		/// Update sequences of the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public bool UpdateSequence( QuestionCollection questions )
		{
			return (bool)this.Dao.InvokeByMethodName( "UpdateSequence", 
				new object[] { this.DataSource, questions } );
		}

		/// <summary>
		/// Copy this object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public int Copy( int id )
		{
			return (int)this.Dao.InvokeByMethodName( "Copy", 
				new object[] { this.DataSource, id } );
		}
		
		/// <summary>
		/// Create the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public bool CreateMatrixQuestion( int sectionId, Question question )
		{
			return (bool)this.Dao.InvokeByMethodName( "CreateMatrixQuestion", 
				new object[] { this.DataSource, sectionId, question } );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************

		/// <summary>
		/// Get a new Question object from the database.
		/// </summary>
		/// <param name="Id">Question Id</param>
		/// <returns></returns>
        public override IValueObject Get(int id)
        {
            return this.Dao.Get(this.DataSource, id);
        }
		
		public override ICollection GetAll()
		{
			return this.Dao.GetAll( this.DataSource );
		}

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 
	} 
} 
