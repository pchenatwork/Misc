#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.QEngine;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;
using BaseAction = SCA.VAS.ValueObjects.QEngine.Action;

using log4net;

namespace SCA.VAS.BusinessLogic.QEngine.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class ActionUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly ActionManagerFactory _actionManagerFactory = 
			( ActionManagerFactory ) ActionManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static ActionUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ActionUtility ).FullName);
		}

		private ActionUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static BaseAction CreateObject( )
		{
			ActionManager actionManager = ( ActionManager ) _actionManagerFactory.CreateInstance( );

			return ( BaseAction )actionManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, BaseAction action )
		{
			ActionManager actionManager = ( ActionManager ) _actionManagerFactory.CreateInstance( dataSourceName );

			return actionManager.Create( action );
		}

		public static bool Update( string dataSourceName, BaseAction action )
		{
			ActionManager actionManager = ( ActionManager ) _actionManagerFactory.CreateInstance( dataSourceName );

			return actionManager.Update( action );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			ActionManager actionManager = ( ActionManager ) _actionManagerFactory.CreateInstance( dataSourceName );

			return actionManager.Delete( id );
		}

		public static BaseAction Get( string dataSourceName, int id )
		{
			ActionManager actionManager = ( ActionManager ) _actionManagerFactory.CreateInstance( dataSourceName );

			return ( BaseAction )actionManager.Get( id );
		}

		public static ActionCollection GetAll( string dataSourceName )
		{
			ActionManager actionManager = ( ActionManager ) _actionManagerFactory.CreateInstance( dataSourceName );

			return ( ActionCollection )actionManager.GetAll( );
		}
		
		public static ActionCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			ActionManager actionManager = ( ActionManager ) _actionManagerFactory.CreateInstance( dataSourceName );

			return ( ActionCollection )actionManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
