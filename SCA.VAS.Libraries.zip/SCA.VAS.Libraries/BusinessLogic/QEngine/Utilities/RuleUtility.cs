#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.QEngine;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;
using BaseRule = SCA.VAS.ValueObjects.QEngine.Rule;

using log4net;

namespace SCA.VAS.BusinessLogic.QEngine.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class RuleUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly RuleManagerFactory _ruleManagerFactory = 
			( RuleManagerFactory ) RuleManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static RuleUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( RuleUtility ).FullName);
		}

		private RuleUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static BaseRule CreateObject( )
		{
			RuleManager ruleManager = ( RuleManager ) _ruleManagerFactory.CreateInstance( );

			return ( BaseRule )ruleManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, BaseRule rule )
		{
			RuleManager ruleManager = ( RuleManager ) _ruleManagerFactory.CreateInstance( dataSourceName );

			return ruleManager.Create( rule );
		}

		public static bool Update( string dataSourceName, BaseRule rule )
		{
			RuleManager ruleManager = ( RuleManager ) _ruleManagerFactory.CreateInstance( dataSourceName );

			return ruleManager.Update( rule );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			RuleManager ruleManager = ( RuleManager ) _ruleManagerFactory.CreateInstance( dataSourceName );

			return ruleManager.Delete( id );
		}

		public static BaseRule Get( string dataSourceName, int id )
		{
			RuleManager ruleManager = ( RuleManager ) _ruleManagerFactory.CreateInstance( dataSourceName );

			return ( BaseRule )ruleManager.Get( id );
		}

		public static RuleCollection GetAll( string dataSourceName )
		{
			RuleManager ruleManager = ( RuleManager ) _ruleManagerFactory.CreateInstance( dataSourceName );

			return ( RuleCollection )ruleManager.GetAll( );
		}
		
		public static RuleCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			RuleManager ruleManager = ( RuleManager ) _ruleManagerFactory.CreateInstance( dataSourceName );

			return ( RuleCollection )ruleManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
