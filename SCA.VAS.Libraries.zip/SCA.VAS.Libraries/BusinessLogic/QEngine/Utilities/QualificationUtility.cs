#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.QEngine;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.QEngine.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class QualificationUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly QualificationManagerFactory _qualificationManagerFactory = 
			( QualificationManagerFactory ) QualificationManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static QualificationUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( QualificationUtility ).FullName);
		}

		private QualificationUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Qualification CreateObject( )
		{
			QualificationManager qualificationManager = ( QualificationManager ) _qualificationManagerFactory.CreateInstance( );

			return ( Qualification )qualificationManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, Qualification qualification )
		{
			QualificationManager qualificationManager = ( QualificationManager ) _qualificationManagerFactory.CreateInstance( dataSourceName );

			return qualificationManager.Create( qualification );
		}

		public static bool Update( string dataSourceName, Qualification qualification )
		{
			QualificationManager qualificationManager = ( QualificationManager ) _qualificationManagerFactory.CreateInstance( dataSourceName );

			return qualificationManager.Update( qualification );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			QualificationManager qualificationManager = ( QualificationManager ) _qualificationManagerFactory.CreateInstance( dataSourceName );

			return qualificationManager.Delete( id );
		}

		public static Qualification Get( string dataSourceName, int id )
		{
			QualificationManager qualificationManager = ( QualificationManager ) _qualificationManagerFactory.CreateInstance( dataSourceName );

			return ( Qualification )qualificationManager.Get( id );
		}

		public static QualificationCollection GetAll( string dataSourceName )
		{
			QualificationManager qualificationManager = ( QualificationManager ) _qualificationManagerFactory.CreateInstance( dataSourceName );

			return ( QualificationCollection )qualificationManager.GetAll( );
		}
		
		public static QualificationCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			QualificationManager qualificationManager = ( QualificationManager ) _qualificationManagerFactory.CreateInstance( dataSourceName );

			return ( QualificationCollection )qualificationManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
