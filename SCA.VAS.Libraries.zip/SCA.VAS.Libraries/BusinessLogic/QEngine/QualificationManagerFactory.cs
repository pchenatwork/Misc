#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.QEngine
{
	#region	Header
	///	<summary>
	///	Factory for Qualification
	///	</summary>
	#endregion Header

	public sealed class QualificationManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static QualificationManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( QualificationManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private QualificationManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the QualificationManagerFactory
		/// </summary>
		/// <returns>an instance of QualificationManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( QualificationManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new QualificationManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new QualificationManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new QualificationManager( dataSourceName );
		} 
		
		#endregion
	} 
} 