#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common
{
	#region	Header
	///	<summary>
	///	Manager class for Setting.
	///	</summary>
	#endregion Header

	[Serializable]
	public class SettingManager : AbstractManager
	{		
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
		public const string FIND_SETTING_BY_KEYWORD = "FindSettingByKeyword";
        public const string FIND_SETTING_BY_TYPE = "FindSettingByType";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static SettingManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( SettingManager ).FullName );
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public SettingManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public SettingManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Common.SettingDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new Setting( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************

		/// <summary>
		/// Create a new Setting object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update( IValueObject existingObject )
		{
			return this.Dao.Update( this.DataSource, existingObject );
		}

        /// <summary>
        /// Import data to the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ICollection Import(string type, string xml)
        {
            return (ICollection)this.Dao.InvokeByMethodName("Import",
                new object[] { this.DataSource, type, xml });
        }

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="name"></param>
		/// <returns></returns>
		public bool Delete( string name )
		{
			return (bool)this.Dao.InvokeByMethodName( "Delete", 
				new object[] { this.DataSource, name } );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new Setting object from the database.
		/// </summary>
		/// <param name="name">Setting Name</param>
		/// <returns></returns>
		public IValueObject GetByName( string name )
		{
			return (IValueObject)this.Dao.InvokeByMethodName( "GetByName", 
				new object[] { this.DataSource, name } );
		}
		
		public override ICollection GetAll()
		{
			return this.Dao.GetAll( this.DataSource );
		}
		
		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 
	} 
} 
