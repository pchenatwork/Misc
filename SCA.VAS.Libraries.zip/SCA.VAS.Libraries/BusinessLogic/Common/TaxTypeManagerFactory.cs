
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common 
{ 
	#region Header 
	/// <summary>
	/// Factory for TaxTypeManager.
	/// </summary>
	#endregion Header
	
	public class TaxTypeManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static TaxTypeManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( TaxTypeManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private TaxTypeManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the TaxTypeManagerFactory
		/// </summary>
		/// <returns>an instance of TaxTypeManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( TaxTypeManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new TaxTypeManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new TaxTypeManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new TaxTypeManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}