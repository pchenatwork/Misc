﻿#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common
{
    #region	Header
    ///	<summary>
    ///	Manager class for Lookup.
    ///	</summary>
    #endregion Header

    [Serializable]
    public class LookupManager : AbstractManager
    {
        #region	Constants
        // *************************************************************************
        //				 constants
        // *************************************************************************
        public const string FIND_LOOKUP_BY_TYPE = "FindLookupByType";
        #endregion Constants

        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        // Private members block	includes instance and static members & structs
        private static ILog _logger = null;

        #endregion Private Members

        #region	Constructors
        // *************************************************************************
        //				 Constructors
        // *************************************************************************
        /// <summary>
        /// class constructor 
        /// initializes logging
        /// </summary>
        static LookupManager()
        {
            _logger = LoggingUtility.GetLogger(typeof(LookupManager).FullName);
        } //	end	class constructor

        ///	<summary>
        ///	default	constructor	
        ///	inits with default
        ///	</summary>
        public LookupManager()
        {
        } // end constructor

        ///	<summary>
        ///	default	constructor	
        ///	inits with a DataSource.
        ///	</summary>
        public LookupManager(string dataSourceName)
            : base(dataSourceName)
        {
        }
        #endregion Constructors

        #region IManager
        // *************************************************************************
        //                IManager
        // *************************************************************************
        /// <summary>
        /// Property DaoClassName (string)
        /// </summary>
        public override string DaoClassName
        {
            get
            {
                return "SCA.VAS.DataAccess.Common.LookupDao";
            }
        }

        public override IValueObject CreateObject()
        {
            return new Lookup();
        }
        #endregion

        #region IPersistentManager
        // *************************************************************************
        //				 IPersistentManager
        // *************************************************************************

        /// <summary>
        /// Create a new Lookup object in the database.
        /// </summary>
        /// <param name="newObject"></param>
        /// <returns></returns>
        public override bool Create(IValueObject newObject)
        {
            return this.Dao.Create(this.DataSource, newObject);
        }

        /// <summary>
        /// Update the object in the database.
        /// </summary>
        /// <param name="existingObject"></param>
        /// <returns></returns>
        public override bool Update(IValueObject existingObject)
        {
            return this.Dao.Update(this.DataSource, existingObject);
        }

        /// <summary>
        /// Remove the object from the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public override bool Delete(int id)
        {
            return this.Dao.Delete(this.DataSource, id);
        }
        #endregion

        #region IFinder
        // *************************************************************************
        //				 IFinder
        // *************************************************************************
        /// <summary>
        /// Get a new Lookup object from the database.
        /// </summary>
        /// <param name="Id">Lookup Id</param>
        /// <returns></returns>
        public override IValueObject Get(int id)
        {
            return this.Dao.Get(this.DataSource, id);
        }

        public ICollection GetByType(string type)
        {
            return(ICollection)this.Dao.InvokeByMethodName("GetByType",new object[] { this.DataSource, type });
        }

        public ICollection FindByCriteria(string criteria, string criteriaValue)
        {
            return (ICollection) this.Dao.InvokeByMethodName("FindByCriteria", new object[]{this.DataSource,criteria,criteriaValue});
        }

        public ICollection FindByHardbidProjectSearchType(string search, string searchType)
        {
            return (ICollection) this.Dao.InvokeByMethodName("FindByHardbidProjectSearchType", new object[]{this.DataSource,search,searchType});
        }
        #endregion
    }
}
