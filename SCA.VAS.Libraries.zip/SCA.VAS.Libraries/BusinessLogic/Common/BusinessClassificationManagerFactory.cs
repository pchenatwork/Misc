#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common
{
	#region	Header
	///	<summary>
	///	Factory for BusinessClassification
	///	</summary>
	#endregion Header

	public sealed class BusinessClassificationManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static BusinessClassificationManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BusinessClassificationManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private BusinessClassificationManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the BusinessClassificationManagerFactory
		/// </summary>
		/// <returns>an instance of BusinessClassificationManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( BusinessClassificationManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new BusinessClassificationManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new BusinessClassificationManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new BusinessClassificationManager( dataSourceName );
		} 
		
		#endregion
	} 
} 