
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common 
{ 
	#region Header 
	/// <summary>
	/// Manager class for AccountType.
	/// </summary>
	#endregion Header
	
	public class DashBoardManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
		#endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
        #endregion Private Members

        #region	Constructors
        // *************************************************************************
        //				 Constructors
        // *************************************************************************
        /// <summary>
        /// class constructor 
        /// initializes logging
        /// </summary>
        static DashBoardManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( AccountTypeManager ).FullName);
		} //	end	class constructor

		/// <summary>
		/// default	constructor	
		/// inits with default
		///	</summary>
		public DashBoardManager()
		{
		} // end constructor

		///	<summary>
		/// default constructor	
		/// inits with a DataSource.
		///	</summary>
		public DashBoardManager( string dataSourceName ) : base( dataSourceName )
		{
		}
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Common.DashBoardDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new DashBoard( );
		}
		#endregion

		#region IPersistentManager
		
		#endregion 

		#region Public Methods
		
		public ICollection ContractSpecialist(  )
		{
			return (ICollection)this.Dao.InvokeByMethodName("ContractSpecialist", new object[] { this.DataSource }  );
		}

		public ICollection HBContractSpecialist()
		{
			return (ICollection)this.Dao.InvokeByMethodName("HBContractSpecialist", new object[] { this.DataSource });
		}

		public ICollection GetDashboardType(string userName)
        {
            return (ICollection)this.Dao.InvokeByMethodName("GetDashboardType", new object[] { this.DataSource, userName });
        }
        #endregion

	    public ICollection GetDashboard(string userName, string isAffiliates)
	    {
            return (ICollection)this.Dao.InvokeByMethodName("GetDashboard", new object[] { this.DataSource, userName, isAffiliates });
        }
        public ICollection GetDashboardWorkFlowTypes()
        {
            return (ICollection)this.Dao.InvokeByMethodName("GetDashboardWorkFlowTypes", new object[] { this.DataSource });
        }
    }
}