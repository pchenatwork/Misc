#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common
{
	#region	Header
	///	<summary>
	///	Factory for UnitOfMeasure
	///	</summary>
	#endregion Header

	public sealed class UnitOfMeasureManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static UnitOfMeasureManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( UnitOfMeasureManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private UnitOfMeasureManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the UnitOfMeasureManagerFactory
		/// </summary>
		/// <returns>an instance of UnitOfMeasureManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( UnitOfMeasureManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new UnitOfMeasureManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new UnitOfMeasureManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new UnitOfMeasureManager( dataSourceName );
		} 
		
		#endregion
	} 
} 