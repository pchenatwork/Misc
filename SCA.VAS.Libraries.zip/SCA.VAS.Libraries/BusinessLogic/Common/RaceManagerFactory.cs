#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common
{
	#region	Header
	///	<summary>
	///	Factory for Race
	///	</summary>
	#endregion Header

	public sealed class RaceManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static RaceManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( RaceManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private RaceManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the RaceManagerFactory
		/// </summary>
		/// <returns>an instance of RaceManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( RaceManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new RaceManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new RaceManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new RaceManager( dataSourceName );
		} 
		
		#endregion
	} 
} 