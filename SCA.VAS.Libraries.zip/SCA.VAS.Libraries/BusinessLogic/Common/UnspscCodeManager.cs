#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common
{
	#region	Header
	///	<summary>
	///	Manager class for UnspscCode.
	///	</summary>
	#endregion Header

	[Serializable]
	public class UnspscCodeManager : AbstractManager
	{		
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
		public const string FIND_BY_KEYWORD = "FindByKeyword";
		public const string FIND_UNSPSCCODE = "FindUnspscCode";
        public const string FIND_UNSPSCCODE_BY_PARENT = "FindUnspscCodeByParent";
        public const string FIND_UNSPSCCODE_BY_LANGUAGE = "FindUnspscCodeByLanguage";
        public const string SEARCH_UNSPSCCODE = "SearchUnspscCode";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static UnspscCodeManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( UnspscCodeManager ).FullName );
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public UnspscCodeManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public UnspscCodeManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Common.UnspscCodeDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new UnspscCode( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************

		/// <summary>
		/// Create a new UnspscCode object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update( IValueObject existingObject )
		{
			return this.Dao.Update( this.DataSource, existingObject );
		}

        /// <summary>
        /// Update the object in the database.
        /// </summary>
        /// <returns></returns>
        public bool UpdateCollection(UnspscCodeCollection collection)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateCollection",
                new object[] { this.DataSource, collection });
        }

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public bool Delete( string code )
		{
			return (bool)this.Dao.InvokeByMethodName( "Delete", 
				new object[] { this.DataSource, code } );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************

		/// <summary>
		/// Get a new UnspscCode object from the database.
		/// </summary>
		/// <param name="code">UnspscCode Code</param>
		/// <returns></returns>
		public IValueObject Get( string code )
		{
			return (IValueObject)this.Dao.InvokeByMethodName( "Get", 
				new object[] { this.DataSource, code } );
		}
		
		public override ICollection GetAll()
		{
			return this.Dao.GetAll( this.DataSource );
		}

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 
	} 
} 
