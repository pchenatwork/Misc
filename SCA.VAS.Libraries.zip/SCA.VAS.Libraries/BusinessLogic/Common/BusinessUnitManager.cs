#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common
{
	#region	Header
	///	<summary>
	///	Manager class for BusinessUnit.
	///	</summary>
	#endregion Header

	[Serializable]
	public class BusinessUnitManager : AbstractManager
	{		
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string FIND_ACTIVE_BUSINESSUNIT = "FindActiveBusinessUnit";
        public const string FIND_BUSINESSUNIT_BY_PARENT = "FindBusinessUnitByParent";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static BusinessUnitManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BusinessUnitManager ).FullName );
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public BusinessUnitManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public BusinessUnitManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Common.BusinessUnitDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new BusinessUnit( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************

		/// <summary>
		/// Create a new BusinessUnit object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update( IValueObject existingObject )
		{
			return this.Dao.Update( this.DataSource, existingObject );
		}

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete( int id )
		{
			return this.Dao.Delete( this.DataSource, id );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************

		/// <summary>
		/// Get a new BusinessUnit object from the database.
		/// </summary>
		/// <param name="Id">BusinessUnit Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}
		
		/// <summary>
		/// Get a new BusinessUnit object from the database.
		/// </summary>
		/// <param name="name">BusinessUnit Name</param>
		/// <returns></returns>
		public IValueObject GetByName( string name )
		{
			return (IValueObject)this.Dao.InvokeByMethodName( "GetByName", 
				new object[] { this.DataSource, name } );
		}
		
		public override ICollection GetAll()
		{
			return this.Dao.GetAll( this.DataSource );
		}

        public override ICollection FindByCriteria(string finderType, object[] criteria)
        {
            return this.Dao.FindByCriteria(this.DataSource, finderType, criteria);
        }
		#endregion 
	} 
} 
