#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class CountyUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly CountyManagerFactory _countyManagerFactory = 
			( CountyManagerFactory ) CountyManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static CountyUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CountyUtility ).FullName);
		}

		private CountyUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static County CreateObject( )
		{
			CountyManager countyManager = ( CountyManager ) _countyManagerFactory.CreateInstance( );

			return ( County )countyManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, County county )
		{
			CountyManager countyManager = ( CountyManager ) _countyManagerFactory.CreateInstance( dataSourceName );

			return countyManager.Create( county );
		}

		public static bool Update( string dataSourceName, County county )
		{
			CountyManager countyManager = ( CountyManager ) _countyManagerFactory.CreateInstance( dataSourceName );

			return countyManager.Update( county );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			CountyManager countyManager = ( CountyManager ) _countyManagerFactory.CreateInstance( dataSourceName );

			return countyManager.Delete( id );
		}

		public static County Get( string dataSourceName, int id )
		{
			CountyManager countyManager = ( CountyManager ) _countyManagerFactory.CreateInstance( dataSourceName );

			return ( County )countyManager.Get( id );
		}

		public static CountyCollection GetAll( string dataSourceName  )
		{
			CountyManager countyManager = ( CountyManager ) _countyManagerFactory.CreateInstance( dataSourceName );

			return ( CountyCollection )countyManager.GetAll( );
		}

		public static CountyCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			CountyManager countyManager = ( CountyManager ) _countyManagerFactory.CreateInstance( dataSourceName );

			return ( CountyCollection )countyManager.FindByCriteria( finderType, criteria );
		}

		public static DataSet FindDataSetByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			CountyManager countyManager = ( CountyManager ) _countyManagerFactory.CreateInstance( dataSourceName );

			return countyManager.FindDataSetByCriteria( finderType, criteria );
		}
		#endregion

	}
}
