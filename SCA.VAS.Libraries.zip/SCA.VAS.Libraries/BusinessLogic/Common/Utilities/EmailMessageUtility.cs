#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class EmailMessageUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly EmailMessageManagerFactory _emailMessageManagerFactory = 
			( EmailMessageManagerFactory ) EmailMessageManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static EmailMessageUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( EmailMessageUtility ).FullName);
		}

		private EmailMessageUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static EmailMessage CreateObject( )
		{
			EmailMessageManager emailMessageManager = ( EmailMessageManager ) _emailMessageManagerFactory.CreateInstance( );

			return ( EmailMessage )emailMessageManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, EmailMessage emailMessage )
		{
			EmailMessageManager emailMessageManager = ( EmailMessageManager ) _emailMessageManagerFactory.CreateInstance( dataSourceName );

			return emailMessageManager.Create( emailMessage );
		}

		public static bool Update( string dataSourceName, EmailMessage emailMessage )
		{
			EmailMessageManager emailMessageManager = ( EmailMessageManager ) _emailMessageManagerFactory.CreateInstance( dataSourceName );

			return emailMessageManager.Update( emailMessage );
		}

		public static int Copy( string dataSourceName, int id )
		{
			EmailMessageManager emailMessageManager = ( EmailMessageManager ) _emailMessageManagerFactory.CreateInstance( dataSourceName );

			return emailMessageManager.Copy( id );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			EmailMessageManager emailMessageManager = ( EmailMessageManager ) _emailMessageManagerFactory.CreateInstance( dataSourceName );

			return emailMessageManager.Delete( id );
		}

		public static EmailMessage Get( string dataSourceName, int id )
		{
			EmailMessageManager emailMessageManager = ( EmailMessageManager ) _emailMessageManagerFactory.CreateInstance( dataSourceName );

			return ( EmailMessage )emailMessageManager.Get( id );
		}

		public static EmailMessage GetByName( string dataSourceName, string name )
		{
			EmailMessageManager emailMessageManager = ( EmailMessageManager ) _emailMessageManagerFactory.CreateInstance( dataSourceName );

			return ( EmailMessage )emailMessageManager.GetByName( name );
		}
		
		public static EmailMessageCollection GetAll( string dataSourceName  )
		{
			EmailMessageManager emailMessageManager = ( EmailMessageManager ) _emailMessageManagerFactory.CreateInstance( dataSourceName );

			return ( EmailMessageCollection )emailMessageManager.GetAll( );
		}

		public static EmailMessageCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			EmailMessageManager emailMessageManager = ( EmailMessageManager ) _emailMessageManagerFactory.CreateInstance( dataSourceName );

			return ( EmailMessageCollection )emailMessageManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
