#region	Copyright 2005 by AECsoft USA Inc.
/*
************************************************************************
Copyright 2005 by AECsoft USA Inc.

All	rights reserved. No	portion	of this	software or	its	content	may	be
reproduced in any form or by any means,	without	the	express	written
permission of the copyright	owner.
************************************************************************
*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.Common.Utilities;	

using log4net;
#endregion

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Summary description for PasswordUtility.
	/// </summary>
	public class PasswordUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;
		#endregion Private Members

		#region Constructor
		public PasswordUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PasswordUtility ).FullName);
		}
		#endregion

		#region Public Methods
		/// <summary>
		/// Random Generate Password
		/// </summary>
		/// <param name="passwordLength"></param>
        public static string Generate(int length)
		{
            // Get the GUID
            string guidResult = System.Guid.NewGuid().ToString();

            // Remove the hyphens
            guidResult = guidResult.Replace("-", string.Empty);

            // Make sure length is valid
            if (length <= 0 || length > guidResult.Length)
                throw new ArgumentException("Length must be between 1 and " + guidResult.Length);

            // Return the first length bytes
            return guidResult.Substring(0, length);
		}
		#endregion
	}
}
