#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class UnspscCodeUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly UnspscCodeManagerFactory _unspscCodeManagerFactory = 
			( UnspscCodeManagerFactory ) UnspscCodeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static UnspscCodeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( UnspscCodeUtility ).FullName);
		}

		private UnspscCodeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static UnspscCode CreateObject( )
		{
			UnspscCodeManager unspscCodeManager = ( UnspscCodeManager ) _unspscCodeManagerFactory.CreateInstance( );

			return ( UnspscCode )unspscCodeManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, UnspscCode unspscCode )
		{
			UnspscCodeManager unspscCodeManager = ( UnspscCodeManager ) _unspscCodeManagerFactory.CreateInstance( dataSourceName );

			return unspscCodeManager.Create( unspscCode );
		}

		public static bool Update( string dataSourceName, UnspscCode unspscCode )
		{
			UnspscCodeManager unspscCodeManager = ( UnspscCodeManager ) _unspscCodeManagerFactory.CreateInstance( dataSourceName );

			return unspscCodeManager.Update( unspscCode );
		}

        public static bool UpdateCollection(string dataSourceName, UnspscCodeCollection collection)
        {
            UnspscCodeManager unspscCodeManager = (UnspscCodeManager)_unspscCodeManagerFactory.CreateInstance(dataSourceName);

            return unspscCodeManager.UpdateCollection(collection);
        }

		public static bool Delete( string dataSourceName, string code )
		{
			UnspscCodeManager unspscCodeManager = ( UnspscCodeManager ) _unspscCodeManagerFactory.CreateInstance( dataSourceName );

			return unspscCodeManager.Delete( code );
		}

		public static UnspscCode Get( string dataSourceName, string code )
		{
			UnspscCodeManager unspscCodeManager = ( UnspscCodeManager ) _unspscCodeManagerFactory.CreateInstance( dataSourceName );

			return ( UnspscCode )unspscCodeManager.Get( code );
		}

		public static UnspscCodeCollection GetAll( string dataSourceName  )
		{
			UnspscCodeManager unspscCodeManager = ( UnspscCodeManager ) _unspscCodeManagerFactory.CreateInstance( dataSourceName );

			return ( UnspscCodeCollection )unspscCodeManager.GetAll( );
		}

		public static UnspscCodeCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			UnspscCodeManager unspscCodeManager = ( UnspscCodeManager ) _unspscCodeManagerFactory.CreateInstance( dataSourceName );

			return ( UnspscCodeCollection )unspscCodeManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
