
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class BranchAccountUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BranchAccountManagerFactory _branchAccountManagerFactory = 
			( BranchAccountManagerFactory ) BranchAccountManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BranchAccountUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BranchAccountUtility ).FullName);
		}

		private BranchAccountUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static BranchAccount CreateObject( )
		{
			BranchAccountManager branchAccountManager = ( BranchAccountManager ) _branchAccountManagerFactory.CreateInstance( );

			return ( BranchAccount )branchAccountManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, BranchAccount branchAccount )
		{
			BranchAccountManager branchAccountManager = ( BranchAccountManager ) _branchAccountManagerFactory.CreateInstance( dataSourceName );

			return branchAccountManager.Create( branchAccount );
		}
		
		public static bool Update( string dataSourceName, BranchAccount branchAccount )
		{
			BranchAccountManager branchAccountManager = ( BranchAccountManager ) _branchAccountManagerFactory.CreateInstance( dataSourceName );

			return branchAccountManager.Update( branchAccount );
		}
		
		public static bool Delete( string dataSourceName, int id )
		{
			BranchAccountManager branchAccountManager = ( BranchAccountManager ) _branchAccountManagerFactory.CreateInstance( dataSourceName );

			return branchAccountManager.Delete( id );
		}

		public static BranchAccount Get( string dataSourceName, int id )
		{
			BranchAccountManager branchAccountManager = ( BranchAccountManager ) _branchAccountManagerFactory.CreateInstance( dataSourceName );

			return ( BranchAccount )branchAccountManager.Get( id );
		}

		public static BranchAccountCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			BranchAccountManager branchAccountManager = ( BranchAccountManager ) _branchAccountManagerFactory.CreateInstance( dataSourceName );

			return ( BranchAccountCollection )branchAccountManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}