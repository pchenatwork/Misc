#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class JobScheduleUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly JobScheduleManagerFactory _jobScheduleManagerFactory = 
			( JobScheduleManagerFactory ) JobScheduleManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static JobScheduleUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( JobScheduleUtility ).FullName);
		}

		private JobScheduleUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static JobSchedule CreateObject( )
		{
			JobScheduleManager jobScheduleManager = ( JobScheduleManager ) _jobScheduleManagerFactory.CreateInstance( );

			return ( JobSchedule )jobScheduleManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, JobSchedule jobSchedule )
		{
			JobScheduleManager jobScheduleManager = ( JobScheduleManager ) _jobScheduleManagerFactory.CreateInstance( dataSourceName );

			return jobScheduleManager.Create( jobSchedule );
		}

		public static bool Update( string dataSourceName, JobSchedule jobSchedule )
		{
			JobScheduleManager jobScheduleManager = ( JobScheduleManager ) _jobScheduleManagerFactory.CreateInstance( dataSourceName );

			return jobScheduleManager.Update( jobSchedule );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			JobScheduleManager jobScheduleManager = ( JobScheduleManager ) _jobScheduleManagerFactory.CreateInstance( dataSourceName );

			return jobScheduleManager.Delete( id );
		}

		public static JobSchedule Get( string dataSourceName, int id )
		{
			JobScheduleManager jobScheduleManager = ( JobScheduleManager ) _jobScheduleManagerFactory.CreateInstance( dataSourceName );

			return ( JobSchedule )jobScheduleManager.Get( id );
		}

        public static JobSchedule GetByName(string dataSourceName, string name)
        {
            JobScheduleManager jobScheduleManager = (JobScheduleManager)_jobScheduleManagerFactory.CreateInstance(dataSourceName);

            return (JobSchedule)jobScheduleManager.GetByName(name);
        }
		
		public static JobScheduleCollection GetAll( string dataSourceName  )
		{
			JobScheduleManager jobScheduleManager = ( JobScheduleManager ) _jobScheduleManagerFactory.CreateInstance( dataSourceName );

			return ( JobScheduleCollection )jobScheduleManager.GetAll( );
		}

		public static JobScheduleCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			JobScheduleManager jobScheduleManager = ( JobScheduleManager ) _jobScheduleManagerFactory.CreateInstance( dataSourceName );

			return ( JobScheduleCollection )jobScheduleManager.FindByCriteria( finderType, criteria );
		}

		public static DateTime NextScheduleDate( JobSchedule jobSchedule )
		{
			DateTime nextScheduleDate = new DateTime(2999, 12, 31);
			DateTime startDate = jobSchedule.StartDate;

			switch ( jobSchedule.Frequency )
			{
				case JobSchedule.ONCE_SCHEDULE:
				{
					return startDate;
				}
				case JobSchedule.DAY_SCHEDULE:
				{
					if (jobSchedule.RepeatNumber == 0)
						return nextScheduleDate;
					
					TimeSpan ts = DateTime.Today - startDate;
                    int days = (jobSchedule.RepeatNumber - ts.Days % jobSchedule.RepeatNumber) % jobSchedule.RepeatNumber;
                    if (ts.Days > 0)
                        startDate = DateTime.Today.AddDays(days);
                    return startDate;
				}
				case JobSchedule.WEEK_SCHEDULE:
				{
					if (jobSchedule.RepeatNumber == 0)
						return nextScheduleDate;
					if (jobSchedule.WeekDays.Length == 0)
						return nextScheduleDate;

                    startDate = startDate.AddDays(-(int)startDate.DayOfWeek);

                    TimeSpan ts = DateTime.Today - startDate;
                    if (ts.Days > 0)
                        startDate = DateTime.Today.AddDays(-ts.Days % (7 * jobSchedule.RepeatNumber));

                    nextScheduleDate = GetWeekScheduleDate(startDate, jobSchedule);
                    if (nextScheduleDate < DateTime.Today)
                        nextScheduleDate = nextScheduleDate.AddDays(7 * jobSchedule.RepeatNumber);
                    return nextScheduleDate;
				}
				case JobSchedule.MONTH_SCHEDULE:
				{
					if (jobSchedule.SelectedMonths.Length == 0)
						return nextScheduleDate;

                    if (startDate < DateTime.Today)
                        startDate = DateTime.Today;

                    nextScheduleDate = GetMonthScheduleDate(startDate, jobSchedule);
                    if (nextScheduleDate < DateTime.Today)
                    {
                        startDate = new DateTime(nextScheduleDate.Year, nextScheduleDate.Month, 1);
                        for (int i = 1; i <= 12; i++)
                        {
                            nextScheduleDate = GetMonthScheduleDate(startDate.AddMonths(i), jobSchedule);
                            if (nextScheduleDate >= DateTime.Today)
                                break;
                        }
                    }
                    return nextScheduleDate;
                }
				default:
					return nextScheduleDate;
			}
		}

        private static DateTime GetWeekScheduleDate(DateTime startDate, JobSchedule jobSchedule)
        {
            DateTime nextScheduleDate = new DateTime(2999, 12, 31);
            DateTime nextDate = new DateTime(1900, 1, 1);
            
            string[] weekDayList = jobSchedule.WeekDays.Split(',', ' ');

            DayOfWeek StartWeekDay = startDate.DayOfWeek;
            for (int i = 0; i < weekDayList.Length; i++)
            {
                switch (weekDayList[i].ToString().Trim())
                {
                    case "0":
                        nextDate = startDate.AddDays(startDate.DayOfWeek - DayOfWeek.Sunday);
                        break;
                    case "1":
                        if (startDate.DayOfWeek > DayOfWeek.Monday)
                            nextDate = startDate.AddDays(7 - (startDate.DayOfWeek - DayOfWeek.Monday));
                        else
                            nextDate = startDate.AddDays(DayOfWeek.Monday - startDate.DayOfWeek);
                        break;
                    case "2":
                        if (startDate.DayOfWeek > DayOfWeek.Tuesday)
                            nextDate = startDate.AddDays(7 - (startDate.DayOfWeek - DayOfWeek.Tuesday));
                        else
                            nextDate = startDate.AddDays(DayOfWeek.Tuesday - startDate.DayOfWeek);
                        break;
                    case "3":
                        if (startDate.DayOfWeek > DayOfWeek.Wednesday)
                            nextDate = startDate.AddDays(7 - (startDate.DayOfWeek - DayOfWeek.Wednesday));
                        else
                            nextDate = startDate.AddDays(DayOfWeek.Wednesday - startDate.DayOfWeek);
                        break;
                    case "4":
                        if (startDate.DayOfWeek > DayOfWeek.Thursday)
                            nextDate = startDate.AddDays(7 - (startDate.DayOfWeek - DayOfWeek.Thursday));
                        else
                            nextDate = startDate.AddDays(DayOfWeek.Thursday - startDate.DayOfWeek);
                        break;
                    case "5":
                        if (startDate.DayOfWeek > DayOfWeek.Friday)
                            nextDate = startDate.AddDays(7 - (startDate.DayOfWeek - DayOfWeek.Friday));
                        else
                            nextDate = startDate.AddDays(DayOfWeek.Friday - startDate.DayOfWeek);
                        break;
                    case "6":
                        if (startDate.DayOfWeek > DayOfWeek.Saturday)
                            nextDate = startDate.AddDays(7 - (startDate.DayOfWeek - DayOfWeek.Saturday));
                        else
                            nextDate = startDate.AddDays(DayOfWeek.Saturday - startDate.DayOfWeek);
                        break;
                }
                if (nextDate >= DateTime.Today)
                {
                    if (nextDate < nextScheduleDate)
                        nextScheduleDate = nextDate;
                    //break;
                }
            }
            if (nextDate < nextScheduleDate)
                nextScheduleDate = nextDate;
            return nextScheduleDate;
        }

		private static DateTime GetMonthScheduleDate( DateTime startDate, JobSchedule jobSchedule )
		{
			DateTime nextScheduleDate = new DateTime(2999, 12, 31);
			DateTime nextDate = new DateTime(1900, 1, 1);

			string[] monthList = jobSchedule.SelectedMonths.Split( ',', ' ' );
			for (int i = 0; i < monthList.Length; i++)
			{
				if (ConvertUtility.ConvertInt( monthList[i] ) < 1 || ConvertUtility.ConvertInt( monthList[i] ) > 12)
					continue;

				if (jobSchedule.ScheduleType == 0)
				{
                    nextDate = new DateTime(startDate.Year, ConvertUtility.ConvertInt(monthList[i]), jobSchedule.DayOfMonth);
				}
				else if (jobSchedule.ScheduleType == 1)
				{
					if (jobSchedule.WeekNumber == 0)
					{
						int lastDayOfMonth;
						switch ( ConvertUtility.ConvertInt( monthList[i] ) )
						{
							case 2:
								if (nextDate.Year % 4 == 0)
									lastDayOfMonth = 29;
								else
									lastDayOfMonth = 28;
								break;
							case 4:
							case 6:
							case 9:
							case 11:
								lastDayOfMonth = 30;
								break;
							default:
								lastDayOfMonth = 31;
								break;
						}
                        nextDate = new DateTime(startDate.Year, ConvertUtility.ConvertInt(monthList[i]), lastDayOfMonth);
					}
					else
					{
                        int firstWeekDayOfMonth = (new DateTime(startDate.Year, ConvertUtility.ConvertInt(monthList[i]), 1)).DayOfWeek - DayOfWeek.Sunday;
						int dayOfMonth;

						if (firstWeekDayOfMonth > ConvertUtility.ConvertInt(jobSchedule.WeekDays))
							dayOfMonth = jobSchedule.WeekNumber * 7 - (firstWeekDayOfMonth - ConvertUtility.ConvertInt(jobSchedule.WeekDays)) + 1;
						else
							dayOfMonth = (jobSchedule.WeekNumber - 1) * 7 - (firstWeekDayOfMonth - ConvertUtility.ConvertInt(jobSchedule.WeekDays)) + 1;
                        nextDate = new DateTime(startDate.Year, ConvertUtility.ConvertInt(monthList[i]), dayOfMonth);
					}
				}

                if (nextDate >= DateTime.Today)
                {
                    if (nextDate < nextScheduleDate)
                        nextScheduleDate = nextDate;
                    //break;
                }
			}
            if (nextDate < nextScheduleDate)
                nextScheduleDate = nextDate;
            return nextScheduleDate;
		}
		#endregion

	}
}
