#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class AffiliateUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly AffiliateManagerFactory _affiliateManagerFactory = 
			( AffiliateManagerFactory ) AffiliateManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static AffiliateUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( AffiliateUtility ).FullName);
		}

		private AffiliateUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Affiliate CreateObject( )
		{
			AffiliateManager affiliateManager = ( AffiliateManager ) _affiliateManagerFactory.CreateInstance( );

			return ( Affiliate )affiliateManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, Affiliate affiliate )
		{
			AffiliateManager affiliateManager = ( AffiliateManager ) _affiliateManagerFactory.CreateInstance( dataSourceName );

			return affiliateManager.Create( affiliate );
		}

		public static bool Update( string dataSourceName, Affiliate affiliate )
		{
			AffiliateManager affiliateManager = ( AffiliateManager ) _affiliateManagerFactory.CreateInstance( dataSourceName );

			return affiliateManager.Update( affiliate );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			AffiliateManager affiliateManager = ( AffiliateManager ) _affiliateManagerFactory.CreateInstance( dataSourceName );

			return affiliateManager.Delete( id );
		}

		public static Affiliate Get( string dataSourceName, int id )
		{
			AffiliateManager affiliateManager = ( AffiliateManager ) _affiliateManagerFactory.CreateInstance( dataSourceName );

			return ( Affiliate )affiliateManager.Get( id );
		}

		public static AffiliateCollection GetAll( string dataSourceName  )
		{
			AffiliateManager affiliateManager = ( AffiliateManager ) _affiliateManagerFactory.CreateInstance( dataSourceName );

			return ( AffiliateCollection )affiliateManager.GetAll( );
		}

		public static AffiliateCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			AffiliateManager affiliateManager = ( AffiliateManager ) _affiliateManagerFactory.CreateInstance( dataSourceName );

			return ( AffiliateCollection )affiliateManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
