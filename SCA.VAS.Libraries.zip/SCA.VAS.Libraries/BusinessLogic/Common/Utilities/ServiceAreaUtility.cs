#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class ServiceAreaUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly ServiceAreaManagerFactory _serviceAreaManagerFactory = 
			( ServiceAreaManagerFactory ) ServiceAreaManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static ServiceAreaUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ServiceAreaUtility ).FullName);
		}

		private ServiceAreaUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static ServiceArea CreateObject( )
		{
			ServiceAreaManager serviceAreaManager = ( ServiceAreaManager ) _serviceAreaManagerFactory.CreateInstance( );

			return ( ServiceArea )serviceAreaManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, ServiceArea serviceArea )
		{
			ServiceAreaManager serviceAreaManager = ( ServiceAreaManager ) _serviceAreaManagerFactory.CreateInstance( dataSourceName );

			return serviceAreaManager.Create( serviceArea );
		}

		public static bool Update( string dataSourceName, ServiceArea serviceArea )
		{
			ServiceAreaManager serviceAreaManager = ( ServiceAreaManager ) _serviceAreaManagerFactory.CreateInstance( dataSourceName );

			return serviceAreaManager.Update( serviceArea );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			ServiceAreaManager serviceAreaManager = ( ServiceAreaManager ) _serviceAreaManagerFactory.CreateInstance( dataSourceName );

			return serviceAreaManager.Delete( id );
		}

		public static ServiceArea Get( string dataSourceName, int id )
		{
			ServiceAreaManager serviceAreaManager = ( ServiceAreaManager ) _serviceAreaManagerFactory.CreateInstance( dataSourceName );

			return ( ServiceArea )serviceAreaManager.Get( id );
		}

		public static ServiceAreaCollection GetAll( string dataSourceName  )
		{
			ServiceAreaManager serviceAreaManager = ( ServiceAreaManager ) _serviceAreaManagerFactory.CreateInstance( dataSourceName );

			return ( ServiceAreaCollection )serviceAreaManager.GetAll( );
		}

		public static ServiceAreaCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			ServiceAreaManager serviceAreaManager = ( ServiceAreaManager ) _serviceAreaManagerFactory.CreateInstance( dataSourceName );

			return ( ServiceAreaCollection )serviceAreaManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
