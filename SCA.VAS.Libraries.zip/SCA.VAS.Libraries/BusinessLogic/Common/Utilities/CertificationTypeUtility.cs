#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class CertificationTypeUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly CertificationTypeManagerFactory _certificationTypeManagerFactory = 
			( CertificationTypeManagerFactory ) CertificationTypeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static CertificationTypeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CertificationTypeUtility ).FullName);
		}

		private CertificationTypeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static CertificationType CreateObject( )
		{
			CertificationTypeManager certificationTypeManager = ( CertificationTypeManager ) _certificationTypeManagerFactory.CreateInstance( );

			return ( CertificationType )certificationTypeManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, CertificationType certificationType )
		{
			CertificationTypeManager certificationTypeManager = ( CertificationTypeManager ) _certificationTypeManagerFactory.CreateInstance( dataSourceName );

			return certificationTypeManager.Create( certificationType );
		}

		public static bool Update( string dataSourceName, CertificationType certificationType )
		{
			CertificationTypeManager certificationTypeManager = ( CertificationTypeManager ) _certificationTypeManagerFactory.CreateInstance( dataSourceName );

			return certificationTypeManager.Update( certificationType );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			CertificationTypeManager certificationTypeManager = ( CertificationTypeManager ) _certificationTypeManagerFactory.CreateInstance( dataSourceName );

			return certificationTypeManager.Delete( id );
		}

		public static CertificationType Get( string dataSourceName, int id )
		{
			CertificationTypeManager certificationTypeManager = ( CertificationTypeManager ) _certificationTypeManagerFactory.CreateInstance( dataSourceName );

			return ( CertificationType )certificationTypeManager.Get( id );
		}

		public static CertificationTypeCollection GetAll( string dataSourceName  )
		{
			CertificationTypeManager certificationTypeManager = ( CertificationTypeManager ) _certificationTypeManagerFactory.CreateInstance( dataSourceName );

			return ( CertificationTypeCollection )certificationTypeManager.GetAll( );
		}

		public static CertificationTypeCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			CertificationTypeManager certificationTypeManager = ( CertificationTypeManager ) _certificationTypeManagerFactory.CreateInstance( dataSourceName );

			return ( CertificationTypeCollection )certificationTypeManager.FindByCriteria( finderType, criteria );
		}
		
		public static DataSet FindDataSetByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			CertificationTypeManager certificationTypeManager = ( CertificationTypeManager ) _certificationTypeManagerFactory.CreateInstance( dataSourceName );

			return certificationTypeManager.FindDataSetByCriteria( finderType, criteria );
		}
		#endregion

	}
}
