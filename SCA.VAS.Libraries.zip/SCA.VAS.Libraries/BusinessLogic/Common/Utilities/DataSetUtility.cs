#region	Copyright 2005 by AECsoft USA Inc.
/*
************************************************************************
Copyright 2005 by AECsoft USA Inc.

All	rights reserved. No	portion	of this	software or	its	content	may	be
reproduced in any form or by any means,	without	the	express	written
permission of the copyright	owner.
************************************************************************
*/
#endregion Copyright

#region	References
using System;
using System.Xml;
using System.Xml.Serialization;
using System.Text;
using System.Data;
using System.IO;
#endregion 

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	#region	Header
	///	<summary>
	///	Summary	description	for	DataSetUtility
	///	</summary>
	#endregion

	public class DataSetUtility
	{

		#region	Constants
		#endregion

		#region	Constructors
		static DataSetUtility()
		{
		}

		///	<summary>
		///	default	constructor	
		///	</summary>
		public DataSetUtility()
		{
		}
		#endregion Constructors

		#region	Properties
		#endregion
	
		#region	Public Methods
		public static void Transform(DataSet dataSet, string filename, char delimiter, string qualifier, bool includeColumnName)
		{
			foreach (DataTable dtb in dataSet.Tables)
			{
				ParseDataTable(dtb, filename, delimiter, qualifier, includeColumnName);
			}
		}
		#endregion

		#region	Private Methods
		private static void ParseDataTable(DataTable dtb, string strFullFileName, char delimiter, string qualifier, bool includeColumnName)
		{
			StreamWriter objStream = new StreamWriter(strFullFileName);
			int intColCount, intCntr = 0;

			// Count total number of columns in the data table.
			intColCount = dtb.Columns.Count;

			// Continue if column headers are required.
			if ( includeColumnName )
			{
				// Loop through columns of data table to export name of each column.
				foreach (DataColumn dcl in dtb.Columns)
				{
					// Write the column name to .csv file.
					objStream.Write(dcl.ColumnName);

					// Don't insert delimiter after last column.
					if (intCntr < intColCount - 1)
						objStream.Write(delimiter);

					intCntr += 1;
				}

				// Insert line terminator string.
				objStream.Write(objStream.NewLine);
			}

			// Iterate over each data row to export all values in the data table.
			foreach (DataRow drw in dtb.Rows)
			{
				intCntr = 0;

				foreach (Object oItem in drw.ItemArray)
				{
					objStream.Write(qualifier + oItem + qualifier);

					// Don't insert delimiter after last column.
					if (intCntr < intColCount - 1)
						objStream.Write(delimiter);

					intCntr += 1;
				}

				// Insert line terminator string.
				objStream.Write(objStream.NewLine);
			}

			objStream.Close();
		}
		#endregion 

	} 
}
