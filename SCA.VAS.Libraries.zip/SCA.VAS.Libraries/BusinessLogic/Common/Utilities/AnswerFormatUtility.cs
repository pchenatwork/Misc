#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class AnswerFormatUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly AnswerFormatManagerFactory _answerFormatManagerFactory = 
			( AnswerFormatManagerFactory ) AnswerFormatManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static AnswerFormatUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( AnswerFormatUtility ).FullName);
		}

		private AnswerFormatUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static AnswerFormat CreateObject( )
		{
			AnswerFormatManager answerFormatManager = ( AnswerFormatManager ) _answerFormatManagerFactory.CreateInstance( );

			return ( AnswerFormat )answerFormatManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, AnswerFormat answerFormat )
		{
			AnswerFormatManager answerFormatManager = ( AnswerFormatManager ) _answerFormatManagerFactory.CreateInstance( dataSourceName );

			return answerFormatManager.Create( answerFormat );
		}

		public static bool Update( string dataSourceName, AnswerFormat answerFormat )
		{
			AnswerFormatManager answerFormatManager = ( AnswerFormatManager ) _answerFormatManagerFactory.CreateInstance( dataSourceName );

			return answerFormatManager.Update( answerFormat );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			AnswerFormatManager answerFormatManager = ( AnswerFormatManager ) _answerFormatManagerFactory.CreateInstance( dataSourceName );

			return answerFormatManager.Delete( id );
		}

		public static AnswerFormat Get( string dataSourceName, int id )
		{
			AnswerFormatManager answerFormatManager = ( AnswerFormatManager ) _answerFormatManagerFactory.CreateInstance( dataSourceName );

			return ( AnswerFormat )answerFormatManager.Get( id );
		}

		public static AnswerFormatCollection GetAll( string dataSourceName  )
		{
			AnswerFormatManager answerFormatManager = ( AnswerFormatManager ) _answerFormatManagerFactory.CreateInstance( dataSourceName );

			return ( AnswerFormatCollection )answerFormatManager.GetAll( );
		}

		public static AnswerFormatCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			AnswerFormatManager answerFormatManager = ( AnswerFormatManager ) _answerFormatManagerFactory.CreateInstance( dataSourceName );

			return ( AnswerFormatCollection )answerFormatManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
