#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class CsiCodeUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly CsiCodeManagerFactory _csiCodeManagerFactory = 
			( CsiCodeManagerFactory ) CsiCodeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static CsiCodeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CsiCodeUtility ).FullName);
		}

		private CsiCodeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static CsiCode CreateObject( )
		{
			CsiCodeManager csiCodeManager = ( CsiCodeManager ) _csiCodeManagerFactory.CreateInstance( );

			return ( CsiCode )csiCodeManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, CsiCode csiCode )
		{
			CsiCodeManager csiCodeManager = ( CsiCodeManager ) _csiCodeManagerFactory.CreateInstance( dataSourceName );

			return csiCodeManager.Create( csiCode );
		}

		public static bool Update( string dataSourceName, CsiCode csiCode )
		{
			CsiCodeManager csiCodeManager = ( CsiCodeManager ) _csiCodeManagerFactory.CreateInstance( dataSourceName );

			return csiCodeManager.Update( csiCode );
		}

        public static bool UpdateCollection(string dataSourceName, CsiCodeCollection collection)
        {
            CsiCodeManager csiCodeManager = (CsiCodeManager)_csiCodeManagerFactory.CreateInstance(dataSourceName);

            return csiCodeManager.UpdateCollection(collection);
        }

		public static bool Delete( string dataSourceName, int id )
		{
			CsiCodeManager csiCodeManager = ( CsiCodeManager ) _csiCodeManagerFactory.CreateInstance( dataSourceName );

			return csiCodeManager.Delete( id );
		}

		public static CsiCode Get( string dataSourceName, int id )
		{
			CsiCodeManager csiCodeManager = ( CsiCodeManager ) _csiCodeManagerFactory.CreateInstance( dataSourceName );

			return ( CsiCode )csiCodeManager.Get( id );
		}
		
		public static CsiCode GetByName( string dataSourceName, string name )
		{
			CsiCodeManager csiCodeManager = ( CsiCodeManager ) _csiCodeManagerFactory.CreateInstance( dataSourceName );

			return ( CsiCode )csiCodeManager.GetByName( name );
		}

		public static CsiCodeCollection GetAll( string dataSourceName  )
		{
			CsiCodeManager csiCodeManager = ( CsiCodeManager ) _csiCodeManagerFactory.CreateInstance( dataSourceName );

			return ( CsiCodeCollection )csiCodeManager.GetAll( );
		}

		public static CsiCodeCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			CsiCodeManager csiCodeManager = ( CsiCodeManager ) _csiCodeManagerFactory.CreateInstance( dataSourceName );

			return ( CsiCodeCollection )csiCodeManager.FindByCriteria( finderType, criteria );
		}
        
        public static void GetAllCsiCodes(CsiCodeCollection csiCodes, CsiCodeCollection allCsiCodes)
        {
            if (csiCodes == null)
                return;

            foreach (CsiCode c in csiCodes)
            {
                allCsiCodes.Add(c);
                if (c.SubCsiCodes != null)
                {
                    GetAllCsiCodes(c.SubCsiCodes, allCsiCodes);
                }
            }
        }
		#endregion

	}
}
