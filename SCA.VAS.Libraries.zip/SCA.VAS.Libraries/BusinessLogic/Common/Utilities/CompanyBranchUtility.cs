#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class CompanyBranchUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;
        
        private static readonly CompanyBranchManagerFactory _companyBranchManagerFactory = 
			( CompanyBranchManagerFactory ) CompanyBranchManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static CompanyBranchUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CompanyBranchUtility ).FullName);
		}

		private CompanyBranchUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static CompanyBranch CreateObject( )
		{
			CompanyBranchManager companyBranchManager = ( CompanyBranchManager ) _companyBranchManagerFactory.CreateInstance( );

			return ( CompanyBranch )companyBranchManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, CompanyBranch companyBranch )
		{
			CompanyBranchManager companyBranchManager = ( CompanyBranchManager ) _companyBranchManagerFactory.CreateInstance( dataSourceName );

			return companyBranchManager.Create( companyBranch );
		}

		public static bool Update( string dataSourceName, CompanyBranch companyBranch )
		{
			CompanyBranchManager companyBranchManager = ( CompanyBranchManager ) _companyBranchManagerFactory.CreateInstance( dataSourceName );

			return companyBranchManager.Update( companyBranch );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			CompanyBranchManager companyBranchManager = ( CompanyBranchManager ) _companyBranchManagerFactory.CreateInstance( dataSourceName );

			return companyBranchManager.Delete( id );
		}

		public static CompanyBranch Get( string dataSourceName, int id )
		{
			CompanyBranchManager companyBranchManager = ( CompanyBranchManager ) _companyBranchManagerFactory.CreateInstance( dataSourceName );

			return ( CompanyBranch )companyBranchManager.Get( id );
		}
		
		public static CompanyBranch GetByName( string dataSourceName, string name, int parentId )
		{
			CompanyBranchManager companyBranchManager = ( CompanyBranchManager ) _companyBranchManagerFactory.CreateInstance( dataSourceName );

            return (CompanyBranch)companyBranchManager.GetByName(name, parentId);
		}

		public static CompanyBranchCollection GetAll( string dataSourceName  )
		{
			CompanyBranchManager companyBranchManager = ( CompanyBranchManager ) _companyBranchManagerFactory.CreateInstance( dataSourceName );

			return ( CompanyBranchCollection )companyBranchManager.GetAll( );
		}

		public static CompanyBranchCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			CompanyBranchManager companyBranchManager = ( CompanyBranchManager ) _companyBranchManagerFactory.CreateInstance( dataSourceName );

            return (CompanyBranchCollection)companyBranchManager.FindByCriteria(finderType, criteria);
		}

        public static DataSet FindDataSetByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            CompanyBranchManager companyBranchManager = (CompanyBranchManager)_companyBranchManagerFactory.CreateInstance(dataSourceName);

            return companyBranchManager.FindDataSetByCriteria(finderType, criteria);
        }
		#endregion
	}
}
