using System;
using System.Collections;
using System.Data;
using System.Data.OleDb;

using log4net;

using SCA.VAS.Common.Utilities;

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Summary description for ExcelUtility.
	/// </summary>
	public class ExcelUtility
	{
		private static ILog _logger = null;

		static ExcelUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ExcelUtility ).FullName);
		} 

		public ExcelUtility()
		{
		}

		public static ArrayList WorksheetNames( string fileName )
		{
			string methodName = "WorksheetNames";
			if ( _logger.IsDebugEnabled )
			{
				LoggingUtility.logMethodEntry( _logger, methodName );
			}
			ArrayList sheetNames = new ArrayList();
			OleDbConnection connection = null;
			try
			{
				connection = DbUtility.GetOleDbConnection(fileName);

				DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, 
					null);

				// List the table name from each row in the schema table.
				for (int i = 0; i < schemaTable.Rows.Count; i++) 
				{
					sheetNames.Add(schemaTable.Rows[i].ItemArray[2].ToString());
				}
			}
			catch ( System.Exception e )
			{
				_logger.Error( methodName, e );
				return null;
			}
			finally
			{
				DbUtility.Close( connection );
			}
			return sheetNames;
		}

		public static DataSet GetWorksheet( string fileName, string sheetName )
		/* VERACODE remediation: use parameterized query when any portion of the query is passed in/untrusted */
		{
			DataSet ret = null;

			string methodName = "GetWorksheet";
			if ( _logger.IsDebugEnabled )
			{
				LoggingUtility.logMethodEntry( _logger, methodName );
			}

			try
			{
				using(OleDbConnection connection = DbUtility.GetOleDbConnection(fileName))
				using(OleDbCommand command = connection.CreateCommand())
				{
					command.CommandText = "select * from ?"; // "select * from [" + sheetName + "]";
					command.Parameters.Add("tablename", OleDbType.VarWChar, 50);
					command.Parameters[0].Value = fileName;
					command.CommandType = CommandType.Text;
					
					command.Prepare();

					using(OleDbDataAdapter da = new OleDbDataAdapter(command))
					using(DataSet ds = new DataSet())
					{
						da.Fill(ds);
						ret = ds;
					}
				}
			}
			catch ( System.Exception e )
			{
				_logger.Error( methodName, e );
			}

			return ret;
		}
	}
}
