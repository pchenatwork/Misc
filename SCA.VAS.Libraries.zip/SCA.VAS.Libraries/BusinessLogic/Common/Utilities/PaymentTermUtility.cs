#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class PaymentTermUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PaymentTermManagerFactory _paymentTermManagerFactory = 
			( PaymentTermManagerFactory ) PaymentTermManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PaymentTermUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PaymentTermUtility ).FullName);
		}

		private PaymentTermUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PaymentTerm CreateObject( )
		{
			PaymentTermManager paymentTermManager = ( PaymentTermManager ) _paymentTermManagerFactory.CreateInstance( );

			return ( PaymentTerm )paymentTermManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, PaymentTerm paymentTerm )
		{
			PaymentTermManager paymentTermManager = ( PaymentTermManager ) _paymentTermManagerFactory.CreateInstance( dataSourceName );

			return paymentTermManager.Create( paymentTerm );
		}

		public static bool Update( string dataSourceName, PaymentTerm paymentTerm )
		{
			PaymentTermManager paymentTermManager = ( PaymentTermManager ) _paymentTermManagerFactory.CreateInstance( dataSourceName );

			return paymentTermManager.Update( paymentTerm );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			PaymentTermManager paymentTermManager = ( PaymentTermManager ) _paymentTermManagerFactory.CreateInstance( dataSourceName );

			return paymentTermManager.Delete( id );
		}

		public static PaymentTerm Get( string dataSourceName, int id )
		{
			PaymentTermManager paymentTermManager = ( PaymentTermManager ) _paymentTermManagerFactory.CreateInstance( dataSourceName );

			return ( PaymentTerm )paymentTermManager.Get( id );
		}

		public static PaymentTermCollection GetAll( string dataSourceName  )
		{
			PaymentTermManager paymentTermManager = ( PaymentTermManager ) _paymentTermManagerFactory.CreateInstance( dataSourceName );

			return ( PaymentTermCollection )paymentTermManager.GetAll( );
		}

        public static PaymentTermCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            PaymentTermManager paymentTermManager = (PaymentTermManager)_paymentTermManagerFactory.CreateInstance(dataSourceName);

            return (PaymentTermCollection)paymentTermManager.FindByCriteria(finderType, criteria);
        }
		#endregion

	}
}
