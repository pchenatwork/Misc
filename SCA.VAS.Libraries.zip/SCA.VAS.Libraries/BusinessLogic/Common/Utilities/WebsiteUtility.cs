#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class WebsiteUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly WebsiteManagerFactory _websiteManagerFactory = 
			( WebsiteManagerFactory ) WebsiteManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static WebsiteUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( WebsiteUtility ).FullName);
		}

		private WebsiteUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Website CreateObject( )
		{
			WebsiteManager websiteManager = ( WebsiteManager ) _websiteManagerFactory.CreateInstance( );

			return ( Website )websiteManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, Website website )
		{
			WebsiteManager websiteManager = ( WebsiteManager ) _websiteManagerFactory.CreateInstance( dataSourceName );

			return websiteManager.Create( website );
		}

		public static bool Update( string dataSourceName, Website website )
		{
			WebsiteManager websiteManager = ( WebsiteManager ) _websiteManagerFactory.CreateInstance( dataSourceName );

			return websiteManager.Update( website );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			WebsiteManager websiteManager = ( WebsiteManager ) _websiteManagerFactory.CreateInstance( dataSourceName );

			return websiteManager.Delete( id );
		}

		public static Website Get( string dataSourceName, int id )
		{
			WebsiteManager websiteManager = ( WebsiteManager ) _websiteManagerFactory.CreateInstance( dataSourceName );

			return ( Website )websiteManager.Get( id );
		}

        public static Website GetByCode(string dataSourceName, string code)
        {
            WebsiteManager websiteManager = (WebsiteManager)_websiteManagerFactory.CreateInstance(dataSourceName);

            return (Website)websiteManager.GetByCode(code);
        }

		public static WebsiteCollection GetAll( string dataSourceName  )
		{
			WebsiteManager websiteManager = ( WebsiteManager ) _websiteManagerFactory.CreateInstance( dataSourceName );

			return ( WebsiteCollection )websiteManager.GetAll( );
		}

		#endregion

	}
}
