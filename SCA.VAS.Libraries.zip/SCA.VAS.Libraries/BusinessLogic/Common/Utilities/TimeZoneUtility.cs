#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

using TimeZone = SCA.VAS.ValueObjects.Common.TimeZone;

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class TimeZoneUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly TimeZoneManagerFactory _timeZoneManagerFactory = 
			( TimeZoneManagerFactory ) TimeZoneManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static TimeZoneUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( TimeZoneUtility ).FullName);
		}

		private TimeZoneUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static TimeZone CreateObject( )
		{
			TimeZoneManager timeZoneManager = ( TimeZoneManager ) _timeZoneManagerFactory.CreateInstance( );

			return ( TimeZone )timeZoneManager.CreateObject( );
		}
	
		public static bool Create( string dataSourceName, TimeZone timeZone )
		{
			TimeZoneManager timeZoneManager = ( TimeZoneManager ) _timeZoneManagerFactory.CreateInstance( dataSourceName );

			return timeZoneManager.Create( timeZone );
		}

		public static bool Update( string dataSourceName, TimeZone timeZone )
		{
			TimeZoneManager timeZoneManager = ( TimeZoneManager ) _timeZoneManagerFactory.CreateInstance( dataSourceName );

			return timeZoneManager.Update( timeZone );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			TimeZoneManager timeZoneManager = ( TimeZoneManager ) _timeZoneManagerFactory.CreateInstance( dataSourceName );

			return timeZoneManager.Delete( id );
		}

		public static TimeZone Get( string dataSourceName, int id )
		{
			TimeZoneManager timeZoneManager = ( TimeZoneManager ) _timeZoneManagerFactory.CreateInstance( dataSourceName );

			return ( TimeZone )timeZoneManager.Get( id );
		}

        public static TimeZone GetByName(string dataSourceName, string name)
        {
            TimeZoneManager timeZoneManager = (TimeZoneManager)_timeZoneManagerFactory.CreateInstance(dataSourceName);

            return (TimeZone)timeZoneManager.GetByName(name);
        }

        public static TimeZoneCollection GetAll(string dataSourceName)
		{
			TimeZoneManager timeZoneManager = ( TimeZoneManager ) _timeZoneManagerFactory.CreateInstance( dataSourceName );

			return ( TimeZoneCollection )timeZoneManager.GetAll( );
		}
		#endregion

	}
}
