#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class BusinessUnitUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BusinessUnitManagerFactory _businessUnitManagerFactory = 
			( BusinessUnitManagerFactory ) BusinessUnitManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BusinessUnitUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BusinessUnitUtility ).FullName);
		}

		private BusinessUnitUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static BusinessUnit CreateObject( )
		{
			BusinessUnitManager businessUnitManager = ( BusinessUnitManager ) _businessUnitManagerFactory.CreateInstance( );

			return ( BusinessUnit )businessUnitManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, BusinessUnit businessUnit )
		{
			BusinessUnitManager businessUnitManager = ( BusinessUnitManager ) _businessUnitManagerFactory.CreateInstance( dataSourceName );

			return businessUnitManager.Create( businessUnit );
		}

		public static bool Update( string dataSourceName, BusinessUnit businessUnit )
		{
			BusinessUnitManager businessUnitManager = ( BusinessUnitManager ) _businessUnitManagerFactory.CreateInstance( dataSourceName );

			return businessUnitManager.Update( businessUnit );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			BusinessUnitManager businessUnitManager = ( BusinessUnitManager ) _businessUnitManagerFactory.CreateInstance( dataSourceName );

			return businessUnitManager.Delete( id );
		}

		public static BusinessUnit Get( string dataSourceName, int id )
		{
			BusinessUnitManager businessUnitManager = ( BusinessUnitManager ) _businessUnitManagerFactory.CreateInstance( dataSourceName );

			return ( BusinessUnit )businessUnitManager.Get( id );
		}

		public static BusinessUnit GetByName( string dataSourceName, string name )
		{
			BusinessUnitManager businessUnitManager = ( BusinessUnitManager ) _businessUnitManagerFactory.CreateInstance( dataSourceName );

			return ( BusinessUnit )businessUnitManager.GetByName( name );
		}

		public static BusinessUnitCollection GetAll( string dataSourceName  )
		{
			BusinessUnitManager businessUnitManager = ( BusinessUnitManager ) _businessUnitManagerFactory.CreateInstance( dataSourceName );

			return ( BusinessUnitCollection )businessUnitManager.GetAll( );
		}

        public static BusinessUnitCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            BusinessUnitManager businessUnitManager = (BusinessUnitManager)_businessUnitManagerFactory.CreateInstance(dataSourceName);

            return (BusinessUnitCollection)businessUnitManager.FindByCriteria(finderType, criteria);
        }
		#endregion

	}
}
