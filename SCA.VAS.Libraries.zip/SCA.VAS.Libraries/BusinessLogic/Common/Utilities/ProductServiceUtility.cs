#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class ProductServiceUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly ProductServiceManagerFactory _productServiceManagerFactory = 
			( ProductServiceManagerFactory ) ProductServiceManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static ProductServiceUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ProductServiceUtility ).FullName );
		}

		private ProductServiceUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static ProductService CreateObject( )
		{
			ProductServiceManager productServiceManager = ( ProductServiceManager ) _productServiceManagerFactory.CreateInstance( );

			return ( ProductService )productServiceManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, ProductService productService )
		{
			ProductServiceManager productServiceManager = ( ProductServiceManager ) _productServiceManagerFactory.CreateInstance( dataSourceName );

			return productServiceManager.Create( productService );
		}

		public static bool Update( string dataSourceName, ProductService productService )
		{
			ProductServiceManager productServiceManager = ( ProductServiceManager ) _productServiceManagerFactory.CreateInstance( dataSourceName );

			return productServiceManager.Update( productService );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			ProductServiceManager productServiceManager = ( ProductServiceManager ) _productServiceManagerFactory.CreateInstance( dataSourceName );

			return productServiceManager.Delete( id );
		}

		public static ProductService Get( string dataSourceName, int id )
		{
			ProductServiceManager productServiceManager = ( ProductServiceManager ) _productServiceManagerFactory.CreateInstance( dataSourceName );

			return ( ProductService )productServiceManager.Get( id );
		}

		public static ProductServiceCollection GetAll( string dataSourceName  )
		{
			ProductServiceManager productServiceManager = ( ProductServiceManager ) _productServiceManagerFactory.CreateInstance( dataSourceName );

			return ( ProductServiceCollection )productServiceManager.GetAll( );
		}

		public static ProductServiceCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			ProductServiceManager productServiceManager = ( ProductServiceManager ) _productServiceManagerFactory.CreateInstance( dataSourceName );

			return ( ProductServiceCollection )productServiceManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
