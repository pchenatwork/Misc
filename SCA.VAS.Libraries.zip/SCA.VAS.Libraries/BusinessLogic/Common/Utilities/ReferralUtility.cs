#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class ReferralUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly ReferralManagerFactory _referralManagerFactory = 
			( ReferralManagerFactory ) ReferralManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static ReferralUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ReferralUtility ).FullName);
		}

		private ReferralUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Referral CreateObject( )
		{
			ReferralManager referralManager = ( ReferralManager ) _referralManagerFactory.CreateInstance( );

			return ( Referral )referralManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, Referral referral )
		{
			ReferralManager referralManager = ( ReferralManager ) _referralManagerFactory.CreateInstance( dataSourceName );

			return referralManager.Create( referral );
		}

		public static bool Update( string dataSourceName, Referral referral )
		{
			ReferralManager referralManager = ( ReferralManager ) _referralManagerFactory.CreateInstance( dataSourceName );

			return referralManager.Update( referral );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			ReferralManager referralManager = ( ReferralManager ) _referralManagerFactory.CreateInstance( dataSourceName );

			return referralManager.Delete( id );
		}

		public static Referral Get( string dataSourceName, int id )
		{
			ReferralManager referralManager = ( ReferralManager ) _referralManagerFactory.CreateInstance( dataSourceName );

			return ( Referral )referralManager.Get( id );
		}

		public static ReferralCollection GetAll( string dataSourceName  )
		{
			ReferralManager referralManager = ( ReferralManager ) _referralManagerFactory.CreateInstance( dataSourceName );

			return ( ReferralCollection )referralManager.GetAll( );
		}

		#endregion

	}
}
