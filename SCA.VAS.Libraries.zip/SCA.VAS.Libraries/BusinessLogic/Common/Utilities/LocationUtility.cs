
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class LocationUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly LocationManagerFactory _locationManagerFactory = 
			( LocationManagerFactory ) LocationManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static LocationUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( LocationUtility ).FullName);
		}

		private LocationUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Location CreateObject( )
		{
			LocationManager locationManager = ( LocationManager ) _locationManagerFactory.CreateInstance( );

			return ( Location )locationManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, Location location )
		{
			LocationManager locationManager = ( LocationManager ) _locationManagerFactory.CreateInstance( dataSourceName );

			return locationManager.Create( location );
		}
		
		public static bool Update( string dataSourceName, Location location )
		{
			LocationManager locationManager = ( LocationManager ) _locationManagerFactory.CreateInstance( dataSourceName );

			return locationManager.Update( location );
		}
		
		public static bool Delete( string dataSourceName, int id )
		{
			LocationManager locationManager = ( LocationManager ) _locationManagerFactory.CreateInstance( dataSourceName );

			return locationManager.Delete( id );
		}

		public static Location Get( string dataSourceName, int id )
		{
			LocationManager locationManager = ( LocationManager ) _locationManagerFactory.CreateInstance( dataSourceName );

			return ( Location )locationManager.Get( id );
		}

        public static LocationCollection GetAll(string dataSourceName)
        {
            LocationManager locationManager = (LocationManager)_locationManagerFactory.CreateInstance(dataSourceName);

            return (LocationCollection)locationManager.GetAll();
        }

		public static LocationCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			LocationManager locationManager = ( LocationManager ) _locationManagerFactory.CreateInstance( dataSourceName );

			return ( LocationCollection )locationManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}