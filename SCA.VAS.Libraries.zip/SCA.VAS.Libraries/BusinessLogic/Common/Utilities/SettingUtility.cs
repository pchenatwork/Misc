#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class SettingUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly SettingManagerFactory _settingManagerFactory = 
			( SettingManagerFactory ) SettingManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static SettingUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( SettingUtility ).FullName);
		}

		private SettingUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Setting CreateObject( )
		{
			SettingManager settingManager = ( SettingManager ) _settingManagerFactory.CreateInstance( );

			return ( Setting )settingManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, Setting setting )
		{
			SettingManager settingManager = ( SettingManager ) _settingManagerFactory.CreateInstance( dataSourceName );

			return settingManager.Create( setting );
		}

		public static bool Update( string dataSourceName, Setting setting )
		{
			SettingManager settingManager = ( SettingManager ) _settingManagerFactory.CreateInstance( dataSourceName );

			return settingManager.Update( setting );
		}

        public static SettingCollection Import(string dataSourceName, string type, string xml)
        {
            SettingManager settingManager = (SettingManager)_settingManagerFactory.CreateInstance(dataSourceName);

            return (SettingCollection)settingManager.Import(type, xml);
        }

		public static bool Delete( string dataSourceName, string name )
		{
			SettingManager settingManager = ( SettingManager ) _settingManagerFactory.CreateInstance( dataSourceName );

			return settingManager.Delete( name );
		}

		public static Setting GetByName( string dataSourceName, string name )
		{
			SettingManager settingManager = ( SettingManager ) _settingManagerFactory.CreateInstance( dataSourceName );

			return ( Setting )settingManager.GetByName( name );
		}
		
		public static string GetValueByName( string dataSourceName, string name )
		{
			SettingManager settingManager = ( SettingManager ) _settingManagerFactory.CreateInstance( dataSourceName );

			Setting setting = ( Setting )settingManager.GetByName( name );
			if (setting != null)
				return setting.Value;
			else
				return string.Empty;
		}

		public static SettingCollection GetAll( string dataSourceName  )
		{
			SettingManager settingManager = ( SettingManager ) _settingManagerFactory.CreateInstance( dataSourceName );

			return ( SettingCollection )settingManager.GetAll( );
		}

		public static SettingCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			SettingManager settingManager = ( SettingManager ) _settingManagerFactory.CreateInstance( dataSourceName );

			return ( SettingCollection )settingManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
