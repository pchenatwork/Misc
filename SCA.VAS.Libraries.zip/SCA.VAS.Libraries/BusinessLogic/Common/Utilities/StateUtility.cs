#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class StateUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly StateManagerFactory _stateManagerFactory = 
			( StateManagerFactory ) StateManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static StateUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( StateUtility ).FullName);
		}

		private StateUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static State CreateObject( )
		{
			StateManager stateManager = ( StateManager ) _stateManagerFactory.CreateInstance( );

			return ( State )stateManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, State state )
		{
			StateManager stateManager = ( StateManager ) _stateManagerFactory.CreateInstance( dataSourceName );

			return stateManager.Create( state );
		}

		public static bool Update( string dataSourceName, State state )
		{
			StateManager stateManager = ( StateManager ) _stateManagerFactory.CreateInstance( dataSourceName );

			return stateManager.Update( state );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			StateManager stateManager = ( StateManager ) _stateManagerFactory.CreateInstance( dataSourceName );

			return stateManager.Delete( id );
		}

		public static State Get( string dataSourceName, int id )
		{
			StateManager stateManager = ( StateManager ) _stateManagerFactory.CreateInstance( dataSourceName );

			return ( State )stateManager.Get( id );
		}

		public static StateCollection GetAll( string dataSourceName  )
		{
			StateManager stateManager = ( StateManager ) _stateManagerFactory.CreateInstance( dataSourceName );

			return ( StateCollection )stateManager.GetAll( );
		}

		public static StateCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			StateManager stateManager = ( StateManager ) _stateManagerFactory.CreateInstance( dataSourceName );

			return ( StateCollection )stateManager.FindByCriteria( finderType, criteria );
		}

		public static DataSet FindDataSetByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			StateManager stateManager = ( StateManager ) _stateManagerFactory.CreateInstance( dataSourceName );

			return stateManager.FindDataSetByCriteria( finderType, criteria );
		}
		#endregion

	}
}
