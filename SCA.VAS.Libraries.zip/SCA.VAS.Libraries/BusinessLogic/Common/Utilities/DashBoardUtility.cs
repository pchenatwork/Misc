
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
using System.Collections;
#endregion References

namespace SCA.VAS.BusinessLogic.Common.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class DashBoardUtility
    {
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly DashBoardManagerFactory _dashBoardManagerFactory = 
			( DashBoardManagerFactory ) DashBoardManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static DashBoardUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( AccountTypeUtility ).FullName);
		}

		private DashBoardUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static DashBoard CreateObject( )
		{
            DashBoardManager dashBoardManager = (DashBoardManager) _dashBoardManagerFactory.CreateInstance( );

			return (DashBoard)dashBoardManager.CreateObject( );
		}
        
		public static DashBoardCollection ContractSpecialist( string dataSourceName)
		{
            DashBoardManager dashBoardManager = (DashBoardManager) _dashBoardManagerFactory.CreateInstance( dataSourceName );

			return (DashBoardCollection)dashBoardManager.ContractSpecialist(  );
		}

		public static DashBoardCollection HBContractSpecialist(string dataSourceName)
		{
			DashBoardManager dashBoardManager = (DashBoardManager)_dashBoardManagerFactory.CreateInstance(dataSourceName);

			return (DashBoardCollection)dashBoardManager.HBContractSpecialist();
		}

		public static DashBoardCollection GetDashboardType(string dataSourceName, string userName)
        {
            DashBoardManager dashBoardManager = (DashBoardManager)_dashBoardManagerFactory.CreateInstance(dataSourceName);

            return (DashBoardCollection)dashBoardManager.GetDashboardType(userName);
        }
        public static DashBoardCollection GetDashboard(string dataSourceName,string userName, string isAffiliates= "N")
        {
            DashBoardManager dashBoardManager = (DashBoardManager)_dashBoardManagerFactory.CreateInstance(dataSourceName);

            return (DashBoardCollection)dashBoardManager.GetDashboard(userName, isAffiliates);
        }
        public static DashBoardCollection GetDashboardWorkFlowTypes(string dataSourceName)
        {
            DashBoardManager dashBoardManager = (DashBoardManager)_dashBoardManagerFactory.CreateInstance(dataSourceName);

            return (DashBoardCollection)dashBoardManager.GetDashboardWorkFlowTypes();
        }
        #endregion
    }
}