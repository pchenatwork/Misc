#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class CurrencyRateUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly CurrencyRateManagerFactory _currencyRateManagerFactory = 
			( CurrencyRateManagerFactory ) CurrencyRateManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static CurrencyRateUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CurrencyRateUtility ).FullName);
		}

		private CurrencyRateUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static CurrencyRate CreateObject( )
		{
			CurrencyRateManager currencyRateManager = ( CurrencyRateManager ) _currencyRateManagerFactory.CreateInstance( );

			return ( CurrencyRate )currencyRateManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, CurrencyRate currencyRate )
		{
			CurrencyRateManager currencyRateManager = ( CurrencyRateManager ) _currencyRateManagerFactory.CreateInstance( dataSourceName );

			return currencyRateManager.Create( currencyRate );
		}

		public static bool Update( string dataSourceName, CurrencyRate currencyRate )
		{
			CurrencyRateManager currencyRateManager = ( CurrencyRateManager ) _currencyRateManagerFactory.CreateInstance( dataSourceName );

			return currencyRateManager.Update( currencyRate );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			CurrencyRateManager currencyRateManager = ( CurrencyRateManager ) _currencyRateManagerFactory.CreateInstance( dataSourceName );

			return currencyRateManager.Delete( id );
		}

        public static bool UpdateCollection(string dataSourceName, string type, DateTime month, CurrencyRateCollection collection)
        {
            CurrencyRateManager currencyRateManager = (CurrencyRateManager)_currencyRateManagerFactory.CreateInstance(dataSourceName);

            return currencyRateManager.UpdateCollection(type, month, collection);
        }

		public static CurrencyRate Get( string dataSourceName, int id )
		{
			CurrencyRateManager currencyRateManager = ( CurrencyRateManager ) _currencyRateManagerFactory.CreateInstance( dataSourceName );

			return ( CurrencyRate )currencyRateManager.Get( id );
		}

		public static CurrencyRateCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			CurrencyRateManager currencyRateManager = ( CurrencyRateManager ) _currencyRateManagerFactory.CreateInstance( dataSourceName );

			return ( CurrencyRateCollection )currencyRateManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
