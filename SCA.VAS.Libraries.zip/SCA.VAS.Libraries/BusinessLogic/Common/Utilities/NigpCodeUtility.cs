#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class NigpCodeUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly NigpCodeManagerFactory _nigpCodeManagerFactory = 
			( NigpCodeManagerFactory ) NigpCodeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static NigpCodeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( NigpCodeUtility ).FullName);
		}

		private NigpCodeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static NigpCode CreateObject( )
		{
			NigpCodeManager nigpCodeManager = ( NigpCodeManager ) _nigpCodeManagerFactory.CreateInstance( );

			return ( NigpCode )nigpCodeManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, NigpCode nigpCode )
		{
			NigpCodeManager nigpCodeManager = ( NigpCodeManager ) _nigpCodeManagerFactory.CreateInstance( dataSourceName );

			return nigpCodeManager.Create( nigpCode );
		}

		public static bool Update( string dataSourceName, NigpCode nigpCode )
		{
			NigpCodeManager nigpCodeManager = ( NigpCodeManager ) _nigpCodeManagerFactory.CreateInstance( dataSourceName );

			return nigpCodeManager.Update( nigpCode );
		}

        public static bool UpdateCollection(string dataSourceName, NigpCodeCollection collection)
        {
            NigpCodeManager nigpCodeManager = (NigpCodeManager)_nigpCodeManagerFactory.CreateInstance(dataSourceName);

            return nigpCodeManager.UpdateCollection(collection);
        }

		public static bool Delete( string dataSourceName, string code, string subCode )
		{
			NigpCodeManager nigpCodeManager = ( NigpCodeManager ) _nigpCodeManagerFactory.CreateInstance( dataSourceName );

			return nigpCodeManager.Delete( code, subCode );
		}

		public static NigpCode Get( string dataSourceName, string code, string subCode )
		{
			NigpCodeManager nigpCodeManager = ( NigpCodeManager ) _nigpCodeManagerFactory.CreateInstance( dataSourceName );

			return ( NigpCode )nigpCodeManager.Get( code, subCode );
		}

		public static NigpCodeCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			NigpCodeManager nigpCodeManager = ( NigpCodeManager ) _nigpCodeManagerFactory.CreateInstance( dataSourceName );

			return ( NigpCodeCollection )nigpCodeManager.FindByCriteria( finderType, criteria );
		}


		#endregion

	}
}
