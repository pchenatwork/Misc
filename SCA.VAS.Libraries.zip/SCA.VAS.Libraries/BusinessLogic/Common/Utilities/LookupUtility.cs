﻿#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
    /// <summary>
    /// Transaction related utility functions.
    /// </summary>
    public class LookupUtility
    {

        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        /// <summary>
        /// logging component
        /// </summary>
        private static ILog _logger;

        private static readonly LookupManagerFactory _LookupManagerFactory =
            (LookupManagerFactory)LookupManagerFactory.Instance();

        #endregion

        #region	Constructors
        // *************************************************************************
        //				 constructors
        // *************************************************************************
        static LookupUtility()
        {
            _logger = LoggingUtility.GetLogger(typeof(LookupUtility).FullName);
        }

        private LookupUtility()
        {
        }
        #endregion

        #region	Public Methods
        //	*************************************************************************
        //				   public methods
        //	*************************************************************************
        public static Lookup CreateObject()
        {
            LookupManager LookupManager = (LookupManager)_LookupManagerFactory.CreateInstance();

            return (Lookup)LookupManager.CreateObject();
        }

        public static bool Create(string dataSourceName, Lookup Lookup)
        {
            LookupManager LookupManager = (LookupManager)_LookupManagerFactory.CreateInstance(dataSourceName);

            return LookupManager.Create(Lookup);
        }

        public static bool Update(string dataSourceName, Lookup Lookup)
        {
            LookupManager LookupManager = (LookupManager)_LookupManagerFactory.CreateInstance(dataSourceName);

            return LookupManager.Update(Lookup);
        }

        public static bool Delete(string dataSourceName, int id)
        {
            LookupManager LookupManager = (LookupManager)_LookupManagerFactory.CreateInstance(dataSourceName);

            return LookupManager.Delete(id);
        }

        public static Lookup Get(string dataSourceName, int id)
        {
            LookupManager LookupManager = (LookupManager)_LookupManagerFactory.CreateInstance(dataSourceName);

            return (Lookup)LookupManager.Get(id);
        }

        public static LookupCollection GetByType(string dataSourceName,string type)
        {
            LookupManager LookupManager = (LookupManager)_LookupManagerFactory.CreateInstance(dataSourceName);

            return (LookupCollection)LookupManager.GetByType(type);
        }

        public static LookupCollection FindByCriteria(string dataSourceName, string criteria, string criteriaValue)
        {
            LookupManager LookupManager = (LookupManager)_LookupManagerFactory.CreateInstance(dataSourceName);

            return (LookupCollection)LookupManager.FindByCriteria(criteria,criteriaValue);
        }

        public static LookupCollection FindByHardbidProjectSearchType(string dataSourceName, string search, string searchType)
        {
            LookupManager LookupManager = (LookupManager)_LookupManagerFactory.CreateInstance(dataSourceName);

            return (LookupCollection)LookupManager.FindByHardbidProjectSearchType(search, searchType);
        }
        #endregion

    }
}
