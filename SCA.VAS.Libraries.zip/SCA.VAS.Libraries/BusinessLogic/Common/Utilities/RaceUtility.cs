#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class RaceUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly RaceManagerFactory _raceManagerFactory = 
			( RaceManagerFactory ) RaceManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static RaceUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( RaceUtility ).FullName);
		}

		private RaceUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Race CreateObject( )
		{
			RaceManager raceManager = ( RaceManager ) _raceManagerFactory.CreateInstance( );

			return ( Race )raceManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, Race race )
		{
			RaceManager raceManager = ( RaceManager ) _raceManagerFactory.CreateInstance( dataSourceName );

			return raceManager.Create( race );
		}

		public static bool Update( string dataSourceName, Race race )
		{
			RaceManager raceManager = ( RaceManager ) _raceManagerFactory.CreateInstance( dataSourceName );

			return raceManager.Update( race );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			RaceManager raceManager = ( RaceManager ) _raceManagerFactory.CreateInstance( dataSourceName );

			return raceManager.Delete( id );
		}

		public static Race Get( string dataSourceName, int id )
		{
			RaceManager raceManager = ( RaceManager ) _raceManagerFactory.CreateInstance( dataSourceName );

			return ( Race )raceManager.Get( id );
		}

		public static RaceCollection GetAll( string dataSourceName  )
		{
			RaceManager raceManager = ( RaceManager ) _raceManagerFactory.CreateInstance( dataSourceName );

			return ( RaceCollection )raceManager.GetAll( );
		}

		public static RaceCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			RaceManager raceManager = ( RaceManager ) _raceManagerFactory.CreateInstance( dataSourceName );

			return ( RaceCollection )raceManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
