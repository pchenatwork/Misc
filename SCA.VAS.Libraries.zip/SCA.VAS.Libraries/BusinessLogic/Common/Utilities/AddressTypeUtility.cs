
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class AddressTypeUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly AddressTypeManagerFactory _addressTypeManagerFactory = 
			( AddressTypeManagerFactory ) AddressTypeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static AddressTypeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( AddressTypeUtility ).FullName);
		}

		private AddressTypeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static AddressType CreateObject( )
		{
			AddressTypeManager addressTypeManager = ( AddressTypeManager ) _addressTypeManagerFactory.CreateInstance( );

			return ( AddressType )addressTypeManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, AddressType addressType )
		{
			AddressTypeManager addressTypeManager = ( AddressTypeManager ) _addressTypeManagerFactory.CreateInstance( dataSourceName );

			return addressTypeManager.Create( addressType );
		}
		
		public static bool Update( string dataSourceName, AddressType addressType )
		{
			AddressTypeManager addressTypeManager = ( AddressTypeManager ) _addressTypeManagerFactory.CreateInstance( dataSourceName );

			return addressTypeManager.Update( addressType );
		}
		
		public static bool Delete( string dataSourceName, int id )
		{
			AddressTypeManager addressTypeManager = ( AddressTypeManager ) _addressTypeManagerFactory.CreateInstance( dataSourceName );

			return addressTypeManager.Delete( id );
		}

		public static AddressType Get( string dataSourceName, int id )
		{
			AddressTypeManager addressTypeManager = ( AddressTypeManager ) _addressTypeManagerFactory.CreateInstance( dataSourceName );

			return ( AddressType )addressTypeManager.Get( id );
		}

		public static AddressTypeCollection GetAll(string dataSourceName)
		{
			AddressTypeManager addressTypeManager = (AddressTypeManager)_addressTypeManagerFactory.CreateInstance(dataSourceName);

			return (AddressTypeCollection)addressTypeManager.GetAll();
		}

		public static AddressTypeCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			AddressTypeManager addressTypeManager = ( AddressTypeManager ) _addressTypeManagerFactory.CreateInstance( dataSourceName );

			return ( AddressTypeCollection )addressTypeManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}