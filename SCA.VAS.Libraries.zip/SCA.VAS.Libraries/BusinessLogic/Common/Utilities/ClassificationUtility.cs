#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class ClassificationUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly ClassificationManagerFactory _classificationManagerFactory = 
			( ClassificationManagerFactory ) ClassificationManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static ClassificationUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ClassificationUtility ).FullName);
		}

		private ClassificationUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Classification CreateObject( )
		{
			ClassificationManager classificationManager = ( ClassificationManager ) _classificationManagerFactory.CreateInstance( );

			return ( Classification )classificationManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, Classification classification )
		{
			ClassificationManager classificationManager = ( ClassificationManager ) _classificationManagerFactory.CreateInstance( dataSourceName );

			return classificationManager.Create( classification );
		}

		public static bool Update( string dataSourceName, Classification classification )
		{
			ClassificationManager classificationManager = ( ClassificationManager ) _classificationManagerFactory.CreateInstance( dataSourceName );

			return classificationManager.Update( classification );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			ClassificationManager classificationManager = ( ClassificationManager ) _classificationManagerFactory.CreateInstance( dataSourceName );

			return classificationManager.Delete( id );
		}

		public static Classification Get( string dataSourceName, int id )
		{
			ClassificationManager classificationManager = ( ClassificationManager ) _classificationManagerFactory.CreateInstance( dataSourceName );

			return ( Classification )classificationManager.Get( id );
		}

		public static ClassificationCollection GetAll( string dataSourceName  )
		{
			ClassificationManager classificationManager = ( ClassificationManager ) _classificationManagerFactory.CreateInstance( dataSourceName );

			return ( ClassificationCollection )classificationManager.GetAll( );
		}

		public static ClassificationCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			ClassificationManager classificationManager = ( ClassificationManager ) _classificationManagerFactory.CreateInstance( dataSourceName );

			return ( ClassificationCollection )classificationManager.FindByCriteria( finderType, criteria );
		}

		#endregion

	}
}
