#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class NaicsCodeUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly NaicsCodeManagerFactory _naicsCodeManagerFactory = 
			( NaicsCodeManagerFactory ) NaicsCodeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static NaicsCodeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( NaicsCodeUtility ).FullName);
		}

		private NaicsCodeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static NaicsCode CreateObject( )
		{
			NaicsCodeManager naicsCodeManager = ( NaicsCodeManager ) _naicsCodeManagerFactory.CreateInstance( );

			return ( NaicsCode )naicsCodeManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, NaicsCode naicsCode )
		{
			NaicsCodeManager naicsCodeManager = ( NaicsCodeManager ) _naicsCodeManagerFactory.CreateInstance( dataSourceName );

			return naicsCodeManager.Create( naicsCode );
		}

		public static bool Update( string dataSourceName, NaicsCode naicsCode )
		{
			NaicsCodeManager naicsCodeManager = ( NaicsCodeManager ) _naicsCodeManagerFactory.CreateInstance( dataSourceName );

			return naicsCodeManager.Update( naicsCode );
		}

        public static bool UpdateCollection(string dataSourceName, NaicsCodeCollection collection)
        {
            NaicsCodeManager naicsCodeManager = (NaicsCodeManager)_naicsCodeManagerFactory.CreateInstance(dataSourceName);

            return naicsCodeManager.UpdateCollection(collection);
        }

		public static bool Delete( string dataSourceName, string code )
		{
			NaicsCodeManager naicsCodeManager = ( NaicsCodeManager ) _naicsCodeManagerFactory.CreateInstance( dataSourceName );

			return naicsCodeManager.Delete( code );
		}

		public static NaicsCode Get( string dataSourceName, string code )
		{
			NaicsCodeManager naicsCodeManager = ( NaicsCodeManager ) _naicsCodeManagerFactory.CreateInstance( dataSourceName );

			return ( NaicsCode )naicsCodeManager.Get( code );
		}

		public static NaicsCodeCollection GetAll( string dataSourceName  )
		{
			NaicsCodeManager naicsCodeManager = ( NaicsCodeManager ) _naicsCodeManagerFactory.CreateInstance( dataSourceName );

			return ( NaicsCodeCollection )naicsCodeManager.GetAll( );
		}

		public static NaicsCodeCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			NaicsCodeManager naicsCodeManager = ( NaicsCodeManager ) _naicsCodeManagerFactory.CreateInstance( dataSourceName );

			return ( NaicsCodeCollection )naicsCodeManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
