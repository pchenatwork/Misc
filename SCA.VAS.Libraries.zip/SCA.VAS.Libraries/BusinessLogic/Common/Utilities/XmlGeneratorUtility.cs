using System;
using System.IO;
using System.Collections;
using System.Xml;

using SCA.VAS.ValueObjects.Common;

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Summary description for XmlGenerator.
	/// </summary>
	public class XmlGeneratorUtility
	{
		#region Private Variable Member
		private string _schemaLine = string.Empty;
		private DbSchemaCollection _schemaList = new DbSchemaCollection();
		private ArrayList _mappingList = new ArrayList();
		private ArrayList _dbSchemaList = new ArrayList();
		private string _delimiter = string.Empty;
		private string _qualifier = string.Empty;

		private string _tableName = string.Empty;
		private string _destinationFile = string.Empty;
		private TextReader _reader;
		#endregion Private Variable Member		
		#region Property
		public DbSchemaCollection SchemaList 
		{
			get
			{
				return _schemaList;
			}
			set
			{
				_schemaList = value;
			}
		}
		public ArrayList MappingList
		{
			get
			{
				return _mappingList;
			}
			set
			{
				_mappingList = value;
			}
		}
		public ArrayList DBSchemaList
		{
			get
			{
				return _dbSchemaList;
			}
			set
			{
				_dbSchemaList = value;
			}
		}
		public string Delimiter
		{
			get
			{
				return _delimiter;
			}
			set
			{
				_delimiter = value;
			}
		}
		public string Qualifier
		{
			get
			{
				return _qualifier;
			}
			set
			{
				_qualifier = value;
			}
		}
		public string DestinationFile
		{
			get
			{
				return _destinationFile;
			}
			set
			{
				_destinationFile = value;
			}
		}
		public string TableName
		{
			get
			{
				return _tableName;
			}
			set
			{
				_tableName = value;
			}
		}
		#endregion Property
		#region Constructor
		public XmlGeneratorUtility( TextReader paraReader )
		{
			_reader = paraReader;
			_schemaLine = _reader.ReadLine();
			if( _schemaLine == null )
			{
				throw ( new Exception() );
			}
			_qualifier = "\"";
			_delimiter = ",";
			SetSchema();
		}

		public XmlGeneratorUtility( Stream readerStream )
		{
			_reader = new StreamReader( readerStream );
			_schemaLine = _reader.ReadLine();
			if( _schemaLine == null )
			{
				throw ( new Exception() );
			}
			SetSchema();
			_qualifier = "\"";
			_delimiter = ",";
		}

		public XmlGeneratorUtility( string readerString )
		{
			_reader = new StringReader( readerString );
			_schemaLine = _reader.ReadLine();
			if( _schemaLine == null )
			{
				throw ( new Exception() );
			}
			_qualifier = "\"";
			_delimiter = ",";
			SetSchema();
		}
		
		public XmlGeneratorUtility( TextReader paraReader, 
			string paraQualifier, string paraDelimiter )
		{
			_reader = paraReader;
			_schemaLine = _reader.ReadLine();
			if( _schemaLine == null )
			{
				throw ( new Exception() );
			}
			_qualifier = paraQualifier;
			_delimiter = paraDelimiter;
			SetSchema();
		}

		public XmlGeneratorUtility( Stream readerStream, 
			string paraQualifier, string paraDelimiter )
		{
			_reader = new StreamReader( readerStream );
			_schemaLine = _reader.ReadLine();
			if( _schemaLine == null )
			{
				throw ( new Exception() );
			}
			_qualifier = paraQualifier;
			_delimiter = paraDelimiter;
			SetSchema();
		}

		public XmlGeneratorUtility( string readerString, 
			string paraQualifier, string paraDelimiter )
		{
			_reader = new StringReader( readerString );
			_schemaLine = _reader.ReadLine();
			if( _schemaLine == null )
			{
				throw ( new Exception() );
			}
			_qualifier = paraQualifier;
			_delimiter = paraDelimiter;
			SetSchema();
		}
		#endregion Constructor
		#region Private Method
		private void SetSchema()
		{			
			string[] localSchemaList = _schemaLine.Split( _delimiter.ToCharArray() );
			for( int i = 0; i< localSchemaList.Length; i ++ )
			{
				localSchemaList[i] = localSchemaList[i].Trim( _qualifier.ToCharArray() );
				DbSchema localSchema = DbSchemaUtility.CreateObject();
				localSchema.Id = i;
				localSchema.Name = localSchemaList[i];
				_schemaList.Add( localSchema );
			}
		}
		#endregion Private Method
		#region Public Method
		public string GenerateXmlFile()
		{
			if( File.Exists( _destinationFile ) )
			{
				File.Delete( _destinationFile );
			}
			Stream outStream = File.OpenWrite( _destinationFile );
			XmlTextWriter localWriter = new XmlTextWriter( outStream, null );

			//output xml declaration 
			localWriter.WriteStartDocument( true );

			//output xml root
			localWriter.WriteStartElement( "ArrayOf" + _tableName );

			//output xml elements

			string newLine;
			while( ( newLine = _reader.ReadLine() )!= null )
			{	
				localWriter.WriteStartElement( _tableName );
				string[] localAttributes = newLine.Split( _delimiter.ToCharArray() );
				for( int i = 0; i < localAttributes.Length; i ++ )
				{
					localAttributes[i] = 
						localAttributes[i].Trim( _qualifier.ToCharArray() );
				}
				for( int i = 0; i < _dbSchemaList.Count; i++ )
				{
					if ( ( int )_mappingList[i] >= 0 )
					{
						localWriter.WriteAttributeString( 
							( string )_dbSchemaList[i], 
							localAttributes[ (int)_mappingList[i] ]
							);
					}
					else
					{
//						localWriter.WriteAttributeString( 
//							( string )_dbSchemaList[i], ""
//							);
					}
				}
				localWriter.WriteEndElement();
			}

			localWriter.WriteEndElement();			
			localWriter.WriteEndDocument();

			localWriter.Flush();
			localWriter.Close();
			return _destinationFile;
		}
		public XmlReader GenerateXmlReader()
		{
			string tempFileName = GenerateXmlFile();
			Stream stream = File.OpenRead( tempFileName );
			XmlTextReader reader = new XmlTextReader( stream );
			return reader;
		}
		#endregion Public Method
	}
}
