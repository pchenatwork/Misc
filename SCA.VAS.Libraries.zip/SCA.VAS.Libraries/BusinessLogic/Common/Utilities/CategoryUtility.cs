#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class CategoryUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly CategoryManagerFactory _categoryManagerFactory = 
			( CategoryManagerFactory ) CategoryManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static CategoryUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CategoryUtility ).FullName);
		}

		private CategoryUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Category CreateObject( )
		{
			CategoryManager categoryManager = ( CategoryManager ) _categoryManagerFactory.CreateInstance( );

			return ( Category )categoryManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, Category category )
		{
			CategoryManager categoryManager = ( CategoryManager ) _categoryManagerFactory.CreateInstance( dataSourceName );

			return categoryManager.Create( category );
		}

		public static bool Update( string dataSourceName, Category category )
		{
			CategoryManager categoryManager = ( CategoryManager ) _categoryManagerFactory.CreateInstance( dataSourceName );

			return categoryManager.Update( category );
		}

        public static bool UpdateCollection(string dataSourceName, CategoryCollection collection)
        {
            CategoryManager categoryManager = (CategoryManager)_categoryManagerFactory.CreateInstance(dataSourceName);

            return categoryManager.UpdateCollection(collection);
        }

		public static bool Delete( string dataSourceName, int id )
		{
			CategoryManager categoryManager = ( CategoryManager ) _categoryManagerFactory.CreateInstance( dataSourceName );

			return categoryManager.Delete( id );
		}

		public static Category Get( string dataSourceName, int id )
		{
			CategoryManager categoryManager = ( CategoryManager ) _categoryManagerFactory.CreateInstance( dataSourceName );

			return ( Category )categoryManager.Get( id );
		}
		
		public static Category GetByName( string dataSourceName, string name )
		{
			CategoryManager categoryManager = ( CategoryManager ) _categoryManagerFactory.CreateInstance( dataSourceName );

			return ( Category )categoryManager.GetByName( name );
		}

		public static CategoryCollection GetAll( string dataSourceName  )
		{
			CategoryManager categoryManager = ( CategoryManager ) _categoryManagerFactory.CreateInstance( dataSourceName );

			return ( CategoryCollection )categoryManager.GetAll( );
		}

		public static CategoryCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			CategoryManager categoryManager = ( CategoryManager ) _categoryManagerFactory.CreateInstance( dataSourceName );

			return ( CategoryCollection )categoryManager.FindByCriteria( finderType, criteria );
		}
        
        public static void GetAllCategories(CategoryCollection categories, CategoryCollection allCategories)
        {
            if (categories == null)
                return;

            foreach (Category c in categories)
            {
                allCategories.Add(c);
                if (c.SubCategories != null)
                {
                    GetAllCategories(c.SubCategories, allCategories);
                }
            }
        }
		#endregion

	}
}
