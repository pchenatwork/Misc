#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class DbSchemaUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly DbSchemaManagerFactory _dbSchemaManagerFactory = 
			( DbSchemaManagerFactory ) DbSchemaManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static DbSchemaUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( DbSchemaUtility ).FullName);
		}

		private DbSchemaUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static DbSchema CreateObject( )
		{
			DbSchemaManager dbSchemaManager = ( DbSchemaManager ) _dbSchemaManagerFactory.CreateInstance( );

			return ( DbSchema )dbSchemaManager.CreateObject( );
		}

		public static DbSchemaCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			DbSchemaManager dbSchemaManager = ( DbSchemaManager ) _dbSchemaManagerFactory.CreateInstance( dataSourceName );

			return ( DbSchemaCollection )dbSchemaManager.FindByCriteria( finderType, criteria );
		}

        public static DataSet ReportByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            DbSchemaManager dbSchemaManager = (DbSchemaManager)_dbSchemaManagerFactory.CreateInstance(dataSourceName);

            return dbSchemaManager.ReportByCriteria(finderType, criteria);
        }
		#endregion

	}
}
