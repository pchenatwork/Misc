#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class SicCodeUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly SicCodeManagerFactory _sicCodeManagerFactory = 
			( SicCodeManagerFactory ) SicCodeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static SicCodeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( SicCodeUtility ).FullName);
		}

		private SicCodeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static SicCode CreateObject( )
		{
			SicCodeManager sicCodeManager = ( SicCodeManager ) _sicCodeManagerFactory.CreateInstance( );

			return ( SicCode )sicCodeManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, SicCode sicCode )
		{
			SicCodeManager sicCodeManager = ( SicCodeManager ) _sicCodeManagerFactory.CreateInstance( dataSourceName );

			return sicCodeManager.Create( sicCode );
		}

		public static bool Update( string dataSourceName, SicCode sicCode )
		{
			SicCodeManager sicCodeManager = ( SicCodeManager ) _sicCodeManagerFactory.CreateInstance( dataSourceName );

			return sicCodeManager.Update( sicCode );
		}

        public static bool UpdateCollection(string dataSourceName, SicCodeCollection collection)
        {
            SicCodeManager sicCodeManager = (SicCodeManager)_sicCodeManagerFactory.CreateInstance(dataSourceName);

            return sicCodeManager.UpdateCollection(collection);
        }

		public static bool Delete( string dataSourceName, string code )
		{
			SicCodeManager sicCodeManager = ( SicCodeManager ) _sicCodeManagerFactory.CreateInstance( dataSourceName );

			return sicCodeManager.Delete( code );
		}

		public static SicCode Get( string dataSourceName, string code )
		{
			SicCodeManager sicCodeManager = ( SicCodeManager ) _sicCodeManagerFactory.CreateInstance( dataSourceName );

			return ( SicCode )sicCodeManager.Get( code );
		}

		public static SicCodeCollection GetAll( string dataSourceName  )
		{
			SicCodeManager sicCodeManager = ( SicCodeManager ) _sicCodeManagerFactory.CreateInstance( dataSourceName );

			return ( SicCodeCollection )sicCodeManager.GetAll( );
		}

		public static SicCodeCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			SicCodeManager sicCodeManager = ( SicCodeManager ) _sicCodeManagerFactory.CreateInstance( dataSourceName );

			return ( SicCodeCollection )sicCodeManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
