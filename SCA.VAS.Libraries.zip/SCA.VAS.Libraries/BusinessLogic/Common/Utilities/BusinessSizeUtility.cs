#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class BusinessSizeUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BusinessSizeManagerFactory _businessSizeManagerFactory = 
			( BusinessSizeManagerFactory ) BusinessSizeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BusinessSizeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BusinessSizeUtility ).FullName);
		}

		private BusinessSizeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static BusinessSize CreateObject( )
		{
			BusinessSizeManager businessSizeManager = ( BusinessSizeManager ) _businessSizeManagerFactory.CreateInstance( );

			return ( BusinessSize )businessSizeManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, BusinessSize businessSize )
		{
			BusinessSizeManager businessSizeManager = ( BusinessSizeManager ) _businessSizeManagerFactory.CreateInstance( dataSourceName );

			return businessSizeManager.Create( businessSize );
		}

		public static bool Update( string dataSourceName, BusinessSize businessSize )
		{
			BusinessSizeManager businessSizeManager = ( BusinessSizeManager ) _businessSizeManagerFactory.CreateInstance( dataSourceName );

			return businessSizeManager.Update( businessSize );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			BusinessSizeManager businessSizeManager = ( BusinessSizeManager ) _businessSizeManagerFactory.CreateInstance( dataSourceName );

			return businessSizeManager.Delete( id );
		}

		public static BusinessSize Get( string dataSourceName, int id )
		{
			BusinessSizeManager businessSizeManager = ( BusinessSizeManager ) _businessSizeManagerFactory.CreateInstance( dataSourceName );

			return ( BusinessSize )businessSizeManager.Get( id );
		}

		public static BusinessSizeCollection GetAll( string dataSourceName  )
		{
			BusinessSizeManager businessSizeManager = ( BusinessSizeManager ) _businessSizeManagerFactory.CreateInstance( dataSourceName );

			return ( BusinessSizeCollection )businessSizeManager.GetAll( );
		}

		#endregion

	}
}
