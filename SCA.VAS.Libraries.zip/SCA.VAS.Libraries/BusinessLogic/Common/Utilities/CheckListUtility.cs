#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class CheckListUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly CheckListManagerFactory _checkListManagerFactory = 
			( CheckListManagerFactory ) CheckListManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static CheckListUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CheckListUtility ).FullName);
		}

		private CheckListUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static CheckList CreateObject( )
		{
			CheckListManager checkListManager = ( CheckListManager ) _checkListManagerFactory.CreateInstance( );

			return ( CheckList )checkListManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, CheckList checkList )
		{
			CheckListManager checkListManager = ( CheckListManager ) _checkListManagerFactory.CreateInstance( dataSourceName );

			return checkListManager.Create( checkList );
		}

		public static bool Update( string dataSourceName, CheckList checkList )
		{
			CheckListManager checkListManager = ( CheckListManager ) _checkListManagerFactory.CreateInstance( dataSourceName );

			return checkListManager.Update( checkList );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			CheckListManager checkListManager = ( CheckListManager ) _checkListManagerFactory.CreateInstance( dataSourceName );

			return checkListManager.Delete( id );
		}

        public static bool UpdateCollection(string dataSourceName, int businessUnitId, CheckListCollection collection)
        {
            CheckListManager checkListManager = (CheckListManager)_checkListManagerFactory.CreateInstance(dataSourceName);

            return checkListManager.UpdateCollection(businessUnitId, collection);
        }

		public static CheckList Get( string dataSourceName, int id )
		{
			CheckListManager checkListManager = ( CheckListManager ) _checkListManagerFactory.CreateInstance( dataSourceName );

			return ( CheckList )checkListManager.Get( id );
		}
		
		public static CheckListCollection GetAll( string dataSourceName  )
		{
			CheckListManager checkListManager = ( CheckListManager ) _checkListManagerFactory.CreateInstance( dataSourceName );

			return ( CheckListCollection )checkListManager.GetAll( );
		}

		public static CheckListCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			CheckListManager checkListManager = ( CheckListManager ) _checkListManagerFactory.CreateInstance( dataSourceName );

			return ( CheckListCollection )checkListManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
