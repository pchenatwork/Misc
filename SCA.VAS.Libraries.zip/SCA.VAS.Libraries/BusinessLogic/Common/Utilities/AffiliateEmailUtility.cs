#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class AffiliateEmailUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly AffiliateEmailManagerFactory _affiliateEmailManagerFactory = 
			( AffiliateEmailManagerFactory ) AffiliateEmailManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static AffiliateEmailUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( AffiliateEmailUtility ).FullName);
		}

		private AffiliateEmailUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static AffiliateEmail CreateObject( )
		{
			AffiliateEmailManager affiliateEmailManager = ( AffiliateEmailManager ) _affiliateEmailManagerFactory.CreateInstance( );

			return ( AffiliateEmail )affiliateEmailManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, AffiliateEmail affiliateEmail )
		{
			AffiliateEmailManager affiliateEmailManager = ( AffiliateEmailManager ) _affiliateEmailManagerFactory.CreateInstance( dataSourceName );

			return affiliateEmailManager.Create( affiliateEmail );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			AffiliateEmailManager affiliateEmailManager = ( AffiliateEmailManager ) _affiliateEmailManagerFactory.CreateInstance( dataSourceName );

			return affiliateEmailManager.Delete( id );
		}

        public static bool UpdateCollection(string dataSourceName, int affiliateId, AffiliateEmailCollection collection)
        {
            AffiliateEmailManager affiliateEmailManager = (AffiliateEmailManager)_affiliateEmailManagerFactory.CreateInstance(dataSourceName);

            return affiliateEmailManager.UpdateCollection(affiliateId, collection);
        }
		
		public static AffiliateEmail Get( string dataSourceName, int id )
		{
			AffiliateEmailManager affiliateEmailManager = ( AffiliateEmailManager ) _affiliateEmailManagerFactory.CreateInstance( dataSourceName );

			return ( AffiliateEmail )affiliateEmailManager.Get( id );
		}

		public static AffiliateEmailCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			AffiliateEmailManager affiliateEmailManager = ( AffiliateEmailManager ) _affiliateEmailManagerFactory.CreateInstance( dataSourceName );

			return ( AffiliateEmailCollection )affiliateEmailManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
