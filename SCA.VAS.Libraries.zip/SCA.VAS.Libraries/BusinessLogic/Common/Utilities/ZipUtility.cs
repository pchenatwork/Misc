#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class ZipUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly ZipManagerFactory _zipManagerFactory = 
			( ZipManagerFactory ) ZipManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static ZipUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ZipUtility ).FullName);
		}

		private ZipUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Zip CreateObject( )
		{
			ZipManager zipManager = ( ZipManager ) _zipManagerFactory.CreateInstance( );

			return ( Zip )zipManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, Zip zip )
		{
			ZipManager zipManager = ( ZipManager ) _zipManagerFactory.CreateInstance( dataSourceName );

			return zipManager.Create( zip );
		}

		public static bool Update( string dataSourceName, Zip zip )
		{
			ZipManager zipManager = ( ZipManager ) _zipManagerFactory.CreateInstance( dataSourceName );

			return zipManager.Update( zip );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			ZipManager zipManager = ( ZipManager ) _zipManagerFactory.CreateInstance( dataSourceName );

			return zipManager.Delete( id );
		}

		public static Zip Get( string dataSourceName, int id )
		{
			ZipManager zipManager = ( ZipManager ) _zipManagerFactory.CreateInstance( dataSourceName );

			return ( Zip )zipManager.Get( id );
		}

        public static Zip GetByCode(string dataSourceName, string code)
        {
            ZipManager zipManager = (ZipManager)_zipManagerFactory.CreateInstance(dataSourceName);

            return (Zip)zipManager.GetByCode(code);
        }

		public static ZipCollection GetAll( string dataSourceName  )
		{
			ZipManager zipManager = ( ZipManager ) _zipManagerFactory.CreateInstance( dataSourceName );

			return ( ZipCollection )zipManager.GetAll( );
		}

		public static ZipCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			ZipManager zipManager = ( ZipManager ) _zipManagerFactory.CreateInstance( dataSourceName );

			return ( ZipCollection )zipManager.FindByCriteria( finderType, criteria );
		}

		public static DataSet FindDataSetByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			ZipManager zipManager = ( ZipManager ) _zipManagerFactory.CreateInstance( dataSourceName );

			return zipManager.FindDataSetByCriteria( finderType, criteria );
		}
		#endregion

	}
}
