
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class TaxTypeUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly TaxTypeManagerFactory _taxTypeManagerFactory = 
			( TaxTypeManagerFactory ) TaxTypeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static TaxTypeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( TaxTypeUtility ).FullName);
		}

		private TaxTypeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static TaxType CreateObject( )
		{
			TaxTypeManager taxTypeManager = ( TaxTypeManager ) _taxTypeManagerFactory.CreateInstance( );

			return ( TaxType )taxTypeManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, TaxType taxType )
		{
			TaxTypeManager taxTypeManager = ( TaxTypeManager ) _taxTypeManagerFactory.CreateInstance( dataSourceName );

			return taxTypeManager.Create( taxType );
		}
		
		public static bool Update( string dataSourceName, TaxType taxType )
		{
			TaxTypeManager taxTypeManager = ( TaxTypeManager ) _taxTypeManagerFactory.CreateInstance( dataSourceName );

			return taxTypeManager.Update( taxType );
		}
		
		public static bool Delete( string dataSourceName, int id )
		{
			TaxTypeManager taxTypeManager = ( TaxTypeManager ) _taxTypeManagerFactory.CreateInstance( dataSourceName );

			return taxTypeManager.Delete( id );
		}

		public static TaxType Get( string dataSourceName, int id )
		{
			TaxTypeManager taxTypeManager = ( TaxTypeManager ) _taxTypeManagerFactory.CreateInstance( dataSourceName );

			return ( TaxType )taxTypeManager.Get( id );
		}

		public static TaxTypeCollection GetAll(string dataSourceName)
		{
			TaxTypeManager taxTypeManager = (TaxTypeManager)_taxTypeManagerFactory.CreateInstance(dataSourceName);

			return (TaxTypeCollection)taxTypeManager.GetAll();
		}

		public static TaxTypeCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			TaxTypeManager taxTypeManager = ( TaxTypeManager ) _taxTypeManagerFactory.CreateInstance( dataSourceName );

			return ( TaxTypeCollection )taxTypeManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}