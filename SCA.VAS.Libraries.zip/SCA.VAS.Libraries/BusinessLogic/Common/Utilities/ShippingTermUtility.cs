#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class ShippingTermUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly ShippingTermManagerFactory _shippingTermManagerFactory = 
			( ShippingTermManagerFactory ) ShippingTermManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static ShippingTermUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ShippingTermUtility ).FullName);
		}

		private ShippingTermUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static ShippingTerm CreateObject( )
		{
			ShippingTermManager shippingTermManager = ( ShippingTermManager ) _shippingTermManagerFactory.CreateInstance( );

			return ( ShippingTerm )shippingTermManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, ShippingTerm shippingTerm )
		{
			ShippingTermManager shippingTermManager = ( ShippingTermManager ) _shippingTermManagerFactory.CreateInstance( dataSourceName );

			return shippingTermManager.Create( shippingTerm );
		}

		public static bool Update( string dataSourceName, ShippingTerm shippingTerm )
		{
			ShippingTermManager shippingTermManager = ( ShippingTermManager ) _shippingTermManagerFactory.CreateInstance( dataSourceName );

			return shippingTermManager.Update( shippingTerm );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			ShippingTermManager shippingTermManager = ( ShippingTermManager ) _shippingTermManagerFactory.CreateInstance( dataSourceName );

			return shippingTermManager.Delete( id );
		}

		public static ShippingTerm Get( string dataSourceName, int id )
		{
			ShippingTermManager shippingTermManager = ( ShippingTermManager ) _shippingTermManagerFactory.CreateInstance( dataSourceName );

			return ( ShippingTerm )shippingTermManager.Get( id );
		}

		public static ShippingTermCollection GetAll( string dataSourceName  )
		{
			ShippingTermManager shippingTermManager = ( ShippingTermManager ) _shippingTermManagerFactory.CreateInstance( dataSourceName );

			return ( ShippingTermCollection )shippingTermManager.GetAll( );
		}

		#endregion

	}
}
