#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Linq;

using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.Configuration;
using SCA.VAS.ValueObjects;
using SCA.VAS.ECMWrapper;
using SCA.VAS.ValueObjects.User;
using SCA.VAS.BusinessLogic.User.Utilities;


using log4net;

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
    /// <summary>
    /// Summary description for EmailUtility.
    /// </summary>
    public class EmailUtility
    {
        #region Constants
        #endregion

        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        private static ILog _logger = null;
        #endregion

        #region	Constructors
        // *************************************************************************
        //				 Constructors
        // *************************************************************************
        /// <summary>
        /// class constructor 
        /// initializes logging
        /// </summary>
        static EmailUtility()
        {
            _logger = LoggingUtility.GetLogger(typeof(EmailUtility).FullName);
        }

        ///	<summary>
        ///	default	constructor	
        ///	</summary>
        public EmailUtility()
        {
        }
        #endregion

        #region	Public Methods

        public static bool Send(string fromEmail, string fromName,
            string toEmail, string toName, string ccEmail, string cc,
            string subject, string body, string bcc, bool confirmation,
            object[] attachments, string replyTo)
        {
            string methodName = "Send";
            bool bOK = true; // Assume OK
            using (SmtpClient smtpClient = new SmtpClient())
            {
                using (MailMessage message = new MailMessage())
                {
                    try
                    {
                        if (ConfigurationManager.AppSettings["SMTPServer"] != null &&
                            ConfigurationManager.AppSettings["SMTPServer"] != string.Empty)
                            smtpClient.Host = ConfigurationManager.AppSettings["SMTPServer"];

                        string footer = ConfigurationManager.AppSettings["EmailFooter"];

                        string headerName = ConfigurationManager.AppSettings["CustomHeaderName"];
                        string headerValue = ConfigurationManager.AppSettings["CustomHeaderValue"];

                        int port = ConvertUtility.ConvertInt(ConfigurationManager.AppSettings["SMTPPort"]);
                        if (port > 0)
                            smtpClient.Port = port;

                        //From address will be given as a MailAddress Object
                        message.From = new MailAddress(fromEmail, fromName);

                        toEmail = toEmail.TrimEnd(new char[] { ';', ',', ' ' });
                        string[] toEmails = toEmail.Split(new char[] { ';', ',', ' ' });
                        if (toEmails.Length == 1)
                        {
                            MailAddress toAddress = new MailAddress(toEmail.Trim(), toName.Trim());
                            // To address collection of MailAddress
                            message.To.Add(toAddress);
                        }
                        else
                        {
                            for (int i = 0; i < toEmails.Length; i++)
                            {
                                if (toEmails[i].Trim().Length > 0)
                                {
                                    MailAddress toAddress = new MailAddress(toEmails[i].Trim());
                                    if (!message.To.Contains(toAddress))
                                    {
                                        message.To.Add(toAddress);
                                    }
                                }
                            }
                        }
                        message.Subject = subject;

                        // CC and BCC optional
                        // MailAddressCollection class is used to send the email to various users
                        ccEmail = ccEmail.TrimEnd(new char[] { ';', ',', ' ' });
                        string[] ccEmails = ccEmail.Split(new char[] { ';', ',', ' ' });
                        for (int i = 0; i < ccEmails.Length; i++)
                        {
                            if (ccEmails[i].Trim().Length > 0)
                            {
                                MailAddress ccAddress;
                                if (ccEmails.Length == 1 && cc.Trim().Length > 0)
                                    ccAddress = new MailAddress(ccEmails[i].Trim(), cc.Trim());
                                else
                                    ccAddress = new MailAddress(ccEmails[i].Trim());
                                if (!message.CC.Contains(ccAddress))
                                {
                                    message.CC.Add(ccAddress);
                                }
                            }
                        }

                        bcc = bcc.TrimEnd(new char[] { ';', ',', ' ' });
                        string[] bccEmails = bcc.Split(new char[] { ';', ',', ' ' });
                        for (int i = 0; i < bccEmails.Length; i++)
                        {
                            if (bccEmails[i].Trim().Length > 0)
                            {
                                MailAddress bccAddress = new MailAddress(bccEmails[i].Trim());
                                if (!message.Bcc.Contains(bccAddress))
                                {
                                    message.Bcc.Add(bccAddress);
                                }
                            }
                        }

                        if (replyTo.Trim().Length > 0)
                        {
                            message.ReplyTo = new MailAddress(replyTo);
                        }

                        message.IsBodyHtml = true;

                        // Message body content
                        message.Body = body + "<br />" + footer;

                        if (confirmation)
                        {
                            message.Headers.Add("Disposition-Notification-To", fromEmail);
                            message.Headers.Add("Return-Receipt-To", fromEmail);
                        }

                        if (headerName != null && headerName.Trim().Length > 0)
                        {
                            message.Headers.Add(headerName, headerValue);
                        }

                        if (attachments != null)
                        {
                            for (int i = 0; i < attachments.Length; i++)
                            {
                                if (attachments[i] != null)
                                {
                                    message.Attachments.Add((Attachment)attachments[i]);
                                }
                            }
                        }

                        // Send SMTP mail
                        smtpClient.Send(message);
                    }
                    catch (Exception ex)
                    {
                        bOK = false;
                        _logger.Error(methodName, ex);
                    }
                }
            }
            return bOK;
        }

        public static bool Send(string fromEmail, string fromName,
            string toEmail, string toName, string ccEmail, string cc,
            string subject, string body, string bcc, bool confirmation,
            object[] attachments, string replyTo, int emailHistID)
        {
            string methodName = "Send";
            bool bOK = true; // Assume OK

            string EnvironmentConfig = string.Empty;
            string EnvironmentName = string.Empty;
            string TestEmail = string.Empty;
            string BCCEmail = string.Empty;

            try
            {
                EnvironmentConfig = ConfigurationManager.AppSettings["Environment"] == null ? "" : ConfigurationManager.AppSettings["Environment"].ToUpper(); // if not PROD, append a notice to the subject line
            }
            catch { }

            try
            {
                TestEmail = ConfigurationManager.AppSettings["TestEmail"] == null ? "" : ConfigurationManager.AppSettings["TestEmail"].Trim(); // if the key exists, substitute TO addresses with that value and remove any CC   <add key="TestEmail" value="jwigdor@nycsca.org" />
            }
            catch { }

            try
            {
                BCCEmail = ConfigurationManager.AppSettings["BCCEmail"] == null ? "" : ConfigurationManager.AppSettings["BCCEmail"].Trim(); // if the key exists, add that value as a BCC on all emails
            }
            catch { }

            // fail:safe .. only branch to the test parameters if we're positively in a test environment
            if (EnvironmentConfig == "DEV" || EnvironmentConfig == "QA" || EnvironmentConfig == "UAT" || EnvironmentConfig == "TEST")
            {
                EnvironmentName = "(" + EnvironmentConfig + " EMAIL) ";
            }

            using (SmtpClient smtpClient = new SmtpClient())
            {
                using (MailMessage message = new MailMessage())
                {
                    try
                    {
                        if (ConfigurationManager.AppSettings["SMTPServer"] != null &&
                            ConfigurationManager.AppSettings["SMTPServer"] != string.Empty)
                            smtpClient.Host = ConfigurationManager.AppSettings["SMTPServer"];

                        string footer = ConfigurationManager.AppSettings["EmailFooter"];

                        string headerName = ConfigurationManager.AppSettings["CustomHeaderName"];
                        string headerValue = ConfigurationManager.AppSettings["CustomHeaderValue"];

                        int port = ConvertUtility.ConvertInt(ConfigurationManager.AppSettings["SMTPPort"]);
                        if (port > 0)
                            smtpClient.Port = port;

                        if (!string.IsNullOrEmpty(fromName) && fromName.Trim().Length > 0)
                            message.From = new MailAddress(fromEmail, fromName);
                        else
                            message.From = new MailAddress(fromEmail);

                        /*
                             ** ADDRESS HANDLING **
                            
                            First, substitute/remove addresses if a test address has been specified in the web.config

                            Add all specified email addresses as MailAddress objects to the MailMessaage object

                            If a BCC address specified in web.config, add it

                        */ 

                        // set up address lists
                        toEmail = toEmail.TrimEnd(new char[] { ';', ',', ' ' });
                        List<string> toEmails = toEmail.Split(new char[] { ';', ',', ' ' }).ToList();

                        ccEmail = ccEmail.TrimEnd(new char[] { ';', ',', ' ' });
                        List<string> ccEmails = ccEmail.Split(new char[] { ';', ',', ' ' }).ToList();

                        bcc = bcc.TrimEnd(new char[] { ';', ',', ' ' });
                        List<string> bccEmails = bcc.Split(new char[] { ';', ',', ' ' }).ToList();

                        // if a test address was specified, remove all specified addresses and substitute the To: address w/ the test addr
                        if (TestEmail.Length > 0) 
                        {
                            toEmails.Clear();
                            toEmails.Add(TestEmail);

                            ccEmails.Clear();

                            bccEmails.Clear();
                        }

                        //
                        // ************* TO: ADDRESSES ************************************************************
                        //

                        // if there's only one address, include the recip name also
                        if (toEmails.Count == 1)
                        {
                            MailAddress toAddress;

                            // if to recipient display name as been specified ("toName"), include it
                            if (!string.IsNullOrEmpty(toName.Trim()))
                                toAddress = new MailAddress(toEmails[0].Trim(), toName.Trim());
                            else
                                toAddress = new MailAddress(toEmails[0].Trim());

                            message.To.Add(toAddress);
                        }
                        else
                        {
                            foreach(string thisTO in toEmails)
                            {
                                if (thisTO.Trim().Length > 0)
                                {
                                    MailAddress toAddress = new MailAddress(thisTO.Trim());
                                    if (!message.To.Contains(toAddress))
                                    {
                                        message.To.Add(toAddress);
                                    }
                                }
                            }
                        }

                        //
                        // ************* CC: ADDRESSES ************************************************************
                        //

                        foreach(string thisCC in ccEmails)
                        {
                            if (thisCC.Trim().Length > 0)
                            {
                                MailAddress ccAddress;

                                // if cc recipient display name has been specified ("cc"), include it
                                if (ccEmails.Count == 1 && cc.Trim().Length > 0)
                                    ccAddress = new MailAddress(thisCC.Trim(), cc.Trim());
                                else
                                    ccAddress = new MailAddress(thisCC.Trim());

                                if (!message.CC.Contains(ccAddress))
                                {
                                    message.CC.Add(ccAddress);
                                }
                            }
                        }

                        //
                        // ************* BCC: ADDRESSES ************************************************************
                        //


                        // FORCE BCC EMAIL IF BCCEMAIL SPECIFIED
                        if (BCCEmail.Length > 0) // bcc email was specified so add that to bcc collection
                        {
                            bccEmails.Add(BCCEmail);
                        }

                        foreach(string thisBCC in bccEmails)
                        {
                            if (thisBCC.Trim().Length > 0)
                            {
                                MailAddress bccAddress = new MailAddress(thisBCC.Trim());
                                if (!message.Bcc.Contains(bccAddress))
                                {
                                    message.Bcc.Add(bccAddress);
                                }
                            }
                        }

                        if (replyTo.Trim().Length > 0)
                        {
                            message.ReplyTo = new MailAddress(replyTo);
                        }

                        message.IsBodyHtml = true;

                        message.Subject = EnvironmentName + subject;

                        // Message body content
                        message.Body = body + "<br />" + footer;

                        if (confirmation)
                        {
                            message.Headers.Add("Disposition-Notification-To", fromEmail);
                            message.Headers.Add("Return-Receipt-To", fromEmail);
                        }

                        if (headerName != null && headerName.Trim().Length > 0)
                        {
                            message.Headers.Add(headerName, headerValue);
                        }

                        if (attachments != null)
                        {
                            for (int i = 0; i < attachments.Length; i++)
                            {
                                if (attachments[i] != null)
                                {
                                    Attachment att = (Attachment)attachments[i];

                                    // attach passed-in attachments to the smtp msg object 
                                    message.Attachments.Add(att);

                                    // save attachment to ECM
                                    try
                                    {
                                        // create byte array
                                        System.IO.Stream st = att.ContentStream;
                                        System.IO.BinaryReader br = new System.IO.BinaryReader(st);
                                        byte[] attbytes = br.ReadBytes((Int32)st.Length);

                                        // set up VASDocument
                                        VASDocument vdoc = new VASDocument();
                                        vdoc.Contents = attbytes;
                                        vdoc.Repository = VASDocument.RepositoryType.VAS;
                                        vdoc.EIN = "Attachments";
                                        vdoc.DocType = "Email";

                                        // use wrapper to store document
                                        long AttID = DocServiceHelper.UploadDoc(vdoc);

                                        // save the returned ECM docID
                                        EmailAttachment emailAttachment = EmailAttachmentUtility.CreateObject();
                                        emailAttachment.EmailHistoryId = emailHistID;
                                        emailAttachment.Filename = att.Name;
                                        emailAttachment.AttachmentId = AttID;
                                        EmailAttachmentUtility.Update("User", emailAttachment);

                                        message.Attachments[i].ContentStream.Position = 0; // IN00173183, required to prevent empty attachments
                                    }
                                    catch (Exception ex)
                                    {
                                        // only log?  continue if no ecm?
                                        _logger.Error(methodName + " attachment save", ex);
                                    }
                                }
                            }
                        }

                        // Send SMTP mail
                        smtpClient.Send(message);
                    }
                    catch (Exception ex)
                    {
                        bOK = false;
                        _logger.Error(methodName, ex);
                    }
                }
            }
            return bOK;
        }

        public static bool Send(string fromEmail, string toEmail, string ccEmail, string cc,
            string subject, string body, string bcc, bool confirmation, object[] attachments,
            string replyTo, int emailHistID)
        {

            bool ret = Send(fromEmail, "", toEmail, "", ccEmail, cc, subject, body, bcc, confirmation, attachments, replyTo, emailHistID);
            return ret;

            //***********************************************************************************
            // the other .Send() method had been copied here long ago just because this override didn't use fromName/toName
            //   the other Send() has been changed to handle them being Length==0
            //***********************************************************************************

        }

        public static string Replace(string originalString, object[] emailableObjs)
        {
            originalString = originalString.Replace("$DATE$", DateTime.Now.ToShortDateString());

            if (emailableObjs != null)
            {
                for (int i = 0; i < emailableObjs.Length; i++)
                {
                    if (emailableObjs[i] != null)
                    {
                        if (emailableObjs[i] is database)
                        {
                            originalString = originalString.Replace("$COMPANY$", ((database)emailableObjs[i]).company);
                            originalString = originalString.Replace("$ADMINEMAIL$", ((database)emailableObjs[i]).adminEmail);
                            originalString = Regex.Replace(originalString, "\\$SITEURL\\$", ((database)emailableObjs[i]).siteUrl, RegexOptions.IgnoreCase);
                        }
                        else
                            originalString = ((IEmailable)emailableObjs[i]).Replace(originalString);
                    }
                }
            }

            //replace some common field configured in web.config file.
            originalString = originalString.Replace("$ADMINEMAIL$", ConfigurationManager.AppSettings["AdminEmail"]);
            originalString = originalString.Replace("$COMPANY$", ConfigurationManager.AppSettings["Company"]);
            if (ConfigurationManager.AppSettings["SiteUrl"] != null)
            {
                originalString = Regex.Replace(originalString, "\\$SITEURL\\$", ConfigurationManager.AppSettings["SiteUrl"], RegexOptions.IgnoreCase);
            }
            if (ConfigurationManager.AppSettings["CESSiteUrl"] != null)
            {
                originalString = Regex.Replace(originalString, "\\$CESSITEURL\\$", ConfigurationManager.AppSettings["CESSiteUrl"], RegexOptions.IgnoreCase);
            }
            if (ConfigurationManager.AppSettings["InternalSiteUrl"] != null)
            {
                originalString = Regex.Replace(originalString, "\\$INTERNALSITEURL\\$", ConfigurationManager.AppSettings["InternalSiteUrl"], RegexOptions.IgnoreCase);
            }

            return originalString;
        }
        #endregion
    }
}
