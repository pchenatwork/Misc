
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class AccountTypeUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly AccountTypeManagerFactory _accountTypeManagerFactory = 
			( AccountTypeManagerFactory ) AccountTypeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static AccountTypeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( AccountTypeUtility ).FullName);
		}

		private AccountTypeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static AccountType CreateObject( )
		{
			AccountTypeManager accountTypeManager = ( AccountTypeManager ) _accountTypeManagerFactory.CreateInstance( );

			return ( AccountType )accountTypeManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, AccountType accountType )
		{
			AccountTypeManager accountTypeManager = ( AccountTypeManager ) _accountTypeManagerFactory.CreateInstance( dataSourceName );

			return accountTypeManager.Create( accountType );
		}
		
		public static bool Update( string dataSourceName, AccountType accountType )
		{
			AccountTypeManager accountTypeManager = ( AccountTypeManager ) _accountTypeManagerFactory.CreateInstance( dataSourceName );

			return accountTypeManager.Update( accountType );
		}
		
		public static bool Delete( string dataSourceName, int id )
		{
			AccountTypeManager accountTypeManager = ( AccountTypeManager ) _accountTypeManagerFactory.CreateInstance( dataSourceName );

			return accountTypeManager.Delete( id );
		}

		public static AccountType Get( string dataSourceName, int id )
		{
			AccountTypeManager accountTypeManager = ( AccountTypeManager ) _accountTypeManagerFactory.CreateInstance( dataSourceName );

			return ( AccountType )accountTypeManager.Get( id );
		}

		public static AccountTypeCollection GetAll(string dataSourceName)
		{
			AccountTypeManager accountTypeManager = (AccountTypeManager)_accountTypeManagerFactory.CreateInstance(dataSourceName);

			return (AccountTypeCollection)accountTypeManager.GetAll();
		}

		public static AccountTypeCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			AccountTypeManager accountTypeManager = ( AccountTypeManager ) _accountTypeManagerFactory.CreateInstance( dataSourceName );

			return ( AccountTypeCollection )accountTypeManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}