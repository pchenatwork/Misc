#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class AuditlogUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly AuditlogManagerFactory _raceManagerFactory = 
			(AuditlogManagerFactory) AuditlogManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static AuditlogUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof(AuditlogUtility).FullName);
		}

		private AuditlogUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Auditlog CreateObject( )
		{
            AuditlogManager manager = (AuditlogManager) _raceManagerFactory.CreateInstance( );

			return (Auditlog)manager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, Auditlog audit )
		{
            AuditlogManager manager = (AuditlogManager) _raceManagerFactory.CreateInstance( dataSourceName );

			return manager.Create( audit );
		}

		public static bool Update( string dataSourceName, Auditlog audit )
		{
            AuditlogManager manager = (AuditlogManager) _raceManagerFactory.CreateInstance( dataSourceName );

			return manager.Update( audit );
		}

        public static void UpdateBidandAward(string dataSourceName, int projectid, string keynote, int entityid = 0)
        {
            AuditlogManager manager = (AuditlogManager)_raceManagerFactory.CreateInstance(dataSourceName);

            manager.UpdateBidandAward(projectid, keynote, entityid);
        }

        public static void SuspendAWhile(string dataSourceName, int projectid, bool totalSuspension = true, bool retainDates = true)
        {
            AuditlogManager manager = (AuditlogManager)_raceManagerFactory.CreateInstance(dataSourceName);

            manager.SuspendAWhile(projectid, totalSuspension, retainDates);
        }

        public static bool Delete( string dataSourceName, int id )
		{
            AuditlogManager manager = (AuditlogManager) _raceManagerFactory.CreateInstance( dataSourceName );

			return manager.Delete( id );
		}

		public static Auditlog Get( string dataSourceName, int id )
		{
            AuditlogManager manager = (AuditlogManager) _raceManagerFactory.CreateInstance( dataSourceName );

			return ( Auditlog )manager.Get( id );
		}

		
		#endregion

	}
}
