#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class QuestionTypeUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly QuestionTypeManagerFactory _questionTypeManagerFactory = 
			( QuestionTypeManagerFactory ) QuestionTypeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static QuestionTypeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( QuestionTypeUtility ).FullName);
		}

		private QuestionTypeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static QuestionType CreateObject( )
		{
			QuestionTypeManager questionTypeManager = ( QuestionTypeManager ) _questionTypeManagerFactory.CreateInstance( );

			return ( QuestionType )questionTypeManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, QuestionType questionType )
		{
			QuestionTypeManager questionTypeManager = ( QuestionTypeManager ) _questionTypeManagerFactory.CreateInstance( dataSourceName );

			return questionTypeManager.Create( questionType );
		}

		public static bool Update( string dataSourceName, QuestionType questionType )
		{
			QuestionTypeManager questionTypeManager = ( QuestionTypeManager ) _questionTypeManagerFactory.CreateInstance( dataSourceName );

			return questionTypeManager.Update( questionType );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			QuestionTypeManager questionTypeManager = ( QuestionTypeManager ) _questionTypeManagerFactory.CreateInstance( dataSourceName );

			return questionTypeManager.Delete( id );
		}

		public static QuestionType Get( string dataSourceName, int id )
		{
			QuestionTypeManager questionTypeManager = ( QuestionTypeManager ) _questionTypeManagerFactory.CreateInstance( dataSourceName );

			return ( QuestionType )questionTypeManager.Get( id );
		}

		public static QuestionTypeCollection GetAll( string dataSourceName  )
		{
			QuestionTypeManager questionTypeManager = ( QuestionTypeManager ) _questionTypeManagerFactory.CreateInstance( dataSourceName );

			return ( QuestionTypeCollection )questionTypeManager.GetAll( );
		}


		public static QuestionTypeCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			QuestionTypeManager questionTypeManager = ( QuestionTypeManager ) _questionTypeManagerFactory.CreateInstance( dataSourceName );

			return ( QuestionTypeCollection )questionTypeManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
