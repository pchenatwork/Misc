#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class BusinessClassificationUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BusinessClassificationManagerFactory _businessClassificationManagerFactory = 
			( BusinessClassificationManagerFactory ) BusinessClassificationManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BusinessClassificationUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BusinessClassificationUtility ).FullName);
		}

		private BusinessClassificationUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static BusinessClassification CreateObject( )
		{
			BusinessClassificationManager businessClassificationManager = ( BusinessClassificationManager ) _businessClassificationManagerFactory.CreateInstance( );

			return ( BusinessClassification )businessClassificationManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, BusinessClassification businessClassification )
		{
			BusinessClassificationManager businessClassificationManager = ( BusinessClassificationManager ) _businessClassificationManagerFactory.CreateInstance( dataSourceName );

			return businessClassificationManager.Create( businessClassification );
		}

		public static bool Update( string dataSourceName, BusinessClassification businessClassification )
		{
			BusinessClassificationManager businessClassificationManager = ( BusinessClassificationManager ) _businessClassificationManagerFactory.CreateInstance( dataSourceName );

			return businessClassificationManager.Update( businessClassification );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			BusinessClassificationManager businessClassificationManager = ( BusinessClassificationManager ) _businessClassificationManagerFactory.CreateInstance( dataSourceName );

			return businessClassificationManager.Delete( id );
		}

		public static BusinessClassification Get( string dataSourceName, int id )
		{
			BusinessClassificationManager businessClassificationManager = ( BusinessClassificationManager ) _businessClassificationManagerFactory.CreateInstance( dataSourceName );

			return ( BusinessClassification )businessClassificationManager.Get( id );
		}

		public static BusinessClassificationCollection GetAll( string dataSourceName  )
		{
			BusinessClassificationManager businessClassificationManager = ( BusinessClassificationManager ) _businessClassificationManagerFactory.CreateInstance( dataSourceName );

			return ( BusinessClassificationCollection )businessClassificationManager.GetAll( );
		}

		#endregion

	}
}
