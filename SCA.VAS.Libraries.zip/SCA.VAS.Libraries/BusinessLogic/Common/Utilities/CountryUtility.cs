#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class CountryUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly CountryManagerFactory _countryManagerFactory = 
			( CountryManagerFactory ) CountryManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static CountryUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CountryUtility ).FullName);
		}

		private CountryUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Country CreateObject( )
		{
			CountryManager countryManager = ( CountryManager ) _countryManagerFactory.CreateInstance( );

			return ( Country )countryManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, Country country )
		{
			CountryManager countryManager = ( CountryManager ) _countryManagerFactory.CreateInstance( dataSourceName );

			return countryManager.Create( country );
		}

		public static bool Update( string dataSourceName, Country country )
		{
			CountryManager countryManager = ( CountryManager ) _countryManagerFactory.CreateInstance( dataSourceName );

			return countryManager.Update( country );
		}

        public static bool UpdateCollection(string dataSourceName, CountryCollection collection)
        {
            CountryManager countryManager = (CountryManager)_countryManagerFactory.CreateInstance(dataSourceName);

            return countryManager.UpdateCollection(collection);
        }

		public static bool Delete( string dataSourceName, int id )
		{
			CountryManager countryManager = ( CountryManager ) _countryManagerFactory.CreateInstance( dataSourceName );

			return countryManager.Delete( id );
		}

		public static Country Get( string dataSourceName, int id )
		{
			CountryManager countryManager = ( CountryManager ) _countryManagerFactory.CreateInstance( dataSourceName );

			return ( Country )countryManager.Get( id );
		}

        public static Country GetByCode(string dataSourceName, string abbreviation)
        {
            CountryManager countryManager = (CountryManager)_countryManagerFactory.CreateInstance(dataSourceName);

            return (Country)countryManager.GetByCode(abbreviation);
        }

		public static CountryCollection GetAll( string dataSourceName  )
		{
			CountryManager countryManager = ( CountryManager ) _countryManagerFactory.CreateInstance( dataSourceName );

			return ( CountryCollection )countryManager.GetAll( );
		}

        public static CountryCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            CountryManager countryManager = (CountryManager)_countryManagerFactory.CreateInstance(dataSourceName);

            return (CountryCollection)countryManager.FindByCriteria(finderType, criteria);
        }

		public static DataSet FindDataSetByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			CountryManager countryManager = ( CountryManager ) _countryManagerFactory.CreateInstance( dataSourceName );

			return countryManager.FindDataSetByCriteria( finderType, criteria );
		}
		#endregion

	}
}
