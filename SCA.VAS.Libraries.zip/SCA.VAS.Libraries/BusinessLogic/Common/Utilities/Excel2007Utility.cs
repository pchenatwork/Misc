using System;
using System.Collections;
using System.Data;
using System.Data.OleDb;

using log4net;

using SCA.VAS.Common.Utilities;

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Summary description for Excel2007Utility.
	/// </summary>
	public class Excel2007Utility
	{
		/*
		 No references, disabled after VERACODE security scan detected vulnerabilities 
		 */

		//	private static ILog _logger = null;

		//	static Excel2007Utility()
		//	{
		//		_logger	= LoggingUtility.GetLogger( typeof( Excel2007Utility ).FullName);
		//	} 

		//	public Excel2007Utility()
		//	{
		//	}

		//	public static ArrayList WorksheetNames( string fileName )
		//	{
		//		string methodName = "WorksheetNames";
		//		if ( _logger.IsDebugEnabled )
		//		{
		//			LoggingUtility.logMethodEntry( _logger, methodName );
		//		}
		//		ArrayList sheetNames = new ArrayList();
		//		OleDbConnection connection = null;
		//		try
		//		{
		//               connection = DbUtility.GetOleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;" +
		//                   "Data Source=" + fileName + ";Extended Properties=\"Excel 12.0 Xml;HDR=NO;IMEX=1;\"");

		//			DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, 
		//				null);

		//			// List the table name from each row in the schema table.
		//			for (int i = 0; i < schemaTable.Rows.Count; i++) 
		//			{
		//				sheetNames.Add(schemaTable.Rows[i].ItemArray[2].ToString());
		//			}
		//		}
		//		catch ( System.Exception e )
		//		{
		//			_logger.Error( methodName, e );
		//			return null;
		//		}
		//		finally
		//		{
		//			DbUtility.Close( connection );
		//		}
		//		return sheetNames;
		//	}

		//	public static DataSet GetWorksheet( string fileName, string sheetName, bool hasHeader )
		//	{
		//		string methodName = "GetWorksheet";
		//		if ( _logger.IsDebugEnabled )
		//		{
		//			LoggingUtility.logMethodEntry( _logger, methodName );
		//		}
		//		OleDbConnection connection = null;
		//		try
		//		{
		//               connection = DbUtility.GetOleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;" +
		//                   "Data Source=" + fileName + ";Extended Properties=\"Excel 12.0 Xml;HDR=" +
		//                   (hasHeader ? "YES" : "NO") + ";IMEX=1;\"");

		//			//create a command and prepare it for execution
		//			OleDbCommand cmd = new OleDbCommand();

		//			/* veracode wants prepared statement here.  saw this online for oledb:

		//					command.CommandText =
		//						"INSERT INTO dbo.Region (RegionID, RegionDescription) VALUES (?, ?)";
		//					command.Parameters.Add("RegionID", OleDbType.Integer, 4);
		//					command.Parameters.Add("RegionDescription", OleDbType.VarWChar, 50);
		//					command.Parameters[0].Value = 20;
		//					command.Parameters[1].Value = "First Region";

		//					// Call  Prepare and ExecuteNonQuery.
		//					command.Prepare();

		//			 */

		//			//associate the connection with the command
		//			cmd.Connection = connection;
		//			//set the command text
		//			cmd.CommandText = "select * from [" + sheetName + "]";
		//			//set the command type
		//			cmd.CommandType = CommandType.Text;

		//			//create the DataAdapter & DataSet
		//			OleDbDataAdapter da = new OleDbDataAdapter(cmd);
		//			DataSet ds = new DataSet();

		//			//fill the DataSet using default values for DataTable names, etc.
		//			da.Fill(ds);

		//			//return the dataset
		//			return ds;
		//		}
		//		catch ( System.Exception e )
		//		{
		//			_logger.Error( methodName, e );
		//			return null;
		//		}
		//		finally
		//		{
		//			DbUtility.Close( connection );
		//		}
		//	}
	}
}
