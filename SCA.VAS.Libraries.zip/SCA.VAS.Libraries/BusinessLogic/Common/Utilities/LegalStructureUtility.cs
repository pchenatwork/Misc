#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class LegalStructureUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly LegalStructureManagerFactory _legalStructureManagerFactory = 
			( LegalStructureManagerFactory ) LegalStructureManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static LegalStructureUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( LegalStructureUtility ).FullName);
		}

		private LegalStructureUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static LegalStructure CreateObject( )
		{
			LegalStructureManager legalStructureManager = ( LegalStructureManager ) _legalStructureManagerFactory.CreateInstance( );

			return ( LegalStructure )legalStructureManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, LegalStructure legalStructure )
		{
			LegalStructureManager legalStructureManager = ( LegalStructureManager ) _legalStructureManagerFactory.CreateInstance( dataSourceName );

			return legalStructureManager.Create( legalStructure );
		}

		public static bool Update( string dataSourceName, LegalStructure legalStructure )
		{
			LegalStructureManager legalStructureManager = ( LegalStructureManager ) _legalStructureManagerFactory.CreateInstance( dataSourceName );

			return legalStructureManager.Update( legalStructure );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			LegalStructureManager legalStructureManager = ( LegalStructureManager ) _legalStructureManagerFactory.CreateInstance( dataSourceName );

			return legalStructureManager.Delete( id );
		}

		public static LegalStructure Get( string dataSourceName, int id )
		{
			LegalStructureManager legalStructureManager = ( LegalStructureManager ) _legalStructureManagerFactory.CreateInstance( dataSourceName );

			return ( LegalStructure )legalStructureManager.Get( id );
		}

		public static LegalStructureCollection GetAll( string dataSourceName  )
		{
			LegalStructureManager legalStructureManager = ( LegalStructureManager ) _legalStructureManagerFactory.CreateInstance( dataSourceName );

			return ( LegalStructureCollection )legalStructureManager.GetAll( );
		}

		public static LegalStructureCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			LegalStructureManager legalStructureManager = ( LegalStructureManager ) _legalStructureManagerFactory.CreateInstance( dataSourceName );

			return ( LegalStructureCollection )legalStructureManager.FindByCriteria( finderType, criteria );
		}
		
		#endregion

	}
}
