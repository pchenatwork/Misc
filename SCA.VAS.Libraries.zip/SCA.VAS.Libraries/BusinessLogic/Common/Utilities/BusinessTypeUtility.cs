#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class BusinessTypeUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BusinessTypeManagerFactory _businessTypeManagerFactory = 
			( BusinessTypeManagerFactory ) BusinessTypeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BusinessTypeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BusinessTypeUtility ).FullName);
		}

		private BusinessTypeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static BusinessType CreateObject( )
		{
			BusinessTypeManager businessTypeManager = ( BusinessTypeManager ) _businessTypeManagerFactory.CreateInstance( );

			return ( BusinessType )businessTypeManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, BusinessType businessType )
		{
			BusinessTypeManager businessTypeManager = ( BusinessTypeManager ) _businessTypeManagerFactory.CreateInstance( dataSourceName );

			return businessTypeManager.Create( businessType );
		}

		public static bool Update( string dataSourceName, BusinessType businessType )
		{
			BusinessTypeManager businessTypeManager = ( BusinessTypeManager ) _businessTypeManagerFactory.CreateInstance( dataSourceName );

			return businessTypeManager.Update( businessType );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			BusinessTypeManager businessTypeManager = ( BusinessTypeManager ) _businessTypeManagerFactory.CreateInstance( dataSourceName );

			return businessTypeManager.Delete( id );
		}

		public static BusinessType Get( string dataSourceName, int id )
		{
			BusinessTypeManager businessTypeManager = ( BusinessTypeManager ) _businessTypeManagerFactory.CreateInstance( dataSourceName );

			return ( BusinessType )businessTypeManager.Get( id );
		}

		public static BusinessTypeCollection GetAll( string dataSourceName  )
		{
			BusinessTypeManager businessTypeManager = ( BusinessTypeManager ) _businessTypeManagerFactory.CreateInstance( dataSourceName );

			return ( BusinessTypeCollection )businessTypeManager.GetAll( );
		}

        public static BusinessTypeCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            BusinessTypeManager businessTypeManager = (BusinessTypeManager)_businessTypeManagerFactory.CreateInstance(dataSourceName);

            return (BusinessTypeCollection)businessTypeManager.FindByCriteria(finderType, criteria);
        }
		#endregion

	}
}
