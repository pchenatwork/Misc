#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class BrandUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BrandManagerFactory _brandManagerFactory = 
			( BrandManagerFactory ) BrandManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BrandUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BrandUtility ).FullName);
		}

		private BrandUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Brand CreateObject( )
		{
			BrandManager brandManager = ( BrandManager ) _brandManagerFactory.CreateInstance( );

			return ( Brand )brandManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, Brand brand )
		{
			BrandManager brandManager = ( BrandManager ) _brandManagerFactory.CreateInstance( dataSourceName );

			return brandManager.Create( brand );
		}

		public static bool Update( string dataSourceName, Brand brand )
		{
			BrandManager brandManager = ( BrandManager ) _brandManagerFactory.CreateInstance( dataSourceName );

			return brandManager.Update( brand );
		}

        public static bool UpdateGlobalId(string dataSourceName, int id, int globalId)
        {
            BrandManager brandManager = (BrandManager)_brandManagerFactory.CreateInstance(dataSourceName);

            return brandManager.UpdateGlobalId(id, globalId);
        }

        public static int Import(string dataSourceName, string xml)
        {
            BrandManager brandManager = (BrandManager)_brandManagerFactory.CreateInstance(dataSourceName);

            return brandManager.Import(xml);
        }

		public static bool Delete( string dataSourceName, int id )
		{
			BrandManager brandManager = ( BrandManager ) _brandManagerFactory.CreateInstance( dataSourceName );

			return brandManager.Delete( id );
		}

		public static Brand Get( string dataSourceName, int id )
		{
			BrandManager brandManager = ( BrandManager ) _brandManagerFactory.CreateInstance( dataSourceName );

			return ( Brand )brandManager.Get( id );
		}

		public static BrandCollection GetAll( string dataSourceName  )
		{
			BrandManager brandManager = ( BrandManager ) _brandManagerFactory.CreateInstance( dataSourceName );

			return ( BrandCollection )brandManager.GetAll( );
		}

        public static BrandCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            BrandManager brandManager = (BrandManager)_brandManagerFactory.CreateInstance(dataSourceName);

            return (BrandCollection)brandManager.FindByCriteria(finderType, criteria);
        }
		#endregion

	}
}
