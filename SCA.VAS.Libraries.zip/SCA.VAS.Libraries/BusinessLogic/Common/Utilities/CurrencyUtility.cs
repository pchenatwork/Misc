#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class CurrencyUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly CurrencyManagerFactory _currencyManagerFactory = 
			( CurrencyManagerFactory ) CurrencyManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static CurrencyUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CurrencyUtility ).FullName);
		}

		private CurrencyUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Currency CreateObject( )
		{
			CurrencyManager currencyManager = ( CurrencyManager ) _currencyManagerFactory.CreateInstance( );

			return ( Currency )currencyManager.CreateObject( );
		}
	
		public static bool Create( string dataSourceName, Currency currency )
		{
			CurrencyManager currencyManager = ( CurrencyManager ) _currencyManagerFactory.CreateInstance( dataSourceName );

			return currencyManager.Create( currency );
		}

		public static bool Update( string dataSourceName, Currency currency )
		{
			CurrencyManager currencyManager = ( CurrencyManager ) _currencyManagerFactory.CreateInstance( dataSourceName );

			return currencyManager.Update( currency );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			CurrencyManager currencyManager = ( CurrencyManager ) _currencyManagerFactory.CreateInstance( dataSourceName );

			return currencyManager.Delete( id );
		}

		public static Currency Get( string dataSourceName, int id )
		{
			CurrencyManager currencyManager = ( CurrencyManager ) _currencyManagerFactory.CreateInstance( dataSourceName );

			return ( Currency )currencyManager.Get( id );
		}

        public static Currency GetByName(string dataSourceName, string name)
        {
            CurrencyManager currencyManager = (CurrencyManager)_currencyManagerFactory.CreateInstance(dataSourceName);

            return (Currency)currencyManager.GetByName(name);
        }

		public static CurrencyCollection GetAll( string dataSourceName  )
		{
			CurrencyManager currencyManager = ( CurrencyManager ) _currencyManagerFactory.CreateInstance( dataSourceName );

			return ( CurrencyCollection )currencyManager.GetAll( );
		}

        public static CurrencyCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            CurrencyManager currencyManager = (CurrencyManager)_currencyManagerFactory.CreateInstance(dataSourceName);

            return (CurrencyCollection)currencyManager.FindByCriteria(finderType, criteria);
        }
		#endregion

	}
}
