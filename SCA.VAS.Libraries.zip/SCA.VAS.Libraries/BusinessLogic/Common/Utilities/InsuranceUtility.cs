#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class InsuranceUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly InsuranceManagerFactory _insuranceManagerFactory = 
			( InsuranceManagerFactory ) InsuranceManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static InsuranceUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( InsuranceUtility ).FullName);
		}

		private InsuranceUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Insurance CreateObject( )
		{
			InsuranceManager insuranceManager = ( InsuranceManager ) _insuranceManagerFactory.CreateInstance( );

			return ( Insurance )insuranceManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, Insurance insurance )
		{
			InsuranceManager insuranceManager = ( InsuranceManager ) _insuranceManagerFactory.CreateInstance( dataSourceName );

			return insuranceManager.Create( insurance );
		}

		public static bool Update( string dataSourceName, Insurance insurance )
		{
			InsuranceManager insuranceManager = ( InsuranceManager ) _insuranceManagerFactory.CreateInstance( dataSourceName );

			return insuranceManager.Update( insurance );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			InsuranceManager insuranceManager = ( InsuranceManager ) _insuranceManagerFactory.CreateInstance( dataSourceName );

			return insuranceManager.Delete( id );
		}

		public static Insurance Get( string dataSourceName, int id )
		{
			InsuranceManager insuranceManager = ( InsuranceManager ) _insuranceManagerFactory.CreateInstance( dataSourceName );

			return ( Insurance )insuranceManager.Get( id );
		}

		public static InsuranceCollection GetAll( string dataSourceName  )
		{
			InsuranceManager insuranceManager = ( InsuranceManager ) _insuranceManagerFactory.CreateInstance( dataSourceName );

			return ( InsuranceCollection )insuranceManager.GetAll( );
		}

        public static InsuranceCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            InsuranceManager insuranceManager = (InsuranceManager)_insuranceManagerFactory.CreateInstance(dataSourceName);

            return (InsuranceCollection)insuranceManager.FindByCriteria(finderType, criteria);
        }
		#endregion

	}
}
