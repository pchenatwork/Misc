#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class JobTitleUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly JobTitleManagerFactory _jobTitleManagerFactory = 
			( JobTitleManagerFactory ) JobTitleManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static JobTitleUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( JobTitleUtility ).FullName);
		}

		private JobTitleUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static JobTitle CreateObject( )
		{
			JobTitleManager jobTitleManager = ( JobTitleManager ) _jobTitleManagerFactory.CreateInstance( );

			return ( JobTitle )jobTitleManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, JobTitle jobTitle )
		{
			JobTitleManager jobTitleManager = ( JobTitleManager ) _jobTitleManagerFactory.CreateInstance( dataSourceName );

			return jobTitleManager.Create( jobTitle );
		}

		public static bool Update( string dataSourceName, JobTitle jobTitle )
		{
			JobTitleManager jobTitleManager = ( JobTitleManager ) _jobTitleManagerFactory.CreateInstance( dataSourceName );

			return jobTitleManager.Update( jobTitle );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			JobTitleManager jobTitleManager = ( JobTitleManager ) _jobTitleManagerFactory.CreateInstance( dataSourceName );

			return jobTitleManager.Delete( id );
		}

		public static JobTitle Get( string dataSourceName, int id )
		{
			JobTitleManager jobTitleManager = ( JobTitleManager ) _jobTitleManagerFactory.CreateInstance( dataSourceName );

			return ( JobTitle )jobTitleManager.Get( id );
		}

		public static JobTitleCollection GetAll( string dataSourceName  )
		{
			JobTitleManager jobTitleManager = ( JobTitleManager ) _jobTitleManagerFactory.CreateInstance( dataSourceName );

			return ( JobTitleCollection )jobTitleManager.GetAll( );
		}

		#endregion

	}
}
