using System;
using System.Xml;
using System.IO;
using System.Text;
using System.Collections;

using log4net;

using SCA.VAS.Common.Utilities;

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	///		Flat-File to XML Converter
	/// </summary>
	public class FlatFileToXmlUtility {

		string _csvPath;
		XmlDocument _mapDoc;
		XmlTextWriter writer;

        private static ILog _logger = null;

		static FlatFileToXmlUtility()
		{
            _logger = LoggingUtility.GetLogger(typeof(FlatFileToXmlUtility).FullName);
		}

        public FlatFileToXmlUtility()
		{
		}

		public FlatFileToXmlUtility(string csvPath,string xmlMap) {
			_csvPath = csvPath;
			try {
				_mapDoc = new XmlDocument();
				_mapDoc.Load(xmlMap);
			} 
			catch {}
		}

		public Stream Transform() {
			StreamReader reader = null;
			XmlElement root = _mapDoc.DocumentElement;
			string line = null;
			MemoryStream stream = null;
			try {
				if (_mapDoc == null) return null;
				char[] delimiter = null;
				if (root.GetAttribute("delimiter") != null && 
					root.GetAttribute("delimiter") != String.Empty) {
					delimiter = root.GetAttribute("delimiter").ToCharArray();
				}
                char[] qualifier = null;
                if (root.GetAttribute("qualifier") != null &&
                    root.GetAttribute("qualifier") != String.Empty)
                {
                    qualifier = root.GetAttribute("qualifier").ToCharArray();
                }
				stream = new MemoryStream();
				writer = new XmlTextWriter(stream, null);
				writer.Formatting = Formatting.Indented;
				writer.WriteStartDocument();
				writer.WriteStartElement(root.GetAttribute("root"));
				reader = new StreamReader(new FileStream(_csvPath,
					FileMode.Open,FileAccess.Read));
                string header = root.GetAttribute("header");
                if (header == "Y")
                    reader.ReadLine();
				while ((line = reader.ReadLine()) != null) {
					string[] tokens = null;
					if (delimiter == null) { //Handle fixed-length files
						tokens = SplitLine(line);
					} else {				 //Handle delimited files
						tokens = line.Split(delimiter);
					}
                    GenerateXml(tokens, qualifier);
                }
				writer.WriteEndElement(); //Close root element
				writer.Flush();
				return CopyStream(stream);
			}
            catch (Exception exp)
            {
                throw new ApplicationException(line + "Flat-file parsing errored out", exp);
            }
			finally {
				if (reader != null) {
					reader.Close();
				}
				if (writer != null) {
					writer.Close();
				}
			}
		}

		private Stream CopyStream(MemoryStream stream) {
			stream.Position = 0;
			//Return new stream so we can close
			//writer and its underlying stream
			MemoryStream outputStream = new MemoryStream();
			stream.WriteTo(outputStream);
			return outputStream;
		}

		private string[] Filter(string[] tokens) {
			ArrayList cleanedTokens = new ArrayList();
			for (int i=0;i<tokens.Length;i++) {
				string token = tokens[i];
				if (token != null && token.Trim().Length != 0) {
					//Check for "" text qualifier
					//Only handles 1 comma currently
					if (token.Substring(0,1) == "\"") {
						if (i != tokens.Length -1) {
							string endToken = tokens[i+1];
							if (endToken.Substring(endToken.Length-1) == "\"") {
								token = token.Remove(0,1) + "," + endToken.Remove(endToken.Length-1,1);
								i++;
							}
						}
					}
					cleanedTokens.Add(token);
				}
			}
			return (string[])cleanedTokens.ToArray(typeof(System.String));
		}

		private string[] SplitLine(string line) {
			XmlElement root = _mapDoc.DocumentElement;
			int currPos = 0;
			string[] tokens = new String[root.ChildNodes.Count];
			//Read through mapping file to know how to parse
			//string in order to generate token array
			for (int i=0;i<root.ChildNodes.Count;i++) 
            {
				XmlElement mapping = (XmlElement)root.ChildNodes[i];
				int endPos = Int32.Parse(mapping.GetAttribute("length"));
                string field = string.Empty;
                if (currPos + endPos <= line.Length)
                {
                    field = line.Substring(currPos, endPos);
                }
                else if (line.Length > currPos)
                {
                    field = line.Substring(currPos, line.Length - currPos);
                }
                tokens[i] = field.Trim();
                currPos += endPos;
			}
			return tokens;
		}

        private void GenerateXml(string[] tokens, char[] qualifier)
        {
			XmlElement root = _mapDoc.DocumentElement; //Get map root
			writer.WriteStartElement(root.GetAttribute("child")); //Create container
			//First add attribute nodes while child container is still open
			XmlNodeList atts = root.SelectNodes("./mapping[@type='Attribute']");
			foreach (XmlNode attNode in atts) {
                if (qualifier != null)
                    writer.WriteAttributeString(attNode.Attributes["name"].Value,
                        tokens[Int32.Parse(attNode.Attributes["pos"].Value)].ToString().TrimStart(qualifier).TrimEnd(qualifier).Trim());
                else
				    writer.WriteAttributeString(attNode.Attributes["name"].Value,
					    tokens[Int32.Parse(attNode.Attributes["pos"].Value)].ToString().Trim());
			}
            for (int i = 0; i < tokens.Length; i++)
            {
                XmlElement node = (XmlElement)root.SelectSingleNode("./mapping[@pos='" + i.ToString() + "' and @type='Element']");
                if (node != null)
                {
                    //mapping exists
                    if (qualifier != null)
                        writer.WriteElementString(node.GetAttribute("name"), tokens[i].ToString().TrimStart(qualifier).TrimEnd(qualifier));
                    else
                        writer.WriteElementString(node.GetAttribute("name"), tokens[i].ToString());
                }
            }
			writer.WriteEndElement(); //Close container
		}
	}
}
