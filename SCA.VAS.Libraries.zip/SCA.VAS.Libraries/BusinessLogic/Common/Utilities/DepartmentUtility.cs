#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class DepartmentUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly DepartmentManagerFactory _departmentManagerFactory = 
			( DepartmentManagerFactory ) DepartmentManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static DepartmentUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( DepartmentUtility ).FullName);
		}

		private DepartmentUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Department CreateObject( )
		{
			DepartmentManager departmentManager = ( DepartmentManager ) _departmentManagerFactory.CreateInstance( );

			return ( Department )departmentManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, Department department )
		{
			DepartmentManager departmentManager = ( DepartmentManager ) _departmentManagerFactory.CreateInstance( dataSourceName );

			return departmentManager.Create( department );
		}

		public static bool Update( string dataSourceName, Department department )
		{
			DepartmentManager departmentManager = ( DepartmentManager ) _departmentManagerFactory.CreateInstance( dataSourceName );

			return departmentManager.Update( department );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			DepartmentManager departmentManager = ( DepartmentManager ) _departmentManagerFactory.CreateInstance( dataSourceName );

			return departmentManager.Delete( id );
		}

		public static Department Get( string dataSourceName, int id )
		{
			DepartmentManager departmentManager = ( DepartmentManager ) _departmentManagerFactory.CreateInstance( dataSourceName );

			return ( Department )departmentManager.Get( id );
		}

		public static DepartmentCollection GetAll( string dataSourceName  )
		{
			DepartmentManager departmentManager = ( DepartmentManager ) _departmentManagerFactory.CreateInstance( dataSourceName );

			return ( DepartmentCollection )departmentManager.GetAll( );
		}

		public static DepartmentCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			DepartmentManager departmentManager = ( DepartmentManager ) _departmentManagerFactory.CreateInstance( dataSourceName );

			return ( DepartmentCollection )departmentManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
