#region	Copyright 2005 to 2007 by AECsoft USA Inc.
/*
************************************************************************
Copyright 2005 by AECsoft USA Inc.

All	rights reserved. No	portion	of this	software or	its	content	may	be
reproduced in any form or by any means,	without	the	express	written
permission of the copyright	owner.
************************************************************************
*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Diagnostics;
using System.Web;
using System.Net;
using System.IO;
using System.Configuration;
using System.Text;
using System.Collections.Specialized;

using log4net;

using SCA.VAS.Common.Utilities;
#endregion

namespace SCA.VAS.BusinessLogic.Common.Utilities
{
    /// <summary>
    /// Utility functions for Html Document.
    /// </summary>
    public class HtmlUtility
    {
        #region Constants
        public const string VIEWSTATE = "__VIEWSTATE";
        public const string EVENTVALIDATION = "__EVENTVALIDATION";
        #endregion

        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        // Private members block	includes instance and static members & structs
        /// <summary>
        /// logging component
        /// </summary>
        private static ILog _logger;
        #endregion Private Members

        #region	Constructors
        /// <summary>
        /// Static function only. No instance created.
        /// </summary>
        private HtmlUtility()
        {
            _logger = LoggingUtility.GetLogger(typeof(HtmlUtility).FullName);
        }
        #endregion

        #region public methods
        /// <summary>
        /// Get the Web site root path from an url.
        /// </summary>
        /// <param name="url">The url.</param>
        /// <returns>The site path.</returns>
        public static String GetSitePath(String url)
        {
            int last = url.LastIndexOf('/');
            if (last > 0)
            {
                return url.Substring(0, last + 1);
            }
            else
            {
                return string.Empty;
            }
        }

        public static String GetSiteRoot(String path)
        {
            int index = path.ToLower().IndexOf("http://");
            index = path.IndexOf("/", index + 8);
            return path.Substring(0, index);
        }

        public static String MakeCompleteUrl(String urlRoot, String path)
        {
            if (path.ToLower().IndexOf("http://") >= 0)
            {
                return HttpUtility.UrlDecode(path);
            }
            else if (path.Substring(0, 1) == "/")
            {
                return HttpUtility.UrlDecode(GetSiteRoot(urlRoot) + path);
            }
            else
            {
                return HttpUtility.UrlDecode(urlRoot + path);
            }
        }

        /// <summary>
        /// Get HTML page with cookie and using GET method.
        /// </summary>
        /// <param name="url"></param>
        /// <param name="container"></param>
        /// <returns></returns>
        public static String GetHtmlPage(String url, CookieContainer container)
        {
            string methodName = "GetHtmlPage";
            try
            {
                // Make a search request.
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
                webRequest.CookieContainer = container;
                webRequest.Method = "GET";

                HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();
                StreamReader streamReader = new StreamReader(webResponse.GetResponseStream());

                // Get the search result.
                String html = streamReader.ReadToEnd();
                // Close and clean up the StreamReader
                streamReader.Close();
                return html;
            }
            catch (System.Exception e)
            {
                if (_logger.IsErrorEnabled)
                {
                    _logger.Error(methodName, e);
                }
                return string.Empty;
            }
        }


        /// <summary>
        /// Get HTML page with Credentials and using GET method.
        /// </summary>
        /// <param name="url"></param>
        /// <param name="container"></param>
        /// <returns></returns>
        public static String GetHtmlPage(String url, NetworkCredential credential)
        {
            string methodName = "GetHtmlPage";
            try
            {
                // Make a search request.
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
                webRequest.Credentials = credential;
                webRequest.Method = "GET";

                HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();
                StreamReader streamReader = new StreamReader(webResponse.GetResponseStream());

                // Get the search result.
                String html = streamReader.ReadToEnd();
                // Close and clean up the StreamReader
                streamReader.Close();
                return html;
            }
            catch (System.Exception e)
            {
                if (_logger.IsErrorEnabled)
                {
                    _logger.Error(methodName, e);
                }
                return string.Empty;
            }
        }


        /// <summary>
        /// Get HTML page without cookie and using GET method.
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static String GetHtmlPage(String url)
        {
            string methodName = "GetHtmlPage";
            try
            {
                // Make a search request.
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
                webRequest.Method = "GET";

                HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();
                StreamReader streamReader = new StreamReader(webResponse.GetResponseStream());

                // Get the search result.
                String html = streamReader.ReadToEnd();
                // Close and clean up the StreamReader
                streamReader.Close();
                return html;
            }
            catch (System.Exception e)
            {
                if (_logger.IsErrorEnabled)
                {
                    _logger.Error(methodName, e);
                }
                return string.Empty;
            }
        }


        /// <summary>
        /// Get HTML page without cookie and using Post method.
        /// </summary>
        /// <param name="url"></param>
        /// <param name="postingData"></param>
        /// <returns></returns>
        public static String PostHtmlPage(String url, String postingData)
        {
            string methodName = "PostHtmlPage";

            try
            {
                String result;
                StreamWriter streamWriter = null;

                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
                webRequest.Method = "POST";
                webRequest.ContentLength = postingData.Length;
                webRequest.ContentType = "application/x-www-form-urlencoded";

                streamWriter = new StreamWriter(webRequest.GetRequestStream());
                streamWriter.Write(postingData);
                streamWriter.Close();

                HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();

                StreamReader streamReader = new StreamReader(webResponse.GetResponseStream());
                result = streamReader.ReadToEnd();
                // Close and clean up the StreamReader
                streamReader.Close();

                return result;
            }
            catch (System.Exception e)
            {
                if (_logger.IsErrorEnabled)
                {
                    _logger.Error(methodName, e);
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Get HTML page with referer and using Post method.
        /// </summary>
        /// <param name="url"></param>
        /// <param name="postingData"></param>
        /// <returns></returns>
        public static String PostHtmlPage(String url, String referer, String postingData)
        {
            string methodName = "PostHtmlPage";

            try
            {
                String result;
                StreamWriter streamWriter = null;

                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
                webRequest.Method = "POST";
                webRequest.ContentLength = postingData.Length;
                webRequest.ContentType = "application/x-www-form-urlencoded";
                webRequest.Referer = referer;

                streamWriter = new StreamWriter(webRequest.GetRequestStream());
                streamWriter.Write(postingData);
                streamWriter.Close();

                HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();

                StreamReader streamReader = new StreamReader(webResponse.GetResponseStream());
                result = streamReader.ReadToEnd();
                // Close and clean up the StreamReader
                streamReader.Close();

                return result;
            }
            catch (System.Exception e)
            {
                if (_logger.IsErrorEnabled)
                {
                    _logger.Error(methodName, e);
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Get HTML page without cookie and using Post method.
        /// </summary>
        /// <param name="url"></param>
        /// <param name="postingData"></param>
        /// <returns></returns>
        public static String PostHtmlPage(String url, CookieContainer container, String postingData)
        {
            string methodName = "PostHtmlPage";

            try
            {
                String result;
                StreamWriter streamWriter = null;

                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
                webRequest.Referer = url;
                webRequest.CookieContainer = container;
                webRequest.Method = "POST";
                webRequest.ContentLength = postingData.Length;
                webRequest.ContentType = "application/x-www-form-urlencoded";

                streamWriter = new StreamWriter(webRequest.GetRequestStream());
                streamWriter.Write(postingData);
                streamWriter.Close();

                HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();

                StreamReader streamReader = new StreamReader(webResponse.GetResponseStream());
                result = streamReader.ReadToEnd();
                // Close and clean up the StreamReader
                streamReader.Close();

                return result;
            }
            catch (System.Exception e)
            {
                if (_logger.IsErrorEnabled)
                {
                    _logger.Error(methodName, e);
                }
                return string.Empty;
            }
        }


        /// <summary>
        /// Posts the HTML page.
        /// </summary>
        /// <param name="url">The URL.</param>
        /// <param name="container">The container.</param>
        /// <param name="keys">The keys.</param>
        /// <param name="values">The values.</param>
        /// <returns></returns>
        public static String PostHtmlPage(string url, CookieContainer container, NameValueCollection nameValues)
        {
            StringBuilder builder = new StringBuilder();
            //Make posting data.
            for (int i = 0; i < nameValues.Count; i++)
            {
                builder.Append(nameValues.GetKey(i));
                builder.Append("=");
                builder.Append(nameValues.Get(i));
                if (i < nameValues.Count - 1)
                {
                    builder.Append("&");
                }
            }
            string postingData = builder.ToString();
            return PostHtmlPage(url, container, postingData);
        }

        /// <summary>
        /// Get HTML page with cookie and using Post method.
        /// </summary>
        /// <param name="url"></param>
        /// <param name="postingData"></param>
        /// <returns></returns>
        public static String PostHtmlPage(String url, CookieContainer container, byte[] postingData)
        {
            string methodName = "PostHtmlPage";

            try
            {
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
                webRequest.CookieContainer = container;
                webRequest.ContentType = "multipart/form-data; boundary=xyz";
                webRequest.Method = "POST";
                webRequest.KeepAlive = true;
                webRequest.Referer = url;
                webRequest.ContentLength = postingData.Length;
                Stream tempStream = webRequest.GetRequestStream();
                // write the data to be posted to the Request Stream
                tempStream.Write(postingData, 0, postingData.Length);
                tempStream.Close();
                HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse();
                //Read the raw HTML from the request
                StreamReader sr = new StreamReader(response.GetResponseStream(),
                    Encoding.Default);
                //Convert the stream to a string
                string s = sr.ReadToEnd();
                sr.Close();
                response.Close();
                return s;
            }
            catch (System.Exception e)
            {
                if (_logger.IsErrorEnabled)
                {
                    _logger.Error(methodName, e);
                }
                return string.Empty;
            }
        }

        public static string GetViewState(CookieContainer container, string url)
        {
            string methodName = "GetViewState";

            try
            {
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
                webRequest.UserAgent = "Upload Test";
                webRequest.Method = "GET";
                webRequest.CookieContainer = container;
                HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse();
                //Read the raw HTML from the request
                StreamReader reader = new StreamReader(response.GetResponseStream(),
                    Encoding.Default);
                //Convert the stream to a string
                string s = reader.ReadToEnd();
                reader.Close();
                response.Close();
                int start = 0, end = 0;
                start = s.IndexOf("__VIEWSTATE");
                if (start > 0)
                {
                    end = s.IndexOf("value=", start);
                }
                else
                {
                    //did not find the viewstate handle here
                }
                start = end;
                end = s.IndexOf("/", start);
                if (end - start < 10)
                {
                    start = end + 1;
                    end = s.IndexOf("/", start);

                    //remove the value= and the quotes from the viewstate value.
                    string vstate =
                        "\"" + "__VIEWSTATE" + "\"\r\n\r\n" +
                        "%2F" + s.Substring(start, (end - start - 2));
                    vstate.Replace("+", "%2B");
                    vstate.Replace("=", "%3D");
                    return vstate;
                }
                else
                {
                    //remove the value= and the quotes from the viewstate value.
                    string vstate =
                        "\"" + "__VIEWSTATE" + "\"\r\n\r\n" +
                        s.Substring(start + 7, ((end - 2) - (start + 7)));
                    vstate.Replace("+", "%2B");
                    vstate.Replace("=", "%3D");
                    return vstate;
                }
            }
            catch (System.Exception e)
            {
                if (_logger.IsErrorEnabled)
                {
                    _logger.Error(methodName, e);
                }
                return string.Empty;
            }
        }

        public static string GetBase64Data(string html, string sectionName)
        {
            int start = 0, end = 0;
            start = html.IndexOf(sectionName);
            if (start > 0)
            {
                end = html.IndexOf("value=", start);
            }
            else
            {
                return null;
            }
            start = end;
            end = html.IndexOf("/>", start);
            //remove the value= and the quotes from the Base64 value.
            string value =
                html.Substring(start + 7, ((end - 2) - (start + 7)));
            return EncodeFormData(value);
        }

        public static string EncodeFormData(string input)
        {
            string replacedString = input;
            replacedString = replacedString.Replace("+", "%2B");
            replacedString = replacedString.Replace("=", "%3D");
            replacedString = replacedString.Replace("/", "%2F");
            replacedString = replacedString.Replace("$", "%24");
            return replacedString;
        }
        #endregion public methods

        #region private methods

        private static String ParseHref(String hrefText)
        {
            int firstQ; // First " position.
            int lastQ; // Last " Postion.

            int href = hrefText.ToLower().IndexOf("href");
            if (href >= 0)
            {
                hrefText = hrefText.Substring(href + 4);
            }

            firstQ = hrefText.IndexOf('"');
            lastQ = hrefText.LastIndexOf('"');
            if (firstQ >= 0 && lastQ >= 0)
            {
                return hrefText.Substring(firstQ + 1, lastQ - firstQ - 1);
            }
            else // no ".
            {
                href = hrefText.ToUpper().IndexOf("=");
                if (href > 0)
                {
                    return hrefText.Substring(href + 1);
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private static String MatchName(String text, ArrayList names)
        {
            foreach (string name in names)
            {
                if (text.IndexOf(name) >= 0)
                {
                    return name;
                }
            }
            return string.Empty;
        }

        private static String MatchName(String text, String name)
        {
            if (text.IndexOf(name) >= 0)
            {
                return name;
            }
            else
            {
                return string.Empty;
            }
        }

        private static String RemoveNbsp(String text)
        {
            int index = text.IndexOf("&nbsp;");
            while (index >= 0)
            {
                text = text.Substring(0, index) + text.Substring(index + 6);
                index = text.IndexOf("&nbsp;");
            }
            return text.Trim();
        }

        #endregion private methods
    }
}
