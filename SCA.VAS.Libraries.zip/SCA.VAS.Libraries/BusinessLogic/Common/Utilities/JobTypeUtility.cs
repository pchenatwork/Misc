#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class JobTypeUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly JobTypeManagerFactory _jobTypeManagerFactory = 
			( JobTypeManagerFactory ) JobTypeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static JobTypeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( JobTypeUtility ).FullName);
		}

		private JobTypeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static JobType CreateObject( )
		{
			JobTypeManager jobTypeManager = ( JobTypeManager ) _jobTypeManagerFactory.CreateInstance( );

			return ( JobType )jobTypeManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, JobType jobType )
		{
			JobTypeManager jobTypeManager = ( JobTypeManager ) _jobTypeManagerFactory.CreateInstance( dataSourceName );

			return jobTypeManager.Create( jobType );
		}

		public static bool Update( string dataSourceName, JobType jobType )
		{
			JobTypeManager jobTypeManager = ( JobTypeManager ) _jobTypeManagerFactory.CreateInstance( dataSourceName );

			return jobTypeManager.Update( jobType );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			JobTypeManager jobTypeManager = ( JobTypeManager ) _jobTypeManagerFactory.CreateInstance( dataSourceName );

			return jobTypeManager.Delete( id );
		}

		public static JobType Get( string dataSourceName, int id )
		{
			JobTypeManager jobTypeManager = ( JobTypeManager ) _jobTypeManagerFactory.CreateInstance( dataSourceName );

			return ( JobType )jobTypeManager.Get( id );
		}

		public static JobTypeCollection GetAll( string dataSourceName  )
		{
			JobTypeManager jobTypeManager = ( JobTypeManager ) _jobTypeManagerFactory.CreateInstance( dataSourceName );

			return ( JobTypeCollection )jobTypeManager.GetAll( );
		}

		#endregion

	}
}
