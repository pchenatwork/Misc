#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class PaymentTypeUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PaymentTypeManagerFactory _paymentTypeManagerFactory = 
			( PaymentTypeManagerFactory ) PaymentTypeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PaymentTypeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PaymentTypeUtility ).FullName);
		}

		private PaymentTypeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PaymentType CreateObject( )
		{
			PaymentTypeManager paymentTypeManager = ( PaymentTypeManager ) _paymentTypeManagerFactory.CreateInstance( );

			return ( PaymentType )paymentTypeManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, PaymentType paymentType )
		{
			PaymentTypeManager paymentTypeManager = ( PaymentTypeManager ) _paymentTypeManagerFactory.CreateInstance( dataSourceName );

			return paymentTypeManager.Create( paymentType );
		}

		public static bool Update( string dataSourceName, PaymentType paymentType )
		{
			PaymentTypeManager paymentTypeManager = ( PaymentTypeManager ) _paymentTypeManagerFactory.CreateInstance( dataSourceName );

			return paymentTypeManager.Update( paymentType );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			PaymentTypeManager paymentTypeManager = ( PaymentTypeManager ) _paymentTypeManagerFactory.CreateInstance( dataSourceName );

			return paymentTypeManager.Delete( id );
		}

		public static PaymentType Get( string dataSourceName, int id )
		{
			PaymentTypeManager paymentTypeManager = ( PaymentTypeManager ) _paymentTypeManagerFactory.CreateInstance( dataSourceName );

			return ( PaymentType )paymentTypeManager.Get( id );
		}

		public static PaymentTypeCollection GetAll( string dataSourceName  )
		{
			PaymentTypeManager paymentTypeManager = ( PaymentTypeManager ) _paymentTypeManagerFactory.CreateInstance( dataSourceName );

			return ( PaymentTypeCollection )paymentTypeManager.GetAll( );
		}

		#endregion

	}
}
