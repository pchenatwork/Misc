#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Common;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Common.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class UnitOfMeasureUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly UnitOfMeasureManagerFactory _unitOfMeasureManagerFactory = 
			( UnitOfMeasureManagerFactory ) UnitOfMeasureManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static UnitOfMeasureUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( UnitOfMeasureUtility ).FullName);
		}

		private UnitOfMeasureUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static UnitOfMeasure CreateObject( )
		{
			UnitOfMeasureManager unitOfMeasureManager = ( UnitOfMeasureManager ) _unitOfMeasureManagerFactory.CreateInstance( );

			return ( UnitOfMeasure )unitOfMeasureManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, UnitOfMeasure unitOfMeasure )
		{
			UnitOfMeasureManager unitOfMeasureManager = ( UnitOfMeasureManager ) _unitOfMeasureManagerFactory.CreateInstance( dataSourceName );

			return unitOfMeasureManager.Create( unitOfMeasure );
		}

		public static bool Update( string dataSourceName, UnitOfMeasure unitOfMeasure )
		{
			UnitOfMeasureManager unitOfMeasureManager = ( UnitOfMeasureManager ) _unitOfMeasureManagerFactory.CreateInstance( dataSourceName );

			return unitOfMeasureManager.Update( unitOfMeasure );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			UnitOfMeasureManager unitOfMeasureManager = ( UnitOfMeasureManager ) _unitOfMeasureManagerFactory.CreateInstance( dataSourceName );

			return unitOfMeasureManager.Delete( id );
		}

		public static UnitOfMeasure Get( string dataSourceName, int id )
		{
			UnitOfMeasureManager unitOfMeasureManager = ( UnitOfMeasureManager ) _unitOfMeasureManagerFactory.CreateInstance( dataSourceName );

			return ( UnitOfMeasure )unitOfMeasureManager.Get( id );
		}

		public static UnitOfMeasureCollection GetAll( string dataSourceName  )
		{
			UnitOfMeasureManager unitOfMeasureManager = ( UnitOfMeasureManager ) _unitOfMeasureManagerFactory.CreateInstance( dataSourceName );

			return ( UnitOfMeasureCollection )unitOfMeasureManager.GetAll( );
		}

		#endregion

	}
}
