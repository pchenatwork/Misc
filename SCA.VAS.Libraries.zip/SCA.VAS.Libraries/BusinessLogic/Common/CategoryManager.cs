#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common
{
	#region	Header
	///	<summary>
	///	Manager class for Category.
	///	</summary>
	#endregion Header

	[Serializable]
	public class CategoryManager : AbstractManager
	{		
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
		public const string FIND_SELECTED_CATEGORY = "FindSelectedCategory";
        public const string FIND_ACTIVE_CATEGORY = "FindActiveCategory";
        public const string FIND_CATEGORY_BY_NAME = "FindCategoryByName";
		public const string FIND_CATEGORY_BY_CODE = "FindCategoryByCode";
		public const string FIND_CATEGORY = "FindCategory";
		public const string FIND_CATEGORY_BY_PARENT = "FindCategoryByParent";
        public const string FIND_ALL_CATEGORY_BY_TYPE = "FindAllCategoryByType";
        public const string FIND_CATEGORY_BY_LEVEL = "FindCategoryByLevel";
        public const string FIND_CATEGORY_BY_LANGUAGE = "FindCategoryByLanguage";
        public const string FIND_CATEGORY_BY_POST = "FindCategoryByPost";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static CategoryManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CategoryManager ).FullName );
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public CategoryManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public CategoryManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Common.CategoryDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new Category( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************

		/// <summary>
		/// Create a new Category object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update( IValueObject existingObject )
		{
			return this.Dao.Update( this.DataSource, existingObject );
		}

        /// <summary>
        /// Update the object in the database.
        /// </summary>
        /// <returns></returns>
        public bool UpdateCollection(CategoryCollection collection)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateCollection",
                new object[] { this.DataSource, collection });
        }

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete( int id )
		{
			return this.Dao.Delete( this.DataSource, id );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new Category object from the database.
		/// </summary>
		/// <param name="Id">Category Id</param>
		/// <returns></returns>
        public override IValueObject Get(int id)
        {
            return this.Dao.Get(this.DataSource, id);
        }
		
		public IValueObject GetByName( string name )
		{
			return (IValueObject)this.Dao.InvokeByMethodName( "GetByName", 
				new object[] { this.DataSource, name } );
		}
		
		public override ICollection GetAll()
		{
			return this.Dao.GetAll( this.DataSource );
		}

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 
	} 
} 
