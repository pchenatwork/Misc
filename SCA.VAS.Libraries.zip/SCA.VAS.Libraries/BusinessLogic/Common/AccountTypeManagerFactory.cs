
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common 
{ 
	#region Header 
	/// <summary>
	/// Factory for AccountTypeManager.
	/// </summary>
	#endregion Header
	
	public class AccountTypeManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static AccountTypeManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( AccountTypeManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private AccountTypeManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the AccountTypeManagerFactory
		/// </summary>
		/// <returns>an instance of AccountTypeManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( AccountTypeManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new AccountTypeManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new AccountTypeManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new AccountTypeManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}