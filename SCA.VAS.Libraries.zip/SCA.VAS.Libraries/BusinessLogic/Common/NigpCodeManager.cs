#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Common;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common
{
	#region	Header
	///	<summary>
	///	Manager class for NigpCode.
	///	</summary>
	#endregion Header

	[Serializable]
	public class NigpCodeManager : AbstractManager
	{		
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
		public const string FIND_LEVEL1_NIGPCODE = "FindLevel1NigpCode";
		public const string FIND_LEVEL2_NIGPCODE = "FindLevel2NigpCode";
		public const string FIND_BY_KEYWORD = "FindByKeyword";
		public const string FIND_NIGPCODE = "FindNigpCode";
		#endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static NigpCodeManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( NigpCodeManager ).FullName );
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public NigpCodeManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public NigpCodeManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Common.NigpCodeDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new NigpCode( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************

		/// <summary>
		/// Create a new NigpCode object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update( IValueObject existingObject )
		{
			return this.Dao.Update( this.DataSource, existingObject );
		}

        /// <summary>
        /// Update the object in the database.
        /// </summary>
        /// <returns></returns>
        public bool UpdateCollection(NigpCodeCollection collection)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateCollection",
                new object[] { this.DataSource, collection });
        }

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public bool Delete( string code, string subCode )
		{
			return (bool)this.Dao.InvokeByMethodName( "Delete", 
				new object[] { this.DataSource, code, subCode } );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************

		/// <summary>
		/// Get a new NigpCode object from the database.
		/// </summary>
		/// <param name="Id">NigpCode Id</param>
		/// <returns></returns>
		public IValueObject Get( string code, string subCode )
		{
			return (IValueObject)this.Dao.InvokeByMethodName( "Get", 
				new object[] { this.DataSource, code, subCode } );
		}
		
		public override ICollection GetAll()
		{
			return this.Dao.GetAll( this.DataSource );
		}

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 
	} 
} 
