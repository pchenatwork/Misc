#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Common
{
	#region	Header
	///	<summary>
	///	Factory for CertificationType
	///	</summary>
	#endregion Header

	public sealed class CertificationTypeManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static CertificationTypeManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CertificationTypeManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private CertificationTypeManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the CertificationTypeManagerFactory
		/// </summary>
		/// <returns>an instance of CertificationTypeManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( CertificationTypeManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new CertificationTypeManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new CertificationTypeManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new CertificationTypeManager( dataSourceName );
		} 
		
		#endregion
	} 
} 