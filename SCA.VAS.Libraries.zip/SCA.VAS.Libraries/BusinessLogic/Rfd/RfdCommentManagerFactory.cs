#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd
{
	#region	Header
	///	<summary>
	///	Factory for RfdComment
	///	</summary>
	#endregion Header

	public sealed class RfdCommentManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static RfdCommentManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( RfdCommentManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private RfdCommentManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the RfdCommentManagerFactory
		/// </summary>
		/// <returns>an instance of RfdCommentManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( RfdCommentManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new RfdCommentManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance()
		{
			return new RfdCommentManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new RfdCommentManager( dataSourceName );
		}  
		#endregion Public Methods
	} 
} 