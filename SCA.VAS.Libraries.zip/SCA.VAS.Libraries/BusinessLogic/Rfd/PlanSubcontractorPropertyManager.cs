#region Copyright
/*=======================================================================
*
* Modification History:
* Date       Programmer Description
* 02-02-2005 Shawn Shi created
*
*=======================================================================
* Copyright ( C ) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd
{
	#region	Header
	///	<summary>
	///	Manager class for PlanSubcontractorProperty.
	///	</summary>
	#endregion Header

	[Serializable]
	public class PlanSubcontractorPropertyManager : AbstractManager
	{		
		#region	Constants
        public const string FIND_BY_PLANSUBCONTRACTOR = "FindPlanSubcontractorPropertyByPlanSubcontractor";
        public const string FIND_PLANSUBCONTRACTORPROPERTY_COUNT = "FindPlanSubcontractorPropertyCount";
        #endregion Constants

		#region	Private Members
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static PlanSubcontractorPropertyManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanSubcontractorPropertyManager ).FullName );
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public PlanSubcontractorPropertyManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public PlanSubcontractorPropertyManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName ( string )
		/// </summary>
		public override string DaoClassName
		{
			get
			{
                return "SCA.VAS.DataAccess.Rfd.PlanSubcontractorPropertyDao";
			}
		}

		public override IValueObject CreateObject()
		{
			return new PlanSubcontractorProperty();
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
        /// <summary>
        /// Remove the object from the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public override bool Delete(int id)
        {
            PlanSubcontractorProperty file = Get(id) as PlanSubcontractorProperty;
            if (file != null && file.AttachmentId > 0) SCA.VAS.ECMWrapper.DocServiceHelper.DeleteDoc(file.AttachmentId);
            return this.Dao.Delete(this.DataSource, id);
        }

        /// <summary>
        /// Update the object in the database.
        /// </summary>
        /// <returns></returns>
        public bool UpdateCollection(int planSubcontractorId, PlanSubcontractorPropertyCollection collection)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateCollection",
                new object[] { this.DataSource, planSubcontractorId, collection });
        }

        /// <summary>
        /// Update Attachment in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateAttachment(int id, int planSubcontractorId, int parentId, int propertyId, string attachmentName, byte[] attachment)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateAttachment",
                new object[] { this.DataSource, id, planSubcontractorId, parentId, propertyId, attachmentName, attachment });
        }

        /// <summary>
        /// Remove attachment in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool DeleteAttachment(int id)
        {
            PlanSubcontractorProperty file = Get(id) as PlanSubcontractorProperty;
            if (file != null && file.AttachmentId > 0) SCA.VAS.ECMWrapper.DocServiceHelper.DeleteDoc(file.AttachmentId);
            return (bool)this.Dao.InvokeByMethodName("DeleteAttachment",
                new object[] { this.DataSource, id });
        }
		#endregion 
		
		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new PlanSubcontractorProperty object from the database.
		/// </summary>
		/// <param name="Id">PlanSubcontractorProperty Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}

        /// <summary>
        /// Get attachment from the database.
        /// </summary>
        /// <param name="Id">PlanSubcontractorProperty Id</param>
        /// <returns></returns>
        public byte[] GetAttachment(int id)
        {
            PlanSubcontractorProperty file = Get(id) as PlanSubcontractorProperty;
            if (file != null && file.AttachmentId > 0)
                return (byte[])SCA.VAS.ECMWrapper.DocServiceHelper.DownloadDoc(file.AttachmentId).Contents;
            else
                 return (byte[])this.Dao.InvokeByMethodName("GetAttachment",new object[] { this.DataSource, id });
        }

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 
	} 
}