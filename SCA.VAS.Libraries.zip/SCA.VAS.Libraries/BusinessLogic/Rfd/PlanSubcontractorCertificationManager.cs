
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Manager class for PlanSubcontractorCertification.
	/// </summary>
	#endregion Header
	
	public class PlanSubcontractorCertificationManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string FIND_BY_PLANSUBCONTRACTOR = "FindPlanSubcontractorCertification";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static PlanSubcontractorCertificationManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanSubcontractorCertificationManager ).FullName);
		} //	end	class constructor

		/// <summary>
		/// default	constructor	
		/// inits with default
		///	</summary>
		public PlanSubcontractorCertificationManager()
		{
		} // end constructor

		///	<summary>
		/// default constructor	
		/// inits with a DataSource.
		///	</summary>
		public PlanSubcontractorCertificationManager( string dataSourceName ) : base( dataSourceName )
		{
		}
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Rfd.PlanSubcontractorCertificationDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new PlanSubcontractorCertification( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		/// <summary>
		/// Create a new PlanSubcontractorCertification object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update(IValueObject existingObject)
		{
			return this.Dao.Update(this.DataSource, existingObject);
		}

        /// <summary>
        /// Update the objects in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="collection"></param>
        /// <returns></returns>
        public bool UpdateCollection(int planSubcontractorId, PlanSubcontractorCertificationCollection collection)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateCollection",
                new object[] { this.DataSource, planSubcontractorId, collection });
        }

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete( int id )
        {
            PlanSubcontractorCertification file = Get(id) as PlanSubcontractorCertification;
            if (file != null && file.CertificateId > 0) SCA.VAS.ECMWrapper.DocServiceHelper.DeleteDoc(file.CertificateId);
            return this.Dao.Delete( this.DataSource, id );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new PlanSubcontractorCertification object from the database.
		/// </summary>
		/// <param name="Id">PlanSubcontractorCertification Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}

        /// <summary>
        /// Get a new PlanSubcontractorCertification object from the database.
        /// </summary>
        /// <param name="certificationId">CertificationId</param>
        /// <returns></returns>
        public IValueObject GetById(Guid certificationId)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("GetById",
                new object[] { this.DataSource, certificationId });
        }

        /// <summary>
        /// Get attachment from the database.
        /// </summary>
        /// <param name="Id">CertificationId</param>
        /// <returns></returns>
        public byte[] GetAttachment(int id)
        {
            PlanSubcontractorCertification file = Get(id) as PlanSubcontractorCertification;
            if (file != null && file.CertificateId > 0)
                return (byte[])SCA.VAS.ECMWrapper.DocServiceHelper.DownloadDoc(file.CertificateId).Contents;
            else
                return (byte[])this.Dao.InvokeByMethodName("GetAttachment",
                new object[] { this.DataSource, id });
        }

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 	
	}
}