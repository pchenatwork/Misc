
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Factory for BidderBreakdownManager.
	/// </summary>
	#endregion Header
	
	public class BidderBreakdownManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static BidderBreakdownManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BidderBreakdownManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private BidderBreakdownManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the BidderBreakdownManagerFactory
		/// </summary>
		/// <returns>an instance of BidderBreakdownManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( BidderBreakdownManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new BidderBreakdownManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new BidderBreakdownManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new BidderBreakdownManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}