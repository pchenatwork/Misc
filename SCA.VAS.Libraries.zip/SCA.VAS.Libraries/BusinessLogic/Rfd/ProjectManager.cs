
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Manager class for Project.
	/// </summary>
	#endregion Header
	
	public class ProjectManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string SEARCH_PROJECT = "SearchProject";
        public const string FIND_PROJECT = "FindProject";
        public const string FIND_PROJECT_BY_OUTLOOK = "FindProjectByOutlook";
        public const string FIND_CS_PROJECT_BY_OUTLOOK = "FindCSProjectByOutlook";
        public const string FIND_PROJECT_BY_TYPE_OUTLOOK = "FindProjectsByTypeByOutlook";
        public const string FIND_BY_SUPPLIER = "FindProjectBySupplier";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static ProjectManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ProjectManager ).FullName);
		} //	end	class constructor

		/// <summary>
		/// default	constructor	
		/// inits with default
		///	</summary>
		public ProjectManager()
		{
		} // end constructor

		///	<summary>
		/// default constructor	
		/// inits with a DataSource.
		///	</summary>
		public ProjectManager( string dataSourceName ) : base( dataSourceName )
		{
		}
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Rfd.ProjectDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new Project( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		/// <summary>
		/// Create a new Project object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update(IValueObject existingObject)
		{
			return this.Dao.Update(this.DataSource, existingObject);
		}

        /// <summary>
        /// Update Status in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateStatus(int id, int status, string statusName, string cancelReasonCode, string cancelComments)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateStatus",
                new object[] { this.DataSource, id, status, statusName, cancelReasonCode, cancelComments });
        }

        public bool UpdateHardbids(IValueObject existingObject)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateHardbids",  new object[] { this.DataSource, existingObject });
        }

        public IValueObject GetByJmId(int jmid)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("GetByJmId",
                new object[] { this.DataSource, jmid });
        }
        public IValueObject ImportFromJustificationMemo(int jmid, int userid)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("ImportFromJustificationMemo",
                new object[] { this.DataSource, jmid, userid });
        }
        public Tuple<string, string> GetPreviousSolCancellationDetails(int id)
        {
            return (Tuple<string, string>)this.Dao.InvokeByMethodName("GetPreviousSolCancellationDetails",
                new object[] { this.DataSource, id });
        }

        public Tuple<int,string> UpdatePTSProjectSOLCancellation(int id, string cancelReasonCode, string cancelComments, string userName)
        {
            return  (Tuple<int, string>)this.Dao.InvokeByMethodName("UpdatePTSProjectSOLCancellation",
                new object[] { this.DataSource, id, cancelReasonCode, cancelComments, userName });
        }

        /// <summary>
        /// Update TransactionId in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateTransactionId(int id, int transactionId)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateTransactionId",
                new object[] { this.DataSource, id, transactionId });
        }


        /// <summary>
        /// Update Contract No in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateContractNo(int id)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateContractNo",
                new object[] { this.DataSource, id });
        }

        /// <summary>
        /// Import this object in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Import(string transNumber, int workflowId, int userId)
        {
            return (int)this.Dao.InvokeByMethodName("Import",
                new object[] { this.DataSource, transNumber, workflowId, userId });
        }

        public double GetBudgetAmount(string packageNo)
        {
            return (double)this.Dao.InvokeByMethodName("GetBudgetAmount",
                new object[] { this.DataSource, packageNo });
        }

        /// <summary>
        /// Import this object in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Import2(string transNumber, int workflowId, int userId)
        {
            return (int)this.Dao.InvokeByMethodName("Import2",
                new object[] { this.DataSource, transNumber, workflowId, userId });
        }

        /// <summary>
        /// Update Criteria in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateCriteria(int id, string criteria)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateCriteria",
                new object[] { this.DataSource, id, criteria });
        }

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete( int id )
		{
			return this.Dao.Delete( this.DataSource, id );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new Project object from the database.
		/// </summary>
		/// <param name="Id">Project Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}

        /// <summary>
        /// Get a new Project object from the database.
        /// </summary>
        /// <param name="projectId">ProjectId</param>
        /// <returns></returns>
        public IValueObject GetById(Guid projectId)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("GetById",
                new object[] { this.DataSource, projectId });
        }

        /// <summary>
        /// Get a new Project object from the database.
        /// </summary>
        /// <param name="rfcId">rfcId</param>
        /// <returns></returns>
        public IValueObject GetByRfc(int rfcId)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("GetByRfc",
                new object[] { this.DataSource, rfcId });
        }

        /// <summary>
        /// Get a new Project object from the database.
        /// </summary>
        /// <param name="transNumber">transNumber</param>
        /// <returns></returns>
        public IValueObject GetByTransNumber(string transNumber)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("GetByTransNumber",
                new object[] { this.DataSource, transNumber });
        }

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
        public List<PlaceHolderPair> ReplacePlaceholders(int id)
        {
            return (List<PlaceHolderPair>)this.Dao.InvokeByMethodName("ReplacePlaceholders", new object[] { this.DataSource, id});
        }
        public List<PlaceHolderPair> ReplacePlaceholders(int id, int bidderid)
        {
            return (List<PlaceHolderPair>)this.Dao.InvokeByMethodName("HardbidReplacePlaceholders", new object[] { this.DataSource, id, bidderid });
        }
        #endregion


    }
}