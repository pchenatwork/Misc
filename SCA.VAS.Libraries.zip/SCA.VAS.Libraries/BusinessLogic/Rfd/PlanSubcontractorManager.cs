
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Manager class for PlanSubcontractor.
	/// </summary>
	#endregion Header
	
	public class PlanSubcontractorManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string FIND_BY_PLAN = "FindPlanSubcontractor";
        public const string FIND_BY_SUPPLIER = "FindPlanSubcontractorBySupplier";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static PlanSubcontractorManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanSubcontractorManager ).FullName);
		} //	end	class constructor

		/// <summary>
		/// default	constructor	
		/// inits with default
		///	</summary>
		public PlanSubcontractorManager()
		{
		} // end constructor

		///	<summary>
		/// default constructor	
		/// inits with a DataSource.
		///	</summary>
		public PlanSubcontractorManager( string dataSourceName ) : base( dataSourceName )
		{
		}
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Rfd.PlanSubcontractorDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new PlanSubcontractor( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		/// <summary>
		/// Create a new PlanSubcontractor object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update(IValueObject existingObject)
		{
			return this.Dao.Update(this.DataSource, existingObject);
		}

        /// <summary>
        /// Update Status in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateStatus(int id, int status, string statusName)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateStatus",
                new object[] { this.DataSource, id, status, statusName });
        }

        /// <summary>
        /// Update TransactionId in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateTransactionId(int id, int transactionId)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateTransactionId",
                new object[] { this.DataSource, id, transactionId });
        }

        /// <summary>
        /// Copy in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool Copy(int planId, int newPlanId, string changeUser)
        {
            return (bool)this.Dao.InvokeByMethodName("Copy",
                new object[] { this.DataSource, planId, newPlanId, changeUser });
        }

        /// <summary>
        /// Import in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool Import(int planId, int sAFId, string changeUser)
        {
            return (bool)this.Dao.InvokeByMethodName("Import",
                new object[] { this.DataSource, planId, sAFId, changeUser });
        }

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete( int id )
		{
			return this.Dao.Delete( this.DataSource, id );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new PlanSubcontractor object from the database.
		/// </summary>
		/// <param name="Id">PlanSubcontractor Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}

        /// <summary>
        /// Get a new PlanSubcontractor object from the database.
        /// </summary>
        /// <param name="planSubcontractorId">PlanId</param>
        /// <returns></returns>
        public IValueObject GetById(Guid planSubcontractorId)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("GetById",
                new object[] { this.DataSource, planSubcontractorId });
        }

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 	
	}
}