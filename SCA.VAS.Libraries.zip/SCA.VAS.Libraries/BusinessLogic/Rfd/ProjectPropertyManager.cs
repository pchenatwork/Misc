
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Manager class for ProjectProperty.
	/// </summary>
	#endregion Header
	
	public class ProjectPropertyManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string FIND_BY_PROJECT = "FindProjectPropertyByProject";
        public const string FIND_PROJECTPROPERTY_COUNT = "FindProjectPropertyCount";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static ProjectPropertyManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ProjectPropertyManager ).FullName);
		} //	end	class constructor

		/// <summary>
		/// default	constructor	
		/// inits with default
		///	</summary>
		public ProjectPropertyManager()
		{
		} // end constructor

		///	<summary>
		/// default constructor	
		/// inits with a DataSource.
		///	</summary>
		public ProjectPropertyManager( string dataSourceName ) : base( dataSourceName )
		{
		}
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Rfd.ProjectPropertyDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new ProjectProperty( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete( int id )
        {
            return this.Dao.Delete( this.DataSource, id );
		}

        /// <summary>
        /// Update the object in the database.
        /// </summary>
        /// <returns></returns>
        public bool UpdateCollection(int projectId, ProjectPropertyCollection collection)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateCollection",
                new object[] { this.DataSource, projectId, collection });
        }

        /// <summary>
        /// Update Attachment in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateAttachment(int id, int projectId, int parentId, int propertyId, string attachmentName, long attachmentId)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateAttachment",
                new object[] { this.DataSource, id, projectId, parentId, propertyId, attachmentName, attachmentId });
        }

        /// <summary>
        /// Remove attachment in the database.
        /// </summary>
        /// <param name="attachmentId"></param>
        /// <returns></returns>
        public bool DeleteAttachmentId(int attachmentId)
        {

            if (attachmentId > 0) SCA.VAS.ECMWrapper.DocServiceHelper.DeleteDoc(attachmentId);

            return (bool)this.Dao.InvokeByMethodName("DeleteAttachmentId",
                new object[] { this.DataSource, attachmentId });
        }
        #endregion

        #region IFinder
        // *************************************************************************
        //				 IFinder
        // *************************************************************************
        /// <summary>
        /// Get a new ProjectProperty object from the database.
        /// </summary>
        /// <param name="Id">ProjectProperty Id</param>
        /// <returns></returns>
        public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}

        /// <summary>
        /// Get attachment from the database.
        /// </summary>
        /// <param name="Id">ProjectProperty Id</param>
        /// <returns></returns>
        public ECMWrapper.VASDocument GetAttachment(int projectId, int propertyId)
        {
            //ProjectProperty file = Get(id) as ProjectProperty;

            var projectProperties = FindByCriteria(FIND_BY_PROJECT, new object[] { projectId }) as ProjectPropertyCollection;
            if (projectProperties == null) return null;

            var file = projectProperties.OfType<ProjectProperty>().FirstOrDefault(p => p.PropertyId == propertyId);
            if (file != null && file.AttachmentId > 0)
            {
                var document = SCA.VAS.ECMWrapper.DocServiceHelper.DownloadDoc(file.AttachmentId);
                if (document == null) return null;

                return document;

                //return (byte[])SCA.VAS.ECMWrapper.DocServiceHelper.DownloadDoc(file.AttachmentId).Contents;
            }
            else
                return null;
        }

        public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 	
	}
}