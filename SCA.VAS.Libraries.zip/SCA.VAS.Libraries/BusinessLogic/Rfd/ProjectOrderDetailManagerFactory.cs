
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Factory for ProjectOrderDetailManager.
	/// </summary>
	#endregion Header
	
	public class ProjectOrderDetailManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static ProjectOrderDetailManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ProjectOrderDetailManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private ProjectOrderDetailManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the ProjectOrderDetailManagerFactory
		/// </summary>
		/// <returns>an instance of ProjectOrderDetailManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( ProjectOrderDetailManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new ProjectOrderDetailManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new ProjectOrderDetailManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new ProjectOrderDetailManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}