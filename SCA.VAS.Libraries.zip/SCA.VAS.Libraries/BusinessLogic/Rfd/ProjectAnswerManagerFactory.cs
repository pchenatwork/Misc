#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd
{
	#region	Header
	///	<summary>
	///	Factory for ProjectAnswer
	///	</summary>
	#endregion Header

	public sealed class ProjectAnswerManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members
		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static ProjectAnswerManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ProjectAnswerManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private ProjectAnswerManagerFactory()
		{
		} 

		#endregion Constructors
		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the ProjectAnswerManagerFactory
		/// </summary>
		/// <returns>an instance of ProjectAnswerManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( ProjectAnswerManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new ProjectAnswerManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new ProjectAnswerManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new ProjectAnswerManager( dataSourceName );
		} 
		#endregion Public Methods
	} 
} 