#region Copyright
/*=======================================================================
*
* Modification History:
* Date       Programmer Description
* 02-02-2005 Shawn Shi created
*
*=======================================================================
* Copyright ( C ) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd
{
	#region	Header
	///	<summary>
	///	Manager class for PlanProperty.
	///	</summary>
	#endregion Header

	[Serializable]
	public class PlanPropertyManager : AbstractManager
	{		
		#region	Constants
        public const string FIND_BY_PLAN = "FindPlanPropertyByPlan";
        public const string FIND_PLANPROPERTY_COUNT = "FindPlanPropertyCount";
        #endregion Constants

		#region	Private Members
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static PlanPropertyManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanPropertyManager ).FullName );
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public PlanPropertyManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public PlanPropertyManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName ( string )
		/// </summary>
		public override string DaoClassName
		{
			get
			{
                return "SCA.VAS.DataAccess.Rfd.PlanPropertyDao";
			}
		}

		public override IValueObject CreateObject()
		{
			return new PlanProperty();
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
        /// <summary>
        /// Remove the object from the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public override bool Delete(int id)
        {
            PlanProperty file = Get(id) as PlanProperty;
            if (file != null && file.AttachmentId > 0) SCA.VAS.ECMWrapper.DocServiceHelper.DeleteDoc(file.AttachmentId);
            return this.Dao.Delete(this.DataSource, id);
        }

        /// <summary>
        /// Update the object in the database.
        /// </summary>
        /// <returns></returns>
        public bool UpdateCollection(int planId, PlanPropertyCollection collection)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateCollection",
                new object[] { this.DataSource, planId, collection });
        }

        /// <summary>
        /// Update Attachment in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateAttachment(int id, int planId, int parentId, int propertyId, string attachmentName, byte[] attachment)
        {
            PlanProperty file = Get(id) as PlanProperty;
            if (file != null && file.AttachmentId > 0) SCA.VAS.ECMWrapper.DocServiceHelper.DeleteDoc(file.AttachmentId);
            return (bool)this.Dao.InvokeByMethodName("UpdateAttachment",
                new object[] { this.DataSource, id, planId, parentId, propertyId, attachmentName, attachment });
        }

        /// <summary>
        /// Remove attachment in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool DeleteAttachment(int id)
        {
            PlanProperty file = Get(id) as PlanProperty;
            if (file != null && file.AttachmentId > 0) SCA.VAS.ECMWrapper.DocServiceHelper.DeleteDoc(file.AttachmentId);
            return (bool)this.Dao.InvokeByMethodName("DeleteAttachment",
                new object[] { this.DataSource, id });
        }
		#endregion 
		
		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new PlanProperty object from the database.
		/// </summary>
		/// <param name="Id">PlanProperty Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}

        /// <summary>
        /// Get attachment from the database.
        /// </summary>
        /// <param name="Id">PlanProperty Id</param>
        /// <returns></returns>
        public byte[] GetAttachment(int id)
        {
            PlanProperty file = Get(id) as PlanProperty;
            if (file.AttachmentId > 0)
                return (byte[])SCA.VAS.ECMWrapper.DocServiceHelper.DownloadDoc(file.AttachmentId).Contents;
            else
                return (byte[])this.Dao.InvokeByMethodName("GetAttachment",
                new object[] { this.DataSource, id });
        }

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 
	} 
}