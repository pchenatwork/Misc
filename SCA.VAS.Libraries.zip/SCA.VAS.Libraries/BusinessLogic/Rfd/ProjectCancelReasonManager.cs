using System.Collections;
using log4net;
using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.ValueObjects.Rfd;

namespace SCA.VAS.BusinessLogic.Rfd
{
    public class ProjectCancelReasonManager : AbstractManager
    {
        #region	Constants
        // *************************************************************************
        //				 constants
        // *************************************************************************
        public const string FIND  = "FindProjectCancelReasons";
        #endregion Constants

        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        // Private members block	includes instance and static members & structs
        private static ILog _logger = null;
        #endregion Private Members

        #region	Constructors
        // *************************************************************************
        //				 Constructors
        // *************************************************************************
        /// <summary>
        /// class constructor 
        /// initializes logging
        /// </summary>
        static ProjectCancelReasonManager()
        {
            _logger = LoggingUtility.GetLogger(typeof(ProjectCancelReasonManager).FullName);
        } //	end	class constructor

        /// <summary>
        /// default	constructor	
        /// inits with default
        ///	</summary>
        public ProjectCancelReasonManager()
        {
        } // end constructor

        ///	<summary>
        /// default constructor	
        /// inits with a DataSource.
        ///	</summary>
        public ProjectCancelReasonManager(string dataSourceName) : base(dataSourceName)
        {
        }
        #endregion Constructors

        #region IManager
        // *************************************************************************
        //                IManager
        // *************************************************************************
        /// <summary>
        /// Property DaoClassName (string)
        /// </summary>
        public override string DaoClassName
        {
            get
            {
                return "SCA.VAS.DataAccess.Rfd.ProjectCancelReasonDao";
            }
        }

        public override IValueObject CreateObject()
        {
            return new ProjectCancelReason();
        }
        #endregion

        #region IPersistentManager
        // *************************************************************************
        //				 IPersistentManager
        // *************************************************************************
        /// <summary>
        /// Remove the object from the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public override bool Delete(int id)
        {
            ProjectCancelReason file = Get(id) as ProjectCancelReason;
            return this.Dao.Delete(this.DataSource, id);
        }

        /// <summary>
        /// Update the object in the database.
        /// </summary>
        /// <returns></returns>
        public bool UpdateCollection(ProjectCancelReasonCollection collection)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateCollection",
                new object[] { this.DataSource, collection });
        }
        #endregion

        #region IFinder
        // *************************************************************************
        //				 IFinder
        // *************************************************************************
        /// <summary>
        /// Get a new ProjectCancelReason object from the database.
        /// </summary>
        /// <param name="Id">ProjectCancelReason Id</param>
        /// <returns></returns>
        public override IValueObject Get(int id)
        {
            return this.Dao.Get(this.DataSource, id);
        }

        public override ICollection FindByCriteria(string finderType, object[] criteria)
        {
            return this.Dao.FindByCriteria(this.DataSource, finderType, criteria);
        }
        #endregion
    }
}