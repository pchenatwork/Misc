
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Factory for BidderRejectManager.
	/// </summary>
	#endregion Header
	
	public class BidderRejectManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static BidderRejectManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BidderRejectManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private BidderRejectManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the BidderRejectManagerFactory
		/// </summary>
		/// <returns>an instance of BidderRejectManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( BidderRejectManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new BidderRejectManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new BidderRejectManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new BidderRejectManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}