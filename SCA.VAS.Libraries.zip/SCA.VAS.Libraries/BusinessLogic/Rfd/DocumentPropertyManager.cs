﻿#region Copyright
/*=======================================================================
 * Modification History:
 * Date       Programmer Description
 * 06/16/2018 PCHEN  First Created
 *=======================================================================*/
#endregion

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References
namespace SCA.VAS.BusinessLogic.Rfd
{
    #region	Header
    ///	<summary>
    ///	Manager class for DocumentProperty.
    ///	</summary>
    #endregion Header

    [Serializable]
    public class DocumentPropertyManager :  AbstractManager
    {
        #region	Constants
        public const string FIND_BY_DOC = "FindDocumentProperty";
        public const string FIND_BY_ID = "GetDocumentProperty";
        public const string DOC_GROUP = "Project";
        #endregion Constants

        #region	Private Members
        // Private members block	includes instance and static members & structs
        private static ILog _logger = null;
        #endregion Private Members

        #region	Constructors
        // *************************************************************************
        //				 Constructors
        // *************************************************************************
        /// <summary>
        /// class constructor 
        /// initializes logging
        /// </summary>
        static DocumentPropertyManager()
        {
            _logger = LoggingUtility.GetLogger(typeof(DocumentPropertyManager).FullName);
        }
        public DocumentPropertyManager()
        {
        }
        public DocumentPropertyManager(string dataSourceName) : base(dataSourceName)
        {
        }
        #endregion Constructors

        #region IManager
        // *************************************************************************
        //                IManager
        // *************************************************************************
        /// <summary>
        /// Property DaoClassName ( string )
        /// </summary>
        public override string DaoClassName
        {
            get
            {
                return "SCA.VAS.DataAccess.Rfd.DocumentPropertyDao";
            }
        }

        public override IValueObject CreateObject()
        {
            return new DocumentProperty();
        }
        #endregion

        #region IPersistentManager
        // *************************************************************************
        //				 IPersistentManager
        // *************************************************************************
        /// <summary>
        /// Remove the DocumentProperty by setting Property Values to 0/NULL
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public override bool Delete(int id)
        {
            return this.Dao.Delete(this.DataSource, id);
        }

        /// <summary>
        /// Update the object in the database.
        /// </summary>
        /// <returns></returns>
        public bool UpdateCollection(int DocumentId, string DocGrp, CommonCollection<DocumentProperty> collection)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateCollection",
                new object[] { this.DataSource, DocumentId, DocGrp, collection });
        }
        #endregion

        #region IFinder
        // *************************************************************************
        //				 IFinder
        // *************************************************************************
        /// <summary>
        /// Get a new DocumentProperty object from the database.
        /// </summary>
        /// <param name="Id">DocumentProperty Id</param>
        /// <returns></returns>
        public override IValueObject Get(int id)
        {
            return this.Dao.Get(this.DataSource, id);
        }

        public override ICollection FindByCriteria(string finderType, object[] criteria)
        {
            return this.Dao.FindByCriteria(this.DataSource, finderType, criteria);
        }
        #endregion
    }
}
