
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Factory for ProjectAdsCategoryManager.
	/// </summary>
	#endregion Header
	
	public class ProjectAdsCategoryManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static ProjectAdsCategoryManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ProjectAdsCategoryManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private ProjectAdsCategoryManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the ProjectAdsCategoryManagerFactory
		/// </summary>
		/// <returns>an instance of ProjectAdsCategoryManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( ProjectAdsCategoryManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new ProjectAdsCategoryManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new ProjectAdsCategoryManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new ProjectAdsCategoryManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}