#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd
{
	#region	Header
	///	<summary>
	///	Factory for ProjectQuestion
	///	</summary>
	#endregion Header

	public sealed class ProjectQuestionManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members
		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static ProjectQuestionManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ProjectQuestionManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private ProjectQuestionManagerFactory()
		{
		} 

		#endregion Constructors
		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the ProjectQuestionManagerFactory
		/// </summary>
		/// <returns>an instance of ProjectQuestionManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( ProjectQuestionManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new ProjectQuestionManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new ProjectQuestionManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new ProjectQuestionManager( dataSourceName );
		}  
		#endregion Public Methods
	} 
} 