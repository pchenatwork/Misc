
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Factory for PlanWaiverCategoryManager.
	/// </summary>
	#endregion Header
	
	public class PlanWaiverCategoryManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static PlanWaiverCategoryManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanWaiverCategoryManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private PlanWaiverCategoryManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the PlanWaiverCategoryManagerFactory
		/// </summary>
		/// <returns>an instance of PlanWaiverCategoryManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( PlanWaiverCategoryManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new PlanWaiverCategoryManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new PlanWaiverCategoryManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new PlanWaiverCategoryManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}