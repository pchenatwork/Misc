#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 - 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd
{
	#region	Header
	///	<summary>
	///	Factory for CapacityContract
	///	</summary>
	#endregion Header

	public sealed class CapacityContractManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static CapacityContractManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CapacityContractManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private CapacityContractManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the CapacityContractManagerFactory
		/// </summary>
		/// <returns>an instance of CapacityContractManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( CapacityContractManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new CapacityContractManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance()
		{
			return new CapacityContractManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new CapacityContractManager( dataSourceName );
		} 
		#endregion Public Methods
	} 
} 
