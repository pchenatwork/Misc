
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{
    #region Header 
    /// <summary>
    /// Manager class for LookupSearch.
    /// </summary>
    #endregion Header

    public class LookupSearchManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string SEARCH_CESUSER = "SearchCesUser";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static LookupSearchManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CesUserManager ).FullName);
		} //	end	class constructor

		/// <summary>
		/// default	constructor	
		/// inits with default
		///	</summary>
		public LookupSearchManager()
		{
		} // end constructor

		///	<summary>
		/// default constructor	
		/// inits with a DataSource.
		///	</summary>
		public LookupSearchManager( string dataSourceName ) : base( dataSourceName )
		{
		}
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Rfd.LookupSearchDao";
			}
		}

        public override IValueObject CreateObject()
		{
			return new LookupSearch( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
        public ICollection Schools()
        {
            return (ICollection)this.Dao.InvokeByMethodName("Schools",
                new object[] { this.DataSource });
        }

        public ICollection ProjectOfficers(string officerType)
        {
            return (ICollection)this.Dao.InvokeByMethodName("ProjectOfficers",
                new object[] { this.DataSource, officerType });
        }

        public ICollection Boroughs()
        {
            return (ICollection)this.Dao.InvokeByMethodName("Boroughs",
                new object[] { this.DataSource});
        }

        public ICollection CreatePackages()
        {
            return (ICollection)this.Dao.InvokeByMethodName("CreatePackages",
                new object[] { this.DataSource });
        }

        public ICollection Packages()
        {
            return (ICollection)this.Dao.InvokeByMethodName("Packages",
                new object[] { this.DataSource });
        }

        public ICollection Designs()
        {
            return (ICollection)this.Dao.InvokeByMethodName("Designs",
                new object[] { this.DataSource });
        }

        public ICollection Solicitations()
        {
            return (ICollection)this.Dao.InvokeByMethodName("Solicitations",
                new object[] { this.DataSource });
        }

        #endregion
    }
}