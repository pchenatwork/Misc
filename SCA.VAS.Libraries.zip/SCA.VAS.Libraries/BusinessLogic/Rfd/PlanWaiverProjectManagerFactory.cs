
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Factory for PlanWaiverProjectManager.
	/// </summary>
	#endregion Header
	
	public class PlanWaiverProjectManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static PlanWaiverProjectManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanWaiverProjectManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private PlanWaiverProjectManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the PlanWaiverProjectManagerFactory
		/// </summary>
		/// <returns>an instance of PlanWaiverProjectManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( PlanWaiverProjectManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new PlanWaiverProjectManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new PlanWaiverProjectManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new PlanWaiverProjectManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}