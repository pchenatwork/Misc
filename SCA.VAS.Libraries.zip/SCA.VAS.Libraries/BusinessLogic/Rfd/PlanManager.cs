
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Manager class for Plan.
	/// </summary>
	#endregion Header
	
	public class PlanManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string SEARCH_PLAN = "SearchPlan";
		public const string FIND_BY_SUBCONTRACTOR = "FindPlanByPlanSubcontractor";
        public const string FIND_PLAN = "FindPlan";
        public const string FIND_PLAN_BY_OUTLOOK = "FindPlanByOutlook";
        public const string FIND_BY_SUPPLIER = "FindPlanBySupplier";
        public const string SEARCH_SUP_MONTHELY_REPORT = "SupMonthelyReport";
		public const string SEARCH_PLAN_FROM_SERVICE_CONTRACT = "SearchPlanFromServiceContract";


		#endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static PlanManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanManager ).FullName);
		} //	end	class constructor

		/// <summary>
		/// default	constructor	
		/// inits with default
		///	</summary>
		public PlanManager()
		{
		} // end constructor

		///	<summary>
		/// default constructor	
		/// inits with a DataSource.
		///	</summary>
		public PlanManager( string dataSourceName ) : base( dataSourceName )
		{
		}
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Rfd.PlanDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new Plan( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		/// <summary>
		/// Create a new Plan object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}


		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update(IValueObject existingObject)
		{
			return this.Dao.Update(this.DataSource, existingObject);
		}

        /// <summary>
        /// Update Status in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateStatus(int id, int status, string statusName)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateStatus",
                new object[] { this.DataSource, new object[] { id, status, statusName } });
        }

        /// <summary>
        /// Update TransactionId in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateTransactionId(int id, int transactionId)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateTransactionId",
                new object[] { this.DataSource, id, transactionId });
        }

        /// <summary>
        /// Copy Plan Wicks in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public void CopyWicks(int id, string changeUser)
        {
            this.Dao.InvokeByMethodName("CopyWicks",
                new object[] { this.DataSource, id, changeUser });
        }

        /// <summary>
        /// Import Plans in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public void ImportPlans()
        {
            this.Dao.InvokeByMethodName("ImportPlans",
                new object[] { this.DataSource});
        }
        
        public void UpdateUnSubmittedSUPs()
        {
            this.Dao.InvokeByMethodName("FixSUPs",
               new object[] { this.DataSource });
        }

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete( int id )
		{
			return this.Dao.Delete( this.DataSource, id );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new Plan object from the database.
		/// </summary>
		/// <param name="Id">Plan Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}

        /// <summary>
        /// Get a new Plan object from the database.
        /// </summary>
        /// <param name="planId">PlanId</param>
        /// <returns></returns>
        public IValueObject GetById(Guid planId)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("GetById",
                new object[] { this.DataSource, planId });
        }

		// PCHEN 042020 Not used, comment out
        ///// <summary>
        ///// Get a new Plan object from the database.
        ///// </summary>
        ///// <param name="projectId">ProjectId</param>
        ///// <returns></returns>
        //public IValueObject GetByProject(int projectId)
        //{
        //    return (IValueObject)this.Dao.InvokeByMethodName("GetByProject",
        //        new object[] { this.DataSource, projectId });
        //}

        ///// <summary>
        ///// Get a new Plan object from the database.
        ///// </summary>
        ///// <param name="contractId">ContractId</param>
        ///// <returns></returns>
        //public IValueObject GetByContract(int contractId)
        //{
        //    return (IValueObject)this.Dao.InvokeByMethodName("GetByContract",
        //        new object[] { this.DataSource, contractId });
        //}

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
        public ICollection GetMentorBidActivity(object[] criteria)
        {
            return (ICollection)this.Dao.InvokeByMethodName("GetMentorBidActivityReport",
                new object[] { this.DataSource, criteria });
        }

        public ICollection GetPreQualLimitedList(object[] criteria)
        {
            return (ICollection)this.Dao.InvokeByMethodName("GetPreQualLimitedListReport",
                new object[] { this.DataSource, criteria });
        }

		/// <summary>
		/// Create Plan for service contract
		/// </summary>
		/// <param name="newPlan"></param>
		/// <returns>New Plan.Id</returns>
		public int CreateForServiceContract(Plan newPlan)
		{
			return (int)this.Dao.InvokeByMethodName("CreateForServiceContract",
				new object[] { this.DataSource, newPlan });
		}
		/// <summary>
		/// Get Plan Financial Data (PaymentItems etc)
		/// </summary>
		/// <param name="PlanId"></param>
		/// <returns></returns>
		public PlanFinancial GetPlanFinancial(int PlanId)
		{
			return (PlanFinancial)this.Dao.InvokeByMethodName("GetPlanFinancial",
				new object[] { this.DataSource, PlanId });
		}

		#endregion
	}
}