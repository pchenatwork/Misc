
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Manager class for RfdSupplier.
	/// </summary>
	#endregion Header
	
	public class RfdSupplierManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string SEARCH_RFDSUPPLIER = "SearchRfdSupplier";
        public const string FIND_BY_OUTLOOK = "FindRfdSupplierByOutlook";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static RfdSupplierManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( RfdSupplierManager ).FullName);
		} //	end	class constructor

		/// <summary>
		/// default	constructor	
		/// inits with default
		///	</summary>
		public RfdSupplierManager()
		{
		} // end constructor

		///	<summary>
		/// default constructor	
		/// inits with a DataSource.
		///	</summary>
		public RfdSupplierManager( string dataSourceName ) : base( dataSourceName )
		{
		}
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Rfd.RfdSupplierDao";
			}
		}

        public override IValueObject CreateObject()
		{
			return new RfdSupplier( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		/// <summary>
		/// Create a new RfdSupplier object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update(IValueObject existingObject)
		{
			return this.Dao.Update(this.DataSource, existingObject);
		}

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete( int id )
		{
			return this.Dao.Delete( this.DataSource, id );
		}

        /// <summary>
        /// Update the objects in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="collection"></param>
        /// <returns></returns>
        public bool UpdateCollection(int rfdProjectId, RfdSupplierCollection collection)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateCollection",
                new object[] { this.DataSource, rfdProjectId, collection });
        }

        /// <summary>
        /// Delete the objects in the database.
        /// </summary>
        /// <returns></returns>
        public bool DeleteByProject(int rfdProjectId)
        {
            return (bool)this.Dao.InvokeByMethodName("DeleteByProject",
                new object[] { this.DataSource, rfdProjectId });
        }

        /// <summary>
        /// Update TransactionId in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateTransactionId(int id, int transactionId)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateTransactionId",
                new object[] { this.DataSource, id, transactionId });
        }

        /// <summary>
        /// Update Status in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateStatus(int id, int status, string changeUser)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateStatus",
                new object[] { this.DataSource, id, status, changeUser });
        }
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new RfdSupplier object from the database.
		/// </summary>
		/// <param name="Id">RfdSupplier Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}

        /// <summary>
        /// Get a new RfdSupplier object from the database.
        /// </summary>
        /// <param name="rfdProjectId">RfdProjectId</param>
        /// <param name="supplierId">SupplierId</param>
        /// <returns></returns>
        public IValueObject GetByProject(int rfdProjectId, int supplierId)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("GetByProject",
                new object[] { this.DataSource, rfdProjectId, supplierId });
        }

        /// <summary>
        /// Get a new RfdSupplier object from the database.
        /// </summary>
        /// <param name="rfdProjectId">RfdSupplierId</param>
        /// <returns></returns>
        public IValueObject GetById(Guid rfdProjectId)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("GetById",
                new object[] { this.DataSource, rfdProjectId });
        }

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 	
	}
}