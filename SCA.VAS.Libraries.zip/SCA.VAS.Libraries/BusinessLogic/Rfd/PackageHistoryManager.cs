#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Content
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd
{
	#region	Header
	///	<summary>
	///	Manager class for PackageHistory.
	///	</summary>
	#endregion Header

	public class PackageHistoryManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string FIND_BY_PACKAGE = "FindPackageHistory";
		#endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static PackageHistoryManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PackageHistoryManager ).FullName);
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public PackageHistoryManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public PackageHistoryManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Rfd.PackageHistoryDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new PackageHistory( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************

		/// <summary>
		/// Create a new PackageHistory object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update( IValueObject existingObject )
		{
			return this.Dao.Update( this.DataSource, existingObject );
		}

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete( int id )
		{
            PackageHistory file = Get(id) as PackageHistory;
            if (file != null && file.AttachmentId > 0) SCA.VAS.ECMWrapper.DocServiceHelper.DeleteDoc(file.AttachmentId);
            return this.Dao.Delete( this.DataSource, id );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new PackageHistory object from the database.
		/// </summary>
		/// <param name="Id">PackageHistory Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}

        /// <summary>
        /// Get a new PackageHistory object from the database.
        /// </summary>
        /// <param name="historyId">PackageHistory Id</param>
        /// <returns></returns>
        public IValueObject GetById(Guid historyId)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("GetById",
                new object[] { this.DataSource, historyId });
        }

        /// <summary>
        /// Get attachment from the database.
        /// </summary>
        /// <param name="Id">PackageHistory Id</param>
        /// <returns></returns>
        public byte[] GetAttachment(int id)
        {
            PackageHistory file = Get(id) as PackageHistory;
            if (file != null && file.AttachmentId > 0)
                return (byte[])SCA.VAS.ECMWrapper.DocServiceHelper.DownloadDoc(file.AttachmentId).Contents;
            else
                return (byte[])this.Dao.InvokeByMethodName("GetAttachment",
                new object[] { this.DataSource, id });
        }

		public override ICollection FindByCriteria( string finderType, object[] criteria )
        {
            return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 
	} 
} 
