
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Factory for SolicitContractManager.
	/// </summary>
	#endregion Header
	
	public class SolicitContractManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static SolicitContractManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( SolicitContractManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private SolicitContractManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the SolicitContractManagerFactory
		/// </summary>
		/// <returns>an instance of SolicitContractManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( SolicitContractManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new SolicitContractManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new SolicitContractManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new SolicitContractManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}