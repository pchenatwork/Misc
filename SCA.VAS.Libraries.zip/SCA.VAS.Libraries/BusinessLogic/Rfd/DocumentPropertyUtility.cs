﻿#region Header Comments
/*=======================================================================
 * Modification History:
 * Date       Programmer Description
 * 04/16/2018 PCHEN  First Created
*=======================================================================*/
#endregion

#region reference
using System;
using System.Data;
using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;
using SCA.VAS.DataAccess.Transactions;
using log4net;
#endregion

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{
    // DocumentPropertyUtility /// <summary>
    /// Transaction related utility functions.
    /// </summary>
    public class DocumentPropertyUtility
    {
        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        /// <summary>
        /// logging component
        /// </summary>
        private static ILog _logger;

        private static readonly DocumentPropertyManagerFactory _DocumentPropertyManagerFactory =
            (DocumentPropertyManagerFactory)DocumentPropertyManagerFactory.Instance();

        #endregion

        #region	Constructors
        // *************************************************************************
        //				 constructors
        // *************************************************************************
        static DocumentPropertyUtility()
        {
            _logger = LoggingUtility.GetLogger(typeof(DocumentPropertyUtility).FullName);
        }

        private DocumentPropertyUtility()
        {
        }
        #endregion

        #region	Public Methods
        //	*************************************************************************
        //				   public methods
        //	*************************************************************************
        public static DocumentProperty CreateObject()
        {
            DocumentPropertyManager DocumentPropertyManager = (DocumentPropertyManager)_DocumentPropertyManagerFactory.CreateInstance();

            return (DocumentProperty)DocumentPropertyManager.CreateObject();
        }

        public static bool UpdateCollection(string dataSourceName, int DocumentId, string DocumentGroup, CommonCollection<DocumentProperty> collection)
        {
            DocumentPropertyManager DocumentPropertyManager = (DocumentPropertyManager)_DocumentPropertyManagerFactory.CreateInstance(dataSourceName);

            return DocumentPropertyManager.UpdateCollection(DocumentId, DocumentGroup, collection);
        }

        public static bool Delete(string dataSourceName, int id)
        {
            DocumentPropertyManager DocumentPropertyManager = (DocumentPropertyManager)_DocumentPropertyManagerFactory.CreateInstance(dataSourceName);

            return DocumentPropertyManager.Delete(id);
        }

        public static DocumentProperty Get(string dataSourceName, int id)
        {
            DocumentPropertyManager DocumentPropertyManager = (DocumentPropertyManager)_DocumentPropertyManagerFactory.CreateInstance(dataSourceName);

            return (DocumentProperty)DocumentPropertyManager.Get(id);
        }

        public static CommonCollection<DocumentProperty> FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            DocumentPropertyManager DocumentPropertyManager = (DocumentPropertyManager)_DocumentPropertyManagerFactory.CreateInstance(dataSourceName);

            return (CommonCollection<DocumentProperty>)DocumentPropertyManager.FindByCriteria(finderType, criteria);
        }
        #endregion

    }
}
