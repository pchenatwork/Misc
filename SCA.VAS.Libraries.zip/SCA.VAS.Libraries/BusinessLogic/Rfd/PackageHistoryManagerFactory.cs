#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Content
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd
{
	#region	Header
	///	<summary>
	///	Factory for PackageHistory
	///	</summary>
	#endregion Header

	public sealed class PackageHistoryManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static PackageHistoryManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PackageHistoryManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private PackageHistoryManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the PackageHistoryManagerFactory
		/// </summary>
		/// <returns>an instance of PackageHistoryManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( PackageHistoryManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new PackageHistoryManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new PackageHistoryManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new PackageHistoryManager( dataSourceName );
		} 
		#endregion Public Methods
	} 
} 