
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Manager class for ProjectAward.
	/// </summary>
	#endregion Header
	
	public class ProjectAwardManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string SEARCH_PROJECTAWARD = "SearchProjectAward";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static ProjectAwardManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ProjectAwardManager ).FullName);
		} //	end	class constructor

		/// <summary>
		/// default	constructor	
		/// inits with default
		///	</summary>
		public ProjectAwardManager()
		{
		} // end constructor

		///	<summary>
		/// default constructor	
		/// inits with a DataSource.
		///	</summary>
		public ProjectAwardManager( string dataSourceName ) : base( dataSourceName )
		{
		}
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Rfd.ProjectAwardDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new ProjectAward( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
        /// <summary>
        /// Update the objects in the database.
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="collection"></param>
        /// <returns></returns>
        public bool UpdateCollection(int projectId, ProjectAwardCollection collection)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateCollection",
                new object[] { this.DataSource, projectId, collection });
        }
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new ProjectAward object from the database.
		/// </summary>
		/// <param name="Id">ProjectAward Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}

		public override ICollection GetAll()
		{
			return this.Dao.GetAll(this.DataSource);
		}

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}

        public override bool Delete(int id)
        {
            return this.Dao.Delete(this.DataSource, id);
        }
        #endregion
    }
}