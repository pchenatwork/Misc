
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Manager class for RfdProject.
	/// </summary>
	#endregion Header
	
	public class RfdProjectManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string SEARCH_RFDPROJECT = "SearchRfdProject";
        public const string FIND_RFDPROJECT_BY_OUTLOOK = "FindRfdProjectByOutlook";
        public const string FIND_RFDPROJECT_BY_EVENT = "FindRfdProjectByEvent";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static RfdProjectManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( RfdProjectManager ).FullName);
		} //	end	class constructor

		/// <summary>
		/// default	constructor	
		/// inits with default
		///	</summary>
		public RfdProjectManager()
		{
		} // end constructor

		///	<summary>
		/// default constructor	
		/// inits with a DataSource.
		///	</summary>
		public RfdProjectManager( string dataSourceName ) : base( dataSourceName )
		{
		}
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Rfd.RfdProjectDao";
			}
		}

        public override IValueObject CreateObject()
		{
			return new RfdProject( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		/// <summary>
		/// Create a new RfdProject object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update(IValueObject existingObject)
		{
			return this.Dao.Update(this.DataSource, existingObject);
		}

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public bool Delete( int id, string userName )
        {
            RfdProject file = Get(id) as RfdProject;
            if (file != null && file.AttachmentId > 0) SCA.VAS.ECMWrapper.DocServiceHelper.DeleteDoc(file.AttachmentId);
            return (bool)this.Dao.InvokeByMethodName("Delete",
                new object[] { this.DataSource, id, userName });
        }

        /// <summary>
        /// Import this object in the database.
        /// </summary>       
        /// <returns></returns>
        public int Import(string transNumber, int workflowId, int userId)
        {
            return (int)this.Dao.InvokeByMethodName("Import",
                new object[] { this.DataSource, transNumber, workflowId, userId });
        }

		/// <summary>
        /// Import Justification memo in the database.
        /// </summary>       
        /// <returns></returns>
        public int ImportJustificationMemo(int jmid, int workflowId, int userId)
        {
            return (int)this.Dao.InvokeByMethodName("ImportJustificationMemo",
                new object[] { this.DataSource, jmid, workflowId, userId });
        }

        /// <summary>
        /// Update TransactionId in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateTransactionId(int id, int transactionId)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateTransactionId",
                new object[] { this.DataSource, id, transactionId });
        }

        /// <summary>
        /// Update Status in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateStatus(int id, int status, string changeUser)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateStatus",
                new object[] { this.DataSource, id, status, changeUser });
        }

        /// <summary>
        /// Update attachment in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateAttachment(int id, string fileName, long attachmentId)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateAttachment",
                new object[] { this.DataSource, id, fileName, attachmentId });
        }

        /// <summary>
        /// Update ConstructionManagement in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateConstructionManagement(int id, string constructionManagement)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateConstructionManagement",
                new object[] { this.DataSource, id, constructionManagement });
        }

        /// <summary>
        /// Update Criteria in the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool UpdateCriteria(int id, string criteria)
        {
            return (bool)this.Dao.InvokeByMethodName("UpdateCriteria",
                new object[] { this.DataSource, id, criteria });
        }
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new RfdProject object from the database.
		/// </summary>
		/// <param name="Id">RfdProject Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}

        /// <summary>
        /// Get a new RfdProject object from the database.
        /// </summary>
        /// <param name="rfdProjectId">RfdProjectId</param>
        /// <returns></returns>
        public IValueObject GetById(Guid rfdProjectId)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("GetById",
                new object[] { this.DataSource, rfdProjectId });
        }

		public IValueObject GetByJmId(int jmId)
		{
			return (IValueObject)this.Dao.InvokeByMethodName("GetByJmId",
				new object[] { this.DataSource, jmId });
		}

		public IValueObject GetByNumber(string transNumber)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("GetByNumber",
                new object[] { this.DataSource, transNumber });
        }

        /// <summary>
        /// Get attachment from the database.
        /// </summary>
        /// <param name="Id">RfdProject Id</param>
        /// <returns></returns>
        public byte[] GetAttachment(int id)
        {
            RfdProject file = Get(id) as RfdProject;
            if (file != null && file.AttachmentId > 0)
                return (byte[])SCA.VAS.ECMWrapper.DocServiceHelper.DownloadDoc(file.AttachmentId).Contents;
            else
                return (byte[])this.Dao.InvokeByMethodName("GetAttachment",
                new object[] { this.DataSource, id });
        }

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 	
	}
}