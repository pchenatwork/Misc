#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd
{
	#region	Header
	///	<summary>
	///	Factory for PlanSubcontractorComment
	///	</summary>
	#endregion Header

	public sealed class PlanSubcontractorCommentManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static PlanSubcontractorCommentManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanSubcontractorCommentManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private PlanSubcontractorCommentManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the PlanSubcontractorCommentManagerFactory
		/// </summary>
		/// <returns>an instance of PlanSubcontractorCommentManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( PlanSubcontractorCommentManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new PlanSubcontractorCommentManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance()
		{
			return new PlanSubcontractorCommentManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new PlanSubcontractorCommentManager( dataSourceName );
		}  
		#endregion Public Methods
	} 
} 