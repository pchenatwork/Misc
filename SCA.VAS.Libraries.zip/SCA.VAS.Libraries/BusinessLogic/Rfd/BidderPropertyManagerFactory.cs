﻿#region Copyright
/*=======================================================================
*
* Modification History:
* Date       Programmer Description
* 4/18/2018  PCHEN      created by copying from PlanPropertyManagerFactory
*=======================================================================
* Copyright ( C ) 2018 NYCSCA VAS TEAM
* All rights reserved.
*=======================================================================*/
#endregion

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd
{
    #region	Header
    ///	<summary>
    ///	Factory for BidderProperty
    ///	</summary>
    #endregion Header

    public sealed class BidderPropertyManagerFactory : AbstractManagerFactory
    {
        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        /// <summary>the singleton factory instance</summary>
        private static IManagerFactory _factory = null;

        #endregion Private Members

        #region	Constructors
        // *************************************************************************
        //				 Constructors
        // *************************************************************************
        /// <summary>
        /// class constructor 
        /// initializes logging
        /// </summary>
        static BidderPropertyManagerFactory()
        {
            _logger = LoggingUtility.GetLogger(typeof(BidderPropertyManagerFactory).FullName);
        }

        ///	<summary>
        ///	No constructor	
        ///	</summary>
        private BidderPropertyManagerFactory()
        {
        }

        #endregion Constructors

        #region	Public Methods
        //	*************************************************************************
        //				   Public methods
        //	*************************************************************************
        /// <summary>
        /// Get singleton instance of the BidderPropertyManagerFactory
        /// </summary>
        /// <returns>an instance of BidderPropertyManagerFactory</returns>
        public static IManagerFactory Instance()
        {
            lock (typeof(BidderPropertyManagerFactory))
            {
                if (_factory == null)
                {
                    _factory = new BidderPropertyManagerFactory();
                }
                return _factory;
            }
        }

        /// <summary>
        /// Factory creation method for Manager instances
        /// </summary>
        /// <returns>
        /// an instance of Manager
        /// </returns>
        public override IManager CreateInstance()
        {
            return new BidderPropertyManager();
        }

        /// <summary>
        /// Factory creation method for Manager instances
        /// </summary>
        /// <returns>
        /// an instance of Manager
        /// </returns>
        public override IManager CreateInstance(string dataSourceName)
        {
            return new BidderPropertyManager(dataSourceName);
        }

        #endregion
    }
}