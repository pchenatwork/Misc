using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

namespace SCA.VAS.BusinessLogic.Rfd
{
    public class ProjectCancelReasonManagerFactory : AbstractManagerFactory
    {
        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        /// <summary>the singleton factory instance</summary>
        private static IManagerFactory _factory = null;

        #endregion Private Members

        #region	Constructors
        // *************************************************************************
        //				 Constructors
        // *************************************************************************
        /// <summary>
        /// class constructor 
        /// initializes logging
        /// </summary>
        static ProjectCancelReasonManagerFactory()
        {
            _logger = LoggingUtility.GetLogger(typeof(ProjectPropertyManagerFactory).FullName);
        }

        ///	<summary>
        ///	No constructor	
        ///	</summary>
        private ProjectCancelReasonManagerFactory()
        {
        }

        #endregion Constructors

        #region	Public Methods
        //	*************************************************************************
        //				   Public methods
        //	*************************************************************************
        /// <summary>
        /// Get singleton instance of the ProjectPropertyManagerFactory
        /// </summary>
        /// <returns>an instance of ProjectPropertyManagerFactory</returns>
        public static IManagerFactory Instance()
        {
            lock (typeof(ProjectCancelReasonManagerFactory))
            {
                if (_factory == null)
                {
                    _factory = new ProjectCancelReasonManagerFactory();
                }
                return _factory;
            }
        }

        /// <summary>
        /// Factory creation method for Manager instances
        /// </summary>
        /// <returns>
        /// an instance of Manager
        /// </returns>
        public override IManager CreateInstance()
        {
            return new ProjectCancelReasonManager();
        }

        /// <summary>
        /// Factory creation method for Manager instances
        /// </summary>
        /// <returns>
        /// an instance of Manager
        /// </returns>
        public override IManager CreateInstance(string dataSourceName)
        {
            return new ProjectCancelReasonManager(dataSourceName);
        }
        #endregion Public Methods
    }
}