#region Copyright
/*=======================================================================
*
* Modification History:
* Date       Programmer Description
* 02-02-2005 Shawn Shi created
*
*=======================================================================
* Copyright ( C ) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd
{
	#region	Header
	///	<summary>
	///	Factory for PlanProperty
	///	</summary>
	#endregion Header

	public sealed class PlanPropertyManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static PlanPropertyManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanPropertyManagerFactory ).FullName );
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private PlanPropertyManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the PlanPropertyManagerFactory
		/// </summary>
		/// <returns>an instance of PlanPropertyManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( PlanPropertyManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new PlanPropertyManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance()
		{
			return new PlanPropertyManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new PlanPropertyManager( dataSourceName );
		} 
		
		#endregion
	} 
} 