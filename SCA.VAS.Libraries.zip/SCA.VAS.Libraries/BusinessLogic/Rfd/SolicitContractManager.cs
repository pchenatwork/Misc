
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Rfd;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Manager class for SolicitContract.
	/// </summary>
	#endregion Header
	
	public class SolicitContractManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string SEARCH_SOLICITCONTRACT = "SearchSolicitContract";
        public const string FIND_SOLICITCONTRACT = "FindSolicitContract";
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static SolicitContractManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( SolicitContractManager ).FullName);
		} //	end	class constructor

		/// <summary>
		/// default	constructor	
		/// inits with default
		///	</summary>
		public SolicitContractManager()
		{
		} // end constructor

		///	<summary>
		/// default constructor	
		/// inits with a DataSource.
		///	</summary>
		public SolicitContractManager( string dataSourceName ) : base( dataSourceName )
		{
		}
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Rfd.SolicitContractDao";
			}
		}

        public override IValueObject CreateObject()
		{
			return new SolicitContract( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new SolicitContract object from the database.
		/// </summary>
		/// <param name="Id">SolicitContract Id</param>
		/// <returns></returns>
	    public IValueObject Get(string type, string contract, int solicitSeq)
        {
            return (IValueObject)this.Dao.InvokeByMethodName("Get",
                new object[] { this.DataSource, type, contract, solicitSeq });
        }

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 	
	}
}