
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd 
{ 
	#region Header 
	/// <summary>
	/// Factory for ProjectOfficialManager.
	/// </summary>
	#endregion Header
	
	public class ProjectOfficialManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static ProjectOfficialManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ProjectOfficialManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private ProjectOfficialManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the ProjectOfficialManagerFactory
		/// </summary>
		/// <returns>an instance of ProjectOfficialManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( ProjectOfficialManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new ProjectOfficialManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new ProjectOfficialManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new ProjectOfficialManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}