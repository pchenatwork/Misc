
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class BidderRejectUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BidderRejectManagerFactory _bidderRejectManagerFactory = 
			( BidderRejectManagerFactory ) BidderRejectManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BidderRejectUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BidderRejectUtility ).FullName);
		}

		private BidderRejectUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static BidderReject CreateObject( )
		{
			BidderRejectManager bidderRejectManager = ( BidderRejectManager ) _bidderRejectManagerFactory.CreateInstance( );

			return ( BidderReject )bidderRejectManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, BidderReject bidderReject )
		{
			BidderRejectManager bidderRejectManager = ( BidderRejectManager ) _bidderRejectManagerFactory.CreateInstance( dataSourceName );

			return bidderRejectManager.Create( bidderReject );
		}
		
		public static bool Update( string dataSourceName, BidderReject bidderReject )
		{
			BidderRejectManager bidderRejectManager = ( BidderRejectManager ) _bidderRejectManagerFactory.CreateInstance( dataSourceName );

			return bidderRejectManager.Update( bidderReject );
		}

        public static bool UpdateCollection(string dataSourceName, int bidderId, BidderRejectCollection collection)
        {
            BidderRejectManager bidderRejectManager = (BidderRejectManager)_bidderRejectManagerFactory.CreateInstance(dataSourceName);

            return bidderRejectManager.UpdateCollection(bidderId, collection);
        }
		
		public static bool Delete( string dataSourceName, int id )
		{
			BidderRejectManager bidderRejectManager = ( BidderRejectManager ) _bidderRejectManagerFactory.CreateInstance( dataSourceName );

			return bidderRejectManager.Delete( id );
		}

		public static BidderReject Get( string dataSourceName, int id )
		{
			BidderRejectManager bidderRejectManager = ( BidderRejectManager ) _bidderRejectManagerFactory.CreateInstance( dataSourceName );

			return ( BidderReject )bidderRejectManager.Get( id );
		}

		public static BidderRejectCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			BidderRejectManager bidderRejectManager = ( BidderRejectManager ) _bidderRejectManagerFactory.CreateInstance( dataSourceName );

			return ( BidderRejectCollection )bidderRejectManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}