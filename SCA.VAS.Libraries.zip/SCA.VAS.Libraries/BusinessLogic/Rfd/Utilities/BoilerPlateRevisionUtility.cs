
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class BoilerPlateRevisionUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BoilerPlateRevisionManagerFactory _boilerPlateRevisionManagerFactory = 
			( BoilerPlateRevisionManagerFactory ) BoilerPlateRevisionManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BoilerPlateRevisionUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BoilerPlateRevisionUtility ).FullName);
		}

		private BoilerPlateRevisionUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static BoilerPlateRevision CreateObject( )
		{
			BoilerPlateRevisionManager boilerPlateRevisionManager = ( BoilerPlateRevisionManager ) _boilerPlateRevisionManagerFactory.CreateInstance( );

			return ( BoilerPlateRevision )boilerPlateRevisionManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, BoilerPlateRevision boilerPlateRevision )
		{
			BoilerPlateRevisionManager boilerPlateRevisionManager = ( BoilerPlateRevisionManager ) _boilerPlateRevisionManagerFactory.CreateInstance( dataSourceName );

			return boilerPlateRevisionManager.Create( boilerPlateRevision );
		}
		
		public static bool Update( string dataSourceName, BoilerPlateRevision boilerPlateRevision )
		{
			BoilerPlateRevisionManager boilerPlateRevisionManager = ( BoilerPlateRevisionManager ) _boilerPlateRevisionManagerFactory.CreateInstance( dataSourceName );

			return boilerPlateRevisionManager.Update( boilerPlateRevision );
		}
		
		public static bool Delete( string dataSourceName, int id )
		{
			BoilerPlateRevisionManager boilerPlateRevisionManager = ( BoilerPlateRevisionManager ) _boilerPlateRevisionManagerFactory.CreateInstance( dataSourceName );

			return boilerPlateRevisionManager.Delete( id );
		}

		public static BoilerPlateRevision Get( string dataSourceName, int id )
		{
			BoilerPlateRevisionManager boilerPlateRevisionManager = ( BoilerPlateRevisionManager ) _boilerPlateRevisionManagerFactory.CreateInstance( dataSourceName );

			return ( BoilerPlateRevision )boilerPlateRevisionManager.Get( id );
		}

		public static BoilerPlateRevisionCollection GetAll(string dataSourceName)
		{
			BoilerPlateRevisionManager boilerPlateRevisionManager = (BoilerPlateRevisionManager)_boilerPlateRevisionManagerFactory.CreateInstance(dataSourceName);

			return (BoilerPlateRevisionCollection)boilerPlateRevisionManager.GetAll();
		}

		public static BoilerPlateRevisionCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			BoilerPlateRevisionManager boilerPlateRevisionManager = ( BoilerPlateRevisionManager ) _boilerPlateRevisionManagerFactory.CreateInstance( dataSourceName );

			return ( BoilerPlateRevisionCollection )boilerPlateRevisionManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}