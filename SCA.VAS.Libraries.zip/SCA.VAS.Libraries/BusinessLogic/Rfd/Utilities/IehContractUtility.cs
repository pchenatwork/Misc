#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.Common.Utilities;
using SCA.VAS.DataAccess.Transactions;
using SCA.VAS.ValueObjects.Rfd;

using log4net;

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{
    /// <summary>
    /// Transaction related utility functions.
    /// </summary>
    public class IehContractUtility
    {
        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        /// <summary>
        /// logging component
        /// </summary>
        private static ILog _logger;

        private static readonly IehContractManagerFactory _iehContractManagerFactory =
            (IehContractManagerFactory)IehContractManagerFactory.Instance();

        #endregion

        #region	Constructors
        // *************************************************************************
        //				 constructors
        // *************************************************************************
        static IehContractUtility()
        {
            _logger = LoggingUtility.GetLogger(typeof(IehContractUtility).FullName);
        }

        private IehContractUtility()
        {
        }
        #endregion

        #region	Public Methods
        //	*************************************************************************
        //				   public methods
        //	*************************************************************************
        public static IehContract CreateObject()
        {
            IehContractManager iehContractManager = (IehContractManager)_iehContractManagerFactory.CreateInstance();

            return (IehContract)iehContractManager.CreateObject();
        }

        public static IehContract Get(string dataSourceName, string taxId, string contractNo, string rfpNo)
        {
            IehContractManager iehContractManager = (IehContractManager)_iehContractManagerFactory.CreateInstance(dataSourceName);

            return (IehContract)iehContractManager.Get(taxId, contractNo, rfpNo);
        }

        public static IehContractCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            IehContractManager iehContractManager = (IehContractManager)_iehContractManagerFactory.CreateInstance(dataSourceName);

            return (IehContractCollection)iehContractManager.FindByCriteria(finderType, criteria);
        }
        #endregion

    }
}
