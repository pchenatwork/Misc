
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;
using SCA.VAS.DataAccess.Transactions;

using log4net;
using SCA.VAS.Common.ValueObjects;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class LookupSearchUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly LookupSearchManagerFactory _lookupSearchManagerFactory = 
			(LookupSearchManagerFactory)LookupSearchManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static LookupSearchUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CesUserUtility ).FullName);
		}

		private LookupSearchUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static LookupSearch CreateObject( )
		{
            LookupSearchManager lookupSearchManager = (LookupSearchManager) _lookupSearchManagerFactory.CreateInstance( );

			return (LookupSearch)lookupSearchManager.CreateObject( );
		}

        public static LookupSearchCollection Schools(string dataSourceName)
        {
            LookupSearchManager lookupSearchManager = (LookupSearchManager)_lookupSearchManagerFactory.CreateInstance(dataSourceName);

            return (LookupSearchCollection)lookupSearchManager.Schools();        
        }

        public static LookupSearchCollection Boroughs(string dataSourceName)
        {
            LookupSearchManager lookupSearchManager = (LookupSearchManager)_lookupSearchManagerFactory.CreateInstance(dataSourceName);

            return (LookupSearchCollection)lookupSearchManager.Boroughs();
        }

        public static LookupSearchCollection ProjectOfficers(string dataSourceName, string officerType)
        {
            LookupSearchManager lookupSearchManager = (LookupSearchManager)_lookupSearchManagerFactory.CreateInstance(dataSourceName);

            return (LookupSearchCollection)lookupSearchManager.ProjectOfficers(officerType);
        }

        public static LookupSearchCollection CreatePackages(string dataSourceName)
        {
            LookupSearchManager lookupSearchManager = (LookupSearchManager)_lookupSearchManagerFactory.CreateInstance(dataSourceName);

            return (LookupSearchCollection)lookupSearchManager.CreatePackages();
        }

        public static LookupSearchCollection Packages(string dataSourceName)
        {
            LookupSearchManager lookupSearchManager = (LookupSearchManager)_lookupSearchManagerFactory.CreateInstance(dataSourceName);

            return (LookupSearchCollection)lookupSearchManager.Packages();
        }

        public static LookupSearchCollection Designs(string dataSourceName)
        {
            LookupSearchManager lookupSearchManager = (LookupSearchManager)_lookupSearchManagerFactory.CreateInstance(dataSourceName);

            return (LookupSearchCollection)lookupSearchManager.Designs();
        }

        public static LookupSearchCollection Solicitations(string dataSourceName)
        {
            LookupSearchManager lookupSearchManager = (LookupSearchManager)_lookupSearchManagerFactory.CreateInstance(dataSourceName);

            return (LookupSearchCollection)lookupSearchManager.Solicitations();
        }        

        #endregion
    }
}