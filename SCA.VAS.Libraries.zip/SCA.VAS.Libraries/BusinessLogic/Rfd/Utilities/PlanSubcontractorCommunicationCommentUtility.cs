
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class PlanSubcontractorCommunicationCommentUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PlanSubcontractorCommunicationCommentManagerFactory _planSubcontractorCommunicationCommentManagerFactory = 
			( PlanSubcontractorCommunicationCommentManagerFactory ) PlanSubcontractorCommunicationCommentManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PlanSubcontractorCommunicationCommentUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanSubcontractorCommunicationCommentUtility ).FullName);
		}

		private PlanSubcontractorCommunicationCommentUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PlanSubcontractorCommunicationComment CreateObject( )
		{
			PlanSubcontractorCommunicationCommentManager planSubcontractorCommunicationCommentManager = ( PlanSubcontractorCommunicationCommentManager ) _planSubcontractorCommunicationCommentManagerFactory.CreateInstance( );

			return ( PlanSubcontractorCommunicationComment )planSubcontractorCommunicationCommentManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, PlanSubcontractorCommunicationComment planSubcontractorCommunicationComment )
		{
			PlanSubcontractorCommunicationCommentManager planSubcontractorCommunicationCommentManager = ( PlanSubcontractorCommunicationCommentManager ) _planSubcontractorCommunicationCommentManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorCommunicationCommentManager.Create( planSubcontractorCommunicationComment );
		}
		
		public static bool Update( string dataSourceName, PlanSubcontractorCommunicationComment planSubcontractorCommunicationComment )
		{
			PlanSubcontractorCommunicationCommentManager planSubcontractorCommunicationCommentManager = ( PlanSubcontractorCommunicationCommentManager ) _planSubcontractorCommunicationCommentManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorCommunicationCommentManager.Update( planSubcontractorCommunicationComment );
		}
		
		public static bool Delete( string dataSourceName, int id )
		{
			PlanSubcontractorCommunicationCommentManager planSubcontractorCommunicationCommentManager = ( PlanSubcontractorCommunicationCommentManager ) _planSubcontractorCommunicationCommentManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorCommunicationCommentManager.Delete( id );
		}

        public static bool DeleteAttachment(string dataSourceName, int id)
        {
            PlanSubcontractorCommunicationCommentManager planSubcontractorCommunicationCommentManager = (PlanSubcontractorCommunicationCommentManager)_planSubcontractorCommunicationCommentManagerFactory.CreateInstance(dataSourceName);

            return planSubcontractorCommunicationCommentManager.DeleteAttachment(id);
        }

		public static PlanSubcontractorCommunicationComment Get( string dataSourceName, int id )
		{
			PlanSubcontractorCommunicationCommentManager planSubcontractorCommunicationCommentManager = ( PlanSubcontractorCommunicationCommentManager ) _planSubcontractorCommunicationCommentManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractorCommunicationComment )planSubcontractorCommunicationCommentManager.Get( id );
		}

        public static PlanSubcontractorCommunicationComment GetById(string dataSourceName, Guid commentId)
        {
            PlanSubcontractorCommunicationCommentManager planSubcontractorCommunicationCommentManager = (PlanSubcontractorCommunicationCommentManager)_planSubcontractorCommunicationCommentManagerFactory.CreateInstance(dataSourceName);

            return (PlanSubcontractorCommunicationComment)planSubcontractorCommunicationCommentManager.GetById(commentId);
        }

        public static byte[] GetAttachment(string dataSourceName, int id)
        {
            PlanSubcontractorCommunicationCommentManager planSubcontractorCommunicationCommentManager = (PlanSubcontractorCommunicationCommentManager)_planSubcontractorCommunicationCommentManagerFactory.CreateInstance(dataSourceName);

            return (byte[])planSubcontractorCommunicationCommentManager.GetAttachment(id);
        }

		public static PlanSubcontractorCommunicationCommentCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PlanSubcontractorCommunicationCommentManager planSubcontractorCommunicationCommentManager = ( PlanSubcontractorCommunicationCommentManager ) _planSubcontractorCommunicationCommentManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractorCommunicationCommentCollection )planSubcontractorCommunicationCommentManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}