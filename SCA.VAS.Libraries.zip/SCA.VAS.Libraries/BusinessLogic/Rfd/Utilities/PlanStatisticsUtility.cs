
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class PlanStatisticsUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PlanStatisticsManagerFactory _planStatisticsManagerFactory = 
			( PlanStatisticsManagerFactory ) PlanStatisticsManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PlanStatisticsUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanStatisticsUtility ).FullName);
		}

		private PlanStatisticsUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PlanStatistics CreateObject( )
		{
			PlanStatisticsManager planStatisticsManager = ( PlanStatisticsManager ) _planStatisticsManagerFactory.CreateInstance( );

			return ( PlanStatistics )planStatisticsManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, PlanStatistics planStatistics )
		{
			PlanStatisticsManager planStatisticsManager = ( PlanStatisticsManager ) _planStatisticsManagerFactory.CreateInstance( dataSourceName );

			return planStatisticsManager.Create( planStatistics );
		}
		
		public static bool Update( string dataSourceName, PlanStatistics planStatistics )
		{
			PlanStatisticsManager planStatisticsManager = ( PlanStatisticsManager ) _planStatisticsManagerFactory.CreateInstance( dataSourceName );

			return planStatisticsManager.Update( planStatistics );
		}

        public static bool UpdateCollection(string dataSourceName, int planId, PlanStatisticsCollection collection)
        {
            PlanStatisticsManager planStatisticsManager = (PlanStatisticsManager)_planStatisticsManagerFactory.CreateInstance(dataSourceName);

            return planStatisticsManager.UpdateCollection(planId, collection);
        }

		public static bool Delete( string dataSourceName, int id )
		{
			PlanStatisticsManager planStatisticsManager = ( PlanStatisticsManager ) _planStatisticsManagerFactory.CreateInstance( dataSourceName );

			return planStatisticsManager.Delete( id );
		}

		public static PlanStatistics Get( string dataSourceName, int id )
		{
			PlanStatisticsManager planStatisticsManager = ( PlanStatisticsManager ) _planStatisticsManagerFactory.CreateInstance( dataSourceName );

			return ( PlanStatistics )planStatisticsManager.Get( id );
		}

        public static PlanStatisticsCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PlanStatisticsManager planStatisticsManager = ( PlanStatisticsManager ) _planStatisticsManagerFactory.CreateInstance( dataSourceName );

			return ( PlanStatisticsCollection )planStatisticsManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}