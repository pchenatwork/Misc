﻿#region Copyright
/*=======================================================================
*
* Modification History:
* Date       Programmer Description
* 04/18/2018 PCHEN  Created from copy
*=======================================================================
* Copyright ( C ) 2018 NYCSCA VAS TEAM
* All rights reserved.
*=======================================================================*/
#endregion

#region reference
using System;
using System.Data;
using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;
using SCA.VAS.DataAccess.Transactions;
using log4net;
#endregion

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{
    /// <summary>
    /// Transaction related utility functions.
    /// </summary>
    public class BidderPropertyUtility
    {
        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        /// <summary>
        /// logging component
        /// </summary>
        private static ILog _logger;

        private static readonly BidderPropertyManagerFactory _bidderPropertyManagerFactory =
            (BidderPropertyManagerFactory)BidderPropertyManagerFactory.Instance();

        #endregion

        #region	Constructors
        // *************************************************************************
        //				 constructors
        // *************************************************************************
        static BidderPropertyUtility()
        {
            _logger = LoggingUtility.GetLogger(typeof(BidderPropertyUtility).FullName);
        }

        private BidderPropertyUtility()
        {
        }
        #endregion

        #region	Public Methods
        //	*************************************************************************
        //				   public methods
        //	*************************************************************************
        public static BidderProperty CreateObject()
        {
            BidderPropertyManager bidderPropertyManager = (BidderPropertyManager)_bidderPropertyManagerFactory.CreateInstance();

            return (BidderProperty)bidderPropertyManager.CreateObject();
        }

        public static bool UpdateCollection(string dataSourceName, int bidderId, CommonCollection<BidderProperty> collection)
        {
            return UpdateCollection(dataSourceName, bidderId, collection, false);
        }
        public static bool UpdateCollection(string dataSourceName, int bidderId, CommonCollection<BidderProperty> collection,bool isBidderComment)
        {
            BidderPropertyManager bidderPropertyManager = (BidderPropertyManager)_bidderPropertyManagerFactory.CreateInstance(dataSourceName);

            return bidderPropertyManager.UpdateCollection(bidderId, collection,isBidderComment);
        }

        public static bool Delete(string dataSourceName, int id)
        {
            BidderPropertyManager bidderPropertyManager = (BidderPropertyManager)_bidderPropertyManagerFactory.CreateInstance(dataSourceName);

            return bidderPropertyManager.Delete(id);
        }

        public static BidderProperty Get(string dataSourceName, int id)
        {
            BidderPropertyManager bidderPropertyManager = (BidderPropertyManager)_bidderPropertyManagerFactory.CreateInstance(dataSourceName);

            return (BidderProperty)bidderPropertyManager.Get(id);
        }

        public static CommonCollection<BidderProperty> FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            BidderPropertyManager bidderPropertyManager = (BidderPropertyManager)_bidderPropertyManagerFactory.CreateInstance(dataSourceName);

            return (CommonCollection<BidderProperty>)bidderPropertyManager.FindByCriteria(finderType, criteria);
        }

        public static bool BidderNTEDivisionCalc(string dataSourceName, int id)
        {
            BidderPropertyManager bidderPropertyManager = (BidderPropertyManager)_bidderPropertyManagerFactory.CreateInstance(dataSourceName);

            return bidderPropertyManager.BidderNTEDivisionCalc(id);
        }
        #endregion

    }
}