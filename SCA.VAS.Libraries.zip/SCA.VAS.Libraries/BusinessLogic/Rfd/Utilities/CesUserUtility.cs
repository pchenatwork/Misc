
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class CesUserUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly CesUserManagerFactory _cesUserManagerFactory = 
			( CesUserManagerFactory ) CesUserManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static CesUserUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( CesUserUtility ).FullName);
		}

		private CesUserUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static CesUser CreateObject( )
		{
			CesUserManager cesUserManager = ( CesUserManager ) _cesUserManagerFactory.CreateInstance( );

			return ( CesUser )cesUserManager.CreateObject( );
		}

        public static CesUser Get(string dataSourceName, string empId)
        {
            CesUserManager cesUserManager = (CesUserManager)_cesUserManagerFactory.CreateInstance(dataSourceName);

            return (CesUser)cesUserManager.Get(empId);
        }

        public static CesUser GetByName(string dataSourceName, string firstName, string lastName)
        {
            CesUserManager cesUserManager = (CesUserManager)_cesUserManagerFactory.CreateInstance(dataSourceName);

            return (CesUser)cesUserManager.GetByName(firstName, lastName);
        }

        public static CesUserCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            CesUserManager cesUserManager = (CesUserManager)_cesUserManagerFactory.CreateInstance(dataSourceName);

            return (CesUserCollection)cesUserManager.FindByCriteria(finderType, criteria);
        }
		#endregion
	}
}