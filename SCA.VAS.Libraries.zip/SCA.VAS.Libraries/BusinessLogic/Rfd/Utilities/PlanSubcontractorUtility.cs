
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class PlanSubcontractorUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PlanSubcontractorManagerFactory _planSubcontractorManagerFactory = 
			( PlanSubcontractorManagerFactory ) PlanSubcontractorManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PlanSubcontractorUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanSubcontractorUtility ).FullName);
		}

		private PlanSubcontractorUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PlanSubcontractor CreateObject( )
		{
			PlanSubcontractorManager planSubcontractorManager = ( PlanSubcontractorManager ) _planSubcontractorManagerFactory.CreateInstance( );

			return ( PlanSubcontractor )planSubcontractorManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, PlanSubcontractor planSubcontractor )
		{
			PlanSubcontractorManager planSubcontractorManager = ( PlanSubcontractorManager ) _planSubcontractorManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorManager.Create( planSubcontractor );
		}
		
		public static bool Update( string dataSourceName, PlanSubcontractor planSubcontractor )
		{
			PlanSubcontractorManager planSubcontractorManager = ( PlanSubcontractorManager ) _planSubcontractorManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorManager.Update( planSubcontractor );
		}

        public static bool UpdateStatus(string dataSourceName, int id, int status, string statusName)
        {
            PlanSubcontractorManager planSubcontractorManager = (PlanSubcontractorManager)_planSubcontractorManagerFactory.CreateInstance(dataSourceName);

            return planSubcontractorManager.UpdateStatus(id, status, statusName);
        }

        public static bool UpdateTransactionId(string dataSourceName, int id, int transactionId)
        {
            PlanSubcontractorManager planSubcontractorManager = (PlanSubcontractorManager)_planSubcontractorManagerFactory.CreateInstance(dataSourceName);

            return planSubcontractorManager.UpdateTransactionId(id, transactionId);
        }

        public static bool Copy(string dataSourceName, int planId, int newPlanId, string changeUser)
        {
            PlanSubcontractorManager planSubcontractorManager = (PlanSubcontractorManager)_planSubcontractorManagerFactory.CreateInstance(dataSourceName);

            return planSubcontractorManager.Copy(planId, newPlanId, changeUser);
        }

        public static bool Import(string dataSourceName, int planId, int sAFId, string changeUser)
        {
            PlanSubcontractorManager planSubcontractorManager = (PlanSubcontractorManager)_planSubcontractorManagerFactory.CreateInstance(dataSourceName);

            return planSubcontractorManager.Import(planId, sAFId, changeUser);
        }

        public static bool Delete( string dataSourceName, int id )
		{
			PlanSubcontractorManager planSubcontractorManager = ( PlanSubcontractorManager ) _planSubcontractorManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorManager.Delete( id );
		}

		public static PlanSubcontractor Get( string dataSourceName, int id )
		{
			PlanSubcontractorManager planSubcontractorManager = ( PlanSubcontractorManager ) _planSubcontractorManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractor )planSubcontractorManager.Get( id );
		}

        public static PlanSubcontractor GetById(string dataSourceName, Guid planSubcontractorId)
        {
            PlanSubcontractorManager planSubcontractorManager = (PlanSubcontractorManager)_planSubcontractorManagerFactory.CreateInstance(dataSourceName);

            return (PlanSubcontractor)planSubcontractorManager.GetById(planSubcontractorId);
        }

		public static PlanSubcontractorCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PlanSubcontractorManager planSubcontractorManager = ( PlanSubcontractorManager ) _planSubcontractorManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractorCollection )planSubcontractorManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}