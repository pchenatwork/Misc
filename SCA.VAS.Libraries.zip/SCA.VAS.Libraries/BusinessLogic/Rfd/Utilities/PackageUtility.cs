#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class PackageUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PackageManagerFactory _packageManagerFactory = 
			( PackageManagerFactory ) PackageManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PackageUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PackageUtility ).FullName);
		}

		private PackageUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Package CreateObject( )
		{
			PackageManager packageManager = ( PackageManager ) _packageManagerFactory.CreateInstance( );

			return ( Package )packageManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, Package package )
		{
			PackageManager packageManager = ( PackageManager ) _packageManagerFactory.CreateInstance( dataSourceName );

			return packageManager.Create( package );
		}

		public static bool Update( string dataSourceName, Package package )
		{
			PackageManager packageManager = ( PackageManager ) _packageManagerFactory.CreateInstance( dataSourceName );

			return packageManager.Update( package );
		}

        public static bool UpdateCollection(string dataSourceName, string changeUser, string xml)
        {
            PackageManager packageManager = (PackageManager)_packageManagerFactory.CreateInstance(dataSourceName);

            return packageManager.UpdateCollection(changeUser, xml);
        }

        public static bool UpdateStatus(string dataSourceName, int id, int status)
        {
            PackageManager packageManager = (PackageManager)_packageManagerFactory.CreateInstance(dataSourceName);

            return packageManager.UpdateStatus(id, status);
        }

        public static bool UpdateTransactionId(string dataSourceName, int id, int transactionId)
        {
            PackageManager packageManager = (PackageManager)_packageManagerFactory.CreateInstance(dataSourceName);

            return packageManager.UpdateTransactionId(id, transactionId);
        }

        public static bool CheckOut(string dataSourceName, int id, int checkOutId, string checkOutType)
        {
            PackageManager packageManager = (PackageManager)_packageManagerFactory.CreateInstance(dataSourceName);

            return packageManager.CheckOut(id, checkOutId, checkOutType);
        }

        public static bool CancelCheckOut(string dataSourceName, int id)
        {
            PackageManager packageManager = (PackageManager)_packageManagerFactory.CreateInstance(dataSourceName);

            return packageManager.CancelCheckOut(id);
        }

        public static int CheckIn(string dataSourceName, int id, string changeUser)
        {
            PackageManager packageManager = (PackageManager)_packageManagerFactory.CreateInstance(dataSourceName);

            return packageManager.CheckIn(id, changeUser);
        }

        public static int CopyFromTemplate(string dataSourceName, int projectId, int addendumId, string type, int templateId, string userName)
        {
            PackageManager packageManager = (PackageManager)_packageManagerFactory.CreateInstance(dataSourceName);

            return packageManager.CopyFromTemplate(projectId, addendumId, type, templateId, userName);
        }

		public static bool Delete( string dataSourceName, int id )
		{
			PackageManager packageManager = ( PackageManager ) _packageManagerFactory.CreateInstance( dataSourceName );

			return packageManager.Delete( id );
		}

		public static Package Get( string dataSourceName, int id )
		{
			PackageManager packageManager = ( PackageManager ) _packageManagerFactory.CreateInstance( dataSourceName );

			return ( Package )packageManager.Get( id );
		}

        public static Package GetById(string dataSourceName, Guid packageId)
        {
            PackageManager packageManager = (PackageManager)_packageManagerFactory.CreateInstance(dataSourceName);

            return (Package)packageManager.GetById(packageId);
        }

        public static byte[] GetAttachment(string dataSourceName, int id)
        {
            PackageManager packageManager = (PackageManager)_packageManagerFactory.CreateInstance(dataSourceName);

            return (byte[])packageManager.GetAttachment(id);
        }

		public static PackageCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PackageManager packageManager = ( PackageManager ) _packageManagerFactory.CreateInstance( dataSourceName );

			return ( PackageCollection )packageManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
