#region Copyright
/*=======================================================================
*
* Modification History:
* Date       Programmer Description
* 02-03-2005 Shawn Shi created
*
*=======================================================================
* Copyright ( C ) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region reference
using System;
using System.Data;
using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;
using log4net;
#endregion

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class PlanPropertyUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PlanPropertyManagerFactory _planPropertyManagerFactory = 
			( PlanPropertyManagerFactory ) PlanPropertyManagerFactory.Instance();

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PlanPropertyUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanPropertyUtility ).FullName );
		}

		private PlanPropertyUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PlanProperty CreateObject()
		{
			PlanPropertyManager planPropertyManager = ( PlanPropertyManager ) _planPropertyManagerFactory.CreateInstance();

			return ( PlanProperty )planPropertyManager.CreateObject();
		}

        public static bool UpdateCollection(string dataSourceName, int planId, PlanPropertyCollection collection)
        {
            PlanPropertyManager planPropertyManager = (PlanPropertyManager)_planPropertyManagerFactory.CreateInstance(dataSourceName);

            return planPropertyManager.UpdateCollection(planId, collection);
        }

        public static bool UpdateAttachment(string dataSourceName, int id, int planId, int parentId, int propertyId, string attachmentName, byte[] attachment)
        {
            PlanPropertyManager planPropertyManager = (PlanPropertyManager)_planPropertyManagerFactory.CreateInstance(dataSourceName);

            return planPropertyManager.UpdateAttachment(id, planId, parentId, propertyId, attachmentName, attachment);
        }

        public static bool Delete(string dataSourceName, int id)
        {
            PlanPropertyManager planPropertyManager = (PlanPropertyManager)_planPropertyManagerFactory.CreateInstance(dataSourceName);

            return planPropertyManager.Delete(id);
        }

        public static bool DeleteAttachment(string dataSourceName, int id)
        {
            PlanPropertyManager planPropertyManager = (PlanPropertyManager)_planPropertyManagerFactory.CreateInstance(dataSourceName);

            return planPropertyManager.DeleteAttachment(id);
        }

		public static PlanProperty Get( string dataSourceName, int id )
		{
			PlanPropertyManager planPropertyManager = ( PlanPropertyManager ) _planPropertyManagerFactory.CreateInstance( dataSourceName );

			return ( PlanProperty )planPropertyManager.Get( id );
		}

        public static byte[] GetAttachment(string dataSourceName, int id)
        {
            PlanPropertyManager planPropertyManager = (PlanPropertyManager)_planPropertyManagerFactory.CreateInstance(dataSourceName);

            return (byte[])planPropertyManager.GetAttachment(id);
        }

		public static PlanPropertyCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PlanPropertyManager planPropertyManager = ( PlanPropertyManager ) _planPropertyManagerFactory.CreateInstance( dataSourceName );

			return ( PlanPropertyCollection )planPropertyManager.FindByCriteria( finderType, criteria );
		}

        public static bool UpdateProperties(string dataSourceName, int planId,
            PlanPropertyCollection collection, PlanPropertyCollection attachments)
        {
            TransactionContext context = TransactionContextFactory.GetContext(TransactionAffinity.Required);

            try
            {
                PlanPropertyManager planPropertyManager = (PlanPropertyManager)_planPropertyManagerFactory.CreateInstance(dataSourceName);

                context.Enter();

                bool bRet = planPropertyManager.UpdateCollection(planId, collection);
                if (bRet)
                {
                    if (attachments != null)
                    {
                        foreach (PlanProperty planProperty in attachments)
                        {
                            if (bRet && planProperty.Attachment != null)
                            {
                                bRet &= planPropertyManager.UpdateAttachment(planProperty.Id,
                                    planId, planProperty.ParentId, planProperty.PropertyId,
                                    planProperty.AttachmentName, planProperty.Attachment);
                            }
                        }
                    }
                }

                if (bRet)
                {
                    context.VoteCommit();
                    return true;
                }
                else
                {
                    context.VoteRollback();
                    return false;
                }
            }
            catch
            {
                context.VoteRollback();
                return false;
            }
            finally
            {
                context.Exit();
            }
        }
		#endregion

	}
}