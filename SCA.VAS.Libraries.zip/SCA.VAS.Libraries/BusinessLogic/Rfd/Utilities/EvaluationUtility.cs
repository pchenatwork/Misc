
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class EvaluationUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly EvaluationManagerFactory _evaluationManagerFactory = 
			( EvaluationManagerFactory ) EvaluationManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static EvaluationUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( EvaluationUtility ).FullName);
		}

		private EvaluationUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Evaluation CreateObject( )
		{
			EvaluationManager evaluationManager = ( EvaluationManager ) _evaluationManagerFactory.CreateInstance( );

			return ( Evaluation )evaluationManager.CreateObject( );
		}

		public static Evaluation Get( string dataSourceName, int id )
		{
			EvaluationManager evaluationManager = ( EvaluationManager ) _evaluationManagerFactory.CreateInstance( dataSourceName );

			return ( Evaluation )evaluationManager.Get( id );
		}

		public static EvaluationCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			EvaluationManager evaluationManager = ( EvaluationManager ) _evaluationManagerFactory.CreateInstance( dataSourceName );

			return ( EvaluationCollection )evaluationManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}