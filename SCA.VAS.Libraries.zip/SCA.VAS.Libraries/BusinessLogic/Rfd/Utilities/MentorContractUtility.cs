#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.Common.Utilities;
using SCA.VAS.DataAccess.Transactions;
using SCA.VAS.ValueObjects.Rfd;

using log4net;

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{
    /// <summary>
    /// Transaction related utility functions.
    /// </summary>
    public class MentorContractUtility
    {
        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        /// <summary>
        /// logging component
        /// </summary>
        private static ILog _logger;

        private static readonly MentorContractManagerFactory _mentorContractManagerFactory =
            (MentorContractManagerFactory)MentorContractManagerFactory.Instance();

        #endregion

        #region	Constructors
        // *************************************************************************
        //				 constructors
        // *************************************************************************
        static MentorContractUtility()
        {
            _logger = LoggingUtility.GetLogger(typeof(MentorContractUtility).FullName);
        }

        private MentorContractUtility()
        {
        }
        #endregion

        #region	Public Methods
        //	*************************************************************************
        //				   public methods
        //	*************************************************************************
        public static MentorContract CreateObject()
        {
            MentorContractManager mentorContractManager = (MentorContractManager)_mentorContractManagerFactory.CreateInstance();

            return (MentorContract)mentorContractManager.CreateObject();
        }

        public static MentorContract Get(string dataSourceName, string taxId, string contractNo, string projectNo, string subcontractor)
        {
            MentorContractManager mentorContractManager = (MentorContractManager)_mentorContractManagerFactory.CreateInstance(dataSourceName);

            return (MentorContract)mentorContractManager.Get(taxId, contractNo, projectNo, subcontractor);
        }

        public static MentorContractCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            MentorContractManager mentorContractManager = (MentorContractManager)_mentorContractManagerFactory.CreateInstance(dataSourceName);

            return (MentorContractCollection)mentorContractManager.FindByCriteria(finderType, criteria);
        }
        #endregion

    }
}
