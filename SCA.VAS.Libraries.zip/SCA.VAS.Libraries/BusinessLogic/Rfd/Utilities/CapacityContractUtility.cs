#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.Common.Utilities;
using SCA.VAS.DataAccess.Transactions;
using SCA.VAS.ValueObjects.Rfd;

using log4net;

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{
    /// <summary>
    /// Transaction related utility functions.
    /// </summary>
    public class CapacityContractUtility
    {
        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        /// <summary>
        /// logging component
        /// </summary>
        private static ILog _logger;

        private static readonly CapacityContractManagerFactory _capacityContractManagerFactory =
            (CapacityContractManagerFactory)CapacityContractManagerFactory.Instance();

        #endregion

        #region	Constructors
        // *************************************************************************
        //				 constructors
        // *************************************************************************
        static CapacityContractUtility()
        {
            _logger = LoggingUtility.GetLogger(typeof(CapacityContractUtility).FullName);
        }

        private CapacityContractUtility()
        {
        }
        #endregion

        #region	Public Methods
        //	*************************************************************************
        //				   public methods
        //	*************************************************************************
        public static CapacityContract CreateObject()
        {
            CapacityContractManager capacityContractManager = (CapacityContractManager)_capacityContractManagerFactory.CreateInstance();

            return (CapacityContract)capacityContractManager.CreateObject();
        }

        public static CapacityContract Get(string dataSourceName, string taxId, string contractNo, string projectNo)
        {
            CapacityContractManager capacityContractManager = (CapacityContractManager)_capacityContractManagerFactory.CreateInstance(dataSourceName);

            return (CapacityContract)capacityContractManager.Get(taxId, contractNo, projectNo);
        }

        public static CapacityContractCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            CapacityContractManager capacityContractManager = (CapacityContractManager)_capacityContractManagerFactory.CreateInstance(dataSourceName);

            return (CapacityContractCollection)capacityContractManager.FindByCriteria(finderType, criteria);
        }
        #endregion

    }
}
