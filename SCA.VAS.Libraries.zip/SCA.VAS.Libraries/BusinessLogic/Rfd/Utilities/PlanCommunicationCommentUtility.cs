
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class PlanCommunicationCommentUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PlanCommunicationCommentManagerFactory _planCommunicationCommentManagerFactory = 
			( PlanCommunicationCommentManagerFactory ) PlanCommunicationCommentManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PlanCommunicationCommentUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanCommunicationCommentUtility ).FullName);
		}

		private PlanCommunicationCommentUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PlanCommunicationComment CreateObject( )
		{
			PlanCommunicationCommentManager planCommunicationCommentManager = ( PlanCommunicationCommentManager ) _planCommunicationCommentManagerFactory.CreateInstance( );

			return ( PlanCommunicationComment )planCommunicationCommentManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, PlanCommunicationComment planCommunicationComment )
		{
			PlanCommunicationCommentManager planCommunicationCommentManager = ( PlanCommunicationCommentManager ) _planCommunicationCommentManagerFactory.CreateInstance( dataSourceName );

			return planCommunicationCommentManager.Create( planCommunicationComment );
		}
		
		public static bool Update( string dataSourceName, PlanCommunicationComment planCommunicationComment )
		{
			PlanCommunicationCommentManager planCommunicationCommentManager = ( PlanCommunicationCommentManager ) _planCommunicationCommentManagerFactory.CreateInstance( dataSourceName );

			return planCommunicationCommentManager.Update( planCommunicationComment );
		}
		
		public static bool Delete( string dataSourceName, int id )
		{
			PlanCommunicationCommentManager planCommunicationCommentManager = ( PlanCommunicationCommentManager ) _planCommunicationCommentManagerFactory.CreateInstance( dataSourceName );

			return planCommunicationCommentManager.Delete( id );
		}

        public static bool DeleteAttachment(string dataSourceName, int id)
        {
            PlanCommunicationCommentManager planCommunicationCommentManager = (PlanCommunicationCommentManager)_planCommunicationCommentManagerFactory.CreateInstance(dataSourceName);

            return planCommunicationCommentManager.DeleteAttachment(id);
        }

		public static PlanCommunicationComment Get( string dataSourceName, int id )
		{
			PlanCommunicationCommentManager planCommunicationCommentManager = ( PlanCommunicationCommentManager ) _planCommunicationCommentManagerFactory.CreateInstance( dataSourceName );

			return ( PlanCommunicationComment )planCommunicationCommentManager.Get( id );
		}

        public static PlanCommunicationComment GetById(string dataSourceName, Guid commentId)
        {
            PlanCommunicationCommentManager planCommunicationCommentManager = (PlanCommunicationCommentManager)_planCommunicationCommentManagerFactory.CreateInstance(dataSourceName);

            return (PlanCommunicationComment)planCommunicationCommentManager.GetById(commentId);
        }

        public static byte[] GetAttachment(string dataSourceName, int id)
        {
            PlanCommunicationCommentManager planCommunicationCommentManager = (PlanCommunicationCommentManager)_planCommunicationCommentManagerFactory.CreateInstance(dataSourceName);

            return (byte[])planCommunicationCommentManager.GetAttachment(id);
        }

		public static PlanCommunicationCommentCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PlanCommunicationCommentManager planCommunicationCommentManager = ( PlanCommunicationCommentManager ) _planCommunicationCommentManagerFactory.CreateInstance( dataSourceName );

			return ( PlanCommunicationCommentCollection )planCommunicationCommentManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}