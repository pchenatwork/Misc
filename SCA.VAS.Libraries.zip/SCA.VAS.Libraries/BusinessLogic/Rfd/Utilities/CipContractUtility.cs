#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.Common.Utilities;
using SCA.VAS.DataAccess.Transactions;
using SCA.VAS.ValueObjects.Rfd;

using log4net;

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{
    /// <summary>
    /// Transaction related utility functions.
    /// </summary>
    public class CipContractUtility
    {
        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        /// <summary>
        /// logging component
        /// </summary>
        private static ILog _logger;

        private static readonly CipContractManagerFactory _cipContractManagerFactory =
            (CipContractManagerFactory)CipContractManagerFactory.Instance();

        #endregion

        #region	Constructors
        // *************************************************************************
        //				 constructors
        // *************************************************************************
        static CipContractUtility()
        {
            _logger = LoggingUtility.GetLogger(typeof(CipContractUtility).FullName);
        }

        private CipContractUtility()
        {
        }
        #endregion

        #region	Public Methods
        //	*************************************************************************
        //				   public methods
        //	*************************************************************************
        public static CipContract CreateObject()
        {
            CipContractManager cipContractManager = (CipContractManager)_cipContractManagerFactory.CreateInstance();

            return (CipContract)cipContractManager.CreateObject();
        }

        public static CipContract Get(string dataSourceName, string taxId, string contractNo, string designCode)
        {
            CipContractManager cipContractManager = (CipContractManager)_cipContractManagerFactory.CreateInstance(dataSourceName);

            return (CipContract)cipContractManager.Get(taxId, contractNo, designCode);
        }

        public static CipContractCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            CipContractManager cipContractManager = (CipContractManager)_cipContractManagerFactory.CreateInstance(dataSourceName);

            return (CipContractCollection)cipContractManager.FindByCriteria(finderType, criteria);
        }
        #endregion

    }
}
