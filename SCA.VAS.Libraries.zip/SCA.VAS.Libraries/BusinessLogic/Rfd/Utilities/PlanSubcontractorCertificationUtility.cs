
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class PlanSubcontractorCertificationUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PlanSubcontractorCertificationManagerFactory _planSubcontractorCertificationManagerFactory = 
			( PlanSubcontractorCertificationManagerFactory ) PlanSubcontractorCertificationManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PlanSubcontractorCertificationUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanSubcontractorCertificationUtility ).FullName);
		}

		private PlanSubcontractorCertificationUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PlanSubcontractorCertification CreateObject( )
		{
			PlanSubcontractorCertificationManager planSubcontractorCertificationManager = ( PlanSubcontractorCertificationManager ) _planSubcontractorCertificationManagerFactory.CreateInstance( );

			return ( PlanSubcontractorCertification )planSubcontractorCertificationManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, PlanSubcontractorCertification planSubcontractorCertification )
		{
			PlanSubcontractorCertificationManager planSubcontractorCertificationManager = ( PlanSubcontractorCertificationManager ) _planSubcontractorCertificationManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorCertificationManager.Create( planSubcontractorCertification );
		}
		
		public static bool Update( string dataSourceName, PlanSubcontractorCertification planSubcontractorCertification )
		{
			PlanSubcontractorCertificationManager planSubcontractorCertificationManager = ( PlanSubcontractorCertificationManager ) _planSubcontractorCertificationManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorCertificationManager.Update( planSubcontractorCertification );
		}

        public static bool UpdateCollection(string dataSourceName, int planSubcontractorId, PlanSubcontractorCertificationCollection collection)
        {
            PlanSubcontractorCertificationManager planSubcontractorCertificationManager = (PlanSubcontractorCertificationManager)_planSubcontractorCertificationManagerFactory.CreateInstance(dataSourceName);

            return planSubcontractorCertificationManager.UpdateCollection(planSubcontractorId, collection);
        }
		
		public static bool Delete( string dataSourceName, int id )
		{
			PlanSubcontractorCertificationManager planSubcontractorCertificationManager = ( PlanSubcontractorCertificationManager ) _planSubcontractorCertificationManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorCertificationManager.Delete( id );
		}

		public static PlanSubcontractorCertification Get( string dataSourceName, int id )
		{
			PlanSubcontractorCertificationManager planSubcontractorCertificationManager = ( PlanSubcontractorCertificationManager ) _planSubcontractorCertificationManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractorCertification )planSubcontractorCertificationManager.Get( id );
		}

        public static PlanSubcontractorCertification GetById(string dataSourceName, Guid certificationId)
        {
            PlanSubcontractorCertificationManager planSubcontractorCertificationManager = (PlanSubcontractorCertificationManager)_planSubcontractorCertificationManagerFactory.CreateInstance(dataSourceName);

            return (PlanSubcontractorCertification)planSubcontractorCertificationManager.GetById(certificationId);
        }

        public static byte[] GetAttachment(string dataSourceName, int id)
        {
            PlanSubcontractorCertificationManager planSubcontractorCertificationManager = (PlanSubcontractorCertificationManager)_planSubcontractorCertificationManagerFactory.CreateInstance(dataSourceName);

            return (byte[])planSubcontractorCertificationManager.GetAttachment(id);
        }

		public static PlanSubcontractorCertificationCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PlanSubcontractorCertificationManager planSubcontractorCertificationManager = ( PlanSubcontractorCertificationManager ) _planSubcontractorCertificationManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractorCertificationCollection )planSubcontractorCertificationManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}