
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class LlwCodeUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly LlwCodeManagerFactory _llwCodeManagerFactory = 
			( LlwCodeManagerFactory ) LlwCodeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static LlwCodeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( LlwCodeUtility ).FullName);
		}

		private LlwCodeUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static LlwCode CreateObject( )
		{
			LlwCodeManager llwCodeManager = ( LlwCodeManager ) _llwCodeManagerFactory.CreateInstance( );

			return ( LlwCode )llwCodeManager.CreateObject( );
		}

        public static LlwCode Get(string dataSourceName, string llwNumber)
        {
            LlwCodeManager llwCodeManager = (LlwCodeManager)_llwCodeManagerFactory.CreateInstance(dataSourceName);

            return (LlwCode)llwCodeManager.Get(llwNumber);
        }

		public static LlwCodeCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			LlwCodeManager llwCodeManager = ( LlwCodeManager ) _llwCodeManagerFactory.CreateInstance( dataSourceName );

			return ( LlwCodeCollection )llwCodeManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}