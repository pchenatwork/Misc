
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class PlanSubcontractorDocumentUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PlanSubcontractorDocumentManagerFactory _planSubcontractorDocumentManagerFactory = 
			( PlanSubcontractorDocumentManagerFactory ) PlanSubcontractorDocumentManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PlanSubcontractorDocumentUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanSubcontractorDocumentUtility ).FullName);
		}

		private PlanSubcontractorDocumentUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PlanSubcontractorDocument CreateObject( )
		{
			PlanSubcontractorDocumentManager planSubcontractorDocumentManager = ( PlanSubcontractorDocumentManager ) _planSubcontractorDocumentManagerFactory.CreateInstance( );

			return ( PlanSubcontractorDocument )planSubcontractorDocumentManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, PlanSubcontractorDocument planSubcontractorDocument )
		{
			PlanSubcontractorDocumentManager planSubcontractorDocumentManager = ( PlanSubcontractorDocumentManager ) _planSubcontractorDocumentManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorDocumentManager.Create( planSubcontractorDocument );
		}
		
		public static bool Update( string dataSourceName, PlanSubcontractorDocument planSubcontractorDocument )
		{
			PlanSubcontractorDocumentManager planSubcontractorDocumentManager = ( PlanSubcontractorDocumentManager ) _planSubcontractorDocumentManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorDocumentManager.Update( planSubcontractorDocument );
		}

        public static bool UpdateCollection(string dataSourceName, int planSubcontractorId, PlanSubcontractorDocumentCollection collection)
        {
            PlanSubcontractorDocumentManager planSubcontractorDocumentManager = (PlanSubcontractorDocumentManager)_planSubcontractorDocumentManagerFactory.CreateInstance(dataSourceName);

            return planSubcontractorDocumentManager.UpdateCollection(planSubcontractorId, collection);
        }

        public static bool Delete( string dataSourceName, int id )
		{
			PlanSubcontractorDocumentManager planSubcontractorDocumentManager = ( PlanSubcontractorDocumentManager ) _planSubcontractorDocumentManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorDocumentManager.Delete( id );
		}

		public static PlanSubcontractorDocument Get( string dataSourceName, int id )
		{
			PlanSubcontractorDocumentManager planSubcontractorDocumentManager = ( PlanSubcontractorDocumentManager ) _planSubcontractorDocumentManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractorDocument )planSubcontractorDocumentManager.Get( id );
		}

        public static PlanSubcontractorDocument GetById(string dataSourceName, Guid documentId)
        {
            PlanSubcontractorDocumentManager planSubcontractorDocumentManager = (PlanSubcontractorDocumentManager)_planSubcontractorDocumentManagerFactory.CreateInstance(dataSourceName);

            return (PlanSubcontractorDocument)planSubcontractorDocumentManager.GetById(documentId);
        }

        public static byte[] GetAttachment(string dataSourceName, int id)
        {
            PlanSubcontractorDocumentManager planSubcontractorDocumentManager = (PlanSubcontractorDocumentManager)_planSubcontractorDocumentManagerFactory.CreateInstance(dataSourceName);

            return (byte[])planSubcontractorDocumentManager.GetAttachment(id);
        }

		public static PlanSubcontractorDocumentCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PlanSubcontractorDocumentManager planSubcontractorDocumentManager = ( PlanSubcontractorDocumentManager ) _planSubcontractorDocumentManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractorDocumentCollection )planSubcontractorDocumentManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}