
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class BidderWicksUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BidderWicksManagerFactory _bidderWicksManagerFactory = 
			( BidderWicksManagerFactory ) BidderWicksManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BidderWicksUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BidderWicksUtility ).FullName);
		}

		private BidderWicksUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static BidderWicks CreateObject( )
		{
			BidderWicksManager bidderWicksManager = ( BidderWicksManager ) _bidderWicksManagerFactory.CreateInstance( );

			return ( BidderWicks )bidderWicksManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, BidderWicks bidderWicks )
		{
			BidderWicksManager bidderWicksManager = ( BidderWicksManager ) _bidderWicksManagerFactory.CreateInstance( dataSourceName );

			return bidderWicksManager.Create( bidderWicks );
		}
		
		public static bool Update( string dataSourceName, BidderWicks bidderWicks )
		{
			BidderWicksManager bidderWicksManager = ( BidderWicksManager ) _bidderWicksManagerFactory.CreateInstance( dataSourceName );

			return bidderWicksManager.Update( bidderWicks );
		}
		
		public static bool Delete( string dataSourceName, int id )
		{
			BidderWicksManager bidderWicksManager = ( BidderWicksManager ) _bidderWicksManagerFactory.CreateInstance( dataSourceName );

			return bidderWicksManager.Delete( id );
		}

		public static BidderWicks Get( string dataSourceName, int id )
		{
			BidderWicksManager bidderWicksManager = ( BidderWicksManager ) _bidderWicksManagerFactory.CreateInstance( dataSourceName );

			return ( BidderWicks )bidderWicksManager.Get( id );
		}

        public static BidderWicksCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			BidderWicksManager bidderWicksManager = ( BidderWicksManager ) _bidderWicksManagerFactory.CreateInstance( dataSourceName );

			return ( BidderWicksCollection )bidderWicksManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}