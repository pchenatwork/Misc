
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class BidderUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BidderManagerFactory _bidderManagerFactory = 
			( BidderManagerFactory ) BidderManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BidderUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BidderUtility ).FullName);
		}

		private BidderUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Bidder CreateObject( )
		{
			BidderManager bidderManager = ( BidderManager ) _bidderManagerFactory.CreateInstance( );

			return ( Bidder )bidderManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, Bidder bidder )
		{
			BidderManager bidderManager = ( BidderManager ) _bidderManagerFactory.CreateInstance( dataSourceName );

			return bidderManager.Create( bidder );
		}
		
		public static bool Update( string dataSourceName, Bidder bidder )
		{
			BidderManager bidderManager = ( BidderManager ) _bidderManagerFactory.CreateInstance( dataSourceName );

			return bidderManager.Update( bidder );
		}

        public static bool UpdateCollection(string dataSourceName, int projectId, BidderCollection collection)
        {
            BidderManager bidderManager = (BidderManager)_bidderManagerFactory.CreateInstance(dataSourceName);

            return bidderManager.UpdateCollection(projectId, collection);
        }
		
		public static bool Delete( string dataSourceName, int id )
		{
			BidderManager bidderManager = ( BidderManager ) _bidderManagerFactory.CreateInstance( dataSourceName );

			return bidderManager.Delete( id );
		}

		public static Bidder Get( string dataSourceName, int id )
		{
			BidderManager bidderManager = ( BidderManager ) _bidderManagerFactory.CreateInstance( dataSourceName );

			return ( Bidder )bidderManager.Get( id );
		}

		public static BidderCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			BidderManager bidderManager = ( BidderManager ) _bidderManagerFactory.CreateInstance( dataSourceName );

			return ( BidderCollection )bidderManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}