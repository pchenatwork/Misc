#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class PlanCommentUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PlanCommentManagerFactory _planCommentManagerFactory = 
			( PlanCommentManagerFactory ) PlanCommentManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PlanCommentUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanCommentUtility ).FullName);
		}

		private PlanCommentUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PlanComment CreateObject( )
		{
			PlanCommentManager planCommentManager = ( PlanCommentManager ) _planCommentManagerFactory.CreateInstance( );

			return ( PlanComment )planCommentManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, PlanComment planComment )
		{
			PlanCommentManager planCommentManager = ( PlanCommentManager ) _planCommentManagerFactory.CreateInstance( dataSourceName );

			return planCommentManager.Create( planComment );
		}
		
		public static bool Update( string dataSourceName, PlanComment planComment )
		{
			PlanCommentManager planCommentManager = ( PlanCommentManager ) _planCommentManagerFactory.CreateInstance( dataSourceName );

			return planCommentManager.Update( planComment );
		}
		
		public static bool Delete( string dataSourceName, int id )
		{
			PlanCommentManager planCommentManager = ( PlanCommentManager ) _planCommentManagerFactory.CreateInstance( dataSourceName );

			return planCommentManager.Delete( id );
		}

        public static bool DeleteAttachment(string dataSourceName, int id)
        {
            PlanCommentManager planCommentManager = (PlanCommentManager)_planCommentManagerFactory.CreateInstance(dataSourceName);

            return planCommentManager.DeleteAttachment(id);
        }

		public static PlanComment Get( string dataSourceName, int id )
		{
			PlanCommentManager planCommentManager = ( PlanCommentManager ) _planCommentManagerFactory.CreateInstance( dataSourceName );

			return ( PlanComment )planCommentManager.Get( id );
		}

        public static PlanComment GetById(string dataSourceName, Guid commentId)
        {
            PlanCommentManager planCommentManager = (PlanCommentManager)_planCommentManagerFactory.CreateInstance(dataSourceName);

            return (PlanComment)planCommentManager.GetById(commentId);
        }

        public static byte[] GetAttachment(string dataSourceName, int id)
        {
            PlanCommentManager planCommentManager = (PlanCommentManager)_planCommentManagerFactory.CreateInstance(dataSourceName);

            return (byte[])planCommentManager.GetAttachment(id);
        }

		public static PlanCommentCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PlanCommentManager planCommentManager = ( PlanCommentManager ) _planCommentManagerFactory.CreateInstance( dataSourceName );

			return ( PlanCommentCollection )planCommentManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}