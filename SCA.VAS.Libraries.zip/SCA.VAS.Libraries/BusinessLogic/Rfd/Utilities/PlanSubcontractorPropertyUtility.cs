#region Copyright
/*=======================================================================
*
* Modification History:
* Date       Programmer Description
* 02-03-2005 Shawn Shi created
*
*=======================================================================
* Copyright ( C ) 2005 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion

#region reference
using System;
using System.Data;
using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;
using log4net;
#endregion

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class PlanSubcontractorPropertyUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PlanSubcontractorPropertyManagerFactory _planSubcontractorPropertyManagerFactory = 
			( PlanSubcontractorPropertyManagerFactory ) PlanSubcontractorPropertyManagerFactory.Instance();

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PlanSubcontractorPropertyUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanSubcontractorPropertyUtility ).FullName );
		}

		private PlanSubcontractorPropertyUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PlanSubcontractorProperty CreateObject()
		{
			PlanSubcontractorPropertyManager planSubcontractorPropertyManager = ( PlanSubcontractorPropertyManager ) _planSubcontractorPropertyManagerFactory.CreateInstance();

			return ( PlanSubcontractorProperty )planSubcontractorPropertyManager.CreateObject();
		}

        public static bool UpdateCollection(string dataSourceName, int planSubcontractorId, PlanSubcontractorPropertyCollection collection)
        {
            PlanSubcontractorPropertyManager planSubcontractorPropertyManager = (PlanSubcontractorPropertyManager)_planSubcontractorPropertyManagerFactory.CreateInstance(dataSourceName);

            return planSubcontractorPropertyManager.UpdateCollection(planSubcontractorId, collection);
        }

        public static bool UpdateAttachment(string dataSourceName, int id, int planSubcontractorId, int parentId, int propertyId, string attachmentName, byte[] attachment)
        {
            PlanSubcontractorPropertyManager planSubcontractorPropertyManager = (PlanSubcontractorPropertyManager)_planSubcontractorPropertyManagerFactory.CreateInstance(dataSourceName);

            return planSubcontractorPropertyManager.UpdateAttachment(id, planSubcontractorId, parentId, propertyId, attachmentName, attachment);
        }

        public static bool Delete(string dataSourceName, int id)
        {
            PlanSubcontractorPropertyManager planSubcontractorPropertyManager = (PlanSubcontractorPropertyManager)_planSubcontractorPropertyManagerFactory.CreateInstance(dataSourceName);

            return planSubcontractorPropertyManager.Delete(id);
        }

        public static bool DeleteAttachment(string dataSourceName, int id)
        {
            PlanSubcontractorPropertyManager planSubcontractorPropertyManager = (PlanSubcontractorPropertyManager)_planSubcontractorPropertyManagerFactory.CreateInstance(dataSourceName);

            return planSubcontractorPropertyManager.DeleteAttachment(id);
        }

		public static PlanSubcontractorProperty Get( string dataSourceName, int id )
		{
			PlanSubcontractorPropertyManager planSubcontractorPropertyManager = ( PlanSubcontractorPropertyManager ) _planSubcontractorPropertyManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractorProperty )planSubcontractorPropertyManager.Get( id );
		}

        public static byte[] GetAttachment(string dataSourceName, int id)
        {
            PlanSubcontractorPropertyManager planSubcontractorPropertyManager = (PlanSubcontractorPropertyManager)_planSubcontractorPropertyManagerFactory.CreateInstance(dataSourceName);

            return (byte[])planSubcontractorPropertyManager.GetAttachment(id);
        }

		public static PlanSubcontractorPropertyCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PlanSubcontractorPropertyManager planSubcontractorPropertyManager = ( PlanSubcontractorPropertyManager ) _planSubcontractorPropertyManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractorPropertyCollection )planSubcontractorPropertyManager.FindByCriteria( finderType, criteria );
		}

        public static bool UpdateProperties(string dataSourceName, int planSubcontractorId,
            PlanSubcontractorPropertyCollection collection, PlanSubcontractorPropertyCollection attachments)
        {
            TransactionContext context = TransactionContextFactory.GetContext(TransactionAffinity.Required);

            try
            {
                PlanSubcontractorPropertyManager planSubcontractorPropertyManager = (PlanSubcontractorPropertyManager)_planSubcontractorPropertyManagerFactory.CreateInstance(dataSourceName);

                context.Enter();

                bool bRet = planSubcontractorPropertyManager.UpdateCollection(planSubcontractorId, collection);
                if (bRet)
                {
                    if (attachments != null)
                    {
                        foreach (PlanSubcontractorProperty planSubcontractorProperty in attachments)
                        {
                            if (bRet && planSubcontractorProperty.Attachment != null)
                            {
                                bRet &= planSubcontractorPropertyManager.UpdateAttachment(planSubcontractorProperty.Id,
                                    planSubcontractorId, planSubcontractorProperty.ParentId, planSubcontractorProperty.PropertyId,
                                    planSubcontractorProperty.AttachmentName, planSubcontractorProperty.Attachment);
                            }
                        }
                    }
                }

                if (bRet)
                {
                    context.VoteCommit();
                    return true;
                }
                else
                {
                    context.VoteRollback();
                    return false;
                }
            }
            catch
            {
                context.VoteRollback();
                return false;
            }
            finally
            {
                context.Exit();
            }
        }
		#endregion

	}
}