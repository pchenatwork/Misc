
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class BidderDocumentUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BidderDocumentManagerFactory _bidderDocumentManagerFactory = 
			(BidderDocumentManagerFactory)BidderDocumentManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BidderDocumentUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BidderDocumentUtility ).FullName);
		}

		private BidderDocumentUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static BidderDocument CreateObject( )
		{
			BidderDocumentManager BidderDocumentManager = ( BidderDocumentManager ) _bidderDocumentManagerFactory.CreateInstance( );

			return ( BidderDocument )BidderDocumentManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, BidderDocument bidderDocument )
		{
			BidderDocumentManager bidderDocumentManager = ( BidderDocumentManager ) _bidderDocumentManagerFactory.CreateInstance( dataSourceName );

			return bidderDocumentManager.Create( bidderDocument );
		}
		
		public static bool Update( string dataSourceName, BidderDocument projectDocument )
		{
			BidderDocumentManager bidderDocumentManager = ( BidderDocumentManager ) _bidderDocumentManagerFactory.CreateInstance( dataSourceName );

			return bidderDocumentManager.Update( projectDocument );
		}

        
		public static bool Delete( string dataSourceName, int id )
		{
			BidderDocumentManager bidderDocumentManager = ( BidderDocumentManager ) _bidderDocumentManagerFactory.CreateInstance( dataSourceName );

			return bidderDocumentManager.Delete( id );
		}
        

		public static BidderDocument Get( string dataSourceName, int id )
		{
			BidderDocumentManager bidderDocumentManager = ( BidderDocumentManager ) _bidderDocumentManagerFactory.CreateInstance( dataSourceName );

			return ( BidderDocument )bidderDocumentManager.Get( id );
		}

        public static BidderDocument GetByType(string dataSourceName, int projectId, int refId, string type)
        {
            BidderDocumentManager bidderDocumentManager = (BidderDocumentManager)_bidderDocumentManagerFactory.CreateInstance(dataSourceName);

            return (BidderDocument)bidderDocumentManager.GetByType(projectId, refId, type);
        }

        public static byte[] GetAttachment(string dataSourceName, int id)
        {
            BidderDocumentManager bidderDocumentManager = (BidderDocumentManager)_bidderDocumentManagerFactory.CreateInstance(dataSourceName);

            return (byte[])bidderDocumentManager.GetAttachment(id);
        }

		public static ProjectDocumentCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			BidderDocumentManager bidderDocumentManager = ( BidderDocumentManager ) _bidderDocumentManagerFactory.CreateInstance( dataSourceName );

			return ( ProjectDocumentCollection )bidderDocumentManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}