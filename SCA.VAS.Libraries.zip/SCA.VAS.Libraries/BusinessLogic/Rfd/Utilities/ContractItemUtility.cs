
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class ContractItemUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly ContractItemManagerFactory _contractItemManagerFactory = 
			( ContractItemManagerFactory ) ContractItemManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static ContractItemUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ContractItemUtility ).FullName);
		}

		private ContractItemUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static ContractItem CreateObject( )
		{
			ContractItemManager contractItemManager = ( ContractItemManager ) _contractItemManagerFactory.CreateInstance( );

			return ( ContractItem )contractItemManager.CreateObject( );
		}
		#endregion
	}
}