
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class BidderApprenticeshipProgramUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BidderApprenticeshipProgramManagerFactory _bidderApprenticeshipProgramManagerFactory = 
			( BidderApprenticeshipProgramManagerFactory ) BidderApprenticeshipProgramManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BidderApprenticeshipProgramUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BidderApprenticeshipProgramUtility ).FullName);
		}

		private BidderApprenticeshipProgramUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static BidderApprenticeshipProgram CreateObject( )
		{
			BidderApprenticeshipProgramManager bidderApprenticeshipProgramManager = ( BidderApprenticeshipProgramManager ) _bidderApprenticeshipProgramManagerFactory.CreateInstance( );

			return ( BidderApprenticeshipProgram )bidderApprenticeshipProgramManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, BidderApprenticeshipProgram bidderApprenticeshipProgram )
		{
			BidderApprenticeshipProgramManager bidderApprenticeshipProgramManager = ( BidderApprenticeshipProgramManager ) _bidderApprenticeshipProgramManagerFactory.CreateInstance( dataSourceName );

			return bidderApprenticeshipProgramManager.Create( bidderApprenticeshipProgram );
		}
		
		public static bool Update( string dataSourceName, BidderApprenticeshipProgram bidderApprenticeshipProgram )
		{
			BidderApprenticeshipProgramManager bidderApprenticeshipProgramManager = ( BidderApprenticeshipProgramManager ) _bidderApprenticeshipProgramManagerFactory.CreateInstance( dataSourceName );

			return bidderApprenticeshipProgramManager.Update( bidderApprenticeshipProgram );
		}
		
		public static bool Delete( string dataSourceName, int id )
		{
			BidderApprenticeshipProgramManager bidderApprenticeshipProgramManager = ( BidderApprenticeshipProgramManager ) _bidderApprenticeshipProgramManagerFactory.CreateInstance( dataSourceName );

			return bidderApprenticeshipProgramManager.Delete( id );
		}

		public static BidderApprenticeshipProgram Get( string dataSourceName, int id )
		{
			BidderApprenticeshipProgramManager bidderApprenticeshipProgramManager = ( BidderApprenticeshipProgramManager ) _bidderApprenticeshipProgramManagerFactory.CreateInstance( dataSourceName );

			return ( BidderApprenticeshipProgram )bidderApprenticeshipProgramManager.Get( id );
		}

		public static BidderApprenticeshipProgramCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			BidderApprenticeshipProgramManager bidderApprenticeshipProgramManager = ( BidderApprenticeshipProgramManager ) _bidderApprenticeshipProgramManagerFactory.CreateInstance( dataSourceName );

			return ( BidderApprenticeshipProgramCollection )bidderApprenticeshipProgramManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}