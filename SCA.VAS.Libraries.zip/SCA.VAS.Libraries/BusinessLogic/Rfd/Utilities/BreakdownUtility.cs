
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class BreakdownUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BreakdownManagerFactory _breakdownManagerFactory = 
			( BreakdownManagerFactory ) BreakdownManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BreakdownUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BreakdownUtility ).FullName);
		}

		private BreakdownUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static Breakdown CreateObject( )
		{
			BreakdownManager breakdownManager = ( BreakdownManager ) _breakdownManagerFactory.CreateInstance( );

			return ( Breakdown )breakdownManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, Breakdown breakdown )
		{
			BreakdownManager breakdownManager = ( BreakdownManager ) _breakdownManagerFactory.CreateInstance( dataSourceName );

			return breakdownManager.Create( breakdown );
		}
		
		public static bool Update( string dataSourceName, Breakdown breakdown )
		{
			BreakdownManager breakdownManager = ( BreakdownManager ) _breakdownManagerFactory.CreateInstance( dataSourceName );

			return breakdownManager.Update( breakdown );
		}
		
		public static bool Delete( string dataSourceName, int id )
		{
			BreakdownManager breakdownManager = ( BreakdownManager ) _breakdownManagerFactory.CreateInstance( dataSourceName );

			return breakdownManager.Delete( id );
		}

		public static Breakdown Get( string dataSourceName, int id )
		{
			BreakdownManager breakdownManager = ( BreakdownManager ) _breakdownManagerFactory.CreateInstance( dataSourceName );

			return ( Breakdown )breakdownManager.Get( id );
		}

		public static BreakdownCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			BreakdownManager breakdownManager = ( BreakdownManager ) _breakdownManagerFactory.CreateInstance( dataSourceName );

			return ( BreakdownCollection )breakdownManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}