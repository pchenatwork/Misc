#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class PackageHistoryUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PackageHistoryManagerFactory _packageHistoryManagerFactory = 
			( PackageHistoryManagerFactory ) PackageHistoryManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PackageHistoryUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PackageHistoryUtility ).FullName);
		}

		private PackageHistoryUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PackageHistory CreateObject( )
		{
			PackageHistoryManager packageHistoryManager = ( PackageHistoryManager ) _packageHistoryManagerFactory.CreateInstance( );

			return ( PackageHistory )packageHistoryManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, PackageHistory packageHistory )
		{
			PackageHistoryManager packageHistoryManager = ( PackageHistoryManager ) _packageHistoryManagerFactory.CreateInstance( dataSourceName );

			return packageHistoryManager.Create( packageHistory );
		}

		public static bool Update( string dataSourceName, PackageHistory packageHistory )
		{
			PackageHistoryManager packageHistoryManager = ( PackageHistoryManager ) _packageHistoryManagerFactory.CreateInstance( dataSourceName );

			return packageHistoryManager.Update( packageHistory );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			PackageHistoryManager packageHistoryManager = ( PackageHistoryManager ) _packageHistoryManagerFactory.CreateInstance( dataSourceName );

			return packageHistoryManager.Delete( id );
		}

		public static PackageHistory Get( string dataSourceName, int id )
		{
			PackageHistoryManager packageHistoryManager = ( PackageHistoryManager ) _packageHistoryManagerFactory.CreateInstance( dataSourceName );

			return ( PackageHistory )packageHistoryManager.Get( id );
		}

        public static PackageHistory GetById(string dataSourceName, Guid historyId)
        {
            PackageHistoryManager packageHistoryManager = (PackageHistoryManager)_packageHistoryManagerFactory.CreateInstance(dataSourceName);

            return (PackageHistory)packageHistoryManager.GetById(historyId);
        }

        public static byte[] GetAttachment(string dataSourceName, int id)
        {
            PackageHistoryManager packageHistoryManager = (PackageHistoryManager)_packageHistoryManagerFactory.CreateInstance(dataSourceName);

            return (byte[])packageHistoryManager.GetAttachment(id);
        }

		public static PackageHistoryCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PackageHistoryManager packageHistoryManager = ( PackageHistoryManager ) _packageHistoryManagerFactory.CreateInstance( dataSourceName );

			return ( PackageHistoryCollection )packageHistoryManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
