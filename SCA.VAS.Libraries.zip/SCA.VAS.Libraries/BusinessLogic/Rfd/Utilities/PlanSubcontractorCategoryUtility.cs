
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class PlanSubcontractorCategoryUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PlanSubcontractorCategoryManagerFactory _planSubcontractorCategoryManagerFactory = 
			( PlanSubcontractorCategoryManagerFactory ) PlanSubcontractorCategoryManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PlanSubcontractorCategoryUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanSubcontractorCategoryUtility ).FullName);
		}

		private PlanSubcontractorCategoryUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PlanSubcontractorCategory CreateObject( )
		{
			PlanSubcontractorCategoryManager planSubcontractorCategoryManager = ( PlanSubcontractorCategoryManager ) _planSubcontractorCategoryManagerFactory.CreateInstance( );

			return ( PlanSubcontractorCategory )planSubcontractorCategoryManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, PlanSubcontractorCategory planSubcontractorCategory )
		{
			PlanSubcontractorCategoryManager planSubcontractorCategoryManager = ( PlanSubcontractorCategoryManager ) _planSubcontractorCategoryManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorCategoryManager.Create( planSubcontractorCategory );
		}
		
		public static bool Update( string dataSourceName, PlanSubcontractorCategory planSubcontractorCategory )
		{
			PlanSubcontractorCategoryManager planSubcontractorCategoryManager = ( PlanSubcontractorCategoryManager ) _planSubcontractorCategoryManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorCategoryManager.Update( planSubcontractorCategory );
		}

        public static bool UpdateCollection(string dataSourceName, int planSubcontractorId, PlanSubcontractorCategoryCollection collection)
        {
            PlanSubcontractorCategoryManager planSubcontractorCategoryManager = (PlanSubcontractorCategoryManager)_planSubcontractorCategoryManagerFactory.CreateInstance(dataSourceName);

            return planSubcontractorCategoryManager.UpdateCollection(planSubcontractorId, collection);
        }

		public static bool Delete( string dataSourceName, int id )
		{
			PlanSubcontractorCategoryManager planSubcontractorCategoryManager = ( PlanSubcontractorCategoryManager ) _planSubcontractorCategoryManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorCategoryManager.Delete( id );
		}

		public static PlanSubcontractorCategory Get( string dataSourceName, int id )
		{
			PlanSubcontractorCategoryManager planSubcontractorCategoryManager = ( PlanSubcontractorCategoryManager ) _planSubcontractorCategoryManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractorCategory )planSubcontractorCategoryManager.Get( id );
		}

		public static PlanSubcontractorCategoryCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PlanSubcontractorCategoryManager planSubcontractorCategoryManager = ( PlanSubcontractorCategoryManager ) _planSubcontractorCategoryManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractorCategoryCollection )planSubcontractorCategoryManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}