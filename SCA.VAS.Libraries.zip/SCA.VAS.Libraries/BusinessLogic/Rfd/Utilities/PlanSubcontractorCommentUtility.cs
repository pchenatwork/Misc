#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class PlanSubcontractorCommentUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PlanSubcontractorCommentManagerFactory _planSubcontractorCommentManagerFactory = 
			( PlanSubcontractorCommentManagerFactory ) PlanSubcontractorCommentManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PlanSubcontractorCommentUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanSubcontractorCommentUtility ).FullName);
		}

		private PlanSubcontractorCommentUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PlanSubcontractorComment CreateObject( )
		{
			PlanSubcontractorCommentManager planSubcontractorCommentManager = ( PlanSubcontractorCommentManager ) _planSubcontractorCommentManagerFactory.CreateInstance( );

			return ( PlanSubcontractorComment )planSubcontractorCommentManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, PlanSubcontractorComment planSubcontractorComment )
		{
			PlanSubcontractorCommentManager planSubcontractorCommentManager = ( PlanSubcontractorCommentManager ) _planSubcontractorCommentManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorCommentManager.Create( planSubcontractorComment );
		}

		public static bool Update( string dataSourceName, PlanSubcontractorComment planSubcontractorComment )
		{
			PlanSubcontractorCommentManager planSubcontractorCommentManager = ( PlanSubcontractorCommentManager ) _planSubcontractorCommentManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorCommentManager.Update( planSubcontractorComment );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			PlanSubcontractorCommentManager planSubcontractorCommentManager = ( PlanSubcontractorCommentManager ) _planSubcontractorCommentManagerFactory.CreateInstance( dataSourceName );

			return planSubcontractorCommentManager.Delete( id );
		}

        public static bool DeleteAttachment(string dataSourceName, int id)
        {
            PlanSubcontractorCommentManager planSubcontractorCommentManager = (PlanSubcontractorCommentManager)_planSubcontractorCommentManagerFactory.CreateInstance(dataSourceName);

            return planSubcontractorCommentManager.DeleteAttachment(id);
        }

		public static PlanSubcontractorComment Get( string dataSourceName, int id )
		{
			PlanSubcontractorCommentManager planSubcontractorCommentManager = ( PlanSubcontractorCommentManager ) _planSubcontractorCommentManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractorComment )planSubcontractorCommentManager.Get( id );
		}

        public static PlanSubcontractorComment GetById(string dataSourceName, Guid commentId)
        {
            PlanSubcontractorCommentManager planSubcontractorCommentManager = (PlanSubcontractorCommentManager)_planSubcontractorCommentManagerFactory.CreateInstance(dataSourceName);

            return (PlanSubcontractorComment)planSubcontractorCommentManager.GetById(commentId);
        }

        public static byte[] GetAttachment(string dataSourceName, int id)
        {
            PlanSubcontractorCommentManager planSubcontractorCommentManager = (PlanSubcontractorCommentManager)_planSubcontractorCommentManagerFactory.CreateInstance(dataSourceName);

            return (byte[])planSubcontractorCommentManager.GetAttachment(id);
        }

		public static PlanSubcontractorCommentCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PlanSubcontractorCommentManager planSubcontractorCommentManager = ( PlanSubcontractorCommentManager ) _planSubcontractorCommentManagerFactory.CreateInstance( dataSourceName );

			return ( PlanSubcontractorCommentCollection )planSubcontractorCommentManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
