
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class PlanItemUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PlanItemManagerFactory _planItemManagerFactory = 
			( PlanItemManagerFactory ) PlanItemManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PlanItemUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PlanItemUtility ).FullName);
		}

		private PlanItemUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static PlanItem CreateObject( )
		{
			PlanItemManager planItemManager = ( PlanItemManager ) _planItemManagerFactory.CreateInstance( );

			return ( PlanItem )planItemManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, PlanItem planItem )
		{
			PlanItemManager planItemManager = ( PlanItemManager ) _planItemManagerFactory.CreateInstance( dataSourceName );

			return planItemManager.Create( planItem );
		}
		
		public static bool Update( string dataSourceName, PlanItem planItem )
		{
			PlanItemManager planItemManager = ( PlanItemManager ) _planItemManagerFactory.CreateInstance( dataSourceName );

			return planItemManager.Update( planItem );
		}

        public static bool UpdateCollection(string dataSourceName, int planId, PlanItemCollection collection)
        {
            PlanItemManager planItemManager = (PlanItemManager)_planItemManagerFactory.CreateInstance(dataSourceName);

            return planItemManager.UpdateCollection(planId, collection);
        }
		
		public static bool Delete( string dataSourceName, int id )
		{
			PlanItemManager planItemManager = ( PlanItemManager ) _planItemManagerFactory.CreateInstance( dataSourceName );

			return planItemManager.Delete( id );
		}

		public static PlanItem Get( string dataSourceName, int id )
		{
			PlanItemManager planItemManager = ( PlanItemManager ) _planItemManagerFactory.CreateInstance( dataSourceName );

			return ( PlanItem )planItemManager.Get( id );
		}

		public static PlanItemCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PlanItemManager planItemManager = ( PlanItemManager ) _planItemManagerFactory.CreateInstance( dataSourceName );

			return ( PlanItemCollection )planItemManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}