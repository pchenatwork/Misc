
#region Copyright 
/*=======================================================================
* 
* Modification History: 
* Date Programmer Description 
* 
*=======================================================================
* Copyright (C) 2003-2008 AECsoft USA, Inc. 
* All rights reserved. 
*=======================================================================*/
#endregion Copyright 

#region References 
using System;
using System.Data;

using SCA.VAS.ValueObjects.Rfd;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Rfd.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header
	
	public class BidderBreakdownUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BidderBreakdownManagerFactory _bidderBreakdownManagerFactory = 
			( BidderBreakdownManagerFactory ) BidderBreakdownManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BidderBreakdownUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BidderBreakdownUtility ).FullName);
		}

		private BidderBreakdownUtility()
		{
		}
		#endregion 

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static BidderBreakdown CreateObject( )
		{
			BidderBreakdownManager bidderBreakdownManager = ( BidderBreakdownManager ) _bidderBreakdownManagerFactory.CreateInstance( );

			return ( BidderBreakdown )bidderBreakdownManager.CreateObject( );
		}

        public static bool UpdateCollection(string dataSourceName, int bidderId, BidderBreakdownCollection collection)
        {
            BidderBreakdownManager bidderBreakdownManager = (BidderBreakdownManager)_bidderBreakdownManagerFactory.CreateInstance(dataSourceName);

            return bidderBreakdownManager.UpdateCollection(bidderId, collection);
        }

        public static BidderBreakdown Get(string dataSourceName, int id)
        {
            BidderBreakdownManager bidderBreakdownManager = (BidderBreakdownManager)_bidderBreakdownManagerFactory.CreateInstance(dataSourceName);

            return (BidderBreakdown)bidderBreakdownManager.Get(id);
        }

		public static BidderBreakdownCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			BidderBreakdownManager bidderBreakdownManager = ( BidderBreakdownManager ) _bidderBreakdownManagerFactory.CreateInstance( dataSourceName );

			return ( BidderBreakdownCollection )bidderBreakdownManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}