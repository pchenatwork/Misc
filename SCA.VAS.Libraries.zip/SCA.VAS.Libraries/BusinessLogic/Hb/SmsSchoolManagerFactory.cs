

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Hb 
{ 
	#region Header 
	/// <summary>
	/// Factory for SmsSchoolManager.
	/// </summary>
	#endregion Header

	public class SmsSchoolManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;
	
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static SmsSchoolManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof(SmsSchoolManagerFactory).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private SmsSchoolManagerFactory()
		{
		}

		#endregion Constructors


		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the SmsSchoolManagerFactory
		/// </summary>
		/// <returns>an instance of SmsSchoolManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof(SmsSchoolManagerFactory) )
			{
				if ( _factory == null )
				{
					_factory = new SmsSchoolManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new SmsSchoolManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new SmsSchoolManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}
