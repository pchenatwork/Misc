

#region References 
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Hb;

using log4net;
#endregion References


namespace SCA.VAS.BusinessLogic.Hb 
{ 
	#region Header 
	/// <summary>
	/// Manager class for HBProjectWorkflow.
	/// </summary>
	#endregion Header
	
	public class HBProjectWorkflowManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string FIND_WORKFLOW_BY_PROJECT = "FindWorkflowByHBProject";
		//... REST all Comes Here ...
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static HBProjectWorkflowManager()
		{
			_logger = LoggingUtility.GetLogger(typeof(HBProjectWorkflowManager).FullName);
		} //	end	class constructor

		/// <summary>
		/// default	constructor	
		/// inits with default
		///	</summary>
		public HBProjectWorkflowManager()
		{
		} // end constructor

		///	<summary>
		/// default constructor	
		/// inits with a DataSource.
		///	</summary>
		public HBProjectWorkflowManager(string dataSourceName) : base(dataSourceName)
		{
		}
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Hb.HBProjectWorkflowDao";
			}
		}

		public override IValueObject CreateObject()
		{
			return new HBProjectWorkflow();
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		/// <summary>
		/// Create a new HBProjectWorkflow object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create(IValueObject newObject)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update(IValueObject existingObject)
		{
			throw new NotImplementedException();
		}
		
		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete(int id)
		{
			return this.Dao.Delete(this.DataSource, id);
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new object object from the database.
		/// </summary>
		/// <param name="Id">HBProjectWorkflow Id</param>
		/// <returns></returns>
		public override IValueObject Get(int id)
		{
			throw new NotImplementedException();
		}

		
		
		#endregion

		#region Manaul Methods
		// *************************************************************************
		//				 Manual Methods Injected for Calling Datasource
		// *************************************************************************


		/// <summary>
        /// Gets new collection of HBProjectWorkflow based on criterias
        /// </summary>
        /// <param name="finderType">finderType => always constant defined both in Manager as well as in DAO Entity</param>
        /// <returns></returns>        
		public override ICollection FindByCriteria(string finderType, object[] criteria)
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}


		/// <summary>
		/// Description:
		/// USE THIS AS AN EXAMPLE ...
		/// </summary>
		/// <param name="anyparam"></param>
		/// <param name="otherparam"></param>
		/// <returns></returns>		
		/*
		public bool ManualMethodName(int anyparam, int otherparam)
		{
			return (bool)this.Dao.InvokeByMethodName("ManualMethodName",
				new object[] { this.DataSource, anyparam, otherparam });
		}
		*/

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <returns></returns>
		public bool UpdateCollection(int projectId, HBProjectWorkflowCollection collection)
		{
			return (bool)this.Dao.InvokeByMethodName("UpdateCollection",
				new object[] { this.DataSource, projectId, collection });
		}

		/// <summary>
		/// Update WorkflowStatusfor the Project in the database.
		/// </summary>
		/// <returns></returns>
		public bool UpdateStatus(int id, int status, string statusName)
		{
			return (bool)this.Dao.InvokeByMethodName("UpdateStatus",
				new object[] { this.DataSource, id, status, statusName });
		}
		#endregion
	}
}
