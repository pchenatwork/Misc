

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Hb 
{ 
	#region Header 
	/// <summary>
	/// Factory for BoroughManager.
	/// </summary>
	#endregion Header

	public class BoroughManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;
	
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static BoroughManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BoroughManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private BoroughManagerFactory()
		{
		} 

		#endregion Constructors


		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the BoroughManagerFactory
		/// </summary>
		/// <returns>an instance of BoroughManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( BoroughManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new BoroughManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new BoroughManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new BoroughManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}
