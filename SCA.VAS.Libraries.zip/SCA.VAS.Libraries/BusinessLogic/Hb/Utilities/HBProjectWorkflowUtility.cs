

#region References 
using System;
using System.Collections.Generic;
using System.Data;

using SCA.VAS.ValueObjects.Hb;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Hb.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header

	public class HBProjectWorkflowUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly HBProjectWorkflowManagerFactory _HBProjectWorkflowManagerFactory = 
			( HBProjectWorkflowManagerFactory ) HBProjectWorkflowManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static HBProjectWorkflowUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( HBProjectWorkflowUtility ).FullName);
		}

		private HBProjectWorkflowUtility()
		{
		}
		#endregion
		

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static HBProjectWorkflow CreateObject( )
		{
			HBProjectWorkflowManager _Manager = ( HBProjectWorkflowManager ) _HBProjectWorkflowManagerFactory.CreateInstance( );

			return ( HBProjectWorkflow )_Manager.CreateObject( );
		}

		public static bool Create( string dataSourceName, HBProjectWorkflow _HBProjectWorkflow )
		{
			throw new NotImplementedException();
		}
		
		public static bool Update( string dataSourceName, HBProjectWorkflow _HBProjectWorkflow )
		{
			throw new NotImplementedException();
		}		
		
		public static HBProjectWorkflow Get( string dataSourceName, int id )
		{
			throw new NotImplementedException();
		}

		public static HBProjectWorkflowCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			HBProjectWorkflowManager _Manager = ( HBProjectWorkflowManager ) _HBProjectWorkflowManagerFactory.CreateInstance( dataSourceName );

			return ( HBProjectWorkflowCollection )_Manager.FindByCriteria( finderType, criteria );
		}

		public static bool UpdateCollection(string dataSourceName, int projectId, HBProjectWorkflowCollection collection)
		{
			HBProjectWorkflowManager _Manager = (HBProjectWorkflowManager)_HBProjectWorkflowManagerFactory.CreateInstance(dataSourceName);

			return (bool)_Manager.UpdateCollection(projectId, collection);
		}

		public static bool UpdateStatus(string dataSourceName, int id, int status, string statusName)
		{
			HBProjectWorkflowManager _Manager = (HBProjectWorkflowManager)_HBProjectWorkflowManagerFactory.CreateInstance(dataSourceName);

			return (bool)_Manager.UpdateStatus(id,status,statusName);
		}

		public static bool Delete( string dataSourceName, int id )
		{
			HBProjectWorkflowManager _Manager = ( HBProjectWorkflowManager ) _HBProjectWorkflowManagerFactory.CreateInstance( dataSourceName );

			return _Manager.Delete( id );
		}

		//Manual Methods from Manager
		///<summary>
		///IsExists is a funtionalty, given in automation to make Manul Method Understand
		///</summar>
		

		#endregion
	}
}
