

#region References 
using System;
using System.Collections.Generic;
using System.Data;

using SCA.VAS.ValueObjects.Hb;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Hb.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header

	public class BoroughUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BoroughManagerFactory _BoroughManagerFactory = 
			( BoroughManagerFactory ) BoroughManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BoroughUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BoroughUtility ).FullName);
		}

		private BoroughUtility()
		{
		}
		#endregion
		

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		

		public static BoroughCollection GetAll(string dataSourceName)
		{
			BoroughManager _Manager = (BoroughManager)_BoroughManagerFactory.CreateInstance(dataSourceName);

			return (BoroughCollection)_Manager.GetAll();
		}

		public static BoroughCollection GetByName(string dataSourceName, string name)
		{
			BoroughManager _Manager = (BoroughManager)_BoroughManagerFactory.CreateInstance(dataSourceName);

			return (BoroughCollection)_Manager.GetByName(name);
		}

		public static BoroughCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			BoroughManager _Manager = ( BoroughManager ) _BoroughManagerFactory.CreateInstance( dataSourceName );

			return ( BoroughCollection )_Manager.FindByCriteria( finderType, criteria );
		}

		
		#endregion
	}
}
