

#region References 
using System;
using System.Collections.Generic;
using System.Data;

using SCA.VAS.ValueObjects.Hb;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Hb.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header

	public class SmsSchoolUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly SmsSchoolManagerFactory _SmsSchoolManagerFactory = 
			(SmsSchoolManagerFactory)SmsSchoolManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static SmsSchoolUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof(SmsSchoolUtility).FullName);
		}

		private SmsSchoolUtility()
		{
		}
		#endregion
		

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		

		public static SmsSchoolCollection GetAll(string dataSourceName)
		{
			SmsSchoolManager _Manager = (SmsSchoolManager)_SmsSchoolManagerFactory.CreateInstance(dataSourceName);

			return (SmsSchoolCollection)_Manager.GetAll();
		}

		public static SmsSchoolCollection GetByName(string dataSourceName, string name)
		{
			SmsSchoolManager _Manager = (SmsSchoolManager)_SmsSchoolManagerFactory.CreateInstance(dataSourceName);

			return (SmsSchoolCollection)_Manager.GetByName(name);
		}

		#endregion
	}
}
