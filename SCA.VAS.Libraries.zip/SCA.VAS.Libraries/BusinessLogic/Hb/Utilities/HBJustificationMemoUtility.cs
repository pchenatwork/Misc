

#region References 
using System;
using System.Collections.Generic;
using System.Data;

using SCA.VAS.ValueObjects.Hb;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Hb.Utilities
{ 
	#region Header 
	/// <summary>
	/// Transaction related utility functions.
	///	</summary>
	#endregion Header

	public class HBJustificationMemoUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly HBJustificationMemoManagerFactory _HBJustificationMemoManagerFactory = 
			( HBJustificationMemoManagerFactory ) HBJustificationMemoManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static HBJustificationMemoUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( HBJustificationMemoUtility ).FullName);
		}

		private HBJustificationMemoUtility()
		{
		}
		#endregion
		

		#region	Public Methods
		//	*************************************************************************
		//				   public methods
		//	*************************************************************************
		public static HBJustificationMemo CreateObject( )
		{
			HBJustificationMemoManager _Manager = ( HBJustificationMemoManager ) _HBJustificationMemoManagerFactory.CreateInstance( );

			return ( HBJustificationMemo )_Manager.CreateObject( );
		}

		public static bool Create( string dataSourceName, HBJustificationMemo _HBJustificationMemo )
		{
			HBJustificationMemoManager _Manager = ( HBJustificationMemoManager ) _HBJustificationMemoManagerFactory.CreateInstance( dataSourceName );

			return _Manager.Create( _HBJustificationMemo );
		}
		
		public static bool Update( string dataSourceName, HBJustificationMemo _HBJustificationMemo )
		{
			HBJustificationMemoManager _Manager = ( HBJustificationMemoManager ) _HBJustificationMemoManagerFactory.CreateInstance( dataSourceName );

			return _Manager.Update( _HBJustificationMemo );
		}		
		
		public static HBJustificationMemo Get( string dataSourceName, int id )
		{
			HBJustificationMemoManager _Manager = ( HBJustificationMemoManager ) _HBJustificationMemoManagerFactory.CreateInstance( dataSourceName );

			return ( HBJustificationMemo )_Manager.Get( id );
		}

		public static ECMWrapper.VASDocument GetAttachment(string dataSourceName, long attachmentId)
		{
			HBJustificationMemoManager _Manager = (HBJustificationMemoManager)_HBJustificationMemoManagerFactory.CreateInstance(dataSourceName);

			return _Manager.GetAttachment(attachmentId);
		}

		public static HBJustificationMemoCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			HBJustificationMemoManager _Manager = ( HBJustificationMemoManager ) _HBJustificationMemoManagerFactory.CreateInstance( dataSourceName );

			return ( HBJustificationMemoCollection )_Manager.FindByCriteria( finderType, criteria );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			HBJustificationMemoManager _Manager = ( HBJustificationMemoManager ) _HBJustificationMemoManagerFactory.CreateInstance( dataSourceName );

			return _Manager.Delete( id );
		}

		public static HBJustificationMemo CreateOrUpdate(string dataSourceName, int id, string dataXml)
		{
			HBJustificationMemoManager _Manager = (HBJustificationMemoManager)_HBJustificationMemoManagerFactory.CreateInstance(dataSourceName);

			return ( HBJustificationMemo )_Manager.CreateOrUpdate(id, dataXml);
		}
		
		public static void SaveAttachment(string dataSourceName, int id, long attachmentId)
		{
			HBJustificationMemoManager _Manager = (HBJustificationMemoManager)_HBJustificationMemoManagerFactory.CreateInstance(dataSourceName);

			_Manager.SaveAttachment(id, attachmentId);
		}

		public static HBJustificationMemo GetByTransactionNumber(string dataSourceName, string transnum)
		{
			HBJustificationMemoManager _Manager = (HBJustificationMemoManager)_HBJustificationMemoManagerFactory.CreateInstance(dataSourceName);

			return (HBJustificationMemo)_Manager.GetByTransactionNumber(transnum);
		}

		//Manual Methods from Manager
		///<summary>
		///IsExists is a funtionalty, given in automation to make Manul Method Understand
		///</summar>
		public bool IsExist(string dataSourceName, int HBJustificationMemoId)
        {
            HBJustificationMemoManager _Manager = ( HBJustificationMemoManager ) _HBJustificationMemoManagerFactory.CreateInstance( dataSourceName );

			return _Manager.IsExists( HBJustificationMemoId );
        }

		#endregion
	}
}
