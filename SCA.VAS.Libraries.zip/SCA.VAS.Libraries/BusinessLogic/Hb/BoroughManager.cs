

#region References 
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Hb;

using log4net;
#endregion References


namespace SCA.VAS.BusinessLogic.Hb 
{ 
	#region Header 
	/// <summary>
	/// Manager class for Borough.
	/// </summary>
	#endregion Header
	
	public class BoroughManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
        public const string SEARCH_ALL_BOROUGH = "SearchAllBorough";
		//... REST all Comes Here ...
        #endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static BoroughManager()
		{
			_logger = LoggingUtility.GetLogger(typeof(BoroughManager).FullName);
		} //	end	class constructor

		/// <summary>
		/// default	constructor	
		/// inits with default
		///	</summary>
		public BoroughManager()
		{
		} // end constructor

		///	<summary>
		/// default constructor	
		/// inits with a DataSource.
		///	</summary>
		public BoroughManager(string dataSourceName) : base(dataSourceName)
		{
		}
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Hb.BoroughDao";
			}
		}

		public override IValueObject CreateObject()
		{
			return new Borough();
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		/// <summary>
		/// Create a new Borough object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create(IValueObject newObject)
		{
			return this.Dao.Create(this.DataSource, newObject);
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update(IValueObject existingObject)
		{
			return this.Dao.Update(this.DataSource, existingObject);
		}
		
		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete(int id)
		{
			return this.Dao.Delete(this.DataSource, id);
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new object object from the database.
		/// </summary>
		/// <param name="Id">Borough Id</param>
		/// <returns></returns>
		public override IValueObject Get(int id)
		{
			return this.Dao.Get(this.DataSource, id);
		}

		/// <summary>
		/// Get all objects from Database as Colelction
		/// </summary>	
		/// <returns></returns>
		public override ICollection GetAll()
		{
			return (ICollection)Dao.InvokeByMethodName("GetAll", new object[] { DataSource });
		}

		#endregion

		#region Manaul Methods
		// *************************************************************************
		//				 Manual Methods Injected for Calling Datasource
		// *************************************************************************

		public ICollection GetByName(string name)
		{
			return (ICollection)Dao.InvokeByMethodName("GetByName", new object[] { DataSource, name });
		}

		/// <summary>
		/// Gets new collection of Borough based on criterias
		/// </summary>
		/// <param name="finderType">finderType => always constant defined both in Manager as well as in DAO Entity</param>
		/// <returns></returns>        
		public override ICollection FindByCriteria(string finderType, object[] criteria)
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}

		///<summary>
		///IsExists is a funtionalty, given in automation to make Manul Method Understand
		///</summar>
		public bool IsExists(int BoroughId)
        {
            return (bool)this.Dao.InvokeByMethodName("IsExists",  new object[] { this.DataSource, BoroughId});
        }

		/// <summary>
		/// Description:
		/// USE THIS AS AN EXAMPLE ...
		/// </summary>
		/// <param name="anyparam"></param>
		/// <param name="otherparam"></param>
		/// <returns></returns>
		/*
		public bool ManualMethodName(int anyparam, int otherparam)
		{
			return (bool)this.Dao.InvokeByMethodName("ManualMethodName",
				new object[] { this.DataSource, anyparam, otherparam });
		}
		*/
		#endregion
    }
}
