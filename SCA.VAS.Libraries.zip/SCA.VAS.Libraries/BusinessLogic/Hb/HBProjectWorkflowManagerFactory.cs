

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Hb 
{ 
	#region Header 
	/// <summary>
	/// Factory for HBProjectWorkflowManager.
	/// </summary>
	#endregion Header

	public class HBProjectWorkflowManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;
	
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static HBProjectWorkflowManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( HBProjectWorkflowManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private HBProjectWorkflowManagerFactory()
		{
		} 

		#endregion Constructors


		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the HBProjectWorkflowManagerFactory
		/// </summary>
		/// <returns>an instance of HBProjectWorkflowManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( HBProjectWorkflowManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new HBProjectWorkflowManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new HBProjectWorkflowManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new HBProjectWorkflowManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}
