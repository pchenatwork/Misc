

#region References 
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Hb 
{ 
	#region Header 
	/// <summary>
	/// Factory for HBJustificationMemoManager.
	/// </summary>
	#endregion Header

	public class HBJustificationMemoManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;
	
		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static HBJustificationMemoManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( HBJustificationMemoManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private HBJustificationMemoManagerFactory()
		{
		} 

		#endregion Constructors


		#region	Public Methods
		//	*************************************************************************
		//				   Public methods
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the HBJustificationMemoManagerFactory
		/// </summary>
		/// <returns>an instance of HBJustificationMemoManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( HBJustificationMemoManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new HBJustificationMemoManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new HBJustificationMemoManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new HBJustificationMemoManager( dataSourceName );
		} 
		#endregion Public Methods
	}
}
