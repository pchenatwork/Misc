#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Content;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Content
{
	#region	Header
	///	<summary>
	///	Manager class for GroupBuyer.
	///	</summary>
	#endregion Header

	public class GroupBuyerManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
		#endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static GroupBuyerManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( GroupBuyerManager ).FullName );
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public GroupBuyerManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public GroupBuyerManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Content.GroupBuyerDao";
			}
		}

		public  new GroupBuyer CreateObject( )
		{
			return new GroupBuyer( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		/// <summary>
		/// Update the objects in the database.
		/// </summary>
		/// <returns></returns>
		public bool UpdateCollection( int groupId, GroupBuyerCollection collection )
		{
			return (bool)this.Dao.InvokeByMethodName( "UpdateCollection", 
				new object[] { this.DataSource, groupId, collection } );
		}

		/// <summary>
		/// Delete the objects in the database.
		/// </summary>
		/// <returns></returns>
		public bool DeleteCollection( int groupId, GroupBuyerCollection collection )
		{
			return (bool)this.Dao.InvokeByMethodName( "DeleteCollection", 
				new object[] { this.DataSource, groupId, collection } );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 	

	} 
} 
