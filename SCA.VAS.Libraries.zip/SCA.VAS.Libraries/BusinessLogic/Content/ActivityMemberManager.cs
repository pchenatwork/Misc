#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Content;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Content
{
	#region	Header
	///	<summary>
	///	Manager class for ActivityMember.
	///	</summary>
	#endregion Header

	public class ActivityMemberManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
		#endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static ActivityMemberManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ActivityMemberManager ).FullName);
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public ActivityMemberManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public ActivityMemberManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Content.ActivityMemberDao";
			}
		}

		public  new ActivityMember CreateObject( )
		{
			return new ActivityMember( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		/// <summary>
		/// Update the objects in the database.
		/// </summary>
		/// <returns></returns>
		public bool UpdateCollection( int activityId, ActivityMemberCollection collection )
		{
			return (bool)this.Dao.InvokeByMethodName( "UpdateCollection", 
				new object[] { this.DataSource, activityId, collection } );
		}

		/// <summary>
		/// Delete the objects in the database.
		/// </summary>
		/// <returns></returns>
		public bool DeleteCollection( int activityId, ActivityMemberCollection collection )
		{
			return (bool)this.Dao.InvokeByMethodName( "DeleteCollection", 
				new object[] { this.DataSource, activityId, collection } );
		}

		/// <summary>
		/// Delete the objects in the database.
		/// </summary>
		/// <returns></returns>
		public bool DeleteByActivity( int activityId )
		{
			return (bool)this.Dao.InvokeByMethodName( "DeleteByActivity", 
				new object[] { this.DataSource, activityId } );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 	

	} 
} 
