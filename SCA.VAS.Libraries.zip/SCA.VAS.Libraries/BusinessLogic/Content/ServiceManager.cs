#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 - 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	Services
using System;
using System.Collections;
using System.Data;
using System.Xml;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.ValueObjects;
using SCA.VAS.Common.Utilities;
using SCA.VAS.ValueObjects.Content;

using log4net;
#endregion Services

namespace SCA.VAS.BusinessLogic.Content
{
	#region	Header
	///	<summary>
	///	Manager class for Service.
	///	</summary>
	#endregion Header

	public class ServiceManager : AbstractManager
	{
		#region	Constants
		// *************************************************************************
		//				 constants
		// *************************************************************************
		public const string FIND_SERVICE_BY_SUPPLIER = "FindServiceBySupplier";
		#endregion Constants

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		// Private members block	includes instance and static members & structs
		private static ILog _logger = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static ServiceManager()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ServiceManager ).FullName);
		} //	end	class constructor

		///	<summary>
		///	default	constructor	
		///	inits with default
		///	</summary>
		public ServiceManager()
		{
		} // end constructor

		///	<summary>
		///	default	constructor	
		///	inits with a DataSource.
		///	</summary>
		public ServiceManager( string dataSourceName ) : base( dataSourceName )
		{
		} 
		#endregion Constructors

		#region IManager
		// *************************************************************************
		//                IManager
		// *************************************************************************
		/// <summary>
		/// Property DaoClassName (string)
		/// </summary>
		public override string DaoClassName
		{
			get
			{
				return "SCA.VAS.DataAccess.Content.ServiceDao";
			}
		}

		public override IValueObject CreateObject( )
		{
			return new Service( );
		}
		#endregion

		#region IPersistentManager
		// *************************************************************************
		//				 IPersistentManager
		// *************************************************************************
		/// <summary>
		/// Create a new Service object in the database.
		/// </summary>
		/// <param name="newObject"></param>
		/// <returns></returns>
		public override bool Create( IValueObject newObject )
		{
			return this.Dao.Create( this.DataSource, newObject );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <param name="existingObject"></param>
		/// <returns></returns>
		public override bool Update( IValueObject existingObject )
		{
			return this.Dao.Update( this.DataSource, existingObject );
		} 

		/// <summary>
		/// Remove the object from the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public override bool Delete( int id )
        {
            Service file = Get(id) as Service;
            if (file != null && file.PictureId > 0) SCA.VAS.ECMWrapper.DocServiceHelper.DeleteDoc(file.PictureId);
            return this.Dao.Delete( this.DataSource, id );
		}
		
		/// <summary>
		/// Remove picture in the database.
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public bool DeletePicture( int id )
        {
            Service file = Get(id) as Service;
            if (file != null && file.PictureId > 0) SCA.VAS.ECMWrapper.DocServiceHelper.DeleteDoc(file.PictureId);
            return (bool)this.Dao.InvokeByMethodName( "DeletePicture", 
				new object[] { this.DataSource, id } );
		}

		/// <summary>
		/// Update the object in the database.
		/// </summary>
		/// <returns></returns>
		public bool UpdateCollection( int supplierId, ServiceCollection collection )
		{
			return (bool)this.Dao.InvokeByMethodName( "UpdateCollection", 
				new object[] { this.DataSource, supplierId, collection } );
		}
		#endregion 

		#region IFinder
		// *************************************************************************
		//				 IFinder
		// *************************************************************************
		/// <summary>
		/// Get a new Service object from the database.
		/// </summary>
		/// <param name="Id">Service Id</param>
		/// <returns></returns>
		public override IValueObject Get( int id )
		{
			return this.Dao.Get( this.DataSource, id );
		}

		/// <summary>
		/// Get a new Service object from the database.
		/// </summary>
		/// <param name="ServiceId">Service Id</param>
		/// <returns></returns>
		public IValueObject GetById( Guid serviceId )
		{
			return (IValueObject)this.Dao.InvokeByMethodName( "GetById", 
				new object[] { this.DataSource, serviceId } );
		}
		
		/// <summary>
		/// Get picture from the database.
		/// </summary>
		/// <param name="Id">Service Id</param>
		/// <returns></returns>
		public byte[] GetPicture( int id )
        {
            Service file = Get(id) as Service;
            if (file != null && file.PictureId > 0)
                return (byte[])SCA.VAS.ECMWrapper.DocServiceHelper.DownloadDoc(file.PictureId).Contents;
            else
                return (byte[])this.Dao.InvokeByMethodName( "GetPicture", 
				new object[] { this.DataSource, id } );
		}

		public byte[] GetPictureById( Guid serviceId )
        {
            Service file = GetById(serviceId) as Service;
            if (file != null && file.PictureId > 0)
                return (byte[])SCA.VAS.ECMWrapper.DocServiceHelper.DownloadDoc(file.PictureId).Contents;
            else
                return (byte[])this.Dao.InvokeByMethodName( "GetPictureById", 
				new object[] { this.DataSource, serviceId } );
		}

		public override ICollection FindByCriteria( string finderType, object[] criteria )
		{
			return this.Dao.FindByCriteria( this.DataSource, finderType, criteria );
		}
		#endregion 	
	} 
} 