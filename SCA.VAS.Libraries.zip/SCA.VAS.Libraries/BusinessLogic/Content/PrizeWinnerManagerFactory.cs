#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Content
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Content
{
	#region	Header
	///	<summary>
	///	Factory for Page
	///	</summary>
	#endregion Header

	public sealed class PrizeWinnerManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static PrizeWinnerManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PrizeWinnerManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private PrizeWinnerManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   Public SCA.VAS.
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the PageManagerFactory
		/// </summary>
		/// <returns>an instance of PageManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( PrizeWinnerManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new PrizeWinnerManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new PrizeWinnerManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new PrizeWinnerManager( dataSourceName );
		} 
		#endregion Public SCA.VAS.
	} 
} 