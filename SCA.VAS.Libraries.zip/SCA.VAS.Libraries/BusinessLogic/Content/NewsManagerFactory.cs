#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Content
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Content
{
	#region	Header
	///	<summary>
	///	Factory for News
	///	</summary>
	#endregion Header

	public sealed class NewsManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static NewsManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( NewsManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private NewsManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   Public SCA.VAS.
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the NewsManagerFactory
		/// </summary>
		/// <returns>an instance of NewsManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( NewsManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new NewsManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new NewsManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new NewsManager( dataSourceName );
		} 
		#endregion Public SCA.VAS.
	} 
} 