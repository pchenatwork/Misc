#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Content
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Content
{
	#region	Header
	///	<summary>
	///	Factory for Newsletter
	///	</summary>
	#endregion Header

	public sealed class NewsletterManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static NewsletterManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( NewsletterManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private NewsletterManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   Public SCA.VAS.
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the NewsletterManagerFactory
		/// </summary>
		/// <returns>an instance of NewsletterManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( NewsletterManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new NewsletterManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new NewsletterManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new NewsletterManager( dataSourceName );
		} 
		#endregion Public SCA.VAS.
	} 
} 