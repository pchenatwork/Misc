#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Content
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Content
{
	#region	Header
	///	<summary>
	///	Factory for Documentation
	///	</summary>
	#endregion Header

	public sealed class DocumentationManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static DocumentationManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( DocumentationManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private DocumentationManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   Public SCA.VAS.
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the DocumentationManagerFactory
		/// </summary>
		/// <returns>an instance of DocumentationManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( DocumentationManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new DocumentationManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new DocumentationManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new DocumentationManager( dataSourceName );
		} 
		#endregion Public SCA.VAS.
	} 
} 