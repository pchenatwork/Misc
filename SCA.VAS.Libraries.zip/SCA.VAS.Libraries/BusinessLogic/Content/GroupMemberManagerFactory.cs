#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Content
{
	#region	Header
	///	<summary>
	///	Factory for GroupMemberManager
	///	</summary>
	#endregion Header

	public sealed class GroupMemberManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static GroupMemberManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( GroupMemberManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private GroupMemberManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   Public SCA.VAS.
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the GroupMemberManagerFactory
		/// </summary>
		/// <returns>an instance of GroupMemberManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( GroupMemberManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new GroupMemberManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance()
		{
			return new GroupMemberManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new GroupMemberManager( dataSourceName );
		}  
		#endregion Public SCA.VAS.
	} 
} 
