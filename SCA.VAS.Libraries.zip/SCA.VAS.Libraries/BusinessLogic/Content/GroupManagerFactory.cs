#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Content
{
	#region	Header
	///	<summary>
	///	Factory for Group
	///	</summary>
	#endregion Header

	public sealed class GroupManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static GroupManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( GroupManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private GroupManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   Public SCA.VAS.
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the GroupManagerFactory
		/// </summary>
		/// <returns>an instance of GroupManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( GroupManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new GroupManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance()
		{
			return new GroupManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new GroupManager( dataSourceName );
		}  
		#endregion Public SCA.VAS.
	} 
} 