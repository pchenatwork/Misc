#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Content
{
    #region	Header
    ///	<summary>
    ///	Factory for Album
    ///	</summary>
    #endregion Header

    public sealed class AlbumManagerFactory : AbstractManagerFactory
    {
        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        /// <summary>the singleton factory instance</summary>
        private static IManagerFactory _factory = null;

        #endregion Private Members

        #region	Constructors
        // *************************************************************************
        //				 Constructors
        // *************************************************************************
        /// <summary>
        /// class constructor 
        /// initializes logging
        /// </summary>
        static AlbumManagerFactory()
        {
            _logger = LoggingUtility.GetLogger(typeof(AlbumManagerFactory).FullName);
        }

        ///	<summary>
        ///	No constructor	
        ///	</summary>
        private AlbumManagerFactory()
        {
        }

        #endregion Constructors

        #region	Public SCA.VAS.
        //	*************************************************************************
        //				   Public SCA.VAS.
        //	*************************************************************************
        /// <summary>
        /// Get singleton instance of the AlbumManagerFactory
        /// </summary>
        /// <returns>an instance of AlbumManagerFactory</returns>
        public static IManagerFactory Instance()
        {
            lock (typeof(AlbumManagerFactory))
            {
                if (_factory == null)
                {
                    _factory = new AlbumManagerFactory();
                }
                return _factory;
            }
        }

        /// <summary>
        /// Factory creation method for Manager instances
        /// </summary>
        /// <returns>
        /// an instance of Manager
        /// </returns>
        public override IManager CreateInstance()
        {
            return new AlbumManager();
        }

        /// <summary>
        /// Factory creation method for Manager instances
        /// </summary>
        /// <returns>
        /// an instance of Manager
        /// </returns>
        public override IManager CreateInstance(string dataSourceName)
        {
            return new AlbumManager(dataSourceName);
        }
        #endregion Public SCA.VAS.
    }
}