#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class PhotoGalleryUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PhotoGalleryManagerFactory _photoGalleryManagerFactory = 
			( PhotoGalleryManagerFactory ) PhotoGalleryManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PhotoGalleryUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PhotoGalleryUtility ).FullName);
		}

		private PhotoGalleryUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static PhotoGallery CreateObject( )
		{
			PhotoGalleryManager photoGalleryManager = ( PhotoGalleryManager ) _photoGalleryManagerFactory.CreateInstance( );

			return ( PhotoGallery )photoGalleryManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, PhotoGallery photoGallery )
		{
			PhotoGalleryManager photoGalleryManager = ( PhotoGalleryManager ) _photoGalleryManagerFactory.CreateInstance( dataSourceName );

			return photoGalleryManager.Create( photoGallery );
		}

		public static bool Update( string dataSourceName, PhotoGallery photoGallery )
		{
			PhotoGalleryManager photoGalleryManager = ( PhotoGalleryManager ) _photoGalleryManagerFactory.CreateInstance( dataSourceName );

			return photoGalleryManager.Update( photoGallery );
		}

        public static bool UpdateCollection(string dataSourceName, int albumId, PhotoGalleryCollection collection)
        {
            PhotoGalleryManager photoGalleryManager = (PhotoGalleryManager)_photoGalleryManagerFactory.CreateInstance(dataSourceName);

            return photoGalleryManager.UpdateCollection(albumId, collection);
        }

		public static bool Delete( string dataSourceName, int id )
		{
			PhotoGalleryManager photoGalleryManager = ( PhotoGalleryManager ) _photoGalleryManagerFactory.CreateInstance( dataSourceName );

			return photoGalleryManager.Delete( id );
		}

		public static PhotoGallery Get( string dataSourceName, int id )
		{
			PhotoGalleryManager photoGalleryManager = ( PhotoGalleryManager ) _photoGalleryManagerFactory.CreateInstance( dataSourceName );

			return ( PhotoGallery )photoGalleryManager.Get( id );
		}

		public static PhotoGalleryCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PhotoGalleryManager photoGalleryManager = ( PhotoGalleryManager ) _photoGalleryManagerFactory.CreateInstance( dataSourceName );

			return ( PhotoGalleryCollection )photoGalleryManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
