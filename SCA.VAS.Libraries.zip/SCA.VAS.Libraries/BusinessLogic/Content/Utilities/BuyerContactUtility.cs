#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class BuyerContactUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BuyerContactManagerFactory _buyerContactManagerFactory = 
			( BuyerContactManagerFactory ) BuyerContactManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BuyerContactUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BuyerContactUtility ).FullName);
		}

		private BuyerContactUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static BuyerContact CreateObject( )
		{
			BuyerContactManager buyerContactManager = ( BuyerContactManager ) _buyerContactManagerFactory.CreateInstance( );

			return ( BuyerContact )buyerContactManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, BuyerContact buyerContact )
		{
			BuyerContactManager buyerContactManager = ( BuyerContactManager ) _buyerContactManagerFactory.CreateInstance( dataSourceName );

			return buyerContactManager.Create( buyerContact );
		}

		public static bool Update( string dataSourceName, BuyerContact buyerContact )
		{
			BuyerContactManager buyerContactManager = ( BuyerContactManager ) _buyerContactManagerFactory.CreateInstance( dataSourceName );

			return buyerContactManager.Update( buyerContact );
		}

        public static bool UpdateSequence(string dataSourceName, BuyerContactCollection collection)
        {
            BuyerContactManager buyerContactManager = (BuyerContactManager)_buyerContactManagerFactory.CreateInstance(dataSourceName);

            return buyerContactManager.UpdateSequence(collection);
        }

		public static bool Delete( string dataSourceName, int id )
		{
			BuyerContactManager buyerContactManager = ( BuyerContactManager ) _buyerContactManagerFactory.CreateInstance( dataSourceName );

			return buyerContactManager.Delete( id );
		}

		public static BuyerContact Get( string dataSourceName, int id )
		{
			BuyerContactManager buyerContactManager = ( BuyerContactManager ) _buyerContactManagerFactory.CreateInstance( dataSourceName );

			return ( BuyerContact )buyerContactManager.Get( id );
		}

		public static BuyerContactCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			BuyerContactManager buyerContactManager = ( BuyerContactManager ) _buyerContactManagerFactory.CreateInstance( dataSourceName );

			return ( BuyerContactCollection )buyerContactManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
