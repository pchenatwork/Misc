#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class EventUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly EventManagerFactory _evtManagerFactory = 
			( EventManagerFactory ) EventManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static EventUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( EventUtility ).FullName);
		}

		private EventUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static Event CreateObject( )
		{
			EventManager evtManager = ( EventManager ) _evtManagerFactory.CreateInstance( );

			return ( Event )evtManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, Event evt )
		{
			EventManager evtManager = ( EventManager ) _evtManagerFactory.CreateInstance( dataSourceName );

			return evtManager.Create( evt );
		}

		public static bool Update( string dataSourceName, Event evt )
		{
			EventManager evtManager = ( EventManager ) _evtManagerFactory.CreateInstance( dataSourceName );

			return evtManager.Update( evt );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			EventManager evtManager = ( EventManager ) _evtManagerFactory.CreateInstance( dataSourceName );

			return evtManager.Delete( id );
		}

		public static Event Get( string dataSourceName, int id )
		{
			EventManager evtManager = ( EventManager ) _evtManagerFactory.CreateInstance( dataSourceName );

			return ( Event )evtManager.Get( id );
		}

		public static EventCollection GetAll( string dataSourceName  )
		{
			EventManager evtManager = ( EventManager ) _evtManagerFactory.CreateInstance( dataSourceName );

			return ( EventCollection )evtManager.GetAll( );
		}

		public static EventCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			EventManager evtManager = ( EventManager ) _evtManagerFactory.CreateInstance( dataSourceName );

			return ( EventCollection )evtManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
