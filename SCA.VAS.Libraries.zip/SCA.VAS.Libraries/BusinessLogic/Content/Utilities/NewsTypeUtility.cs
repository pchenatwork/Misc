#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class NewsTypeUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly NewsTypeManagerFactory _newsTypeManagerFactory = 
			( NewsTypeManagerFactory ) NewsTypeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static NewsTypeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( NewsTypeUtility ).FullName);
		}

		private NewsTypeUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static NewsType CreateObject( )
		{
			NewsTypeManager newsTypeManager = ( NewsTypeManager ) _newsTypeManagerFactory.CreateInstance( );

			return ( NewsType )newsTypeManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, NewsType newsType )
		{
			NewsTypeManager newsTypeManager = ( NewsTypeManager ) _newsTypeManagerFactory.CreateInstance( dataSourceName );

			return newsTypeManager.Create( newsType );
		}

		public static bool Update( string dataSourceName, NewsType newsType )
		{
			NewsTypeManager newsTypeManager = ( NewsTypeManager ) _newsTypeManagerFactory.CreateInstance( dataSourceName );

			return newsTypeManager.Update( newsType );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			NewsTypeManager newsTypeManager = ( NewsTypeManager ) _newsTypeManagerFactory.CreateInstance( dataSourceName );

			return newsTypeManager.Delete( id );
		}

		public static NewsType Get( string dataSourceName, int id )
		{
			NewsTypeManager newsTypeManager = ( NewsTypeManager ) _newsTypeManagerFactory.CreateInstance( dataSourceName );

			return ( NewsType )newsTypeManager.Get( id );
		}

		public static NewsTypeCollection GetAll( string dataSourceName  )
		{
			NewsTypeManager newsTypeManager = ( NewsTypeManager ) _newsTypeManagerFactory.CreateInstance( dataSourceName );

			return ( NewsTypeCollection )newsTypeManager.GetAll( );
		}
		#endregion

	}
}
