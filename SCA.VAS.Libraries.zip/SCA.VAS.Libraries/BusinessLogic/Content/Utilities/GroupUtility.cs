#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class GroupUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly GroupManagerFactory _groupManagerFactory = 
			( GroupManagerFactory ) GroupManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static GroupUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( GroupUtility ).FullName);
		}

		private GroupUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static Group CreateObject( )
		{
			GroupManager groupManager = ( GroupManager ) _groupManagerFactory.CreateInstance( );

			return ( Group )groupManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, Group group )
		{
			GroupManager groupManager = ( GroupManager ) _groupManagerFactory.CreateInstance( dataSourceName );

			return groupManager.Create( group );
		}

		public static bool Update( string dataSourceName, Group group )
		{
			GroupManager groupManager = ( GroupManager ) _groupManagerFactory.CreateInstance( dataSourceName );

			return groupManager.Update( group );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			GroupManager groupManager = ( GroupManager ) _groupManagerFactory.CreateInstance( dataSourceName );

			return groupManager.Delete( id );
		}

		public static Group Get( string dataSourceName, int id )
		{
			GroupManager groupManager = ( GroupManager ) _groupManagerFactory.CreateInstance( dataSourceName );

			return ( Group )groupManager.Get( id );
		}

		public static GroupCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			GroupManager groupManager = ( GroupManager ) _groupManagerFactory.CreateInstance( dataSourceName );

			return ( GroupCollection )groupManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
