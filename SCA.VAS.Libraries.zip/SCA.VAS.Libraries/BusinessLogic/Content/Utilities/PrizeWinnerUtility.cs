#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class PrizeWinnerUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PrizeWinnerManagerFactory _prizeWinnerManagerFactory = 
			( PrizeWinnerManagerFactory ) PrizeWinnerManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PrizeWinnerUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PrizeWinnerUtility ).FullName);
		}

		private PrizeWinnerUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static PrizeWinner CreateObject( )
		{
			PrizeWinnerManager prizeWinnerManager = ( PrizeWinnerManager ) _prizeWinnerManagerFactory.CreateInstance( );

			return ( PrizeWinner )prizeWinnerManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, PrizeWinner prizeWinner )
		{
			PrizeWinnerManager prizeWinnerManager = ( PrizeWinnerManager ) _prizeWinnerManagerFactory.CreateInstance( dataSourceName );

			return prizeWinnerManager.Create( prizeWinner );
		}

		public static bool Update( string dataSourceName, PrizeWinner prizeWinner )
		{
			PrizeWinnerManager prizeWinnerManager = ( PrizeWinnerManager ) _prizeWinnerManagerFactory.CreateInstance( dataSourceName );

			return prizeWinnerManager.Update( prizeWinner );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			PrizeWinnerManager prizeWinnerManager = ( PrizeWinnerManager ) _prizeWinnerManagerFactory.CreateInstance( dataSourceName );

			return prizeWinnerManager.Delete( id );
		}

		public static PrizeWinner Get( string dataSourceName, int id )
		{
			PrizeWinnerManager prizeWinnerManager = ( PrizeWinnerManager ) _prizeWinnerManagerFactory.CreateInstance( dataSourceName );

			return ( PrizeWinner )prizeWinnerManager.Get( id );
		}

		public static PrizeWinnerCollection GetAll( string dataSourceName  )
		{
			PrizeWinnerManager prizeWinnerManager = ( PrizeWinnerManager ) _prizeWinnerManagerFactory.CreateInstance( dataSourceName );

			return ( PrizeWinnerCollection )prizeWinnerManager.GetAll( );
		}

		public static PrizeWinnerCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PrizeWinnerManager prizeWinnerManager = ( PrizeWinnerManager ) _prizeWinnerManagerFactory.CreateInstance( dataSourceName );

			return ( PrizeWinnerCollection )prizeWinnerManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
