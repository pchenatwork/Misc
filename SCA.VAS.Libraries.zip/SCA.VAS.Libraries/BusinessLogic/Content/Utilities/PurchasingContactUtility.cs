#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class PurchasingContactUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PurchasingContactManagerFactory _purchasingContactManagerFactory = 
			( PurchasingContactManagerFactory ) PurchasingContactManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PurchasingContactUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PurchasingContactUtility ).FullName);
		}

		private PurchasingContactUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static PurchasingContact CreateObject( )
		{
			PurchasingContactManager purchasingContactManager = ( PurchasingContactManager ) _purchasingContactManagerFactory.CreateInstance( );

			return ( PurchasingContact )purchasingContactManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, PurchasingContact purchasingContact )
		{
			PurchasingContactManager purchasingContactManager = ( PurchasingContactManager ) _purchasingContactManagerFactory.CreateInstance( dataSourceName );

			return purchasingContactManager.Create( purchasingContact );
		}

        public static bool Update(string dataSourceName, PurchasingContact purchasingContact)
        {
            PurchasingContactManager purchasingContactManager = (PurchasingContactManager)_purchasingContactManagerFactory.CreateInstance(dataSourceName);

            return purchasingContactManager.Update(purchasingContact);
        }

		public static bool Delete( string dataSourceName, int id )
		{
			PurchasingContactManager purchasingContactManager = ( PurchasingContactManager ) _purchasingContactManagerFactory.CreateInstance( dataSourceName );

			return purchasingContactManager.Delete( id );
		}

		public static PurchasingContact Get( string dataSourceName, int id )
		{
			PurchasingContactManager purchasingContactManager = ( PurchasingContactManager ) _purchasingContactManagerFactory.CreateInstance( dataSourceName );

			return ( PurchasingContact )purchasingContactManager.Get( id );
		}

		public static PurchasingContactCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PurchasingContactManager purchasingContactManager = ( PurchasingContactManager ) _purchasingContactManagerFactory.CreateInstance( dataSourceName );

			return ( PurchasingContactCollection )purchasingContactManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
