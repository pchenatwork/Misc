#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class MessageUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly MessageManagerFactory _messageManagerFactory = 
			( MessageManagerFactory ) MessageManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static MessageUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( MessageUtility ).FullName);
		}

		private MessageUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static Message CreateObject( )
		{
			MessageManager messageManager = ( MessageManager ) _messageManagerFactory.CreateInstance( );

			return ( Message )messageManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, Message message )
		{
			MessageManager messageManager = ( MessageManager ) _messageManagerFactory.CreateInstance( dataSourceName );

			return messageManager.Create( message );
		}

		public static bool Update( string dataSourceName, Message message )
		{
			MessageManager messageManager = ( MessageManager ) _messageManagerFactory.CreateInstance( dataSourceName );

			return messageManager.Update( message );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			MessageManager messageManager = ( MessageManager ) _messageManagerFactory.CreateInstance( dataSourceName );

			return messageManager.Delete( id );
		}

		public static Message Get( string dataSourceName, int id )
		{
			MessageManager messageManager = ( MessageManager ) _messageManagerFactory.CreateInstance( dataSourceName );

			return ( Message )messageManager.Get( id );
		}

		public static MessageCollection GetAll( string dataSourceName  )
		{
			MessageManager messageManager = ( MessageManager ) _messageManagerFactory.CreateInstance( dataSourceName );

			return ( MessageCollection )messageManager.GetAll( );
		}

		public static MessageCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			MessageManager messageManager = ( MessageManager ) _messageManagerFactory.CreateInstance( dataSourceName );

			return ( MessageCollection )messageManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
