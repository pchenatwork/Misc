#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class ActivityMemberUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly ActivityMemberManagerFactory _activityMemberManagerFactory = 
			( ActivityMemberManagerFactory ) ActivityMemberManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static ActivityMemberUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ActivityMemberUtility ).FullName);
		}

		private ActivityMemberUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static ActivityMember CreateObject( )
		{
			ActivityMemberManager activityMemberManager = ( ActivityMemberManager ) _activityMemberManagerFactory.CreateInstance( );

			return ( ActivityMember )activityMemberManager.CreateObject( );
		}

		public static bool UpdateCollection( string dataSourceName, int activityId, ActivityMemberCollection collection )
		{
			ActivityMemberManager activityMemberManager = ( ActivityMemberManager ) _activityMemberManagerFactory.CreateInstance( dataSourceName );

			return activityMemberManager.UpdateCollection( activityId, collection );
		}

		public static bool DeleteCollection( string dataSourceName, int activityId, ActivityMemberCollection collection )
		{
			ActivityMemberManager activityMemberManager = ( ActivityMemberManager ) _activityMemberManagerFactory.CreateInstance( dataSourceName );

			return activityMemberManager.DeleteCollection( activityId, collection );
		}

		public static bool DeleteByActivity( string dataSourceName, int activityId )
		{
			ActivityMemberManager activityMemberManager = ( ActivityMemberManager ) _activityMemberManagerFactory.CreateInstance( dataSourceName );

			return activityMemberManager.DeleteByActivity( activityId );
		}

		public static ActivityMemberCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			ActivityMemberManager activityMemberManager = ( ActivityMemberManager ) _activityMemberManagerFactory.CreateInstance( dataSourceName );

			return ( ActivityMemberCollection )activityMemberManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
