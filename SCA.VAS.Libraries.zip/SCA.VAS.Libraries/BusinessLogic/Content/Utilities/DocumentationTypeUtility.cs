#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class DocumentationTypeUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly DocumentationTypeManagerFactory _documentationTypeManagerFactory = 
			( DocumentationTypeManagerFactory ) DocumentationTypeManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static DocumentationTypeUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( DocumentationTypeUtility ).FullName);
		}

		private DocumentationTypeUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static DocumentationType CreateObject( )
		{
			DocumentationTypeManager documentationTypeManager = ( DocumentationTypeManager ) _documentationTypeManagerFactory.CreateInstance( );

			return ( DocumentationType )documentationTypeManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, DocumentationType documentationType )
		{
			DocumentationTypeManager documentationTypeManager = ( DocumentationTypeManager ) _documentationTypeManagerFactory.CreateInstance( dataSourceName );

			return documentationTypeManager.Create( documentationType );
		}

		public static bool Update( string dataSourceName, DocumentationType documentationType )
		{
			DocumentationTypeManager documentationTypeManager = ( DocumentationTypeManager ) _documentationTypeManagerFactory.CreateInstance( dataSourceName );

			return documentationTypeManager.Update( documentationType );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			DocumentationTypeManager documentationTypeManager = ( DocumentationTypeManager ) _documentationTypeManagerFactory.CreateInstance( dataSourceName );

			return documentationTypeManager.Delete( id );
		}

		public static DocumentationType Get( string dataSourceName, int id )
		{
			DocumentationTypeManager documentationTypeManager = ( DocumentationTypeManager ) _documentationTypeManagerFactory.CreateInstance( dataSourceName );

			return ( DocumentationType )documentationTypeManager.Get( id );
		}

		public static DocumentationTypeCollection GetAll( string dataSourceName  )
		{
			DocumentationTypeManager documentationTypeManager = ( DocumentationTypeManager ) _documentationTypeManagerFactory.CreateInstance( dataSourceName );

			return ( DocumentationTypeCollection )documentationTypeManager.GetAll( );
		}

        public static DocumentationTypeCollection FindByCriteria(string dataSourceName, string finderType, object[] criteria)
        {
            DocumentationTypeManager documentationTypeManager = (DocumentationTypeManager)_documentationTypeManagerFactory.CreateInstance(dataSourceName);

            return (DocumentationTypeCollection)documentationTypeManager.FindByCriteria(finderType, criteria);
        }
		#endregion

	}
}
