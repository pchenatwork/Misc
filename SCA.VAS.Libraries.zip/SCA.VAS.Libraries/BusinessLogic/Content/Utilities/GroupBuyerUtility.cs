#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class GroupBuyerUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly GroupBuyerManagerFactory _groupBuyerManagerFactory = 
			( GroupBuyerManagerFactory ) GroupBuyerManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static GroupBuyerUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( GroupBuyerUtility ).FullName );
		}

		private GroupBuyerUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static GroupBuyer CreateObject( )
		{
			GroupBuyerManager groupBuyerManager = ( GroupBuyerManager ) _groupBuyerManagerFactory.CreateInstance( );

			return ( GroupBuyer )groupBuyerManager.CreateObject( );
		}

		public static bool UpdateCollection( string dataSourceName, int groupId, GroupBuyerCollection collection )
		{
			GroupBuyerManager groupBuyerManager = ( GroupBuyerManager ) _groupBuyerManagerFactory.CreateInstance( dataSourceName );

			return groupBuyerManager.UpdateCollection( groupId, collection );
		}

		public static bool DeleteCollection( string dataSourceName, int groupId, GroupBuyerCollection collection )
		{
			GroupBuyerManager groupBuyerManager = ( GroupBuyerManager ) _groupBuyerManagerFactory.CreateInstance( dataSourceName );

			return groupBuyerManager.DeleteCollection( groupId, collection );
		}

		public static GroupBuyerCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			GroupBuyerManager groupBuyerManager = ( GroupBuyerManager ) _groupBuyerManagerFactory.CreateInstance( dataSourceName );

			return ( GroupBuyerCollection )groupBuyerManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
