#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class NewsletterUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly NewsletterManagerFactory _newsletterManagerFactory = 
			( NewsletterManagerFactory ) NewsletterManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static NewsletterUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( NewsletterUtility ).FullName);
		}

		private NewsletterUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static Newsletter CreateObject( )
		{
			NewsletterManager newsletterManager = ( NewsletterManager ) _newsletterManagerFactory.CreateInstance( );

			return ( Newsletter )newsletterManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, Newsletter newsletter )
		{
			NewsletterManager newsletterManager = ( NewsletterManager ) _newsletterManagerFactory.CreateInstance( dataSourceName );

			return newsletterManager.Create( newsletter );
		}

		public static bool Update( string dataSourceName, Newsletter newsletter )
		{
			NewsletterManager newsletterManager = ( NewsletterManager ) _newsletterManagerFactory.CreateInstance( dataSourceName );

			return newsletterManager.Update( newsletter );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			NewsletterManager newsletterManager = ( NewsletterManager ) _newsletterManagerFactory.CreateInstance( dataSourceName );

			return newsletterManager.Delete( id );
		}

		public static Newsletter Get( string dataSourceName, int id )
		{
			NewsletterManager newsletterManager = ( NewsletterManager ) _newsletterManagerFactory.CreateInstance( dataSourceName );

			return ( Newsletter )newsletterManager.Get( id );
		}

		public static NewsletterCollection GetAll( string dataSourceName  )
		{
			NewsletterManager newsletterManager = ( NewsletterManager ) _newsletterManagerFactory.CreateInstance( dataSourceName );

			return ( NewsletterCollection )newsletterManager.GetAll( );
		}

		public static NewsletterCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			NewsletterManager newsletterManager = ( NewsletterManager ) _newsletterManagerFactory.CreateInstance( dataSourceName );

			return ( NewsletterCollection )newsletterManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
