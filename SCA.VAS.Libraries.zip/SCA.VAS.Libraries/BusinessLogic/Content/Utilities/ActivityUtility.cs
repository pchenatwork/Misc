#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class ActivityUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly ActivityManagerFactory _activityManagerFactory = 
			( ActivityManagerFactory ) ActivityManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static ActivityUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ActivityUtility ).FullName);
		}

		private ActivityUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static Activity CreateObject( )
		{
			ActivityManager activityManager = ( ActivityManager ) _activityManagerFactory.CreateInstance( );

			return ( Activity )activityManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, Activity activity )
		{
			ActivityManager activityManager = ( ActivityManager ) _activityManagerFactory.CreateInstance( dataSourceName );

			return activityManager.Create( activity );
		}

		public static bool Update( string dataSourceName, Activity activity )
		{
			ActivityManager activityManager = ( ActivityManager ) _activityManagerFactory.CreateInstance( dataSourceName );

			return activityManager.Update( activity );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			ActivityManager activityManager = ( ActivityManager ) _activityManagerFactory.CreateInstance( dataSourceName );

			return activityManager.Delete( id );
		}

		public static Activity Get( string dataSourceName, int id )
		{
			ActivityManager activityManager = ( ActivityManager ) _activityManagerFactory.CreateInstance( dataSourceName );

			return ( Activity )activityManager.Get( id );
		}

		public static ActivityCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			ActivityManager activityManager = ( ActivityManager ) _activityManagerFactory.CreateInstance( dataSourceName );

			return ( ActivityCollection )activityManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
