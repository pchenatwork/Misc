#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class ServiceUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly ServiceManagerFactory _serviceManagerFactory = 
			( ServiceManagerFactory ) ServiceManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static ServiceUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( ServiceUtility ).FullName);
		}

		private ServiceUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static Service CreateObject( )
		{
			ServiceManager serviceManager = ( ServiceManager ) _serviceManagerFactory.CreateInstance( );

			return ( Service )serviceManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, Service service )
		{
			ServiceManager serviceManager = ( ServiceManager ) _serviceManagerFactory.CreateInstance( dataSourceName );

			return serviceManager.Create( service );
		}

		public static bool Update( string dataSourceName, Service service )
		{
			ServiceManager serviceManager = ( ServiceManager ) _serviceManagerFactory.CreateInstance( dataSourceName );

			return serviceManager.Update( service );
		}

		public static bool UpdateCollection( string dataSourceName, int supplierId, ServiceCollection collection )
		{
			ServiceManager serviceManager = ( ServiceManager ) _serviceManagerFactory.CreateInstance( dataSourceName );

			return serviceManager.UpdateCollection( supplierId, collection );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			ServiceManager serviceManager = ( ServiceManager ) _serviceManagerFactory.CreateInstance( dataSourceName );

			return serviceManager.Delete( id );
		}

		public static bool DeletePicture( string dataSourceName, int id )
		{
			ServiceManager serviceManager = ( ServiceManager ) _serviceManagerFactory.CreateInstance( dataSourceName );

			return serviceManager.DeletePicture( id );
		}

		public static Service Get( string dataSourceName, int id )
		{
			ServiceManager serviceManager = ( ServiceManager ) _serviceManagerFactory.CreateInstance( dataSourceName );

			return ( Service )serviceManager.Get( id );
		}

		public static Service GetById( string dataSourceName, Guid serviceId )
		{
			ServiceManager serviceManager = ( ServiceManager ) _serviceManagerFactory.CreateInstance( dataSourceName );

			return ( Service )serviceManager.GetById( serviceId );
		}

		public static byte[] GetPicture( string dataSourceName, int id )
		{
			ServiceManager serviceManager = ( ServiceManager ) _serviceManagerFactory.CreateInstance( dataSourceName );

			return ( byte[] )serviceManager.GetPicture( id );
		}

		public static byte[] GetPictureById( string dataSourceName, Guid serviceId )
		{
			ServiceManager serviceManager = ( ServiceManager ) _serviceManagerFactory.CreateInstance( dataSourceName );

			return ( byte[] )serviceManager.GetPictureById( serviceId );
		}

		public static ServiceCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			ServiceManager serviceManager = ( ServiceManager ) _serviceManagerFactory.CreateInstance( dataSourceName );

			return ( ServiceCollection )serviceManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
