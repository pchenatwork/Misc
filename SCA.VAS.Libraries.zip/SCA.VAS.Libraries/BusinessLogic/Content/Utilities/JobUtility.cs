#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class JobUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly JobManagerFactory _jobManagerFactory = 
			( JobManagerFactory ) JobManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static JobUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( JobUtility ).FullName);
		}

		private JobUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static Job CreateObject( )
		{
			JobManager jobManager = ( JobManager ) _jobManagerFactory.CreateInstance( );

			return ( Job )jobManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, Job job )
		{
			JobManager jobManager = ( JobManager ) _jobManagerFactory.CreateInstance( dataSourceName );

			return jobManager.Create( job );
		}

		public static bool Update( string dataSourceName, Job job )
		{
			JobManager jobManager = ( JobManager ) _jobManagerFactory.CreateInstance( dataSourceName );

			return jobManager.Update( job );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			JobManager jobManager = ( JobManager ) _jobManagerFactory.CreateInstance( dataSourceName );

			return jobManager.Delete( id );
		}

		public static Job Get( string dataSourceName, int id )
		{
			JobManager jobManager = ( JobManager ) _jobManagerFactory.CreateInstance( dataSourceName );

			return ( Job )jobManager.Get( id );
		}

		public static JobCollection GetAll( string dataSourceName  )
		{
			JobManager jobManager = ( JobManager ) _jobManagerFactory.CreateInstance( dataSourceName );

			return ( JobCollection )jobManager.GetAll( );
		}

		public static JobCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			JobManager jobManager = ( JobManager ) _jobManagerFactory.CreateInstance( dataSourceName );

			return ( JobCollection )jobManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
