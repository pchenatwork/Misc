#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class BuyerCommentUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly BuyerCommentManagerFactory _buyerCommentManagerFactory = 
			( BuyerCommentManagerFactory ) BuyerCommentManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static BuyerCommentUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( BuyerCommentUtility ).FullName);
		}

		private BuyerCommentUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static BuyerComment CreateObject( )
		{
			BuyerCommentManager buyerCommentManager = ( BuyerCommentManager ) _buyerCommentManagerFactory.CreateInstance( );

			return ( BuyerComment )buyerCommentManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, BuyerComment buyerComment )
		{
			BuyerCommentManager buyerCommentManager = ( BuyerCommentManager ) _buyerCommentManagerFactory.CreateInstance( dataSourceName );

			return buyerCommentManager.Create( buyerComment );
		}

		public static bool Update( string dataSourceName, BuyerComment buyerComment )
		{
			BuyerCommentManager buyerCommentManager = ( BuyerCommentManager ) _buyerCommentManagerFactory.CreateInstance( dataSourceName );

			return buyerCommentManager.Update( buyerComment );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			BuyerCommentManager buyerCommentManager = ( BuyerCommentManager ) _buyerCommentManagerFactory.CreateInstance( dataSourceName );

			return buyerCommentManager.Delete( id );
		}

		public static BuyerComment Get( string dataSourceName, int id )
		{
			BuyerCommentManager buyerCommentManager = ( BuyerCommentManager ) _buyerCommentManagerFactory.CreateInstance( dataSourceName );

			return ( BuyerComment )buyerCommentManager.Get( id );
		}

		public static BuyerCommentCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			BuyerCommentManager buyerCommentManager = ( BuyerCommentManager ) _buyerCommentManagerFactory.CreateInstance( dataSourceName );

			return ( BuyerCommentCollection )buyerCommentManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
