#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class AlbumUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly AlbumManagerFactory _albumManagerFactory = 
			( AlbumManagerFactory ) AlbumManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static AlbumUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( AlbumUtility ).FullName);
		}

		private AlbumUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static Album CreateObject( )
		{
			AlbumManager albumManager = ( AlbumManager ) _albumManagerFactory.CreateInstance( );

			return ( Album )albumManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, Album album )
		{
			AlbumManager albumManager = ( AlbumManager ) _albumManagerFactory.CreateInstance( dataSourceName );

			return albumManager.Create( album );
		}

		public static bool Update( string dataSourceName, Album album )
		{
			AlbumManager albumManager = ( AlbumManager ) _albumManagerFactory.CreateInstance( dataSourceName );

			return albumManager.Update( album );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			AlbumManager albumManager = ( AlbumManager ) _albumManagerFactory.CreateInstance( dataSourceName );

			return albumManager.Delete( id );
		}

		public static Album Get( string dataSourceName, int id )
		{
			AlbumManager albumManager = ( AlbumManager ) _albumManagerFactory.CreateInstance( dataSourceName );

			return ( Album )albumManager.Get( id );
		}

		public static AlbumCollection GetAll( string dataSourceName  )
		{
			AlbumManager albumManager = ( AlbumManager ) _albumManagerFactory.CreateInstance( dataSourceName );

			return ( AlbumCollection )albumManager.GetAll( );
		}

		public static AlbumCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			AlbumManager albumManager = ( AlbumManager ) _albumManagerFactory.CreateInstance( dataSourceName );

			return ( AlbumCollection )albumManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
