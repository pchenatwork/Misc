#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class DocumentationUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly DocumentationManagerFactory _documentationManagerFactory = 
			( DocumentationManagerFactory ) DocumentationManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static DocumentationUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( DocumentationUtility ).FullName);
		}

		private DocumentationUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static Documentation CreateObject( )
		{
			DocumentationManager documentationManager = ( DocumentationManager ) _documentationManagerFactory.CreateInstance( );

			return ( Documentation )documentationManager.CreateObject( );
		}
		
		public static bool Create( string dataSourceName, Documentation documentation )
		{
			DocumentationManager documentationManager = ( DocumentationManager ) _documentationManagerFactory.CreateInstance( dataSourceName );

			return documentationManager.Create( documentation );
		}

		public static bool Update( string dataSourceName, Documentation documentation )
		{
			DocumentationManager documentationManager = ( DocumentationManager ) _documentationManagerFactory.CreateInstance( dataSourceName );

			return documentationManager.Update( documentation );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			DocumentationManager documentationManager = ( DocumentationManager ) _documentationManagerFactory.CreateInstance( dataSourceName );

			return documentationManager.Delete( id );
		}

		public static Documentation Get( string dataSourceName, int id )
		{
			DocumentationManager documentationManager = ( DocumentationManager ) _documentationManagerFactory.CreateInstance( dataSourceName );

			return ( Documentation )documentationManager.Get( id );
		}

		public static Documentation GetByName( string dataSourceName, string filename, string category )
		{
			DocumentationManager documentationManager = ( DocumentationManager ) _documentationManagerFactory.CreateInstance( dataSourceName );

			return ( Documentation )documentationManager.GetByName( filename, category );
		}

        public static void GenerateDisplayNo(DocumentationCollection documentations,
            string displayNo)
        {
            if (documentations == null)
                return;

            int i = 0;
            foreach (Documentation d in documentations)
            {
                i++;
                d.DisplayNo = displayNo + i;
                GenerateDisplayNo(d.SubDocumentations, d.DisplayNo + ".");
            }
        }

		public static DocumentationCollection GetAll( string dataSourceName  )
		{
			DocumentationManager documentationManager = ( DocumentationManager ) _documentationManagerFactory.CreateInstance( dataSourceName );

			return ( DocumentationCollection )documentationManager.GetAll( );
		}

		public static DocumentationCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			DocumentationManager documentationManager = ( DocumentationManager ) _documentationManagerFactory.CreateInstance( dataSourceName );

			return ( DocumentationCollection )documentationManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
