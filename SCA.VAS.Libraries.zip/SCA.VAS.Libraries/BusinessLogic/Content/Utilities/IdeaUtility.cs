#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;


namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class IdeaUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly IdeaManagerFactory _ideaManagerFactory = 
			( IdeaManagerFactory ) IdeaManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static IdeaUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( IdeaUtility ).FullName);
		}

		private IdeaUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static Idea CreateObject( )
		{
			IdeaManager ideaManager = ( IdeaManager ) _ideaManagerFactory.CreateInstance( );

			return ( Idea )ideaManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, Idea idea )
		{
			IdeaManager ideaManager = ( IdeaManager ) _ideaManagerFactory.CreateInstance( dataSourceName );

			return ideaManager.Create( idea );
		}

		public static bool Update( string dataSourceName, Idea idea )
		{
			IdeaManager ideaManager = ( IdeaManager ) _ideaManagerFactory.CreateInstance( dataSourceName );

			return ideaManager.Update( idea );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			IdeaManager ideaManager = ( IdeaManager ) _ideaManagerFactory.CreateInstance( dataSourceName );

			return ideaManager.Delete( id );
		}

		public static Idea Get( string dataSourceName, int id )
		{
			IdeaManager ideaManager = ( IdeaManager ) _ideaManagerFactory.CreateInstance( dataSourceName );

			return ( Idea )ideaManager.Get( id );
		}

		public static byte[] GetImage( string dataSourceName, int id, int fileNo )
		{
			IdeaManager ideaManager = ( IdeaManager ) _ideaManagerFactory.CreateInstance( dataSourceName );

            return (byte[])ideaManager.GetImage(id, fileNo);
		}

		public static IdeaCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			IdeaManager ideaManager = ( IdeaManager ) _ideaManagerFactory.CreateInstance( dataSourceName );

			return ( IdeaCollection )ideaManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
