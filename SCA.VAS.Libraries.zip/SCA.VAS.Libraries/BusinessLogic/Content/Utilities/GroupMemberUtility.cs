#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class GroupMemberUtility
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly GroupMemberManagerFactory _groupMemberManagerFactory = 
			( GroupMemberManagerFactory ) GroupMemberManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static GroupMemberUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( GroupMemberUtility ).FullName);
		}

		private GroupMemberUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static GroupMember CreateObject( )
		{
			GroupMemberManager groupMemberManager = ( GroupMemberManager ) _groupMemberManagerFactory.CreateInstance( );

			return ( GroupMember )groupMemberManager.CreateObject( );
		}

		public static bool UpdateCollection( string dataSourceName, int groupId, GroupMemberCollection collection )
		{
			GroupMemberManager groupMemberManager = ( GroupMemberManager ) _groupMemberManagerFactory.CreateInstance( dataSourceName );

			return groupMemberManager.UpdateCollection( groupId, collection );
		}

		public static bool DeleteCollection( string dataSourceName, int groupId, GroupMemberCollection collection )
		{
			GroupMemberManager groupMemberManager = ( GroupMemberManager ) _groupMemberManagerFactory.CreateInstance( dataSourceName );

			return groupMemberManager.DeleteCollection( groupId, collection );
		}

		public static bool DeleteByGroup( string dataSourceName, int groupId )
		{
			GroupMemberManager groupMemberManager = ( GroupMemberManager ) _groupMemberManagerFactory.CreateInstance( dataSourceName );

			return groupMemberManager.DeleteByGroup( groupId );
		}

		public static GroupMemberCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			GroupMemberManager groupMemberManager = ( GroupMemberManager ) _groupMemberManagerFactory.CreateInstance( dataSourceName );

			return ( GroupMemberCollection )groupMemberManager.FindByCriteria( finderType, criteria );
		}
		#endregion
	}
}
