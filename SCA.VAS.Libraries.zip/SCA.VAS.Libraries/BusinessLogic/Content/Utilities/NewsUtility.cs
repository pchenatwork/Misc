#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class NewsUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly NewsManagerFactory _newsManagerFactory = 
			( NewsManagerFactory ) NewsManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static NewsUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( NewsUtility ).FullName);
		}

		private NewsUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static News CreateObject( )
		{
			NewsManager newsManager = ( NewsManager ) _newsManagerFactory.CreateInstance( );

			return ( News )newsManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, News news )
		{
			NewsManager newsManager = ( NewsManager ) _newsManagerFactory.CreateInstance( dataSourceName );

			return newsManager.Create( news );
		}

		public static bool Update( string dataSourceName, News news )
		{
			NewsManager newsManager = ( NewsManager ) _newsManagerFactory.CreateInstance( dataSourceName );

			return newsManager.Update( news );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			NewsManager newsManager = ( NewsManager ) _newsManagerFactory.CreateInstance( dataSourceName );

			return newsManager.Delete( id );
		}

		public static News Get( string dataSourceName, int id )
		{
			NewsManager newsManager = ( NewsManager ) _newsManagerFactory.CreateInstance( dataSourceName );

			return ( News )newsManager.Get( id );
		}

		public static NewsCollection GetAll( string dataSourceName  )
		{
			NewsManager newsManager = ( NewsManager ) _newsManagerFactory.CreateInstance( dataSourceName );

			return ( NewsCollection )newsManager.GetAll( );
		}

		public static NewsCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			NewsManager newsManager = ( NewsManager ) _newsManagerFactory.CreateInstance( dataSourceName );

			return ( NewsCollection )newsManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
