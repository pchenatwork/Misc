#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class PageLinkUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PageLinkManagerFactory _pageLinkManagerFactory = 
			( PageLinkManagerFactory ) PageLinkManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PageLinkUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PageLinkUtility ).FullName);
		}

		private PageLinkUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static PageLink CreateObject( )
		{
			PageLinkManager pageLinkManager = ( PageLinkManager ) _pageLinkManagerFactory.CreateInstance( );

			return ( PageLink )pageLinkManager.CreateObject( );
		}

		public static bool Create( string dataSourceName, PageLink pageLink )
		{
			PageLinkManager pageLinkManager = ( PageLinkManager ) _pageLinkManagerFactory.CreateInstance( dataSourceName );

			return pageLinkManager.Create( pageLink );
		}

		public static bool Update( string dataSourceName, PageLink pageLink )
		{
			PageLinkManager pageLinkManager = ( PageLinkManager ) _pageLinkManagerFactory.CreateInstance( dataSourceName );

			return pageLinkManager.Update( pageLink );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			PageLinkManager pageLinkManager = ( PageLinkManager ) _pageLinkManagerFactory.CreateInstance( dataSourceName );

			return pageLinkManager.Delete( id );
		}

		public static PageLink Get( string dataSourceName, int id )
		{
			PageLinkManager pageLinkManager = ( PageLinkManager ) _pageLinkManagerFactory.CreateInstance( dataSourceName );

			return ( PageLink )pageLinkManager.Get( id );
		}

		public static PageLinkCollection GetAll( string dataSourceName  )
		{
			PageLinkManager pageLinkManager = ( PageLinkManager ) _pageLinkManagerFactory.CreateInstance( dataSourceName );

			return ( PageLinkCollection )pageLinkManager.GetAll( );
		}

		public static PageLinkCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PageLinkManager pageLinkManager = ( PageLinkManager ) _pageLinkManagerFactory.CreateInstance( dataSourceName );

			return ( PageLinkCollection )pageLinkManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
