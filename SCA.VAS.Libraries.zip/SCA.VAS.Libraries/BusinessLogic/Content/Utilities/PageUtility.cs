#region	Copyright
/*=======================================================================
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

using System;
using System.Data;

using SCA.VAS.ValueObjects.Content;
using SCA.VAS.Common.Utilities;	
using SCA.VAS.DataAccess.Transactions;

using log4net;

namespace SCA.VAS.BusinessLogic.Content.Utilities
{
	/// <summary>
	/// Transaction related utility functions.
	/// </summary>
	public class PageUtility
	{

		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>
		/// logging component
		/// </summary>
		private static ILog _logger;

		private static readonly PageManagerFactory _pageManagerFactory = 
			( PageManagerFactory ) PageManagerFactory.Instance( );

		#endregion

		#region	Constructors
		// *************************************************************************
		//				 constructors
		// *************************************************************************
		static PageUtility()
		{
			_logger	= LoggingUtility.GetLogger( typeof( PageUtility ).FullName);
		}

		private PageUtility()
		{
		}
		#endregion 

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   public SCA.VAS.
		//	*************************************************************************
		public static Page CreateObject( )
		{
			PageManager pageManager = ( PageManager ) _pageManagerFactory.CreateInstance( );

			return ( Page )pageManager.CreateObject( );
		}

		
		public static bool Create( string dataSourceName, Page page )
		{
			PageManager pageManager = ( PageManager ) _pageManagerFactory.CreateInstance( dataSourceName );

			return pageManager.Create( page );
		}

		public static bool Update( string dataSourceName, Page page )
		{
			PageManager pageManager = ( PageManager ) _pageManagerFactory.CreateInstance( dataSourceName );

			return pageManager.Update( page );
		}

		public static bool Delete( string dataSourceName, int id )
		{
			PageManager pageManager = ( PageManager ) _pageManagerFactory.CreateInstance( dataSourceName );

			return pageManager.Delete( id );
		}

		public static Page Get( string dataSourceName, int id )
		{
			PageManager pageManager = ( PageManager ) _pageManagerFactory.CreateInstance( dataSourceName );

			return ( Page )pageManager.Get( id );
		}

        public static Page GetByMenu(string dataSourceName, int menuId)
        {
            PageManager pageManager = (PageManager)_pageManagerFactory.CreateInstance(dataSourceName);

            return (Page)pageManager.GetByMenu(menuId);
        }

        public static Page GetByUrl(string dataSourceName, string applicationName, string url)
		{
			PageManager pageManager = ( PageManager ) _pageManagerFactory.CreateInstance( dataSourceName );

            return (Page)pageManager.GetByUrl(applicationName, url);
		}

		public static PageCollection FindByCriteria( string dataSourceName, string finderType, object[] criteria )
		{
			PageManager pageManager = ( PageManager ) _pageManagerFactory.CreateInstance( dataSourceName );

			return ( PageCollection )pageManager.FindByCriteria( finderType, criteria );
		}
		#endregion

	}
}
