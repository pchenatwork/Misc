#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Content
{
	#region	Header
	///	<summary>
	///	Factory for DocumentationPermission
	///	</summary>
	#endregion Header

	public sealed class DocumentationPermissionManagerFactory : AbstractManagerFactory
	{
		#region	Private Members
		// *************************************************************************
		//				 Private Members
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Members

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static DocumentationPermissionManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( DocumentationPermissionManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private DocumentationPermissionManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   Public SCA.VAS.
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the DocumentationPermissionManagerFactory
		/// </summary>
		/// <returns>an instance of DocumentationPermissionManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( DocumentationPermissionManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new DocumentationPermissionManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( )
		{
			return new DocumentationPermissionManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new DocumentationPermissionManager( dataSourceName );
		} 
		
		#endregion
	} 
} 