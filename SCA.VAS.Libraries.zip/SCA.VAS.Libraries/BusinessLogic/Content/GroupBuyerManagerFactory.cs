#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2003 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Content
{
	#region	Header
	///	<summary>
	///	Factory for GroupBuyerManager
	///	</summary>
	#endregion Header

	public sealed class GroupBuyerManagerFactory : AbstractManagerFactory
	{
		#region	Private Buyers
		// *************************************************************************
		//				 Private Buyers
		// *************************************************************************
		/// <summary>the singleton factory instance</summary>
		private static IManagerFactory	_factory = null;

		#endregion Private Buyers

		#region	Constructors
		// *************************************************************************
		//				 Constructors
		// *************************************************************************
		/// <summary>
		/// class constructor 
		/// initializes logging
		/// </summary>
		static GroupBuyerManagerFactory()
		{
			_logger	= LoggingUtility.GetLogger( typeof( GroupBuyerManagerFactory ).FullName);
		} 

		///	<summary>
		///	No constructor	
		///	</summary>
		private GroupBuyerManagerFactory()
		{
		} 

		#endregion Constructors

		#region	Public SCA.VAS.
		//	*************************************************************************
		//				   Public SCA.VAS.
		//	*************************************************************************
		/// <summary>
		/// Get singleton instance of the GroupBuyerManagerFactory
		/// </summary>
		/// <returns>an instance of GroupBuyerManagerFactory</returns>
		public static IManagerFactory Instance()
		{
			lock ( typeof( GroupBuyerManagerFactory ) )
			{
				if ( _factory == null )
				{
					_factory = new GroupBuyerManagerFactory();
				}
				return _factory;
			} 
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance()
		{
			return new GroupBuyerManager();
		} 

		/// <summary>
		/// Factory creation method for Manager instances
		/// </summary>
		/// <returns>
		/// an instance of Manager
		/// </returns>
		public override IManager CreateInstance( string dataSourceName )
		{
			return new GroupBuyerManager( dataSourceName );
		}  
		#endregion Public SCA.VAS.
	} 
} 
