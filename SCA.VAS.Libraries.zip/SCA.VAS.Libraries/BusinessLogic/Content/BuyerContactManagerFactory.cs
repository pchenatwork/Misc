#region	Copyright
/*=======================================================================
*
* Modification History:
* Date				Programmer			Description
*
*=======================================================================
* Copyright (C) 2004 AECsoft USA, Inc.
* All rights reserved.
*=======================================================================*/
#endregion Copyright

#region	References
using System;

using SCA.VAS.BusinessLogic.Managers;
using SCA.VAS.Common.Utilities;

using log4net;
#endregion References

namespace SCA.VAS.BusinessLogic.Content
{
    #region	Header
    ///	<summary>
    ///	Factory for BuyerContact
    ///	</summary>
    #endregion Header

    public sealed class BuyerContactManagerFactory : AbstractManagerFactory
    {
        #region	Private Members
        // *************************************************************************
        //				 Private Members
        // *************************************************************************
        /// <summary>the singleton factory instance</summary>
        private static IManagerFactory _factory = null;

        #endregion Private Members

        #region	Constructors
        // *************************************************************************
        //				 Constructors
        // *************************************************************************
        /// <summary>
        /// class constructor 
        /// initializes logging
        /// </summary>
        static BuyerContactManagerFactory()
        {
            _logger = LoggingUtility.GetLogger(typeof(BuyerContactManagerFactory).FullName);
        }

        ///	<summary>
        ///	No constructor	
        ///	</summary>
        private BuyerContactManagerFactory()
        {
        }

        #endregion Constructors

        #region	Public SCA.VAS.
        //	*************************************************************************
        //				   Public SCA.VAS.
        //	*************************************************************************
        /// <summary>
        /// Get singleton instance of the BuyerContactManagerFactory
        /// </summary>
        /// <returns>an instance of BuyerContactManagerFactory</returns>
        public static IManagerFactory Instance()
        {
            lock (typeof(BuyerContactManagerFactory))
            {
                if (_factory == null)
                {
                    _factory = new BuyerContactManagerFactory();
                }
                return _factory;
            }
        }

        /// <summary>
        /// Factory creation method for Manager instances
        /// </summary>
        /// <returns>
        /// an instance of Manager
        /// </returns>
        public override IManager CreateInstance()
        {
            return new BuyerContactManager();
        }

        /// <summary>
        /// Factory creation method for Manager instances
        /// </summary>
        /// <returns>
        /// an instance of Manager
        /// </returns>
        public override IManager CreateInstance(string dataSourceName)
        {
            return new BuyerContactManager(dataSourceName);
        }
        #endregion Public SCA.VAS.
    }
}